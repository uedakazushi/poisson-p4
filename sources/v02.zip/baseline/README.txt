射影4空間の Poisson 構造：部分分類と検証
2026年10月28日

結論の範囲
============
完全分類を証明した bundle ではありません。
Matviichuk--Pym--Schedler の toric degeneration をもつ rank 4 の40成分を
有理数線形代数で再列挙し、rank 2 の6族が全 Poisson scheme の成分であることを
整数係数の接空間計算で確認します。合わせて「少なくとも46成分」という下界です。
46が正確な総数とは主張しません。

読む順序
========
1. p4_poisson_classification.pdf
   日本語の研究ノート。全体の還元、分類表、6成分の証明、Aff(3,2)の変形、
   divisorial zero の境界への帰着、未解決部分、40図の識別表を含みます。
2. data/rank2_certificates.json
   6成分について、Jacobi 行列の rank と実際のパラメータ族の微分の rank、
   非零 minor による標数0の証明のデータです。
3. data/p4_toric_smoothing_diagrams.json
   40図の辺、orders、period space の有理数基底、整数 biresidue 行列の例。
4. data/aff32_certificate.json
   Aff(3,2)型の2変数族による rank 4 への変形、symbolic Jacobi、退化因子、
   toric limit、今回の図のID T19への同定を検証します。

次元の規約
==========
affine: 定数倍を含む Pois(P^4) 内の次元。
projective: 非零 Poisson 構造の定数倍を除いた空間の次元。
どちらも PGL(5) では割っていません。自己同型群の次元を無視して一律に24を
引いても、同型類のモジュライ次元にはなりません。

コードの実行
============
Python 3 と NumPy を使います。SymPy や外部CASは不要です。
このディレクトリをカレントディレクトリにして、次を実行できます。

  python3 code/verify_rank2_components.py
  python3 code/verify_aff32_deformation.py

2つの検証スクリプトは JSON を標準出力へ出し、外部ファイルを読みません。
同じ code ディレクトリの基礎モジュールを読み込みます。

40図の再列挙は Python 標準ライブラリのみです。

  python3 code/enumerate_p4_smoothing_diagrams.py

このスクリプトは列挙の進捗と集計を標準出力へ出し、同じ code ディレクトリに
p4_toric_smoothing_diagrams.json を生成します。保存済みの data/ のJSONが
基準となる出力です。data/ のCSVはその一覧・集計です。

LuaLaTeX ソース
==============
p4_poisson_classification.tex と toric_components_table.tex がPDFのソースです。
LuaLaTeX、LuaTeX-ja、HaranoAjiフォントを含むTeX Live環境で次を実行します。

  latexmk -lualatex p4_poisson_classification.tex

再現用データは浮動小数点の rank 推定を使いません。整数恒等式と素数1000003
上の非零 minor により、標数0での接空間次元上界と族の次元下界を一致させます。
初回探索では別実装・別素数による監査も実施していますが、同梱コードは最終の
具体例を直接検証するものです。

主な文献
========
https://arxiv.org/abs/2010.08692
https://arxiv.org/abs/2310.05284
https://arxiv.org/abs/2207.12880
https://arxiv.org/abs/2408.10057
https://arxiv.org/abs/1112.3871
https://www.math.mcgill.ca/bpym/files/bpym-thesis.pdf

未解決事項
==========
全rank4成分の40族への包含、rank2の安定な接層をもつ代数的可積分な分岐の
完全記述、成分間の交叉・境界・scheme構造、全点のPGL同型類の分類は残ります。
既存の表を全分類として読み替えないでください。

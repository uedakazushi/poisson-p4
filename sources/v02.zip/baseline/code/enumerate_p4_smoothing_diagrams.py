#!/usr/bin/env python3
"""Reconstruct the 40 toric smoothing diagrams for Poisson structures on P^4.

Python 3 standard library only; all linear algebra is over fractions.Fraction.
Reference: Matviichuk--Pym--Schedler, arXiv:2010.08692, Table 2, Theorem 1.4.
Sign convention: theta_ijk=(b_jk+b_ki)/b_ij, as in Matviichuk,
arXiv:2310.05284, Section 2. The skew 5x5 biresidue matrix has zero row sums
and generic rank four. Each edge's three nonnegative integer orders sum to 2.

This classifies ONLY components meeting the toric log-symplectic locus.
It makes no claim that those components exhaust all Poisson structures on P^4.
Run this script to write p4_toric_smoothing_diagrams.json alongside the script.
"""
import itertools
import json
import math
from collections import Counter
from fractions import Fraction as F
from pathlib import Path

N=5
EDGES=list(itertools.combinations(range(N),2))
PERMS=list(itertools.permutations(range(N)))
VARS=list(itertools.combinations(range(1,N),2))
ZERO=(0,)*6

def add(a,b):return tuple(x+y for x,y in zip(a,b))
def scale(c,a):return tuple(c*x for x in a)
def dot(a,b):return sum(x*y for x,y in zip(a,b))

B=[[ZERO for j in range(N)] for i in range(N)]
for index,(i,j) in enumerate(VARS):
    row=[0]*6;row[index]=1;B[i][j]=tuple(row);B[j][i]=scale(-1,row)
for i in range(1,N):
    B[0][i]=tuple(sum(B[i][j][k] for j in range(1,N)) for k in range(6))
    B[i][0]=scale(-1,B[0][i])
assert all(tuple(sum(B[i][j][k] for j in range(N)) for k in range(6))==ZERO
           for i in range(N))

def rref(rows,ncols):
    matrix=[[F(x) for x in row] for row in rows];pivots=[];r=0
    for c in range(ncols):
        p=next((i for i in range(r,len(matrix)) if matrix[i][c]),None)
        if p is None:continue
        matrix[r],matrix[p]=matrix[p],matrix[r]
        factor=matrix[r][c];matrix[r]=[x/factor for x in matrix[r]]
        for i in range(len(matrix)):
            if i!=r and matrix[i][c]:
                factor=matrix[i][c]
                matrix[i]=[a-factor*b for a,b in zip(matrix[i],matrix[r])]
        pivots.append(c);r+=1
        if r==len(matrix):break
    return matrix[:r],pivots

def nullspace(rows,ncols=6):
    matrix,pivots=rref(rows,ncols);basis=[]
    for free in range(ncols):
        if free in pivots:continue
        v=[F(0)]*ncols;v[free]=F(1)
        for row,pivot in zip(matrix,pivots):v[pivot]=-row[free]
        basis.append(tuple(v))
    return basis

def components(graph):
    unused=set(range(N));out=[]
    while unused:
        todo=[min(unused)];seen=set()
        while todo:
            v=todo.pop()
            if v in seen:continue
            seen.add(v)
            for i,j in graph:
                if i==v and j not in seen:todo.append(j)
                if j==v and i not in seen:todo.append(i)
        unused-=seen
        edges=sum(i in seen and j in seen for i,j in graph)
        out.append(('C' if edges==len(seen) else 'P',len(seen)))
    return sorted(out,key=lambda x:(-x[1],x[0]))

def graph_key(graph,p):
    return tuple(sorted(tuple(sorted((p[i],p[j]))) for i,j in graph))

def graph_representatives():
    out=set()
    for mask in range(1<<len(EDGES)):
        graph=tuple(e for k,e in enumerate(EDGES) if mask&(1<<k))
        if any(sum(v in e for e in graph)>2 for v in range(N)):continue
        if any(kind=='C' and size%2==0 for kind,size in components(graph)):continue
        out.add(min(graph_key(graph,p) for p in PERMS))
    return sorted(out,key=lambda g:(len(g),g))

def decoration_key(graph,orders,p):
    result=[]
    for (i,j),theta in zip(graph,orders):
        edge=tuple(sorted((p[i],p[j])))
        transformed={p[k]:m for k,m in zip([k for k in range(N) if k not in (i,j)],theta)}
        result.append(edge+tuple(transformed[k] for k in range(N) if k not in edge))
    return tuple(sorted(result))

def nonzero_generic_pfaffian(basis):
    for a in range(len(basis)):
        for b in range(a,len(basis)):
            value=0
            for i,j,sign in [(0,5,1),(1,4,-1),(2,3,1)]:
                value+=sign*basis[a][i]*basis[b][j]
                if a!=b:value+=sign*basis[b][i]*basis[a][j]
            if value:return True
    return False

def proportional_ratio(numerator,denominator):
    index=next((i for i,x in enumerate(denominator) if x),None)
    if index is None:return None
    ratio=numerator[index]/denominator[index]
    return ratio if numerator==scale(ratio,denominator) else None

def nonnegative_integer(x):return x is not None and x.denominator==1 and x>=0

def integer_example(basis,graph):
    dim=len(basis)
    for height in range(1,15):
        candidates=[tuple(height**j for j in range(dim))]
        if height==14:candidates=itertools.product(range(1,5),repeat=dim)
        for parameters in candidates:
            values=tuple(sum(c*v[k] for c,v in zip(parameters,basis)) for k in range(6))
            if values[0]*values[5]-values[1]*values[4]+values[2]*values[3]==0:continue
            matrix=[[dot(B[i][j],values) for j in range(N)] for i in range(N)]
            found=[]
            for i,j in EDGES:
                if matrix[i][j] and all(nonnegative_integer((matrix[j][k]+matrix[k][i])/matrix[i][j])
                                      for k in range(N) if k not in (i,j)):
                    found.append((i,j))
            if tuple(found)!=tuple(graph):continue
            denominator=math.lcm(*(x.denominator for row in matrix for x in row))
            integral=[[int(x*denominator) for x in row] for row in matrix]
            divisor=math.gcd(*(x for row in integral for x in row))
            return [[x//divisor for x in row] for row in integral]
    raise RuntimeError('No generic integer point located')

def enumerate_diagrams():
    possible_orders=sorted(set(itertools.permutations((2,0,0))) |
                           set(itertools.permutations((1,1,0))))
    output=[]
    for graph in graph_representatives():
        automorphisms=[p for p in PERMS if graph_key(graph,p)==graph]
        accepted=0
        for orders in itertools.product(possible_orders,repeat=len(graph)):
            key=decoration_key(graph,orders,tuple(range(N)))
            if key!=min(decoration_key(graph,orders,p) for p in automorphisms):continue
            rows=[]
            for (i,j),theta in zip(graph,orders):
                for k,m in zip([k for k in range(N) if k not in (i,j)],theta):
                    rows.append(add(add(B[j][k],B[k][i]),scale(-m,B[i][j])))
            basis=nullspace(rows)
            if not basis or not nonzero_generic_pfaffian(basis):continue
            restricted=[[tuple(dot(B[i][j],v) for v in basis) for j in range(N)] for i in range(N)]
            if any(not any(restricted[i][j]) for i,j in graph):continue
            exact_graph=[];exact_orders={}
            for i,j in EDGES:
                denominator=restricted[i][j]
                if not any(denominator):continue
                ratios=[proportional_ratio(add(restricted[j][k],restricted[k][i]),denominator)
                        for k in range(N) if k not in (i,j)]
                if all(nonnegative_integer(r) for r in ratios):
                    exact_graph.append((i,j));exact_orders[(i,j)]=[int(r) for r in ratios]
            if tuple(exact_graph)!=tuple(graph):continue
            weights=[]
            for i,j in graph:
                theta=exact_orders[(i,j)];weight=[-1 if k in (i,j) else 0 for k in range(N)]
                for k,m in zip([k for k in range(N) if k not in (i,j)],theta):weight[k]=m
                weights.append(weight)
            weight_rank=len(rref(weights,N)[1])
            record={
                'graph_type':'+'.join(kind+str(size) for kind,size in components(graph)),
                'generic_degeneracy_degree_partition':[size for kind,size in components(graph)],
                'edges':[{'edge':[i,j], 'orders':{str(k):m for k,m in
                    zip([k for k in range(N) if k not in (i,j)],exact_orders[(i,j)])}}
                    for i,j in graph],
                'period_dimension':len(basis),'edge_count':len(graph),
                'smoothing_weight_rank':weight_rank,
                'generic_torus_stabilizer_dimension':4-weight_rank,
                'period_basis_coordinates':['b'+str(i)+str(j) for i,j in VARS],
                'period_basis':[[str(x) for x in v] for v in basis],
                'forced_zero_entries':[[i,j] for i,j in EDGES if not any(restricted[i][j])],
                'biresidue_example':integer_example(basis,graph),
                'affine_component_dimension':20+len(basis)+len(graph),
                'projective_component_dimension':19+len(basis)+len(graph),
                'coarse_affine_moduli_dimension':len(basis)+len(graph)-weight_rank,
            }
            if record['graph_type']=='C5':
                record['named_family']='q_5,1' if any(2 in values for values in exact_orders.values()) else 'q_5,2'
            output.append(record);accepted+=1
        print('graph','+'.join(k+str(n) for k,n in components(graph)),
              'diagrams',accepted,flush=True)
    for index,record in enumerate(output,1):record['id']='T'+str(index).zfill(2)
    return output

if __name__=='__main__':
    diagrams=enumerate_diagrams()
    assert len(diagrams)==40
    full_keys=[min(decoration_key(tuple(tuple(e['edge']) for e in d['edges']),
                  tuple(tuple(e['orders'][str(k)] for k in range(N) if k not in e['edge'])
                        for e in d['edges']),p) for p in PERMS) for d in diagrams]
    assert len(set(full_keys))==40
    for d in diagrams:
        b=d['biresidue_example']
        assert all(sum(row)==0 for row in b)
        assert all(b[i][j]==-b[j][i] for i in range(N) for j in range(N))
        assert len(rref(b,N)[1])==4
        for e in d['edges']:
            i,j=e['edge']
            assert b[i][j]!=0
            assert all(F(b[j][k]+b[k][i],b[i][j])==m for k,m in
                       ((int(k),m) for k,m in e['orders'].items()))
    result={'scope':'The 40 irreducible components meeting the toric log-symplectic locus; not a full classification of Pois(P4).',
            'references':['https://arxiv.org/abs/2010.08692',
                          'https://arxiv.org/abs/2310.05284',
                          'https://arxiv.org/abs/2411.10425'],
            'conventions':{'P_r':'a path with r vertices; P_1 is an isolated vertex',
                           'C_r':'a cycle with r vertices',
                           'period_coordinates':'b12,b13,b14,b23,b24,b34; the remaining entries are determined by skew symmetry and zero row sums',
                           'edge_order':'theta_ijk=(b_jk+b_ki)/b_ij',
                           'component_dimension':'The affine Poisson space includes scaling, the projective space divides by scaling; neither divides by PGL(5).',
                           'dimension_derivation':'At a toric point the PGL(5) orbit has dimension 20. A stratum of periods has dimension s and a smoothing graph with e edges has e smoothing parameters. Thus the affine component dimension is 20+s+e, projective dimension 19+s+e.'},
            'count':len(diagrams),
            'graph_type_histogram':dict(Counter(d['graph_type'] for d in diagrams)),
            'period_dimension_histogram':dict(sorted(Counter(d['period_dimension'] for d in diagrams).items())),
            'projective_component_dimension_histogram':dict(sorted(Counter(d['projective_component_dimension'] for d in diagrams).items())),
            'generic_degeneracy_degree_partition_histogram':dict(Counter('+'.join(str(x) for x in d['generic_degeneracy_degree_partition']) for d in diagrams)),
            'diagrams':diagrams}
    path=Path(__file__).with_name('p4_toric_smoothing_diagrams.json')
    path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='diagrams'},indent=2),flush=True)
    print('wrote',path,flush=True)

射影4空間の Poisson 構造：完全分類への還元 v2
2026年10月28日

最初に読むもの
==============
p4_poisson_completeness_v2.pdf が今回の日本語研究ノートです。
LuaLaTeX ソースと再現コード、方程式の全係数、検証証明書を同梱します。
baseline/ は前回の46成分の部分分類・検証資料をそのまま保持しています。
HANDOFF.txt は次回の研究に必要な確定事項と未解決事項をまとめます。

結論の範囲
==========
完全分類を達成したという主張ではありません。
全 Poisson 空間の既約成分の下界は、前回と同じ46です。
文献の40個の一般 rank 4 成分と、前回の6個の一般 rank 2 成分を区別します。
この数字は「rank 2 locus の成分数」や「PGL(5) の軌道数」ではありません。

今回の主な結果
==============
1. 全ての非零 projective Poisson 成分が [x0^2 d3 wedge d4] を含みます。
   その係数が非零の chart は A^8 × S78 と多項式的に同型です。
   S78 は78変数、182方程式で定義され、通常の次数は高々6です。
   この表示は形式的な局所近似ではなく、全成分を捉えます。

2. 一般 rank 4 の全成分は S61 の成分と一対一に対応します。
   S61 は重み1の16変数、重み2の45変数をもち、
   重み4の70方程式、重み5の64方程式で定義されます。
   154本から134本への削減には20個の厳密な Bianchi 恒等式を使います。
   対応する projective 成分の次元は slice の次元に9を加えた値です。

3. 一般 rank 4 で、bivector 自体が因子に沿って零になる構造は、
   すべて既知40成分の和に入ります。複素4次元 symplectic Lie 代数へ
   帰着し、全ての分岐を compatible toric pencil と閉包で処理します。
   退化因子 pi^2 が非被約な全ての場合を処理したわけではありません。

4. 因子的零点のない安定な rank 2 構造について、polynomial Poisson
   center が多項式環なら Rat(1,1,3) または Rat(1,2,2) です。
   滑らかな二次 Casimir は Rat(1,2,2) へ、projective 特異点が有限な
   三次 Casimir は Rat(1,1,3) へ帰着します。
   中心の有限生成性・多項式性そのものは未証明です。

5. S61 の一次パラメータを零とした45変数部分は、sp4 の r-matrix を
   用いて記述できます。ただし条件は rho3([r,r])=0 であり、通常の
   CYBE [r,r]=0 より弱い条件です。その差を示す例も検証しています。

次元・成分の規約
================
Pois(P4) は定数倍を含む affine Poisson scheme です。
P Pois(P4) は非零構造の定数倍を除いた projective scheme です。
いずれも PGL(5) による商ではありません。
成分の議論は C 上で行います。Q 係数の理想を出力していますが、
必要なのは C へ基底変換した後の幾何学的最小素イデアルです。

再現方法
========
Python 3 と NumPy が必要です。SymPy や外部CASは使いません。
このディレクトリをカレントディレクトリとして、順に実行します。
既存データを保つには、下記の data を別の出力ディレクトリに置換してください。
最初の2本が方程式を生成し、3本目以降がそれらを読みます。

  python3 code/build_universal_slice.py data
  python3 code/build_symplectic_slice.py data
  python3 code/reduce_symplectic_bianchi.py data
  python3 code/audit_reconstruction.py data
  python3 code/verify_quadratic_rmap.py data
  python3 code/verify_casimir_filters.py data
  python3 code/verify_boundary_points.py data
  python3 code/rank4_divisorial_zero_check.py > data/rank4_divisorial_zero_certificates.json

出力先引数を省略した場合は、同梱の data/ が使われます。
最後のスクリプトだけは JSON を標準出力に書きます。
baseline/ の検証は baseline/README.txt を参照してください。
LuaLaTeX、LuaTeX-ja、HaranoAji フォントを含む TeX Live 環境では、

  latexmk -lualatex p4_poisson_completeness_v2.tex

により PDF を生成できます。

データの読み方
==============
universal_slice_equations.json:
  parameter_count、parameter_weights、消去した39変数の復元式、
  182方程式および元の Jacobi 行番号を保存しています。
  対応する certificate は raw basis、gauge、線形消去の pivot 等を保存します。
  kappa は u17（JSON の0始まり index 16）です。

symplectic_slice_equations.json:
  61変数、消去した55変数の復元式、削減前の154方程式を保存します。
symplectic_slice_reduced_equations.json:
  最終の134方程式と、削減前の対応する generator index を保存します。
symplectic_bianchi_identities.json:
  取り除いた20方程式を復元する厳密な恒等式を保存します。

多項式の一般的な encoding は [monomial, numerator, denominator] の列です。
monomial は0始まりの変数 index の昇順リストで、同じ index の反復が冪です。
例えば [[0,0,2],3,2] は (3/2)u1^2 u3、[[],1,1] は定数1を表します。
各方程式・復元式の係数は Q 上で厳密です。

data/*.sing は Singular 形式の理想です。分解コマンドはコメント化してあり、
読み込みによって高負荷の最小素分解が自動的に始まることはありません。
Singular 自体による分解は今回実行していません。

検証済みの内容
==============
・方程式を消去してから復元する構成と、bivector を先に復元して Schouten
  bracket を計算する独立な手順を、全係数について Q 上で照合しています。
・Bianchi による20個の生成元復元恒等式を厳密に検証しています。
・Lie 型の全パラメータ族の Jacobi と compatibility は形式パラメータを
  残した整数係数恒等式です。数値的な標本だけを使った確認ではありません。
・中心の次数1・2・3部分は Q 上の核計算です。
・境界の接空間では、整数恒等式と有限体上の非零 minor による上下界を
  一致させ、標数0の次元を証明しています。
・同梱コードを別の出力ディレクトリで再実行し、方程式・データの一致を
  確認しています。data/reproducibility_check.json を参照してください。

未解決事項
==========
I61 と I78 の最小素分解、全成分数46の完全性、安定 rank 2 中心の
有限生成性・多項式性、全点の PGL 同型類、成分交叉の完全記述は未解決です。
134本・182本が最小生成本数であるとは主張しません。
二次 obstruction の線形包を、tangent cone の理想全体とは同一視しません。

主要文献
========
https://arxiv.org/abs/2010.08692
https://arxiv.org/html/2207.12880v5
https://arxiv.org/abs/1112.3871
https://www.math.mcgill.ca/bpym/files/bpym-thesis.pdf
https://arxiv.org/abs/math/0407501

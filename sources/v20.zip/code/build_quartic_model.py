"""Generate the complete fixed-curve Jacobi models over QQ.

This is a necessary coefficient scheme, not an existence result.  No
parameter localization or quotient is performed. Only nonzero rational
constants are used to normalize duplicated equations.
"""
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
import sympy as sp


def build(kind: str, output_directory: Path) -> dict:
    x = sp.symbols("x0:5")
    t = sp.Symbol("t")
    pairs = list(itertools.combinations(range(5), 2))
    monomials = [x[i] * x[j] for i in range(5) for j in range(i, 5)]
    coefficients = sp.symbols("c0:150")
    matrix = sp.zeros(5)
    for k, (i, j) in enumerate(pairs):
        matrix[i, j] = sum(coefficients[15*k+l]*m
                           for l, m in enumerate(monomials))
        matrix[j, i] = -matrix[i, j]
    a, b = sp.symbols("a b")
    if kind == "nodal":
        normalization = [1+t**4, t, t**2, t**3, 0]
        residue = a*t
        residue_parameters = [a]
    elif kind == "cuspidal":
        normalization = [1, t**2, t**3, t**4, 0]
        residue = a*t+b*t**2
        residue_parameters = [a, b]
    else:
        raise ValueError(kind)
    restriction = dict(zip(x, normalization))
    linear_equations = []
    for i, j in pairs:
        equation = sp.expand(
            matrix[i, j].subs(restriction, simultaneous=True)
            + residue * (normalization[i]*sp.diff(normalization[j], t)
                         - normalization[j]*sp.diff(normalization[i], t))/5
        )
        linear_equations.extend(sp.Poly(equation, t).coeffs())
    for j in range(5):
        divergence = sum(sp.diff(matrix[i, j], x[i]) for i in range(5))
        linear_equations.extend(sp.Poly(divergence, *x).coeffs())
    variables = list(coefficients)+residue_parameters
    constraint_matrix, _ = sp.linear_eq_to_matrix(linear_equations, variables)
    reduced, pivots = constraint_matrix.rref()
    free = [i for i in range(len(variables)) if i not in pivots]
    parameters = sp.symbols("z0:"+str(len(free)))
    solution = {variables[j]: parameters[k] for k, j in enumerate(free)}
    for row, j in enumerate(pivots):
        solution[variables[j]] = -sum(
            reduced[row, k]*solution[variables[k]] for k in free
        )
    # Exact completeness of this linear parametrization follows from RREF.
    checks = {
        "all_linear_constraints_satisfied": all(
            sp.expand(e.subs(solution)) == 0 for e in linear_equations),
        "linear_rank_104": len(pivots) == 104,
        "expected_dimension": len(free) == (47 if kind == "nodal" else 48),
        "residue_parameters_retained": all(v in [variables[i] for i in free]
                                           for v in residue_parameters),
    }
    matrix = matrix.subs(solution).applyfunc(sp.expand)
    pfaffians = []
    for i in range(5):
        j, k, l, m = [v for v in range(5) if v != i]
        pfaffians.append(sp.expand((-1)**i * (
            matrix[j,k]*matrix[l,m]-matrix[j,l]*matrix[k,m]
            + matrix[j,m]*matrix[k,l])))
    F = sp.expand(sum(x[i]*pfaffians[i] for i in range(5))/5)
    equations = []
    nonzero_count = 0
    seen = set()
    for i, j, k in itertools.combinations(range(5), 3):
        polynomial = sp.expand(sum(
            matrix[i,l]*sp.diff(matrix[j,k], x[l])
            + matrix[j,l]*sp.diff(matrix[k,i], x[l])
            + matrix[k,l]*sp.diff(matrix[i,j], x[l])
            for l in range(5)))
        for coefficient in sp.Poly(polynomial, *x).coeffs():
            if coefficient == 0:
                continue
            nonzero_count += 1
            normalized = sp.Poly(
                coefficient, *parameters, domain=sp.QQ
            ).monic().as_expr()
            if normalized not in seen:
                seen.add(normalized)
                equations.append(normalized)
    checks["nonzero_coefficient_count"] = nonzero_count == (
        292 if kind == "nodal" else 267)
    checks["distinct_equation_count"] = len(equations) == (
        204 if kind == "nodal" else 193)
    report = {
        "kind": kind,
        "field": "QQ",
        "sympy_version": sp.__version__,
        "unknowns_before_linear_reduction": len(variables),
        "linear_rank": len(pivots),
        "dimension": len(free),
        "all_jacobi_cubic_slots": 350,
        "nonzero_jacobi_coefficients": nonzero_count,
        "distinct_monic_jacobi_equations": len(equations),
        "checks": checks,
        "all_passed": all(checks.values()),
        "scope": ("Necessary full Jacobi coefficient scheme for fixed curve. "
                  "No normality, existence, components, or moduli dimension inferred."),
    }
    assert report["all_passed"]
    model = {
        "schema_version": 1,
        "report": report,
        "coordinates": [str(v) for v in x],
        "normalization_parameter": str(t),
        "parameters": [str(v) for v in parameters],
        "free_original": [str(variables[i]) for i in free],
        "normalization": [str(v) for v in normalization],
        "residue": str(residue.subs(solution)),
        "residue_parameters": {str(v): str(solution[v]) for v in residue_parameters},
        "matrix_upper": {f"{i},{j}": str(matrix[i,j]) for i,j in pairs},
        "pfaffians": [str(v) for v in pfaffians],
        "F": str(F),
        "jacobi_equations": [str(v) for v in equations],
    }
    output_directory.mkdir(parents=True, exist_ok=True)
    (output_directory/f"{kind}_model.json").write_text(
        json.dumps(model, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    (output_directory/f"{kind}_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("kind", choices=["nodal", "cuspidal"])
    parser.add_argument("--output-directory", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(build(args.kind, args.output_directory), indent=2))

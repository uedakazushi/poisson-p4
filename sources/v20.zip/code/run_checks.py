"""Run mathematical verification groups in disposable copies.

Generated reports go only to the explicitly selected output directory.
The archived source tree, including all previous editions, is read-only.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-directory", type=Path, required=True)
    parser.add_argument("--regenerate-models", action="store_true")
    args = parser.parse_args()
    bundle = Path(__file__).resolve().parents[1]
    output = args.output_directory.resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output/"logs").mkdir(exist_ok=True)
    reports = []
    with tempfile.TemporaryDirectory(prefix="p4_v20_checks_") as temp:
        work = Path(temp)
        shutil.copytree(bundle/"proofs", work/"proofs")
        shutil.copytree(bundle/"data/quartic_models", work/"models")
        jobs = [
            ("singular_secant", [sys.executable,
             str(work/"proofs/geometry/verify_singular_secant.py"),
             "--output", str(work/"singular_secant.json")]),
            ("star_support", [sys.executable,
             str(work/"proofs/geometry/verify_star_support.py"),
             "--output", str(work/"star_support.json")]),
            ("quartic_curves", [sys.executable,
             str(work/"proofs/models/verify_quartic_models.py")]),
            ("independent_linear_reduction", [sys.executable,
             str(work/"proofs/models/space_quartic_linear_reduction.py")]),
            ("full_jacobi_audit", [sys.executable,
             str(work/"proofs/models/audit_quartic_model.py"), str(work/"models")]),
        ]
        if args.regenerate_models:
            for kind in ["nodal", "cuspidal"]:
                jobs.append(("regenerate_"+kind, [sys.executable,
                    str(bundle/"code/build_quartic_model.py"), kind,
                    "--output-directory", str(work/"regenerated")]))
        for name, command in jobs:
            started = time.monotonic()
            result = subprocess.run(command, cwd=work, text=True,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, check=False)
            (output/"logs"/(name+".txt")).write_text(result.stdout, encoding="utf-8")
            report = {"name": name, "exit_code": result.returncode,
                      "seconds": round(time.monotonic()-started, 3),
                      "passed": result.returncode == 0}
            reports.append(report)
            print(json.dumps(report), flush=True)
            if result.returncode != 0:
                raise RuntimeError(f"Mathematical check failed: {name}")
        if args.regenerate_models:
            for kind in ["nodal", "cuspidal"]:
                old = json.loads((work/"models"/f"{kind}_model.json").read_text())
                new = json.loads((work/"regenerated"/f"{kind}_model.json").read_text())
                # Version metadata may differ; all actual algebra must coincide.
                old["report"].pop("sympy_version", None)
                new["report"].pop("sympy_version", None)
                if old != new:
                    raise AssertionError(f"Regenerated model differs: {kind}")
        generated = {
            "singular_secant.json": work/"singular_secant.json",
            "star_support.json": work/"star_support.json",
            "independent_linear_reduction.json":
                work/"proofs/models/space_quartic_linear_reduction.json",
            "full_jacobi_audit.json":
                work/"proofs/models/root_quartic_audit.json",
        }
        for name, path in generated.items():
            shutil.copy2(path, output/name)
    summary = {"groups": reports, "all_passed": all(r["passed"] for r in reports),
               "regenerated_models": args.regenerate_models,
               "scope": "Exact mathematical checks; no claim of solving remaining Jacobi schemes."}
    (output/"summary.json").write_text(json.dumps(summary, indent=2)+"\n")
    print(json.dumps({"all_passed": summary["all_passed"],
                      "groups": len(reports)}, indent=2))


if __name__ == "__main__":
    main()

"""Read-only SHA-256 verification of the full bundle and preserved v19."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[1]
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

verified = 0
for line in (root/"SHA256SUMS.txt").read_text().splitlines():
    expected, relative = line.split("  ", 1)
    actual = digest(root/relative)
    assert actual == expected, f"Bundle mismatch: {relative}"
    verified += 1
old = json.loads((root/"data/previous_v19_preservation.json").read_text())
for relative, expected in old["files"].items():
    assert digest(root/"previous_v19"/relative) == expected, relative
assert digest(root/"previous_v19.pdf") == (
    "d19ed8d70af1c3239ccb81aed96286ca26795faa86b80c50f7cdb3479dc1e214")
assert old["file_count"] == 1513
print(json.dumps({"all_passed": True, "all_files_verified": verified,
                  "historical_files_verified": old["file_count"],
                  "historical_pdf_verified": True}, indent=2))

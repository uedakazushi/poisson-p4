#!/usr/bin/env python3
"""Exact preliminary linear reduction for singular integral space quartics.
Not a Jacobi solution or existence proof. SymPy 1.14.0.
"""
from pathlib import Path
import json
import sympy as s
x=s.symbols('x0:5'); a,b=s.symbols('s t'); pairs=[(i,j) for i in range(5) for j in range(i+1,5)]
mons=[x[i]*x[j] for i in range(5) for j in range(i,5)]

def coeffvec(poly,vars,mons):
    p=s.Poly(s.expand(poly),*vars)
    return s.Matrix([p.coeff_monomial(m) for m in mons])

def one(kind):
    if kind=='node':
        nu=[a**4+b**4,a**3*b,a**2*b**2,a*b**3,s.S(0)]
        q=[x[1]*x[3]-x[2]**2,x[0]*x[2]-x[1]**2-x[3]**2]
        derivations=[(a,-b)]
    else:
        nu=[a**4,a**2*b**2,a*b**3,b**4,s.S(0)]
        q=[x[0]*x[3]-x[1]**2,x[1]*x[3]-x[2]**2]
        derivations=[(a,-b),(b,0)]
    sub=dict(zip(x,nu)); binarymons=[a**(8-k)*b**k for k in range(9)]
    evaluation=s.Matrix.hstack(*[coeffvec(m.subs(sub),(a,b),binarymons) for m in mons])
    assert evaluation.rank()==8
    assert all(s.expand(f.subs(sub))==0 for f in q)
    kernel=[x[4]*z for z in x]+q
    assert s.Matrix.hstack(*[coeffvec(f,x,mons) for f in kernel]).rank()==7
    lift=[]
    for ds,dt in derivations:
        nuder=[s.expand(ds*s.diff(y,a)+dt*s.diff(y,b)) for y in nu]
        rep={}
        for i,j in pairs:
            target=coeffvec(nu[i]*nuder[j]-nu[j]*nuder[i],(a,b),binarymons)
            sol,params=evaluation.gauss_jordan_solve(target)
            sol=sol.xreplace({p:s.S(0) for p in params})
            rep[i,j]=s.expand(sum(c*m for c,m in zip(sol,mons)))
            assert s.expand(rep[i,j].subs(sub)-(nu[i]*nuder[j]-nu[j]*nuder[i]))==0
        lift.append(rep)
    variables=list(s.symbols('c0:70'))+list(s.symbols('z0:'+str(len(lift))))
    P=s.zeros(5)
    for k,(i,j) in enumerate(pairs):
        P[i,j]=sum(variables[7*k+l]*f for l,f in enumerate(kernel))+sum(variables[70+l]*r[i,j] for l,r in enumerate(lift))
        P[j,i]=-P[i,j]
    div=[s.expand(sum(s.diff(P[i,j],x[i]) for i in range(5))) for j in range(5)]
    equations=[s.Poly(f,*x).coeff_monomial(z) for f in div for z in x]
    matrix=s.linear_eq_to_matrix(equations,variables)[0]
    rank=matrix.rank()
    independent_rows=matrix.T.rref()[1]
    independent_cols=matrix[list(independent_rows),:].rref()[1]
    minor=matrix.extract(list(independent_rows),list(independent_cols))
    determinant=minor.det()
    assert minor.rows==24 and determinant != 0
    null=matrix.nullspace()
    assert all(matrix*v==s.zeros(matrix.rows,1) for v in null)
    # Matrix ranks for fixed residue: the inhomogeneous system must be solvable.
    fixed=matrix[:,:70]
    for k in range(len(lift)):
        assert fixed.row_join(matrix[:,70+k]).rank()==fixed.rank()
    result={'curve':kind,'ideal':[str(z) for z in [x[4]]+q], 'normalization':[str(z) for z in nu],
      'quadratic_restriction_rank':evaluation.rank(),'ideal_quadrics_dimension':7,
      'residue_dimension':len(lift),'unconstrained_parameters':len(variables),
      'divergence_rank':rank,'divergence_minor_rows':list(independent_rows),'divergence_minor_columns':list(independent_cols),'divergence_minor_determinant':str(determinant),'canonical_linear_space_dimension':len(null),
      'fixed_residue_affine_dimension':70-fixed.rank(),
      'residue_lifts':[{str(ij):str(poly) for ij,poly in r.items()} for r in lift],
      'statement':'Necessary linear conditions only; Jacobi, Pfaffian rank, and normality remain.'}
    return result

out=[one(k) for k in ['node','cusp']]
print(json.dumps(out,indent=2))
Path(__file__).with_name('space_quartic_linear_reduction.json').write_text(json.dumps(out,indent=2)+'\n')

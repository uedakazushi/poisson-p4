"""Exact algebraic checks for the two singular integral space quartic models.

These calculations verify the displayed standard models, not the theoretical
exhaustion argument (Castelnuovo, normalization, and unmixedness).
"""
import json
import sympy as sp

s,t=sp.symbols('s t')
x=sp.symbols('x0:4')
node_Q=[x[1]*x[3]-x[2]**2,x[0]*x[2]-x[1]**2-x[3]**2]
cusp_Q=[x[0]*x[3]-x[1]**2,x[1]*x[3]-x[2]**2]
node_v=[s**4+t**4,s**3*t,s**2*t**2,s*t**3]
cusp_v=[s**4,s**2*t**2,s*t**3,t**4]
checks={}

for name,Q,v in [('node',node_Q,node_v),('cusp',cusp_Q,cusp_v)]:
    checks[name+'_parametrization'] = all(sp.expand(q.subs(dict(zip(x,v)), simultaneous=True))==0 for q in Q)
    coeffmat=sp.Matrix([[sp.expand(z).coeff(s,4-i).coeff(t,i) for z in v] for i in range(5)])
    checks[name+'_nondegenerate']=coeffmat.rank()==4
    monomials=[x[i]*x[j] for i in range(4) for j in range(i,4)]
    images=[sp.Poly(m.subs(dict(zip(x,v)),simultaneous=True),s,t) for m in monomials]
    matrix=sp.Matrix([[poly.coeff_monomial(s**(8-i)*t**i) for poly in images] for i in range(9)])
    checks[name+'_two_quadrics']=len(matrix.nullspace())==2
    for chart in range(4):
        free=[z for i,z in enumerate(x) if i!=chart]
        deh=[sp.expand(q.subs(x[chart],1)) for q in Q]
        J=sp.Matrix([[sp.diff(q,z) for z in free] for q in deh])
        minors=[sp.expand(J[:,[i,j]].det()) for i in range(3) for j in range(i+1,3)]
        G=sp.groebner(deh+minors,*free)
        if chart!=0:
            checks[name+'_smooth_chart_'+str(chart)]=list(G)==[1]
        else:
            checks[name+'_singular_support_origin']=all(any(sp.expand(g)==z**k for g in G) for z in free for k in [1]) if name=='node' else all(G.reduce(z**2)[1]==0 for z in free)
            checks[name+'_origin_singular']=all(g.subs(dict.fromkeys(free,0))==0 for g in G)
    if name=='cusp':
        checks['cusp_local_A2']=sp.expand(Q[1].subs({x[0]:1,x[3]:x[1]**2}))==x[1]**3-x[2]**2
    if name=='node':
        q=sp.expand(Q[0].subs({x[0]:1,x[2]:x[1]**2+x[3]**2}))
        initial=sp.Poly(q,x[1],x[3]).terms()
        initial=sp.Add(*[c*x[1]**a*x[3]**b for (a,b),c in initial if a+b==2])
        checks['node_distinct_tangents']=initial==x[1]*x[3]

checks['all_passed']=all(checks.values())
print(json.dumps(checks,ensure_ascii=False,indent=2))
assert checks['all_passed']

"""Exact illustration of the singular-directrix lemma; not a Poisson example."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import sympy as sp


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    x = sp.symbols("x0:5")
    x0, x1, x2, x3, x4 = x
    a, b, u, v, t = sp.symbols("a b u v t")
    F = (
        x0*x2**2*x4**2 - 2*x0*x2*x3**2*x4 + x0*x3**4
        - x1**3*x4**2 + 4*x1**2*x2*x3*x4 - x1**2*x3**3
        - 2*x1*x2**3*x4 - x1*x2**2*x3**2 + x2**4*x3
    )
    gamma = [1, t**2, t**3, t**4, t**5]
    secant = [a+b] + [a*u**j + b*v**j for j in range(2, 6)]
    join = [a, b, b*t, b*t**2, b*t**3]
    gradient = [sp.diff(F, xi) for xi in x]
    checks: dict[str, bool] = {}
    checks["homogeneous_quintic"] = {sum(m) for m in sp.Poly(F, x).monoms()} == {5}
    checks["secant_identity"] = sp.expand(F.subs(dict(zip(x, secant)), simultaneous=True)) == 0
    J = sp.Matrix(secant).jacobian([a, b, u, v])
    minor = J[:4, :].subs({a: 1, b: 1, u: 1, v: 2}).det()
    checks["secant_cone_dimension_four"] = minor == -12
    checks["join_in_hypersurface"] = sp.expand(F.subs(dict(zip(x, join)), simultaneous=True)) == 0
    for i, partial in enumerate(gradient):
        checks[f"gradient_{i}_vanishes_on_join"] = sp.expand(
            partial.subs(dict(zip(x, join)), simultaneous=True)
        ) == 0
    for i in range(5):
        for j in range(i, 5):
            checks[f"hessian_{i}_{j}_vanishes_on_curve"] = sp.expand(
                sp.diff(F, x[i], x[j]).subs(dict(zip(x, gamma)), simultaneous=True)
            ) == 0
    # F is primitive and linear in x0, hence irreducible: coefficient Q^2
    # and constant part B are coprime. Q is the irreducible quadric x2*x4-x3^2.
    Q = x2*x4-x3**2
    B = F.subs(x0, 0)
    checks["linear_coefficient_is_Q_squared"] = sp.diff(F, x0) == sp.expand(Q**2)
    checks["primitive_linear_polynomial"] = sp.gcd(Q**2, B) == 1
    checks["Q_irreducible"] = len(sp.factor_list(Q)[1]) == 1 and sp.factor_list(Q)[1][0][1] == 1
    # A homogeneous parametrization and its derivative show the singular
    # point is a cusp: affine coordinate algebra C[t^2,t^3,t^4,t^5].
    checks["normalization_derivative_vanishes_at_cusp"] = all(
        sp.diff(g, t).subs(t, 0) == 0 for g in gamma[1:]
    )
    # The Zariski tangent dimension is instead two in the projective chart:
    # ideal includes x3-x1^2, x4-x1*x2, x2^2-x1^3 in x0=1.
    local_equations = [x3-x1**2, x4-x1*x2, x2**2-x1**3]
    tangent_rank = sp.Matrix(local_equations).jacobian([x1,x2,x3,x4]).subs(
        {x1:0,x2:0,x3:0,x4:0}
    ).rank()
    checks["projective_Zariski_tangent_dimension_two"] = 4-tangent_rank == 2
    result = {
        "description": "cuspidal rational quintic secant hypersurface, exact symbolic illustration",
        "field": "QQ, hence valid over C",
        "sympy_version": sp.__version__,
        "polynomial": str(F),
        "checks": checks,
        "check_count": len(checks),
        "nonzero_secant_minor": int(minor),
        "all_passed": all(checks.values()),
        "scope": "Illustration of a geometric lemma, not a Poisson structure or a classification computation.",
    }
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    assert result["all_passed"]


if __name__ == "__main__":
    main()

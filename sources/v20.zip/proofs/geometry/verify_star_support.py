"""Exact monomial checks supporting the concurrent-line proof."""
from __future__ import annotations
import argparse
import itertools
import json
from pathlib import Path
import sympy as sp


def exponents(total, count):
    if count == 1:
        yield (total,)
        return
    for i in range(total+1):
        for tail in exponents(total-i, count-1):
            yield (i,)+tail


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output', type=Path)
    args=parser.parse_args()
    # Exponents are (s,y1,y2,y3,y4). Four coordinate-line cubes are monomial
    # ideals, so this enumeration determines their exact degree-five piece.
    allowed=[m for m in exponents(5,5)
             if all(sum(m[j] for j in range(1,5) if j!=i)>=3 for i in range(1,5))]
    s_dependent=[m for m in allowed if m[0]>0]
    checks={
      'four_line_cube_intersection_dimension_17':len(allowed)==17,
      'unique_s_dependent_monomial':s_dependent==[(1,1,1,1,1)],
      'all_other_monomials_are_quintic_in_directions':all(m[0]==0 for m in allowed if m not in s_dependent),
    }
    y=sp.symbols('y1:5')
    product=sp.prod(y)
    # The six mixed Hessian entries are the six complementary pair products.
    # Their common projective zero set is precisely the four coordinate points.
    hess=[sp.diff(product,y[i],y[j]) for i,j in itertools.combinations(range(4),2)]
    pairs=[y[i]*y[j] for i,j in itertools.combinations(range(4),2)]
    checks['second_derivatives_are_all_pair_products']=set(hess)==set(pairs)
    # Three noncollinear direction points in P^2 already kill every quartic
    # and lower form with triple vanishing at all three.
    for k in range(5):
        plane_allowed=[m for m in exponents(k,3)
                       if all(k-m[i]>=3 for i in range(3))]
        checks[f'plane_degree_{k}_three_coordinate_triples_vanish']=not plane_allowed
    plane5=[m for m in exponents(5,3) if all(5-m[i]>=3 for i in range(3))]
    checks['plane_quintic_three_triples_dimension_three']=len(plane5)==3
    checks['plane_quintic_three_triples_support']=set(plane5)=={(2,2,1),(2,1,2),(1,2,2)}
    result={
      'description':'exact monomial constraints for five concurrent triple lines',
      'checks':checks,
      'allowed_four_line_degree_five_monomials':allowed,
      'all_passed':all(checks.values()),
      'scope':'The fifth direction and plane collinearity arguments are proved geometrically; no generic-position numerical test substitutes for them.',
    }
    if args.output:
        args.output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
    assert result['all_passed']


if __name__=='__main__':
    main()

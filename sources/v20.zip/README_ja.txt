射影4空間の Poisson 構造 — 研究継続ノート 第20版
2026-10-29

主原稿
  p4_poisson_completeness_v20.pdf
  p4_poisson_completeness_v20.tex
  preamble.tex / sections/*.tex

今回の到達点
  正規な実際の退化五次因子には、不活性な既約曲線成分がない。
  従って標準二次持ち上げの共通零スキーム B は有限、length(B)≤16。
  その台だけを modular residue の零点集合と同一視する。
  一般横断型が全て Ẽ6 の分岐は、可約支持も含め q_(5,1) に限る。
  未決定の正規因子候補は全 Ẽ8 型・被約支持の次数4に帰着する。
  支持の必要型は節点四次、尖点四次、3+1、2+2、2+1+1、1+1+1+1。
  非 q_(5,1) では |B_red|≤r+1≤5。

未決定事項
  六つの必要支持型が Poisson 構造として実現するかは未決定。
  全 P4 の分類には非正規・非被約因子、階数2、全スキームの冪零構造が残る。
  既約成分数57は下界であり、完全な成分数ではない。

検証コード
  Python 3 と SymPy 1.14.0 を使用。
  python3 code/run_checks.py --output-directory /tmp/p4-v20-results
  保存済みモデルも150係数から再生成する場合：
  python3 code/run_checks.py --output-directory /tmp/p4-v20-full-results --regenerate-models
  実行は一時コピー内で行い、保存済み原稿・証明書・旧版を書き換えない。

個別の係数モデル生成
  python3 code/build_quartic_model.py nodal --output-directory /tmp/p4-v20-models
  python3 code/build_quartic_model.py cuspidal --output-directory /tmp/p4-v20-models
  節点：47変数、204本の数値的比例を除いた二次 Jacobi 係数。
  尖点：48変数、193本。
  いずれも元の全350係数と同じイデアルを生成する。
  47/48は必要な線形空間の次元で、Poisson族の次元ではない。
  JSONに全行列、Pfaffian、F、全方程式、パラメータの順序を収録。

原稿の組版
  LuaLaTeX、ltjsarticle、luatexja-preset (HaranoAji)、latexmk を使用。
  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v20.tex
  記入欄・フォームは設けていない。

検証資料
  data/reproduced/                今回実行した5群の結果と全ログ
  data/quartic_models/            節点・尖点の全 Jacobi モデルと生成報告
  proofs/geometry/               割線と五直線の厳密な照合
  proofs/models/                 曲線標準形、独立線形還元、全 Jacobi 監査
  proofs/audits/                 独立証明、監査結果、rootによる指摘の反映記録
  data/pdf_quality_check.json     描画・組版・フォームの確認

旧版の保存
  previous_v19/       第19版の全1513ファイルを byte 単位で変更せず保存。
  previous_v19.pdf    第19版のPDF。
  第1～18版は previous_v19/ の中に再帰的に含まれる。
  data/previous_v19_preservation.json に各旧版ファイルの SHA-256 を収録。

改変検出
  python3 code/verify_bundle.py
  SHA256SUMS.txt が本版の全ファイル（manifest自身を除く）をカバーする。

本文の証明が一般の場合を扱う。有限個の計算例を完全な幾何学的証明の
代わりに用いていない。既存文献の定理と、本研究ノートで導いた帰結を区別する。

射影4空間の Poisson 構造：研究継続ノート 第14版
2026年10月29日
============================================================

対象は複素数体上の全射影 Poisson スキームです。
PGL5 による商は取りません。次元は複素次元です。
この資料は継続研究の証明・計算記録であり、既刊の完全分類を報告するものではありません。

今回の主要結果
--------------
1. 安定な飽和接層を持ち、因子に沿って消えない階数2の構造は、
   実際の Jacobian 型 (1,1,3) または (1,2,2) です。
   polynomial center の生成性や Casimir 次数の上限は仮定しません。
   五切断、unmixed な零点曲面、Chern 数1/2/3、二平面の全 Ext、
   OGr(2,5) の Veronese 表示、原五切断の像の全階数分けで証明します。

2. 既知の非安定な葉層の分類と、因子的零点の全場合の閉包論を合わせ、
   被約な階数2以下の射影空間はちょうど8既約成分です。
   名前                       射影次元    全Poisson空間の成分か
   Rat(1,1,3)                    36       はい
   Rat(1,2,2)                    28       はい
   Log(1,1,1,2)                  28       はい
   LPB                           39       はい
   Aff(5)                        22       はい
   Aff(4,1)                      22       はい
   Log(1,1,1,1,1) のrank2部分     24       rank4成分の境界
   Aff(3,2)                      22       rank4成分の境界
   従って全Poisson空間の一般階数2の成分はちょうど6個です。
   全8成分間の交叉や冪零構造、PGL軌道の全分類までの主張ではありません。

3. 正規五次式 F について、退化因子として実現されるための必要十分条件は、
   Jacobian イデアル J(F) が高さ3、S/J(F) が Gorenstein、
   五つの偏微分が一次独立（最小生成元数5）となることです。
   K_F={quadratic alternating P: P grad F=0} にrank4の元があることとも同値です。
   存在すれば dim K_F=1、射影 Poisson 構造は一意に復元されます。
   最小分解は 0→S(-10)→S(-6)^5→S(-4)^5→S→S/J→0。
   Jacobian 曲線スキーム全体の次数40、算術種数101、双対化層O(5)です。
   被約台の数値と混同しないでください。

4. 1050×150行列 M(F):P↦P grad F について、全150minorが零、
   どれか149minorが可逆、核生成元のPfaffianが非零、かつFが正規、
   という determinantal subscheme は、この Poisson 領域の全スキームと同型です。
   冪零元を含む局所基底上でも証明しています。
   この determinantal scheme の既約成分分解はまだ未決定です。

全体の成分数の下界は57のままです。第14版で新たな成分は加算しません。
少なくとも51成分が一般階数4で、未発見の全成分があれば一般階数4です。

ファイル構成
------------
p4_poisson_completeness_v14.pdf      今回の日本語論文
p4_poisson_completeness_v14.tex      LuaLaTeX の主原稿
preamble.tex, sections/             全本文と証明
proofs/                            独立の証明監査記録
code/stable/                       二平面・spinor・全射影の厳密計算
code/normal/                       正規五次式の二実装による厳密計算
code/rank2_lower_bounds/            従来の6+2成分とAff32変形の検証コード
code/run_checks.py                  10項目の一括再現
code/verify_bundle.py               SHA256 と全旧版の byte 一致確認
data/reproduced/                    全10項目の標準出力と再現証明書
data/pdf_quality_check.json         PDF の組版・全ページ確認記録
data/previous_v13_preservation.json  旧版989ファイルの保存記録
previous_v13/                      第13版と、そこに入る第1--12版の全資料
HANDOFF.txt                        次回継続の正確な状態と注意点
SHA256SUMS.txt                      このファイル自身を除いた全ファイルのハッシュ

再現方法
--------
Python 3.12、SymPy 1.14.0、NumPy 2.3.5 で確認しました。
別の Python 3 環境で依存を用意する場合:
  python3 -m pip install -r requirements.txt
全10検証:
  python3 code/run_checks.py
別の出力先へ再現する場合:
  python3 code/run_checks.py --output /tmp/p4_v14_reproduced --jobs 4
内容保存の検証:
  python3 code/verify_bundle.py

論文は TeX Live、LuaLaTeX、luatexja、Harano Aji フォントを使います。
このディレクトリから:
  latexmk -lualatex -interaction=nonstopmode -halt-on-error -outdir=/tmp/p4_v14_build p4_poisson_completeness_v14.tex
書込み可能なフォームや記入欄は含めていません。

証明書の読み方
--------------
有限体の非零minorは標数零での階数の下界を保証します。
上界は有理数上の実際の核、族の微分、および恒等式で独立に与えます。
normal/independent_normal_certificate.py は標準ライブラリだけの別実装です。
幾何学的な尽くし上げは本文の証明によります。
数値標本から未知の成分の不存在を推測する方法ではありません。

過去版と現在版の関係
--------------------
previous_v13 以下は変更せず保存しました。
古い frontier 記述は当時の研究状態です。現在の未解決事項は本版の
「全体の成分数と残る分類問題」と HANDOFF.txt を優先してください。
特に安定な階数2に一次Casimirがない可能性は、本版で閉じています。
完全切断空間が五次元でも、原五切断の像が四次元の場合を落としてはいけません。
等方的rank4射影は排除されず、実際のRat(1,2,2)へ帰着します。

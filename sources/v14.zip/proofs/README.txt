V14 proof audit records
======================

The authoritative complete statements and proofs are the current sections/*.tex.
The audits are complementary, not competing global status summaries.

stable_exhaustion_audit.txt: stable no-divisor rank2 proof, including all section-map ranks.
c2_one_final_exhaustion_audit.txt: independent c2=1 audit PLUS nonstable/divisorial total rank2 coverage.
linear_factor_closedness_lemma.txt: independent proof of the relative linear-oneform step.
normal_quintic_full_scheme_audit.txt: full determinantal-scheme equivalence, including nilpotent bases.

Script paths mentioned in the development audits are archived here under code/stable/
and code/normal/. The separate nonstable audit requested at the end of the first
audit has been completed in the second audit and in sections/rank2_global_eight.tex.
Exploratory isotropic_sample.py is not used in any theorem and is not part of the
current verification suite. The universal eight-parameter computation supersedes it.

#!/usr/bin/env python3
"""Reproduce v14 exact certificates without changing any archived source.

Run from any directory: python3 code/run_checks.py
Optional: --output /absolute/path --jobs 4
Requires the versions in requirements.txt. The history is byte-checked separately.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


PACKAGE = Path(__file__).resolve().parents[1]
CASES = [
    ("two_plane_extension", "stable/verify_c2_one_model.py", [],
     "stable/verify_c2_one_model.json", "code/stable/verify_c2_one_model.json"),
    ("spinor_geometry", "stable/construct_spinor.py", [],
     "stable/spinor_certificate.json", "code/stable/spinor_certificate.json"),
    ("all_rank_four_projections", "stable/rank4_projection.py", [],
     "stable/rank4_projection_certificate.json", "code/stable/rank4_projection_certificate.json"),
    ("independent_projection_check", "stable/verify_spinor_projection_independent.py", [],
     "stable/verify_spinor_projection_independent.json", "code/stable/verify_spinor_projection_independent.json"),
    ("independent_extension_and_projection_audit", "stable/audit_c2_one.py", [],
     "stable/audit_c2_one.json", "code/stable/audit_c2_one.json"),
    ("normal_quintic_symbolic", "normal/verify_normal_quintic.py", [],
     "normal/verify_normal_quintic.json", "code/normal/verify_normal_quintic.json"),
    ("normal_quintic_independent_integer", "normal/independent_normal_certificate.py", [],
     "normal/independent_normal_certificate.json", "code/normal/independent_normal_certificate.json"),
    ("six_full_rank_two_components", "rank2_lower_bounds/verify_rank2_components.py", [],
     None, "data/six_rank2_components.json"),
    ("two_boundary_rank_two_components", "rank2_lower_bounds/verify_boundary_points.py", ["boundary_output"],
     "boundary_output/boundary_points_certificate.json", "data/rank2_boundary_certificate.json"),
    ("aff32_universal_rank_four_deformation", "rank2_lower_bounds/verify_aff32_deformation.py", [],
     None, "data/aff32_deformation_certificate.json"),
]


def execute_case(case, output):
    name, script, args, generated_path, expected_path = case
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix=f"p4_v14_{name}_") as tmp:
        work = Path(tmp)
        shutil.copytree(PACKAGE / "code", work, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        result = subprocess.run([sys.executable, str(work / script), *args], cwd=work,
                                env=env, capture_output=True, text=True)
        (output / f"{name}.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        record = {"name": name, "script": script, "exit_code": result.returncode,
                  "seconds": round(time.monotonic() - started, 3)}
        try:
            if result.returncode:
                raise RuntimeError(f"exit code {result.returncode}")
            raw = (work / generated_path).read_text() if generated_path else result.stdout
            actual, expected = json.loads(raw), json.loads((PACKAGE / expected_path).read_text())
            if actual != expected:
                raise AssertionError("certificate differs from the archived exact result")
            destination = output / "outputs" / f"{name}.json"
            destination.write_text(json.dumps(actual, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            record.update(passed=True, exact_json_equal=True,
                          source_sha256=hashlib.sha256((PACKAGE / "code" / script).read_bytes()).hexdigest())
        except Exception as exc:
            record.update(passed=False, error=str(exc))
        return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=PACKAGE / "data/reproduced")
    parser.add_argument("--jobs", type=int, default=4)
    args = parser.parse_args()
    output = args.output.resolve()
    (output / "outputs").mkdir(parents=True, exist_ok=True)
    results = []
    with ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        futures = [pool.submit(execute_case, case, output) for case in CASES]
        for future in as_completed(futures):
            record = future.result()
            results.append(record)
            print(f"{record['name']}: {'PASS' if record['passed'] else 'FAIL'}", flush=True)
    order = {case[0]: i for i, case in enumerate(CASES)}
    results.sort(key=lambda record: order[record['name']])
    summary = {"all_passed": all(r["passed"] for r in results), "number_of_checks": len(results),
               "python_version": sys.version.split()[0], "checks": results,
               "scope": "Exact polynomial identities and witness ranks; theoretical exhaustiveness is proved in the manuscript."}
    (output / "verification_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"all_passed": summary["all_passed"], "number_of_checks": len(results)}), flush=True)
    if not summary["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

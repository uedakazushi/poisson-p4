#!/usr/bin/env python3
"""Exact rank-four deformation of the rank-two Aff(3,2) family on P^4.

Python 3 and NumPy are sufficient; symbolic polynomial arithmetic uses integers
and fractions, with no SymPy dependency. Run:
    python3 verify_aff32_deformation.py > ../data/aff32_certificate.json

The polynomial ring is Z[x0,x1,x2,x3,x4,b,t]. Schouten derivatives are taken
only in x0,...,x4, so b and t are genuine symbolic parameters, not sample values.
Write d_ij for partial_i wedge partial_j and set
 N = x0 partial_1 + x1 partial_2 + x3 partial_4,
 H_b = x1 partial_1 + 2x2 partial_2 + b x3 partial_3 +(b+1)x4 partial_4.
The family is P(b,t)=N wedge H_b + t eta_b + t^2 theta_b, where the nonzero
coefficients are
 eta01=-(2b^2+b-1)x0x1,
 eta02=-(b^2+b-1)x0x2-bx1^2,
 eta03=-(2b-1)x0x3,
 eta04=-(b-1)x1x3,
 eta12=(b^2-4b+2)x1x2,
 eta24=(b-2)x2x4,
 theta01=b(b-1)(b+1)x1^2,
 theta02=b(b-1)^2x1x2,
 theta03=b(b-1)x1x3.

The script proves E wedge [P(b,t),P(b,t)]=0 identically and proves that the
coefficient of E wedge P(b,t) wedge P(b,t) is
 2(b-1)t*x3*[2(x0-(b-1)t*x1)x2-x1^2]*[x1*x3-(x0-b*t*x1)*x4].
For generic b and t nonzero this divisor is reduced, with degrees (1,2,2);
the two quadrics have ranks three and four. The structure is log symplectic.
At (b,t)=(7,0), the PGL action, scale, b, and t derivatives have rank 24 after
the Euler quotient, matching the full affine Poisson tangent dimension 24.
This is an actual two-parameter family, so the dimension argument does not
mistake the union of separate deformation curves for a smooth parameter family.

At (b,t)=(7,1), use
 z0=x3+x4, z1=7x1-x0, z2=x0-8x1+2x2, z3=x0-6x1, z4=x3.
After taking the unique divergence-free lift, the result is
 sum lambda_ij*z_i*z_j*d_ij + z3*z4*d_01 + 2z1*z4*d_02 + 2z1^2*d_23,
where 5*lambda (upper triangle order 01,02,03,04,12,13,14,23,24,34) equals
 (-6,17,-29,18,-17,17,-6,24,-24,12).
Weights (0,1,-2,0,2) give the extra terms positive weights 1,5,4. The limit is
nondegenerate toric: E wedge P_limit^2=24*z0*z1*z2*z3*z4. Thus this rank-four
component belongs to the toric-degeneration classification of Matviichuk,
Pym and Schedler, https://arxiv.org/pdf/2010.08692 . Its smoothing edges are
01 and 23, with exponents (0,1,1) and (0,2,0), respectively. The middle term
of weight 5 is the forced mixed correction.

The report also gives the affine logarithmic Poisson matrix in coordinates
log(z_i/z4), its exact inverse, and the corresponding five-coordinate residue
matrix. The term 'inverse' fixes the sign convention for this matrix.
"""

from collections import defaultdict, Counter
from fractions import Fraction
import itertools
import json

import numpy as np

import poisson_p4_components_check as p
from verify_rank2_components import (
    wedge_fields, linear_action_derivative, assert_integer_product_zero,
)


def add_polynomials(*polynomials):
    result = defaultdict(int)
    for polynomial in polynomials:
        p.add_polynomial(result, polynomial)
    return dict(result)


def scale_polynomial(polynomial, scalar):
    return {monomial: scalar * coefficient
            for monomial, coefficient in polynomial.items()}


def monomial(x_exponents, b_power=0, t_power=0, coefficient=1):
    return {tuple(x_exponents) + (b_power, t_power): coefficient}


def coordinate(index):
    return monomial([int(index == k) for k in range(5)])


def parameter_shift(polynomial, b_power=0, t_power=0):
    result = {}
    for powers, coefficient in polynomial.items():
        shifted = list(powers)
        shifted[5] += b_power
        shifted[6] += t_power
        result[tuple(shifted)] = coefficient
    return result


def coefficient_polynomial(x_exponents, b_coefficients):
    return add_polynomials(*[
        monomial(x_exponents, b_power, 0, coefficient)
        for b_power, coefficient in enumerate(b_coefficients) if coefficient
    ])


def add_bivectors(first, second):
    return {pair: add_polynomials(first.get(pair, {}), second.get(pair, {}))
            for pair in p.PAIRS}


def euler_wedge_trivector(trivector):
    result = defaultdict(int)
    for indices, polynomial in trivector.items():
        for direction in range(5):
            sign = p.permutation_sign((direction,) + indices)
            if not sign:
                continue
            for powers, coefficient in polynomial.items():
                multiplied = list(powers)
                multiplied[direction] += 1
                result[(tuple(sorted((direction,) + indices)), tuple(multiplied))] += (
                    sign * coefficient)
    return {term: coefficient for term, coefficient in result.items() if coefficient}


def pfaffian_section(bivector):
    """Coefficient of E wedge P wedge P in the standard five-vector."""
    result = defaultdict(int)
    for first_pair, first in bivector.items():
        for second_pair, second in bivector.items():
            for direction in range(5):
                sign = p.permutation_sign((direction,) + first_pair + second_pair)
                if not sign:
                    continue
                for powers, coefficient in p.polynomial_product(first, second).items():
                    multiplied = list(powers)
                    multiplied[direction] += 1
                    result[tuple(multiplied)] += sign * coefficient
    return {powers: coefficient for powers, coefficient in result.items() if coefficient}


def symbolic_family():
    nilpotent = [{}, coordinate(0), coordinate(1), {}, coordinate(3)]
    grading = [{}, coordinate(1), scale_polynomial(coordinate(2), 2),
               parameter_shift(coordinate(3), b_power=1),
               add_polynomials(parameter_shift(coordinate(4), b_power=1), coordinate(4))]
    initial = wedge_fields(nilpotent, grading)
    eta = {
        (0, 1): coefficient_polynomial((1, 1, 0, 0, 0), (1, -1, -2)),
        (0, 2): add_polynomials(
            coefficient_polynomial((1, 0, 1, 0, 0), (1, -1, -1)),
            coefficient_polynomial((0, 2, 0, 0, 0), (0, -1))),
        (0, 3): coefficient_polynomial((1, 0, 0, 1, 0), (1, -2)),
        (0, 4): coefficient_polynomial((0, 1, 0, 1, 0), (1, -1)),
        (1, 2): coefficient_polynomial((0, 1, 1, 0, 0), (2, -4, 1)),
        (2, 4): coefficient_polynomial((0, 0, 1, 0, 1), (-2, 1)),
    }
    theta = {
        (0, 1): coefficient_polynomial((0, 2, 0, 0, 0), (0, -1, 0, 1)),
        (0, 2): coefficient_polynomial((0, 1, 1, 0, 0), (0, 1, -2, 1)),
        (0, 3): coefficient_polynomial((0, 1, 0, 1, 0), (0, -1, 1)),
    }
    family = add_bivectors(
        add_bivectors(initial, {pair: parameter_shift(polynomial, t_power=1)
                               for pair, polynomial in eta.items()}),
        {pair: parameter_shift(polynomial, t_power=2)
         for pair, polynomial in theta.items()},
    )
    return family


def specialize(polynomial, b_value, t_value):
    result = defaultdict(int)
    for powers, coefficient in polynomial.items():
        result[powers[:5]] += coefficient * b_value ** powers[5] * t_value ** powers[6]
    return {powers: coefficient for powers, coefficient in result.items() if coefficient}


def verify_symbolic_pfaffian(family):
    first_quadric = add_polynomials(
        monomial((1, 0, 1, 0, 0), coefficient=2),
        monomial((0, 2, 0, 0, 0), coefficient=-1),
        monomial((0, 1, 1, 0, 0), 1, 1, -2),
        monomial((0, 1, 1, 0, 0), 0, 1, 2),
    )
    second_quadric = add_polynomials(
        monomial((0, 1, 0, 1, 0)),
        monomial((1, 0, 0, 0, 1), coefficient=-1),
        monomial((0, 1, 0, 0, 1), 1, 1),
    )
    factor = add_polynomials(
        monomial((0, 0, 0, 1, 0), 1, 1, 2),
        monomial((0, 0, 0, 1, 0), 0, 1, -2),
    )
    expected = p.polynomial_product(
        factor, p.polynomial_product(first_quadric, second_quadric))
    assert pfaffian_section(family) == expected


def verify_smooth_point(family):
    point = {pair: specialize(polynomial, 7, 0)
             for pair, polynomial in family.items()}
    b_derivative = {pair: specialize(p.polynomial_derivative(polynomial, 5), 7, 0)
                    for pair, polynomial in family.items()}
    t_derivative = {pair: specialize(p.polynomial_derivative(polynomial, 6), 7, 0)
                    for pair, polynomial in family.items()}
    columns = [p.bivector_vector(point), p.bivector_vector(b_derivative),
               p.bivector_vector(t_derivative)]
    for i, j in itertools.product(range(5), repeat=2):
        matrix = np.zeros((5, 5), dtype=np.int64)
        matrix[i, j] = 1
        columns.append(p.bivector_vector(linear_action_derivative(point, matrix)))
    derivative = np.column_stack(columns)
    vertical = p.vertical_bivector_matrix()
    jacobi = p.linearized_jacobi_matrix(point)
    assert_integer_product_zero(jacobi, derivative)
    assert_integer_product_zero(jacobi, vertical)
    jacobi_certificate = p.modular_rank_certificate(jacobi)
    family_certificate = p.modular_rank_certificate(np.column_stack([vertical, derivative]))
    assert jacobi_certificate['rank_mod_prime'] == 102
    assert family_certificate['rank_mod_prime'] == 48
    return {
        'base_parameters': {'b': 7, 't': 0},
        'jacobi_matrix_certificate': jacobi_certificate,
        'family_matrix_certificate': family_certificate,
        'ambient_affine_tangent_dimension': 24,
        'family_affine_differential_rank': 24,
        'full_affine_component_dimension': 24,
        'full_projective_component_dimension': 23,
        'rank_two_Aff32_affine_family_dimension': 23,
        'rank_two_Aff32_projective_family_dimension': 22,
    }


def inverse_matrix(matrix):
    size = len(matrix)
    augmented = [[Fraction(value) for value in row]
                 + [Fraction(int(i == j)) for j in range(size)]
                 for i, row in enumerate(matrix)]
    for column in range(size):
        pivot = next(i for i in range(column, size) if augmented[i][column])
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        scalar = augmented[column][column]
        augmented[column] = [value / scalar for value in augmented[column]]
        for row in range(size):
            if row == column:
                continue
            scalar = augmented[row][column]
            augmented[row] = [a - scalar * b
                              for a, b in zip(augmented[row], augmented[column])]
    return [row[size:] for row in augmented]


def divergence(bivector):
    result = []
    for j in range(5):
        coefficient = defaultdict(int)
        for i in range(5):
            p.add_polynomial(coefficient,
                             p.polynomial_derivative(p.bivector_entry(bivector, i, j), i))
        result.append({powers: value for powers, value in coefficient.items() if value})
    return result


def change_linear_coordinates(bivector, matrix):
    inverse = inverse_matrix(matrix)
    linear_forms = [
        {tuple(int(j == k) for j in range(5)): row[k]
         for k in range(5) if row[k]}
        for row in inverse
    ]
    result = {pair: defaultdict(int) for pair in p.PAIRS}
    for (k, l), coefficient in bivector.items():
        substituted = defaultdict(int)
        for powers, scalar in coefficient.items():
            term = {(0,) * 5: scalar}
            for variable, degree in enumerate(powers):
                for _ in range(degree):
                    term = p.polynomial_product(term, linear_forms[variable])
            p.add_polynomial(substituted, term)
        for i, j in p.PAIRS:
            scalar = matrix[i][k] * matrix[j][l] - matrix[i][l] * matrix[j][k]
            p.add_polynomial(result[(i, j)], substituted, scalar)
    return {pair: {powers: value for powers, value in coefficient.items() if value}
            for pair, coefficient in result.items()}


def fraction_matrix_json(matrix):
    return [[str(Fraction(value)) for value in row] for row in matrix]


def verify_toric_limit(family):
    point = {pair: specialize(polynomial, 7, 1)
             for pair, polynomial in family.items()}
    coordinate_matrix = [
        [0, 0, 0, 1, 1], [-1, 7, 0, 0, 0], [1, -8, 2, 0, 0],
        [1, -6, 0, 0, 0], [0, 0, 0, 1, 0],
    ]
    transformed = change_linear_coordinates(point, coordinate_matrix)
    euler = [{tuple(int(i == k) for k in range(5)): 1} for i in range(5)]
    vertical_correction = wedge_fields(euler, divergence(transformed))
    transformed = {
        pair: add_polynomials(transformed[pair],
                              scale_polynomial(vertical_correction[pair], Fraction(-1, 5)))
        for pair in p.PAIRS
    }
    transformed = {pair: {powers: value for powers, value in coefficient.items() if value}
                   for pair, coefficient in transformed.items()}
    assert not any(divergence(transformed))
    assert all(not coefficient
               for coefficient in p.affine_jacobi_coefficients(transformed).values())
    weights = [0, 1, -2, 0, 2]
    weight_counts = Counter()
    limit = {pair: {} for pair in p.PAIRS}
    extra_terms = []
    for (i, j), polynomial in transformed.items():
        for powers, coefficient in polynomial.items():
            weight = sum(a * b for a, b in zip(weights, powers)) - weights[i] - weights[j]
            weight_counts[weight] += 1
            assert weight >= 0
            if weight == 0:
                assert powers == tuple(int(k == i) + int(k == j) for k in range(5))
                limit[(i, j)][powers] = coefficient
            else:
                extra_terms.append({'pair': [i, j], 'exponents': list(powers),
                                    'coefficient': str(coefficient), 'weight': weight})
    assert pfaffian_section(limit) == {(1, 1, 1, 1, 1): Fraction(24)}
    expected_extras = {
        ((0, 1), (0, 0, 0, 1, 1)): 1,
        ((0, 2), (0, 1, 0, 0, 1)): 2,
        ((2, 3), (0, 2, 0, 0, 0)): 2,
    }
    assert {(tuple(term['pair']), tuple(term['exponents'])): Fraction(term['coefficient'])
            for term in extra_terms} == expected_extras
    poisson_matrix = [[Fraction(0) for _ in range(5)] for _ in range(5)]
    for (i, j), coefficient in limit.items():
        scalar = next(iter(coefficient.values()))
        poisson_matrix[i][j] = scalar
        poisson_matrix[j][i] = -scalar
    chart_matrix = [
        [poisson_matrix[i][j] - poisson_matrix[i][4] + poisson_matrix[j][4]
         for j in range(4)]
        for i in range(4)
    ]
    chart_inverse = inverse_matrix(chart_matrix)
    residue_matrix = [[Fraction(0) for _ in range(5)] for _ in range(5)]
    for i in range(4):
        for j in range(4):
            residue_matrix[i][j] = chart_inverse[i][j]
        residue_matrix[i][4] = -sum(chart_inverse[i])
        residue_matrix[4][i] = sum(chart_inverse[i])
    assert all(sum(row) == 0 for row in residue_matrix)
    # Smoothable-edge exponent test in the chosen residue convention.
    edge_exponents = {}
    for i, j in [(0, 1), (2, 3)]:
        exponents = {}
        for k in range(5):
            if k not in (i, j):
                exponent = ((residue_matrix[k][i] - residue_matrix[k][j])
                            / residue_matrix[i][j])
                assert exponent.denominator == 1 and exponent >= 0
                exponents[str(k)] = int(exponent)
        edge_exponents[f'{i}{j}'] = exponents
    assert edge_exponents == {'01': {'2': 0, '3': 1, '4': 1},
                              '23': {'0': 0, '1': 2, '4': 0}}
    return {
        'base_parameters': {'b': 7, 't': 1},
        'coordinate_matrix_z_equals_Bx': coordinate_matrix,
        'lift_normalization': 'P_unimodular = P - (1/5) E wedge div(P)',
        'unimodular_affine_jacobi_exact_zero': True,
        'one_parameter_weights': weights,
        'weight_counts': {str(weight): count for weight, count in sorted(weight_counts.items())},
        'positive_weight_terms': extra_terms,
        'toric_poisson_matrix_lambda': fraction_matrix_json(poisson_matrix),
        'chart_log_poisson_matrix': fraction_matrix_json(chart_matrix),
        'chart_log_poisson_matrix_inverse': fraction_matrix_json(chart_inverse),
        'five_coordinate_residue_matrix': fraction_matrix_json(residue_matrix),
        'toric_pfaffian_coefficient': 24,
        'toric_pfaffian_monomial': 'z0*z1*z2*z3*z4',
        'smoothing_edge_exponents': edge_exponents,
        'smoothing_edges': ['01', '23'],
        'catalog_label_used_in_this_bundle': 'T19',
        'catalog_label_is_canonical_literature_name': False,
    }


def main():
    family = symbolic_family()
    assert not euler_wedge_trivector(p.affine_jacobi_coefficients(family))
    verify_symbolic_pfaffian(family)
    report = {
        'symbolic_ring': 'Z[x0,x1,x2,x3,x4,b,t]',
        'schouten_derivative_variables': ['x0', 'x1', 'x2', 'x3', 'x4'],
        'projective_jacobi_identity_exact': True,
        'pfaffian_identity_exact': True,
        'pfaffian_formula': '2*(b-1)*t*x3*(2*(x0-(b-1)*t*x1)*x2-x1^2)*(x1*x3-(x0-b*t*x1)*x4)',
        'generic_degeneracy_divisor_degrees': [1, 2, 2],
        'generic_quadric_ranks': [3, 4],
        'smooth_point_certificate': verify_smooth_point(family),
        'toric_degeneration_certificate': verify_toric_limit(family),
    }
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

"""Independent exact checks of the c2=1 extension and its O(5) model."""
import itertools
import json
from pathlib import Path
import sympy as s

out = Path(__file__).parent
a, b, c, d, t = s.symbols('a b c d t')
v = (a, b, c, d)
lam, mu = s.symbols('lambda mu')
S = s.Matrix([[d,b,0,0],[-c,0,b,0],[0,-a,0,d],[0,0,-a,-c]])
w = s.Matrix([b,-d,c,-a])
f = s.Matrix([[lam*a,mu*c,mu*d,lam*b]])
T = S.col_join(f.subs({lam:1,mu:1}))
assert S*w == s.zeros(4,1)
assert f*w == s.zeros(1,1)
generators = s.Matrix([[a*c,a*d,b*c,b*d]])
assert generators*S == s.zeros(1,4)

fvars = s.symbols('f:20')
flin = s.Matrix(1,4,lambda i,j:sum(fvars[5*j+k]*x for k,x in enumerate((*v,t))))
Eeq = s.Poly((flin*w)[0],a,b,c,d,t).coeffs()
Emat, _ = s.linear_eq_to_matrix(Eeq,fvars)
assert len(Emat.nullspace()) == 6
rows = [s.Matrix([s.expand(S[i,j]).coeff(x) for j in range(4) for x in (*v,t)]) for i in range(4)]
reps = [s.Matrix([s.expand(fr[0,j]).coeff(x) for j in range(4) for x in (*v,t)])
        for fr in (f.subs({lam:1,mu:0}),f.subs({lam:0,mu:1}))]
assert s.Matrix.hstack(*rows).rank() == 4
assert s.Matrix.hstack(*rows,*reps).rank() == 6

pairs = list(itertools.combinations(range(5),2))
def skew(entries):
    P=s.zeros(5)
    for (i,j),p in zip(pairs,entries): P[i,j]=p; P[j,i]=-p
    return P
Pgeo=skew([a*a,c*c,a*b+c*d,a*c,-a*b+c*d,d*d,a*d,b*b,b*c,b*d])
Pspin=skew([b*d,-b*c,-a*d,a*c,b*b,d*d,-a*b-c*d,a*b-c*d,c*c,a*a])
assert all(s.expand(e)==0 for e in T.T*Pgeo)
def pfaffs(P):
    return [s.expand(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])
            for i,j,k,l in itertools.combinations(range(5),4)]
assert pfaffs(Pgeo)==[0]*5
assert pfaffs(Pspin)==[0]*5

mons=[v[i]*v[j] for i in range(4) for j in range(i,4)]
quadmat=s.Matrix([[s.Poly(Pgeo[i,j],*v).coeff_monomial(m) for m in mons] for i,j in pairs])
assert quadmat.det()!=0

def metric(P):
    qvars=s.symbols('q:15'); qi=0; Q=s.zeros(5)
    for i in range(5):
        for j in range(i,5):
            Q[i,j]=Q[j,i]=qvars[qi]; qi+=1
    eq=[]
    for ff in P.T*Q*P: eq.extend(s.Poly(ff,*v).coeffs())
    M,_=s.linear_eq_to_matrix(eq,qvars)
    ns=M.nullspace()
    assert len(ns)==1
    Q=Q.subs(dict(zip(qvars,ns[0])))
    assert Q.det()!=0
    return Q
Qg=metric(Pgeo); Qs=metric(Pspin)
assert Qs[0,0]!=0 and Qs[1,1]==0

Avars=s.symbols('z:20'); A=s.Matrix(4,5,Avars)
div_data={}
for killed in (None,0,1):
    R=s.eye(5)
    if killed is not None: R[killed,killed]=0
    P=R*Pspin*R.T
    eq=[]
    for j in range(5):
        div=sum(s.diff(P[i,j],v[k])*A[k,i] for i in range(5) for k in range(4))
        eq.extend([s.expand(div).coeff(x) for x in v])
    D,_=s.linear_eq_to_matrix(eq,Avars)
    ns=D.nullspace()
    z=s.symbols('u:'+str(len(ns)))
    Avec=sum((zi*ni for zi,ni in zip(z,ns)),s.zeros(20,1))
    AM=s.Matrix(4,5,Avec)
    maximal=[s.factor(AM[:,ii].det()) for ii in itertools.combinations(range(5),4)]
    div_data[str(killed)]={'rank':D.rank(),'nullity':len(ns),'kernel':[[str(e) for e in row] for row in AM.tolist()],
        'all_input_maximal_minors_zero':all(m==0 for m in maximal),'input_maximal_minors':[str(m) for m in maximal]}
assert div_data['None']['rank']==20
assert div_data['0']['rank']==16
assert div_data['0']['all_input_maximal_minors_zero']
assert div_data['1']['rank']==12
assert not div_data['1']['all_input_maximal_minors_zero']

# Check the surviving orbit's integration independently by exterior minors.
x=s.symbols('x:5')
u0,u1,u2,u3,u4,u5,u6,u7=z
tt=x[1]
Q1=u0*tt*x[0]-u4*x[0]*x[4]-u3*tt*x[3]-u6*x[3]*x[4]-u5*tt*x[4]-u7*x[4]**2/2
Q2=-u3*tt*x[0]-u6*x[0]*x[4]+u0*tt*x[2]-u4*x[2]*x[4]+u1*tt*x[4]+u2*x[4]**2/2
Psub=P.subs(dict(zip(v,AM*s.Matrix(x))),simultaneous=True)
J=s.Matrix([[s.diff(q,xx) for xx in x] for q in (tt,Q1,Q2)])
PJ=s.zeros(5)
for i,j in pairs:
    cc=[k for k in range(5) if k not in (i,j)]
    PJ[i,j]=(-1)**(i+j-1)*J[:,cc].det(); PJ[j,i]=-PJ[i,j]
assert all(s.expand(e)==0 for e in PJ+Psub)
assert all(s.expand(e)==0 for e in Psub*J.T)

data={'extension_syzygy_dimension':6,'extension_coboundary_dimension':4,'extension_quotient_dimension':2,
      'extension_representatives_independent':True,'T_transpose_Pgeo_zero':True,
      'Pgeo_pfaffians_zero':True,'Pspin_pfaffians_zero':True,
      'Pgeo_quadratic_basis_determinant':str(quadmat.det()),
      'Pgeo_metric':[[str(e) for e in row] for row in Qg.tolist()],
      'Pspin_metric':[[str(e) for e in row] for row in Qs.tolist()],
      'Pgeo_metric_determinant':str(Qg.det()),'Pspin_metric_determinant':str(Qs.det()),
      'projection_0_nonisotropic':True,'projection_1_isotropic':True,'divergence':div_data,
      'surviving_orbit_actual_Jacobian_identity':True,'surviving_orbit_three_Casimirs_checked':True}
(out/'audit_c2_one.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))

#!/usr/bin/env python3
"""Independent exact verification of the full and rank-four spinor cases."""
import itertools
import json
from pathlib import Path
import sympy as s

a, b, c, d = s.symbols("a b c d")
v = (a, b, c, d)
pairs = list(itertools.combinations(range(5), 2))
entries = (b*d, -b*c, -a*d, a*c, b*b, d*d,
           -a*b-c*d, a*b-c*d, c*c, a*a)
P = s.zeros(5)
for (i, j), f in zip(pairs, entries):
    P[i, j], P[j, i] = f, -f
M = s.Matrix([[-2,0,0,0,0], [0,0,0,0,-1],
              [0,0,0,1,0], [0,0,1,0,0], [0,-1,0,0,0]])
AA = s.symbols("h0:20")
A = s.Matrix(4, 5, AA)

def zero(expressions):
    return all(s.expand(f) == 0 for f in expressions)

def differential(Q):
    div = [s.expand(sum(A[k, i]*s.diff(Q[i, j], v[k])
                        for k in range(4) for i in range(5)))
           for j in range(5)]
    return s.linear_eq_to_matrix([f.coeff(z) for f in div for z in v], AA)[0]

D = differential(P)
results = {
    "spinor_metric_determinant": int(M.det()),
    "isotropic_image": zero(P.T*M*P),
    "full_divergence_rank": D.rank(),
    "full_divergence_determinant": int(D.det()),
}

P0 = P.copy()
P1 = P.copy()
for i in range(5):
    P0[0, i] = P0[i, 0] = 0
    P1[1, i] = P1[i, 1] = 0
D0, D1 = differential(P0), differential(P1)
kernel0 = D0.nullspace()
results["nonisotropic_rank"] = D0.rank()
results["nonisotropic_kernel_supported_in_column_zero"] = all(
    z == 0 for w in kernel0 for k, z in enumerate(w) if k % 5 != 0)

x = s.symbols("x0:5")
t, z = x[1], x[4]
r0,r1,r2,r3,r4,r5,r6,r7 = s.symbols("r0:8")
As = s.Matrix([[0,r0,0,0,-r4], [-r6,r1,-r4,0,r2],
               [0,r3,0,0,r6], [r4,r5,0,r6,r7]])
Q = P1.subs(dict(zip(v, As*s.Matrix(x))), simultaneous=True)
Q1 = r0*x[0]*t-r3*t*x[3]-r4*x[0]*z-r5*t*z-r6*x[3]*z-r7*z*z/2
Q2 = r0*t*x[2]+r1*t*z+r2*z*z/2-r3*x[0]*t-r4*x[2]*z-r6*x[0]*z
J = s.Matrix([[s.diff(f, xx) for xx in x] for f in (t,Q1,Q2)])
PJ = s.zeros(5)
for i,j in pairs:
    complement = [k for k in range(5) if k not in (i,j)]
    PJ[i,j] = (-1)**(i+j-1)*J[:,complement].det()
    PJ[j,i] = -PJ[i,j]
results.update({
    "isotropic_divergence_rank": D1.rank(),
    "isotropic_A_parametrizes_kernel": zero(D1*s.Matrix(list(As))),
    "isotropic_parameter_rank": s.Matrix(list(As)).jacobian(s.symbols("r0:8")).rank(),
    "all_three_casimirs": all(zero(Q*s.Matrix([s.diff(f,xx) for xx in x]))
                              for f in (t,Q1,Q2)),
    "Jacobian_bivector_equals_negative_projected_spinor": zero(PJ+Q),
})
assert results["full_divergence_rank"] == 20
assert abs(results["full_divergence_determinant"]) == 16
assert results["nonisotropic_rank"] == 16
assert results["isotropic_divergence_rank"] == 12
assert results["isotropic_parameter_rank"] == 8
assert all(value for value in results.values() if isinstance(value, bool))
results["all_passed"] = True
Path(__file__).with_suffix(".json").write_text(
    json.dumps(results, indent=2)+"\n", encoding="utf-8")
print(json.dumps(results, indent=2))

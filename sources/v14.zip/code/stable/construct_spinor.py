import json
import itertools
from pathlib import Path
import sympy as s

out=Path(__file__).parent
v=s.symbols('a b c d')
J=s.zeros(4)
J[0,1]=J[2,3]=1
J[1,0]=J[3,2]=-1
forms=[]
for pairs in [[(0,1,1),(2,3,-1)],[(0,2,1)],[(0,3,1)],[(1,2,1)],[(1,3,1)]]:
    F=s.zeros(4)
    for i,j,c in pairs:F[i,j]=c;F[j,i]=-c
    forms.append(F)
cliff=[J.inv()*F for F in forms]
B=s.Matrix.hstack(*[K*s.Matrix(v) for K in cliff])
q=s.Matrix(5,5,lambda i,j:s.trace(cliff[i]*cliff[j])/4)
assert q.det()!=0
for i in range(5):
    for j in range(5):
        assert cliff[i]*cliff[j]+cliff[j]*cliff[i]==2*q[i,j]*s.eye(4)
assert s.Matrix(v).T*J*B==s.zeros(1,5)
minor3=[s.expand(B.extract(rows,cols).det())
        for rows in itertools.combinations(range(4),3)
        for cols in itertools.combinations(range(5),3)]
mons3=[s.prod(v[i] for i in inds) for inds in itertools.combinations_with_replacement(range(4),3)]
M3=s.Matrix([[s.Poly(ff,*v).coeff_monomial(mm) for mm in mons3] for ff in minor3])
assert M3.rank()==20
mons=[v[i]*v[j] for i in range(4) for j in range(i,4)]
pairlist=[(i,j) for i in range(5) for j in range(i+1,5)]
u=s.symbols('u:100')
P=s.zeros(5)
for p,(i,j) in enumerate(pairlist):
    P[i,j]=sum(u[p*10+k]*mon for k,mon in enumerate(mons));P[j,i]=-P[i,j]
eq=[]
for f in B*P:eq.extend(s.Poly(f,*v).coeffs())
M,_=s.linear_eq_to_matrix(eq,u)
ns=M.nullspace()
assert len(ns)==1
vec=ns[0]
den=s.ilcm(*[e.q for e in vec]);vec=vec*den
g=s.igcd(*[int(e) for e in vec]);vec=vec/g
P=P.subs(dict(zip(u,vec)))
assert all(s.expand(f)==0 for f in B*P)
assert all(s.expand(f)==0 for f in P.T*q*P)
assert all(s.expand(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])==0
           for i in range(5) for j in range(i+1,5)
           for k in range(j+1,5) for l in range(k+1,5))
Avars=s.symbols('h:20')
A=s.Matrix(4,5,Avars)
div=s.Matrix([sum(A[k,i]*s.diff(P[i,j],v[k]) for i in range(5) for k in range(4)) for j in range(5)])
D,_=s.linear_eq_to_matrix([s.expand(f).coeff(vk) for f in div for vk in v],Avars)
kn=D.nullspace()
assert len(kn)==0
assert D.det()!=0
data={
 'spinor_variables':[str(x) for x in v],
 'clifford_matrices':[[[str(c) for c in row] for row in K.tolist()] for K in cliff],
 'kernel_matrix':[[str(c) for c in row] for row in B.tolist()],
 'orthogonal_metric':[[str(c) for c in row] for row in q.tolist()],
 'orthogonal_metric_determinant':str(q.det()),
 'clifford_anticommutators_verified':True,
 'all_3x3_minors_span_cubic_forms_rank':M3.rank(),
 'isotropic_Plucker_image_verified':True,
 'plucker_pair_order':pairlist,
 'plucker_quadratics':[str(s.factor(P[i,j])) for i,j in pairlist],
 'plucker_linear_system_shape':M.shape,
 'plucker_linear_system_rank':M.rank(),
 'divergence_linear_system_shape':D.shape,
 'divergence_linear_system_rank':D.rank(),
 'divergence_determinant':str(D.det()),
 'divergence_kernel_dimension':len(kn),
}
(out/'spinor_certificate.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data,indent=2))

#!/usr/bin/env python3
"""Exact certificates for the c2=1 extension and orthogonal Plucker model."""
from itertools import combinations
import json
from pathlib import Path
import sympy as s

a, b, c, d, t = s.symbols("a b c d t")
y = (a, b, c, d)
pair_order = list(combinations(range(5), 2))
entries = [a*a, c*c, a*b+c*d, a*c, -a*b+c*d,
           d*d, a*d, b*b, b*c, b*d]
P = s.zeros(5)
for (i, j), f in zip(pair_order, entries):
    P[i, j], P[j, i] = f, -f
S = s.Matrix([[d,b,0,0], [-c,0,b,0], [0,-a,0,d], [0,0,-a,-c]])
w = s.Matrix([b,-d,c,-a])
T = S.col_join(s.Matrix([[a,c,d,b]]))
metric = s.Matrix([[0,0,0,1,0], [0,0,-1,0,0],
                   [0,-1,0,0,0], [1,0,0,0,0], [0,0,0,0,2]])

def identically_zero(seq):
    return all(s.expand(z) == 0 for z in seq)

pfaffians = [P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k]
             for i,j,k,l in combinations(range(5), 4)]
monomials = [a*a,a*b,a*c,a*d,b*b,b*c,b*d,c*c,c*d,d*d]
veronese = s.Matrix([[s.Poly(f,y).coeff_monomial(m) for m in monomials]
                    for f in entries])

# Universal divergence for P(Ax), A a 4x5 matrix. Since input coordinates
# are independent for rank A=4, the twenty coefficients must all vanish.
parameters = s.symbols("A0:20")
A = s.Matrix(4,5,parameters)
divergence_coefficients = []
for j in range(5):
    v = s.expand(sum(A[k,i]*s.diff(P[i,j], y[k])
                     for i in range(5) for k in range(4)))
    divergence_coefficients += [v.coeff(x) for x in y]
divergence = s.linear_eq_to_matrix(divergence_coefficients, parameters)[0]

# Ext1: four linear forms f with f.w=0, modulo the four rows of S.
f_parameters = s.symbols("f0:20")
variables = y + (t,)
f = s.Matrix(1,4,[sum(f_parameters[5*i+j]*variables[j] for j in range(5))
                   for i in range(4)])
ext_differential = s.linear_eq_to_matrix(
    s.Poly((f*w)[0], variables).coeffs(), f_parameters)[0]
row_vectors = []
for i in range(4):
    row_vectors.append([S[i,k].coeff(x) for k in range(4) for x in variables])
classes = [[a,0,0,b], [0,c,d,0]]
class_vectors = [[s.sympify(v).coeff(x) for v in cls for x in variables] for cls in classes]
six_vectors = s.Matrix(row_vectors + class_vectors)

checks = {
    "syzygy_Sw_zero": identically_zero(S*w),
    "extended_syzygy_Tw_zero": identically_zero(T*w),
    "kernel_Ttranspose_P_zero": identically_zero(T.T*P),
    "all_five_pfaffians_zero": identically_zero(pfaffians),
    "isotropy_Ptranspose_metric_P_zero": identically_zero(P.T*metric*P),
    "metric_determinant": int(metric.det()),
    "veronese_coefficient_rank": veronese.rank(),
    "veronese_coefficient_determinant": int(veronese.det()),
    "universal_divergence_rank": divergence.rank(),
    "universal_divergence_determinant": int(divergence.det()),
    "ext_relation_kernel_dimension": 20-ext_differential.rank(),
    "ext_trivial_change_rank": s.Matrix(row_vectors).rank(),
    "ext_six_representatives_rank": six_vectors.rank(),
    "all_ext_representatives_satisfy_relation": identically_zero(
        ext_differential*six_vectors.T),
}
assert all(checks[k] for k in checks if isinstance(checks[k], bool))
assert (checks["metric_determinant"], checks["veronese_coefficient_determinant"],
        checks["universal_divergence_determinant"]) == (2,2,16)
assert (checks["ext_relation_kernel_dimension"], checks["ext_trivial_change_rank"],
        checks["ext_six_representatives_rank"]) == (6,4,6)
result = {
    "model": [str(z) for z in entries],
    "pair_order": pair_order,
    "input_variable_order": [str(z) for z in y],
    "monomial_order": [str(z) for z in monomials],
    "metric": metric.tolist(),
    "veronese_matrix": veronese.tolist(),
    "universal_divergence_matrix": divergence.tolist(),
    "checks": checks,
    "all_passed": True,
}
out = Path(__file__).with_suffix(".json")
out.write_text(json.dumps(result, indent=2, default=str)+"\n", encoding="utf-8")
print(json.dumps(checks, indent=2))
print("all_passed=true")

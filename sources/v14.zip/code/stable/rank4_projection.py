import json
from pathlib import Path
import itertools
import sympy as s

out=Path(__file__).parent
a,b,c,d=s.symbols('a b c d');v=(a,b,c,d)
ps=[b*d,-b*c,-a*d,a*c,b*b,d*d,-a*b-c*d,a*b-c*d,c*c,a*a]
pairs=list(itertools.combinations(range(5),2))
P=s.zeros(5)
for(i,j),f in zip(pairs,ps):P[i,j]=f;P[j,i]=-f
AA=s.symbols('h:20');A=s.Matrix(4,5,AA)
results={}
for kill in (0,1):
    B=s.eye(5);B[kill,kill]=0
    Q=B*P*B.T
    dv=s.Matrix([sum(A[k,i]*s.diff(Q[i,j],v[k]) for i in range(5) for k in range(4)) for j in range(5)])
    D,_=s.linear_eq_to_matrix([s.expand(f).coeff(t) for f in dv for t in v],AA)
    ker=D.nullspace();z=s.symbols('r0:'+str(len(ker)))
    Avec=sum((zi*ki for zi,ki in zip(z,ker)),s.zeros(20,1))
    AM=s.Matrix(4,5,Avec)
    minors=[s.factor(AM[:,[i for i in range(5) if i!=j]].det()) for j in range(5)]
    dat={'kill':kill,'D_rank':D.rank(),'kernel_dimension':len(ker),
         'kernel_parameters':[str(t) for t in z],
         'kernel_A':[[str(x) for x in row] for row in AM.tolist()],
         'maximal_minors':[str(m) for m in minors],
         'all_maximal_minors_zero':all(m==0 for m in minors)}
    x=s.symbols('x0:5')
    vA=AM*s.Matrix(x)
    QQ=Q.subs(dict(zip(v,vA)),simultaneous=True)
    eulerw=[s.expand(x[i]*QQ[j,k]-x[j]*QQ[i,k]+x[k]*QQ[i,j])
            for i,j,k in itertools.combinations(range(5),3)]
    dat['euler_wedge_zero_mod_central_hyperplane']=all(s.expand(f.subs(x[kill],0))==0 for f in eulerw)
    dat['euler_wedge_quotient']=[str(s.factor(f/x[kill])) for f in eulerw] if dat['euler_wedge_zero_mod_central_hyperplane'] else []
    if kill==1:
        r0,r1,r2,r3,r4,r5,r6,r7=z;t=x[1]
        Q1=r0*t*x[0]-r4*x[0]*x[4]-r3*t*x[3]-r6*x[3]*x[4]-r5*t*x[4]-r7*x[4]**2/2
        Q2=-r3*t*x[0]-r6*x[0]*x[4]+r0*t*x[2]-r4*x[2]*x[4]+r1*t*x[4]+r2*x[4]**2/2
        for FF in (t,Q1,Q2):assert all(s.expand(ff)==0 for ff in QQ*s.Matrix([s.diff(FF,xx) for xx in x]))
        J=s.Matrix([[s.diff(F,xx) for xx in x] for F in (t,Q1,Q2)])
        # Complementary3x3 Jacobian minors, with contraction orientation.
        JR=s.zeros(5)
        for i,j in pairs:
            inds=[k for k in range(5) if k not in (i,j)]
            JR[i,j]=(-1)**(i+j-1)*J[:,inds].det();JR[j,i]=-JR[i,j]
        sign=next(s.cancel(JR[i,j]/QQ[i,j]) for i,j in pairs if QQ[i,j]!=0)
        assert sign in (1,-1)
        assert all(s.expand(ff)==0 for ff in JR-sign*QQ)
        dat['quadratic_Casimirs']=[str(s.factor(Q1)),str(s.factor(Q2))]
        dat['all_universal_center_identities_zero']=True
        dat['Jacobian_matrix_equals_projected_P_times']=str(sign)
    results[str(kill)]=dat
(out/'rank4_projection_certificate.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))

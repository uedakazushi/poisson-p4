射影4空間の Poisson 構造：研究継続 v6
====================================
2026年10月29日。基礎体 C。日本語本文は LuaLaTeX。

今回の到達点
------------
全射影 Poisson scheme の既約成分数の下界を48から52へ更新した。
52は確認した相異なる成分の数であり、成分総数の完全な決定ではない。

追加した四成分は、次の一般退化因子をもつ。

  一般退化因子           成分次元  一般PGL5軌道  被約有理商の次元
  3H+H1+H2                   28          22              6
  H+2H1+2H2                  28          22              6
  H+F4（F4は既約四次）       23          23              0
  5H                         23          22              1

最初の二族では、三つの超平面は共通の P2 を含む。
成分次元は非零 Poisson bivector の定数倍を除いた射影次元であり、
PGL5 による商を取る前の次元である。有理商は被約成分の Rosenlicht 商
を指し、商 scheme や moduli stack 全体を構成したという意味ではない。

最初の三成分は一般点で正則である。五重超平面の成分では、証明した
点および一般点の形式局所構造が

  C[[u1,...,u23,epsilon]]/(epsilon^3)

となる。被約台は23次元で滑らかだが、Poisson scheme の一般横断長は3。
二次までの普遍変形と、二次補正の全選択に対して消えない第三次
obstruction を全150係数で検証した。厚さ3を三成分とは数えない。
退化因子の重複度と、パラメータ scheme の非被約性は別の概念である。

補助空間 Q の成果
-----------------
A4 上の J=partial12+partial34 と compatible な二次 Poisson 構造の
45変数空間 Q では、実際の既約成分を少なくとも15個確認した。
これは全 P4 の52成分とは別の数である。

modular field の冪零型(2,2)では、固定 trace fiber の被約台を、ちょうど
17個の4次元既約成分に分解した。中心化群による同定後、modular orbit
上には11個の10次元 saturation がある。そのうち一つが全 Q の成分。
元の固定 fiber scheme 全体の被約性は主張していない。

さらに零 modular の10次元成分を得た。その完成局所環は

  C[[u1,...,u10,epsilon]]/(epsilon^3)

であり、これを homogenize した全 P4 の成分が上記の 5H 型である。
固定 fiber の17、orbit 上の11、全補助空間の15、全 P4 の52を区別する。

安定 rank2 の三次 Casimir
-------------------------
仮定は、一般 rank2、因子的零点がないこと、および飽和した葉方向接層
について H0(T_F)=0 である。canonical な二次斉次・発散零の lift を Pi、
標準体積形式を Omega、beta=i_Pi Omega とする。

既約三次斉次多項式 F が Pi の Casimir なら、独立な一次 Casimir L1,L2
と c!=0 が存在して

  beta=c*dF wedge dL1 wedge dL2

となる。これは実際の Rat(1,1,3) 表示であり、成分の閉包への所属だけを
述べたものではない。v5で残っていた normal・noncone で特異曲線をもつ
場合も処理した。中心の有限生成性は仮定しない。三次 Casimir の存在自体を
一般の安定構造について保証する定理ではない。

Rat(1,1,3)、Rat(1,2,2) の実際の表示に帰着しない上記の安定分岐では、
中心の次数別部分 A_d は

  (i) A1=A2=A3=0、または
  (ii) A1=C L, A2=C L^2, A3=C L^3

に限られる。(ii)には可約三次 Casimir L^3 が残る。
新たな独立な多項式 Casimir が存在するなら、その次数は4以上である。

収録物
------
p4_poisson_completeness_v6.pdf : 定理・証明・残存課題の日本語本文
*.tex                         : LuaLaTeX source
code/                         : 九つの検証 entrypoint、補助モデル、runner
data/                         : JSON証明書、実行ログ、検証結果
proofs/                       : 詳細な証明と独立監査
previous_v5/                  : 内容を変更していない v5 と、それ以前の記録
research_checkpoints/         : 未確定の探索記録を置く場所
HANDOFF.txt                   : 次回研究のための精密な引継ぎ

previous_v5/ のコードを参照する検証があるので、この履歴ディレクトリを
削除しないこと。研究途中の checkpoint は主定理の根拠として使用しない。

計算の再現
----------
Python3.12.14、NumPy2.3.5、SymPy1.14.0で確認した。
必要な Python 依存関係は requirements.txt にある。
このディレクトリを作業ディレクトリとして、標準的な Python 環境で

  python3 -m pip install -r requirements.txt
  python3 code/run_v6_checks.py

を実行する。runner は九つの検証を一時作業ディレクトリから順に起動し、
JSON証明書とログを data/ に再生成する。実行したスクリプトの内容ハッシュ、
終了コード、依存バージョンは data/v6_check_results.json に記録される。
収録した実行記録では九つすべてが exit0、all_passed=true である。

数学計算には浮動小数点の rank 判定、乱数、ネットワークを用いない。
有限体の非零 minor を使う箇所も、有理数上の rank または上界を別に確認する。
独立監査は、過去の Poisson helper を import せず全係数行列を再構築する。
検証を再実行しても過去の原稿や証明書を変更しない。

PDFの再組版
-----------
LuaLaTeX、luatexja、HaranoAjiフォント、本文で使用する標準パッケージを
含む日本語 TeX Live 環境が必要である。latexmk がある場合は

  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v6.tex

で組版できる。latexmk を使わない場合は lualatex を複数回実行し、目次と
相互参照を解決する。空の記入欄は設けていない。

未完了の範囲
------------
全分類、正確な成分総数、全 primary decomposition、全軌道の分類、
固定した二次・三次・四次超曲面上の moduli と周囲への延長の全対応、
文献上の新規性の認定は主張していない。次の具体的な研究対象は
HANDOFF.txt の「次回の研究タスク」に記した。

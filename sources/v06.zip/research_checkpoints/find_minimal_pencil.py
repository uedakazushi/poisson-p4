from pathlib import Path
from itertools import combinations
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'previous_v5'/'code'))
import certify_regular_nilpotent as c
sp,np=c.sp,c.np
x0,x,y,z,w=c.xx5
Q=sp.zeros(4)
entries=[3*x*x-6*x*z,0,-2*x*x,3*x*z-18*z*z,-2*x*y-3*x*w+30*z*w,6*x*z]
for I,v in zip(c.m.old.PAIRS,entries):Q[I]=v;Q[I[::-1]]=-v
qs=c.sparse(Q,1)
hams=[c.hamiltonian({mon:1}) for mon in c.p.DEGREE_TWO if mon[0]==0]
basis=[c.v.wedge_fields(A,B) for A,B in combinations(hams,2)]
target=[(I,mon) for I in combinations(range(1,5),3) for mon in c.p.homogeneous_monomials(3) if mon[0]==0]
cols=[c.polar(qs,R) for R in basis]
D=sp.Matrix([[col.get(I,{}).get(mon,0) for col in cols] for I,mon in target])
nn=D.nullspace()
def conv(d):
 R=sp.zeros(4)
 for (i,j),pol in d.items():
  f=sum(v*sp.prod(z**k for z,k in zip(c.xx5,mon)) for mon,v in pol.items())
  R[i-1,j-1]=f;R[j-1,i-1]=-f
 return R
bs=[conv(d) for d in basis]
t=sp.symbols('epsilon')
out=[]
for k,v in enumerate(nn):
 R=sum((v[i]*bs[i] for i in range(45)),sp.zeros(4))
 s=sp.expand(R[0,1]+R[2,3])
 jac=c.jac(R,c.xx)
 if jac==[0]*4:
  st=3*x*x+t*s
  X=sp.Matrix([-sp.diff(st,y),sp.diff(st,x),-sp.diff(st,w),sp.diff(st,z)])
  cp=sp.factor(X.jacobian(c.xx).charpoly().as_expr())
  out.append({'index':k,'R':{str(I):str(R[I]) for I in c.m.old.PAIRS},'trace':str(s),'charpoly':str(cp)})
  print('pencil',k,'s=',s,'char=',cp,flush=True)
 else:print('not poisson',k,'s=',s,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

from pathlib import Path
import sys,json
BASE=Path(__file__).resolve().parents[1]/'previous_v5'/'code'
sys.path.insert(0,str(BASE))
import certify_regular_nilpotent as c
sp,np=c.sp,c.np
x0,x,y,z,w=c.xx5
a,b,cc=sp.symbols('a b c')
d,e,f=sp.symbols('d e f')
Q=sp.zeros(4)
ent=[(sp.Rational(1,2)-cc)*x*x-a*x*z,
     0,-a*x*x/3,
     (3*cc-12*cc*cc)/(4*a)*x*x+(sp.Rational(1,2)-6*cc)*x*z-3*a*z*z,
     -a*x*y/3+d*x*x+e*x*z+(4*cc-sp.Rational(1,2))*x*w+f*z*z+5*a*z*w,
     cc*x*x+a*x*z]
for (i,j),p in zip(c.m.old.PAIRS,ent):Q[i,j]=p;Q[j,i]=-p
assert c.jac(Q,c.xx)==[0]*4
assert c.jac(Q+c.J,c.xx)==[0]*4
print('Pf=',sp.factor(Q[0,1]*Q[2,3]-Q[0,2]*Q[1,3]+Q[0,3]*Q[1,2]))
results=[]
for vals in [(1,0,0,0,0),(1,2,3,5,7),(2,1,2,3,4)]:
 qs0=Q.subs(dict(zip((a,cc,d,e,f),vals)))
 den=sp.ilcm(*[v.q for p in qs0 for v in sp.Poly(p,*c.xx).coeffs()])
 q=den*qs0
 qc=c.quadratic_certificate(q)
 P=sp.zeros(5)
 for i,j in c.m.old.PAIRS:P[i+1,j+1]=x0*x0*c.J[i,j]+q[i,j];P[j+1,i+1]=-P[i+1,j+1]
 ps=c.sparse(P)
 D=c.p.linearized_jacobi_matrix(ps)
 V=c.p.vertical_bivector_matrix()
 orbit=[]
 for i in range(5):
  for j in range(5):
   A=np.zeros((5,5),dtype=np.int64);A[i,j]=1
   orbit.append(c.p.bivector_vector(c.v.linear_action_derivative(ps,A)))
 M=np.column_stack([V,*orbit,c.p.bivector_vector(ps)])
 assert not np.any(D@M)
 dr=c.rank(D);mr=c.rank(M)
 r={'parameters':vals,'scale':str(den),'Q':{str(I):str(q[I]) for I in c.m.old.PAIRS},'quadratic':qc,'projective_tangent':125-dr,'projective_orbit':mr-25}
 results.append(r)
 print('sample',vals,'Q tang/orbit',qc['tangent_dimension'],qc['Sp4_orbit_dimension'],'P4 tang/orbit',125-dr,mr-25,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(results,indent=2)+'\n')

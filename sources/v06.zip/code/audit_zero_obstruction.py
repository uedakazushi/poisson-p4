#!/usr/bin/env python3
"""Independent all-coefficient audit of the order-three transverse obstruction.

Only SymPy and the standalone polynomial-dictionary algebra of
audit_nilpotent22.py are used. No historical Poisson helper is imported.
The universal tensors are read as data and all asserted identities/ranks
are independently reconstructed.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
import sys,json
import sympy as sp
from sympy.polys.matrices import DomainMatrix
import audit_nilpotent22 as d
HERE=Path(__file__).resolve().parent
xx=sp.symbols('x0:5');x0,x,y,z,w=xx
coords=sp.Matrix(xx[1:]);a,b=sp.symbols('a b')
pairs=list(combinations(range(1,5),2));triples=list(combinations(range(1,5),3))

def rank(M):return len(DomainMatrix.from_Matrix(M).convert_to(sp.QQ).rref()[1])
def tensor(entries):
    local={str(v):v for v in [*xx,a,b]}
    M=sp.zeros(4)
    for i,j in pairs:
        f=sp.sympify(entries[str(i)+str(j)],locals=local)
        M[i-1,j-1]=f;M[j-1,i-1]=-f
    return M
def sparse(M):
    return {(i+1,j+1):{(0,)+mon:v for mon,v in sp.Poly(M[i,j],*coords).terms() if v} for i,j in combinations(range(4),2)}
def jac(M):
    return [sp.expand(sum(M[i,l]*sp.diff(M[j,k],coords[l])+M[j,l]*sp.diff(M[k,i],coords[l])+M[k,l]*sp.diff(M[i,j],coords[l]) for l in range(4))) for i,j,k in combinations(range(4),3)]
def polar(M,N):return [sp.cancel(f-g-h) for f,g,h in zip(jac(M+N),jac(M),jac(N))]
def yvector(T):return sp.Matrix([T.get(I,{}).get(m,0) for I,m in d.YBASIS])
def vec(P):return sp.Matrix(d.vector(P))

def main():
    path=next(p for p in [HERE.parent/'p4_v6_zero_work'/'zero_log_component_certificate.json',HERE.parent/'data'/'zero_log_component_certificate.json'] if p.is_file())
    raw=json.loads(path.read_text())
    Q=tensor(raw['universal_Q_brackets']);R=tensor(raw['universal_R_brackets']);S=tensor(raw['universal_second_order_T_brackets'])
    U=sp.Matrix([0,a*z,0,b*x]);V=sp.Matrix([-b*x,(2*b-a)*y,a*z,(b-2*a)*w])
    assert (Q-(V*U.T-U*V.T)).applyfunc(sp.expand)==sp.zeros(4)
    J=sp.zeros(4);J[0,1]=J[2,3]=1;J[1,0]=J[3,2]=-1
    assert jac(Q)==[0]*4 and polar(J,Q)==[0]*4
    assert polar(Q,R)==polar(J,R)==polar(J,S)==[0]*4
    assert [sp.cancel(u+v) for u,v in zip(polar(Q,S),jac(R))]==[0]*4
    assert sp.expand(Q[0,1]+Q[2,3])==0 and sp.expand(R[0,1]+R[2,3])==x*y-z*w
    pt={a:5,b:7}
    q=sparse(Q.subs(pt));r=sparse(R.subs(pt));s=sparse(S.subs(pt))
    p={I:d.add(pol,{d.mon(0,0):1} if I in [(1,2),(3,4)] else {}) for I,pol in q.items()}
    assert not any(d.jac(p).values())
    second={I:d.add(pol,d.jac(r).get(I,{})) for I,pol in d.jac(p,s).items()}
    assert not any(second.values())
    O3=d.jac(r,s)
    JD=sp.Matrix.hstack(*(yvector(d.e_wedge(d.jac(p,{I:{m:1}}))) for I,m in d.XBASIS))
    vv=[d.vertical(i,j) for i in range(5) for j in range(5)]
    oo=[d.action(p,i,j) for i in range(5) for j in range(5)]
    fa=sparse(Q.diff(a).subs(pt));fb=sparse(Q.diff(b).subs(pt))
    actual=vv+oo+[p,fa,fb]
    F=sp.Matrix.hstack(*(vec(t) for t in actual));K=F.row_join(vec(r))
    assert JD*K==sp.zeros(JD.rows,K.cols)
    A=sp.Matrix.hstack(*(yvector(d.e_wedge(d.jac(r,t))) for t in actual+[r]))
    ob=yvector(d.e_wedge(O3))
    ranks={'Jacobi':rank(JD),'vertical':rank(sp.Matrix.hstack(*(vec(t) for t in vv))),
       'orbit_vertical_scale':rank(sp.Matrix.hstack(*(vec(t) for t in vv+oo+[p]))),
       'actual':rank(F),'all_tangent':rank(K),
       'all_second_order_ambiguities':rank(JD.row_join(A)),
       'third_obstruction':rank(JD.row_join(A).row_join(ob))}
    assert ranks=={'Jacobi':101,'vertical':24,'orbit_vertical_scale':47,'actual':48,'all_tangent':49,'all_second_order_ambiguities':101,'third_obstruction':102}
    # Reconstruct the compatible quadratic space independently from all60
    # coefficients, as the kernel of sixteen linear Jacobi coefficients.
    mon2=[m for m in d.MON2 if m[0]==0]
    xb=[(I,m) for I in pairs for m in mon2]
    mon1=[d.mon(i) for i in range(1,5)]
    mon3=[d.mon(*ii) for ii in combinations_with_replacement(range(1,5),3)]
    j={(1,2):{(0,0,0,0,0):1},(3,4):{(0,0,0,0,0):1}}
    target1=[(I,m) for I in triples for m in mon1]
    target3=[(I,m) for I in triples for m in mon3]
    coeff=lambda T,target:sp.Matrix([T.get(I,{}).get(m,0) for I,m in target])
    LC=sp.Matrix.hstack(*(coeff(d.jac(j,{I:{m:1}}),target1) for I,m in xb))
    assert rank(LC)==15
    NB=sp.Matrix.hstack(*LC.nullspace());assert NB.shape==(60,45)
    basis=[]
    for col in NB.columnspace():
        T={}
        for (I,m),v in zip(xb,col):
            if v:T.setdefault(I,{})[m]=v
        basis.append(T)
    Dq=sp.Matrix.hstack(*(coeff(d.jac(q,T),target3) for T in basis))
    qorbit=[]
    for i,k in combinations_with_replacement(range(4),2):
        h=coords[i]*coords[k]
        X=-J*sp.Matrix([sp.diff(h,t) for t in coords]);DM=X.jacobian(coords)
        T={}
        for I in d.PAIRS:
            T[I]=d.add(*(d.scale(d.action(q,u+1,v+1).get(I,{}),DM[u,v]) for u in range(4) for v in range(4) if DM[u,v]))
        qorbit.append(T)
    qactual=qorbit+[fa,fb]
    Fq=sp.Matrix.hstack(*(vec(T) for T in qactual));Kq=Fq.row_join(vec(r))
    Aq=sp.Matrix.hstack(*(coeff(d.jac(r,T),target3) for T in qactual+[r]))
    Oq=coeff(O3,target3)
    Tr=sp.Matrix([[T.get((1,2),{}).get(m,0)+T.get((3,4),{}).get(m,0) for T in basis] for m in mon2])
    qranks={'Jacobi':rank(Dq),'actual':rank(Fq),'all_tangent':rank(Kq),
       'zero_trace_constraints':rank(Dq.col_join(Tr)),
       'all_second_order_ambiguities':rank(Dq.row_join(Aq)),
       'third_obstruction':rank(Dq.row_join(Aq).row_join(Oq))}
    assert qranks=={'Jacobi':34,'actual':10,'all_tangent':11,'zero_trace_constraints':35,'all_second_order_ambiguities':34,'third_obstruction':35}
    out={'implementation':'Independent dictionary calculus and QQ DomainMatrix; all60 quadratic and all150 projective coefficients.',
       'universal_first_and_second_jets':True,'universal_Q_wedge_formula':True,
       'full_P4_ranks':ranks,'quadratic_ranks':qranks,
       'second_order_Jacobi_exactly_zero':True,
       'third_order_obstruction_survives_every_second_order_choice':True,
       'all_first_order_directions_are_actual_plus_R':True,
       'formal_local_rings_supported':['C[[u1,...,u23,t]]/(t^3)','C[[u1,...,u10,t]]/(t^3)'],
       'scope':'Exact algebraic audit; formal implicit-function argument is recorded in the written proof.'}
    dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE
    dest.mkdir(parents=True,exist_ok=True)
    (dest/'zero_obstruction_independent_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()

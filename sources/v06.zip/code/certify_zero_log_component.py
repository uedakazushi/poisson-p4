#!/usr/bin/env python3
"""A zero-modular component with generic transverse ring C[e]/(e^3).

Certifies both the 45-dimensional compatible-quadratic ambient scheme and
THE FULL P4 Poisson scheme.  All first/second universal jets are verified as
rational identities.  At A=5,B=7 it checks that every tangent direction is
spanned by actual family directions and R, and that the third obstruction
survives arbitrary second-order choices, using exact ranks over Q.
"""
from pathlib import Path
from fractions import Fraction
from itertools import combinations
import sys,json
import sympy as s
import numpy as np
HERE=Path(__file__).resolve().parent
for base in [HERE.parent/'p4_poisson_completeness_v5'/'code',HERE.parent/'previous_v5'/'code']:
    if base.is_dir():sys.path.insert(0,str(base));break
else:raise RuntimeError('v5 certificate helper directory not found')
import certify_regular_nilpotent as c
x,y,z,w=c.xx
xx=c.xx
pairs=list(combinations(range(4),2))
a,b=s.symbols('a b')
J=c.J

def wedge(X,Y):return X*Y.T-Y*X.T

def polar_symbolic(A,B):
    return [s.cancel(f-g-h) for f,g,h in zip(c.jac(A+B,xx),c.jac(A,xx),c.jac(B,xx))]

def simplify_all(pol):return [s.cancel(f) for f in pol]

def projective_vector(jac):
    out=np.zeros(len(c.p.FOUR_VECTOR_BASIS),dtype=np.int64)
    for triple,pol in jac.items():
        for k in range(5):
            sign=c.p.permutation_sign((k,)+triple)
            if not sign:continue
            for mon,coeff in pol.items():
                mm=list(mon);mm[k]+=1
                out[c.p.FOUR_VECTOR_INDEX[(tuple(sorted((k,)+triple)),tuple(mm))]]+=sign*coeff
    return out

def vector_to_bivector(col):
    out={}
    for (ij,mon),v in zip(c.p.BIVECTOR_BASIS,col):
        if v:out.setdefault(ij,{})[mon]=int(v)
    return out

def encode_matrix(Q):return {''.join(str(i+1) for i in ij):str(s.factor(Q[ij])) for ij in pairs}

def exact_rank(M):return c.rank_cert(np.asarray(M,dtype=np.int64))

def main(output_dir=HERE):
    U=s.Matrix([0,a*z,0,b*x])
    V=s.Matrix([-b*x,(2*b-a)*y,a*z,(b-2*a)*w])
    Q=wedge(V,U)
    assert c.jac(Q,xx)==[0]*4
    assert c.jac(Q+J,xx)==[0]*4
    assert s.expand(Q[0,1]+Q[2,3])==0
    assert all(s.expand(sum(s.diff(Q[i,j],xx[i]) for i in range(4)))==0 for j in range(4))
    assert s.expand(Q[0,1]*Q[2,3]-Q[0,2]*Q[1,3]+Q[0,3]*Q[1,2])==0
    # Two universal independent projective stabilizers give orbit<=22.
    H=s.Matrix([x,-y,-z,w]);K=s.Matrix([0,y,0,w])
    assert c.lie(H,Q,xx)==s.zeros(4) and c.lie(H,J,xx)==s.zeros(4)
    assert (c.lie(K,Q,xx)+Q).applyfunc(s.expand)==s.zeros(4) and c.lie(K,J,xx)==-J
    # Identification with the logarithmic (1,1,2) form, including all signs.
    quad=b*x*y-a*z*w
    dquad=s.Matrix([s.diff(quad,t) for t in xx])
    eta=((b-3*a)*z*quad*s.Matrix([1,0,0,0])+(a-3*b)*x*quad*s.Matrix([0,0,1,0])+(a+b)*x*z*dquad)/4
    dalpha=s.Matrix(4,4,lambda i,j:s.expand(s.diff(eta[j],xx[i])-s.diff(eta[i],xx[j])))
    for i,j in pairs:
        k,l=[h for h in range(4) if h not in [i,j]]
        sign=c.p.permutation_sign((i,j,k,l))
        assert s.expand(Q[i,j]-sign*dalpha[k,l])==0
    # All quadratic additions in the vertical constant wedge are obtained
    # by a symplectic shear for general a,b, and hence lie in the closure.
    psh,qsh,rsh=s.symbols('p_sh q_sh r_sh')
    G=s.Matrix([[1,0,0,0],[psh,1,qsh,0],[0,0,1,0],[qsh,0,rsh,1]])
    assert G*J*G.T==J
    change=(c.push(Q,G)-Q).applyfunc(s.expand)
    wanted=b*(a-3*b)*psh*x*x-2*(a-b)**2*qsh*x*z+a*(b-3*a)*rsh*z*z
    assert s.expand(change[1,3]-wanted)==0
    assert all(change[ij]==0 for ij in pairs if ij!=(1,3))
    # A rational first-order direction, normalized by trace(R)=xy-zw.
    R=s.zeros(4)
    rv=[(2*(a+b)*x*y-3*a*z*w)/(3*a),
        2*x*z*(a-2*b)/(3*(a-b)),
        -x*w*(a-2*b)*(a+b)/(3*a*(a-b)),
        y*z*(a+b)/(3*(a-b)),
        -2*y*w*(a*a-a*b+b*b)/(3*a*(a-b)),
        x*y*(a-2*b)/(3*a)]
    for ij,val in zip(pairs,rv):R[ij]=val;R[ij[::-1]]=-val
    assert s.expand(R[0,1]+R[2,3]-(x*y-z*w))==0
    assert simplify_all(polar_symbolic(Q,R))==[0]*4
    assert simplify_all(polar_symbolic(J,R))==[0]*4
    # A universal second-order correction.  Its trace is zero.
    den=180*a*a*b*b*(a-b)**2
    T=s.zeros(4)
    tv=[-y*w*(a-2*b)*(6*a**3-a*a*b-5*a*b*b+17*b**3)/den,
        -(2*a**4*z*w+7*a**3*b*x*y-3*a**3*b*z*w+17*a*a*b*b*x*y+57*a*a*b*b*z*w-83*a*b**3*x*y-73*a*b**3*z*w+42*b**4*x*y)/den,
        w*w*(4*a**4-8*a**3*b+27*a*a*b*b-23*a*b**3-17*b**4)/den,
        y*y*(a-2*b)*(3*a**3+3*a*a*b+13*a*b*b-2*b**3)/den,
        s.Integer(0),
        y*w*(a-2*b)*(6*a**3-a*a*b-5*a*b*b+17*b**3)/den]
    for ij,val in zip(pairs,tv):T[ij]=val;T[ij[::-1]]=-val
    assert simplify_all(polar_symbolic(J,T))==[0]*4
    assert s.expand(T[0,1]+T[2,3])==0
    assert simplify_all([u+v for u,v in zip(polar_symbolic(Q,T),c.jac(R,xx))])==[0]*4
    obstruction=polar_symbolic(R,T)
    # Thus Q+eR+e^2T, and x0^2J+Q+eR+e^2T, satisfy Jacobi modulo e^3
    # universally in a,b, with the displayed nonzero denominators inverted.
    pt={a:5,b:7};Q0=Q.subs(pt)
    R0=R.subs(pt).applyfunc(s.cancel)
    rscale=int(s.ilcm(*[v.q for ij in pairs for _,v in s.Poly(R0[ij],*xx).terms()]))
    rs=c.sparse(rscale*R0,1);qs=c.sparse(Q0,1)
    obs=[s.cancel(v.subs(pt)) for v in obstruction]
    oscale=int(s.ilcm(*[v.q for f in obs for _,v in s.Poly(f,*xx).terms()]))
    obdict={I:{(0,)+mon:int(v*oscale) for mon,v in s.Poly(f,*xx).terms() if v}
            for I,f in zip(combinations(range(1,5),3),obs)}
    # Full45 compatible quadratic model: wedge pairs of Hamiltonian linear
    # fields are a basis, as verified by its coefficient rank45.
    hams=[c.hamiltonian({mon:1}) for mon in c.p.DEGREE_TWO if mon[0]==0]
    basis=[c.v.wedge_fields(A,B) for A,B in combinations(hams,2)]
    BB=np.column_stack([c.p.bivector_vector(B) for B in basis])
    assert c.rank(BB)==45
    target=[(I,mon) for I in combinations(range(1,5),3) for mon in c.p.homogeneous_monomials(3) if mon[0]==0]
    cols=[c.polar(qs,B) for B in basis]
    Dq=np.array([[col.get(I,{}).get(mon,0) for col in cols] for I,mon in target],dtype=np.int64)
    Tr=np.array([[B.get((1,2),{}).get((0,)+mon,0)+B.get((3,4),{}).get((0,)+mon,0) for B in basis] for mon in c.m.old.MON2],dtype=np.int64)
    oq=[]
    for X in hams:
        A=np.zeros((5,5),dtype=np.int64)
        for i,pol in enumerate(X):
            for mon,v in pol.items():A[i,mon.index(1)]=v
        oq.append(c.v.linear_action_derivative(qs,A))
    dqa=c.sparse(Q.diff(a).subs(pt),1);dqb=c.sparse(Q.diff(b).subs(pt),1)
    fq=oq+[dqa,dqb]
    Fq=np.column_stack([c.p.bivector_vector(B) for B in fq])
    Kq=np.column_stack([Fq,c.p.bivector_vector(rs)])
    dqrank,dqcert=exact_rank(Dq)
    fqrank,fqcert=exact_rank(Fq)
    kqrank,kqcert=exact_rank(Kq)
    zrank,zcert=exact_rank(np.vstack([Dq,Tr]))
    orbitqrank,orbitqcert=exact_rank(np.column_stack([c.p.bivector_vector(B) for B in oq]))
    assert (dqrank,fqrank,kqrank,zrank,orbitqrank)==(34,10,11,35,9)
    assert all(not c.polar(qs,B)[I] for B in fq+[rs] for I in c.p.TRIPLES)
    obsq=np.array([obdict.get(I,{}).get(mon,0) for I,mon in target],dtype=np.int64)
    brq=[c.polar(rs,B) for B in fq+[rs]]
    ambiguityq=np.array([[col.get(I,{}).get(mon,0) for col in brq] for I,mon in target],dtype=np.int64)
    aqrank,aqcert=exact_rank(np.column_stack([Dq,ambiguityq]))
    oqrank,oqcert=exact_rank(np.column_stack([Dq,ambiguityq,obsq]))
    assert (aqrank,oqrank)==(34,35)
    # FULL P4 model, with all150 quadratic coefficients.
    P=s.zeros(5)
    for i,j in pairs:P[i+1,j+1]=Q0[i,j]+c.x0*c.x0*J[i,j];P[j+1,i+1]=-P[i+1,j+1]
    assert c.jac(P,c.xx5)==[0]*10
    ps=c.sparse(P);D=c.p.linearized_jacobi_matrix(ps);Vert=c.p.vertical_bivector_matrix()
    orbit=[]
    for i in range(5):
        for j in range(5):
            A=np.zeros((5,5),dtype=np.int64);A[i,j]=1
            orbit.append(c.v.linear_action_derivative(ps,A))
    allactual=[vector_to_bivector(v) for v in Vert.T]+orbit+[ps,dqa,dqb]
    FF=np.column_stack([c.p.bivector_vector(B) for B in allactual])
    KK=np.column_stack([FF,c.p.bivector_vector(rs)])
    assert not np.any(D@KK)
    dr,dc=exact_rank(D);fr,fc=exact_rank(FF);kr,kc=exact_rank(KK)
    orbitr,orbitc=exact_rank(np.column_stack([Vert,*[c.p.bivector_vector(B) for B in orbit],c.p.bivector_vector(ps)]))
    assert (dr,fr,kr,orbitr)==(101,48,49,47)
    obp=projective_vector(obdict)
    ambiguity=np.column_stack([projective_vector(c.polar(rs,B)) for B in allactual+[rs]])
    ar,ac=exact_rank(np.column_stack([D,ambiguity]))
    obr,obc=exact_rank(np.column_stack([D,ambiguity,obp]))
    assert (ar,obr)==(101,102)
    # Universal degeneracy factor and rank: traceQ=PfQ=0 gives x0^5.
    eps=s.symbols('epsilon')
    Pf=s.expand((c.x0*c.x0+Q[0,1])*(c.x0*c.x0+Q[2,3])-Q[0,2]*Q[1,3]+Q[0,3]*Q[1,2])
    assert Pf==c.x0**4
    out={'parameters':['a','b'],'open_denominator':'a*b*(a-b) != 0',
      'universal_Q_brackets':encode_matrix(Q),'universal_R_brackets':encode_matrix(R),
      'universal_second_order_T_brackets':encode_matrix(T),
      'universal_Jacobi_through_order2_verified':True,'logarithmic_model_identity_verified':True,'symplectic_shear_identity_verified':True,'trace_R':'x1*x2-x3*x4','trace_T':'0',
      'sample':{'a':5,'b':7},'sample_R_integer_scale':rscale,'sample_obstruction_integer_scale':oscale,
      'third_order_affine_obstruction':[str(s.factor(v)) for v in obstruction],
      'quadratic':{'Jacobi_rank':dqrank,'full_tangent_dimension':45-dqrank,
        'zero_trace_tangent_dimension':45-zrank,'Sp4_orbit_dimension':orbitqrank,
        'actual_family_dimension':fqrank,'actual_family_plus_R_rank':kqrank,
        'all_second_order_choices_rank':aqrank,'with_third_obstruction_rank':oqrank,
        'all_tangent_directions_spanned':True,'ambiguity_fully_eliminated':True,
        'Jacobi_minor':dqcert,'actual_family_minor':fqcert,'kernel_span_minor':kqcert,
        'zero_trace_minor':zcert,'orbit_minor':orbitqcert,'ambiguity_minor':aqcert,'obstruction_minor':oqcert,
        'completed_local_ring':'C[[u1,...,u10,epsilon]]/(epsilon^3)'},
      'full_P4':{'Jacobi_rank':dr,'projective_tangent_dimension':125-dr,
        'vertical_orbit_scale_rank':orbitr,'projective_orbit_dimension':orbitr-25,
        'actual_family_plus_vertical_scale_rank':fr,'actual_projective_family_dimension':fr-25,
        'actual_family_plus_R_vertical_scale_rank':kr,'all_second_order_choices_rank':ar,
        'with_third_obstruction_rank':obr,'all_tangent_directions_spanned':True,
        'ambiguity_fully_eliminated':True,'Jacobi_minor':dc,'actual_family_minor':fc,
        'kernel_span_minor':kc,'orbit_minor':orbitc,'ambiguity_minor':ac,'obstruction_minor':obc,
        'completed_local_ring':'C[[u1,...,u23,epsilon]]/(epsilon^3)',
        'component_dimension':23,'projective_degeneracy':'x0^5','generic_rank':4,'universal_projective_stabilizers':['x partial_x-y partial_y-z partial_z+w partial_w','y partial_y+w partial_w'],'stabilizer_lie_actions':['0','-P'],'generic_projective_orbit_upper_bound':22},
      'logical_scope':'See zero_log_component_theorem.txt for the formal implicit-function argument. Exact universal first/second jets and a choice-independent nonzero third obstruction imply a unique reduced component and generic scheme multiplicity3. No assertion that the entire zero modular locus is exhausted.'}
    dest=Path(output_dir);dest.mkdir(parents=True,exist_ok=True)
    (dest/'zero_log_component_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'quadratic':{'tangent':45-dqrank,'family':fqrank,'obstruction_ranks':[aqrank,oqrank]},'full_P4':{'tangent':125-dr,'family':fr-25,'orbit':orbitr-25,'obstruction_ranks':[ar,obr]},'generic_transverse_ring':'C[epsilon]/(epsilon^3)'},indent=2))
if __name__=='__main__':main(sys.argv[1] if len(sys.argv)>1 else HERE)

#!/usr/bin/env python3
"""Exact reduced-fiber classification for modular Jordan type (2,2).

This reconstructs all sixty coefficients, verifies the two open charts and
fifteen closed irreducible strata, and certifies one full quadratic component
and one full projective P4 component.  No reducedness of the original closed
fiber scheme or completeness of the ambient component list is asserted.
"""
from pathlib import Path
from fractions import Fraction as F
import sys,json

HERE=Path(__file__).resolve().parent
for candidate in [HERE.parent/'p4_poisson_completeness_v5'/'code',
                  HERE.parent/'previous_v5'/'code']:
    if candidate.is_dir():
        sys.path.insert(0,str(candidate));break
else:raise RuntimeError('The preserved v5 code directory is required.')
import certify_regular_nilpotent as old
sp=old.sp

def build():
    ans=old.m.fixed_trace({(1,0,1,0):F(1)})
    Q,t,eq=old.tensor(ans)
    return ans,Q,t,eq

def encode_matrix_entries(Q):
    return {str(i+1)+str(j+1):str(sp.factor(Q[i,j])) for i,j in old.m.old.PAIRS}

def main():
    ans,Q,t,eq=build()
    assert ans['linear_rank']==49 and len(t)==11 and len(eq)==9
    a,b,p3,p4,p5,c,v,d,A,B,u=t
    expected=[-(6*B*b-c*A+5*d*A-2*A)/2,
              A*B,B*v-u*A,-(6*a*A+B*c+3*B*d-2*B)/2,
              (4*u*b-p4*A+2*c*v-4*v*d+2*v)/2,
              -4*a*b-4*B*p3-56*u*v-4*p5*A+c*c-2*c*d+c+d*d-d,
              (4*a*v-B*p4-2*u*c)/4,
              -2*a*c-2*a*d+a+4*B*p5-4*u*u,
              (2*b*c-6*b*d+3*b+4*p3*A-4*v*v)/3]
    assert all(sp.expand(x-y)==0 for x,y in zip(eq,expected))
    N=sp.Matrix([0,old.x3,0,old.x1]);Nmat=N.jacobian(old.xx)
    assert Nmat.rank()==2 and Nmat**2==sp.zeros(4)
    assert old.lie(N,Q,old.xx)==sp.zeros(4)

    # Exact localized graph on A != 0; all four coordinates (A,b,v,d) are free.
    chartA={B:0,u:0,a:0,c:5*d-2,
            p3:(4*v*v-(4*d-1)*b)/(4*A),
            p4:2*v*(3*d-1)/A,
            p5:(4*d-2)*(4*d-1)/(4*A)}
    assert all(sp.cancel(e.subs(chartA,simultaneous=True))==0 for e in eq)
    qa=Q.subs(chartA,simultaneous=True).applyfunc(sp.factor)
    assert old.jac(qa,old.xx)==[0]*4
    assert old.jac(qa+old.J,old.xx)==[0]*4

    # The nonidentity component of the centralizer interchanges the two charts.
    S=sp.Matrix([[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]])
    swap={a:-b,b:-a,p3:-p5,p4:-p4,p5:-p3,c:c-2*d+1,
          v:-u,d:1-d,A:-B,B:-A,u:-v}
    assert S*old.J*S.T==old.J and S*Nmat==Nmat*S
    assert (old.push(Q,S)-Q.subs(swap,simultaneous=True)).applyfunc(sp.expand)==sp.zeros(4)

    # The exact closed equations for A=B=0 have three independent free
    # coordinates p3,p4,p5 and these five equations on a,b,u,v,c,d.
    core=[2*u*b+v*(c-2*d+1),
          -4*a*b-56*u*v+(c-d)*(c-d+1),
          2*a*v-u*c,
          a*(1-2*c-2*d)-4*u*u,
          b*(2*c-6*d+3)-4*v*v]
    reduced=[sp.factor(e.subs({A:0,B:0})) for e in eq]
    assert reduced[:4]==[0]*4
    assert sp.expand(reduced[4]-core[0])==0
    assert sp.expand(reduced[5]-core[1])==0
    assert sp.expand(2*reduced[6]-core[2])==0
    assert sp.expand(reduced[7]-core[3])==0
    assert sp.expand(3*reduced[8]-core[4])==0

    lam=sp.symbols('lambda',nonzero=True)
    R=sp.Rational
    branches={};branch_subs={}
    def branch(name,aa,bb,uu,vv,cc,dd,domain='A1'):
        sub={a:aa,b:bb,u:uu,v:vv,c:cc,d:dd,A:0,B:0}
        assert all(sp.simplify(e.subs(sub,simultaneous=True))==0 for e in eq),name
        branch_subs[name]=sub
        branches[name]={'domain':domain,'coordinates':{str(k):str(z) for k,z in sub.items()}}
    for sg,name in [(1,'C_plus'),(-1,'C_minus')]:
        cc=sg*R(1,8);dd=R(1,2);vv=-1/(256*lam)
        branch(name,lam*cc/(2*vv),-vv*cc/(2*lam),lam,vv,cc,dd,'Gm')
    for sg,name in [(1,'D_plus'),(-1,'D_minus')]:
        cc=sg*sp.sqrt(3)/18;dd=R(1,2)+cc;vv=-1/(216*lam)
        branch(name,lam*cc/(2*vv),vv*cc/(2*lam),lam,vv,cc,dd,'Gm')
    branch('U0',4*lam**2,0,lam,0,0,0)
    branch('U1',-4*lam**2,0,lam,0,0,1)
    branch('V0',0,4*lam**2,0,lam,-1,0)
    branch('V1',0,-4*lam**2,0,lam,1,1)
    branch('L0',0,0,0,0,lam,lam)
    branch('L1',0,0,0,0,lam-1,lam)
    branch('A0',lam,0,0,0,R(1,4),R(1,4))
    branch('A1',lam,0,0,0,-R(1,4),R(3,4))
    branch('B0',0,lam,0,0,R(3,4),R(3,4))
    branch('B1',0,lam,0,0,-R(3,4),R(1,4))
    branch('AB',lam,-1/(16*lam),0,0,0,R(1,2),'Gm')
    assert len(branches)==15
    targets={'C_plus':'C_plus','C_minus':'C_minus','D_plus':'D_minus','D_minus':'D_plus',
             'U0':'V1','V1':'U0','U1':'V0','V0':'U1','L0':'L0','L1':'L1',
             'A0':'B0','B0':'A0','A1':'B1','B1':'A1','AB':'AB'}
    coordinate_of_lambda={name:(u if name.startswith(('C_','D_','U')) else
                               v if name.startswith('V') else
                               d if name.startswith('L') else
                               b if name.startswith('B') else a)
                          for name in branches}
    for name,target in targets.items():
        transformed={k:sp.sympify(swap[k]).subs(branch_subs[name],simultaneous=True)
                     for k in [a,b,u,v,c,d,A,B]}
        next_lambda=transformed[coordinate_of_lambda[target]]
        expected_sub={k:sp.sympify(z).subs(lam,next_lambda) for k,z in branch_subs[target].items()}
        assert all(sp.simplify(transformed[k]-expected_sub[k])==0 for k in transformed),(name,target)

    # Exhaustion when u*v != 0: eliminate a,b from two equations.
    elim={a:u*c/(2*v),b:-v*(c-2*d+1)/(2*u)}
    e3=sp.factor(core[3].subs(elim,simultaneous=True)*2*v/u)
    e4=sp.factor(core[4].subs(elim,simultaneous=True)*(-2*u/v))
    assert sp.expand(e3-(c*(1-2*c-2*d)-8*u*v))==0
    assert sp.expand(e4-((c-2*d+1)*(2*c-6*d+3)+8*u*v))==0
    f=sp.factor(e3+e4)
    assert sp.expand(f+3*(2*d-1)*(2*c-2*d+1))==0
    g=sp.factor(core[1].subs(elim,simultaneous=True).subs(u*v,c*(1-2*c-2*d)/8))
    assert sp.expand(g-(16*c*c+10*c*d-5*c+d*d-d))==0
    assert sp.expand(g.subs(d,R(1,2))-16*c*c+R(1,4))==0
    assert sp.expand(g.subs(d,c+R(1,2))-27*c*c+R(1,4))==0
    # Exhaustion for the two one-sided cases and for u=v=0 is elementary:
    # the exact factors below give all 2+2+7 remaining curves.
    assert sp.factor(core[1].subs({u:0,a:0,c:2*d-1}))==d*(d-1)
    assert sp.factor(core[1].subs({v:0,b:0,c:0}))==d*(d-1)
    uv_zero=[0,-4*a*b+c*c-2*c*d+c+d*d-d,0,a*(1-2*c-2*d),b*(2*c-6*d+3)]
    assert all(sp.expand(e.subs({u:0,v:0})-z)==0 for e,z in zip(core,uv_zero))

    # Explicit simple generic point of chart A. The 4 factor clears the
    # point and family-derivative denominators without changing dimensions.
    at={A:1,b:0,v:1,d:0}
    q=qa.subs(at).applyfunc(sp.expand)
    point=4*q
    qc=old.quadratic_certificate(point)
    assert (qc['tangent_dimension'],qc['Sp4_orbit_dimension'])==(10,9)
    hams=[old.hamiltonian({mon:1}) for mon in old.p.DEGREE_TWO if mon[0]==0]
    qs=old.sparse(point,1);orbit=[];tracecols=[]
    for X in hams:
        mat=old.np.zeros((5,5),dtype=old.np.int64)
        for i,poly in enumerate(X):
            for mon,z in poly.items():mat[i,mon.index(1)]=z
        derivative=old.v.linear_action_derivative(qs,mat)
        orbit.append(old.p.bivector_vector(derivative))
        tracecols.append([derivative.get((1,2),{}).get(mon,0)+derivative.get((3,4),{}).get(mon,0)
                          for mon in old.p.DEGREE_TWO])
    family=[]
    for par in [A,b,v,d]:
        rr=(4*qa.diff(par)).subs(at).applyfunc(sp.expand)
        rs=old.sparse(rr,1)
        assert all(not poly for poly in old.polar(qs,rs).values())
        family.append(old.p.bivector_vector(rs))
    famrank,famcert=old.rank_cert(old.np.column_stack(orbit+family))
    tracerank=old.rank(old.np.column_stack(tracecols))
    assert famrank==10 and tracerank==6

    # Full projective ambient component, using all150 quadratic coefficients.
    P=sp.zeros(5)
    for i,j in old.m.old.PAIRS:
        P[i+1,j+1]=old.x0**2*old.J[i,j]+q[i,j]
        P[j+1,i+1]=-P[i+1,j+1]
    assert old.jac(P,old.xx5)==[0]*10
    ps=old.sparse(2*P)
    JD=old.p.linearized_jacobi_matrix(ps);VV=old.p.vertical_bivector_matrix()
    oo=[]
    for i in range(5):
        for j in range(5):
            mm=old.np.zeros((5,5),dtype=old.np.int64);mm[i,j]=1
            oo.append(old.p.bivector_vector(old.v.linear_action_derivative(ps,mm)))
    MM=old.np.column_stack([VV,*oo,old.p.bivector_vector(ps)])
    assert not old.np.any(JD@MM)
    jr,jcert=old.rank_cert(JD);vr,vcert=old.rank_cert(VV);mr,mcert=old.rank_cert(MM)
    assert (jr,vr,mr)==(102,24,48)
    quartic=sp.factor(P[1,2]*P[3,4]-P[1,3]*P[2,4]+P[1,4]*P[2,3])
    x0,x1,x2,x3,x4=old.xx5
    quartic_expected=x0**4+x0**2*x1*x3+x1**3*x2-x1**3*x3+x1**2*x3**2/2-x1**2*x3*x4
    assert sp.expand(quartic-quartic_expected)==0
    assert all(mon[0]+mon[1]>=2 for mon,_ in sp.Poly(quartic,*old.xx5).terms())
    assert all(mon[0]+mon[1]>=3 for mon,_ in sp.Poly(x0*quartic,*old.xx5).terms())
    assert sp.Poly(quartic,x2).degree()==1
    assert sp.gcd(sp.diff(quartic,x2),quartic.subs(x2,0))==1
    N5=sp.Matrix([0,*N]);div=sp.Matrix([sum(sp.diff(P[i,j],old.xx5[i]) for i in range(5)) for j in range(5)])
    assert div==N5
    Pi=P-sp.Rational(1,5)*old.wedge(old.xx5,N5)
    assert (Pi.T*sp.Matrix([1,0,0,0,0])+x0*N5/5).applyfunc(sp.expand)==sp.zeros(5,1)
    assert (Pi.T*sp.Matrix([sp.diff(quartic,z) for z in old.xx5])-quartic*N5/5).applyfunc(sp.expand)==sp.zeros(5,1)
    assert old.lie(N5,P,old.xx5)==sp.zeros(5)

    out={
        'trace':'x1*x3','modular_field':'x3 partial_2+x1 partial_4',
        'modular_Jordan_type':[2,2],
        'fixed_trace_linear_rank':49,'free_parameter_count':11,
        'normal_form_brackets':encode_matrix_entries(Q),
        'Jacobi_generators':[str(sp.factor(e)) for e in eq],
        'coordinates':{'a':'t1','b':'t2','p3':'t3','p4':'t4','p5':'t5','c':'t6','v':'t7','d':'t8','A':'t9','B':'t10','u':'t11'},
        'open_A_chart':{str(k):str(z) for k,z in chartA.items()},
        'open_A_parameters':['A != 0','b','v','d'],
        'centralizer_swap':{str(k):str(z) for k,z in swap.items()},
        'closed_fiber_equations':[str(sp.factor(e)) for e in core],
        'closed_fiber_free_coordinates':['t3','t4','t5'],
        'closed_fiber_irreducible_curves':branches,
        'closed_uv_nonzero_exhaustion_factors':[str(f),str(g)],
        'reduced_fixed_fiber_component_count':17,
        'reduced_fixed_fiber_component_dimensions':[4]*17,
        'centralizer_component_permutation':[['openA','openB'],['C_plus'],['C_minus'],['D_plus','D_minus'],['U0','V1'],['U1','V0'],['L0'],['L1'],['A0','B0'],['A1','B1'],['AB']],
        'Sp4_saturation_component_count_over_modular_orbit':11,
        'Sp4_saturation_dimensions':[10]*11,
        'new_full_quadratic_component':{
            'fixed_fiber_branches':['openA','openB'],
            'point_brackets':encode_matrix_entries(q),
            'exact_quadratic_certificate_for_four_times_point':qc,
            'trace_orbit_dimension':tracerank,
            'actual_family_plus_orbit_rank':famrank,
            'actual_family_minor':famcert,
            'full_quadratic_component_dimension':10,
            'distinction':'Nilpotent trace excludes all ten nonnilpotent-meeting components; dimension10 differs from regular-nilpotent9 and minimal-nilpotent13.'},
        'new_full_P4_component':{
            'representative':'P=x0^2 J+Q, Q as point_brackets above',
            'all_affine_Jacobi_coefficients_zero':True,
            'quartic_Pfaffian':str(quartic),
            'projective_degeneracy':'x0 times the quartic Pfaffian',
            'quartic_irreducibility':'Primitive degree-one polynomial in x2; coefficient x1^3 and constant term have gcd1.',
            'D_in_plane_ideal_cube':True,
            'plane':'x0=x1=0',
            'Jacobi_rank':jr,'vertical_rank':vr,'vertical_orbit_scale_rank':mr,
            'Jacobi_times_vertical_orbit_scale_zero':True,
            'Jacobi_minor':jcert,'vertical_minor':vcert,'orbit_minor':mcert,
            'projective_tangent_dimension':23,'projective_orbit_dimension':23,
            'component_dimension':23,'generic_projective_stabilizer_lie_algebra':'C*(x3 partial_2+x1 partial_4)',
            'canonical_representative':'Pi=P-(1/5)E wedge N',
            'cofactor_x0':'-(1/5)N','cofactor_quartic':'(1/5)N',
            'distinction_from_prior_48':'The closed condition of order>=3 vanishing along some projective plane excludes SNC; rank4 excludes the six rank2 components; dimension23 excludes both prior22D additions.'},
        'scope':'Reduced fixed-fiber component classification, eleven saturations over the (2,2) orbit, one new full45 component, one new fullP4 component. Other ten saturation closures are not identified here as ambient components or boundaries.'}
    dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE
    dest.mkdir(parents=True,exist_ok=True)
    (dest/'nilpotent22_certificate.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'fixed_fiber_components':17,'fixed_fiber_component_dimensions':[4]*17,
                      'saturations_over_orbit':11,'new_full_quadratic_component':10,
                      'new_full_P4_component':23,'P4_ranks':[jr,vr,mr]},indent=2))

if __name__=='__main__':main()

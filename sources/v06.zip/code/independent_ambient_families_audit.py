#!/usr/bin/env python3
"""Helper-free independent audit of the two universal28D P4 families.

Only Python's standard library and SymPy are imported.  The full projective
Jacobi linearization is independently assembled from monomial dictionaries.
Ranks use SymPy DomainMatrix over QQ, not any historical Poisson/rank helper.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from collections import defaultdict
import sys,json,hashlib
import sympy as sp
from sympy.polys.matrices import DomainMatrix

HERE=Path(__file__).resolve().parent
xs=sp.symbols('x0 x y z w');x0,x,y,z,w=xs
pairs=list(combinations(range(5),2));triples=list(combinations(range(5),3))
quads=list(combinations(range(5),4))

def mons(n):
    result=[]
    for factors in combinations_with_replacement(range(5),n):
        ex=[0]*5
        for i in factors:ex[i]+=1
        result.append(tuple(ex))
    return result

m2=mons(2);m4=mons(4)
basis=[(ij,m) for ij in pairs for m in m2]
outbasis=[(ij,m) for ij in quads for m in m4]
bindex={q:i for i,q in enumerate(basis)};oindex={q:i for i,q in enumerate(outbasis)}

def pol(expr):return {m:sp.Rational(a) for m,a in sp.Poly(expr,*xs).terms() if a}
def tensor(entries):return {ij:pol(expr) for ij,expr in entries.items() if expr!=0}
def entry(P,i,j):
    if i==j:return {}
    if i<j:return P.get((i,j),{})
    return {m:-a for m,a in P.get((j,i),{}).items()}
def dx(f,i):
    ans={}
    for m,a in f.items():
        if m[i]:
            n=list(m);n[i]-=1;ans[tuple(n)]=a*m[i]
    return ans
def times(f,g):
    ans=defaultdict(int)
    for m,a in f.items():
        for n,b in g.items():ans[tuple(i+j for i,j in zip(m,n))]+=a*b
    return {m:a for m,a in ans.items() if a}
def plus(dest,src,scale=1):
    for m,a in src.items():dest[m]+=scale*a
def multiply_coordinate(f,j):
    ans={}
    for m,a in f.items():
        n=list(m);n[j]+=1;ans[tuple(n)]=a
    return ans
def vector(P):
    return sp.SparseMatrix(150,1,{(bindex[ij,m],0):a for ij,f in P.items() for m,a in f.items() if a})

def jacobi_linearization(P):
    data={}
    for col,(ij,m) in enumerate(basis):
        R={ij:{m:sp.S.One}}
        for tri in triples:
            jac=defaultdict(int)
            for i,j,k in [tri,(tri[1],tri[2],tri[0]),(tri[2],tri[0],tri[1])]:
                for ell in range(5):
                    plus(jac,times(entry(P,i,ell),dx(entry(R,j,k),ell)))
                    plus(jac,times(entry(R,i,ell),dx(entry(P,j,k),ell)))
            for ell in range(5):
                if ell in tri:continue
                # Put ell followed by the ordered triple into increasing order.
                sg=(-1)**sum(i<ell for i in tri)
                inds=tuple(sorted((ell,)+tri))
                for mon,a in jac.items():
                    if not a:continue
                    ex=list(mon);ex[ell]+=1;row=oindex[inds,tuple(ex)]
                    data[row,col]=data.get((row,col),0)+sg*a
    return sp.SparseMatrix(350,150,{key:a for key,a in data.items() if a})

def vertical(i,j):
    out={}
    for a,b in pairs:
        expr=(xs[a]*xs[j] if b==i else 0)-(xs[b]*xs[j] if a==i else 0)
        if expr!=0:out[a,b]=pol(expr)
    return out
def infinitesimal_action(P,i,j):
    out={}
    for a,b in pairs:
        f=defaultdict(int,multiply_coordinate(dx(entry(P,a,b),i),j))
        if a==i:plus(f,entry(P,j,b),-1)
        if b==i:plus(f,entry(P,a,j),-1)
        out[a,b]={m:c for m,c in f.items() if c}
    return out

def rank(M):
    dm=DomainMatrix.from_Matrix(M).convert_to(sp.QQ)
    rr,piv=dm.rref()
    return len(piv),list(piv)

def universal(kind,f,h):
    yy=-sp.diff(h,w);ww=sp.diff(h,z)
    if kind=='B':yy-=sp.diff(f,x)*z/2;ww-=sp.diff(f,x)*w/2
    Q=sp.zeros(5)
    for ij,val in {(1,2):f,(2,3):yy,(2,4):ww,(3,4):(x0*x0 if kind=='A' else f)}.items():
        i,j=ij;Q[i,j]=val;Q[j,i]=-val
    return Q

def symbolic_jacobi(P):
    return [sp.expand(sum(P[i,l]*sp.diff(P[j,k],xs[l])+P[j,l]*sp.diff(P[k,i],xs[l])+P[k,l]*sp.diff(P[i,j],xs[l]) for l in range(5))) for i,j,k in triples]

def lie(X,P):
    diff=X.jacobian(xs)
    return (P.applyfunc(lambda a:sum(X[i]*sp.diff(a,xs[i]) for i in range(5)))-diff*P-P*diff.T).applyfunc(sp.expand)

def main():
    # Independent order of the16 cubic directions, from exponent enumeration.
    hmons=[sp.prod(xs[i] for i in choices) for choices in combinations_with_replacement([0,1,3,4],3) if any(i in (3,4) for i in choices)]
    fmons=[x*x,x0*x,x0*x0]
    assert len(hmons)==16
    aa=sp.symbols('a0:3');bb=sp.symbols('b0:16')
    f=sum(a*m for a,m in zip(aa,fmons));h=sum(b*m for b,m in zip(bb,hmons))
    V=sp.SparseMatrix.hstack(*[vector(vertical(i,j)) for i in range(5) for j in range(5)])
    vr,vp=rank(V);assert vr==24
    report={}
    for kind in ['A','B']:
        U=universal(kind,f,h)
        assert symbolic_jacobi(U)==[0]*10
        pf=sp.expand(U[1,2]*U[3,4]-U[1,3]*U[2,4]+U[1,4]*U[2,3])
        assert sp.expand(pf-(x0*x0*f if kind=='A' else f*f))==0
        div=sp.Matrix([sum(sp.diff(U[i,j],xs[i]) for i in range(5)) for j in range(5)])
        expected=sp.Matrix([0,0,(1 if kind=='A' else 2)*sp.diff(f,x),0,0])
        assert div==expected
        for coeff in [x0,x]:assert lie(sp.Matrix([0,0,coeff,0,0]),U)==sp.zeros(5)
        P=universal(kind,x0*x0+x*x,x*z*w+z**3+w**3)
        assert symbolic_jacobi(P)==[0]*10
        pp=tensor({ij:P[ij] for ij in pairs})
        J=jacobi_linearization(pp)
        O=sp.SparseMatrix.hstack(*[vector(infinitesimal_action(pp,i,j)) for i in range(5) for j in range(5)])
        M=sp.SparseMatrix.hstack(V,O,vector(pp))
        # Family directions independently constructed from basis polynomials.
        variations=[]
        for m in fmons:
            entries={(1,2):m}
            if kind=='B':entries.update({(3,4):m,(2,3):-sp.diff(m,x)*z/2,(2,4):-sp.diff(m,x)*w/2})
            variations.append(vector(tensor(entries)))
        for m in hmons:variations.append(vector(tensor({(2,3):-sp.diff(m,w),(2,4):sp.diff(m,z)})))
        R=sp.SparseMatrix.hstack(*variations)
        fr=sp.SparseMatrix.hstack(M,R)
        assert J*fr==sp.zeros(350,fr.cols)
        rr,rp=rank(R);jr,jp=rank(J);mr,mp=rank(M);ar,ap=rank(fr)
        assert (rr,jr,vr,mr,ar)==(19,97,24,47,53)
        sample_pf=sp.factor(P[1,2]*P[3,4]-P[1,3]*P[2,4]+P[1,4]*P[2,3])
        report[kind]={
            'implementation':'Independent monomial dictionaries; no historical Poisson helper imported.',
            'universal_parameter_count':19,'universal_Jacobi':True,
            'universal_Pfaffian':str(sp.factor(pf)),
            'universal_stabilizers_verified':['x0 partial_y','x partial_y'],
            'universal_divergence':str(div[2])+' partial_y',
            'sample_f':'x0^2+x^2','sample_h':'x*z*w+z^3+w^3',
            'sample_Pfaffian':str(sample_pf),
            'full_Jacobi_shape':list(J.shape),
            'rank_actual19_family':rr,'rank_full_Jacobi':jr,'rank_vertical':vr,
            'rank_vertical_orbit_scale':mr,'rank_vertical_orbit_scale_family':ar,
            'exact_Jacobi_times_actual_directions_zero':True,
            'projective_tangent':125-jr,'projective_actual_family':ar-vr-1,
            'projective_orbit':mr-vr-1,'generic_stabilizer_dimension':2,
            'generic_rational_quotient_dimension':6,
            'exact_rational_pivot_columns':{'Jacobi':jp,'vertical':vp,'orbit_scale_vertical':mp,'actual_family':ap,'parameters':rp}}
        print(kind,'ranks',[jr,vr,mr,ar],flush=True)
    report['geometric_audit']={
        'irreducible_image_closures_are_components':'PGL5 times the affine19 parameter space has irreducible image. Its derivative has projective rank28 at the witness, equal to the full tangent dimension; the point is smooth and its unique component equals the image closure.',
        'generic_orbit_and_quotient':'The two independent stabilizer fields exist on the entire family; after conjugation they bound every orbit in the image by22. Equality at the witness proves generic orbit22 and Rosenlicht quotient transcendence degree28-22=6.',
        'SNC_distinction':'A satisfies the closed projective factorization condition L^3 q; B satisfies L q^2. Neither can contain a reduced SNC degeneracy divisor on the rank4 open set.',
        'A_B_distinction':'At f=x0^2+x^2, the three distinct hyperplanes in B have multiplicities1,2,2, so B is outside the closed L^3 q condition that contains A.',
        'prior_components':'Generic rank4 excludes six rank2 components; dimension28 excludes the preceding22D components and the independently found23D component.',
        'verdict':'PASS; no correction required.'}
    dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE
    dest.mkdir(parents=True,exist_ok=True)
    (dest/'independent_ambient_families_audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    print('PASS: two distinct full28D components; generic orbits22; rational quotient dimensions6.')

if __name__=='__main__':main()

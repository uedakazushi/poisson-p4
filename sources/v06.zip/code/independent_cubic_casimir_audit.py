#!/usr/bin/env python3
"""Independent full-space and exceptional-case audit of cubic Casimirs.

Imports no project helper.  All150 coefficients are tested against the full
375-row central/divergence target.  Exceptional Pfaffian consequences are
proved by rational coefficient spans and an explicit degree-three identity,
without repeating the original Groebner-basis computation.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
import sys,json
import sympy as s
from sympy.polys.matrices import DomainMatrix

HERE=Path(__file__).resolve().parent
X=s.symbols('x y z u v');x,y,z,u,v=X
PAIRS=list(combinations(range(5),2))
def exponents(degree):
    ans=[]
    for seq in combinations_with_replacement(range(5),degree):
        ans.append(tuple(seq.count(i) for i in range(5)))
    return ans
M2=exponents(2);M4=exponents(4);M1=exponents(1)
BASIS=[(ij,m) for ij in PAIRS for m in M2]
TARGET=[('central',j,m) for j in range(5) for m in M4]+[('divergence',j,m) for j in range(5) for m in M1]
INDEX={l:i for i,l in enumerate(TARGET)}

def mon(m):return s.prod(t**e for t,e in zip(X,m))
def vector(P):return s.Matrix([s.Poly(P[i,j],*X).coeff_monomial(m) for (i,j),m in BASIS])
def tensor(vec):
    out=s.zeros(5)
    for val,((i,j),m) in zip(vec,BASIS):out[i,j]+=val*mon(m);out[j,i]-=val*mon(m)
    return out
def skew(d):
    P=s.zeros(5)
    for (i,j),a in d.items():P[i,j]=a;P[j,i]=-a
    return P
def parity(seq):return (-1)**sum(seq[i]>seq[j] for i in range(5) for j in range(i+1,5))

def constraints(F):
    gradients=[dict(s.Poly(s.diff(F,q),*X).terms()) for q in X]
    data={}
    for col,((i,j),m) in enumerate(BASIS):
        for direction,output,sg in [(i,j,1),(j,i,-1)]:
            for n,c in gradients[direction].items():
                if c==0:continue
                key=(INDEX['central',output,tuple(a+b for a,b in zip(m,n))],col)
                data[key]=data.get(key,0)+sg*c
            if m[direction]:
                n=list(m);n[direction]-=1
                key=(INDEX['divergence',output,tuple(n)],col)
                data[key]=data.get(key,0)+sg*m[direction]
    return s.SparseMatrix(375,150,{k:c for k,c in data.items() if c!=0})

def jacobian(F):
    out=[]
    for i,j in PAIRS:
        Q=s.zeros(5)
        for k in range(5):
            if k in (i,j):continue
            a,b=sorted(set(range(5))-{i,j,k})
            val=parity([a,b,k,i,j])*s.diff(F,X[k])
            Q[a,b]+=val;Q[b,a]-=val
        out.append(vector(Q))
    return s.SparseMatrix.hstack(*out)

def rank(M):return DomainMatrix.from_Matrix(M).convert_to(s.QQ).rank()
def pfaffians(P):
    ans=[]
    for i,j,k,l in combinations(range(5),4):
        f=s.expand(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])
        ans.extend(c for c in s.Poly(f,*X).coeffs() if c!=0)
    return list(dict.fromkeys(ans))
def span_contains(equations,targets,variables):
    polys=[s.Poly(e,*variables) for e in equations+targets]
    mons=sorted(set(m for p in polys for m in p.monoms()))
    mat=s.Matrix([[p.coeff_monomial(m) for m in mons] for p in polys])
    before=rank(mat[:-len(targets),:]);after=rank(mat)
    assert before==after
    return {'coefficient_span_rank':before,'augmented_rank':after,'targets':[str(q) for q in targets]}
def row_equations(P,i):return [c for j in range(5) for c in s.Poly(s.expand(P[i,j]),*X).coeffs() if c!=0]

CASES={
 'chordal':(x*u*u+y*y*v-x*z*v-2*y*z*u+z**3,140),
 'conic_nonisotropic':(v*(x*y+z*z)+z*u*u,140),
 'conic_isotropic':(v*(x*y+z*z)+x*u*u,140),
 'conic_A2':(v*(x*y+z*z)+u**3,139),
 'regular_distinct':(u*(x*x+y*y+z*z)+v*(x*x+2*y*y+3*z*z),140),
 'regular_repeated':(u*x*y+v*z*z,140),
 'regular_J2_distinct':(u*(2*x*y+z*z)+v*(y*y+z*z),140),
 'regular_J3':(u*(2*x*z+y*y)+2*v*y*z,140),
 'regular_J2_same':(u*(2*x*y+z*z)+v*y*y,140),
 'two_squares_z3':(u*x*x+v*y*y+z**3,140),
 'two_squares_one_z2':(u*x*x+v*y*y+x*z*z,140),
 'two_squares_both_z2':(u*x*x+v*y*y+(x+y)*z*z,140),
 'square_product_z3_y3':(u*x*x+v*x*y+z**3+y**3,140),
 'square_product_yz2':(u*x*x+v*x*y+y*z*z,140),
 'square_product_y2z_xz2':(u*x*x+v*x*y+y*y*z+x*z*z,140),
 'square_product_z3':(u*x*x+v*x*y+z**3,139),
 'square_product_y3_xz2':(u*x*x+v*x*y+y**3+x*z*z,139),
 'common_factor_three_roots':(x*(u*y+v*z)+y**3+z**3,140),
 'common_factor_double_root':(x*(u*y+v*z)+y*y*z,140),
 'common_factor_triple_root':(x*(u*y+v*z)+y**3,139)}

def main():
    report={'finite_models':{}}
    for name,(F,expected) in CASES.items():
        M=constraints(F);J=jacobian(F)
        rr=rank(M);assert rr==expected and rank(J)==10 and M*J==s.zeros(375,10)
        report['finite_models'][name]={'full_matrix_shape':[375,150],'rank_over_Q':rr,'kernel_dimension':150-rr,'Jacobian_image_dimension':10}
    print('Twenty independent full150 rank calculations passed.',flush=True)

    # Check the isotrivial weighted degenerations, with every possible extra
    # monomial rather than just one chosen cubic remainder.
    def weighted(name,base,extra,weights):
        bw={sum(i*j for i,j in zip(m,weights)) for m,c in s.Poly(base,*X).terms() if c!=0}
        assert len(bw)==1;degree=next(iter(bw))
        ew=[sum(i*j for i,j in zip(s.Poly(q,*X).monoms()[0],weights)) for q in extra]
        assert all(t>degree for t in ew)
        return {'name':name,'weights':weights,'base_weight':degree,'remainder_weights':ew}
    xyz_cubics=[mon(m) for m in exponents(3) if m[3]==m[4]==0]
    weights=[weighted('regular_pencils',CASES['regular_distinct'][0],xyz_cubics,[1,1,1,0,0]),
             weighted('conic_l_nonzero',CASES['conic_nonisotropic'][0],[u**3,u*u*v,u*v*v,v**3],[0,0,0,1,2]),
             weighted('conic_l_zero',CASES['conic_A2'][0],[u*u*v,u*v*v,v**3],[0,0,0,1,3]),
             weighted('two_squares',CASES['two_squares_z3'][0],[x*y*z],[3,3,2,0,0]),
             weighted('square_product_yz2',CASES['square_product_yz2'][0],[y**3],[2,2,1,0,0]),
             weighted('common_factor',CASES['common_factor_triple_root'][0],[x**3],[2,1,1,0,0])]
    report['weighted_degenerations']=weights

    # The singular-pencil equations and the discriminant-zero alternative line.
    aa,bb,cc,dd,ee,ff,t=s.symbols('aa bb cc dd ee ff t')
    pencil=x*y+t*(aa*x*x+bb*x*y+cc*y*y+dd*x*z+ee*y*z+ff*z*z)
    determinant=s.expand((s.hessian(pencil,(x,y,z))/2).det())
    assert s.expand(determinant).coeff(t,1)==-ff/4
    rem=s.expand(determinant.subs(ff,0))
    assert s.expand(rem.coeff(t,2)-dd*ee/4)==0
    assert s.expand(rem.coeff(t,3)-(-aa*ee*ee+bb*dd*ee-cc*dd*dd)/4)==0
    k=s.symbols('k',nonzero=True)
    double=u*x*x+v*x*y+z*z*(z+k*y)
    assert all(s.diff(double,q).subs({x:0,z:0,v:0})==0 for q in X)
    regular_member=s.hessian(x*v+k*z*z,(x,v,z))/2
    assert s.factor(regular_member.det())==-k/4
    report['pencil_special_cases']={'singular_pencil_determinant':str(s.factor(determinant)),
        'discriminant_zero_other_line':'x=z=v=0',
        'other_line_regular_member':'x*v+k*z^2','regular_member_determinant':'-k/4'}

    # A new full140 minor, selected in this independent row ordering.
    A=s.symbols('A')
    parametric=u*x*x+v*x*y+z**3+y*y*z+A*y**3
    PM=constraints(parametric);P0=PM.subs(A,0)
    _,cols=DomainMatrix.from_Matrix(P0).convert_to(s.QQ).rref()
    _,rows=DomainMatrix.from_Matrix(P0[:,list(cols)].T).convert_to(s.QQ).rref()
    minor=PM.extract(rows,cols)
    ring=s.QQ.poly_ring(A)
    det=ring.to_sympy(DomainMatrix.from_Matrix(minor).convert_to(ring).det())
    det=s.factor(det)
    ratio=s.cancel(det/(27*A*A+4)**3)
    assert ratio.is_Rational and ratio!=0
    report['independent_parametric_minor']={'rows':list(rows),'columns':list(cols),
        'determinant':str(det),'discriminant_power':3,'constant_ratio':str(ratio)}
    print('Weights, singular pencils, double-root line, and parametric minor passed.',flush=True)

    a=s.symbols('a0:10');p,q,r,h=s.symbols('p q r h')
    Bq=skew({(0,1):2*z,(0,2):-x,(1,2):y})
    extra_cases=[
      ('conic',v*(x*y+z*z)+u**3+p*u*u*v+q*u*v*v+r*v**3,u*Bq,
       [a[0],a[1],a[4]],(p,q,r),3,v,{a[3]:0,a[6]:0,a[8]:0},4,v,{a[2]:0,a[5]:0,a[7]:0},(a[9]*v+u)*Bq),
      ('E1',CASES['square_product_z3'][0],skew({(1,3):y*z,(1,4):-x*z,(3,4):v*z}),
       [a[5],a[6],a[9]],(),0,x,{a[4]:0,a[7]:0,a[8]:0},2,x,{a[0]:0,a[2]:0,a[3]:0},
       (z-a[1]*x)*skew({(1,3):y,(1,4):-x,(3,4):v})),
      ('E2',CASES['square_product_y3_xz2'][0],skew({(1,2):-x*x/6,(1,3):x*z/3,(2,3):-v*x/6,(2,4):-x*y/2,(3,4):y*z}),
       [a[7],a[9]],(),0,x,{a[4]:0,a[5]:0,a[6]:0},1,x,{a[1]:0,a[2]:0,a[3]:-s.Rational(1,6)},
       (a[0]*x+y/2)*skew({(2,3):y,(2,4):-x,(3,4):2*z})),
      ('E3',x*(u*y+v*z)+y**3+h*x**3,skew({(1,2):x*z/3,(1,4):-v*x/3,(2,3):y*z,(2,4):u*x/3,(3,4):v*y}),
       [a[7],a[8],a[9]],(h,),0,x,{a[4]:0,a[5]:0,a[6]:0},1,x,{a[1]:0,a[2]:-s.Rational(1,3),a[3]:0},
       (a[0]*x+y)*skew({(2,3):z,(2,4):-y,(3,4):v}))]
    report['exceptional_cases']={}
    for name,F,Q,targets,params,row1,div1,sub1,row2,div2,sub2,expected in extra_cases:
        M=constraints(F);J=jacobian(F);B=J.row_join(vector(Q))
        assert M*B==s.zeros(375,11)
        B0=B.subs({q:0 for q in params})
        _,rows=DomainMatrix.from_Matrix(B0.T).convert_to(s.QQ).rref()
        assert len(rows)==11
        minor=s.factor(B.extract(rows,range(11)).det())
        assert minor.is_Rational and minor!=0  # Uniform over EVERY parameter.
        P=tensor(J*s.Matrix(a))+Q
        eq=pfaffians(P);variables=(*a,*params)
        sc=span_contains(eq,targets,variables)
        sub={z:0 for z in targets}
        square_cert=None
        if name=='E2':
            rr=[a[8]+2*a[1]*a[5]-2*a[2]*a[4],a[5]*a[8],a[2]*a[8]]
            square_cert=span_contains([e.subs(sub) for e in eq],rr,variables)
            assert s.expand(a[8]*rr[0]-2*a[1]*rr[1]+2*a[4]*rr[2]-a[8]**2)==0
            sub[a[8]]=0
        P1=P.subs(sub)
        assert all(s.expand(P1[row1,j]).subs(div1,0)==0 for j in range(5))
        first_span=span_contains(row_equations(P1,row1),[z-c for z,c in sub1.items()],variables)
        P2=P1.subs(sub1)
        assert all(s.expand(P2[row1,j])==0 for j in range(5))
        assert all(s.expand(P2[row2,j]).subs(div2,0)==0 for j in range(5))
        second_span=span_contains(row_equations(P2,row2),[z-c for z,c in sub2.items()],variables)
        P3=P2.subs(sub2).applyfunc(s.expand)
        assert all(P3[row2,j]==0 for j in range(5))
        assert (P3-expected).applyfunc(s.expand)==s.zeros(5)
        report['exceptional_cases'][name]={'uniform11minor_rows':list(rows),'uniform11minor_determinant':str(minor),
            'raw_Pfaffian_coefficient_span':sc,'E2_square_identity':square_cert,
            'first_hamiltonian_divisor':str(div1),'first_row_span':first_span,
            'second_hamiltonian_divisor':str(div2),'second_row_span':second_span,
            'forced_divisorial_factor':True,'Groebner_basis_used':False,
            'all_parameter_specializations_covered':True}
    report['geometric_and_exhaustion_audit']='PASS; full written argument and source qualification in independent_cubic_casimir_audit.txt.'
    report['all_passed']=True
    dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE
    dest.mkdir(parents=True,exist_ok=True)
    (dest/'independent_cubic_casimir_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print('All four exceptional exclusions passed by coefficient spans; uniform minors passed.',flush=True)

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Exact35-variable zero-trace/Pfaffian scheme and constant-factor deformation."""
from pathlib import Path
from itertools import combinations
import sys,json
import sympy as s
HERE=Path(__file__).resolve().parent
for base in [HERE.parent/'p4_poisson_completeness_v5'/'code',HERE.parent/'previous_v5'/'code']:
    if base.is_dir():sys.path.insert(0,str(base));break
import certify_regular_nilpotent as c
x,y,z,w=c.xx
xx=c.xx

def main(dest=HERE):
    ans=c.m.fixed_trace({});Q,t,eq=c.tensor(ans)
    assert ans['linear_rank']==25 and len(t)==35 and len(eq)==35
    assert all(s.expand(sum(s.diff(Q[i,j],xx[i]) for i in range(4)))==0 for j in range(4))
    pf=s.expand(Q[0,1]*Q[2,3]-Q[0,2]*Q[1,3]+Q[0,3]*Q[1,2])
    pp=s.Poly(pf,*xx);pe=pp.coeffs();assert len(pe)==35
    mon=sorted(set(m for f in eq+pe for m,_ in s.Poly(f,*t).terms()))
    M=s.Matrix([[s.Poly(f,*t).coeff_monomial(m) for m in mon] for f in eq])
    P=s.Matrix([[s.Poly(f,*t).coeff_monomial(m) for m in mon] for f in pe])
    ranks=[M.rank(),P.rank(),M.col_join(P).rank()];assert ranks==[35,35,35]
    coeff=s.symbols('g0:10');mons=[x**3,x*x*z,x*x*w,x*z*z,x*z*w,x*w*w,z**3,z*z*w,z*w*w,w**3]
    G=sum(v*m for v,m in zip(coeff,mons));eps=s.symbols('epsilon')
    R=s.zeros(4);R[1,2]=s.diff(G,w);R[2,1]=-R[1,2];R[1,3]=-s.diff(G,z);R[3,1]=-R[1,3]
    Rt=R.copy();Rt[0,1]=eps*x*x;Rt[1,0]=-eps*x*x
    assert c.jac(Rt,xx)==[0]*4 and c.jac(Rt+c.J,xx)==[0]*4
    assert s.expand(Rt[0,1]+Rt[2,3])==eps*x*x
    assert s.expand(Rt[0,1]*Rt[2,3]-Rt[0,2]*Rt[1,3]+Rt[0,3]*Rt[1,2])==0
    # Cartan wedge is a special point of BOTH old generic normal families.
    A,B,D,E=s.symbols('A B D E')
    def normal(A,B,D,E):
        R=s.zeros(4)
        vals=[A*x*y+B*z*w,E*x*z,-E*x*w,(-B-E)*y*z,(B+E)*y*w,D*z*w]
        for ij,f in zip(combinations(range(4),2),vals):R[ij]=f;R[ij[::-1]]=-f
        return R
    G1=normal(A,0,D,E);G2=normal(A,B,B,E)
    assert c.jac(G1,xx)==[0]*4 and c.jac(G1+c.J,xx)==[0]*4
    assert c.jac(G2,xx)==[0]*4 and c.jac(G2+c.J,xx)==[0]*4
    assert G1.subs({A:0,D:0})==G2.subs({A:0,B:0})
    out={'zero_trace_linear_rank':25,'zero_trace_parameter_count':35,'free_coefficient_basis':ans['free_basis'],
      'zero_trace_Q_brackets':{str(ij):str(Q[ij]) for ij in combinations(range(4),2)},
      'unimodularity_verified':True,'Jacobi_generators':[str(f) for f in eq],
      'Pfaffian_coefficients':{str(m):str(f) for m,f in pp.terms()},
      'Jacobi_Pfaffian_coefficient_row_ranks':ranks,'scheme_ideal_equality_verified':True,
      'constant_factor_universal_deformation':{'G':'arbitrary homogeneous cubic in x,z,w',
       'Q':'partial_y wedge (G_w partial_z-G_z partial_w)',
       'Q_epsilon':'Q+epsilon*x^2 partial_x wedge partial_y',
       'trace':'epsilon*x^2','Pfaffian':0,'Jacobi_and_J_compatibility_verified':True,
       'containment':'rank2 minimal-nilpotent13D component from v5'},
      'commuting_quadratic_family_containment':'Richardson Theorem A reduces every commuting Hamiltonian pair to a limit of Cartan pairs; their wedges lie in G1 intersection G2.',
      'both_universal_Cartan_deformations_verified':True,
      'scope':'Exact zero modular scheme and two containment classes; no complete zero-fiber decomposition.'}
    dest=Path(dest);dest.mkdir(parents=True,exist_ok=True)
    (dest/'zero_reduction_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'zero_parameters':35,'Jacobi_Pfaffian_row_ranks':ranks,'constant_factor_deformation':'passed','Cartan_deformations':'passed'},indent=2))
if __name__=='__main__':main(sys.argv[1] if len(sys.argv)>1 else HERE)

"""Full homogeneous quadratic central/unimodular models in five variables."""
from itertools import combinations, combinations_with_replacement, product
from collections import defaultdict
import sympy as s

X=s.symbols('x y z u v')
PAIRS=list(combinations(range(5),2))
MON2=[tuple(a.count(i) for i in range(5)) for a in combinations_with_replacement(range(5),2)]
BASIS=list(product(PAIRS,MON2))
def mon(a):return s.prod(q**e for q,e in zip(X,a))
def matrix(F):
    grad=[s.Poly(s.diff(F,q),*X) for q in X]
    rows=defaultdict(lambda:[0]*150)
    for col,((i,j),a) in enumerate(BASIS):
        for index,out,sign in [(i,j,1),(j,i,-1)]:
            for b,c in grad[index].terms():
                if c:
                    e=tuple(u+v for u,v in zip(a,b))
                    rows['central',out,e][col]+=sign*c
            if a[index]:
                e=list(a);e[index]-=1
                rows['divergence',out,tuple(e)][col]+=sign*a[index]
    labels=sorted(rows)
    return s.Matrix([rows[l] for l in labels]),labels
def vector(P):
    return s.Matrix([s.Poly(P[i,j],*X).coeff_monomial(a) for (i,j),a in BASIS])
def tensor(vec):
    P=s.zeros(5)
    for c,((i,j),a) in zip(vec,BASIS):P[i,j]+=c*mon(a);P[j,i]-=c*mon(a)
    return P
def parity(seq):return (-1)**sum(seq[i]>seq[j] for i in range(len(seq)) for j in range(i+1,len(seq)))
def jacobian(F):
    """Columns P with i_P Omega = dF wedge dxi wedge dxj."""
    J=s.zeros(150,10)
    for col,(i,j) in enumerate(PAIRS):
        P=s.zeros(5)
        for k in range(5):
            if k in (i,j):continue
            a,b=sorted(set(range(5))-{i,j,k})
            coeff=parity([a,b,k,i,j])*s.diff(F,X[k])
            P[a,b]+=coeff;P[b,a]-=coeff
        J[:,col]=vector(P)
    return J
def complete_model(F):
    M,labels=matrix(F);R,piv=M.rref();free=[i for i in range(150) if i not in piv]
    K=s.zeros(150,len(free))
    for j,k in enumerate(free):
        K[k,j]=1
        for i,p in enumerate(piv):K[p,j]=-R[i,k]
    assert M*K==s.zeros(M.rows,K.cols)
    J=jacobian(F);assert M*J==s.zeros(M.rows,10)
    B=J.row_join(K);_,bp=B.rref();B=B[:,list(bp)]
    assert B.cols==K.cols and list(bp[:10])==list(range(10))
    a=s.symbols('a:'+str(B.cols));P=tensor(B*s.Matrix(a))
    eq=[]
    for i,j,k,l in combinations(range(5),4):
        pf=s.expand(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])
        for f in s.Poly(pf,*X).coeffs():
            if f!=0:
                f=s.Poly(f,*a).monic().as_expr()
                if f not in eq:eq.append(f)
    return {'F':F,'M':M,'rank':len(piv),'K':K,'B':B,'a':a,'P':P,'eq':eq,'labels':labels}

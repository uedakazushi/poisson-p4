#!/usr/bin/env python3
"""Independent all-coefficient audit for the v6 nilpotent (2,2) component.

No import from any previous Poisson or rank calculation. Polynomial operations,
Schouten linearization and orbit columns are reconstructed here; ranks over QQ
are computed by SymPy. Only exact integers and rationals are used.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from collections import defaultdict
import json,argparse
import sympy as sp
HERE=Path(__file__).resolve().parent
PAIRS=list(combinations(range(5),2));TRIPLES=list(combinations(range(5),3));QUADS=list(combinations(range(5),4))

def mon(*ii):return tuple(ii.count(k) for k in range(5))
MON2=[mon(*ii) for ii in combinations_with_replacement(range(5),2)]
MON4=[mon(*ii) for ii in combinations_with_replacement(range(5),4)]
XBASIS=[(I,m) for I in PAIRS for m in MON2]
YBASIS=[(I,m) for I in QUADS for m in MON4]

def add(*polys):
    out=defaultdict(int)
    for pol in polys:
        for m,c in pol.items():out[m]+=c
    return {m:c for m,c in out.items() if c}
def scale(p,c):return {m:c*v for m,v in p.items() if c*v}
def mul(p,q):
    out=defaultdict(int)
    for m,c in p.items():
        for n,d in q.items():out[tuple(a+b for a,b in zip(m,n))]+=c*d
    return {m:c for m,c in out.items() if c}
def dx(p,i):
    out={}
    for m,c in p.items():
        if m[i]:
            n=list(m);n[i]-=1;out[tuple(n)]=c*m[i]
    return out
def ent(P,i,j):
    if i==j:return {}
    return P.get((i,j),{}) if i<j else scale(P.get((j,i),{}),-1)
def jac(P,R=None):
    out={}
    for i,j,k in TRIPLES:
        terms=[]
        for a,b,c in [(i,j,k),(j,k,i),(k,i,j)]:
            for h in range(5):
                terms.append(mul(ent(P,a,h),dx(ent(P if R is None else R,b,c),h)))
                if R is not None:terms.append(mul(ent(R,a,h),dx(ent(P,b,c),h)))
        out[i,j,k]=add(*terms)
    return out
def e_wedge(T):
    return {I:add(*(scale(mul({mon(i):1},T.get(tuple(j for j in I if j!=i),{})),(-1)**k)
                    for k,i in enumerate(I))) for I in QUADS}
def vector(P):return [P.get(I,{}).get(m,0) for I,m in XBASIS]
def action(P,a,b):
    out={}
    for i,j in PAIRS:
        out[i,j]=add(mul({mon(b):1},dx(ent(P,i,j),a)),
                     scale(ent(P,b,j),-int(i==a)),
                     scale(ent(P,i,b),-int(j==a)))
    return out
def vertical(a,b):
    return {(i,j):add({mon(i,b):1} if j==a else {},{mon(j,b):-1} if i==a else {}) for i,j in PAIRS}

def main():
    candidates=[HERE.parent/'p4_v6_nilpotent22_work'/'nilpotent22_certificate.json',HERE.parent/'data'/'nilpotent22_certificate.json']
    input_path=next(p for p in candidates if p.is_file())
    cert=json.loads(input_path.read_text())
    xx=sp.symbols('x0:5');x0,x1,x2,x3,x4=xx
    entries=[x0*x0-x1*x1+x1*x3-x1*x4,-x1*x1,0,
        3*x1*x2-4*x1*x3+x3*x3-3*x3*x4,
        x1*x1+x1*x2-2*x1*x3+2*x1*x4+x3*x3/2-2*x3*x4+x4*x4,
        x0*x0+x1*x1+x1*x4]
    P={I:{m:sp.Rational(v) for m,v in sp.Poly(2*f,*xx).terms() if v} for I,f in zip(combinations(range(1,5),2),entries)}
    assert not any(jac(P).values())
    cols=[]
    for I,m in XBASIS:
        T=e_wedge(jac(P,{I:{m:1}}))
        cols.append([T.get(K,{}).get(n,0) for K,n in YBASIS])
    JD=sp.Matrix.hstack(*(sp.Matrix(c) for c in cols))
    V=sp.Matrix.hstack(*(sp.Matrix(vector(vertical(a,b))) for a in range(5) for b in range(5)))
    O=sp.Matrix.hstack(*(sp.Matrix(vector(action(P,a,b))) for a in range(5) for b in range(5)))
    M=sp.Matrix.hstack(V,O,sp.Matrix(vector(P)))
    assert JD*M==sp.zeros(JD.rows,M.cols)
    ranks=(JD.rank(),V.rank(),M.rank())
    assert ranks==(102,24,48)
    pf=add(mul(ent(P,1,2),ent(P,3,4)),scale(mul(ent(P,1,3),ent(P,2,4)),-1),mul(ent(P,1,4),ent(P,2,3)))
    F=sp.expand(sum(v*sp.prod(z**a for z,a in zip(xx,m)) for m,v in pf.items())/4)
    assert all(m[0]+m[1]>=2 for m,v in sp.Poly(F,*xx).terms())
    assert sp.degree(F,x2)==1 and sp.gcd(sp.diff(F,x2),F.subs(x2,0))==1
    # Independently build all60 coefficients on A4 and solve linear conditions.
    x=sp.Matrix(xx[1:]);pairs4=list(combinations(range(4),2))
    mon2=[z1*z2 for z1,z2 in combinations_with_replacement(x,2)]
    rr=sp.symbols('r0:60');R=sp.zeros(4)
    for k,(i,j) in enumerate(pairs4):
        R[i,j]=sum(rr[10*k+l]*m for l,m in enumerate(mon2));R[j,i]=-R[i,j]
    J=sp.zeros(4);J[0,1]=J[2,3]=1;J[1,0]=J[3,2]=-1
    N=sp.Matrix([0,x3,0,x1]);DN=N.jacobian(x)
    def coefficients(polys):
        return [v for f in polys for m,v in sp.Poly(sp.expand(f),*x).terms() if v]
    compat=[sum(J[i,l]*sp.diff(R[j,k],x[l])+J[j,l]*sp.diff(R[k,i],x[l])+J[k,l]*sp.diff(R[i,j],x[l]) for l in range(4)) for i,j,k in combinations(range(4),3)]
    invariance=R.applyfunc(lambda f:sum(N[l]*sp.diff(f,x[l]) for l in range(4)))-DN*R-R*DN.T
    equations=coefficients(compat+[R[0,1]+R[2,3]-x1*x3]+[invariance[i,j] for i,j in pairs4])
    A,b=sp.linear_eq_to_matrix(equations,rr)
    assert A.rank()==49 and A.row_join(b).rank()==49
    ts=sp.symbols('t1:12');local={str(z):z for z in list(xx)+list(ts)}
    Q=sp.zeros(4)
    for i,j in pairs4:
        Q[i,j]=sp.sympify(cert['normal_form_brackets'][str(i+1)+str(j+1)],locals=local)
        Q[j,i]=-Q[i,j]
    qvec=sp.Matrix([sp.Poly(Q[i,j],*x).coeff_monomial(m) for i,j in pairs4 for m in mon2])
    assert A*qvec==b and qvec.jacobian(ts).rank()==11
    raw=coefficients([sum(Q[i,l]*sp.diff(Q[j,k],x[l])+Q[j,l]*sp.diff(Q[k,i],x[l])+Q[k,l]*sp.diff(Q[i,j],x[l]) for l in range(4)) for i,j,k in combinations(range(4),3)])
    expected=[sp.sympify(v,locals=local) for v in cert['Jacobi_generators']]
    basis=[sp.Integer(1),*ts,*[a*b for a,b in combinations_with_replacement(ts,2)]]
    matrix=lambda rows:sp.Matrix([[sp.Poly(e,*ts).coeff_monomial(m) for m in basis] for e in rows])
    assert matrix(raw).rank()==matrix(expected).rank()==matrix(raw+expected).rank()==9
    result={'implementation':'Polynomial dictionaries and SymPy; no previous Poisson helper is imported.',
      'full_P4_ranks':list(ranks),'Jacobi_times_orbit_vertical_scale_zero':True,
      'projective_tangent':23,'projective_orbit':23,
      'quartic_Pfaffian':str(F),'primitive_linear_in_x2':True,'D_in_I_P2_cubed':True,
      'independent_fixed_trace_linear_rank':49,'normal_form_parameter_rank':11,
      'full_raw_Jacobi_and_nine_equations_same_coefficient_rowspace':True,
      'Jacobi_coefficient_rowspace_rank':9,
      'scope':'Independent all60 linear reduction, all nonlinear coefficient generators, and all150 ambient tangent/orbit check. The written17-component case split is audited separately.'}
    out=Path(__import__('sys').argv[1]).resolve() if len(__import__('sys').argv)>1 else HERE
    out.mkdir(parents=True,exist_ok=True)
    (out/'nilpotent22_independent_audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()


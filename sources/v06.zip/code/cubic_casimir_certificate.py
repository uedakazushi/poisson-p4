#!/usr/bin/env python3
"""Exact certificate for all normal cubic Casimir reductions in v6.

Every linear calculation starts with all 150 coefficients.  The finite
normal-form and degeneration arguments are in cubic_casimir_theorem.txt.
No historical Poisson helper is imported.
"""
from normal_cubic_models import *
from pathlib import Path
import json,sys

x,y,z,u,v=X

CASES={
 'chordal':(x*u*u+y*y*v-x*z*v-2*y*z*u+z**3,140),
 'conic_nonisotropic':(v*(x*y+z*z)+z*u*u,140),
 'conic_isotropic':(v*(x*y+z*z)+x*u*u,140),
 'conic_A2':(v*(x*y+z*z)+u**3,139),
 'regular_pencil_distinct':(u*(x*x+y*y+z*z)+v*(x*x+2*y*y+3*z*z),140),
 'regular_pencil_repeated':(u*x*y+v*z*z,140),
 'regular_pencil_J2_distinct':(u*(2*x*y+z*z)+v*(y*y+z*z),140),
 'regular_pencil_J3':(u*(2*x*z+y*y)+2*v*y*z,140),
 'regular_pencil_J2_same':(u*(2*x*y+z*z)+v*y*y,140),
 'two_squares_z3':(u*x*x+v*y*y+z**3,140),
 'two_squares_one_z2':(u*x*x+v*y*y+x*z*z,140),
 'two_squares_both_z2':(u*x*x+v*y*y+(x+y)*z*z,140),
 'square_product_z3_y3':(u*x*x+v*x*y+z**3+y**3,140),
 'square_product_yz2':(u*x*x+v*x*y+y*z*z,140),
 'square_product_y2z_xz2':(u*x*x+v*x*y+y*y*z+x*z*z,140),
 'square_product_z3':(u*x*x+v*x*y+z**3,139),
 'square_product_y3_xz2':(u*x*x+v*x*y+y**3+x*z*z,139),
 'common_factor_three_roots':(x*(u*y+v*z)+y**3+z**3,140),
 'common_factor_double_root':(x*(u*y+v*z)+y*y*z,140),
 'common_factor_triple_root':(x*(u*y+v*z)+y**3,139),
}

def pfaffians(P):
    eq=[]
    for i,j,k,l in combinations(range(5),4):
        pf=s.expand(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])
        eq.extend(c for c in s.Poly(pf,*X).coeffs() if c!=0)
    return list(dict.fromkeys(eq))

def row_coefficients(P,i):
    return [c for j in range(5) for c in s.Poly(s.expand(P[i,j]),*X).coeffs() if c!=0]

def sparse(P):
    return {str((i,j)):str(s.factor(P[i,j])) for i,j in PAIRS if P[i,j]!=0}

def verify_rank(name,F,expected):
    M,labels=matrix(F);R,piv=M.rref();assert len(piv)==expected
    J=jacobian(F);assert J.rank()==10 and M*J==s.zeros(M.rows,10)
    _,rows=M[:,list(piv)].T.rref()
    determinant=M.extract(rows,piv).det(method='domain-ge');assert determinant!=0
    report={'F':str(F),'matrix_shape':list(M.shape),'rank_over_Q':len(piv),
      'kernel_dimension':150-len(piv),'jacobian_image_dimension':10,
      'jacobian_image_in_kernel':True,'pivot_rows':list(rows),'pivot_columns':list(piv),
      'minor_determinant':str(determinant)}
    print(name,expected,flush=True)
    return report

def exceptional_case(name,F,Q,necessary,first_row,second_row,first_subs,second_subs,factor,cofactor,parameter_symbols=()):
    a=s.symbols('a:10');k=s.symbols('k')
    P=tensor(jacobian(F)*s.Matrix(a))+k*Q
    assert all(s.expand(sum(P[i,j]*s.diff(F,X[i]) for i in range(5)))==0 for j in range(5))
    assert all(s.expand(sum(s.diff(P[i,j],X[i]) for i in range(5)))==0 for j in range(5))
    B=jacobian(F).row_join(vector(Q));assert B.rank()==11
    uniform_rows={
      'conic_A2':[1,10,11,12,16,27,31,61,72,76,106],
      'common_factor_triple_root':[1,2,4,16,17,32,61,62,77,107,111]
    }.get(name)
    uniform_minor=None
    if uniform_rows is not None:
        uniform_minor=s.factor(B.extract(uniform_rows,range(11)).det(method='domain-ge'))
        assert uniform_minor=={'conic_A2':108,'common_factor_triple_root':-1}[name]
    eq=[s.expand(e.subs(k,1)) for e in pfaffians(P)]
    G=s.groebner(eq,*reversed(a),*parameter_symbols,order='grevlex')
    for f in necessary:assert G.reduce(s.sympify(f,locals={str(q):q for q in a}))[1]==0
    # Caller supplies the reduced-support consequences, including a8=0
    # when only a8^2 is in the ideal.
    Pn=P.subs(k,1).subs(first_subs[0])
    divisor=first_subs[1]
    assert all(s.expand(Pn[first_row,j]).subs(divisor,0)==0 for j in range(5))
    first_eq=row_coefficients(Pn,first_row)
    first_solution=s.solve(first_eq,list(first_subs[2]),dict=True)
    assert first_solution==[first_subs[3]],(name,first_solution)
    P1=Pn.subs(first_subs[3])
    divisor2=second_subs[0]
    assert all(s.expand(P1[second_row,j]).subs(divisor2,0)==0 for j in range(5))
    second_eq=row_coefficients(P1,second_row)
    second_solution=s.solve(second_eq,list(second_subs[1]),dict=True)
    assert second_solution==[second_subs[2]],(name,second_solution)
    P2=P1.subs(second_subs[2]).applyfunc(s.expand)
    assert (P2-factor*cofactor).applyfunc(s.expand)==s.zeros(5)
    return {'F':str(F),'extra':sparse(Q),'extra_independent_of_jacobian_image':True,
      'uniform_independence_minor_rows':uniform_rows,'uniform_independence_minor':str(uniform_minor),
      'necessary_ideal_memberships':necessary,'groebner_basis':[str(g) for g in G],
      'first_hamiltonian_row':[str(s.factor(Pn[first_row,j])) for j in range(5)],
      'first_row_zero_solution':{str(q):str(c) for q,c in first_subs[3].items()},
      'second_hamiltonian_row':[str(s.factor(P1[second_row,j])) for j in range(5)],
      'second_row_zero_solution':{str(q):str(c) for q,c in second_subs[2].items()},
      'forced_common_linear_factor':str(factor),'remaining_tensor':sparse(P2),
      'common_factor_identity_verified':True}

def main():
    dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
    dest.mkdir(parents=True,exist_ok=True)
    report={'models':{name:verify_rank(name,*args) for name,args in CASES.items()}}

    A=s.symbols('A');F=u*x*x+v*x*y+z**3+y*y*z+A*y**3
    M,_=matrix(F);M0=M.subs(A,0);_,cols=M0.rref();_,rows=M0[:,list(cols)].T.rref()
    det=s.factor(M.extract(rows,cols).det(method='domain-ge'))
    assert det==325358826026112*(27*A*A+4)**4
    report['parametric_discriminant_minor']={'F':str(F),'rows':list(rows),'columns':list(cols),'determinant':str(det)}

    a=s.symbols('a:10');p,q,r,h=s.symbols('p q r h')
    def skew(d):
        B=s.zeros(5)
        for (i,j),f in d.items():B[i,j]=f;B[j,i]=-f
        return B
    Bq=skew({(0,1):2*z,(0,2):-x,(1,2):y})
    F=v*(x*y+z*z)+u**3+p*u*u*v+q*u*v*v+r*v**3
    ex={}
    ex['conic_A2']=exceptional_case('conic_A2',F,u*Bq,['a0','a1','a4'],3,4,
       ({a[0]:0,a[1]:0,a[4]:0},v,(a[3],a[6],a[8]),{a[3]:0,a[6]:0,a[8]:0}),
       (v,(a[2],a[5],a[7]),{a[2]:0,a[5]:0,a[7]:0}),a[9]*v+u,Bq,(p,q,r))

    F=CASES['square_product_z3'][0]
    Q=skew({(1,3):y*z,(1,4):-x*z,(3,4):v*z})
    C=skew({(1,3):y,(1,4):-x,(3,4):v})
    ex['square_product_z3']=exceptional_case('square_product_z3',F,Q,['a5','a6','a9'],0,2,
       ({a[5]:0,a[6]:0,a[9]:0},x,(a[4],a[7],a[8]),{a[4]:0,a[7]:0,a[8]:0}),
       (x,(a[0],a[2],a[3]),{a[0]:0,a[2]:0,a[3]:0}),z-a[1]*x,C)

    F=CASES['square_product_y3_xz2'][0]
    Q=skew({(1,2):-x*x/s.Integer(6),(1,3):x*z/s.Integer(3),(2,3):-v*x/s.Integer(6),(2,4):-x*y/s.Integer(2),(3,4):y*z})
    C=skew({(2,3):y,(2,4):-x,(3,4):2*z})
    ex['square_product_y3_xz2']=exceptional_case('square_product_y3_xz2',F,Q,['a7','a9','a8**2'],0,1,
       ({a[7]:0,a[8]:0,a[9]:0},x,(a[4],a[5],a[6]),{a[4]:0,a[5]:0,a[6]:0}),
       (x,(a[1],a[2],a[3]),{a[1]:0,a[2]:0,a[3]:-s.Rational(1,6)}),a[0]*x+y/2,C)

    F=x*(u*y+v*z)+y**3+h*x**3
    Q=skew({(1,2):x*z/s.Integer(3),(1,4):-v*x/s.Integer(3),(2,3):y*z,(2,4):u*x/s.Integer(3),(3,4):v*y})
    C=skew({(2,3):z,(2,4):-y,(3,4):v})
    ex['common_factor_triple_root']=exceptional_case('common_factor_triple_root',F,Q,['a7','a8','a9'],0,1,
       ({a[7]:0,a[8]:0,a[9]:0},x,(a[4],a[5],a[6]),{a[4]:0,a[5]:0,a[6]:0}),
       (x,(a[1],a[2],a[3]),{a[1]:0,a[2]:-s.Rational(1,3),a[3]:0}),a[0]*x+y,C,(h,))
    report['exceptional_models']=ex

    # Check the singular-pencil determinant calculation.
    aa,bb,cc,dd,ee,ff,t=s.symbols('aa bb cc dd ee ff t')
    pencil=x*y+t*(aa*x*x+bb*x*y+cc*y*y+dd*x*z+ee*y*z+ff*z*z)
    mat=s.hessian(pencil,(x,y,z))/2
    determinant=s.factor(mat.det());reduced=s.expand(determinant.subs(ff,0))
    assert s.expand(reduced-(dd*ee*t*t+(-aa*ee*ee+bb*dd*ee-cc*dd*dd)*t**3)/4)==0
    report['singular_pencil_determinant']={'full':str(determinant),'after_f_zero':str(reduced)}
    report['all_passed']=True
    (dest/'cubic_casimir_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print('All twenty full-space models, discriminant minor, and four exceptional exclusions passed.',flush=True)

if __name__=='__main__':main()

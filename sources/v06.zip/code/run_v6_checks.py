#!/usr/bin/env python3
"""Rebuild all nine v6 exact certificates, in a temporary working directory."""
from pathlib import Path
import hashlib,json,os,platform,subprocess,sys,tempfile,time
import numpy,sympy
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
CHECKS=[
 'certify_ambient_families.py',
 'independent_ambient_families_audit.py',
 'certify_nilpotent22.py',
 'audit_nilpotent22.py',
 'certify_zero_log_component.py',
 'audit_zero_obstruction.py',
 'certify_zero_reduction.py',
 'cubic_casimir_certificate.py',
 'independent_cubic_casimir_audit.py',
]
def main():
 dest=ROOT/'data';dest.mkdir(exist_ok=True)
 env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
 results=[]
 with tempfile.TemporaryDirectory(prefix='p4_v6_verification_') as cwd:
  for name in CHECKS:
   script=HERE/name
   started=time.perf_counter()
   done=subprocess.run([sys.executable,str(script),str(dest)],cwd=cwd,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
   elapsed=time.perf_counter()-started
   log=dest/(script.stem+'.log');log.write_text(done.stdout)
   results.append({'script':name,'exit_code':done.returncode,'elapsed_seconds':round(elapsed,3),'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'log':log.name})
   print(f'{name}: exit={done.returncode}, {elapsed:.2f}s',flush=True)
   if done.returncode:
    print(done.stdout,flush=True)
    break
 report={'python':platform.python_version(),'numpy':numpy.__version__,'sympy':sympy.__version__,
   'results':results,'all_passed':len(results)==len(CHECKS) and all(r['exit_code']==0 for r in results),
   'scope':'Nine exact certificate entrypoints, including independent algebra implementations. Written proof/exhaustion/formal-local audits are in proofs/. Historical files are not modified.'}
 (dest/'v6_check_results.json').write_text(json.dumps(report,indent=2)+'\n')
 if not report['all_passed']:raise SystemExit(1)
 print('All nine exact v6 checks passed.',flush=True)
if __name__=='__main__':main()

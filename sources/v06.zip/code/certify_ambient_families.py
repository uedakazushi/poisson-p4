#!/usr/bin/env python3
"""Exact universal identities and full P4 component certificates for A and B.

Both image closures are dimension28 full components. Ranks are computed on
all150 homogeneous quadratic coefficients, not just the displayed families.
The generic PGL orbit has dimension22 and the rational quotient dimension6.
"""
from pathlib import Path
from itertools import product,combinations
import sys,json
HERE=Path(__file__).resolve().parent
for path in [HERE.parent/'p4_poisson_completeness_v5'/'code',HERE.parent/'previous_v5'/'code']:
 if path.is_dir():sys.path.insert(0,str(path));break
else:raise RuntimeError('Preserved v5 code is required.')
import certify_regular_nilpotent as c
sp,np=c.sp,c.np
x0,x,y,z,w=c.xx5
e=[sp.eye(5)[:,i] for i in range(5)]
Jxy=c.wedge(e[1],e[2]);Jzw=c.wedge(e[3],e[4])
Ezw=z*e[3]+w*e[4]
def X(h):return -sp.diff(h,w)*e[3]+sp.diff(h,z)*e[4]
def family(kind,f,h):
 if kind=='A':return f*Jxy+x0*x0*Jzw+c.wedge(e[2],X(h))
 return f*(Jxy+Jzw)+c.wedge(e[2],-sp.diff(f,x)*Ezw/2+X(h))
FM=[x0*x0,x0*x,x*x]
HM=[sp.prod(v**i for v,i in zip((x0,x,z,w),mon)) for mon in product(range(4),repeat=4) if sum(mon)==3 and mon[2]+mon[3]>0]

def main():
 assert len(HM)==16
 aa=sp.symbols('a0:3');bb=sp.symbols('b0:16')
 ff=sum(a*m for a,m in zip(aa,FM));hh=sum(b*m for b,m in zip(bb,HM))
 out={}
 for kind in ['A','B']:
  U=family(kind,ff,hh)
  assert c.jac(U,c.xx5)==[0]*10
  pf=sp.factor(U[1,2]*U[3,4]-U[1,3]*U[2,4]+U[1,4]*U[2,3])
  assert sp.expand(pf-(x0*x0*ff if kind=='A' else ff*ff))==0
  divergence=sp.Matrix([sum(sp.diff(U[i,j],c.xx5[i]) for i in range(5)) for j in range(5)])
  assert divergence==(1 if kind=='A' else 2)*sp.diff(ff,x)*e[2]
  for Z in [x0*e[2],x*e[2]]:assert c.lie(Z,U,c.xx5)==sp.zeros(5)
  # One short integral witness works for both components.
  f=x0*x0+x*x;h=x*z*w+z**3+w**3
  P=family(kind,f,h)
  ps=c.sparse(P)
  D=c.p.linearized_jacobi_matrix(ps);V=c.p.vertical_bivector_matrix()
  orbit=[]
  for i in range(5):
   for j in range(5):
    A=np.zeros((5,5),dtype=np.int64);A[i,j]=1
    orbit.append(c.p.bivector_vector(c.v.linear_action_derivative(ps,A)))
  M=np.column_stack([V,*orbit,c.p.bivector_vector(ps)])
  deriv=[U.diff(v) for v in aa+bb]
  cols=[c.p.bivector_vector(c.sparse(2*R)) for R in deriv]
  assert c.rank(np.column_stack(cols))==19
  F=np.column_stack([M,*cols])
  assert not np.any(D@F)
  dr,dc=c.rank_cert(D);vr,vc=c.rank_cert(V)
  mr,mc=c.rank_cert(M);fr,fc=c.rank_cert(F)
  assert (dr,vr,mr,fr)==(97,24,47,53)
  out[kind]={
   'universal_formula':('f*partial_x wedge partial_y+x0^2*partial_z wedge partial_w+partial_y wedge X_h' if kind=='A' else 'f*(partial_x wedge partial_y+partial_z wedge partial_w)+partial_y wedge (-f_x E_zw/2+X_h)'),
   'parameter_degrees':{'f':'arbitrary homogeneous binary quadratic in x0,x','h':'arbitrary homogeneous cubic in x0,x,z,w modulo cubics in x0,x'},
   'f_basis':[str(t) for t in FM],'h_basis':[str(t) for t in HM],
   'family_parameter_count':19,'universal_affine_Jacobi_verified':True,
   'universal_Pfaffian':str(pf),'universal_projective_degeneracy':str(sp.factor(x0*pf)),
   'sample_f':str(f),'sample_h':str(h),
   'sample_brackets':{str(i)+str(j):str(sp.expand(P[i,j])) for i,j in combinations(range(5),2)},
   'full_Jacobi_matrix_shape':list(D.shape),
   'rank_Jacobi_over_Q':dr,'rank_vertical_over_Q':vr,
   'rank_vertical_orbit_scale_over_Q':mr,
   'rank_vertical_orbit_scale_actual_family_over_Q':fr,
   'Jacobi_times_all_actual_directions_zero':True,
   'projective_tangent_dimension':125-dr,
   'projective_orbit_dimension':mr-vr-1,
   'projective_actual_family_dimension':fr-vr-1,
   'full_component_dimension':28,'witness_is_smooth':True,
   'universal_independent_stabilizer_fields':['x0 partial_y','x partial_y'],
   'generic_stabilizer_dimension':2,'generic_rational_quotient_dimension':6,
   'Jacobi_minor':dc,'vertical_minor':vc,'orbit_minor':mc,'actual_family_minor':fc}
 out['distinction']={
  'A_versus_B':'A satisfies the closed condition D=L^3 q. The generic B divisor has distinct linear factors with multiplicities1,2,2, so B is not A.',
  'SNC_components':'A has a triple linear factor; B has a squared quadratic factor. Both are closed projective factorization conditions excluding every reduced SNC divisor.',
  'other_prior_components':'Generic rank4 excludes all six rank2 components; dimension28 differs from both prior22D additions and the new23D nilpotent22 component.',
  'scope':'Two full projective P4 components, each dimension28; no complete classification or literature novelty claim.'}
 dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE
 dest.mkdir(parents=True,exist_ok=True)
 (dest/'ambient_families_certificate.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:{'ranks':[out[k]['rank_Jacobi_over_Q'],out[k]['rank_vertical_over_Q'],out[k]['rank_vertical_orbit_scale_over_Q'],out[k]['rank_vertical_orbit_scale_actual_family_over_Q']],'component_dimension':28,'generic_orbit':22,'generic_quotient':6} for k in ['A','B']},indent=2))
if __name__=='__main__':main()

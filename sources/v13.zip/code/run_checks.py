"""Reproduce v13 certificates in an isolated temporary copy.

Every mathematical JSON field is compared; only explicitly named elapsed-time
fields are ignored.  Preserved historical files are never modified.
"""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, time

ROOT = Path(__file__).resolve().parents[1]
IGNORE = {'seconds', 'elapsed', 'elapsed_seconds', 'execution_seconds'}
def math_only(x):
    if isinstance(x, dict):
        return {k: math_only(v) for k, v in x.items() if k not in IGNORE}
    if isinstance(x, list): return [math_only(v) for v in x]
    return x
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--skip-high-jets', action='store_true')
parser.add_argument('--regenerate-high-jets', action='store_true')
args = parser.parse_args()
out = args.output.resolve(); out.mkdir(parents=True, exist_ok=True)
(out/'outputs').mkdir(exist_ok=True)
checks = [
 ('ambient_involution', 'root/involution.py', [], ['root/involution.json']),
 ('universal_torsion_lifts', 'jets/axis_annihilator_lift.py', [], ['jets/axis_annihilator_lift.json']),
 ('independent_lift_audit', 'jets/independent_axis_lift_audit.py', [], ['jets/independent_axis_lift_audit.json']),
 ('independent_axis_algebra', 'axis/verify_axis_structure.py', [], ['axis/verify_axis_structure.json']),
 ('independent_full_nil_algebra', 'nil/nil_full_algebra_certificate.py', [], ['nil/nil_full_algebra_certificate.json']),
 ('unitization_59_relations', 'reconstruction/compress_unitization.py', [], ['reconstruction/unitization_59_relations.json','reconstruction/unitization_compressed.json']),
 ('colon_eleven_polynomials', 'reconstruction/short_colon_ideal.py', [], ['reconstruction/short_colon_ideal.json']),
 ('full_six_branch_intersection', 'reconstruction/full_intersection.py', [], ['reconstruction/full_intersection.json']),
 ('full_polynomial_normal_form', 'reconstruction/final_polynomial_normal_form.py', [], ['reconstruction/final_polynomial_normal_form.json']),
 ('independent_graded_minimality', 'reconstruction/graded_minimality.py', [], ['reconstruction/graded_minimality.json']),
]
if args.regenerate_high_jets:
    checks.insert(1, ('regenerate_high_jets', 'jets/build_high_jets.py', ['8'], ['jets/zero_jet_7.json','jets/zero_jet_8.json']))
if not args.skip_high_jets:
    checks.append(('all_350_high_jet_relations', 'jets/verify_high_jets.py', [], ['jets/high_jets_verification.json']))

start = time.time(); result = []
with tempfile.TemporaryDirectory(prefix='p4_v13_verify_') as temp:
    work = Path(temp)/'v13'; work.mkdir()
    shutil.copytree(ROOT/'code', work/'code')
    prev = work/'previous_v12'; prev.mkdir()
    shutil.copy2(ROOT/'previous_v12/HANDOFF.txt', prev/'HANDOFF.txt')
    shutil.copytree(ROOT/'previous_v12/previous_v11/code/zero_jets', prev/'previous_v11/code/zero_jets')
    env = os.environ.copy(); env['PYTHONDONTWRITEBYTECODE'] = '1'
    for name, script, argv, outputs in checks:
        tick = time.time()
        run = subprocess.run([sys.executable,str(work/'code'/script),*argv], cwd=work, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (out/(name+'.log')).write_text(run.stdout)
        if run.returncode:
            raise RuntimeError(f'{name} failed, see {out/(name+".log")}')
        for relative in outputs:
            actual = work/'code'/relative; expected = ROOT/'code'/relative
            if math_only(json.loads(actual.read_text())) != math_only(json.loads(expected.read_text())):
                raise AssertionError(f'{name}: mathematical JSON differs: {relative}')
            dest=out/'outputs'/relative; dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(actual,dest)
        row={'name':name,'passed':True,'script':script,'script_sha256':sha(ROOT/'code'/script),'outputs_compared':outputs,'seconds':time.time()-tick}
        result.append(row); print('PASS',name,round(row['seconds'],3),flush=True)
summary={'all_passed':True,'check_count':len(result),'checks':result,'seconds':time.time()-start,
 'isolation':'Temporary copy; historical files read only.',
 'comparison':'All mathematical JSON fields; only four named timing keys ignored.',
 'high_jets_regenerated':args.regenerate_high_jets,
 'high_jet_full_350_validation':not args.skip_high_jets}
(out/'verification_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('ALL PASSED',len(result),'seconds',round(summary['seconds'],3),flush=True)

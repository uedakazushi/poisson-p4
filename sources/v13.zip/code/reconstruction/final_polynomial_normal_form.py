"""Exact six-variable eleven-polynomial normal form of the zero-magnetic germ.
This verifies algebraic ideal identities. Identification with the actual completed
Poisson scheme is proved using the colon reconstruction theorem, separately.
"""
import json
from pathlib import Path
import sympy as S
HERE=Path(__file__).resolve().parent
zeta,tau,ell,b,chi,d=S.symbols('zeta tau ell b chi d')
vs=(zeta,tau,ell,b,chi,d);oldsigma,oldc=S.symbols('sigma c')
loc={str(v):v for v in vs};loc.update({'sigma':oldsigma,'c':oldc})
z=json.loads((HERE/'full_intersection.json').read_text())
oldI=[S.sympify(f,locals=loc).subs({oldsigma:zeta,oldc:chi+8*d*d*(9*b-8*ell)},simultaneous=True).expand() for f in z['full_ideal_lex']]
A=ell*(3*tau+9*b*ell-16*ell*ell)
B=(15*b-20*ell)*tau+18*b*b*ell-36*b*ell*ell
U=3*ell*zeta+4*A-B
V=3*tau*(zeta+9*tau)+(72*b*b-153*b*ell+16*ell*ell)*tau+5*ell*(3*b-8*ell)*(3*b-4*ell)*(3*b-2*ell)
P=tau+3*b*ell-8*ell*ell
Q=zeta+6*tau+9*b*b-30*b*ell+16*ell*ell
F=(14*ell-15*b)*P+3*ell*Q
H=3*P+Q+15*b*ell
assert S.expand(F-U)==0
assert S.expand(V-(3*P*H-(3*b-8*ell)*F))==0
I0=[F,P*H,chi*tau,chi*zeta]
I=[F,P*H,chi*tau,chi*zeta,d*zeta*zeta,b*d*zeta,d*A,d*B,d*(92*tau*tau+99*b**3*ell),d*ell*(11776*ell**3-1323*b**3),d*b*b*ell*(184*ell-57*b)]
G0=S.groebner(oldI,*vs,order='grevlex',domain=S.QQ)
G=S.groebner(I,*vs,order='grevlex',domain=S.QQ)
assert G==G0
assert all(G0.reduce(S.expand(f))[1]==0 for f in I)
assert all(G.reduce(S.expand(f))[1]==0 for f in oldI)
# Independently construct transformed J and the five reduced branches.
J=[b*zeta,chi*zeta,ell*zeta,zeta*zeta,zeta*tau,A,B,b*ell*(46*ell*ell-9*b*b),b*b*ell*(184*ell-57*b),92*tau*tau+99*b**3*ell,chi*tau]
branches={
 '18':[d,8*ell-3*b,tau,zeta],
 '20':[d,4*ell-3*b,tau,zeta],
 '22':[chi,d,ell,tau],
 '24':[chi,d,tau-ell*(8*ell-3*b),zeta+(8*ell-3*b)**2],
 '25':[chi,d,zeta+9*tau+9*b*b-6*b*ell-8*ell*ell,(ell-3*b)*tau-ell*(4*ell-3*b)*(2*ell-3*b)]}
x=S.symbols('intersection_parameter')
def inter(H,K):
 T=S.groebner([x*f for f in H]+[(1-x)*f for f in K],x,*vs,order='lex',domain=S.QQ)
 return [f.as_expr() for f in T.polys if not f.as_expr().has(x)]
L=[S.Integer(1)]
for K in branches.values():L=inter(L,K)
assert S.groebner(inter(J,L),*vs,order='grevlex',domain=S.QQ)==G
# Check colon(I,d)=J by elimination, not an assumed saturation or cancellation.
# I intersect(d), divided by d, is I:d for a principal polynomial ideal.
Id=inter(I,[d]);colon=[S.cancel(f/d) for f in Id]
GJ=S.groebner(J,*vs,order='grevlex',domain=S.QQ)
assert S.groebner(colon,*vs,order='grevlex',domain=S.QQ)==GJ
# The stronger fiber-product form I=I0+dJ is an exact polynomial identity.
assert S.groebner(I0+[d*f for f in J],*vs,order='grevlex',domain=S.QQ)==G
assert all(not f.has(d) for f in J)
# d-regularity of J and the exact d=0 fiber.
Jd=inter(J,[d]);assert S.groebner([S.cancel(f/d) for f in Jd],*vs,order='grevlex',domain=S.QQ)==GJ
K16=[ell,tau,zeta]
Ired=inter(K16,L)
assert S.groebner(I+[d],*vs,order='grevlex',domain=S.QQ)==S.groebner(Ired+[d],*vs,order='grevlex',domain=S.QQ)
# Minimality is inherited from v12 mu(I)=11 under the proven coordinate changes.
orders=[];degrees=[]
for f in I:
 terms=S.Poly(S.expand(f),*vs).terms();orders.append(min(sum(m) for m,co in terms));degrees.append(max(sum(m) for m,co in terms))
assert sorted(orders)==[2,2,2,2,3,3,3,3,3,5,5]
assert max(degrees)==5
weights=(2,2,1,1,1,1)
weighted_degrees=[]
for f in I:
    wd={sum(a*w for a,w in zip(m,weights)) for m,co in S.Poly(S.expand(f),*vs).terms()}
    assert len(wd)==1
    weighted_degrees.append(next(iter(wd)))
out={'all_passed':True,
'scope':'Exact polynomial ideal equality, exact intersections and colons over QQ. Completion at the origin is identified with the full transverse Poisson germ by the companion all-orders reconstruction proof.',
'variables':list(map(str,vs)),
'coordinate_change_from_simultaneously_normalized':{'ell':'a+b','tau':'p+(28*a+19*b)*(a+b)/3','zeta':'q-9*b^2-6*p-(64*a+112*b)*(a+b)','chi':'c-8*d^2*(9*b-8*(a+b))','b':'b','d':'d'},
'inverse_coordinate_change':{'a':'ell-b','p':'tau-28*ell^2/3+3*b*ell','q':'zeta+9*b^2+6*tau+8*ell^2+66*b*ell','c':'chi+8*d^2*(9*b-8*ell)','b':'b','d':'d'},
'auxiliary_polynomials':{'A':str(A),'B':str(B),'P':str(P),'Q':str(Q),'F':str(F),'H':str(H)},
'I0_four_generators':list(map(str,I0)),
'positive_grading_weights':dict(zip(map(str,vs),weights)),'generator_weighted_degrees':weighted_degrees,
'eleven_full_ideal_generators':list(map(str,I)),
'generator_orders':orders,'generator_max_degrees':degrees,
'minimality':'The independent companion graded_minimality.py computes every weighted piece of I/mI and proves mu(I)=11; this also agrees with v12. The eleven displayed polynomials are minimal in the completed local ring.',
'colon_ideal_generators':list(map(str,J)),
'five_other_reduced_branch_primes':{k:list(map(str,v)) for k,v in branches.items()},
'reduced_T16_prime':list(map(str,K16)),
'checks':['transformed_old_intersection_equals_eleven_polynomials','new_J_intersection_five_primes_equals_I','I_colon_d_equals_J','J_colon_d_equals_J','I_equals_I0_plus_dJ_with_J_independent_of_d','d_zero_fiber_equals_reduced_d_zero_fiber','positive_weighted_homogeneity','orders_4_quadratic_5_cubic_2_quintic','maximum_polynomial_degree_5'],
'groebner_basis':[str(p.as_expr()) for p in G.polys]}
(HERE/'final_polynomial_normal_form.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['all_passed','checks','generator_orders','generator_max_degrees']},indent=2))
for f in I:print(S.factor(f))

"""Exact verification of an eleven-polynomial colon ideal in adapted coordinates."""
import json
from pathlib import Path
import sympy as S
HERE=Path(__file__).resolve().parent
sigma,tau,ell,b,c,d=S.symbols('sigma tau ell b c d');vs=(sigma,tau,ell,b,c,d)
z=json.loads((HERE/'unitization_59_relations.json').read_text())
original=[S.sympify(r['polynomial'],locals={str(v):v for v in vs}) for r in z['relations']]
short=[b*sigma,c*sigma,ell*sigma,sigma*sigma,sigma*tau,
ell*(3*tau+9*b*ell-16*ell*ell),
(15*b-20*ell)*tau+18*b*b*ell-36*b*ell*ell,
b*ell*(46*ell*ell-9*b*b),
b*b*ell*(184*ell-57*b),
92*tau*tau+99*b**3*ell,
(c-8*d*d*(9*b-8*ell))*tau]
G0=S.groebner(original,*vs,order='grevlex',domain=S.QQ);G=S.groebner(short,*vs,order='grevlex',domain=S.QQ)
assert G==G0
assert all(G0.reduce(S.expand(f))[1]==0 for f in short)
assert all(G.reduce(S.expand(f))[1]==0 for f in original)
# Inverse triangular change to raw normalized variables a,b,p,c,d,q.
a,p,q=S.symbols('a p q');locals6={ell:a+b,tau:p+(28*a+19*b)*(a+b)/3,sigma:q-9*b*b-6*p-(64*a+112*b)*(a+b)}
origcoord=[S.factor(f.subs(locals6,simultaneous=True)) for f in short]
print('PASS: exact equality with all59unitization relations; eleven generators.')
for f in short:print(S.factor(f))
# Optional test deletion proves no generator is globally in the ideal of the others.
irredundant=[]
for i,f in enumerate(short):
 others=short[:i]+short[i+1:]
 irredundant.append(S.groebner(others,*vs,order='grevlex',domain=S.QQ).reduce(S.expand(f))[1]!=0)
assert all(irredundant)
out={'all_passed':True,'scope':'Exact equality of polynomial ideals in six variables, hence of completed ideals. No finite-jet inference.',
'adapted_coordinates':list(map(str,vs)),
'coordinate_change':{'ell':'a+b','tau':'p+(28*a+19*b)*(a+b)/3','sigma':'q-9*b^2-6*p-(64*a+112*b)*(a+b)'},
'inverse_change':{'a':'ell-b','p':'tau-28*ell^2/3+3*b*ell','q':'sigma+9*b^2+6*tau+8*ell^2+66*b*ell'},
'eleven_generators':list(map(str,short)),
'normalized_original_coordinates_generators':list(map(str,origcoord)),
'generator_deletion_irredundant':irredundant,
'groebner_basis':list(map(str,[f.as_expr() for f in G.polys])),
'original_relations_verified':len(original)}
(HERE/'short_colon_ideal.json').write_text(json.dumps(out,indent=2)+'\n')

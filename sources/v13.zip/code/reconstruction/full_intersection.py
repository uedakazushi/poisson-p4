"""Exact polynomial intersection of the colon component and five reduced branches."""
import json,time
from pathlib import Path
import sympy as S
HERE=Path(__file__).resolve().parent
sigma,tau,ell,b,c,d=S.symbols('sigma tau ell b c d');vs=(sigma,tau,ell,b,c,d);x=S.symbols('intersection_parameter')
a=ell-b;p=tau-S.Rational(28,3)*ell**2+3*b*ell;q=sigma+9*b*b+6*tau+8*ell*ell+66*b*ell
P=p+S.Rational(4,3)*ell**2;Q=q+8*ell*(a-11*b);H=3*P+Q+15*b*ell
branches={
 '18':[d,8*a+5*b,p+S.Rational(3,16)*b*b,q-S.Rational(279,8)*b*b],
 '20':[d,4*a+b,p+3*b*b,q-63*b*b],
 '22':[c,d,P,ell],
 '24':[c,d,P,Q],
 '25':[c,d,H,(a-2*b)*P-9*b*ell**2]
}
z=json.loads((HERE/'short_colon_ideal.json').read_text());loc={str(v):v for v in vs};J=[S.sympify(f,locals=loc) for f in z['eleven_generators']]
def inter(I,K):
 G=S.groebner([x*f for f in I]+[(1-x)*f for f in K],x,*vs,order='lex',domain=S.QQ)
 return [f.as_expr() for f in G.polys if not f.as_expr().has(x)]
start=time.time();L=[S.Integer(1)]
for key,K in branches.items():
 L=inter(L,K);print('L through',key,'gens',len(L),'sec',time.time()-start,flush=True)
full=inter(J,L);print('FULL gens',len(full),'sec',time.time()-start,flush=True)
G=S.groebner(full,*vs,order='grevlex',domain=S.QQ);print('FULL grevlex',len(G.polys),time.time()-start,flush=True)
for f in G.polys:print(S.factor(f.as_expr()),flush=True)
(HERE/'full_intersection.json').write_text(json.dumps({'all_passed':True,'coordinates':list(map(str,vs)), 'colon_generators':list(map(str,J)),'other_branch_primes':{k:list(map(str,v)) for k,v in branches.items()},'other_branch_intersection_lex':list(map(str,L)),'full_ideal_lex':list(map(str,full)),'full_ideal_grevlex':[str(f.as_expr()) for f in G.polys]},indent=2)+'\n')

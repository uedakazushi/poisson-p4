"""Positive-grading certificate of local minimality for the final polynomial ideals."""
import json
from pathlib import Path
import sympy as S
HERE=Path(__file__).resolve().parent
z=json.loads((HERE/'final_polynomial_normal_form.json').read_text())
vs=S.symbols('zeta tau ell b chi d');loc=dict(zip(map(str,vs),vs));weights=(2,2,1,1,1,1)
I=[S.sympify(f,locals=loc) for f in z['eleven_full_ideal_generators']]
J=[S.sympify(f,locals=loc) for f in z['colon_ideal_generators']]
def monomials(weight):
 def rec(i,left,prefix):
  if i==len(vs):
   if left==0:yield tuple(prefix)
   return
  for e in range(left//weights[i]+1):yield from rec(i+1,left-e*weights[i],prefix+[e])
 return list(rec(0,weight,[]))
def wdeg(f):
 wd={sum(e*w for e,w in zip(m,weights)) for m,v in S.Poly(S.expand(f),*vs).terms()};assert len(wd)==1;return next(iter(wd))
def check(gens):
 ds=list(map(wdeg,gens));rows=[]
 for k in sorted(set(ds)):
  keys=monomials(k);basis=[S.prod(v**e for v,e in zip(vs,m)) for m in keys]
  full=[];positive=[]
  for f,r in zip(gens,ds):
   if r>k:continue
   for mm in monomials(k-r):
    h=S.Poly(S.expand(f*S.prod(v**e for v,e in zip(vs,mm))),*vs)
    row=[h.coeff_monomial(m) for m in keys];full.append(row)
    if any(mm):positive.append(row)
  rankfull=S.Matrix(full).rank() if full else 0;rankpositive=S.Matrix(positive).rank() if positive else 0
  rows.append({'weighted_degree':k,'I_dimension':rankfull,'mI_dimension':rankpositive,'quotient_dimension':rankfull-rankpositive,'ambient_monomials':len(keys)})
 return rows
ci=check(I);cj=check(J)
assert [r['quotient_dimension'] for r in ci]==[3,4,4]
assert [r['quotient_dimension'] for r in cj]==[6,5]
out={'all_passed':True,'weights':dict(zip(map(str,vs),weights)),'full_ideal':ci,'colon_ideal':cj,'minimal_number_full':11,'minimal_number_colon':11,
'proof':'The polynomial ideals are homogeneous for a strictly positive grading. The quotient I/mI is therefore graded and supported in the generator weights. Exact rank differences calculate every graded piece; their sum is the minimal generator number of the localization and completion at the homogeneous maximal ideal. No degree cutoff approximation or v12 minimality assumption is used.'}
(HERE/'graded_minimality.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

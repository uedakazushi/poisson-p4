"""Substitute the 59 exact unitization relations into six polynomial coordinates."""
import json,time
from pathlib import Path
from itertools import combinations_with_replacement
import sympy as S
HERE=Path(__file__).resolve().parent
src=HERE.parent/'nil/nil_full_algebra_certificate.json'
z=json.loads(src.read_text())
ell,tau,sigma,b,c,d=S.symbols('ell tau sigma b c d')
vs=(sigma,tau,ell,b,c,d)
a=ell-b
reps=[ell,a*ell,b*ell,b*b*ell,tau,(a*a-S.Rational(9,32)*b*b)*ell,(a*b+b*b/2)*ell,b**3*ell,sigma]
names=z['basis'];ni={s:i for i,s in enumerate(names)}
polys=[];labels=[]
def add(label,f):labels.append(label);polys.append(S.expand(f))
for j,col in enumerate(z['variable_action_columns']['b']):add('b*'+names[j],b*reps[j]-sum(S.Rational(v)*e for v,e in zip(col,reps)))
for j,col in zip([4,5,6,7,8],z['axis_c_matrix_columns_without_d2']):add('c*'+names[j],c*reps[j]-d*d*sum(S.Rational(v)*e for v,e in zip(col,reps)))
for i,j in combinations_with_replacement(range(9),2):
 col=z['unordered_nonzero_products'].get(names[i]+' * '+names[j],['0']*9)
 add(names[i]+'*'+names[j],reps[i]*reps[j]-sum(S.Rational(v)*e for v,e in zip(col,reps)))
assert len(polys)==59
nonzero=[(l,p) for l,p in zip(labels,polys) if p]
print('nonzero',len(nonzero),flush=True)
start=time.time();G=S.groebner([p for l,p in nonzero],*vs,order='grevlex');print('Grevlex',len(G.polys),time.time()-start,flush=True)
gens=[p.as_expr() for p in G.polys]
for p in gens:print(S.factor(p),flush=True)
(HERE/'unitization_59_relations.json').write_text(json.dumps({'coordinates':list(map(str,vs)),'reps':list(map(str,reps)),'relations':[{'label':l,'polynomial':str(p)} for l,p in zip(labels,polys)],'number_nonzero':len(nonzero),'groebner_order':'grevlex','groebner_basis':list(map(str,gens))},indent=2)+'\n')
# deterministic redundancy deletion from the original polynomial list
keep=[p for l,p in nonzero]
# exact factor-normalized duplicates
uniq=[]
for p in keep:
 p=S.Poly(p,*vs).monic().as_expr()
 if p not in uniq:uniq.append(p)
print('normalized_unique',len(uniq),flush=True)
# Prefer retaining low-degree relations. Delete high-degree candidates first.
uniq.sort(key=lambda p:(S.total_degree(p),len(S.Poly(p,*vs).terms()),str(p)))
keep=uniq[:]
for p in uniq[::-1]:
 other=keep[:];other.remove(p)
 if not S.groebner(other,*vs,order='grevlex').reduce(p)[1]:keep=other
print('IRREDUNDANT',len(keep),flush=True)
for p in keep:print(S.factor(p),flush=True)
assert all(S.groebner(keep,*vs,order='grevlex').reduce(p)[1]==0 for p in polys)
(HERE/'unitization_compressed.json').write_text(json.dumps({'all_passed':True,'scope':'Exact polynomial ideal equivalence, not a truncation. Irredundant under generator deletion; minimal local generator count not asserted.','coordinates':list(map(str,vs)),'number_relations':len(keep),'generators':list(map(str,keep)),'groebner_basis':list(map(str,gens))},indent=2)+'\n')

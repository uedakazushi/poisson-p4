"""Universal finite constraints on arbitrary genuine equivariant torsion lifts.
No explicit coordinate normalization or guessed full lift is used.
Existence of actual lifts is supplied by the previous complete filtered theorem.
"""
import json,time,hashlib
from pathlib import Path
import sympy as s
from weighted_quotient import Quotient,V,W,wt,expr,poly
HERE=Path(__file__).resolve().parent
start=time.time();a,b,p,c,d,q=V;Q8=Quotient(8);Q6=Quotient(6)
QS={4:Quotient(4),5:Quotient(5),6:Q6}
mons=[m for m in Q8.mons if 3<=sum(m)<=5 and wt(m)==1 and m[4]%2==1]
terms=[expr({m:1}) for m in mons]
assert len(mons)==17
answers=[];origins=[];kernels=[]
h3=(a*a-s.Rational(9,32)*b*b)*d*(a+b);h4=(a*b+b*b/2)*d*(a+b);h5=b**3*d*(a+b)
base=[d*p,d*q]
expected={'a':(-s.Rational(16,9),-s.Rational(223,45)),
          'b':(s.Rational(64,9),s.Rational(568,45)),
          'p':(-s.Rational(39,46),),'q':(-s.Rational(36,23),),
          'c':(s.Rational(512,3),s.Rational(6272,15))}
for j,leading in enumerate(base):
    sol=Q8.solve(-c**3*leading,[c**3*t for t in terms]);assert len(sol)==1
    cs=next(iter(sol));free=set().union(*(v.free_symbols for v in cs))
    assert len(free)==12
    origin=[s.expand(v.subs({z:0 for z in free})) for v in cs]
    dirs=[[s.diff(v,z) for v in cs] for z in sorted(free,key=str)]
    originpoly=leading+sum(k*v for k,v in zip(origin,terms))
    kernelpolys=[sum(k*v for k,v in zip(vec,terms)) for vec in dirs]
    assert Q8.nf(c**3*originpoly)==0
    assert all(Q8.nf(c**3*t)==0 for t in kernelpolys)
    action_data={}
    for x,N,targets in [(a,4,[h3,h4]),(b,4,[h3,h4]),(p,5,[h5]),(q,5,[h5]),(c,6,[d*d*h3,d*d*h4])]:
        image=QS[N].nf(x*originpoly)
        assert all(QS[N].nf(x*t)==0 for t in kernelpolys)
        vals=next(iter(QS[N].solve(image,targets)))
        assert vals==tuple(6**j*v for v in expected[str(x)])
        action_data[str(x)]={'truncation_degree':N,'coefficients':list(map(str,vals)),
                            'independent_of_all_12_parameters':True}
    answers.append({'leading_term':str(leading),'coefficients_origin':list(map(str,origin)),
      'kernel_basis':[[str(v) for v in vec] for vec in dirs],
      'free_dimension':len(free),'constraint_rank':17-len(free),'actions':action_data})
    origins.append(originpoly);kernels.append(kernelpolys)
    print('universal actions',leading,'passed',flush=True)
products={}
for i in range(2):
 for j in range(i,2):
    kappa=-s.Rational(99,92)*6**(i+j)
    assert Q6.nf(origins[i]*origins[j]-kappa*d*h5)==0
    assert all(Q6.nf(t*origins[j])==0 for t in kernels[i])
    assert all(Q6.nf(t*origins[i])==0 for t in kernels[j])
    assert all(Q6.nf(t*u)==0 for t in kernels[i] for u in kernels[j])
    products[f'{i+1},{j+1}']={'coefficient_in_d_h5':str(kappa),
      'independent_of_both_sets_of_12_parameters':True,'truncation_degree':6}
out={'all_passed':True,'scope':'Universal finite constraints on the fifth jet of any actual d-odd weight1 axis torsion lift with initial dp or dq. Existence and all-order finite determination follow from the filtered theorem, torus and involution.',
'variables':list(map(str,V)),'weights':list(W),'unknown_exponents':[list(m) for m in mons],
'unknown_monomials':list(map(str,terms)),'annihilator':'c^3',
'annihilator_checked_through_degree':8,'solutions':answers,'products':products,
'input_jet_math_sha256':hashlib.sha256(json.dumps({k:v for k,v in json.loads((HERE/'zero_jet_8.json').read_text()).items() if k!='seconds'},sort_keys=True,separators=(',',':')).encode()).hexdigest(),
'seconds':time.time()-start}
(HERE/'axis_annihilator_lift.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASSED',time.time()-start,flush=True)

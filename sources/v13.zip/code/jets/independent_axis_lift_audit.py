"""Standard-library-only independent audit of the universal torsion-lift certificate.
Uses Fraction and sparse row elimination. Imports neither SymPy nor the
Kuranishi / quotient / normal-form code that produced the certificate.
The exact raw jet cache is an explicitly identified input.
"""
from fractions import Fraction as F
from itertools import combinations_with_replacement
from pathlib import Path
import json,time,hashlib
HERE=Path(__file__).resolve().parent;START=time.time();W=(1,1,2,-1,-1,2)
IDS=(24,25,29,43,95,97,113,115,116,128,140)
VARS=('a','b','p','c','d','q')
def mon(n):return [tuple(v.count(i) for i in range(6)) for v in combinations_with_replacement(range(6),n)]
def wt(m):return sum(a*b for a,b in zip(m,W))
def ad(m,n):return tuple(a+b for a,b in zip(m,n))
def clean(p):return {m:v for m,v in p.items() if v}
def plus(*polys):
 out={}
 for p in polys:
  for m,v in p.items():out[m]=out.get(m,F(0))+v
 return clean(out)
def scale(p,k):return clean({m:v*k for m,v in p.items()})
def times(p,q,N):
 out={}
 for m,v in p.items():
  for n,w in q.items():
   k=ad(m,n)
   if sum(k)<=N:out[k]=out.get(k,F(0))+v*w
 return clean(out)
def gen(i):return {tuple(int(i==j) for j in range(6)):F(1)}
GVAR=[gen(i) for i in range(6)];a,b,p,c,d,q=GVAR
ONE={(0,)*6:F(1)}
def power(p,n,N=8):
 out=ONE
 for _ in range(n):out=times(out,p,N)
 return out

def rowreduce(rows):
 piv={}
 for row in rows:
  v=dict(row)
  while v:
   k=min(v)
   if k not in piv:
    lead=v[k];piv[k]={i:x/lead for i,x in v.items()};break
   z=v[k]
   for i,x in piv[k].items():
    v[i]=v.get(i,F(0))-z*x
    if not v[i]:v.pop(i,None)
 return piv

def rank(rows):return len(rowreduce(rows))
Z=json.loads((HERE/'zero_jet_8.json').read_text())
CERT=json.loads((HERE/'axis_annihilator_lift.json').read_text())
RAW={i:{} for i in IDS}
for e in Z['residuals']:
 for i,j,v in e['entries']:
  if i in IDS:RAW[i][tuple(e['monomials'][j])]=F(v)

class Quotient:
 def __init__(self,N):self.N=N;self.mons=[m for n in range(N+1) for m in mon(n)];self.cache={}
 def block(self,w):
  if w in self.cache:return self.cache[w]
  keys=[m for m in self.mons if wt(m)==w];ki={m:i for i,m in enumerate(keys)}
  rows=[]
  for g0 in RAW.values():
   g={m:v for m,v in g0.items() if sum(m)<=self.N}
   if not g:continue
   weights={wt(m) for m in g};assert len(weights)==1;gw=next(iter(weights));lo=min(map(sum,g))
   for mm in self.mons:
    if sum(mm)+lo>self.N:break
    if wt(mm)+gw!=w:continue
    rows.append({ki[ad(m,mm)]:v for m,v in g.items() if sum(m)+sum(mm)<=self.N})
  piv=rowreduce(rows);self.cache[w]=(keys,ki,piv);return keys,ki,piv
 def nf(self,p):
  parts={}
  for m,v in p.items():
   if sum(m)<=self.N:parts.setdefault(wt(m),{})[m]=v
  out={}
  for w,part in parts.items():
   keys,ki,piv=self.block(w);v={ki[m]:x for m,x in part.items()}
   while v:
    k=min(v);co=v.pop(k)
    if k not in piv:out[keys[k]]=out.get(keys[k],F(0))+co;continue
    for i,x in piv[k].items():
     if i==k:continue
     v[i]=v.get(i,F(0))-co*x
     if not v[i]:v.pop(i,None)
  return clean(out)

QS={N:Quotient(N) for N in [4,5,6,8]}
mons=[tuple(m) for m in CERT['unknown_exponents']]
assert mons==[m for n in range(3,6) for m in mon(n) if wt(m)==1 and m[4]%2==1]
assert len(mons)==17
terms=[{m:F(1)} for m in mons]
c3=power(c,3)
cols=[QS[8].nf(times(c3,t,8)) for t in terms]
keys=sorted(set().union(*map(set,cols)))
matrows=[{j:col[m] for j,col in enumerate(cols) if m in col} for m in keys]
assert rank(matrows)==5
n=times(d,plus(a,b),8)
h3=times(plus(power(a,2),scale(power(b,2),-F(9,32))),n,8)
h4=times(plus(times(a,b,8),scale(power(b,2),F(1,2))),n,8)
h5=times(power(b,3),n,8)
origins=[];kernels=[];action_count=0
for j,entry in enumerate(CERT['solutions']):
 coeff=[F(x) for x in entry['coefficients_origin']]
 kern=[[F(x) for x in row] for row in entry['kernel_basis']]
 assert len(coeff)==17 and len(kern)==12 and all(len(row)==17 for row in kern)
 assert rank([{i:x for i,x in enumerate(row) if x} for row in kern])==12
 origin=plus(times(d,p if j==0 else q,8),*(scale(t,x) for t,x in zip(terms,coeff)))
 dirs=[plus(*(scale(t,x) for t,x in zip(terms,row))) for row in kern]
 assert not QS[8].nf(times(c3,origin,8))
 assert all(not QS[8].nf(times(c3,k,8)) for k in dirs)
 for name,N,targets in [('a',4,[h3,h4]),('b',4,[h3,h4]),('p',5,[h5]),('q',5,[h5]),('c',6,[times(power(d,2),h3,8),times(power(d,2),h4,8)])]:
  x=GVAR[VARS.index(name)];coef=[F(v) for v in entry['actions'][name]['coefficients']]
  diff=plus(times(x,origin,N),*(scale(t,-v) for t,v in zip(targets,coef)))
  assert not QS[N].nf(diff),(j,name)
  assert all(not QS[N].nf(times(x,k,N)) for k in dirs)
  action_count+=1
 origins.append(origin);kernels.append(dirs)
product_checks=0
for i in range(2):
 for j in range(i,2):
  k=F(CERT['products'][f'{i+1},{j+1}']['coefficient_in_d_h5'])
  assert not QS[6].nf(plus(times(origins[i],origins[j],6),scale(times(d,h5,6),-k)))
  assert all(not QS[6].nf(times(t,origins[j],6)) for t in kernels[i])
  assert all(not QS[6].nf(times(t,origins[i],6)) for t in kernels[j])
  assert all(not QS[6].nf(times(t,u,6)) for t in kernels[i] for u in kernels[j])
  product_checks+=1+12+12+144
math={k:v for k,v in Z.items() if k!='seconds'}
mathsha=hashlib.sha256(json.dumps(math,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert mathsha==CERT['input_jet_math_sha256']
out={'all_passed':True,'arithmetic':'Python standard library Fraction only','imports_authored_quotient_or_calculus':False,
'scope':'Independent finite-jet verification against exact raw eighth-order residual input. All-order statements use the separate existence/weight/involution proof.',
'input_jet_math_sha256':mathsha,'unknown_count':17,'constraint_rank':5,'affine_dimension':12,
'kernel_dimension_certified_by_independent_rank':12,'universal_low_action_checks':action_count,
'universal_low_product_checks_including_all_parameter_terms':product_checks,'seconds':time.time()-START}
(HERE/'independent_axis_lift_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

"""Extend the fixed raw Kuranishi residuals without ideal closure.
The old cache is read only; full output resides beside this script.
"""
from pathlib import Path
import json,sys,time,ast,hashlib
import sympy as s
HERE=Path(__file__).resolve().parent
BASE=next(p/n/'previous_v11/code/zero_jets' for p in [HERE,*HERE.parents] for n in ['previous_v12','p4_poisson_completeness_v12'] if (p/n/'previous_v11/code/zero_jets/zero_jet_6.json').is_file())
sys.path.insert(0,str(BASE))
from zero_full_jet import setup,atomic_json
start=time.time();sl=setup(); print('SETUP',time.time()-start,flush=True)
z=json.loads((BASE/'zero_jet_6.json').read_text())
sl.coefficients={int(k):{tuple(m):sl.C.tensor({ast.literal_eval(pair):s.sympify(f,locals=dict(zip(map(str,sl.C.x),sl.C.x))) for pair,f in pol.items()}) for m,pol in v} for k,v in z['coefficients'].items()}
entries=z['residuals']; print('LOADED',time.time()-start,flush=True)
for d in range(7,int(sys.argv[1]) + 1):
    M=sl.solve_order(d)
    sl.coefficients[d]={m:P for m,P in sl.coefficients[d].items() if any(P.values())}
    entries.append({'degree':d,'monomials':[list(m) for m in sl.monomials(d)],'entries':[[i,j,str(v)] for (i,j),v in M.todok().items() if v]})
    cache={'degree':d,'rows':350,'variables':list(map(str,sl.u)),'weights':[1,1,2,-1,-1,2],
      'source_sha256':z['source_sha256'],'baseline_sixth_jet_sha256':hashlib.sha256((BASE/'zero_jet_6.json').read_bytes()).hexdigest(),
      'residuals':entries,'coefficients':{str(j):[[list(m),sl.C.encode(P)] for m,P in sl.coefficients[j].items() if P] for j in range(1,d+1)},'seconds':time.time()-start}
    atomic_json(HERE/f'zero_jet_{d}.json',cache)
    print('SAVED',d,len(sl.coefficients[d]),len(entries[-1]['entries']),time.time()-start,flush=True)

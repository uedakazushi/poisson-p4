from pathlib import Path
import sys,time,json,hashlib
import sympy as s
from weighted_quotient import Quotient,poly,expr,wt
HERE=Path(__file__).resolve().parent
start=time.time();out={}
expected=[1,6,17,30,47,64,81,99,118]
for N in [7,8]:
    q=Quotient(N); dims={}
    for w in range(-N,2*N+1):
        keys,ki,piv,free,red=q.block(w);dims[str(w)]=len(free)
    assert sum(dims.values())==sum(expected[:N+1]),(N,sum(dims.values()))
    z=json.loads((HERE/f'zero_jet_{N}.json').read_text())
    rs={r:{} for r in range(350)}
    for e in z['residuals']:
        for i,j,v in e['entries']:rs[i][tuple(e['monomials'][j])]=s.Rational(v)
    assert all(q.nf(expr(g))==0 for g in rs.values())
    # The exact involution d -> -d: a fixed residual row has definite parity.
    parities={str(i):sorted(set(m[4]%2 for m in g)) for i,g in rs.items() if g}
    assert all(len(p)==1 for p in parities.values())
    out[str(N)]={'quotient_dimension':sum(dims.values()),'expected_dimension_from_v11_all_order_initial_ideal':sum(expected[:N+1]),'weight_block_dimensions':dims,'all_350_residuals_generated_by_selected_eleven_mod_m_power':True,'each_residual_row_has_fixed_d_parity':True,'cache_math_sha256':hashlib.sha256(json.dumps({k:v for k,v in z.items() if k!='seconds'},sort_keys=True,separators=(',',':')).encode()).hexdigest()}
    print(N,'verified',sum(dims.values()),'seconds',time.time()-start,flush=True)
out={'all_passed':True,'scope':'Exact finite jets and quotient calculations through degrees7,8. All-order lifting is a separate argument.','degrees':out,'seconds':time.time()-start}
(HERE/'high_jets_verification.json').write_text(json.dumps(out,indent=2)+'\n')

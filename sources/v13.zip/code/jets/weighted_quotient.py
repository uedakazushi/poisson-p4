"""Exact finite m-adic quotient of fixed raw eleven residual equations.
Each weight block is computed separately. All rationals are exact.
No conclusion beyond truncation is included in this module.
"""
from pathlib import Path
from itertools import combinations_with_replacement
from functools import lru_cache
import json,sys
import sympy as s
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent
BASE=next(p/n/'previous_v11/code/zero_jets' for p in [HERE,*HERE.parents] for n in ['previous_v12','p4_poisson_completeness_v12'] if (p/n/'previous_v11/code/zero_jets/zero_jet_6.json').is_file())
V=s.symbols('a b p c d q'); W=(1,1,2,-1,-1,2)
ROWS=(24,25,29,43,95,97,113,115,116,128,140)
def mon(d):
    return [tuple(v.count(i) for i in range(6)) for v in combinations_with_replacement(range(6),d)]
def wt(m):return sum(a*b for a,b in zip(m,W))
def add(m,n):return tuple(a+b for a,b in zip(m,n))
def expr(dic):return s.expand(sum(c*s.prod(x**v for x,v in zip(V,m)) for m,c in dic.items()))
def poly(f,N=None):
    return {m:c for m,c in s.Poly(s.expand(f),*V).terms() if N is None or sum(m)<=N}
class Quotient:
 def __init__(self,N):
    self.N=N;src=HERE/f'zero_jet_{N}.json'
    if not src.exists():src=BASE/f'zero_jet_{N}.json'
    z=json.loads(src.read_text());self.generators={r:{} for r in ROWS}
    for e in z['residuals']:
        for i,j,val in e['entries']:
            if i in ROWS:self.generators[i][tuple(e['monomials'][j])]=s.Rational(val)
    self.mons=[m for d in range(N+1) for m in mon(d)]
    self.blocks={}
 def block(self,w):
    if w in self.blocks:return self.blocks[w]
    keys=[m for m in self.mons if wt(m)==w];ki={m:i for i,m in enumerate(keys)}
    rows=[]
    for g in self.generators.values():
        gw=set(map(wt,g));assert len(gw)==1;gw=gw.pop();lo=min(map(sum,g))
        for mm in self.mons:
            if sum(mm)+lo>self.N:break
            if wt(mm)+gw!=w:continue
            rows.append({ki[add(m,mm)]:v for m,v in g.items() if sum(m)+sum(mm)<=self.N})
    M=s.MutableSparseMatrix(len(rows),len(keys),{(i,j):v for i,r in enumerate(rows) for j,v in r.items()})
    dm,piv=DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()
    R=dm.to_Matrix()[:len(piv),:];free=[j for j in range(len(keys)) if j not in piv]
    red={p:{keys[j]:-R[i,j] for j in free if R[i,j]} for i,p in enumerate(piv)}
    self.blocks[w]=(keys,ki,piv,free,red)
    return self.blocks[w]
 def nf(self,f):
    out={}
    for m,c in poly(f,self.N).items():
        keys,ki,piv,free,red=self.block(wt(m));r=red.get(ki[m],{m:s.Integer(1)})
        for n,v in r.items():out[n]=out.get(n,0)+c*v
    return expr({m:s.cancel(c) for m,c in out.items() if c})
 def solve(self,f,terms):
    """Solve f=sum const_i*terms_i modulo the truncated ideal.
    Returns linsolve set; free unknowns mean coefficient not determined yet.
    """
    fs=[poly(self.nf(v)) for v in [f,*terms]];keys=sorted(set().union(*map(set,fs)))
    A=s.Matrix([[g.get(m,0) for g in fs[1:]] for m in keys]);b=s.Matrix([fs[0].get(m,0) for m in keys])
    return s.linsolve((A,b))
if __name__=='__main__':
 q=Quotient(int(sys.argv[1]) if len(sys.argv)>1 else 6)
 for w in [-1,0,1,2,3,4]:
    keys,ki,piv,free,red=q.block(w);print(w,len(keys),len(piv),len(free),flush=True)

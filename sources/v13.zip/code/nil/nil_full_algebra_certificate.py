"""Independent rational verification of v13 nilradical action/product tables.

This verifier uses only Python's standard library and Fraction.  It does not
import the author's Kuranishi code, symbolic algebra, or the jet quotient.
It checks algebraic consistency of exact formulas; the accompanying proof
explains why the formulas describe the actual completed nilradical.
"""
from fractions import Fraction as F
from pathlib import Path
import json

names=('n','an','bn','b2n','t','f3','f4','f5','s')
Z=F(0); O=F(1); dim=len(names)
def vec(**kw): return [F(kw.get(k,0)) for k in names]
def add(u,v): return [a+b for a,b in zip(u,v)]
def sc(c,v): return [c*a for a in v]
def mat(cols): return [[cols[j][i] for j in range(dim)] for i in range(dim)]
def apply(M,v): return [sum(M[i][j]*v[j] for j in range(dim)) for i in range(dim)]
def mm(A,B): return mat([apply(A,[B[i][j] for i in range(dim)]) for j in range(dim)])
def ma(A,B): return [[a+b for a,b in zip(r,s)] for r,s in zip(A,B)]
def ms(c,A): return [[c*a for a in r] for r in A]
def det2(A): return A[0][0]*A[1][1]-A[0][1]*A[1][0]
def encode(v):
    if isinstance(v,F): return str(v)
    if isinstance(v,list) or isinstance(v,tuple): return [encode(x) for x in v]
    if isinstance(v,dict): return {str(k):encode(x) for k,x in v.items()}
    return v
E=[vec(**{n:1}) for n in names]
zero=vec()
A=mat([
 vec(an=1),vec(b2n=F(9,32),f3=1),vec(b2n=F(-1,2),f4=1),
 vec(f5=F(-127,184)),vec(f3=F(-16,9),f4=F(-223,45)),
 vec(f5=F(-4135,11776)),vec(f5=F(85,368)),zero,zero])
B=mat([
 vec(bn=1),vec(b2n=F(-1,2),f4=1),vec(b2n=1),vec(f5=1),
 vec(f3=F(64,9),f4=F(568,45)),vec(f5=F(217,736)),
 vec(f5=F(-35,184)),zero,zero])
P=mat([
 vec(b2n=F(-9,8),f3=-4,f4=-8),vec(f5=F(981,2944)),
 vec(f5=F(-18,23)),zero,vec(f5=F(-39,46)),zero,zero,zero,zero])
Q=mat([
 vec(b2n=F(177,4),f3=40,f4=128),vec(f5=F(-22113,1472)),
 vec(f5=F(729,23)),zero,vec(f5=F(-36,23)),zero,zero,zero,zero])
ops={'a':A,'b':B,'p':P,'q':Q}
for x,X in ops.items():
 for y,Y in ops.items(): assert mm(X,Y)==mm(Y,X),(x,y)

# Multiplication on actual N is d times this constant tensor mu.
tab={}
def put(i,j,v):
 tab[(i,j)]=v;tab[(j,i)]=v
put(0,0,vec(an=1,bn=1))
put(0,1,vec(b2n=F(-7,32),f3=1,f4=1))
put(0,2,vec(b2n=F(1,2),f4=1))
put(0,3,vec(f5=F(57,184)))
put(1,1,vec(f5=F(363,11776)))
put(1,2,vec(f5=F(-21,184)))
put(2,2,vec(f5=F(57,184)))
put(0,4,vec(f3=F(16,3),f4=F(23,3)))
put(0,5,vec(f5=F(-663,11776)))
put(0,6,vec(f5=F(15,368)))
put(1,4,vec(f5=F(-75,736)))
put(2,4,vec(f5=F(21,184)))
put(4,4,vec(f5=F(-99,92)))
def mu(u,v):
 out=vec()
 for i,ui in enumerate(u):
  if ui:
   for j,vj in enumerate(v):
    if vj: out=add(out,sc(ui*vj,tab.get((i,j),zero)))
 return out
for i in range(dim):
 for j in range(dim):
  assert mu(E[i],E[j])==mu(E[j],E[i])
  for k in range(dim):
   assert mu(mu(E[i],E[j]),E[k])==mu(E[i],mu(E[j],E[k])),(i,j,k)
  for x,X in ops.items():
   assert apply(X,mu(E[i],E[j]))==mu(apply(X,E[i]),E[j]),(x,i,j)
assert mat([mu(E[0],e) for e in E])==ma(A,B)
At=ms(F(1,3),ma(ms(F(28),A),ms(F(19),B)))
assert mat([mu(E[4],e) for e in E])==ma(P,mm(At,ma(A,B)))
assert all(mu(E[-1],e)==zero for e in E)

# Coordinate action of the exact unitization C=S direct_sum M, where
# multiplication internal to M is mu (not d*mu).
Mu=[mat([mu(e,x) for x in E]) for e in E]
assert ma(Mu[0],ms(F(-1),B))==A
assert ma(Mu[4],ma(ms(F(-28,3),Mu[1]),ms(F(-19,3),Mu[2])))==P
assert ma(ms(F(9),mm(B,B)),ma(ms(F(6),Mu[4]),ma(Mu[8],ma(ms(F(8),Mu[1]),ms(F(74),Mu[2])))))==Q
u=vec(t=1,an=F(-28,3),bn=F(-19,3))
v=vec(t=6,s=1,an=8,bn=74)
Rop=ma(Q,ms(F(-9),mm(B,B)))
assert apply(P,E[0])==apply(ma(A,B),u)
assert apply(Rop,E[0])==apply(ma(A,B),v)
assert apply(P,v)==apply(Rop,u)

# The nine positive-coordinate polynomial generators used in the final
# full-ring presentation vanish in the explicit unitization.  The two
# remaining generators chi*tau and chi*sigma vanish because chi kills T.
ell=E[0]; tau=E[4]; sigma=E[8]
ell2=mu(ell,ell);ell3=mu(ell,ell2);ell4=mu(ell,ell3)
Pnil=add(tau,add(sc(F(3),apply(B,ell)),sc(F(-8),ell2)))
Qnil=add(sigma,add(sc(F(6),tau),add(sc(F(-30),apply(B,ell)),sc(F(16),ell2))))
Hnil=add(sc(F(3),Pnil),add(Qnil,sc(F(15),apply(B,ell))))
Fvalue=add(sc(F(14),mu(ell,Pnil)),add(sc(F(-15),apply(B,Pnil)),add(sc(F(3),mu(ell,Qnil)),sc(F(27),apply(B,apply(B,ell))))))
PHvalue=add(mu(Pnil,Hnil),sc(F(9),apply(B,apply(B,Pnil))))
assert Fvalue==zero and PHvalue==zero
assert mu(sigma,sigma)==zero and apply(B,sigma)==zero
assert add(sc(F(92),mu(tau,tau)),sc(F(99),apply(B,apply(B,apply(B,ell)))))==zero
assert add(sc(F(3),mu(ell,tau)),add(sc(F(9),apply(B,ell2)),sc(F(-16),ell3)))==zero
assert add(sc(F(15),apply(B,tau)),add(sc(F(-20),mu(ell,tau)),add(sc(F(18),apply(B,apply(B,ell))),sc(F(-36),apply(B,ell2)))))==zero
assert add(sc(F(11776),ell4),sc(F(-1323),apply(B,apply(B,apply(B,ell)))))==zero
assert add(sc(F(184),apply(B,apply(B,ell2))),sc(F(-57),apply(B,apply(B,apply(B,ell)))))==zero

# Cyclic rank-four axis block, and exact nonunital product.
t=E[4]; at=apply(A,t);bt=apply(B,t)
a2t=apply(A,at);abt=apply(A,bt);b2t=apply(B,bt)
assert a2t==vec(f5=F(-383,736))
assert abt==vec(f5=F(77,184))
assert b2t==vec(f5=F(-7,23))
assert sc(F(224),a2t)==sc(F(383),b2t)
assert sc(F(8),abt)==sc(F(-11),b2t)
assert apply(P,t)==sc(F(39,14),b2t)
assert apply(Q,t)==sc(F(36,7),b2t)
assert mu(t,t)==sc(F(99,28),b2t)
assert det2([[at[5],bt[5]],[at[6],bt[6]]])==F(64,5)
assert det2([[A[7][5],A[7][6]],[B[7][5],B[7][6]]])==F(-2835,2166784)

# Rational ranks and spans; row vectors, standard exact Gaussian elimination.
def basis(rows):
 p={}
 for row in rows:
  v=row[:]
  for j in sorted(p):
   if v[j]: v=add(v,sc(-v[j],p[j]))
  piv=next((j for j,c in enumerate(v) if c),None)
  if piv is not None:p[piv]=sc(1/v[piv],v)
 return list(p.values())
def same_span(rows,expected):
 a=basis(rows); b=basis(expected)
 return len(a)==len(b)==len(basis(a+b))
powers={1:E}
for k in range(2,6): powers[k]=basis([mu(u,v) for u in powers[k-1] for v in E])
assert [len(powers[k]) for k in range(1,6)]==[9,4,2,1,0]
w1=vec(an=1,bn=1);w2=vec(b2n=F(1,2),f4=1)
h=vec(f3=16,f4=23);s5=vec(f5=1)
v3=vec(b2n=F(9,32),f3=1,f4=2)
assert same_span(powers[2],[w1,w2,h,s5])
assert same_span(powers[3],[v3,s5])
assert same_span(powers[4],[s5])
n4=mu(mu(mu(E[0],E[0]),E[0]),E[0])
assert n4==vec(f5=F(1323,11776))

# The exact axis block action is C=d^2 C0, C0=8 B-64 A.  The actual
# c-action on the four free A-generators is scalar c, not this C0.
axis_ids=(4,5,6,7,8)
C0=ma(ms(F(-64),A),ms(F(8),B))
for X in (A,B,C0):
 for i in axis_ids:
  for j in range(dim):
   assert mu(apply(X,E[i]),E[j])==apply(X,mu(E[i],E[j]))
ct=apply(C0,t);c2t=apply(C0,ct)
assert ct==vec(f3=F(512,3),f4=F(6272,15))
assert c2t==vec(f5=F(-59328,23))
assert apply(C0,c2t)==zero
assert apply(C0,E[5])==vec(f5=F(4569,184))
assert apply(C0,E[6])==vec(f5=F(-375,23))
k=vec(f3=1000,f4=1523)
assert apply(C0,k)==zero
assert len(basis([t,ct,c2t,k,E[8]]))==5
assert apply(C0,h)==vec(f5=F(513,23))
assert [len(basis([apply(C0,e) for e in [E[i] for i in axis_ids]])),
        len(basis([apply(C0,apply(C0,e)) for e in [E[i] for i in axis_ids]]))]==[2,1]

out={
 'basis':list(names),'variable_action_columns':{x:[[str(X[i][j]) for i in range(dim)] for j in range(dim)] for x,X in ops.items()},
 'multiplication_factor':'d','unordered_nonzero_products':{f'{names[i]} * {names[j]}':encode(v) for (i,j),v in tab.items() if i<=j},
 'associativity_basis_triples_checked':dim**3,'positive_operator_pairs_checked':16,
 'unitization_coordinate_action_checks':['a=-b+m0','p=m4-28*m1/3-19*m2/3','q=9*b^2+6*m4+m8+8*m1+74*m2'],
 'K16_koszul_syzygies_checked':3,
 'final_full_ring_generator_unitization_membership_checks':11,
 'centroid_basis_pair_checks':4*dim**2,
 'constant_algebra_power_dimensions':[len(powers[k]) for k in range(1,6)],
 'axis_block_quadratic_relations':['224*a^2-383*b^2','8*a*b+11*b^2'],
 'axis_block_p_action':'39*b^2/14','axis_block_q_action':'36*b^2/7',
 'axis_block_c_action':'8*d^2*(b-8*a)',
 'axis_c_matrix_columns_without_d2':[encode(apply(C0,E[i])) for i in axis_ids],
 'axis_jordan_basis':[encode(v) for v in [t,ct,c2t,k,E[8]]],
 'axis_generic_c_jordan_type':[3,1,1],
 'axis_A_module':'M_3(d^2) direct_sum (A/(c))^2',
 'N2_torsion_c_coefficient':'513/23',
 'axis_nonunital_product':'(99/28)*d*b^2*f*g',
 'n_fourth_coefficient':str(F(1323,11776)),
 'scope':'Exact consistency certificate; finite-jet-to-all-orders proof is in companion text.'}
path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'verified':True,'basis_size':dim,'associativity_checks':dim**3,'constant_power_dimensions':out['constant_algebra_power_dimensions'],'output':str(path)}))

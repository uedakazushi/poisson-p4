"""Independent exact rational verification of v13 axis actions and normal forms.
Standard library only: imports no SymPy, Kuranishi calculus, or author row reducer.
All powers of d are represented as sparse univariate polynomials over Fraction.
"""
from fractions import Fraction as F
from pathlib import Path
import json
from itertools import combinations, permutations

def p(x=0,k=0):
    x=F(x); return {k:x} if x else {}
def add(x,y):
    z=x.copy()
    for k,v in y.items():
        z[k]=z.get(k,F(0))+v
        if not z[k]:del z[k]
    return z
def neg(x):return {k:-v for k,v in x.items()}
def sub(x,y):return add(x,neg(y))
def mul(x,y):
    z={}
    for i,u in x.items():
        for j,v in y.items():z=add(z,p(u*v,i+j))
    return z
def scale(x,v,k=0):return mul(x,p(v,k))
def zero(n=5,m=5):return [[{} for j in range(m)] for i in range(n)]
def eye(n=5):
    x=zero(n,n)
    for i in range(n):x[i][i]=p(1)
    return x
def madd(x,y):return [[add(a,b) for a,b in zip(r,s)] for r,s in zip(x,y)]
def msub(x,y):return [[sub(a,b) for a,b in zip(r,s)] for r,s in zip(x,y)]
def mscale(x,v,k=0):return [[scale(a,v,k) for a in r] for r in x]
def mmul(x,y):
    z=zero(len(x),len(y[0]))
    for i in range(len(x)):
        for j in range(len(y[0])):
            for k in range(len(y)):z[i][j]=add(z[i][j],mul(x[i][k],y[k][j]))
    return z
def col(x,j):return [[row[j]] for row in x]
def columns(*cols):return [[cc[i][0] for cc in cols] for i in range(5)]
def const_inverse(mat):
    n=len(mat);x=[[entry.get(0,F(0)) for entry in row]+[F(i==j) for j in range(n)] for i,row in enumerate(mat)]
    assert all(all(set(e)<= {0} for e in row) for row in mat)
    det=F(1)
    for j in range(n):
        k=next(k for k in range(j,n) if x[k][j])
        if k!=j:x[j],x[k]=x[k],x[j];det=-det
        v=x[j][j];det*=v;x[j]=[a/v for a in x[j]]
        for k in range(n):
            if k!=j:
                v=x[k][j];x[k]=[a-v*b for a,b in zip(x[k],x[j])]
    return [[p(v) for v in row[n:]] for row in x],det

a,b,pp,q,c=[zero() for _ in range(5)]
for op,vals in [(a,[(2,0,'-16/9'),(3,0,'-223/45'),(4,2,'-4135/11776'),(4,3,'85/368')]),(b,[(2,0,'64/9'),(3,0,'568/45'),(4,2,'217/736'),(4,3,'-35/184')])]:
    for i,j,v in vals:op[i][j]=p(v)
    for i in range(5):op[i][1]=scale(op[i][0],6)
pp[4][0]=p('-39/46');pp[4][1]=p('-117/23')
q[4][0]=p('-36/23');q[4][1]=p('-216/23')
c[2][0]=p('512/3',2);c[3][0]=p('6272/15',2)
c[4][2]=p('4569/184',2);c[4][3]=p('-375/23',2)
for i in range(5):c[i][1]=scale(c[i][0],6)
d=mscale(eye(),1,1)
ops={'a':a,'b':b,'p':pp,'q':q,'c':c,'d':d}
checks=[]
for name,x in ops.items():
    for name2,y in ops.items():assert mmul(x,y)==mmul(y,x)
checks.append('all_36_operator_commutators_zero')
assert c==mscale(msub(b,mscale(a,8)),8,2)
checks.append('c_equals_8_d_squared_b_minus_8a')

# Symmetric D-bilinear product tensor of T.
products=[[zero(5,1) for j in range(5)] for i in range(5)]
for i in range(2):
    for j in range(2):products[i][j][4][0]=p(F(-99,92)*6**(i+j),1)
def times(x,y):
    z=zero(5,1)
    for i in range(5):
        for j in range(5):
            v=mul(x[i][0],y[j][0])
            for k in range(5):z[k][0]=add(z[k][0],mul(v,products[i][j][k][0]))
    return z
I=eye();basis=[col(I,j) for j in range(5)]
for x in basis:
    for y in basis:
        assert times(x,y)==times(y,x)
        for z in basis:assert times(times(x,y),z)==times(x,times(y,z))
        for name,op in ops.items():assert times(mmul(op,x),y)==mmul(op,times(x,y))
checks.append('125_associativity_and_150_module_product_compatibility_identities')

# The cyclic rank4 summand and the primitive rank1 axis socle.
e=basis[0];s=msub(basis[1],mscale(e,6));b2=mmul(b,b)
Kchange=columns(e,mmul(a,e),mmul(b,e),mmul(b2,e),s)
Kinv,Kdet=const_inverse(Kchange)
assert mmul(Kinv,Kchange)==I
for op in [a,b,pp,q,c]:assert mmul(op,s)==zero(5,1)
for x in basis:assert times(s,x)==zero(5,1)
assert msub(mscale(mmul(a,a),224),mscale(b2,383))==zero()
assert madd(mscale(mmul(a,b),8),mscale(b2,11))==zero()
assert mscale(pp,14)==mscale(b2,39)
assert mscale(q,7)==mscale(b2,36)
assert mmul(b2,b)==zero()
for x in basis:assert times(e,x)==mmul(mscale(b2,'99/28',1),x)
checks.append('cyclic_K_plus_axis_socle_and_full_nonunital_product')

# Explicit D-basis for the A-module Jordan lattice.
v=msub(b,mscale(a,8));w=madd(mscale(a,224),mscale(b,281))
assert mmul(v,v)==mscale(b2,'927/7')
assert mmul(v,w)==zero()
Mchange=columns(e,mscale(mmul(v,e),8),mscale(mmul(mmul(v,v),e),64),mmul(w,e),s)
Minv,Mdet=const_inverse(Mchange)
Cnormal=mmul(mmul(Minv,c),Mchange)
expected=zero();expected[1][0]=p(1,2);expected[2][1]=p(1,2)
assert Cnormal==expected
assert mmul(mmul(c,c),c)==zero()
C2=mmul(c,c)
assert C2[4][0]==p('-59328/23',4)
checks.append('A_module_M3_plus_two_axis_lines_and_Smith_factors')

# Fitting ideals from every minor of the explicit five-generator A presentation.
# Every nonzero minor is a monomial, so divisibility minimization is exact.
Pres=[[{} for _ in range(5)] for _ in range(5)]
for i in range(5):Pres[i][i]={(1,0):F(1)}
Pres[1][0]={(0,2):F(-1)};Pres[2][1]={(0,2):F(-1)}
def bipmul(x,y):
    z={}
    for (i,j),u in x.items():
        for (k,l),v in y.items():
            exp=(i+k,j+l);z[exp]=z.get(exp,F(0))+u*v
            if not z[exp]:del z[exp]
    return z
fitting={}
for size in range(1,6):
    monomials=set()
    for rows in combinations(range(5),size):
        for cols in combinations(range(5),size):
            det={}
            for perm in permutations(range(size)):
                sign=(-1)**sum(perm[i]>perm[j] for i in range(size) for j in range(i+1,size))
                term={(0,0):F(sign)}
                for i,j in enumerate(perm):term=bipmul(term,Pres[rows[i]][cols[j]])
                for exp,val in term.items():
                    det[exp]=det.get(exp,F(0))+val
                    if not det[exp]:del det[exp]
            if det:
                assert len(det)==1
                monomials.add(next(iter(det)))
    minimal=sorted([m for m in monomials if not any(n!=m and all(u<=v for u,v in zip(n,m)) for n in monomials)],reverse=True)
    fitting[5-size]=minimal
assert fitting=={0:[(5,0)],1:[(4,0),(3,2),(2,4)],2:[(3,0),(2,2),(1,4)],3:[(2,0),(1,2),(0,4)],4:[(1,0),(0,2)]}
checks.append('all_251_nonempty_minors_and_Fitting_ideals')

def encode_mat(mat):return [[[[k,str(v)] for k,v in sorted(entry.items())] for entry in row] for row in mat]
out={'all_passed':True,'arithmetic':'Python standard-library Fraction, sparse polynomials in d',
'checks':checks,'basis':['t1','t2','f3','f4','f5'],
'operators':{name:encode_mat(op) for name,op in ops.items()},
'K_change_of_basis_determinant':str(Kdet),'M3_change_of_basis_determinant':str(Mdet),
'K_change_of_basis':encode_mat(Kchange),'M3_change_of_basis':encode_mat(Mchange),
'normal_c_matrix':encode_mat(Cnormal),
'K_relations':['224a^2-383b^2','8ab+11b^2','14p-39b^2','7q-36b^2','c-8d^2(b-8a)'],
'T_product':'(f,lambda)*(g,mu)=((99/28)d*b^2*f*g,0)',
'Fitting_ideals_monomial_exponents_c_d':fitting,
'nonzero_Smith_factors_c':['d^2','d^2'],'nonzero_Smith_factors_c_squared':['d^4'],
'Jordan_type_generic':[3,1,1],'Jordan_type_d_zero':[1,1,1,1,1],
'c_squared_t1_coefficient_d4f5':'-59328/23',
'limitations':'Certifies rational algebra identities. Actual action identification requires the full-jet universal-lift proof and all-order weight/involution constraints.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['all_passed','checks','K_change_of_basis_determinant','M3_change_of_basis_determinant']},indent=2))

"""Exact ambient involution preserving the fixed full Kuranishi slice.

The map is P -> -G_* P with G=diag(-1,1,-1,1,-1).  The proof of
all-order descent uses stability of the actual implicit complement and
uniqueness of the implicit solution, not inspection of a finite jet.
"""
from pathlib import Path
import json, sys
import sympy as s

HERE = Path(__file__).resolve().parent
BASE = next(p / name for p in [HERE, *HERE.parents]
            for name in ('previous_v12', 'p4_poisson_completeness_v12')
            if (p / name / 'HANDOFF.txt').is_file())
sys.path.insert(0, str(BASE / 'previous_v11/code/zero_jets'))
from zero_full_jet import setup

sl = setup()
C = sl.C
signs = (-1, 1, -1, 1, -1)
def sign_of(I, m, scalar):
    return scalar * s.prod(signs[i] for i in I) * s.prod(g ** e for g, e in zip(signs, m))

input_signs = [sign_of(I, m, -1) for I, m in C.basis]
output_signs = [sign_of(I, m, 1) for I, m in C.projective_basis]
U = s.diag(*input_signs)
V = s.diag(*output_signs)
assert U * C.vector(sl.P) == C.vector(sl.P)
assert U * U == s.eye(150)
coordinate_signs = (1, 1, 1, 1, -1, 1)
assert all(U * R == g * R for R, g in zip(sl.Rv, coordinate_signs))
# The derivative of E wedge Jacobi transforms equivariantly.  Its selected
# rows, as well as all coordinate columns in the implicit complement, are
# invariant because both ambient representations are diagonal.
assert sl.D * U == V * sl.D
implicit_signs = [input_signs[j] for j in sl.wcols]
assert U * sl.W == sl.W * s.diag(*implicit_signs)
assert sl.Mi * V[sl.rows, sl.rows] == s.diag(*implicit_signs) * sl.Mi

out = {
    'all_passed': True,
    'ambient_coordinate_matrix_diagonal': list(signs),
    'bivector_scalar': -1,
    'P0_fixed': True,
    'raw_slice_coordinates': list(map(str, sl.u)),
    'raw_slice_coordinate_signs': list(coordinate_signs),
    'ambient_input_dimension': 150,
    'projective_Jacobi_output_dimension': 350,
    'implicit_dimension': len(sl.wcols),
    'implicit_coordinate_complement_stable': True,
    'selected_implicit_equations_stable': True,
    'derivative_equivariance': True,
    'all_order_argument': 'The polynomial Jacobi map is equivariant. The fixed affine slice and the selected invertible implicit system are invariant. Uniqueness of its formal solution induces the exact involution (a,b,p,c,d,q)->(a,b,p,c,-d,q).',
}
HERE.joinpath('involution.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))

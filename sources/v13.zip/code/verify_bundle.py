"""Read-only verification of the v13 manifest and unchanged v12 bundle."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
z=json.loads((ROOT/'manifest.json').read_text())
actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p!=ROOT/'manifest.json'}
assert actual==set(z['files']),{'missing':sorted(set(z['files'])-actual),'extra':sorted(actual-set(z['files']))}
for p,h in z['files'].items():assert sha(ROOT/p)==h,p
old=ROOT/'previous_v12';mz=json.loads((old/'manifest.json').read_text())
for p,h in mz['files'].items():assert sha(old/p)==h,'previous_v12/'+p
pres=json.loads((ROOT/'data/previous_v12_preservation.json').read_text())
for p,h in pres['files'].items():assert sha(old/p)==h,p
assert {str(p.relative_to(old)) for p in old.rglob('*') if p.is_file()}==set(pres['files'])
print(json.dumps({'all_passed':True,'manifest_files_verified':len(z['files']),'previous_v12_files_unchanged':len(pres['files'])},indent=2))

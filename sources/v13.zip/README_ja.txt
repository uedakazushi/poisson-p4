射影4空間の Poisson 構造 — 研究継続ノート 第13版
=================================================

今回の結論
----------
零磁気点 P_* の全非被約完備局所環を、6変数・最小11本の有限多項式で決定した。
前版の代数的形式冪級数11本を切り詰めた近似ではなく、適切な形式座標における全環の表示である。
最大通常次数5、初項の位数は二次4本・三次5本・五次2本。
全 Poisson スキームの完成環には21個の滑らかな変数を加える。
PGL5商は取らない。すべて複素数上の次元。
大域的な完全分類は未完であり、本研究の大域成分数の下界57は変更しない。

本文と主要データ
----------------
p4_poisson_completeness_v13.pdf : 日本語本文、全証明の説明、11多項式、全冪零乗法表。
p4_poisson_completeness_v13.tex、preamble.tex、sections/ : LuaLaTeXソース。
proofs/ : 各段階の詳しい証明と依存関係。
code/reconstruction/final_polynomial_normal_form.json : 最終11多項式、座標変換、各枝、商イデアル。
code/nil/nil_full_algebra_certificate.json : 全9生成元の作用行列と乗法表。
code/jets/axis_annihilator_lift.json : 任意の実際の軸基底を制約する有限線形証明書。
HANDOFF.txt : 次回研究用の詳細な引継ぎ。解決済みの局所問題を未決定扱いしないこと。
previous_v12/ : 第12版の913ファイルをすべて変更せず収録。第11版以前も再帰的に含む。

再現
----
Python 3と SymPy 1.14.0を用いる。標準ライブラリだけで動く独立検算器も3本ある。

  python3 code/run_checks.py --output /tmp/p4_v13_checks

標準実行は11項目。隔離コピーで実行し、すべての数学的JSONを収録値と比較する。
七・八次の係数自体を六次の保存済み入力から再生成する場合は、次を用いる。

  python3 code/run_checks.py --regenerate-high-jets --output /tmp/p4_v13_checks_regenerated

七・八次の全350式の確認を省略し、他の10項目だけを再現する場合は --skip-high-jets を使う。
検証結果は data/reproduced/。経過時間の4種類のキーだけを比較対象から除く。

  python3 code/verify_bundle.py

は収録ファイルと前版のSHA256を読み取りのみで照合する。
PDFは LuaLaTeX、LuaTeX-ja、HaranoAji フォントを用い、次で再ビルドできる。

  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v13.tex

論理上の区別
------------
1. 実際の対合と全次数の持ち上げ存在が、有限計算を適用できる根拠。
2. 有限制約の全解で作用が一定なことと、重み・偶奇による高次補正の排除を併用する。
3. N=dK16の具体的な埋め込みを使い、I:d、単位化、六枝との交わりで全環を再構成する。
4. Gröbner証明書は多項式イデアルの全等式を検査する。有限jetの外挿ではない。
5. raw c と新しい chi=c-8d^2(b-8a) は異なる作用素。cTは非零、chiTは零。
6. 正の重みに関する斉次性と通常の接錐は異なる。通常の接錐との非同型は前版のまま。

次の研究対象
------------
零磁気点の全局所環の未決定係数は解消した。
未被覆の階数4・階数2領域、他の境界型、成分排除の大域的議論へ進む。

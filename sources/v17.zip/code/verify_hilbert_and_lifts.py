#!/usr/bin/env python3
"""Exact supplementary dimension/Hilbert checks using Python's standard library."""
from fractions import Fraction as Q
from itertools import combinations, combinations_with_replacement
from math import comb
import json


def rank(matrix):
    a = [[Q(x) for x in row] for row in matrix]
    r = 0
    for c in range(len(a[0]) if a else 0):
        p = next((i for i in range(r, len(a)) if a[i][c]), None)
        if p is None:
            continue
        a[p], a[r] = a[r], a[p]
        pivot = a[r][c]
        a[r] = [x / pivot for x in a[r]]
        for i in range(r + 1, len(a)):
            if a[i][c]:
                f = a[i][c]
                a[i] = [x - f * y for x, y in zip(a[i], a[r])]
        r += 1
        if r == len(a):
            break
    return r


def main():
    columns = []
    for i, j in combinations(range(5), 2):
        for u, v in combinations_with_replacement(range(5), 2):
            mon = [0] * 5
            mon[u] += 1
            mon[v] += 1
            if sum(mon[2:]):
                columns.append((i, j, mon))
    assert len(columns) == 120
    delta = [[0] * 120 for _ in range(25)]
    for c, (i, j, mon) in enumerate(columns):
        for derivative, target, sign in ((i, j, 1), (j, i, -1)):
            if mon[derivative]:
                residual = mon[:]
                residual[derivative] -= 1
                delta[5 * target + residual.index(1)][c] += sign * mon[derivative]
    pure = [c for c, (_, _, mon) in enumerate(columns) if sum(mon[2:]) == 2]
    assert len(pure) == 60
    full_rank = rank(delta)
    pure_rank = rank([[row[c] for c in pure] for row in delta])
    assert full_rank == 24 and pure_rank == 14
    canonical_dimension = 120 - full_rank
    pure_kernel = 60 - pure_rank
    admissible_first_normal = canonical_dimension - pure_kernel
    assert (canonical_dimension, pure_kernel, admissible_first_normal) == (96, 46, 50)
    # The projective jet rank36 is independently certified by verify_line_jet.py.
    assert admissible_first_normal - 36 == 14

    h = [1, 3, 6, 10, 10, 6, 3, 1]
    factor = [1, -3, 3, -1]
    product = [0] * (len(h) + len(factor) - 1)
    for i, a in enumerate(h):
        for j, b in enumerate(factor):
            product[i + j] += a * b
    assert product == [1, 0, 0, 0, -5, 0, 5, 0, 0, 0, -1]
    degree = sum(h)
    weighted_sum = sum(i * value for i, value in enumerate(h))
    genus = 1 - degree + weighted_sum
    assert (degree, weighted_sum, genus) == (40, 140, 101)
    assert h == h[::-1] and 2 * genus - 2 == 5 * degree
    for n in range(7, 20):
        assert sum(h[i] * (n - i + 1) for i in range(len(h))) == 40 * n - 100
    original_cubic = 3 * comb(5, 2) + 2 * comb(6, 2) + comb(7, 2)
    fixed_cube = 3 + 2 * comb(6, 2) + comb(7, 2)
    quartic = 2 * comb(6, 2) + comb(7, 2)
    assert (original_cubic, fixed_cube, quartic) == (81, 54, 51)
    print(json.dumps({
        "all_passed": True,
        "arithmetic": "Python standard-library Fraction and integer arithmetic",
        "divergence_rank": full_rank,
        "pure_normal_quadratic_divergence_rank": pure_rank,
        "pure_normal_quadratic_kernel": pure_kernel,
        "admissible_first_ambient_normal_dimension": admissible_first_normal,
        "extra_ambient_lift_parameters_beyond_projective_jet": 14,
        "h_vector": h,
        "degree": degree,
        "weighted_sum": weighted_sum,
        "arithmetic_genus": genus,
        "canonical_degree_check": "2*101-2=5*40",
        "quintic_coefficient_counts": {
            "triple_line_unrestricted": original_cubic,
            "fixed_pure_cube": fixed_cube,
            "multiplicity_four": quartic
        },
        "scope": "Exact necessary dimension and Hilbert identities; no existence or classification assertion"
    }, indent=2))


if __name__ == "__main__":
    main()

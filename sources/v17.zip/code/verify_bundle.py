#!/usr/bin/env python3
"""Read-only validation of the v17 archive and byte-preserved v16 history."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    expected = {}
    for line in (ROOT / "SHA256SUMS.txt").read_text().splitlines():
        value, name = line.split("  ", 1)
        expected[name] = value
    actual = {p.relative_to(ROOT).as_posix(): digest(p) for p in ROOT.rglob("*")
              if p.is_file() and p != ROOT / "SHA256SUMS.txt"
              and "__pycache__" not in p.parts and p.suffix != ".pyc"}
    assert actual == expected, "Archive differs from SHA256SUMS.txt"
    history = json.loads((ROOT / "data/previous_v16_preservation.json").read_text())
    prior_root = ROOT / "previous_v16"
    prior = {p.relative_to(prior_root).as_posix(): digest(p)
             for p in prior_root.rglob("*") if p.is_file()}
    expected_prior = {row["path"]: row["sha256"] for row in history["files"]}
    assert prior == expected_prior, "Historical v16 contents changed"
    assert len(prior) == history["count"] == 1339
    print(json.dumps({"all_passed": True, "all_files_verified": len(actual),
                      "historical_files_verified": len(prior)}, indent=2))


if __name__ == "__main__":
    main()

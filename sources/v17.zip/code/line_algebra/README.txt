v17 line algebra working package
================================

All files are new and confined to this working directory. Prior-version
artifacts have not been edited. No publication/save operation is performed
by these programs.

Proof note:
  line_algebra_proof.tex

Exact certificate data:
  line_first_jet.json
  singular_pencil_A_solutions.json
  first_jet_gauge.json
  line_first_jet_independent_verification.json
  leading_pfaffian_independent_verification.json

Regenerate linear certificates (requires SymPy):
  python3 build_line_jet.py
  python3 build_gauge.py

Independent checks (Python standard library only):
  python3 verify_line_jet.py
  python3 verify_leading_pfaffian.py

Every program resolves its directory using __file__, so this folder can be
relocated. In the current environment SymPy is available by setting
PYTHONPATH=/tmp/p4_v6_math for the two generation commands.

Established exact algebra:
* The canonical lift space has dimension 96.
* First normal jets are all pairs A in sl3 tensor H0(O2), B symmetric
  tensor H0(O1), a 36-dimensional space; the kernel has dimension 60.
* Six explicit singular-pencil cases have A-solution dimensions
  8,8,9,6,15,24 and unipotent-coordinate quotient dimensions
  2,2,3,0,11,24. This is not a pencil-classification theorem.
* Leading Pfaffian-gradient identities are computed independently.
* Primitive moving nilpotent rank-one lower blocks are inconsistent;
  a constant -2 linear combination of required coefficients certifies it.
* The unified multiplicity-three first-order normal form and its three
  displayed scalar identities are symbolically checked without sampling.

Geometric inputs used by the proof note, proved by sibling/parent work:
* The inactive line has P|cone(L)=0 and F in I_L^3.
* The canonical quadratic lift satisfies grad(F)=signed_Pfaffians(P).
* The full five-dimensional isotropy along cone(L) is nilpotent under
  the normal-degeneracy hypotheses.
* When F3 is nonzero, it is a binary quadratic times the cube of one
  fixed normal linear form.

Scope limits:
These are necessary conditions on closed points and exact linear maps.
The 46 remaining pure-normal quadratic lift directions have not been
subjected to all higher Jacobi equations. The data do not establish the
existence or nonexistence of normal Poisson degeneracy quintics with this
support, nor new irreducible components, scheme structures, or moduli
dimensions. In particular, B=A=0 only implies F3=0; it is not eliminated
by this package.

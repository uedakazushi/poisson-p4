#!/usr/bin/env python3
"""Exact first-jet coordinate-gauge certificates. Full Jacobi is not assumed."""
from pathlib import Path
import json
import sympy as sp

ROOT=Path(__file__).resolve().parent
s,t=sp.symbols('s t')
coeffs=sp.symbols('u0:6')
xi=sp.Matrix([coeffs[2*i]*s+coeffs[2*i+1]*t for i in range(3)])
cross=sp.Matrix([[0,-xi[2],xi[1]],[xi[2],0,-xi[0]],[-xi[1],xi[0],0]])
quad=[s*s,s*t,t*t]

def encode(q):
 q=sp.Rational(q)
 return [int(q.p),int(q.q)]

def sparse(M):
 return [[i,j,encode(M[i,j])] for i in range(M.rows) for j in range(M.cols) if M[i,j]]

def vector(A):
 return sp.Matrix([sp.expand(A[i,j]).coeff(s,2-k).coeff(t,k)
                   for i in range(3) for j in range(3) if (i,j)!=(2,2)
                   for k in range(3)])

def elementary(i,j,p):
 A=sp.zeros(3)
 A[i,j]=p
 if i==j:
  assert i!=2
  A[2,2]=-p
 return A

forms={
 'rank2_common_kernel_two_roots':sp.diag(s,t,0),
 'rank2_common_kernel_double_root':sp.Matrix([[s,t,0],[t,0,0],[0,0,0]]),
 'rank2_constant':s*sp.diag(1,1,0),
 'rank2_moving_kernel':sp.Matrix([[0,0,s],[0,0,t],[s,t,0]]),
 'rank1':s*sp.diag(1,0,0),
 'rank0':sp.zeros(3)}
complements={
 'rank2_common_kernel_two_roots':[elementary(2,0,t*t),elementary(2,1,s*s)],
 'rank2_common_kernel_double_root':[elementary(2,0,s*s),elementary(2,1,s*s)],
 'rank2_constant':[elementary(0,1,t*t)-elementary(1,0,t*t),
                   elementary(2,0,t*t),elementary(2,1,t*t)],
 'rank2_moving_kernel':[],
 'rank1':[elementary(1,0,t*t),elementary(2,0,t*t)]
         +[elementary(i,j,p) for i,j in [(1,1),(1,2),(2,1)] for p in quad],
 'rank0':[elementary(i,j,p) for i in range(3) for j in range(3)
          if (i,j)!=(2,2) for p in quad]}
solutions=json.loads((ROOT/'singular_pencil_A_solutions.json').read_text())
dimensions={r['id']:r['dimension'] for r in solutions['cases']}
out=[]
for label,B in forms.items():
 G=(-cross*B).applyfunc(sp.expand)
 assert sp.trace(G)==0
 assert (G.T*B+B*G).applyfunc(sp.expand)==sp.zeros(3)
 gv=vector(G)
 L=gv.jacobian(coeffs)
 piv=list(L.rref()[1])
 K=sp.Matrix.hstack(*(vector(A) for A in complements[label])) if complements[label] else sp.zeros(24,0)
 for A in complements[label]:
  assert sp.trace(A)==0
  assert (A.T*B+B*A).applyfunc(sp.expand)==sp.zeros(3)
 V=L[:,piv].row_join(K)
 rows=list(V.T.rref()[1])
 assert V.cols==dimensions[label]
 assert len(rows)==V.cols
 determinant=V.extract(rows,range(V.cols)).det() if V.cols else 1
 out.append({'id':label,'B':[[str(e) for e in B.row(i)] for i in range(3)],
             'gauge_rank':len(piv),'quotient_dimension':K.cols,
             'gauge_matrix':sparse(L),'gauge_matrix_shape':[24,6],
             'gauge_independent_columns':piv,
             'quotient_representatives':[[[str(A[i,j]) for j in range(3)] for i in range(3)]
                                         for A in complements[label]],
             'quotient_matrix':sparse(K),'quotient_matrix_shape':[24,K.cols],
             'combined_rank_minor':{'rows':rows,'determinant':encode(determinant)}})
assert [r['gauge_rank'] for r in out]==[6,6,6,6,4,0]
assert [r['quotient_dimension'] for r in out]==[2,2,3,0,11,24]
(ROOT/'first_jet_gauge.json').write_text(json.dumps({
 'coordinate_change':'s_new=s+u.z, t_new=t+v.z, z_new=z',
 'affine_first_order':'tau_new=tau+(v-tau*u).y; y_new=y modulo I_L^2',
 'first_jet_action':'A_new=A-[xi]_cross B, xi an arbitrary vector of binary linear forms',
 'scope':'First jet only. Quotient is by the six-dimensional unipotent subgroup, not by the full line stabilizer.',
 'cases':out},indent=2)+'\n')
print(json.dumps([{k:r[k] for k in ['id','gauge_rank','quotient_dimension']} for r in out],indent=2))

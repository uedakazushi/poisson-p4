#!/usr/bin/env python3
"""Independent Fraction-only verifier of the canonical line/first-jet data."""
from pathlib import Path
from fractions import Fraction as Q
import ast,itertools,json
ROOT=Path(__file__).resolve().parent
d=json.loads((ROOT/'line_first_jet.json').read_text())
pencils=json.loads((ROOT/'singular_pencil_A_solutions.json').read_text())

def zeros(m,n):return [[Q(0) for _ in range(n)] for _ in range(m)]
def read_matrix(raw,shape):
 out=zeros(*shape)
 for i,j,c in raw:out[i][j]=Q(*c)
 return out
def mm(A,B):
 if not A:return []
 rows=[[(j,c) for j,c in enumerate(row) if c] for row in A]
 cols=list(zip(*B));return [[sum(c*col[j] for j,c in row if col[j]) for col in cols] for row in rows]
def submatrix(A,rr,cc):return [[A[i][j] for j in cc] for i in rr]
def identity(n):return [[Q(i==j) for j in range(n)] for i in range(n)]
def det(A):
 A=[r[:] for r in A];out=Q(1);n=len(A)
 for c in range(n):
  pivot=next((r for r in range(c,n) if A[r][c]),None)
  if pivot is None:return Q(0)
  if pivot!=c:A[c],A[pivot]=A[pivot],A[c];out=-out
  p=A[c][c];out*=p
  for r in range(c+1,n):
   if A[r][c]:
    f=A[r][c]/p
    for j in range(c+1,n):A[r][j]-=f*A[c][j]
 return out
def add(a,b,scale=Q(1)):
 r=a.copy()
 for m,c in b.items():
  v=r.get(m,Q(0))+scale*c
  if v:r[m]=v
  else:r.pop(m,None)
 return r
def mul(a,b):
 r={}
 for m,c in a.items():
  for n,e in b.items():
   k=tuple(x+y for x,y in zip(m,n));r[k]=r.get(k,Q(0))+c*e
 return {m:c for m,c in r.items() if c}
def deriv(a,i):
 r={}
 for m,c in a.items():
  if m[i]:
   n=list(m);n[i]-=1;r[tuple(n)]=c*m[i]
 return r
def variable(i,n):
 m=[0]*n;m[i]=1;return {tuple(m):Q(1)}

columns=d['coefficient_columns'];order=d['first_jet_order']
assert len(columns)==120 and len(order)==45
assert len(set((i,j,tuple(m)) for i,j,m in columns))==120
for i,j,m in columns:assert 0<=i<j<5 and sum(m)==2 and sum(m[2:])>=1
D=zeros(25,120);J=zeros(45,120)
variables=[variable(i,4) for i in range(4)]
for col,(i,j,m) in enumerate(columns):
 # Independently differentiate the five-dimensional bivector matrix.
 P=[[{} for _ in range(5)] for _ in range(5)]
 P[i][j]={tuple(m):Q(1)};P[j][i]={tuple(m):Q(-1)}
 for a in range(5):
  divergence={}
  for b in range(5):divergence=add(divergence,deriv(P[b][a],b))
  for mon,c in divergence.items():
   assert sum(mon)==1;D[5*a+mon.index(1)][col]=c
 # Restrict to x0=1 and apply the projective bivector formula before taking jets.
 affine=[[{tuple(mon[1:]):c for mon,c in entry.items()} for entry in row] for row in P]
 pi=[[{} for _ in range(4)] for _ in range(4)]
 for a in range(4):
  for b in range(4):
   pi[a][b]=add(add(affine[a+1][b+1],mul(variables[a],affine[0][b+1]),Q(-1)),
                mul(variables[b],affine[0][a+1]))
 for row,(tag,a,b,k) in enumerate(order):
  if tag=='A':poly=pi[0][a+1]
  else:
   left,right=[(2,3),(3,1),(1,2)][a];poly=pi[left][right]
  mon=[0]*4;mon[0]=k;mon[b+1]=1
  J[row][col]=poly.get(tuple(mon),Q(0))
assert D==read_matrix(d['divergence_matrix'],d['divergence_shape'])
assert J==read_matrix(d['first_jet_matrix'],d['first_jet_shape'])
assert all(sum(D[6*i][j] for i in range(5))==0 for j in range(120))
minor=d['divergence_minor'];delta_minor=det(submatrix(D,minor['rows'],minor['columns']))
assert delta_minor==Q(*minor['determinant'])==-1
N=read_matrix(d['canonical_kernel'],d['canonical_kernel_shape'])
assert mm(D,N)==zeros(25,96)
assert submatrix(N,d['canonical_free_columns'],range(96))==identity(96)
C=read_matrix(d['jet_constraints'],d['jet_constraints_shape'])
assert mm(mm(C,J),N)==zeros(9,96)
# The claimed nine constraints are precisely trace(A)=0 and skew(B)=0.
idx={tuple(v):i for i,v in enumerate(order)};expected=zeros(9,45)
for k in range(3):
 for i in range(3):expected[k][idx['A',i,i,k]]=1
for row,(i,j,k) in enumerate((i,j,k) for i in range(3) for j in range(i+1,3) for k in range(2)):
 expected[row+3][idx['B',i,j,k]]=1;expected[row+3][idx['B',j,i,k]]=-1
assert expected==C
core=d['core_jet_rows'];assert len(core)==36
JN=mm(J,N);T=[JN[i] for i in core]
minor=d['core_jet_minor'];jet_minor=det(submatrix(T,range(36),minor['columns_in_kernel_coordinates']))
assert jet_minor==Q(*minor['determinant'])==-256
R=read_matrix(d['jet_right_inverse'],d['jet_right_inverse_shape'])
assert mm(D,R)==zeros(25,36)
JR=mm(J,R)
assert [JR[i] for i in core]==identity(36)
K=read_matrix(d['zero_jet_kernel'],d['zero_jet_kernel_shape'])
assert mm(D,K)==zeros(25,60) and mm(J,K)==zeros(45,60)
free=[d['canonical_free_columns'][j] for j in d['zero_jet_free_kernel_coordinates']]
assert submatrix(K,free,range(60))==identity(60)

def parse_binary(expr):
 def rec(node):
  if isinstance(node,ast.Constant):return {(0,0):Q(node.value)} if node.value else {}
  if isinstance(node,ast.Name):return variable(['s','t'].index(node.id),2)
  if isinstance(node,ast.UnaryOp):return {m:-c for m,c in rec(node.operand).items()}
  if isinstance(node.op,ast.Pow):
   assert isinstance(node.right,ast.Constant) and node.right.value in [0,1,2]
   out={(0,0):Q(1)}
   for _ in range(node.right.value):out=mul(out,rec(node.left))
   return out
  a,b=rec(node.left),rec(node.right)
  if isinstance(node.op,ast.Add):return add(a,b)
  if isinstance(node.op,ast.Sub):return add(a,b,Q(-1))
  if isinstance(node.op,ast.Mult):return mul(a,b)
  raise ValueError(expr)
 return rec(ast.parse(expr,mode='eval').body)

results=[];condition_matrices={}
quad=[(2,0),(1,1),(0,2)]
for case in pencils['cases']:
 B=[[parse_binary(entry) for entry in row] for row in case['B']]
 conditions={};count=0
 for i in range(3):
  for j in range(3):
   if (i,j)==(2,2):continue
   for m in quad:
    A=[[{} for _ in range(3)] for _ in range(3)];A[i][j]={m:Q(1)}
    if i==j:A[2][2]={m:Q(-1)}
    for a in range(3):
     for b in range(a,3):
      p={}
      for k in range(3):p=add(add(p,mul(A[k][a],B[k][b])),mul(B[a][k],A[k][b]))
      for mon,c in p.items():conditions.setdefault((a,b,mon),[Q(0)]*24)[count]+=c
    count+=1
 assert count==24
 keys=sorted(conditions,key=lambda z:(z[0],z[1],-z[2][0],-z[2][1]))
 L=[conditions[k] for k in keys if any(conditions[k])]
 assert L==read_matrix(case['condition_matrix'],case['condition_shape'])
 condition_matrices[case['id']]=L
 Np=read_matrix(case['kernel'],case['kernel_shape']);dim=case['dimension']
 assert mm(L,Np)==zeros(len(L),dim)
 assert submatrix(Np,case['free_columns'],range(dim))==identity(dim)
 rc=case['rank_minor'];value=det(submatrix(L,rc['rows'],rc['columns']))
 assert value==Q(*rc['determinant']) and value
 assert case['rank']+dim==24
 results.append({'id':case['id'],'dimension':dim,'exact_minor':str(value),'all_passed':True})
assert [r['dimension'] for r in results]==[8,8,9,6,15,24]
gauge_results=[]
for case in json.loads((ROOT/'first_jet_gauge.json').read_text())['cases']:
 B=[[parse_binary(entry) for entry in row] for row in case['B']]
 G=zeros(24,6)
 for column in range(6):
  xi=[{}, {}, {}];xi[column//2]={(1,0) if column%2==0 else (0,1):Q(1)}
  negative=lambda p:{m:-c for m,c in p.items()}
  cross=[[{},negative(xi[2]),xi[1]],[xi[2],{},negative(xi[0])],[negative(xi[1]),xi[0],{}]]
  row=0
  for i in range(3):
   for j in range(3):
    if (i,j)==(2,2):continue
    p={}
    for k in range(3):p=add(p,mul(cross[i][k],B[k][j]),Q(-1))
    for mon in quad:G[row][column]=p.get(mon,Q(0));row+=1
 assert G==read_matrix(case['gauge_matrix'],case['gauge_matrix_shape'])
 K=read_matrix(case['quotient_matrix'],case['quotient_matrix_shape'])
 for col,rep in enumerate(case['quotient_representatives']):
  row=0
  for i in range(3):
   for j in range(3):
    if (i,j)==(2,2):continue
    poly=parse_binary(rep[i][j])
    for mon in quad:assert K[row][col]==poly.get(mon,Q(0));row+=1
 L=condition_matrices[case['id']]
 assert mm(L,G)==zeros(len(L),6)
 assert mm(L,K)==zeros(len(L),case['quotient_dimension'])
 columns=case['gauge_independent_columns'];assert len(columns)==case['gauge_rank']
 V=[[row[c] for c in columns]+kr for row,kr in zip(G,K)]
 dim=case['gauge_rank']+case['quotient_dimension']
 minor=case['combined_rank_minor'];value=det(submatrix(V,minor['rows'],range(dim)))
 assert value==Q(*minor['determinant']) and value
 if case['gauge_rank']<6:
  assert all(all(row[c]==0 for row in G) for c in range(6) if c not in columns)
 gauge_results.append({'id':case['id'],'gauge_rank':case['gauge_rank'],
                       'quotient_dimension':case['quotient_dimension'],
                       'exact_combined_minor':str(value),'all_passed':True})
result={'all_passed':True,'arithmetic':'Python standard-library Fraction only',
        'canonical_dimension':96,'first_projective_normal_jet_dimension':36,'first_jet_zero_kernel_dimension':60,
        'divergence_rank_minor':str(delta_minor),'jet_rank_minor':str(jet_minor),
        'divergence_and_projective_jets_independently_derived':True,'first_jet_map_surjective':True,
        'pencil_A_solutions':results,'unipotent_gauge_quotients':gauge_results,
        'scope':'Linear conditions and degree-one-normal Jacobi only; no full Jacobi or normality claim'}
(ROOT/'line_first_jet_independent_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

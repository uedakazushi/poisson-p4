#!/usr/bin/env python3
"""Canonical quadratic bivectors vanishing on a line, and their first jets.

This is a linear-algebra certificate only. It does not impose full Jacobi.
All arithmetic is exact over QQ. Output is relocatable and independently
checkable using the standard-library verifier.
"""
from pathlib import Path
import itertools,json
import sympy as s

ROOT=Path(__file__).resolve().parent
pairs=list(itertools.combinations(range(5),2))
monomials=[]
for i in range(5):
 for j in range(i,5):
  m=[0]*5;m[i]+=1;m[j]+=1
  if sum(m[2:]):monomials.append(tuple(m))
assert len(monomials)==12
columns=[(i,j,m) for i,j in pairs for m in monomials]
D=s.zeros(25,120)
# A_ij coefficient of tau^k: 27 coordinates. B_ij coefficient of tau^k:18.
jet_order=[['A',i,j,k] for i in range(3) for j in range(3) for k in range(3)]
jet_order += [['B',i,j,k] for i in range(3) for j in range(3) for k in range(2)]
index={tuple(r):i for i,r in enumerate(jet_order)}
J=s.zeros(45,120)
for col,(i,j,m) in enumerate(columns):
 for coordinate,derivative,sign in [(j,i,1),(i,j,-1)]:
  if m[derivative]:
   mm=list(m);mm[derivative]-=1
   assert sum(mm)==1
   D[5*coordinate+mm.index(1),col]+=sign*m[derivative]
 # Only terms of degree exactly1 in normal coordinates contribute.
 if sum(m[2:])!=1:continue
 normal=next(q for q in range(3) if m[q+2])
 tangential_t=m[1]
 # pi_(tau,z_a) = P_(1,a+2) - tau P_(0,a+2) + z_a P_01.
 if i==1 and j>=2:J[index['A',j-2,normal,tangential_t],col]+=1
 if i==0 and j>=2:J[index['A',j-2,normal,tangential_t+1],col]-=1
 # pi_(za,zb) has the same first jet as P_(a+2,b+2).
 normal_pair={(3,4):(0,1),(2,4):(1,-1),(2,3):(2,1)}
 if (i,j) in normal_pair:
  row,sign=normal_pair[i,j]
  J[index['B',row,normal,tangential_t],col]+=sign

def enc(q):q=s.Rational(q);return [int(q.p),int(q.q)]
def sparse(M):return [[i,j,enc(M[i,j])] for i in range(M.rows) for j in range(M.cols) if M[i,j]]
def kernel_from_rref(M):
 R,piv=M.rref();free=[i for i in range(M.cols) if i not in piv]
 K=s.zeros(M.cols,len(free))
 for j,f in enumerate(free):
  K[f,j]=1
  for i,p in enumerate(piv):K[p,j]=-R[i,f]
 return K,list(piv),free

N,dpiv,dfree=kernel_from_rref(D)
assert len(dpiv)==24 and N.shape==(120,96)
drows=list(D.T.rref()[1]);dminor=D.extract(drows,dpiv).det()
assert dminor
assert D*N==s.zeros(25,96)
# Exact nine universal constraints on first jet: three traces and six skewparts.
C=s.zeros(9,45)
for k in range(3):
 for i in range(3):C[k,index['A',i,i,k]]=1
for row,(i,j,k) in enumerate((i,j,k) for i in range(3) for j in range(i+1,3) for k in range(2)):
 C[row+3,index['B',i,j,k]]=1;C[row+3,index['B',j,i,k]]=-1
assert C*J*N==s.zeros(9,96)
core=[i for i,(tag,a,b,k) in enumerate(jet_order) if (tag=='A' and (a,b)!=(2,2)) or (tag=='B' and a<=b)]
assert len(core)==36
T=(J*N).extract(core,range(96))
kpiv=list(T.rref()[1]);assert len(kpiv)==36
tminor=T[:,kpiv].det();assert tminor
R=s.zeros(96,36);inverse=T[:,kpiv].inv()
for i,p in enumerate(kpiv):
 for j in range(36):R[p,j]=inverse[i,j]
assert T*R==s.eye(36)
K,t_piv,t_free=kernel_from_rref(T);assert K.shape==(96,60)
assert T*K==s.zeros(36,60)
# Explicit global right inverse and first-jet-zero directions.
lift=N*R;zerojet=N*K
assert D*lift==s.zeros(25,36) and D*zerojet==s.zeros(25,60)
assert J*zerojet==s.zeros(45,60)

data={'status':'exact linear algebra; full Jacobi not imposed',
 'line_equations':['x2','x3','x4'],'coefficient_columns':[[i,j,list(m)] for i,j,m in columns],
 'divergence_rows':['5*j+k represents x_k coefficient of (delta P)^j'],
 'divergence_matrix':sparse(D),'divergence_shape':[25,120],
 'divergence_rank':24,'divergence_minor':{'rows':drows,'columns':dpiv,'determinant':enc(dminor)},
 'canonical_kernel':sparse(N),'canonical_kernel_shape':[120,96],'canonical_free_columns':dfree,
 'first_jet_order':jet_order,'first_jet_matrix':sparse(J),'first_jet_shape':[45,120],
 'jet_constraints':sparse(C),'jet_constraints_shape':[9,45],
 'core_jet_rows':core,'core_jet_order':[jet_order[i] for i in core],
 'core_jet_rank':36,'core_jet_minor':{'columns_in_kernel_coordinates':kpiv,'determinant':enc(tminor)},
 'jet_right_inverse':sparse(lift),'jet_right_inverse_shape':[120,36],
 'zero_jet_kernel':sparse(zerojet),'zero_jet_kernel_shape':[120,60],
 'zero_jet_free_kernel_coordinates':t_free,
 'interpretation':{'A':'tracezero 3x3 matrix of binary quadratics, 24 coefficients',
                   'B':'symmetric 3x3 matrix of binary linear forms,12coefficients',
                   'canonical_dimension':96,'first_jet_dimension':36,'zero_jet_dimension':60}}
(ROOT/'line_first_jet.json').write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:data[k] for k in ('divergence_rank','divergence_minor','core_jet_rank','core_jet_minor','interpretation')},indent=2))

# Solve the degree-one-normal Jacobi condition in each singular pencil normal form.
u,v=s.symbols('s t')
forms={
 'rank2_common_kernel_two_roots':s.diag(u,v,0),
 'rank2_common_kernel_double_root':s.Matrix([[u,v,0],[v,0,0],[0,0,0]]),
 'rank2_constant':u*s.diag(1,1,0),
 'rank2_moving_kernel':s.Matrix([[0,0,u],[0,0,v],[u,v,0]]),
 'rank1':u*s.diag(1,0,0),
 'rank0':s.zeros(3)}
names=s.symbols('a0:24');A=s.zeros(3);idx=0;quads=[u*u,u*v,v*v]
for i in range(3):
 for j in range(3):
  if (i,j)==(2,2):continue
  A[i,j]=sum(names[idx+k]*quads[k] for k in range(3));idx+=3
A[2,2]=-A[0,0]-A[1,1]
answers=[]
for label,B in forms.items():
 M=(A.T*B+B*A).applyfunc(s.expand)
 equations=[c for i in range(3) for j in range(i,3) for c in s.Poly(M[i,j],u,v).coeffs() if c]
 if equations:L,rhs=s.linear_eq_to_matrix(equations,names)
 else:L=s.zeros(0,24)
 KK,piv,free=kernel_from_rref(L)
 rr=list(L.T.rref()[1]) if L.rows else []
 minor=L.extract(rr,piv).det() if piv else s.Integer(1)
 assert L*KK==s.zeros(L.rows,KK.cols)
 answers.append({'id':label,'B':[[str(B[i,j]) for j in range(3)] for i in range(3)],
  'A_parameter_order':[str(z) for z in names],'A_template':[[str(A[i,j]) for j in range(3)] for i in range(3)],
  'condition_matrix':sparse(L),'condition_shape':[L.rows,24],
  'rank':len(piv),'dimension':len(free),'rank_minor':{'rows':rr,'columns':piv,'determinant':enc(minor)},
  'kernel':sparse(KK),'kernel_shape':[24,len(free)],'free_columns':free})
assert [a['dimension'] for a in answers]==[8,8,9,6,15,24]
(ROOT/'singular_pencil_A_solutions.json').write_text(json.dumps({'cases':answers},indent=2)+'\n')
print({a['id']:a['dimension'] for a in answers})

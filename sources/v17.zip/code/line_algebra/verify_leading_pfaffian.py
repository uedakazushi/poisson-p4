#!/usr/bin/env python3
"""Independent exact symbolic check of the leading Pfaffian reduction.

Uses Python's standard library only. Polynomials are sparse dictionaries;
their monomials are sorted tuples of variable names. No sampling is used.
"""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations
import json

ROOT=Path(__file__).resolve().parent

class P(dict):
 def __init__(self, d=0):
  if isinstance(d,dict):super().__init__({m:Q(c) for m,c in d.items() if c})
  else:super().__init__({():Q(d)} if d else {})
 def __add__(self,b):
  b=P(b);d=dict(self)
  for m,c in b.items():d[m]=d.get(m,Q(0))+c
  return P(d)
 __radd__=__add__
 def __neg__(self):return P({m:-c for m,c in self.items()})
 def __sub__(self,b):return self+-P(b)
 def __rsub__(self,b):return P(b)+-self
 def __mul__(self,b):
  b=P(b);d={}
  for m,c in self.items():
   for n,e in b.items():
    k=tuple(sorted(m+n));d[k]=d.get(k,Q(0))+c*e
  return P(d)
 __rmul__=__mul__
 def __truediv__(self,b):return self*Q(1,b)
 def __pow__(self,n):
  out=P(1)
  for _ in range(n):out=out*self
  return out
 def derivative(self,v):
  d={}
  for m,c in self.items():
   count=m.count(v)
   if count:
    k=list(m);k.remove(v);d[tuple(k)]=count*c
  return P(d)
 def binary_coefficient(self,es,et):
  d={}
  for m,c in self.items():
   if m.count('s')==es and m.count('t')==et:
    k=tuple(v for v in m if v not in ['s','t']);d[k]=c
  return P(d)
 def string(self):
  if not self:return '0'
  return ' + '.join(str(c)+'*'+('*'.join(m) or '1') for m,c in sorted(self.items()))

def v(name):return P({(name,):1})
def zero(n=3):return [[P() for _ in range(n)] for _ in range(n)]
def add(A,B):return [[a+b for a,b in zip(ra,rb)] for ra,rb in zip(A,B)]
def scale(c,A):return [[c*e for e in row] for row in A]
def mm(A,B):return [[sum((A[i][k]*B[k][j] for k in range(len(B))),P()) for j in range(len(B[0]))] for i in range(len(A))]
def mv(A,x):return [sum((a*b for a,b in zip(row,x)),P()) for row in A]
def dot(x,y):return sum((a*b for a,b in zip(x,y)),P())
def cross(x,y):return [x[1]*y[2]-x[2]*y[1],x[2]*y[0]-x[0]*y[2],x[0]*y[1]-x[1]*y[0]]
def skew(x):return [[P(),-x[2],x[1]],[x[2],P(),-x[0]],[-x[1],x[0],P()]]
def comm(A,B):return add(mm(A,B),scale(-1,mm(B,A)))
def transpose(A):return [list(r) for r in zip(*A)]
def traceless(prefix):
 A=[[v(prefix+str(i)+str(j)) for j in range(3)] for i in range(3)]
 A[2][2]=-A[0][0]-A[1][1]
 return A
def determinant_columns(x,y,z):return dot(x,cross(y,z))
def curl(x):
 return [x[2].derivative('z1')-x[1].derivative('z2'),
         x[0].derivative('z2')-x[2].derivative('z0'),
         x[1].derivative('z0')-x[0].derivative('z1')]

z=[v('z'+str(i)) for i in range(3)]
M=traceless('m');N=traceless('n')
B=[[v('b'+str(min(i,j))+str(max(i,j))) for j in range(3)] for i in range(3)]
av=[v('a'+str(i)) for i in range(3)]
a=dot(av,z);mz=mv(M,z);nz=mv(N,z);bz=mv(B,z)
Pi=zero(5)
Pi[0][1]=a
for i in range(3):Pi[0][i+2]=mz[i];Pi[1][i+2]=nz[i]
Pi[2][3]=bz[2];Pi[2][4]=-bz[1];Pi[3][4]=bz[0]
for i in range(5):
 for j in range(i+1,5):Pi[j][i]=-Pi[i][j]
pf=[]
for omitted in range(5):
 i,j,k,l=[r for r in range(5) if r!=omitted]
 pf.append((-1)**omitted*(Pi[i][j]*Pi[k][l]-Pi[i][k]*Pi[j][l]+Pi[i][l]*Pi[j][k]))
q=[a*b-c for b,c in zip(bz,cross(mz,nz))]
assert pf==[dot(nz,bz),-dot(mz,bz)]+q
curlq=curl(q)
expected=mv(add(mm(skew(av),B),scale(-1,comm(M,N))),z)
assert curlq==expected
G=dot(z,q)/3
for i in range(3):
 defect=sum((z[j]*(q[j].derivative('z'+str(i))-q[i].derivative('z'+str(j))) for j in range(3)),P())/3
 assert G.derivative('z'+str(i))-q[i]==defect

# Jacobi of the first projective normal jet. The coefficient matrices are
# treated as constants because differentiation in the tangent direction
# only contributes in the next normal degree.
A=traceless('c')
az=mv(A,z);L=zero(4)
for i in range(3):L[0][i+1]=az[i]
L[1][2]=bz[2];L[1][3]=-bz[1];L[2][3]=bz[0]
for i in range(4):
 for j in range(i+1,4):L[j][i]=-L[i][j]
J={}
for i,j,k in combinations(range(4),3):
 J[i,j,k]=sum((L[i][l+1]*L[j][k].derivative('z'+str(l))
              +L[j][l+1]*L[k][i].derivative('z'+str(l))
              +L[k][l+1]*L[i][j].derivative('z'+str(l)) for l in range(3)),P())
Qmat=add(mm(transpose(A),B),mm(B,A));Qz=mv(Qmat,z)
assert J[1,2,3]==P()
assert [J[0,2,3],-J[0,1,3],J[0,1,2]]==Qz

# Rank-one, fixed nilpotent lower block after unipotent coordinate gauge.
s,t=v('s'),v('t')
h0,h1,h2,rho=[v(n) for n in ['h0','h1','h2','rho']]
alpha,beta,kappa,lam=[v(n) for n in ['alpha','beta','kappa','lambda']]
gamma,delta=v('gamma'),v('delta')
h=h0*s*s+h1*s*t+h2*t*t
U=[[P(),P(),P()],[kappa,P(),rho],[lam,P(),P()]]
A0=[[P(),P(),P()],[P(),P(),h0],[P(),P(),P()]]
A1=[[P(),P(),P()],[P(),P(),h1],[P(),P(),P()]]
A2=[[P(),P(),P()],[alpha,P(),h2],[beta,P(),P()]]
Mr=add(scale(s,U),scale(-t,A2))
Nr=add(scale(s,A0),scale(t,add(A1,U)))
Br=zero();Br[0][0]=s
ar=[gamma*s+delta*t,P(),-s*h0*lam+t*(h0*beta-h1*lam)]
error=add(comm(Mr,Nr),scale(-1,mm(skew(ar),Br)))
target=zero();target[1][0]=t*t*((h1+rho)*beta-h2*lam)
assert error==target
qrank=[dot(ar,z)*b-c for b,c in zip(mv(Br,z),cross(mv(Mr,z),mv(Nr,z)))]
C=gamma*s*s+delta*s*t-(kappa*beta-lam*alpha)*t*t
residual=((h1+rho)*beta-h2*lam)
# The only off-center monomial left is exactly the same obstruction.
assert qrank[1]==qrank[2]==P()
assert qrank[0]-C*z[0]*z[0]==-t*t*residual*z[0]*z[2]

# The primitive moving nilpotent quadratic block has no commuting linear
# lifts. The following constant syzygy is a certificate of inconsistency.
r,u,w=v('r'),v('u'),v('w')
R=[[r,u],[w,-r]]
J0=[[P(),P(-1)],[P(),P()]]
J1=[[P(1),P()],[P(),P(-1)]]
J2=[[P(),P()],[P(1),P()]]
H=add(scale(s,R),scale(-t,J2))
K=add(scale(s,J0),scale(t,add(J1,R)))
E=comm(H,K)
constant=E[1][0].binary_coefficient(0,2)-E[0][1].binary_coefficient(2,0)
assert constant==P(-2)

# Rank-zero normal bracket: Jordan-three and Jordan-two forms of the
# transverse cubic forced by commuting mixed blocks.
aa,bb,cc,dd=[v(n) for n in ['j_a','j_b','j_c','j_d']]
J3=[[P(),P(1),P()],[P(),P(),P(1)],[P(),P(),P()]]
M3=add(scale(aa,J3),scale(bb,mm(J3,J3)))
assert comm(M3,J3)==zero()
det3=determinant_columns(z,mv(M3,z),mv(J3,z))
assert det3==bb*z[2]**3
Jtwo=zero();Jtwo[0][1]=P(1)
Mtwo=[[aa,bb,cc],[P(),aa,P()],[P(),dd,-2*aa]]
assert comm(Mtwo,Jtwo)==zero()
det2=determinant_columns(z,mv(Mtwo,z),mv(Jtwo,z))
assert det2==dd*z[1]**3-3*aa*z[1]**2*z[2]

# Unified multiplicity-three form after the pure-cube theorem and the
# nilpotency theorem for the full five-dimensional canonical isotropy.
# Each displayed coefficient may be an arbitrary binary linear form.
bl,ell,em,pp,qq,rr,kk,aw,au,avv=[v(n) for n in
 ['Bline','ell','em','p','q','rline','k','aw','au','av']]
Mu=[[P(),P(),P()],[pp,P(),ell],[qq,P(),P()]]
Nu=[[P(),P(),P()],[rr,P(),em],[kk,P(),P()]]
Bu=zero();Bu[0][0]=bl
alpha_u=[aw,au,avv]
error_u=add(comm(Mu,Nu),scale(-1,mm(skew(alpha_u),Bu)))
target_u=zero();target_u[1][0]=ell*kk-em*qq-bl*avv;target_u[2][0]=bl*au
assert error_u==target_u
qu=[dot(alpha_u,z)*b-c for b,c in zip(mv(Bu,z),cross(mv(Mu,z),mv(Nu,z)))]
assert qu[1]==qu[2]==P()
assert qu[0]==(bl*aw-pp*kk+qq*rr)*z[0]**2+bl*au*z[0]*z[1]+(bl*avv-ell*kk+em*qq)*z[0]*z[2]
assert mm(mm(Mu,Mu),Mu)==zero() and mm(mm(Nu,Nu),Nu)==zero()
# The full five-dimensional linear Poisson matrix has rank <=4 and its
# normal Pfaffian vector is central whenever the two displayed constraints hold.

result={
 'all_passed':True,'arithmetic':'standard-library Fraction sparse symbolic polynomials; no sampling',
 'signed_pfaffian_identity':True,
 'curl_identity':'curl(a Bz-(Mz)x(Nz))=([a]_cross B-[M,N])z',
 'euler_gradient_defect_identity':True,
 'first_jet_jacobi_identity':'A^T B+B A=0',
 'rank1_fixed_nilpotent_constraint':'(h1+rho)*beta=h2*lambda',
 'rank1_fixed_nilpotent_F3':'(gamma*s^2+delta*s*t-(kappa*beta-lambda*alpha)*t^2)*z0^3/3',
 'moving_nilpotent_inconsistency_certificate':{
   'expression':'coeff_t2([H,K]21)-coeff_s2([H,K]12)','value':-2},
 'rank0_Jordan3_determinant':'j_b*z2^3',
 'rank0_Jordan2_determinant':'j_d*z1^3-3*j_a*z1^2*z2',
 'unified_m3_normal_form':{
  'M':[['0','0','0'],['p','0','ell'],['q','0','0']],
  'N':[['0','0','0'],['r','0','m'],['k','0','0']],
  'B':'b*diag(1,0,0)',
  'constraints':['b*a_u=0','b*a_v=ell*k-m*q'],
  'cubic_coefficient':'3*c=b*a_w-p*k+q*r',
  'all_coefficients':'binary linear forms',
  'identities_checked':True},
 'scope':'Necessary leading Pfaffian-gradient conditions only. Existence of full Poisson lifts and normality are not asserted.'}
(ROOT/'leading_pfaffian_independent_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

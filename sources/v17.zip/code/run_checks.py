#!/usr/bin/env python3
"""Run the v17 exact checks in disposable copies, without changing archived originals."""
from pathlib import Path
import argparse
import json
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--singular", help="Optional absolute path or command for Singular")
    args = parser.parse_args()
    out = args.output_dir or Path(tempfile.mkdtemp(prefix="p4_v17_reports_"))
    out = out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    (out / "logs").mkdir(exist_ok=True)
    (out / "reports").mkdir(exist_ok=True)
    results = []
    with tempfile.TemporaryDirectory(prefix="p4_v17_checks_") as tmp:
        work = Path(tmp)
        algebra = work / "line_algebra"
        shutil.copytree(ROOT / "code/line_algebra", algebra)
        for label, script, report in [
            ("linear_jet_and_gauge", "verify_line_jet.py", "line_first_jet_independent_verification.json"),
            ("leading_pfaffian_identities", "verify_leading_pfaffian.py", "leading_pfaffian_independent_verification.json")
        ]:
            completed = subprocess.run([sys.executable, str(algebra / script)], cwd=algebra,
                                       text=True, capture_output=True, check=False)
            (out / "logs" / (label + ".txt")).write_text(completed.stdout + completed.stderr)
            assert completed.returncode == 0, label
            data = json.loads((algebra / report).read_text())
            assert data["all_passed"] is True, label
            shutil.copy2(algebra / report, out / "reports" / report)
            results.append({"name": label, "all_passed": True})
        shutil.copy2(ROOT / "code/verify_hilbert_and_lifts.py", work / "verify_hilbert_and_lifts.py")
        completed = subprocess.run([sys.executable, str(work / "verify_hilbert_and_lifts.py")],
                                   cwd=work, text=True, capture_output=True, check=False)
        (out / "logs/hilbert_and_lifts.txt").write_text(completed.stdout + completed.stderr)
        assert completed.returncode == 0
        data = json.loads(completed.stdout)
        assert data["all_passed"] is True
        (out / "reports/hilbert_and_lifts.json").write_text(json.dumps(data, indent=2) + "\n")
        results.append({"name": "hilbert_and_lifts", "all_passed": True})
        if args.singular:
            target = work / "verify_numerical_counterexamples.sing"
            shutil.copy2(ROOT / "proofs/singularities/verify_numerical_counterexamples.sing", target)
            completed = subprocess.run([args.singular, "-q", str(target)], cwd=work,
                                       text=True, capture_output=True, check=False)
            log = completed.stdout + completed.stderr
            (out / "logs/numerical_counterexamples.txt").write_text(log)
            assert completed.returncode == 0 and "ALL EXPECTED EXACT LENGTHS VERIFIED" in log
            expected = [(40, 40), (56, 52), (52, 44)]
            values = [(int(a), int(b)) for a, b in re.findall(r"example \d+: mu=(\d+), tau=(\d+)", log)]
            assert values == expected
            assert "plane factor: mu=14, tau=13" in log
            report = {"all_passed": True, "local_order": "ds", "base_field": "QQ",
                      "mu_tau_pairs": values, "plane_factor": [14, 13],
                      "role": "Supplementary counterexamples to numerical bounds; not used by the main proof"}
            (out / "reports/numerical_counterexamples.json").write_text(json.dumps(report, indent=2) + "\n")
            results.append({"name": "numerical_counterexamples", "all_passed": True})
    summary = {"all_passed": True, "version": 17, "checks": results,
               "check_count": len(results), "singular_supplement_run": bool(args.singular),
               "archived_originals_modified": False}
    (out / "verification_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"output_directory": str(out), **summary}, indent=2))


if __name__ == "__main__":
    main()

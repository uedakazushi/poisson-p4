射影4空間の Poisson 構造：研究継続 第17版
=========================================
2026年10月29日

主原稿
------
p4_poisson_completeness_v17.pdf
p4_poisson_completeness_v17.tex
sections/*.tex / preamble.tex

今回の結果
----------
正規な退化五次因子の零 modular residue 直線に対し、
四次元 isotropy と標準五次元 affine lift の isotropy が冪零である。
三重消滅なら、最初の法線項は q2(s,t)w^3、w は固定法線一次式となる。
五重消滅を排除し、四重消滅なら conormal 括弧 B=0、
四次項の pencil は非比例でなければならない。
全被約特異曲線が直線のとき、一般横断特異点は 40<tau<mu を満たす。
五つの Jacobian 生成元の最小性から、横断 family は接触自明ではない。

正確な線形・多項式計算
----------------------
標準二次 lift の空間は96次元、projective 一次 jet は36次元、核60次元。
ambient 一次法線項50次元と、発散を解いた純法線二次項46次元に分けられる。
先頭 Pfaffian–勾配条件、三重の場合の必要標準形、
動く原始冪零二次ブロックの排除を有理数上で検証した。

再現
----
python3 code/run_checks.py
python3 code/verify_bundle.py

独立 checker は Python 標準ライブラリだけを使う。
SymPy は任意の証明書再生成 builder のみに必要。
補助的な局所 Milnor/Tjurina 反例も再計算する場合：
python3 code/run_checks.py --singular /absolute/path/to/Singular

実際に実行した4系統の検証結果は data/reproduced/ にある。
checker は一時コピー上で動き、保存済みデータを変更しない。
PDF は LuaLaTeX、ltjsarticle、luatexja、Harano Aji fonts で生成する。

範囲
----
直線型を完全に排除したわけではない。
三重型、四重型とも高い法線次数の全 Jacobi 方程式と正規性の判定が残る。
閉点の必要条件をスキーム同型、既約成分、被約性、商モジュライ次元と
同一視してはならない。全成分数の下界57は変更しない。

保存
----
previous_v16/ 内の1339ファイルは前版から byte 単位で変更していない。
旧版の保存台帳は data/previous_v16_preservation.json、
今回の全体 checksum は SHA256SUMS.txt にある。
HANDOFF.txt に次回へ引き継ぐ仮定と未解決事項を記載した。

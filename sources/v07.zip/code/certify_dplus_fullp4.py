"""Exact full-P4 audit of the Dplus algebraic-number-field representative."""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
from itertools import combinations
import ast,json,sys
sys.path.insert(0,str(ROOT/'previous_v6'/'previous_v5'/'code'))
import certify_regular_nilpotent as c
from sympy.polys.matrices import DomainMatrix
s,np=c.sp,c.np
HERE=Path(__file__).resolve().parent
x0,x,y,z,w=c.xx5;xx=c.xx;pairs=list(combinations(range(4),2));K=s.QQ.algebraic_field(s.sqrt(3))
def rk(M):return len(DomainMatrix.from_Matrix(M).convert_to(K).rref()[1])
def red(M):return DomainMatrix.from_Matrix(M).convert_to(K).to_Matrix()
def read(data):
 M=s.zeros(4)
 for key,f in data.items():
  I=tuple(ast.literal_eval(key));M[I]=s.sympify(f,locals=dict(zip(('x','y','z','w'),xx)));M[I[::-1]]=-M[I]
 return M
def sparse4(M):return {(i+1,j+1):{(0,)+m:v for m,v in s.Poly(s.expand(M[i,j]),*xx).terms() if v} for i,j in pairs}
def vec2(B):return s.Matrix([B.get(I,{}).get(m,0) for I,m in c.p.BIVECTOR_BASIS])
def vec4(B):
 out=s.zeros(len(c.p.FOUR_VECTOR_BASIS),1)
 for I,pol in B.items():
  for k in range(5):
   sign=c.p.permutation_sign((k,)+I)
   if sign:
    for mon,v in pol.items():
     mm=list(mon);mm[k]+=1
     out[c.p.FOUR_VECTOR_INDEX[(tuple(sorted((k,)+I)),tuple(mm))]]+=sign*v
 return red(out)
def dictvec(v):
 out={}
 for (I,m),a in zip(c.p.BIVECTOR_BASIS,v):
  if a:out.setdefault(I,{})[m]=a
 return out
def jdict(M):return {I:{(0,)+m:v for m,v in s.Poly(s.expand(pol),*xx).terms() if v} for I,pol in zip(combinations(range(1,5),3),c.jac(M,xx))}
record=json.loads((REFERENCE/'dplus_higher_jets.json').read_text())
Q,R,T=[read(rec) for rec in record['jets']]
qs,rs,ts=map(sparse4,(Q,R,T));ps={I:dict(poly) for I,poly in qs.items()}
for I in ((1,2),(3,4)):ps[I][(2,0,0,0,0)]=1
DP=s.Matrix.hstack(*[vec4(c.polar(ps,{I:{m:1}})) for I,m in c.p.BIVECTOR_BASIS])
print('full differential assembled',flush=True)
Vert=s.Matrix(c.p.vertical_bivector_matrix());acts=[dictvec(Vert[:,j]) for j in range(Vert.cols)]
for i in range(5):
 for j in range(5):
  A=np.zeros((5,5),dtype=np.int64);A[i,j]=1
  acts.append(c.v.linear_action_derivative(ps,A))
acts.append(ps)
FP=s.Matrix.hstack(*[vec2(B) for B in acts]);KP=FP.row_join(vec2(rs))
assert red(DP*KP)==s.zeros(350,KP.cols)
assert vec4(c.polar(ps,ts))+vec4(jdict(R))==s.zeros(350,1)
obs=vec4(c.polar(rs,ts))
ranks={'full_Jacobi_rank':rk(DP),'vertical_rank':rk(Vert),'actual_vertical_orbit_scale_rank':rk(FP),'actual_plus_R_rank':rk(KP),'differential_plus_third_rank':rk(DP.row_join(obs))}
print(ranks,flush=True)
ambiguity=s.Matrix.hstack(DP,*[vec4(c.polar(rs,B)) for B in acts+[rs]])
ranks['all_second_correction_ambiguity_rank']=rk(ambiguity)
ranks['all_ambiguity_plus_third_rank']=rk(ambiguity.row_join(obs))
pf=s.factor((x0*x0+Q[0,1])*(x0*x0+Q[2,3])+Q[0,3]*Q[1,2],extension=s.sqrt(3))
print('Pfaffian',pf,flush=True)
print('binary factor',s.factor(pf.subs(x0,0),extension=s.sqrt(3)),flush=True)
print('discriminant',s.factor(x*x*z*z-4*pf.subs(x0,0),extension=s.sqrt(3)),flush=True)
out={'all_passed':True,'field':str(K),'ranks':ranks,'Pfaffian':str(pf),'binary_quartic_factor':str(s.factor(pf.subs(x0,0),extension=s.sqrt(3))),'spectral_discriminant':str(s.factor(x*x*z*z-4*pf.subs(x0,0),extension=s.sqrt(3))), 'full_second_jet_identity':True}
assert list(ranks.values())==[101,24,48,49,102,101,102]
(DATA/(Path(__file__).stem+'.json')).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2),flush=True)

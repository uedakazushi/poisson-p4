"""Reproduce all new exact certificates without modifying reference outputs."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse, json, os, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[1]
JOBS=[
 ['minimal_thickness.py'], ['independent_minimal_thickness_audit.py'],
 ['certify_a0_thickness.py'], ['audit_a0_thickness.py'],
 ['certify_closed_squarezero.py'], ['one_normal_higher_jets.py','Cplus','Dplus'],
 ['audit_closed_nilpotent.py'], ['certify_boundary_deformations.py'],
 ['certify_nil22_summary.py'], ['certify_dplus_fullp4.py'],
 ['independent_dplus_fullp4_audit.py'],
 ['certify_logarithmic_boundaries.py'], ['certify_exceptional_primitive.py'],
 ['certify_exceptional_primitive_slices.py'], ['certify_zero_reduced_components.py'],
 ['quartic_certificate.py'], ['independent_quartic_rank_audit.py'],
 ['exceptional_boundary_independent_audit.py']]
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--jobs',type=int,default=1)
 ap.add_argument('--output-dir',type=Path,default=ROOT/'data'/'reproduced')
 args=ap.parse_args();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
 env=os.environ.copy();env['P4_V7_OUTPUT_DIR']=str(out);env['PYTHONDONTWRITEBYTECODE']='1'
 def run(job):
  start=time.monotonic();log=out/(Path(job[0]).stem+'.log')
  with log.open('w') as f:
   result=subprocess.run([sys.executable,str(ROOT/'code'/job[0]),*job[1:]],env=env,stdout=f,stderr=subprocess.STDOUT,cwd=ROOT)
  return {'script':job[0],'arguments':job[1:],'exit_code':result.returncode,'elapsed_seconds':round(time.monotonic()-start,2),'log':log.name}
 results=[]
 with ThreadPoolExecutor(max_workers=max(1,args.jobs)) as pool:
  futures=[pool.submit(run,job) for job in JOBS]
  for future in as_completed(futures):
   result=future.result();results.append(result)
   print(('PASS' if result['exit_code']==0 else 'FAIL')+' '+result['script'],flush=True)
 results.sort(key=lambda r:next(i for i,j in enumerate(JOBS) if j[0]==r['script']))
 report={'all_passed':all(r['exit_code']==0 for r in results),'number_of_checks':len(results),'python':sys.version.split()[0],'results':results}
 (out/'v7_check_results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'all_passed':report['all_passed'],'number_of_checks':len(results)},indent=2))
 return 0 if report['all_passed'] else 1
if __name__=='__main__':raise SystemExit(main())

#!/usr/bin/env python3
"""Exact one-dimensional Kuranishi slices in the full45 compatible space."""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
from itertools import combinations
import json,sys
import sympy as s
from sympy.polys.matrices import DomainMatrix
from independent_minimal_thickness_audit import Calculus,constant_compatibility,symplectic_orbit
HERE=Path(__file__).resolve().parent

def rr(M,field):
    m,p=DomainMatrix.from_Matrix(M).convert_to(field).rref()
    return m.to_Matrix(),list(p)
def rk(M,field):return len(rr(M,field)[1])
def inv(M,field):return DomainMatrix.from_Matrix(M).convert_to(field).inv().to_Matrix()
def zero(M,field):return not any(DomainMatrix.from_Matrix(M).convert_to(field).to_Matrix())
def kern(M,field):
    R,p=rr(M,field);free=[j for j in range(M.cols) if j not in p];K=s.zeros(M.cols,len(free))
    for col,j in enumerate(free):
        K[j,col]=1
        for i,k in enumerate(p):K[k,col]=-R[i,j]
    return K

def point(C,name):
    x,y,z,w=C.x;p=x*x+2*x*z+3*z*z
    if name=='Cplus':
        q=[x*x/16+x*z/2-z*z/16,0,5*x*x/16-x*z/4-z*z/16,
           x*x/16+x*z/4-5*z*z/16,p+(z-x)*(y+w)/8,-x*x/16+x*z/2+z*z/16]
    elif name=='Dplus':
        c=s.sqrt(3)/18;d=s.Rational(1,2)+c;u=s.Rational(1,6);v=-s.Rational(1,36)
        a=-3*c;b=-c/12
        q=[-u*z*z-v*x*x-d*x*z+x*z,0,a*z*z-4*u*x*z+(c-3*d+2)*x*x/2,
           b*x*x-(c+d)*z*z/2-4*v*x*z,p+2*u*y*z-c*x*y+c*z*w+2*v*x*w+2*d*x*y-x*y,
           u*z*z+v*x*x+d*x*z]
    else:raise ValueError(name)
    return C.tensor(dict(zip(C.pairs,q)))

def run(name,maxorder=9):
    C=Calculus(4);C.x=s.symbols('x y z w')
    C.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*C.x).terms() if a}
    field=s.QQ.algebraic_field(s.sqrt(3)) if name=='Dplus' else s.QQ
    Q=point(C,name);J=C.tensor({(0,1):1,(2,3):1});CC,B=constant_compatibility(C,J)
    assert zero(C.cubic_vector(C.jacobi(Q)),field)
    assert zero(CC*C.vector(Q),field)
    D=C.derivative(Q)*B;dr,dp=rr(D,field);r=len(dp)
    orbit=symplectic_orbit(C,J,Q);F=s.Matrix.hstack(*[C.vector(Z) for Z in orbit+[Q]])
    assert zero(C.derivative(Q)*F,field)
    O=rk(F[:,:10],field);fr=rk(F,field)
    assert r==34 and fr==10
    K=kern(D,field);KV=B*K
    _,piv=rr(F.row_join(KV),field)
    normal=[KV[:,j-F.cols] for j in piv if j>=F.cols];assert len(normal)==1
    R=C.from_vector(normal[0]);W=B[:,dp];DW=D[:,dp]
    assert zero(C.cubic_vector(C.polar(Q,R)),field)
    assert rk(s.Matrix.hstack(F,normal[0],W),field)==45
    _,rows=rr(DW.T,field);Mi=inv(DW[rows,:],field)
    jets=[Q,R];steps=[]
    for order in range(2,maxorder+1):
        known=s.zeros(80,1)
        for i in range(1,order):
            j=order-i
            if i>j:continue
            term=C.jacobi(jets[i]) if i==j else C.polar(jets[i],jets[j])
            known+=C.cubic_vector(term)
        # Field reduction prevents unsimplified sqrt3 expressions from growing.
        known=DomainMatrix.from_Matrix(known).convert_to(field).to_Matrix()
        coeff=-Mi*known[rows,:]
        coeff=DomainMatrix.from_Matrix(coeff).convert_to(field).to_Matrix()
        correction=W*coeff
        residual=DomainMatrix.from_Matrix(known+DW*coeff).convert_to(field).to_Matrix()
        nonzero=[(i,v) for i,v in enumerate(residual) if v!=0]
        step={'order':order,'residual_zero':not nonzero,'residual_nonzero_count':len(nonzero)}
        if nonzero:
            step['first_nonzero_residual']=[nonzero[0][0],str(nonzero[0][1])]
            steps.append(step);break
        jets.append(C.from_vector(correction));steps.append(step)
        print(name,order,'extends',flush=True)
    report={'Q':C.encode(Q),'R':C.encode(R),'Jacobi_rank':r,'Sp4_orbit_rank':O,'orbit_times_scale_rank':fr,
            'tangent_dimension':45-r,'normal_dimension':1,'linear_equation_rows':rows,'complement_columns':dp,
            'steps':steps,'first_obstruction_order':steps[-1]['order'] if not steps[-1]['residual_zero'] else None,
            'jets':[C.encode(Z) for Z in jets],
            'formal_slice_justification':'The actual10-dimensional Sp4 times Gm orbit and the35-dimensional linear slice R+W are transverse in ambient45-space. The group action gives a local product. The chosen34 equations uniquely solve W-coordinates as series in the single normal variable. Residual equations determine the one-variable slice ideal.'}
    assert report['first_obstruction_order']=={'Cplus':4,'Dplus':3}[name]
    report['all_passed']=True
    (DATA/(name.lower()+'_higher_jets.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(name,'FINAL',report['first_obstruction_order'],flush=True)
    return report

if __name__=='__main__':
    for name in sys.argv[1:] or ['Cplus','Dplus']:run(name)

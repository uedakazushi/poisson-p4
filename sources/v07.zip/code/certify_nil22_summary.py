#!/usr/bin/env python3
"""Full coefficient tangent table for all eleven nil22 saturation strata."""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
import json
import sympy as s
from independent_minimal_thickness_audit import Calculus,constant_compatibility,symplectic_orbit
from one_normal_higher_jets import point as exceptional_point,rk,zero
from certify_closed_squarezero import core
HERE=Path(__file__).resolve().parent

def point(C,name):
    x,y,z,w=C.x;p=x*x+2*x*z+3*z*z
    if name in ['Cplus','Dplus']:return exceptional_point(C,name)
    if name in ['Cminus','U1','AB']:return core(C,name,1,2,3)
    if name=='open':q=[-x*x+x*z-x*w,-x*x,0,3*x*y-4*x*z+z*z-3*z*w,x*x+x*y-2*x*z+2*x*w+z*z/2-2*z*w+w*w,x*x+x*w]
    elif name=='U0':q=[x*z-z*z,0,(x-2*z)**2,0,p-x*y+2*y*z,z*z]
    elif name=='L0':q=[-x*z,0,-x*x,-2*z*z,p+x*y+2*z*w,2*x*z]
    elif name=='L1':q=[-x*z,0,-s.Rational(3,2)*x*x,-s.Rational(3,2)*z*z,p+2*x*y+z*w,2*x*z]
    elif name=='A0':q=[3*x*z/4,0,z*z+3*x*x/4,-z*z/4,p-3*x*y/4+z*w/4,x*z/4]
    elif name=='A1':q=[x*z/4,0,z*z-x*x/4,-z*z/4,p+3*x*y/4-z*w/4,3*x*z/4]
    else:raise ValueError(name)
    return C.tensor(dict(zip(C.pairs,q)))

def main():
    C=Calculus(4);C.x=s.symbols('x y z w');C.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*C.x).terms() if a}
    x,y,z,w=C.x;J=C.tensor({(0,1):1,(2,3):1});CC,B=constant_compatibility(C,J)
    P=Calculus(5);P.x=s.symbols('x0 x y z w');P.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*P.x).terms() if a}
    status={'open':('old component','K',1),'Cplus':('new component','K[e]/(e^4)',4),
            'Cminus':('new component','K[u,v]/(u,v)^2',3),'Dplus':('new component','K[e]/(e^3)',3),
            'U0':('boundary of G2',None,None),'U1':('new component','K[u,v]/(u,v)^2',3),
            'L0':('boundary of G2',None,None),'L1':('boundary of G1',None,None),
            'A0':('new component','K[e]/(e^3)',3),'A1':('boundary of G1',None,None),
            'AB':('new component','K[u,v]/(u,v)^2',3)}
    expected_tangent={'open':10,'Cplus':11,'Cminus':12,'Dplus':11,'U0':11,'U1':12,'L0':11,'L1':11,'A0':11,'A1':11,'AB':12}
    out={}
    for name in status:
        field=s.QQ.algebraic_field(s.sqrt(3)) if name=='Dplus' else s.QQ
        Q=point(C,name);DQ=C.derivative(Q)*B;O=symplectic_orbit(C,J,Q)
        assert zero(CC*C.vector(Q),field) and zero(C.cubic_vector(C.jacobi(Q)),field)
        qm=C.as_matrix(Q);assert s.expand(qm[0,1]+qm[2,3]-x*z)==0
        orank=rk(s.Matrix.hstack(*[C.vector(Z) for Z in O]),field)
        tangent=45-rk(DQ,field);assert tangent==expected_tangent[name]
        PQ=C.lift(Q,P)
        for I in [(1,2),(3,4)]:PQ.setdefault(I,{})[(2,0,0,0,0)]=1
        DP=P.derivative(PQ,True)
        V=s.Matrix.hstack(*[P.vector(P.vertical(i,j)) for i in range(5) for j in range(5)])
        OP=[]
        for i in range(5):
            for j in range(5):
                X=s.zeros(5,1);X[i]=P.x[j];OP.append(P.lie(PQ,X))
        F=s.Matrix.hstack(V,*[P.vector(Z) for Z in OP+[PQ]])
        assert zero(DP*F,field)
        st,ring,length=status[name]
        entry={'reduced_saturation_dimension':10,'full_Q_generic_tangent':tangent,'sample_Sp4_orbit_dimension':orank,
               'assignment':st,'generic_transverse_ring_if_component':ring,'generic_length_if_component':length,
               'Q':C.encode(Q),'sample_full_P4_Jacobi_rank':rk(DP,field),
               'sample_P4_projective_tangent':125-rk(DP,field),'sample_P4_projective_orbit':rk(F,field)-25,
               'full_P4_scope':'Separate full P4 components are proved for open (v6), A0 (v7), and Dplus (v7); other ambient memberships are not concluded here.'}
        out[name]=entry
        print(name,tangent,orank,entry['sample_P4_projective_tangent'],entry['sample_P4_projective_orbit'],flush=True)
    out['all_passed']=True
    out['count']={'nil22_saturations':11,'full_Q_components_among_them':7,'new_full_Q_components':6,'assigned_G1_G2_boundaries':4,'unassigned_full_Q_saturations':0}
    (DATA/'nil22_classification_summary.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()

"""Exact checks for primitive sections of both logarithmic P3 closures.

All calculations are over QQ (with explicit symbolic parameters).  No historical
Poisson helper is imported.  The accompanying proof supplies the proper-incidence
and closed-rational-form arguments; this file checks every finite normal-form
calculation, including the repeated-factor strata.
"""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
import itertools
import json
import sympy as s

OUT = DATA
x, y, z, w = xx = s.symbols('x y z w')
pairs = list(itertools.combinations(range(4), 2))
J = s.Matrix([[0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1], [0, 0, -1, 0]])
mons2 = [s.prod(xx[i] for i in ij) for ij in itertools.combinations_with_replacement(range(4), 2)]


def df(f):
    return s.Matrix([s.diff(f, v) for v in xx])


def wedge(u, v):
    return (u*v.T-v*u.T).applyfunc(s.expand)


def d1(eta):
    return s.Matrix(4, 4, lambda i, j: s.expand(s.diff(eta[j], xx[i])-s.diff(eta[i], xx[j])))


def star(A):
    """i_Q(dx dy dz dw)=A, with i_(X wedge Y)=i_Y i_X."""
    Q = s.zeros(4)
    for i, j in pairs:
        k, l = [n for n in range(4) if n not in (i, j)]
        perm = [i, j, k, l]
        sign = (-1)**sum(perm[a] > perm[b] for a in range(4) for b in range(a+1, 4))
        Q[i, j] = sign*A[k, l]
        Q[j, i] = -Q[i, j]
    return Q


def primitive(A):
    return s.expand(A[0, 1]+A[2, 3])


def jac(Q):
    return [s.expand(sum(Q[i, l]*s.diff(Q[j, k], xx[l]) + Q[j, l]*s.diff(Q[k, i], xx[l]) + Q[k, l]*s.diff(Q[i, j], xx[l]) for l in range(4))) for i, j, k in itertools.combinations(range(4), 3)]


def divergence(Q):
    return [s.expand(sum(s.diff(Q[i, j], xx[i]) for i in range(4))) for j in range(4)]


def eqzero(expr):
    if isinstance(expr, s.MatrixBase):
        assert all(s.expand(v) == 0 for v in expr)
    elif isinstance(expr, (list, tuple)):
        assert all(s.expand(v) == 0 for v in expr)
    else:
        assert s.expand(expr) == 0


def coefficient_matrix(poly, unknowns):
    equations = s.Poly(s.expand(poly), *xx).coeffs()
    return s.linear_eq_to_matrix(equations, unknowns)[0]


def brackets(Q):
    return {''.join(str(xx[i]) + str(xx[j])): str(s.factor(Q[i, j])) for i, j in pairs}


def main():
    data = {'scope': 'Exact normal-form certificate; closure coverage is proved in logarithmic_boundaries_theorem.txt.'}
    a, b, c, lam = s.symbols('a b c lambda')
    fcoeff = s.symbols('f0:10')
    F = sum(v*m for v, m in zip(fcoeff, mons2))

    # Universal matrix extension of the v6 Log(1,1,2) zero-modular family.
    b11, b12, b21, b22 = s.symbols('b11 b12 b21 b22')
    B = s.Matrix([[b11, b12], [b21, b22]])
    S = s.Matrix([[0, -1], [1, 0]])
    X, Y = s.Matrix([x, z]), s.Matrix([y, w])
    bx, cy, ux = B*X, -(B.T+s.trace(B)*s.eye(2))*Y, S*B*X
    V = s.Matrix([bx[0], cy[0], bx[1], cy[1]])
    U = s.Matrix([0, ux[0], 0, ux[1]])
    h0, h1, h2 = s.symbols('h0 h1 h2')
    h = h0*x*x+h1*x*z+h2*z*z
    Qb = wedge(V, U)
    Qbf = Qb.copy(); Qbf[1, 3] += h; Qbf[3, 1] -= h
    eqzero(Qbf[0, 1]+Qbf[2, 3]); eqzero(divergence(Qbf))
    eqzero(jac(Qbf)); eqzero(jac(Qbf+J))
    eqzero(Qbf[0, 1]*Qbf[2, 3]-Qbf[0, 2]*Qbf[1, 3]+Qbf[0, 3]*Qbf[1, 2])
    V6 = s.Matrix([-b*x, (2*b-a)*y, a*z, (b-2*a)*w])
    U6 = s.Matrix([0, a*z, 0, b*x])
    eqzero(Qb.subs({b11: -b, b12: 0, b21: 0, b22: a}) + wedge(V6, U6))
    t11, t12, t21, t22 = s.symbols('t11 t12 t21 t22')
    T = s.Matrix([[t11, t12], [t21, t22]])
    eqzero(T.T*S*T-T.det()*S)
    data['universal_matrix_family'] = {
        'V': list(map(str, V)), 'U': list(map(str, U)), 'brackets': brackets(Qbf),
        'Jacobi': 'identically zero', 'compatibility': 'identically zero',
        'divergence': 'identically zero', 'trace': 'identically zero', 'Pfaffian': 'identically zero',
        'diagonal_relation': 'Q_B for B=diag(-b,a) is minus the v6 Q(a,b)',
        'conjugacy_identity': 'T^T S T = det(T) S'}

    # Strict Log(1,1,1,1): row sums and a nonzero perfect matching.
    r0, r1, r2 = s.symbols('r0 r1 r2')
    ac = [r0, r1, -r0-r1, r2, r0-r2, r1+r2]
    Ac = s.zeros(4)
    for (i, j), v in zip(pairs, ac):
        Ac[i, j] = v; Ac[j, i] = -v
    eqzero(Ac*s.ones(4, 1))
    match = Ac.subs({r0: 0, r2: -r1})
    H1, H2 = s.Matrix([x, -y, 0, 0]), s.Matrix([0, 0, z, -w])
    Qmatch = s.Matrix(4, 4, lambda i, j: match[i, j]*xx[i]*xx[j])
    eqzero(Qmatch-r1*wedge(H1, H2))
    data['four_independent_hyperplanes'] = {
        'row_sum_normal_form': list(map(str, ac)),
        'matching_12_34_forces': ['r0=0', 'r2=-r1'],
        'result': 'r1*(x d_x-y d_y) wedge (z d_z-w d_w)'}

    # D=L^2 M N, with F independent of L,M,N.  Arbitrary alternating
    # pairings, rather than a specially chosen symplectic form, are essential.
    residues = [a, b, -a-b]
    eta211 = y*z*(x*df(w)-w*df(x)) + residues[0]*x*y*z*df(x) + residues[1]*x*x*z*df(y) + residues[2]*x*x*y*df(z)
    A211 = d1(eta211)
    pp = s.symbols('p01 p02 p03 p12 p13 p23')
    prim211 = s.expand(sum(pp[n]*A211[i, j] for n, (i, j) in enumerate(pairs)))
    expected211 = (2*y*z*pp[2] + x*z*(pp[4]+(2*b-a)*pp[0])
                   + x*y*(pp[5]+(2*(-a-b)-a)*pp[1])
                   + w*z*pp[0]+w*y*pp[1]+x*x*((-a-b)-b)*pp[3])
    eqzero(prim211-expected211)
    five_zero = {pp[i]: 0 for i in [0, 1, 2, 4, 5]}
    pf_pairing = pp[0]*pp[5]-pp[1]*pp[4]+pp[2]*pp[3]
    eqzero(pf_pairing.subs(five_zero))
    data['partition_211'] = {'primitive_polynomial': str(prim211),
        'forced_zero_pairings': list(map(str, five_zero)),
        'pairing_Pfaffian': 'zero after the five forced vanishing conditions',
        'conclusion': 'Nondegenerate pairings force span(L,M,N,F) of dimension at most 3.'}

    # D=L^3 M and D=L^2 M^2, both symplectic and isotropic pairs.
    eta31 = lam*(x*x*y*df(x)-x**3*df(y)) + x*y*df(F)-2*y*F*df(x)
    p31 = primitive(d1(eta31))
    eqzero(p31-(3*y*s.diff(F, y)-x*s.diff(F, x)+2*F-4*lam*x*x))
    M31 = coefficient_matrix(p31, [*fcoeff, lam])
    K31 = M31.nullspace()
    assert len(K31) == 1
    eqzero(sum(K31[0][i]*mons2[i] for i in range(10))-x*x); assert K31[0][-1] == 0
    eta22 = lam*(x*y*y*df(x)-x*x*y*df(y)) + x*y*df(F)-F*df(x*y)
    p22 = primitive(d1(eta22))/2
    eqzero(p22-(y*s.diff(F, y)-x*s.diff(F, x)-2*lam*x*y))
    M22 = coefficient_matrix(p22, [*fcoeff, lam])
    K22 = M22.nullspace()
    assert len(K22) == 4 and all(v[-1] == 0 for v in K22)
    kernel22 = [s.expand(sum(v[i]*mons2[i] for i in range(10))) for v in K22]
    assert set(kernel22) == {x*y, z*z, z*w, w*w}
    D31 = 3*z*s.diff(F, y)+x*s.diff(F, w)
    D22 = z*s.diff(F, y)+x*s.diff(F, w)
    M31i, M22i = coefficient_matrix(D31, fcoeff), coefficient_matrix(D22, fcoeff)
    assert M31i.rank() == M22i.rank() == 6
    for kernel, op in [([x*x, x*z, z*z, x*y-3*z*w], lambda f: 3*z*s.diff(f, y)+x*s.diff(f, w)),
                       ([x*x, x*z, z*z, x*y-z*w], lambda f: z*s.diff(f, y)+x*s.diff(f, w))]:
        eqzero([op(f) for f in kernel])
    data['partition_31'] = {'symplectic_rank': M31.rank(), 'symplectic_kernel': ['F=x^2, lambda=0; hence eta=0'],
        'isotropic_rank': 6, 'isotropic_kernel': ['x^2', 'xz', 'z^2', 'xy-3zw']}
    data['partition_22'] = {'symplectic_rank': M22.rank(), 'symplectic_kernel': list(map(str, kernel22)),
        'symplectic_residue': 'lambda=0', 'isotropic_rank': 6,
        'isotropic_kernel': ['x^2', 'xz', 'z^2', 'xy-zw']}

    # Squarefree D=L M q: all primitive possibilities in the strict Log112 image.
    cres = -(a+b)/2
    eta112 = a*y*F*df(x)+b*x*F*df(y)+cres*x*y*df(F)
    p112 = primitive(d1(eta112))
    weight = lambda m: s.expand((b-a)*m+(cres-a)*y*s.diff(m, y)-(cres-b)*x*s.diff(m, x))
    eqzero(p112-weight(F))
    weights = {str(m): str(s.simplify(weight(m)/m)) for m in mons2}
    aa, bb = s.symbols('A B')
    Diso = aa*z*s.diff(F, y)+bb*x*s.diff(F, w)
    for f in [x*x, x*z, z*z, bb*x*y-aa*z*w]:
        eqzero(aa*z*s.diff(f, y)+bb*x*s.diff(f, w))
    assert coefficient_matrix(Diso.subs({aa: 2, bb: 3}), fcoeff).rank() == 6
    qcan = b*x*y-a*z*w
    eta_v6 = ((b-3*a)*z*qcan*df(x)+(a-3*b)*x*qcan*df(z)+(a+b)*x*z*df(qcan))/4
    eqzero(star(d1(eta_v6))-wedge(V6, U6))
    data['squarefree_L_M_q'] = {'symplectic_monomial_weights': weights,
        'irreducible_q_symplectic_case': 'a=b != 0, q in span(xy,z^2,zw,w^2); commuting quadratics',
        'isotropic_generic_kernel': ['x^2', 'xz', 'z^2', 'Bxy-Azw'],
        'isotropic_A0_or_B0': 'q is independent of one symplectic dual coordinate; constant-vector factor',
        'v6_identification': 'star(d eta_v6)=Q_v6(a,b), checked symbolically'}

    # Repeated linear factor D=L^2 q with irreducible q: potential F/L.
    # F independent of L.  If the pair is symplectic it has no nonzero q.
    eta_L2q_symp = x*F*df(y)-y*F*df(x)+c*(x*x*df(F)-2*x*F*df(x))
    p_L2q_symp = primitive(d1(eta_L2q_symp))
    eqzero(p_L2q_symp-(2*F+x*s.diff(F, x)+(y+4*c*x)*s.diff(F, y)))
    M_L2q_symp = coefficient_matrix(p_L2q_symp, fcoeff)
    det_L2q_symp = s.factor(M_L2q_symp.det())
    assert abs(det_L2q_symp) == 2**3*3**4*4**3
    D_L2q_iso = (z+4*c*x)*s.diff(F, y)-x*s.diff(F, w)
    M_L2q_iso = coefficient_matrix(D_L2q_iso, fcoeff)
    K_L2q_iso = M_L2q_iso.nullspace()
    assert len(K_L2q_iso) == 4
    for f in [x*x, x*z, z*z, x*y+z*w+4*c*x*w]:
        eqzero((z+4*c*x)*s.diff(f, y)-x*s.diff(f, w))
    q0 = h0*x*x+h1*x*z+h2*z*z
    tau = s.symbols('tau')
    qq = q0+tau*(x*y+z*w+4*c*x*w)
    eta_L2q_iso = x*qq*df(z)-z*qq*df(x)+c*(x*x*df(qq)-2*x*qq*df(x))
    Q_L2q_iso = star(d1(eta_L2q_iso))
    target = tau*Qb.subs({b11: 1, b12: 0, b21: 4*c, b22: 1})
    fextra = -4*(q0+c*x*s.diff(q0, z))
    target[1, 3] += fextra; target[3, 1] -= fextra
    eqzero(Q_L2q_iso-target)
    data['repeated_L2_q'] = {'symplectic_operator_determinant': str(det_L2q_symp),
        'isotropic_kernel_dimension': 4, 'isotropic_kernel': ['x^2', 'xz', 'z^2', 'xy+zw+4cxw'],
        'matrix_B': [['1', '0'], ['4c', '1']],
        'formula': 'star(d eta)=tau*Q_B - 4*(q0+c*x*d_z(q0))*d_y wedge d_w',
        'identity_verified': True}

    data['all_checks_passed'] = True
    path = OUT/'logarithmic_boundaries_certificate.json'
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'all_checks_passed': True, 'certificate': str(path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

"""Exact, reproducible witnesses for the v7 quartic reductions.

Run with Python 3 + SymPy. This certificate is supplementary to the
universal proofs in quartic_cone_theorem.txt, not a substitute for them.
No routines from v6 or earlier are imported.
"""
from v7_paths import ROOT, DATA, REFERENCE
from itertools import combinations, combinations_with_replacement
from pathlib import Path
import json
import sympy as s
from quartic_models import X, BASIS, PAIRS, MON2, matrix, tensor


def kernel_from_rref(M):
    R, pivots = M.rref()
    free = [j for j in range(M.cols) if j not in pivots]
    K = s.zeros(M.cols, len(free))
    for col, j in enumerate(free):
        K[j, col] = 1
        for row, p in enumerate(pivots):
            K[p, col] = -R[row, j]
    assert M * K == s.zeros(M.rows, K.cols)
    return len(pivots), K


def modular_full_rank_rows(M, prime):
    """Return independent original row indices using exact F_p arithmetic."""
    echelon = {}
    rows = []
    for i in range(M.rows):
        a = [int(M[i, j]) % prime for j in range(M.cols)]
        for pivot in sorted(echelon):
            if a[pivot]:
                factor = a[pivot]
                b = echelon[pivot]
                a = [(x - factor*y) % prime for x, y in zip(a, b)]
        pivot = next((j for j, value in enumerate(a) if value), None)
        if pivot is not None:
            inv = pow(a[pivot], -1, prime)
            echelon[pivot] = [(value*inv) % prime for value in a]
            rows.append(i)
            if len(rows) == M.cols:
                break
    assert len(rows) == M.cols
    return rows


def modular_determinant(M, prime):
    """Determinant by row elimination, separately from row selection."""
    assert M.rows == M.cols
    A = [[int(M[i, j]) % prime for j in range(M.cols)] for i in range(M.rows)]
    det = 1
    for j in range(M.cols):
        pivot = next((i for i in range(j, M.rows) if A[i][j]), None)
        if pivot is None:
            return 0
        if pivot != j:
            A[j], A[pivot] = A[pivot], A[j]
            det = -det
        value = A[j][j]
        det = det*value % prime
        inv = pow(value, -1, prime)
        for i in range(j+1, M.rows):
            factor = A[i][j]*inv % prime
            if factor:
                for k in range(j, M.cols):
                    A[i][k] = (A[i][k] - factor*A[j][k]) % prime
    return det % prime


def low_degree_central_matrix(F, degree):
    """All degree-0/1 bivectors on the first four coordinates, no divergence."""
    variables = X[:4]
    monomials = [s.Integer(1)] if degree == 0 else list(variables)
    columns = [(i, j, m) for i, j in combinations(range(4), 2) for m in monomials]
    equations = {}
    for col, (i, j, m) in enumerate(columns):
        for component, term in [(j, m*s.diff(F, variables[i])),
                                (i, -m*s.diff(F, variables[j]))]:
            for exp, coefficient in s.Poly(term, *variables).terms():
                if coefficient:
                    row = equations.setdefault((component, exp), [0]*len(columns))
                    row[col] += coefficient
    return s.Matrix([equations[key] for key in sorted(equations)])


def binomial_certificate(name, F, expected_rank):
    M, labels = matrix(F)
    rank, K = kernel_from_rref(M)
    assert rank == expected_rank
    active = [i for i, q in enumerate(X) if s.diff(F, q) != 0]
    for col in range(K.cols):
        P = tensor(K[:, col])
        for i in active:
            # Every coefficient of the Hamiltonian of x_i is divisible by x_i.
            assert all(s.expand(P[i, j]).subs(X[i], 0) == 0 for j in range(5))
    report = dict(name=name, F=str(s.expand(F)), matrix_shape=list(M.shape),
                  rank=rank, kernel_dimension=K.cols,
                  active_variables=[str(X[i]) for i in active],
                  all_active_hamiltonians_divisible=True)
    print(name, "rank", rank, "kernel", K.cols, flush=True)
    return report


def full_rank_certificate(name, F, family, parameter_dimension):
    M, labels = matrix(F)
    rank, K = kernel_from_rref(M)
    assert rank == 150 and K.cols == 0
    prime = 1000003
    rows = modular_full_rank_rows(M, prime)
    determinant = modular_determinant(M[rows, :], prime)
    assert determinant != 0
    report = dict(name=name, F=str(s.expand(F)), matrix_shape=list(M.shape),
                  rank=rank, kernel_dimension=0, family=family,
                  affine_parameter_dimension=parameter_dimension,
                  minor_rows_zero_based=rows, minor_columns="all 150 in BASIS order",
                  minor_row_labels=[labels[i] for i in rows],
                  minor_prime=prime, minor_determinant_mod_prime=determinant)
    print(name, "rank", rank, "minor mod", prime, "=", determinant, flush=True)
    return report


def main():
    x, y, z, u, v = X
    report = dict(schema="p4-quartic-certificate-v7", field="QQ",
                  coordinate_order=[str(q) for q in X],
                  bivector_pair_order=PAIRS, quadratic_exponent_order=MON2,
                  matrix_definition="All coefficients of Pi#dF=0 and delta(Pi)=0")
    binomials = [
        ("cone_13", x**4-y**2*z*u, 144),
        ("cone_22a", x**3*y-z**3*u, 145),
        ("cone_22b", x**3*y-z**2*u**2, 145),
        ("five_14", x**4-y*z*u*v, 147),
        ("five_23a", x**3*y-z**2*u*v, 149),
        ("five_23b", x**2*y**2-z**2*u*v, 149),
    ]
    report["binomial_examples"] = [binomial_certificate(*entry) for entry in binomials]

    # The discriminant of ax^3+bx^2y+cxy^2+dy^3, in coefficient coordinates.
    disc = y**2*z**2-4*x*z**3-4*y**3*u-27*x**2*u**2+18*x*y*z*u
    M, _ = matrix(disc)
    rank, K = kernel_from_rref(M)
    assert rank == 139
    low_ranks = []
    for degree, dimension in [(0, 6), (1, 24)]:
        L = low_degree_central_matrix(disc, degree)
        low_rank = L.rank()
        assert low_rank == dimension
        low_ranks.append(dict(coefficient_degree=degree, matrix_shape=list(L.shape),
                              rank=low_rank, kernel_dimension=0))
    report["discriminant_quartic_cone"] = dict(
        F=str(s.expand(disc)), matrix_shape=list(M.shape), rank=rank,
        kernel_dimension=K.cols, low_degree_bivector_checks=low_ranks,
        interpretation="Nonzero quadratic kernels exist; the universal stability proof excludes them.")
    print("discriminant cone rank", rank, "low-degree ranks", [a["rank"] for a in low_ranks], flush=True)

    double_plane = x**3*v+x**2*z**2+x*y*z*u+y**2*u**2+y**3*z
    remainder = double_plane-x**3*v
    assert s.degree(double_plane, v) == 1 and s.gcd(x**3, remainder) == 1
    # Gauss' lemma: primitive and degree one in v => absolutely irreducible over C.
    partial_matrix = s.Matrix([[s.Poly(s.diff(double_plane, q), *X).coeff_monomial(m)
                                for q in X]
                               for m in sorted({m for q in X for m, c in
                                                s.Poly(s.diff(double_plane, q), *X).terms() if c})])
    assert partial_matrix.rank() == 5
    assert all(s.diff(double_plane, q).subs({x:0, y:0}) == 0 for q in X)
    general_double = full_rank_certificate(
        "double_plane_quartic", double_plane, "(x,y)^2 in degree 4", 35)
    general_double.update(absolutely_irreducible_by="primitive degree-one polynomial in v",
                          essential_variables=5, gradient_height=2)
    bihomogeneous = x**2*(z**2+u**2+v**2)+x*y*(z*u+u*v+z*v)+y**2*(z**2+2*u**2+3*v**2)
    general_bihom = full_rank_certificate(
        "bihomogeneous_22", bihomogeneous,
        "Sym^2(span(x,y)) tensor Sym^2(span(z,u,v))", 18)
    report["open_family_exclusions"] = [general_double, general_bihom]

    target = (DATA/(Path(__file__).stem+'.json'))
    target.write_text(json.dumps(report, indent=2)+"\n")
    print("ALL CERTIFICATES PASSED:", target, flush=True)


if __name__ == "__main__":
    main()

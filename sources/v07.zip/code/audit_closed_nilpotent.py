"""A second polynomial engine audits the five new closed nilpotent strata."""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
from itertools import combinations
import ast,json,sys
sys.path.insert(0,str(ROOT/'previous_v6'/'previous_v5'/'code'))
import certify_regular_nilpotent as c
from sympy.polys.matrices import DomainMatrix
s,np=c.sp,c.np;HERE=Path(__file__).resolve().parent
SOURCE=REFERENCE
x,y,z,w=c.xx;xx=c.xx;pairs=list(combinations(range(4),2))
def rk(M,F=s.QQ):return len(DomainMatrix.from_Matrix(M).convert_to(F).rref()[1])
def read(data):
 M=s.zeros(4)
 for key,f in data.items():
  I=tuple(ast.literal_eval(key));M[I]=s.sympify(f,locals=dict(zip(('x','y','z','w'),xx)));M[I[::-1]]=-M[I]
 return M
def sparse(M):return {(i+1,j+1):{(0,)+m:v for m,v in s.Poly(s.expand(M[i,j]),*xx).terms() if v} for i,j in pairs}
def vec2(B):return s.Matrix([B.get(I,{}).get(m,0) for I,m in c.p.BIVECTOR_BASIS])
target=[(I,m) for I in combinations(range(1,5),3) for m in c.p.homogeneous_monomials(3) if m[0]==0]
def vec3(B):return s.Matrix([B.get(I,{}).get(m,0) for I,m in target])
def jdict(M):return {I:{(0,)+m:v for m,v in s.Poly(s.expand(pol),*xx).terms() if v} for I,pol in zip(combinations(range(1,5),3),c.jac(M,xx))}
hams=[c.hamiltonian({m:1}) for m in c.p.DEGREE_TWO if m[0]==0]
basis=[c.v.wedge_fields(A,B) for A,B in combinations(hams,2)]
def orbit(qs):
 oo=[]
 for H in hams:
  A=np.zeros((5,5),dtype=np.int64)
  for i,pol in enumerate(H):
   for m,v in pol.items():A[i,m.index(1)]=v
  oo.append(c.v.linear_action_derivative(qs,A))
 return oo
def D(qs):return s.Matrix.hstack(*[vec3(c.polar(qs,B)) for B in basis])
report={}
for name,order,F in [('Cplus',4,s.QQ),('Dplus',3,s.QQ.algebraic_field(s.sqrt(3)))]:
 rec=json.loads((SOURCE/(name.lower()+'_higher_jets.json')).read_text())
 jets=list(map(read,rec['jets']));Q=jets[0];qs=sparse(Q);Dq=D(qs)
 oo=orbit(qs);A=s.Matrix.hstack(*[vec2(B) for B in oo+[qs]])
 assert rk(Dq,F)==34 and rk(A,F)==10 and rk(A.row_join(vec2(sparse(jets[1]))),F)==11
 assert vec3(jdict(Q))==s.zeros(80,1)
 for R in jets:
  assert [s.expand(a-b) for a,b in zip(c.jac(R+c.J,xx),c.jac(R,xx))]==[0]*4
 coeff=[]
 for n in range(1,order+1):
  vv=s.zeros(80,1)
  if n<len(jets):vv+=vec3(c.polar(qs,sparse(jets[n])))
  for i in range(1,n):
   j=n-i
   if i>j:continue
   vv+=vec3(jdict(jets[i])) if i==j else vec3(c.polar(sparse(jets[i]),sparse(jets[j])))
  vv=DomainMatrix.from_Matrix(vv).convert_to(F).to_Matrix()
  if n<order:assert vv==s.zeros(80,1)
  else:assert rk(Dq.row_join(vv),F)==35
  coeff.append({'order':n,'zero':vv==s.zeros(80,1)})
 report[name]={'all_passed':True,'field':str(F),'Jacobi_rank':34,'actual_orbit_scale_rank':10,'actual_plus_normal_rank':11,'first_cokernel_obstruction_order':order,'jet_coefficients':coeff}
 print(name,report[name],flush=True)
sq=json.loads((SOURCE/'closed_squarezero_certificate.json').read_text())
p3,p4,p5=s.symbols('p3 p4 p5');params=[p3,p4,p5];K=s.QQ.frac_field(*params)
for name in ('Cminus','U1','AB'):
 rec=sq[name];Q,R,S=[read(rec[k]) for k in ('Q','R','S')];qs,rs,ss=map(sparse,(Q,R,S))
 Dq=D(qs);assert rk(Dq)==33
 for T in (Q,R,S):
  assert [s.expand(a-b) for a,b in zip(c.jac(T+c.J,xx),c.jac(T,xx))]==[0]*4
 assert vec3(jdict(Q))==s.zeros(80,1)
 assert vec3(c.polar(qs,rs))==vec3(c.polar(qs,ss))==s.zeros(80,1)
 obs=s.Matrix.hstack(vec3(jdict(R)),vec3(c.polar(rs,ss)),vec3(jdict(S)))
 assert rk(Dq.row_join(obs))==36
 G=Q.copy();g=(p3-1)*x*x+(p4-2)*x*z+(p5-3)*z*z;G[1,3]+=g;G[3,1]-=g
 gs=sparse(G);DG=D(gs)
 assert vec3(jdict(G))==s.zeros(80,1)
 ag=orbit(gs)+[sparse(G.diff(p)) for p in params]
 AG=s.Matrix.hstack(*[vec2(B) for B in ag])
 assert rk(DG,K)==33 and rk(AG,K)==10
 actual=AG.subs({p3:1,p4:2,p5:3});assert rk(actual)==10
 assert rk(s.Matrix.hstack(actual,vec2(rs),vec2(ss)))==12
 report[name]={'all_passed':True,'generic_field':'QQ(p3,p4,p5)','generic_Jacobi_rank':33,'generic_actual_rank':10,'sample_Jacobi_rank':33,'sample_actual_rank':10,'actual_plus_two_normals_rank':12,'Jacobi_plus_three_quadratic_obstructions_rank':36}
 print(name,report[name],flush=True)
report['all_passed']=True
(DATA/(Path(__file__).stem+'.json')).write_text(json.dumps(report,indent=2)+'\n')

#!/usr/bin/env python3
"""Independent full150-coefficient Dplus audit, with exact singular geometry."""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
import ast,json
import sympy as s
from independent_minimal_thickness_audit import Calculus
from one_normal_higher_jets import rk,zero
HERE=Path(__file__).resolve().parent

def main():
    record=json.loads((REFERENCE/'dplus_higher_jets.json').read_text())
    C=Calculus(4);C.x=s.symbols('x y z w');x,y,z,w=C.x
    C.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*C.x).terms() if a}
    P=Calculus(5);P.x=s.symbols('x0 x y z w');x0=P.x[0]
    P.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*P.x).terms() if a}
    field=s.QQ.algebraic_field(s.sqrt(3));r=s.sqrt(3)
    tensors=[]
    for row in record['jets']:
        tensors.append(C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals=dict(zip(('x','y','z','w'),C.x))) for I,f in row.items()}))
    Q,R,T=tensors
    PQ,PR,PT=[C.lift(Z,P) for Z in tensors]
    for I in [(1,2),(3,4)]:PQ.setdefault(I,{})[(2,0,0,0,0)]=1
    PM=P.as_matrix(PQ);F=s.expand(PM[1,2]*PM[3,4]-PM[1,3]*PM[2,4]+PM[1,4]*PM[2,3])
    p=s.expand(F.subs(x0,0));Delta=s.expand(x*x*z*z-4*p)
    L=x+(3-r)*z;M=x-(9+5*r)*z;Ld=x-(3+r)*z;Md=x+(9-5*r)*z
    p_factor=-r*L**3*M/864;delta_factor=r*Ld**3*Md/216
    assert s.Poly(s.expand(p-p_factor),x,z).is_zero
    assert s.Poly(s.expand(Delta-delta_factor),x,z).is_zero
    assert s.gcd(L,x*z,extension=r)==1
    assert s.simplify(M.subs(x,(r-3)*z)+4*(3+r)*z)==0
    assert s.simplify(Md.subs(x,(3+r)*z)-4*(3-r)*z)==0
    # Identities underlying the complete two-case singular-locus calculation.
    assert s.expand(s.diff(F,x0)-2*x0*(2*x0*x0+x*z))==0
    assert s.expand(F-((x0*x0+x*z/2)**2-Delta/4))==0
    normal=s.symbols('h')
    local=s.Poly(s.expand(F.subs(x,normal+(r-3)*z)),x0,normal)
    coeff2=local.coeff_monomial(x0*x0)
    coeff3=local.coeff_monomial(normal**3)
    assert s.simplify(coeff2-(r-3)*z*z)==0
    assert s.simplify(coeff3-r*(3+r)*z/216)==0
    geometry={'Pf_Q_factor':str(p_factor),'Delta_factor':str(delta_factor),
              'Pf_P':str(s.collect(F,x0)),'quartic_irreducible':True,
              'singular_planes':['x0=0, x+(3-sqrt(3))*z=0',
                                 'x-(3+sqrt(3))*z=0, x0=gamma*z',
                                 'x-(3+sqrt(3))*z=0, x0=-gamma*z'],
              'gamma_square':'-(3+sqrt(3))/2','singular_plane_count':3,
              'generic_normal_type_each_plane':'A2 cusp; multiplicity2',
              'D_order_along_first_plane':3,'D_order_along_other_two_planes':2,
              'irreducibility_reason':'No linear factor since its repeated binary factor does not divide xz. A quadratic factorization would force either p or Delta to be a square; neither is.'}
    print('geometry',geometry,flush=True)
    D=P.derivative(PQ,True)
    VV=[P.vertical(i,j) for i in range(5) for j in range(5)]
    OP=[]
    for i in range(5):
        for j in range(5):
            X=s.zeros(5,1);X[i]=P.x[j];OP.append(P.lie(PQ,X))
    V=s.Matrix.hstack(*[P.vector(Z) for Z in VV])
    Factual=s.Matrix.hstack(V,*[P.vector(Z) for Z in OP+[PQ]])
    K=Factual.row_join(P.vector(PR))
    assert zero(P.euler_vector(P.jacobi(PQ)),field)
    assert zero(D*K,field)
    assert zero(P.euler_vector(P.polar(PQ,PT))+P.euler_vector(P.jacobi(PR)),field)
    Obs=P.euler_vector(P.polar(PR,PT))
    Amb=s.Matrix.hstack(D,*[P.euler_vector(P.polar(PR,Z)) for Z in VV+OP+[PQ,PR]])
    ranks={'Jacobi_rank':rk(D,field),'vertical_rank':rk(V,field),
           'actual_vertical_orbit_scale_rank':rk(Factual,field),'actual_plus_R_rank':rk(K,field),
           'all_second_correction_ambiguity_rank':rk(Amb,field),'all_ambiguity_plus_third_rank':rk(Amb.row_join(Obs),field)}
    assert list(ranks.values())==[101,24,48,49,101,102]
    out={'independent_full150_assembly':True,'field':'QQ(sqrt(3))','ranks':ranks,
         'all_first_and_second_jet_identities_verified':True,'geometry':geometry,'all_passed':True}
    (DATA/'independent_dplus_fullp4_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print('ranks',ranks,flush=True);print('PASS',flush=True)

if __name__=='__main__':main()

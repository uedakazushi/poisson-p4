"""Exact primitive-pairing calculations for the exceptional P3 orbit.

Uses the explicit normal form in Alcantara--Cerveau, arXiv:2608.26470,
section 3.  No boundary-exhaustion claim from that preprint is used.
"""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
import json
import itertools
import sympy as s
from certify_logarithmic_boundaries import xx, pairs, df, d1, wedge, star, coefficient_matrix, eqzero

OUT = DATA
x, y, z, w = xx


def v(i, j):
    return xx[i]*df(xx[j])-xx[j]*df(xx[i])


def pairing_certificate(eta):
    A = d1(eta)
    pp = s.symbols('p01 p02 p03 p12 p13 p23')
    polynomial = s.expand(sum(p*A[i, j] for p, (i, j) in zip(pp, pairs)))
    M = coefficient_matrix(polynomial, pp)
    K = M.nullspace()
    uu = s.symbols('u0:'+str(len(K)))
    p = sum((u*k for u, k in zip(uu, K)), s.zeros(6, 1))
    pf = s.factor(p[0]*p[5]-p[1]*p[4]+p[2]*p[3])
    return {'matrix': [[str(t) for t in row] for row in M.tolist()],
            'rank': M.rank(),
            'kernel': [list(map(str, k)) for k in K],
            'pairing_Pfaffian_on_kernel': str(pf)}, M


def main():
    e1 = y*z*v(1, 3)-2*y*w*v(1, 2)
    e2 = 3*z*w*v(0, 2)-2*z*z*v(0, 3)
    e3 = y*w*v(0, 3)-3*w*w*v(0, 1)
    eta = e1+e2+e3
    coeff = s.symbols('c1 c2 c3')
    At = d1(sum((a*e for a, e in zip(coeff, [e1, e2, e3])), s.zeros(4, 1)))
    eqzero(At[0, 1]*At[2, 3]-At[0, 2]*At[1, 3]+At[0, 3]*At[1, 2])
    eqzero(sum(xx[i]*eta[i] for i in range(4)))
    data = {'source': 'https://arxiv.org/abs/2608.26470, section 3 normal form only',
            'scope': 'Open exceptional orbit and explicit boundary degenerations; no boundary exhaustion assumed.',
            'normal_form': list(map(str, eta.applyfunc(s.expand))),
            'three_pieces': [list(map(str, e.applyfunc(s.expand))) for e in [e1, e2, e3]]}
    generic, M = pairing_certificate(eta)
    assert generic['rank'] == 6
    rows = list(M.T.rref()[1])
    minor = M[rows, :]
    assert minor.det() != 0
    generic['nonzero_6_by_6_minor_rows'] = rows
    generic['minor_determinant'] = str(minor.det())
    data['exceptional_open_orbit'] = generic

    boundary = {}
    # Pullback diag(t^n_i), n sums zero.  The displayed projective limits
    # follow from the exact weights of the three pieces.
    for name, keep, weights in [
            ('eta1_plus_eta2', [0, 1], [-1, -1, -1, 3]),
            ('eta2_plus_eta3', [1, 2], [-3, 1, 1, 1]),
            ('eta1_plus_eta3', [0, 2], [1, 0, 0, -1])]:
        assert sum(weights) == 0
        e = sum(([e1, e2, e3][i] for i in keep), s.zeros(4, 1))
        ans, _ = pairing_certificate(e)
        piece_weights = []
        for piece in [e1, e2, e3]:
            observed = set()
            for i, f in enumerate(piece):
                for mon, val in s.Poly(f, *xx).terms():
                    if val:
                        observed.add(sum(k*n for k, n in zip(mon, weights))+weights[i])
            assert len(observed) == 1
            piece_weights.append(next(iter(observed)))
        assert set(i for i, val in enumerate(piece_weights) if val == min(piece_weights)) == set(keep)
        ans['diagonal_one_parameter_weights'] = weights
        ans['three_piece_weights'] = piece_weights
        boundary[name] = ans
    assert boundary['eta1_plus_eta2']['pairing_Pfaffian_on_kernel'] == '0'
    assert boundary['eta2_plus_eta3']['pairing_Pfaffian_on_kernel'] == '0'
    assert boundary['eta1_plus_eta3']['pairing_Pfaffian_on_kernel'] != '0'

    q12, q23, q13 = 2*x*z-y*y, 2*y*w-z*z, x*w-y*z
    log12 = -4*w*q12*df(z)+2*z*q12*df(w)+z*w*df(q12)
    log23 = -2*w*q23*df(x)-4*x*q23*df(w)+3*x*w*df(q23)
    log13 = -3*w*q13*df(y)-y*q13*df(w)+2*y*w*df(q13)
    eqzero(log12+2*(e1+e2)); eqzero(log23+2*(e2+e3)); eqzero(log13-(e1+e3))
    boundary['logarithmic_identities'] = {
        '12': '-2*(eta1+eta2)=zw(2xz-y^2)*[-4 dz/z+2 dw/w+d(2xz-y^2)/(2xz-y^2)]',
        '23': '-2*(eta2+eta3)=xw(2yw-z^2)*[-2 dx/x-4 dw/w+3 d(2yw-z^2)/(2yw-z^2)]',
        '13': 'eta1+eta3=yw(xw-yz)*[-3 dy/y-dw/w+2 d(xw-yz)/(xw-yz)]'}
    data['explicit_boundary_orbits'] = boundary

    # The fourth explicit family is obtained by an actual invertible linear
    # substitution for epsilon != 0, followed by epsilon -> 0.
    a, b, eps = s.symbols('a b epsilon')
    g = s.Matrix([eps*x+a*y+b*z, y, z, w])
    pull = (g.jacobian(xx).T*eta.subs(dict(zip(xx, g)), simultaneous=True)).applyfunc(s.expand)
    e0 = pull.subs(eps, 0).applyfunc(s.expand)
    assert e0[0] == 0 and all(s.diff(f, x) == 0 for f in e0)
    assert s.Poly(e0[2], *xx).coeff_monomial(y*y*w) == -2
    ans, M0 = pairing_certificate(e0)
    assert ans['rank'] == 3 and ans['pairing_Pfaffian_on_kernel'] == '0'
    # First three rows give a constant nonzero 3-minor in the only active
    # pairing columns p12,p13,p23.  Thus the conclusion holds at EVERY a,b.
    active_minor = s.factor(M0[:3, 3:6].det())
    assert active_minor != 0 and not active_minor.free_symbols
    ans['constant_rank_witness_minor'] = str(active_minor)
    ans['eta0'] = list(map(str, e0))
    ans['degeneration'] = 'x -> epsilon*x+a*y+b*z; y,z,w fixed; determinant=epsilon'
    ans['conclusion'] = 'This explicit entire LPB family has no nondegenerate primitive pairing.'
    data['explicit_LPB_boundary_family'] = ans
    data['all_checks_passed'] = True
    target = OUT/'exceptional_primitive_certificate.json'
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'all_checks_passed': True, 'certificate': str(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

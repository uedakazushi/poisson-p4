"""Cross-check the new A0 certificate using the historical polynomial engine.

The primary A0 certificate uses a new independent dictionary implementation.
This audit uses a different engine, preserving every rational coefficient.
"""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
from itertools import combinations
import ast,json,sys,hashlib
sys.path.insert(0,str(ROOT/'previous_v6'/'previous_v5'/'code'))
import certify_regular_nilpotent as c
from sympy.polys.matrices import DomainMatrix
s,np=c.sp,c.np
HERE=Path(__file__).resolve().parent
x0,x,y,z,w=c.xx5;xx=c.xx;pairs=list(combinations(range(4),2))
def rk(M):return len(DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1])
def read(data):
 M=s.zeros(4)
 for key,f in data.items():
  I=tuple(ast.literal_eval(key));M[I]=s.sympify(f,locals=dict(zip(('x','y','z','w'),xx)));M[I[::-1]]=-M[I]
 return M
def sparse(M):return {(i+1,j+1):{(0,)+m:v for m,v in s.Poly(M[i,j],*xx).terms() if v} for i,j in pairs}
def vec2(B):return s.Matrix([B.get(I,{}).get(m,0) for I,m in c.p.BIVECTOR_BASIS])
target=[(I,m) for I in combinations(range(1,5),3) for m in c.p.homogeneous_monomials(3) if m[0]==0]
def vec3(B):return s.Matrix([B.get(I,{}).get(m,0) for I,m in target])
def vec4(B):
 out=s.zeros(len(c.p.FOUR_VECTOR_BASIS),1)
 for I,pol in B.items():
  for k in range(5):
   sign=c.p.permutation_sign((k,)+I)
   if sign:
    for mon,v in pol.items():
     mm=list(mon);mm[k]+=1
     out[c.p.FOUR_VECTOR_INDEX[(tuple(sorted((k,)+I)),tuple(mm))]]+=sign*v
 return out
def dictvec(v):
 out={}
 for (I,m),a in zip(c.p.BIVECTOR_BASIS,v):
  if a:out.setdefault(I,{})[m]=a
 return out
def jdict(M):return {I:{(0,)+m:v for m,v in s.Poly(pol,*xx).terms() if v} for I,pol in zip(combinations(range(1,5),3),c.jac(M,xx))}
source=REFERENCE/'a0_thickness_certificate.json'
record=json.loads(source.read_text());Q,R,T=[read(record[k]) for k in ('Q','R','T')]
qs,rs,ts=map(sparse,(Q,R,T))
assert c.jac(Q,xx)==[0]*4
for U in (Q,R,T):assert [s.expand(a-b) for a,b in zip(c.jac(U+c.J,xx),c.jac(U,xx))]==[0]*4
assert vec3(c.polar(qs,rs))==s.zeros(80,1)
assert vec3(c.polar(qs,ts))+vec3(jdict(R))==s.zeros(80,1)
hams=[c.hamiltonian({m:1}) for m in c.p.DEGREE_TWO if m[0]==0]
basis=[c.v.wedge_fields(A,B) for A,B in combinations(hams,2)]
Dq=s.Matrix.hstack(*[vec3(c.polar(qs,B)) for B in basis])
oq=[]
for H in hams:
 A=np.zeros((5,5),dtype=np.int64)
 for i,pol in enumerate(H):
  for m,v in pol.items():A[i,m.index(1)]=v
 oq.append(c.v.linear_action_derivative(qs,A))
Fq=s.Matrix.hstack(*[vec2(B) for B in oq+[qs]])
aq=s.Matrix.hstack(Dq,*[vec3(c.polar(rs,B)) for B in oq+[qs,rs]])
qrank=[rk(Dq),rk(Fq[:,:10]),rk(Fq),rk(Fq.row_join(vec2(rs))),rk(aq),rk(aq.row_join(vec3(c.polar(rs,ts))))]
assert qrank==[34,9,10,11,34,35]
P=s.zeros(5)
for i,j in pairs:P[i+1,j+1]=4*(Q[i,j]+x0*x0*c.J[i,j]);P[j+1,i+1]=-P[i+1,j+1]
ps=c.sparse(P);r4=sparse(4*R);t4=sparse(4*T)
DP=s.Matrix(c.p.linearized_jacobi_matrix(ps));Vert=s.Matrix(c.p.vertical_bivector_matrix())
acts=[dictvec(Vert[:,j]) for j in range(Vert.cols)]
for i in range(5):
 for j in range(5):
  A=np.zeros((5,5),dtype=np.int64);A[i,j]=1
  acts.append(c.v.linear_action_derivative(ps,A))
acts.append(ps)
FP=s.Matrix.hstack(*[vec2(B) for B in acts]);KP=FP.row_join(vec2(r4))
assert DP*KP==s.zeros(350,KP.cols)
assert vec4(c.polar(ps,t4))+vec4(jdict(4*R))==s.zeros(350,1)
ap=s.Matrix.hstack(DP,*[vec4(c.polar(r4,B)) for B in acts+[r4]])
prank=[rk(DP),rk(Vert),rk(FP),rk(KP),rk(ap),rk(ap.row_join(vec4(c.polar(r4,t4))))]
assert prank==[101,24,48,49,101,102]
pf=s.factor((P[1,2]*P[3,4]-P[1,3]*P[2,4]+P[1,4]*P[2,3])/16)
assert s.expand(pf-(x0**4+x0*x0*x*z-z**4/4))==0
out={'all_passed':True,'different_polynomial_engine_from_primary':True,'rational_coefficients_preserved':True,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'quadratic_ranks':qrank,'full_P4_ranks':prank,'integer_lift_scale':4,'Pfaffian':str(pf),'all_first_second_jet_and_full_ambiguity_checks':True}
(DATA/(Path(__file__).stem+'.json')).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

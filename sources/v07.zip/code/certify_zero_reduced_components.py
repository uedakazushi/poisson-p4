"""Exact separation and dimension witnesses for the three reduced zero components."""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
import json
import sympy as s
from certify_logarithmic_boundaries import xx, pairs, mons2, J, df, wedge, star
import itertools

OUT = DATA
x, y, z, w = xx


def vector_wedge_Q(X, Q):
    return [s.expand(X[i]*Q[j, k]-X[j]*Q[i, k]+X[k]*Q[i, j]) for i, j, k in itertools.combinations(range(4), 3)]


def linear_equations(expressions, unknowns):
    coefficients = [c for f in expressions for c in s.Poly(f, *xx).coeffs()]
    return s.linear_eq_to_matrix(coefficients, unknowns)[0]


def qvec(Q):
    return s.Matrix([s.Poly(Q[i, j], *xx).coeff_monomial(m) for i, j in pairs for m in mons2])


def lie_Q(A, Q):
    X = A*s.Matrix(xx)
    return s.Matrix(4, 4, lambda i, j: s.expand(sum(X[k]*s.diff(Q[i, j], xx[k])-A[i, k]*Q[k, j]-A[j, k]*Q[i, k] for k in range(4))))


def main():
    H1, H2 = s.Matrix([x, -y, 0, 0]), s.Matrix([0, 0, z, -w])
    Qc = wedge(H1, H2)
    aa = s.symbols('a0:16')
    A = s.Matrix(4, 4, aa)
    M = linear_equations(vector_wedge_Q(A*s.Matrix(xx), Qc), aa)
    K = M.nullspace()
    assert M.rank() == 14 and len(K) == 2
    N1, N2 = [s.Matrix(4, 4, k) for k in K]
    assert N1 == s.diag(-1, 1, 0, 0)
    assert N2 == s.diag(0, 0, -1, 1)
    r, t = s.symbols('r t')
    N = r*N1+t*N2
    assert N*N == s.diag(r*r, r*r, t*t, t*t)

    # Sp4 orbit has dimension 8; the cone scaling contributes a ninth dimension.
    symplectic_generators = []
    for i in range(4):
        for j in range(i, 4):
            S = s.zeros(4); S[i, j] = 1; S[j, i] = 1
            symplectic_generators.append(J*S)
    orbit = s.Matrix.hstack(*(qvec(lie_Q(B, Qc)) for B in symplectic_generators))
    assert orbit.rank() == 8
    assert orbit.row_join(qvec(Qc)).rank() == 9

    # A generic constant-factor member has a unique constant factor.
    G = z**3+w**3
    Qr = star(wedge(df(x), df(G)))
    V = s.Matrix(s.symbols('v0:4'))
    Mr = linear_equations(vector_wedge_Q(V, Qr), list(V))
    assert Mr.rank() == 3 and Mr.nullspace() == [s.Matrix([0, 1, 0, 0])]
    Mc = linear_equations(vector_wedge_Q(V, Qc), list(V))
    assert Mc.rank() == 4

    # v6 logarithmic component: sample a=1,b=2.
    U = s.Matrix([0, z, 0, 2*x])
    Vlog = s.Matrix([-2*x, 3*y, z, 0*w])
    Ql = wedge(Vlog, U)
    Ml = linear_equations(vector_wedge_Q(V, Ql), list(V))
    assert Ml.rank() == 4
    Umat = U.jacobian(xx)
    assert Umat*Umat == s.zeros(4)
    assert Umat != s.zeros(4)
    assert all(f == 0 for f in vector_wedge_Q(U, Ql))

    data = {'Cartan_all_homogeneous_linear_tangent_fields': {
                'rank_on_16_actual_matrix_entries': M.rank(),
                'kernel_matrices': [[list(map(str, row)) for row in B.tolist()] for B in [N1, N2]],
                'no_quotient_by_Euler': True,
                'square_of_rN1_plus_tN2': 'diag(r^2,r^2,t^2,t^2)',
                'only_square_zero_field': 'r=t=0'},
            'Cartan_Sp4_orbit_rank': orbit.rank(), 'Cartan_orbit_plus_scaling_rank': 9,
            'constant_factor_ranks': {'R_sample': Mr.rank(), 'Cartan_sample': Mc.rank(), 'L_sample': Ml.rank()},
            'R_sample_unique_constant_factor': 'partial_y',
            'L_sample_square_zero_linear_tangent': list(map(str, U)),
            'reduced_zero_component_affine_dimensions': {'R0': 12, 'C0': 9, 'L0': 10},
            'dimension_proofs': 'zero_reduced_components_theorem.txt; L0 dimension was independently certified in v6.',
            'all_checks_passed': True}
    target = OUT/'zero_reduced_components_certificate.json'
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'all_checks_passed': True, 'certificate': str(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

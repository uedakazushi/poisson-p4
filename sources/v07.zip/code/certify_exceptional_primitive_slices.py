"""Exhaust the primitive section of the ENTIRE exceptional orbit closure.

Method: a genuine Borel-stable 13-dimensional linear over-space, three
B-congruence normal forms for nondegenerate alternating pairings, and exact
case analysis of the resulting 5/7/9-variable Pfaffian schemes.  No claim
about a compactification in any external source is used.
"""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
import itertools
import json
import sympy as s
from certify_logarithmic_boundaries import xx, pairs, df, d1, coefficient_matrix, eqzero

OUT = DATA
x, y, z, w = xx


def v(i, j):
    return xx[i]*df(xx[j])-xx[j]*df(xx[i])


def normal_form_basis():
    return [w*w*v(2, 3), z*z*v(2, 3), w*w*v(1, 3), w*w*v(0, 3),
            z*w*v(2, 3), y*w*v(1, 3), w*w*v(1, 2), z*w*v(1, 3),
            z*z*v(1, 3)-s.Rational(3, 2)*z*w*v(1, 2),
            z*w*v(0, 3)-3*w*w*v(0, 2),
            z*z*v(0, 3)-s.Rational(3, 2)*z*w*v(0, 2),
            y*w*v(0, 3)-3*w*w*v(0, 1),
            y*z*v(1, 3)-2*y*w*v(1, 2)]


MON3 = [s.prod(xx[i] for i in ij) for ij in itertools.combinations_with_replacement(range(4), 3)]


def vec(eta):
    return s.Matrix([s.Poly(f, *xx).coeff_monomial(m) for f in eta for m in MON3])


def lie(eta, i, j):
    out = eta.diff(xx[i])*xx[j]
    out[j] += eta[i]
    return out


def equation_span(equations, variables):
    monomials = sorted(set(m for f in equations for m, val in s.Poly(f, *variables).terms() if val))
    return s.Matrix([[s.Poly(f, *variables).coeff_monomial(m) for m in monomials] for f in equations]), monomials


def check_equations(actual, proposed, variables):
    monomials = sorted(set(m for f in actual+proposed for m, val in s.Poly(f, *variables).terms() if val))
    matrix = lambda seq: s.Matrix([[s.Poly(f, *variables).coeff_monomial(m) for m in monomials] for f in seq])
    A, P = matrix(actual), matrix(proposed)
    ranks = [A.rank(), P.rank(), A.col_join(P).rank()]
    assert ranks[0] == ranks[1] == ranks[2] == len(proposed)
    return ranks


def main():
    W = normal_form_basis()
    M = s.Matrix.hstack(*map(vec, W))
    assert M.rank() == 13
    generators = pairs+[(i, i) for i in range(4)]
    stability = {}
    for i, j in generators:
        N = s.Matrix.hstack(*(vec(lie(e, i, j)) for e in W))
        rank = M.row_join(N).rank()
        assert rank == 13
        stability[f'x{j+1} d_x{i+1}'] = rank
    eta_exc = W[12]-2*W[10]+W[11]
    cyclic = [eta_exc]
    cyclic_ranks = []
    for stage in range(3):
        larger = cyclic+[lie(e, i, j) for e in cyclic for i, j in generators]
        N = s.Matrix.hstack(*map(vec, larger))
        piv = N.rref()[1]
        cyclic = [larger[i] for i in piv]
        cyclic_ranks.append(len(cyclic))
    assert cyclic_ranks == [8, 13, 13]

    t = s.symbols('t0:13')
    eta = sum((a*e for a, e in zip(t, W)), s.zeros(4, 1))
    A = d1(eta)
    names = ['12_34', '13_24', '14_23']
    matchings = [[(0, 1), (2, 3)], [(0, 2), (1, 3)], [(0, 3), (1, 2)]]
    slices = {}
    actual_slices = []
    for name, matching in zip(names, matchings):
        primitive = s.expand(sum(A[i, j] for i, j in matching))
        C = coefficient_matrix(primitive, t)
        K = C.nullspace()
        u = s.symbols('u0:'+str(len(K)))
        sol = sum((a*k for a, k in zip(u, K)), s.zeros(13, 1))
        e = eta.subs(dict(zip(t, sol))).applyfunc(s.expand)
        AA = d1(e)
        pf = s.expand(AA[0, 1]*AA[2, 3]-AA[0, 2]*AA[1, 3]+AA[0, 3]*AA[1, 2])
        eq = s.Poly(pf, *xx).coeffs()
        slices[name] = {'primitive_rank': C.rank(), 'variable_count': len(K),
                        'coefficient_substitution': list(map(str, sol)),
                        'eta_coefficients': list(map(str, e))}
        actual_slices.append((u, e, eq))

    # Slice 12|34.  Every one-form has a common factor w.
    u, e, eq = actual_slices[0]
    assert len(u) == 5
    E = [u[3]*u[4], 8*u[1]*u[3]-25*u[4]**2]
    span_ranks = check_equations(eq, E, u)
    assert all(s.rem(f, w, w) == 0 for f in e)
    slices[names[0]].update({'integrability_equations': list(map(str, E)),
                            'equation_row_ranks': span_ranks,
                            'all_points': 'eta divisible by w; divisorial-zero lemma applies.'})

    # Slice 13|24.  Its reduced zero set has exactly the three branches
    # used here; no saturation by u6 is silently discarded.
    u, e, eq = actual_slices[1]
    assert len(u) == 7
    E = [-8*u[2]*u[4]+10*u[2]*u[6]+25*u[5]**2,
         u[6]*(2*u[4]-15*u[6]), u[5]*(12*u[4]+35*u[6])]
    span_ranks = check_equations(eq, E, u)
    s_open = {u[4]: s.Rational(15, 2)*u[6], u[5]: 0, u[2]: 0}
    q = u[6]*(x*z+5*y*w)/2+u[1]*z*z/2+u[3]*z*w/3+u[0]*w*w/4
    elog = -4*w*q*df(z)+2*z*q*df(w)+z*w*df(q)
    eqzero(e.subs(s_open)-elog)
    for missing, sub in [(y, {u[6]: 0, u[5]: 0, u[4]: 0}),
                         (x, {u[6]: 0, u[5]: 0, u[2]: 0})]:
        ee = e.subs(sub)
        idx = xx.index(missing)
        assert ee[idx] == 0 and all(s.diff(f, missing) == 0 for f in ee)
    slices[names[1]].update({'integrability_equations': list(map(str, E)),
        'equation_row_ranks': span_ranks,
        'u6_nonzero': {'forced': ['u4=15*u6/2', 'u5=0', 'u2=0'],
                       'q': str(q), 'log_residues_on_z_w_q': [-4, 2, 1]},
        'u6_zero': 'Equations force u5=0 and u2*u4=0; branches omit y or x respectively.'})

    # Slice 14|23.  Exact reconstruction on u8 != 0, and full closed fiber.
    u, e, eq = actual_slices[2]
    assert len(u) == 9
    E = [100*u[0]*u[8]+60*u[2]*u[7]-3*(2*u[5]+u[6])**2,
         100*u[3]*u[8]-6*u[5]*u[7]+27*u[6]*u[7],
         25*u[1]*u[8]-9*u[7]**2,
         12*u[4]*u[7]+(2*u[5]+11*u[6])*u[8]]
    span_ranks = check_equations(eq, E, u)
    eclosed = e.subs({u[8]: 0, u[7]: 0, u[6]: -2*u[5]})
    assert eclosed[0] == 0 and all(s.diff(f, x) == 0 for f in eclosed)
    L = -s.Rational(5, 3)*u[8]*y+u[7]*z+(2*u[5]+u[6])*w/8
    q = (x*w+s.Rational(3, 5)*y*z-9*u[7]*z*z/(25*u[8])-3*u[4]*y*w/(5*u[8])
         +(24*u[4]*u[7]-26*u[5]*u[8]-23*u[6]*u[8])*z*w/(100*u[8]**2)
         +(-20*u[2]*u[8]+6*u[4]*u[5]+3*u[4]*u[6])*w*w/(100*u[8]**2))
    elog = -3*w*q*df(L)-L*q*df(w)+2*L*w*df(q)
    N = ((12*u[8]*E[0]-3*(2*u[5]+u[6])*E[3])*w*w
         +(12*u[8]*E[1]-24*u[7]*E[3])*w*z
         +48*u[8]*E[2]*z*z+100*u[8]*E[3]*w*y)
    # A polynomial identity after clearing precisely the open denominator.
    eqzero((e-elog)*1200*u[8]**2-N*v(2, 3))
    slices[names[2]].update({'integrability_equations': list(map(str, E)),
        'equation_row_ranks': span_ranks,
        'u8_zero': 'E3 forces u7=0; E1 forces u6=-2*u5; eta omits x.',
        'u8_nonzero': {'L': str(L), 'q': str(q), 'log_residues_on_L_w_q': [-3, -1, 2],
                       'exact_identity': '1200*u8^2*(eta-eta_log)=N*(z dw-w dz)',
                       'N_in_integrability_ideal': str(N)}})

    data = {'scope': 'All primitive points of the full exceptional orbit closure; point-set containment.',
            'external_compactification_used': False,
            'borel_basis_dimension': 13,
            'basis': [list(map(str, e.applyfunc(s.expand))) for e in W],
            'borel_stability_augmented_ranks': stability,
            'cyclic_generation_ranks': cyclic_ranks,
            'normal_pairings': names,
            'slices': slices,
            'conclusion': 'All three slices consist of divisorial-zero, three-variable, or actual Log112 forms. Hence the entire exceptional primitive section is contained in R0 union C0 union L0.',
            'all_checks_passed': True}
    target = OUT/'exceptional_primitive_slices_certificate.json'
    target.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps({'all_checks_passed': True, 'certificate': str(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()

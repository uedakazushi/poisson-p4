"""Independent audit engine for the v7 exceptional Borel-module argument.

No helper from the exceptional proof, the zero-fiber proof, or earlier
versions is imported. All one-forms use their literal polynomial entries.
"""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
from itertools import combinations, combinations_with_replacement
import json
import sympy as s

x,y,z,w = X = s.symbols('x y z w')
PAIRS = list(combinations(range(4),2))
MON3 = [s.prod(X[i] for i in indices) for indices in combinations_with_replacement(range(4),3)]
MON2 = [s.prod(X[i] for i in indices) for indices in combinations_with_replacement(range(4),2)]

def vij(i,j):
    result=s.zeros(4,1)
    result[j]=X[i]
    result[i]=-X[j]
    return result

v12,v13,v14,v23,v24,v34=[vij(i,j) for i,j in PAIRS]
W=[w*w*v34,z*z*v34,w*w*v24,w*w*v14,z*w*v34,y*w*v24,
   w*w*v23,z*w*v24,z*z*v24-s.Rational(3,2)*z*w*v23,
   z*w*v14-3*w*w*v13,z*z*v14-s.Rational(3,2)*z*w*v13,
   y*w*v14-3*w*w*v12,y*z*v24-2*y*w*v23]

def vec(eta):
    return s.Matrix([s.Poly(eta[i],*X).coeff_monomial(m) for i in range(4) for m in MON3])

def exterior_derivative(eta):
    return s.Matrix(4,4,lambda i,j:s.expand(s.diff(eta[j],X[i])-s.diff(eta[i],X[j])))

def df(f):
    return s.Matrix([s.diff(f,q) for q in X])

def assert_zero(values):
    assert all(s.cancel(value)==0 for value in values)

def same_equation_span(actual,proposed,variables):
    exponents=sorted({a for f in actual+proposed for a,c in s.Poly(f,*variables).terms() if c})
    def coefficients(seq):
        return s.Matrix([[s.Poly(f,*variables).coeff_monomial(a) for a in exponents] for f in seq])
    A=coefficients(actual); P=coefficients(proposed)
    ranks=[A.rank(),P.rank(),A.col_join(P).rank()]
    assert ranks==[len(proposed)]*3
    return ranks

def flag_congruence_audit():
    a,b,c,d,e,f=s.symbols('a b c d e f')
    P=s.Matrix([[0,a,b,c],[-a,0,d,e],[-b,-d,0,f],[-c,-e,-f,0]])
    pf=a*f-b*e+c*d
    U1=s.Matrix([[1,0,d/a,e/a],[0,1,-b/a,-c/a],[0,0,1,0],[0,0,0,1]])
    target1=s.zeros(4);target1[0,1]=a;target1[1,0]=-a
    target1[2,3]=pf/a;target1[3,2]=-pf/a
    assert_zero(U1.T*P*U1-target1)
    U2=s.Matrix([[1,-d/b,0,f/b],[0,1,0,0],[0,0,1,-c/b],[0,0,0,1]])
    target2=s.zeros(4);target2[0,2]=b;target2[2,0]=-b
    target2[1,3]=e-c*d/b;target2[3,1]=-e+c*d/b
    assert_zero(U2.T*P.subs(a,0)*U2-target2)
    U3=s.Matrix([[1,-e/c,-f/c,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]])
    target3=s.zeros(4);target3[0,3]=c;target3[3,0]=-c
    target3[1,2]=d;target3[2,1]=-d
    assert_zero(U3.T*P.subs({a:0,b:0})*U3-target3)
    assert U1.det()==U2.det()==U3.det()==1
    return {'branches':['a != 0','a = 0, b != 0','a = b = 0'],
            'pivot_pairs':[['a','Pf(P)/a'],['b','-Pf(P)/b'],['c','d']],
            'upper_triangular_congruence_identities_verified':3,
            'note':'Nondegeneracy makes both pivots nonzero in every branch; diagonal scaling gives the three matchings.'}

def lie(eta,i,j):
    # Pullback by the upper triangular coordinate change x_i -> x_i+t*x_j.
    return s.Matrix([s.expand(X[j]*s.diff(eta[k],X[i])+(eta[i] if k==j else 0)) for k in range(4)])

def pairing_matrix(eta, pairing, coefficients):
    alpha=exterior_derivative(eta)
    polynomial=sum(alpha[i,j] for i,j in pairing)
    equations=[s.Poly(polynomial,*X).coeff_monomial(m) for m in MON2]
    return s.linear_eq_to_matrix(equations,coefficients)[0]

def main():
    B=s.Matrix.hstack(*[vec(e) for e in W])
    assert B.shape==(80,13) and B.rank()==13
    assert all(s.expand(sum(X[i]*e[i] for i in range(4)))==0 for e in W)
    operators=[]
    for i in range(4):
        for j in range(i,4):
            target=s.Matrix.hstack(*[vec(lie(e,i,j)) for e in W])
            op,parameters=B.gauss_jordan_solve(target)
            assert not parameters.rows and B*op==target
            operators.append(((i,j),op))
    start=s.zeros(13,1);start[12]=1;start[10]=-2;start[11]=1
    cyclic=start
    dimensions=[]
    while True:
        candidates=s.Matrix.hstack(cyclic,*[op*cyclic for pair,op in operators])
        pivots=candidates.rref()[1]
        expanded=candidates[:,list(pivots)]
        dimensions.append(expanded.cols)
        if expanded.cols==cyclic.cols:
            break
        cyclic=expanded
    assert cyclic.cols==13
    c=s.symbols('c0:13')
    eta=sum((a*e for a,e in zip(c,W)),s.zeros(4,1))
    cases={}
    for label,pairing,expected in [('12_34',[(0,1),(2,3)],5),
                                   ('13_24',[(0,2),(1,3)],7),
                                   ('14_23',[(0,3),(1,2)],9)]:
        M=pairing_matrix(eta,pairing,c)
        K=M.nullspace()
        assert len(K)==expected
        u=s.symbols('u0:'+str(expected))
        param=sum((a*b for a,b in zip(u,K)),s.zeros(13,1))
        form=eta.subs(dict(zip(c,param)),simultaneous=True).applyfunc(s.expand)
        alpha=exterior_derivative(form)
        pf=s.expand(alpha[0,1]*alpha[2,3]-alpha[0,2]*alpha[1,3]+alpha[0,3]*alpha[1,2])
        equations=s.Poly(pf,*X).coeffs()
        G=s.groebner(equations,*u)
        if expected==5:
            proposed=[u[3]*u[4],8*u[1]*u[3]-25*u[4]**2]
            assert all(s.expand(f).subs(w,0)==0 for f in form)
            interpretation='All one-form coefficients have the common factor w.'
        elif expected==7:
            proposed=[-8*u[2]*u[4]+10*u[2]*u[6]+25*u[5]**2,
                      u[6]*(2*u[4]-15*u[6]),u[5]*(12*u[4]+35*u[6])]
            q=u[6]*(x*z+5*y*w)/2+u[1]*z*z/2+u[3]*z*w/3+u[0]*w*w/4
            log=-4*w*q*df(z)+2*z*q*df(w)+z*w*df(q)
            assert_zero(form.subs({u[4]:s.Rational(15,2)*u[6],u[5]:0,u[2]:0})-log)
            for missing,condition in [(1,{u[6]:0,u[5]:0,u[4]:0}),
                                      (0,{u[6]:0,u[5]:0,u[2]:0})]:
                closed=form.subs(condition)
                assert s.expand(closed[missing])==0
                assert_zero([s.diff(f,X[missing]) for f in closed])
            interpretation='u6 != 0: exact Log112; u6 = 0: both complete branches omit one coordinate.'
        else:
            proposed=[100*u[0]*u[8]+60*u[2]*u[7]-3*(2*u[5]+u[6])**2,
                      100*u[3]*u[8]-6*u[5]*u[7]+27*u[6]*u[7],
                      25*u[1]*u[8]-9*u[7]**2,
                      12*u[4]*u[7]+(2*u[5]+11*u[6])*u[8]]
            closed=form.subs({u[8]:0,u[7]:0,u[6]:-2*u[5]})
            assert s.expand(closed[0])==0
            assert_zero([s.diff(f,x) for f in closed])
            L=-s.Rational(5,3)*u[8]*y+u[7]*z+(2*u[5]+u[6])*w/8
            q=(x*w+s.Rational(3,5)*y*z-9*u[7]*z*z/(25*u[8])-3*u[4]*y*w/(5*u[8])
               +(24*u[4]*u[7]-26*u[5]*u[8]-23*u[6]*u[8])*z*w/(100*u[8]**2)
               +(-20*u[2]*u[8]+6*u[4]*u[5]+3*u[4]*u[6])*w*w/(100*u[8]**2))
            log=-3*w*q*df(L)-L*q*df(w)+2*L*w*df(q)
            E1,E2,E3,E4=proposed
            N=(12*u[8]*E1-3*(2*u[5]+u[6])*E4)*w*w
            N+=(12*u[8]*E2-24*u[7]*E4)*w*z+48*u[8]*E3*z*z+100*u[8]*E4*w*y
            assert_zero(1200*u[8]**2*(form-log)-N*v34)
            interpretation='u8 != 0: full polynomial ideal identity to Log112; u8 = 0: entire closed branch omits x.'
        ranks=same_equation_span(equations,proposed,u)
        cases[label]={'pairing_rank':M.rank(),'dimension':expected,
                      'kernel_in_W_coordinates':[list(map(str,k)) for k in K],
                      'one_form':list(map(str,form)),
                      'integrability_groebner':[str(p.as_expr()) for p in G.polys],
                      'independent_equation_span_ranks':ranks,
                      'proposed_equations':[str(f) for f in proposed],
                      'all_branch_identities_verified':True,'interpretation':interpretation}
        print(label,'dimension',expected,'GB',[s.factor(p.as_expr()) for p in G.polys],flush=True)
    data={'independent_basis_rank':13,'Lie_B_stability_generators':10,
          'cyclic_module_dimensions':dimensions,'pairing_slices':cases,
          'B_congruence_normal_form_audit':flag_congruence_audit(),
          'all_checks_passed':True}
    (DATA/(Path(__file__).stem+'.json')).write_text(json.dumps(data,indent=2)+'\n')
    print('ALL CURRENT CHECKS PASSED',flush=True)

if __name__=='__main__':main()

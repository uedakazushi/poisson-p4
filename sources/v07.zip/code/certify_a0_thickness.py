#!/usr/bin/env python3
"""Exact full-Q and full-P4 certificate for the closed nil22 A0 component."""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
from itertools import combinations
import json
import sympy as s
from independent_minimal_thickness_audit import Calculus,rank,constant_compatibility,symplectic_orbit
HERE=Path(__file__).resolve().parent

def solve0(M,b):
    sol,free=M.gauss_jordan_solve(b)
    return sol.subs({v:0 for v in free})

def main():
    C=Calculus(4);C.x=s.symbols('x y z w');x,y,z,w=C.x
    P=Calculus(5);P.x=s.symbols('x0 x y z w');x0=P.x[0]
    J=C.tensor({(0,1):1,(2,3):1})
    Q=C.tensor({(0,1):s.Rational(3,4)*x*z,(0,3):z*z+s.Rational(3,4)*x*x,
                (1,2):-z*z/4,(1,3):x*x+2*x*z+3*z*z-s.Rational(3,4)*x*y+z*w/4,(2,3):x*z/4})
    CC,B=constant_compatibility(C,J)
    D=C.derivative(Q)*B
    trace=s.Matrix([[C.from_vector(B[:,i]).get((0,1),{}).get(m,0)+C.from_vector(B[:,i]).get((2,3),{}).get(m,0) for i in range(45)] for m in C.m2])
    goal=C.pol(3*x*y+z*w)
    R=C.from_vector(B*solve0(D.col_join(trace),s.zeros(80,1).col_join(s.Matrix([goal.get(m,0) for m in C.m2]))))
    T=C.from_vector(B*solve0(D,-C.cubic_vector(C.jacobi(R))))
    assert not any(C.cubic_vector(C.jacobi(Q)))
    for A in [Q,R,T]:assert CC*C.vector(A)==s.zeros(16,1)
    assert not any(C.cubic_vector(C.polar(Q,R)))
    assert C.cubic_vector(C.polar(Q,T))+C.cubic_vector(C.jacobi(R))==s.zeros(80,1)
    O=symplectic_orbit(C,J,Q);F=s.Matrix.hstack(*[C.vector(Z) for Z in O+[Q]])
    K=F.row_join(C.vector(R));Amb=s.Matrix.hstack(D,*[C.cubic_vector(C.polar(R,Z)) for Z in O+[Q,R]])
    Obs=C.cubic_vector(C.polar(R,T));A3=Amb.row_join(Obs)
    qq={'Jacobi_rank':rank(D),'Sp4_orbit_rank':rank(F[:,:10]),'orbit_times_scale_rank':rank(F),
        'actual_plus_R_rank':rank(K),'ambiguity_rank':rank(Amb),'third_rank':rank(A3)}
    assert list(qq.values())==[34,9,10,11,34,35]
    print('Q',qq,flush=True)
    PQ=C.lift(Q,P);PR=C.lift(R,P);PT=C.lift(T,P)
    for I in [(1,2),(3,4)]:PQ.setdefault(I,{})[(2,0,0,0,0)]=1
    DP=P.derivative(PQ,True)
    VV=[P.vertical(i,j) for i in range(5) for j in range(5)]
    OP=[]
    for i in range(5):
        for j in range(5):
            X=s.zeros(5,1);X[i]=P.x[j];OP.append(P.lie(PQ,X))
    V=s.Matrix.hstack(*[P.vector(Z) for Z in VV]);FP=s.Matrix.hstack(V,*[P.vector(Z) for Z in OP+[PQ]])
    KP=FP.row_join(P.vector(PR))
    assert DP*KP==s.zeros(350,KP.cols)
    assert P.euler_vector(P.polar(PQ,PT))+P.euler_vector(P.jacobi(PR))==s.zeros(350,1)
    AP=s.Matrix.hstack(DP,*[P.euler_vector(P.polar(PR,Z)) for Z in VV+OP+[PQ,PR]])
    AP3=AP.row_join(P.euler_vector(P.polar(PR,PT)))
    pp={'Jacobi_rank':rank(DP),'vertical_rank':rank(V),'vertical_orbit_scale_rank':rank(FP),
        'actual_plus_R_rank':rank(KP),'ambiguity_rank':rank(AP),'third_rank':rank(AP3)}
    assert list(pp.values())==[101,24,48,49,101,102]
    M=P.as_matrix(PQ);pf=s.factor(M[1,2]*M[3,4]-M[1,3]*M[2,4]+M[1,4]*M[2,3])
    assert s.expand(pf-(x0**4+x0*x0*x*z-z**4/4))==0
    # A0's exact four-parameter fixed-trace family, verified symbolically.
    a,p3,p4,p5=s.symbols('a p3 p4 p5');F0=C.as_matrix(Q)
    F0[0,3]=a*z*z+3*x*x/4;F0[3,0]=-F0[0,3]
    F0[1,3]=p3*x*x+p4*x*z+p5*z*z-3*x*y/4+z*w/4;F0[3,1]=-F0[1,3]
    jac=[s.expand(sum(F0[i,l]*s.diff(F0[j,k],C.x[l])+F0[j,l]*s.diff(F0[k,i],C.x[l])+F0[k,l]*s.diff(F0[i,j],C.x[l]) for l in range(4))) for i,j,k in C.triples]
    assert jac==[0]*4
    at={a:1,p3:1,p4:2,p5:3}
    family=[C.tensor({I:s.diff(F0[I],t).subs(at) for I in C.pairs}) for t in [a,p3,p4,p5]]
    actual_family=s.Matrix.hstack(*[C.vector(Z) for Z in O+family])
    assert rank(actual_family)==10
    report={'all_passed':True,'Q':C.encode(Q),'R':C.encode(R),'T':C.encode(T),
            'quadratic':qq,'P4':pp,'Pfaffian':str(pf),'degeneracy_divisor':str(x0*pf),
            'fixed_trace_family_Jacobi_identity':True,'fixed_trace_family_plus_Sp4_rank':10,
            'all_first_and_second_jet_identities_verified':True,
            'generic_transverse_ring':'K[epsilon]/(epsilon^3)','generic_length':3,
            'reduced_Q_component_dimension':10,'projective_P4_component_dimension':23,
            'projective_generic_orbit_dimension':23,
            'trace_R':str(s.factor(C.as_matrix(R)[0,1]+C.as_matrix(R)[2,3]))}
    (DATA/'a0_thickness_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print('P4',pp,flush=True);print('R',C.encode(R),flush=True);print('T',C.encode(T),flush=True)

if __name__=='__main__':main()

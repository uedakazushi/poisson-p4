#!/usr/bin/env python3
"""Independent symbolic-universal audit of two full150 quartic exclusions.

This does not import quartic_models, quartic_certificate, or any Poisson
helper. It first forms a universal antisymmetric polynomial matrix with
150 symbolic coefficients, then differentiates and contracts it directly.
"""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
from itertools import combinations,combinations_with_replacement
import hashlib,json
import sympy as s
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent

def main():
    source=REFERENCE/'quartic_certificate.json'
    reference=json.loads(source.read_text())
    xx=s.symbols('x y z u v');x,y,z,u,v=xx
    pairs=list(combinations(range(5),2))
    monomials=[s.prod(xx[i] for i in I) for I in combinations_with_replacement(range(5),2)]
    coeff=s.symbols('q0:150');Q=s.zeros(5)
    for k,(i,j) in enumerate(pairs):
        Q[i,j]=sum(coeff[15*k+a]*m for a,m in enumerate(monomials));Q[j,i]=-Q[i,j]
    divergence=s.Matrix([sum(s.diff(Q[i,j],xx[i]) for i in range(5)) for j in range(5)])
    examples=[('double_plane_quartic',x**3*v+x*x*z*z+x*y*z*u+y*y*u*u+y**3*z,436,836086),
              ('bihomogeneous_22',x*x*(z*z+u*u+v*v)+x*y*(z*u+u*v+z*v)+y*y*(z*z+2*u*u+3*v*v),508,796551)]
    out={}
    for name,F,expected_rows,expected_det in examples:
        contraction=Q.T*s.Matrix([s.diff(F,z) for z in xx])
        polynomials={}
        for label,vec in [('central',contraction),('divergence',divergence)]:
            for j,f in enumerate(vec):
                for exp,c in s.Poly(s.expand(f),*xx).terms():
                    if c!=0:polynomials[label,j,exp]=c
        labels=sorted(polynomials)
        M,b=s.linear_eq_to_matrix([polynomials[key] for key in labels],coeff)
        assert not any(b) and M.shape==(expected_rows,150)
        dm=DomainMatrix.from_Matrix(M).convert_to(s.QQ);_,piv=dm.rref()
        assert len(piv)==150
        item=next(a for a in reference['open_family_exclusions'] if a['name']==name)
        rows=item['minor_rows_zero_based'];prime=item['minor_prime']
        source_labels=[(a[0],a[1],tuple(a[2])) for a in item['minor_row_labels']]
        assert [labels[i] for i in rows]==source_labels
        determinant=int(DomainMatrix.from_Matrix(M[rows,:]).convert_to(s.GF(prime)).det())%prime
        assert determinant==item['minor_determinant_mod_prime']==expected_det
        entry={'matrix_shape':list(M.shape),'exact_QQ_rank':len(piv),'kernel_dimension':0,
               'minor_rows_match_source_labels':True,'minor_prime':prime,'independent_minor_determinant':determinant,
               'polynomial':str(F),'all_passed':True}
        if name=='double_plane_quartic':
            R=s.expand(F-x**3*v);assert s.degree(F,v)==1 and s.gcd(x**3,R)==1
            partials=[s.diff(F,z) for z in xx]
            assert all(f.subs({x:0,y:0})==0 for f in partials)
            mon3=sorted({m for f in partials for m,c in s.Poly(f,*xx).terms() if c})
            PM=s.Matrix([[s.Poly(f,*xx).coeff_monomial(m) for f in partials] for m in mon3])
            assert PM.rank()==5
            gg=partials[0]
            for f in partials[1:]:gg=s.gcd(gg,f)
            assert gg==1
            entry.update(essential_variable_count=5,primitive_linear_in_v=True,gradient_ideal_height=2)
        out[name]=entry;print(name,entry,flush=True)
    out['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
    out['independent_universal_matrix_implementation']=True;out['all_passed']=True
    (DATA/'independent_quartic_rank_audit.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()

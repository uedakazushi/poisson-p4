#!/usr/bin/env python3
"""Explicit polynomial degenerations from G1/G2 to four closed nil22 strata."""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
from itertools import combinations
import json
import sympy as s
HERE=Path(__file__).resolve().parent
x,y,z,w,t=s.symbols('x y z w t');xx=(x,y,z,w);pairs=list(combinations(range(4),2))
l,m,n,aa,bb,ee,e=s.symbols('l m n aa bb ee e')
parameters=[l,m,n,aa,bb,ee]
J=s.Matrix([[0,1,0,0],[-1,0,0,0],[0,0,0,1],[0,0,-1,0]])

def normal(kind,A,B,E):
    vals=[A*x*y if kind=='G1' else A*x*y+B*z*w,E*x*z,-E*x*w,
          -E*y*z if kind=='G1' else -(B+E)*y*z,
          E*y*w if kind=='G1' else (B+E)*y*w,B*z*w]
    Q=s.zeros(4)
    for I,f in zip(pairs,vals):Q[I]=f;Q[I[::-1]]=-f
    return Q
def jac(Q):
    return [s.expand(sum(Q[i,h]*s.diff(Q[j,k],xx[h])+Q[j,h]*s.diff(Q[k,i],xx[h])+Q[k,h]*s.diff(Q[i,j],xx[h]) for h in range(4))) for i,j,k in combinations(range(4),3)]
def encode(Q):return {str(I):str(s.expand(Q[I])) for I in pairs}

def build(name):
    # q=(x,z), p=(y,w); p' = p + (K0/t+L) q.
    if name=='L1':kind='G1';alpha=beta=1;eta=e;K0=(0,s.Rational(1,2),0);T=s.eye(4)
    elif name=='L0':kind='G2';alpha=-1;beta=1;eta=e;K0=(0,1,0);T=s.eye(4)
    elif name=='A1':
        kind='G1';alpha=beta=1;eta=s.Rational(1,2);K0=(0,s.Rational(1,2),1)
        T=s.Matrix([[1,0,1,0],[0,1,0,0],[0,0,1,0],[0,-1,0,1]])
    elif name=='U0':
        kind='G2';alpha=beta=1;eta=-1;K0=(1,1,1)
        T=s.Matrix([[1,0,2,0],[0,-1,0,1],[1,0,1,0],[0,2,0,-1]])
    else:raise ValueError(name)
    a0,b0,d0=K0;a=a0/t+l;b=b0/t+m;d=d0/t+n
    S=s.Matrix([[1,0,0,0],[a,1,b,0],[0,0,1,0],[b,0,d,1]])
    assert S*J*S.T==J and T*J*T.T==J
    N=normal(kind,t*alpha+t*t*aa,t*beta+t*t*bb,t*eta+t*t*ee)
    sub=dict(zip(xx,S*s.Matrix(xx)))
    P=(S.inv()*N.subs(sub,simultaneous=True)*S.inv().T).applyfunc(s.expand)
    # Now use the new fixed symplectic base coordinates T*x.
    P=(T*P.subs(dict(zip(xx,T.inv()*s.Matrix(xx))),simultaneous=True)*T.T).applyfunc(s.expand)
    assert all(s.Poly(P[I],t).degree()>=0 for I in pairs if P[I]!=0)
    F=P.subs(t,0).applyfunc(s.expand)
    assert s.expand(F[0,1]+F[2,3]-x*z)==0
    # All parameters affect only the free magnetic binary quadratic.
    base=F.subs({v:0 for v in parameters})
    for I in pairs:
        if I!=(1,3):assert s.expand(F[I]-base[I])==0
    magnetic=s.expand(F[1,3]-base[1,3])
    coeff=s.Matrix([s.Poly(magnetic,*xx).coeff_monomial(mon) for mon in [x*x,x*z,z*z]])
    linear=coeff.jacobian(parameters);assert all(s.diff(q,v)==0 for q in linear for v in parameters)
    rank=linear.rank();assert rank==3
    cols=linear.rref()[1];minor=s.factor(linear[:,list(cols)].det())
    print(name,'base',encode(base),'magnetic=',s.factor(magnetic),'minor=',minor,flush=True)
    # Direct identities in the whole universal polynomial family.
    assert jac(P)==[0]*4
    assert [s.expand(a-b) for a,b in zip(jac(P+J),jac(P))]==[0]*4
    report={'source_component':kind,'target_stratum':name,'fixed_K0':[str(a0),str(b0),str(d0)],
            'fixed_symplectic_coordinate_matrix':[[str(v) for v in T.row(i)] for i in range(4)],
            'leading_coefficients':[str(alpha),str(beta),str(eta)],
            'family_is_polynomial_in_t':True,'full_family_Jacobi_identity':True,'full_family_compatibility_identity':True,
            'base_limit':encode(base),'limit':encode(F),'magnetic_coefficients':[str(v) for v in coeff],
            'magnetic_coefficient_matrix':[[str(v) for v in linear.row(i)] for i in range(3)],
            'magnetic_rank':int(rank),'chosen_parameter_columns':list(cols),'magnetic_minor':str(minor),
            'polynomial_family':encode(P),'all_passed':True}
    return report

def main():
    out={name:build(name) for name in ['L1','L0','A1','U0']}
    A,B,E=s.symbols('A B E')
    deltas={}
    for kind in ['G1','G2']:
        Q=normal(kind,A,B,E);tr=Q[0,1]+Q[2,3]
        pf=Q[0,1]*Q[2,3]-Q[0,2]*Q[1,3]+Q[0,3]*Q[1,2]
        delta=s.factor(tr*tr-4*pf)
        expected=(A*x*y-B*z*w)**2 if kind=='G1' else A*A*x*x*y*y
        assert s.expand(delta-expected)==0
        deltas[kind]=str(delta)
    out['reduced_support_square_discriminant']=deltas
    out['all_passed']=True
    (DATA/'boundary_deformations_certificate.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()

"""Exact local jets at the remaining minimal-nilpotent component."""
from v7_paths import ROOT, DATA, REFERENCE
from pathlib import Path
from itertools import combinations
import sys,json
sys.path.insert(0,str(ROOT/'previous_v6'/'previous_v5'/'code'))
import certify_regular_nilpotent as c
s,np=c.sp,c.np
x0,x,y,z,w=c.xx5;xx=c.xx;pairs=list(combinations(range(4),2))
def make(vals):
 Q=s.zeros(4)
 for ij,v in zip(pairs,vals):Q[ij]=v;Q[ij[::-1]]=-v
 return Q
Q=make([3*x*x-6*x*z,0,-2*x*x,3*x*z-18*z*z,6*x*x-2*x*y-3*x*w+30*z*w,6*x*z])
def sparse(M):
 return { (i+1,j+1):{(0,)+m:v for m,v in s.Poly(M[i,j],*xx).terms() if v} for i,j in pairs}
def vec2(B):return s.Matrix([B.get(I,{}).get(m,0) for I,m in c.p.BIVECTOR_BASIS])
target=[(I,m) for I in combinations(range(1,5),3) for m in c.p.homogeneous_monomials(3) if m[0]==0]
def vec3(B):return s.Matrix([B.get(I,{}).get(m,0) for I,m in target])
def vec4(B):
 out=s.zeros(len(c.p.FOUR_VECTOR_BASIS),1)
 for I,pol in B.items():
  for k in range(5):
   sign=c.p.permutation_sign((k,)+I)
   if sign:
    for mon,v in pol.items():
     mm=list(mon);mm[k]+=1
     out[c.p.FOUR_VECTOR_INDEX[(tuple(sorted((k,)+I)),tuple(mm))]]+=sign*v
 return out
def tensor(v):
 M=s.zeros(4)
 for (I,m),coef in zip(c.p.BIVECTOR_BASIS,v):
  if coef:
   assert 0 not in I and m[0]==0
   t=coef*s.prod(u**k for u,k in zip(c.xx5,m))
   M[I[0]-1,I[1]-1]+=t;M[I[1]-1,I[0]-1]-=t
 return M.applyfunc(s.factor)
def encode(M):return {str(I):str(s.factor(M[I])) for I in pairs}
def jdict(M):
 return {I:{(0,)+m:v for m,v in s.Poly(pol,*xx).terms() if v} for I,pol in zip(combinations(range(1,5),3),c.jac(M,xx))}
def solve0(D,b):
 sol,free=D.gauss_jordan_solve(b)
 return sol.subs({u:0 for u in free})
def rk(M):return M.rank()
qs=sparse(Q)
assert c.jac(Q,xx)==[0]*4 and c.jac(Q+c.J,xx)==[0]*4
hams=[c.hamiltonian({m:1}) for m in c.p.DEGREE_TWO if m[0]==0]
basis=[c.v.wedge_fields(A,B) for A,B in combinations(hams,2)]
BB=s.Matrix.hstack(*[vec2(B) for B in basis])
Dq=s.Matrix.hstack(*[vec3(c.polar(qs,B)) for B in basis])
trmons=[m for m in c.p.DEGREE_TWO if m[0]==0]
Tr=s.Matrix([[B.get((1,2),{}).get(m,0)+B.get((3,4),{}).get(m,0) for B in basis] for m in trmons])
trgoal=s.Matrix([int(m==(0,0,0,1,1)) for m in trmons])
R=tensor(BB*solve0(Dq.col_join(Tr),s.zeros(Dq.rows,1).col_join(trgoal)))
rs=sparse(R)
assert s.expand(R[0,1]+R[2,3]-z*w)==0
assert vec3(c.polar(qs,rs))==s.zeros(Dq.rows,1)
T=tensor(BB*solve0(Dq,-vec3(jdict(R))))
ts=sparse(T)
assert vec3(c.polar(qs,ts))+vec3(jdict(R))==s.zeros(Dq.rows,1)
assert c.jac(R+c.J,xx)==c.jac(R,xx)
assert c.jac(T+c.J,xx)==c.jac(T,xx)
print('R=',encode(R),flush=True);print('T=',encode(T),flush=True)
oq=[]
for H in hams:
 A=np.zeros((5,5),dtype=np.int64)
 for i,pol in enumerate(H):
  for m,v in pol.items():A[i,m.index(1)]=v
 oq.append(c.v.linear_action_derivative(qs,A))
Fq=s.Matrix.hstack(*[vec2(B) for B in oq+[qs]])
Kq=Fq.row_join(vec2(rs))
ambiguityq=s.Matrix.hstack(*[vec3(c.polar(rs,B)) for B in oq+[qs,rs]])
obs=c.polar(rs,ts)
qresult={'Jacobi_rank':rk(Dq),'Sp4_orbit_rank':rk(Fq[:,:10]),'actual_Sp4_times_scale_rank':rk(Fq),'actual_plus_R_rank':rk(Kq),'ambiguity_rank':rk(Dq.row_join(ambiguityq)),'third_rank':rk(Dq.row_join(ambiguityq).row_join(vec3(obs)))}
print('QUADRATIC',qresult,flush=True)
P=s.zeros(5)
for i,j in pairs:P[i+1,j+1]=Q[i,j]+x0*x0*c.J[i,j];P[j+1,i+1]=-P[i+1,j+1]
ps=c.sparse(P);DP=s.Matrix(c.p.linearized_jacobi_matrix(ps));Vert=s.Matrix(c.p.vertical_bivector_matrix())
def sparse150(v):
 out={}
 for (I,m),coef in zip(c.p.BIVECTOR_BASIS,v):
  if coef:out.setdefault(I,{})[m]=coef
 return out
actual=[sparse150(v) for v in Vert.columnspace()]
orbit=[]
for i in range(5):
 for j in range(5):
  A=np.zeros((5,5),dtype=np.int64);A[i,j]=1
  orbit.append(c.v.linear_action_derivative(ps,A))
actual+=orbit+[ps]
FP=s.Matrix.hstack(*[vec2(B) for B in actual]);KP=FP.row_join(vec2(rs))
assert DP*KP==s.zeros(DP.rows,KP.cols)
ambiguity=s.Matrix.hstack(*[vec4(c.polar(rs,B)) for B in actual+[rs]])
presult={'Jacobi_rank':rk(DP),'vertical_rank':rk(Vert),'actual_vertical_orbit_scale_rank':rk(FP),'actual_plus_R_rank':rk(KP),'ambiguity_rank':rk(DP.row_join(ambiguity)),'third_rank':rk(DP.row_join(ambiguity).row_join(vec4(obs)))}
print('FULL P4',presult,flush=True)
pf=s.factor(P[1,2]*P[3,4]-P[1,3]*P[2,4]+P[1,4]*P[2,3])
print('Pf=',pf,flush=True)
out={'Q':encode(Q),'R':encode(R),'T':encode(T),'quadratic':qresult,'P4':presult,'Pfaffian':str(pf),'obstruction':{str(I):{str(m):str(v) for m,v in pol.items()} for I,pol in obs.items() if pol}}
def cokernel_witness(D,o,labels):
 candidates=[]
 for ell in D.T.nullspace():
  value=(ell.T*o)[0]
  if value:
   supp=[i for i,c0 in enumerate(ell) if c0]
   candidates.append((len(supp),ell,value,supp))
 assert candidates
 _,ell,value,supp=min(candidates,key=lambda a:a[0])
 assert ell.T*D==s.zeros(1,D.cols)
 return {'functional':[{'target':str(labels[i]),'coefficient':str(ell[i])} for i in supp], 'value_on_obstruction':str(value)}
out['quadratic_cokernel_witness']=cokernel_witness(Dq,vec3(obs),target)
out['full_P4_cokernel_witness']=cokernel_witness(DP,vec4(obs),c.p.FOUR_VECTOR_BASIS)
print('COKERNEL WITNESSES',json.dumps({k:out[k] for k in ('quadratic_cokernel_witness','full_P4_cokernel_witness')}),flush=True)
assert qresult=={'Jacobi_rank':34,'Sp4_orbit_rank':9,'actual_Sp4_times_scale_rank':10,'actual_plus_R_rank':11,'ambiguity_rank':34,'third_rank':35}
assert presult=={'Jacobi_rank':101,'vertical_rank':24,'actual_vertical_orbit_scale_rank':48,'actual_plus_R_rank':49,'ambiguity_rank':101,'third_rank':102}
out['all_passed']=True
(DATA/(Path(__file__).stem+'.json')).write_text(json.dumps(out,indent=2)+'\n')

射影4空間の Poisson 構造：研究継続 v7
====================================
2026年10月29日

最初に読むファイル
------------------
p4_poisson_completeness_v7.pdf
  日本語の LuaLaTeX 本文。今回の全主張、証明、旧結果への依存、未完了の範囲を収録。
  記入欄・入力フォームはありません。

確定した今回の到達点
--------------------
1. 全射影 Poisson scheme P(Pois(P4)) の既約成分数は少なくとも55。
   前回52に、23次元の3成分 M, A0, D±を追加。
   いずれも開PGL5軌道と一般横断環 K[e]/(e^3) を持つ。
2. J互換な二次Poisson構造の45変数補助空間Qは、被約既約成分がちょうど22。
   次元別は13次元2個、11次元2個、10次元17個、9次元1個。
3. 零モジュラーfiberの被約既約成分はちょうど3個、次元12,9,10。
   exceptional componentの全原始切断も、実際のBorel表現から独立に処理。
4. 安定rank2分岐では、非正規を含む全ての既約四次Casimir coneを排除。
   残る四次候補は本質五変数、勾配イデアルの高さ2または3。
   二つの特異平面を持つ線形系の一般点も、全150係数で排除。

範囲の区別
----------
補助空間Qの22成分分類は、全P4の完全分類ではありません。
55は全P4の下界です。PGL商の次元、固定モジュラーfiberの成分数、
補助空間の成分数、全射影schemeの成分数を区別しています。
全ての群軌道の一意標準形、全境界のprimary decomposition、embedded components、
商stack、成分の全scheme交叉は未分類です。
文献上の新規性は本bundleの検証対象としていません。

ファイル構成
------------
*.tex                         本文・節別の完全なLuaLaTeXソース
code/                         今回の再現コードと実行器
data/                         参照用の厳密計算証明書
data/reproduced/               配布版コードで再実行した証明書とログ
proofs/                       詳細な数学的証明と独立監査
previous_v6/                  v6の全275ファイルをbyte単位で保持
                              内部にv5以下の証明とコードも保持
SHA256SUMS.txt                 本bundle各ファイルのSHA-256（このmanifest自体は除く）

再現方法
--------
Python 3.12、SymPy 1.14.0、NumPy 2.3.5で検証しました。
既存のPython環境に合わせて、必要に応じ仮想環境を作りrequirements.txtを導入してください。

  python3 -m venv .venv
  .venv/bin/python -m pip install -r requirements.txt
  .venv/bin/python code/run_v7_checks.py --jobs 3

18本の検証プログラムを実行します。並列度は--jobsで変更できます。
参照証明書は変更せず、既定でdata/reproduced/へ再生成します。
出力先の変更例：

  python3 code/run_v7_checks.py --jobs 1 --output-dir /absolute/path/to/results

個別スクリプトも実行できます。環境変数P4_V7_OUTPUT_DIRで出力先を変えられます。
引数が必要な高次jetスクリプトの例：

  python3 code/one_normal_higher_jets.py Cplus Dplus

全計算は有理数、QQ(sqrt(3))、QQ(p3,p4,p5)上の厳密計算です。
有限体minorは素数1000003を用い、その行ラベル・基底順序・行番号をJSONに保持。
浮動小数点rankの推定は使いません。

LuaLaTeX本文の再作成
-------------------
LuaLaTeX、LuaTeX-ja、HaranoAji fonts、latexmkを含むTeX Live環境で、

  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v7.tex

を実行してください。

主な監査の所在
--------------
proofs/root_mathematical_audit.txt
proofs/independent_minimal_thickness_audit.txt
proofs/dplus_geometry_audit.txt
proofs/independent_quartic_rank_audit.txt
proofs/quartic_cone_independent_audit.txt
proofs/exceptional_boundary_independent_audit.txt

proofs内の各担当HANDOFFは作業記録として元の検証時点のパスを含むことがあります。
配布後の実行には上記code/のportable scriptsと本READMEの手順を用いてください。

次に残る研究
------------
・全61変数sliceの、二次部分以外の16方向との相互作用。
・Cplus,Cminus,U1,ABの斉次化の、全P4内での成分の帰属。
・安定rank2の本質五変数四次、最小中心次数5以上、必要な多項式中心元がない場合。
・全78変数slice、因子的零点、全scheme交叉、超曲面上の構造の周囲への延長。

外部原典PDFやその全文textは再配布していません。
一次資料のURL、使用範囲、原典から独立に証明した箇所は本文とproofsに明記しています。

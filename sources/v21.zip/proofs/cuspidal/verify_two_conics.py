#!/usr/bin/env python3
"""Exact necessary conormal nilpotency calculations for both CI(2,2) two-conic models.
No Poisson-Jacobi component decomposition is asserted.
"""
import json
import sympy as s
x=s.symbols('x0:4');a=s.symbols('a0:4');b=s.symbols('b0:4');checks={};data={}
Q=x[0]*x[1]
def rankquad(q,vars): return s.hessian(q,vars).rank()
def same_constant_span(es,fs,params):
 pp=[s.Poly(e,*params,domain=s.QQ) for e in es+fs];mm=sorted({m for p in pp for m,c in p.terms()});mat=s.Matrix([[p.coeff_monomial(m) for m in mm] for p in pp]);re=mat[:len(es),:].rank();rf=mat[len(es):,:].rank();return re==rf==mat.rank()
for tag,R in [('secant',x[0]**2+x[1]**2+x[2]*x[3]),('tangent',x[2]**2+(x[0]+x[1])*x[3])]:
 A=s.Matrix(a);B=s.Matrix(b);q=[Q,R];Mg=s.Matrix([[sum(s.diff(qi,xx)*vv for xx,vv in zip(x,W)) for W in [A,B]] for qi in q]);lc=s.Poly(s.trace(Mg),*x).coeffs();LM,Lr=s.linear_eq_to_matrix(lc,a+b)
 sol=({a[0]:-2*b[1],a[1]:-2*b[0],b[2]:0,b[3]:0} if tag=='secant' else {a[0]:-b[3],a[1]:-b[3],b[0]:-b[1],b[2]:0});Ar=A.subs(sol);Br=B.subs(sol);M=Mg.subs(sol);free=([a[2],a[3],b[0],b[1]] if tag=='secant' else [a[2],a[3],b[1],b[3]])
 checks[tag+'_trace_rank4']=LM.rank()==4;checks[tag+'_trace_solution']=s.expand(s.trace(M))==0
 G=s.groebner(q,*x,domain=s.QQ.frac_field(*free),order='grevlex');quo,rem=G.reduce(s.expand(M.det()));checks[tag+'_division_identity']=s.expand(M.det()-rem-sum(u*p.as_expr() for u,p in zip(quo,G.polys)))==0
 es=s.Poly(s.expand(rem),*x).coeffs();fs=([a[2]*b[0],a[3]*b[0],a[2]*b[1],a[3]*b[1],b[0]**2-b[1]**2] if tag=='secant' else [a[2]*b[1],a[3]*b[1],b[1]*b[3],b[3]**2]);checks[tag+'_coefficient_ideal_exact_constant_span']=same_constant_span(es,fs,free)
 V=Ar*Q+Br*R
 cases=([('rank2',{b[0]:0,b[1]:0},Q,s.Matrix([0,0,a[2],a[3]])),('rank3minus',{a[2]:0,a[3]:0,b[1]:b[0]},R-2*Q,s.Matrix([b[0],b[0],0,0])),('rank3plus',{a[2]:0,a[3]:0,b[1]:-b[0]},R+2*Q,s.Matrix([b[0],-b[0],0,0]))] if tag=='secant' else [('rank2',{b[1]:0,b[3]:0},Q,s.Matrix([0,0,a[2],a[3]])),('rank3',{a[2]:0,a[3]:0,b[3]:0},R,s.Matrix([-b[1],b[1],0,0]))])
 for name,sub,S,v in cases:
  checks[tag+'_'+name+'_V_factor']=all(s.expand(w)==0 for w in V.subs(sub)-S*v)
  checks[tag+'_'+name+'_vertex']=s.expand(sum(s.diff(S,xx)*vv for xx,vv in zip(x,v)))==0
  checks[tag+'_'+name+'_rank']=rankquad(S,x)==(2 if name=='rank2' else 3)
  checks[tag+'_'+name+'_constraints']=all(s.expand(e.subs(sub))==0 for e in fs)
 checks[tag+'_conic_x0_smooth']=rankquad(R.subs(x[0],0),x[1:])==3
 checks[tag+'_conic_x1_smooth']=rankquad(R.subs(x[1],0),(x[0],x[2],x[3]))==3
 data[tag]={'quadrics':[str(Q),str(R)],'trace_substitution':{str(k):str(v) for k,v in sol.items()},'matrix':str(M),'determinant_remainder':str(rem),'necessary_ideal_generators':[str(e) for e in fs],'note':'Closed-point branch exhaustiveness follows directly from listed products and squares; no radical equality claimed.'}
result={'all_passed':all(checks.values()),'checks':checks,'models':data,'scope':'Two conics spanning P3 with intersection length2 only; not the intersection-length1 or P4-spanning branches.'}
print(json.dumps(result,indent=2));assert result['all_passed']

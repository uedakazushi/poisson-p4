#!/usr/bin/env python3
"""Independent exact check of the concurrent-star Pfaffian integrability argument.
The proof needs actual gradient Pfaffians (Jacobi plus the canonical lift).
It does not assert that an arbitrary quintic satisfies the hypotheses.
"""
import sympy as s,json
x0=s.symbols('x0');y=s.symbols('y1:4');c=s.symbols('c');t=s.symbols('t');checks={}
# All coefficients of the x0^2 and x0*y part, before scalar restriction.
avec=s.symbols('A0:3');lv=s.symbols('L0:9');L=s.Matrix(3,3,lv);av=s.Matrix(avec)
rays=[s.Matrix([1,0,0]),s.Matrix([0,1,0]),s.Matrix([0,0,1]),s.Matrix([1,1,1])]
e=[]
for v in rays:
 e.extend(av.cross(v));e.extend((L*v).cross(v))
LM,_=s.linear_eq_to_matrix(e,avec+lv);checks['tangency_linear_rank_11']=LM.rank()==11
N=LM.nullspace();scalar=s.Matrix([0,0,0,1,0,0,0,1,0,0,0,1]);checks['tangency_only_scalar_direction']=len(N)==1 and s.Matrix.hstack(N[0],scalar).rank()==1
# Arbitrary homogeneous quadratic coefficients, with no hidden curve conditions.
mon=[y[i]*y[j] for i in range(3) for j in range(i,3)]
k=s.symbols('k0:60');quad=[sum(k[6*i+j]*m for j,m in enumerate(mon)) for i in range(10)]
P=s.zeros(5);P[0,1]=c*x0*y[0]+quad[0];P[0,2]=c*x0*y[1]+quad[1];P[0,3]=c*x0*y[2]+quad[2]
P[0,4]=quad[3];P[1,2]=quad[4];P[1,3]=quad[5];P[2,3]=quad[6];P[1,4]=quad[7];P[2,4]=quad[8];P[3,4]=quad[9]
for i in range(5):
 for j in range(i):P[i,j]=-P[j,i]
def pf4(ix):
 a,b,d,e=ix;return s.expand(P[a,b]*P[d,e]-P[a,d]*P[b,e]+P[a,e]*P[b,d])
bpf=[(-1)**i*pf4([j for j in range(5) if j!=i]) for i in range(5)];U=s.Matrix([P[1,4],P[2,4],P[3,4]]);cross=s.Matrix(y).cross(U)
checks['b0_independent_x0']=s.diff(bpf[0],x0)==0
for i in range(3):checks[f'pfaffian_derivative_{i+1}']=s.expand(s.diff(bpf[i+1],x0)+c*cross[i])==0
checks['orthogonal_cross_identity']=s.expand(s.Matrix(y).dot(cross))==0
integrability_sum=sum(y[i]*(s.diff(bpf[0],y[i])-s.diff(bpf[i+1],x0)) for i in range(3));checks['exact_Euler_integrability_identity']=s.expand(integrability_sum-4*bpf[0])==0
checks['identity_includes_c_zero']=s.expand((integrability_sum-4*bpf[0]).subs(c,0))==0
# Check three nilpotency branches against their binary invariants.
q1=y[0]*(y[1]-y[2]);q2=y[1]*(y[0]-y[2]);branches=[('a3',q1,s.Matrix([0,1,1]),y[0],y[1]-y[2]),('b2',q2-q1,s.Matrix([1,1,0]),y[2],y[0]-y[1]),('b3',q2,s.Matrix([1,0,1]),y[1],y[0]-y[2])]
for name,Q,d,u,v in branches:
 checks[name+'_Q_is_product']=s.expand(Q-u*v)==0
 checks[name+'_binary_invariants']=sum(s.diff(u,z)*w for z,w in zip(y,d))==0 and sum(s.diff(v,z)*w for z,w in zip(y,d))==0
 values=[(u.subs(dict(zip(y,r))),v.subs(dict(zip(y,r)))) for r in rays]
 checks[name+'_both_binary_axes']=any(uu!=0 and vv==0 for uu,vv in values) and any(uu==0 and vv!=0 for uu,vv in values)
 checks[name+'_all_rays_on_Q']=all(s.expand(Q.subs(dict(zip(y,r))))==0 for r in rays)
# Binary quintic with zero gradient at both axes => u^2v^2 divides it.
u,v=s.symbols('u v');fc=s.symbols('f0:6');f=sum(fc[i]*u**(5-i)*v**i for i in range(6));conditions=[s.diff(f,z).subs({u:1,v:0}) for z in (u,v)]+[s.diff(f,z).subs({u:0,v:1}) for z in (u,v)];BM,_=s.linear_eq_to_matrix(conditions,fc);checks['binary_gradient_conditions_rank4']=BM.rank()==4
for i,sol in enumerate(BM.nullspace()):
 form=s.expand(sum(sol[j]*u**(5-j)*v**j for j in range(6)));checks[f'binary_solution_{i}_divisible_Q_squared']=s.div(form,u**2*v**2,u,v)[1]==0
# Trace/determinant nilpotency calculation for all constant A,B independently.
x=(x0,)+y;a=s.symbols('a0:4');bb=s.symbols('b0:4');Aa=s.Matrix(a);Bb=s.Matrix(bb);Mq=s.Matrix([[sum(s.diff(q,z)*w for z,w in zip(x,W)) for W in [Aa,Bb]] for q in [q1,q2]])
sub={a[1]:-bb[2],a[2]:a[3]-bb[2],bb[1]:bb[2]+bb[3]};Mr=Mq.subs(sub);checks['star_trace_formula']=s.expand(s.trace(Mr))==0
TR,_=s.linear_eq_to_matrix(s.Poly(s.trace(Mq),*y).coeffs(),a+bb);checks['star_trace_rank3']=TR.rank()==3
params=[a[3],bb[2],bb[3]];G=s.groebner([q1,q2],*y,domain=s.QQ.frac_field(*params),order='grevlex');quo,rem=G.reduce(s.expand(Mr.det()));checks['star_determinant_division_identity']=s.expand(Mr.det()-rem-sum(q*p.as_expr() for q,p in zip(quo,G.polys)))==0
es=s.Poly(rem,*y).coeffs();fs=[a[3]*bb[2],a[3]*bb[3],bb[2]*bb[3]];pp=[s.Poly(e,*params,domain=s.QQ) for e in es+fs];mm=sorted({m for p in pp for m,_ in p.terms()});Cmat=s.Matrix([[p.coeff_monomial(m) for m in mm] for p in pp]);checks['star_nilpotency_ideal_exact_constant_span']=Cmat[:len(es),:].rank()==Cmat[len(es):,:].rank()==Cmat.rank()==3
result={'all_passed':all(checks.values()),'checks':checks,'pfaffian_identity':'4*b0|H = sum_{a=1}^3 y_a*(d_a b0 - d_0 b_a)|H','nilpotency_ideal':['a3*b2','a3*b3','b2*b3'],'scope':'Independent polynomial identities supporting the normal-actual-D E8 concurrent-star exclusion; no full Jacobi scheme decomposition.'}
print(json.dumps(result,indent=2));assert result['all_passed']

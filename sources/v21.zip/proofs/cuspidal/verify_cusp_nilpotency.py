#!/usr/bin/env python3
"""Exact cusp conormal nilpotency calculation, independent of Jacobi elimination.
This certifies only the displayed polynomial identities and two closed-point
branches. Geometric use of the generic E8 conormal algebra is proved separately.
"""
import json
from pathlib import Path
import sympy as s
x=s.symbols('x0:5');t=s.symbols('t');A,B,C,D=s.symbols('A B C D');z=s.symbols('z0:48')
q1=x[0]*x[3]-x[1]**2;q2=x[1]*x[3]-x[2]**2
VA=s.Matrix([A,-D/2,-C,0]);VB=s.Matrix([-B,-A,0,-D]);V=VA*q1+VB*q2
M=s.Matrix([[sum(s.diff(q,xx)*v for xx,v in zip(x[:4],W)) for W in [VA,VB]] for q in [q1,q2]])
determinant=s.expand(M.det().subs(dict(zip(x[:4],[1,t**2,t**3,t**4]))))
expected=(-A**2-B*D/2)*t**8+2*B*C*t**7-A*D*t**6-4*A*C*t**5-s.Rational(3,2)*D**2*t**4+2*C*D*t**3
a=s.symbols('a0:4');b=s.symbols('b0:4')
Mg=s.Matrix([[sum(s.diff(q,xx)*v for xx,v in zip(x[:4],W)) for W in [a,b]] for q in [q1,q2]])
trace_formula=(a[0]+b[1])*x[3]+(b[3]-2*a[1])*x[1]+a[3]*x[0]-2*b[2]*x[2]
checks={'general_trace_formula':s.expand(s.trace(Mg)-trace_formula)==0,'trace_reduction_to_M':all(s.expand(v)==0 for v in Mg.subs(dict(zip(a,[A,-D/2,-C,0]))|dict(zip(b,[-B,-A,0,-D])))-M),'trace_identically_zero':s.expand(s.trace(M))==0,'determinant_identity':s.expand(determinant-expected)==0,'D_square_coefficient':s.Poly(determinant,t).coeff_monomial(t**4)==-s.Rational(3,2)*D**2,'A_square_after_D_zero':s.Poly(determinant.subs(D,0),t).coeff_monomial(t**8)==-A**2,'BC_after_A_D_zero':s.expand(determinant.subs({D:0,A:0})-2*B*C*t**7)==0}
checks['B_branch_vector']=V.subs({A:0,C:0,D:0})==s.Matrix([-B*q2,0,0,0])
checks['C_branch_vector']=V.subs({A:0,B:0,D:0})==s.Matrix([0,0,-C*q1,0])
checks['q2_vertex_e0']=s.diff(q2,x[0])==0
checks['q1_vertex_e2']=s.diff(q1,x[2])==0
checks['q1_rank3']=s.hessian(q1,x[:4]).rank()==3
checks['q2_rank3']=s.hessian(q2,x[:4]).rank()==3
model_path=Path(__file__).resolve().parents[1]/'p4_poisson_completeness_v20/data/quartic_models/cuspidal_model.json'
if not model_path.exists():
 import argparse
 parser=argparse.ArgumentParser();parser.add_argument('--model',type=Path,required=True);model_path=parser.parse_args().model
model=json.loads(model_path.read_text());loc={str(v):v for v in x+z}
model_V=s.Matrix([s.sympify(model['matrix_upper'][f'{i},4'],locals=loc).subs(x[4],0) for i in range(4)])
checks['matches_archived_full_model']=all(s.expand(v)==0 for v in model_V-V.subs({A:z[27],B:z[12],C:z[37],D:z[42]}))
result={'all_passed':all(checks.values()),'checks':checks,'matrix':str(M),'determinant_restriction':str(determinant),'closed_point_conclusion':'A=D=0 and B*C=0 over C; no equality of nonreduced schemes claimed','scope':'Identities plus elementary closed-point nilpotency branches; not a Jacobi ideal decomposition.'}
print(json.dumps(result,indent=2));assert result['all_passed']

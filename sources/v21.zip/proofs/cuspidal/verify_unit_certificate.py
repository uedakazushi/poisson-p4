#!/usr/bin/env python3
"""Read-only verifier for a finite rational unit-ideal certificate.
Use --model to point at the v20 cuspidal model JSON when this is moved.
"""
import argparse,json
from pathlib import Path
import sympy as s
p=argparse.ArgumentParser();p.add_argument('--model',type=Path,default=Path(__file__).resolve().parents[1]/'p4_poisson_completeness_v20/data/quartic_models/cuspidal_model.json');p.add_argument('--certificate',type=Path,default=Path(__file__).with_name('unit_certificate_11.json'));args=p.parse_args()
m=json.loads(args.model.read_text());cert=json.loads(args.certificate.read_text());z=s.symbols('z0:48');loc={str(v):v for v in z};E=[s.sympify(e,locals=loc) for e in m['jacobi_equations']];sub={z[46]:s.S.One,z[47]:s.S.One};active=list(z[:46]);checks={}
for k,stage in enumerate(cert['stages']):
 recorded={loc[q]:s.sympify(v,locals=loc) for q,v in stage['substitution'].items()};checks[f'stage_{k}_substitution_derived']=recorded==sub
 es=[s.expand(e.xreplace(sub)) for e in E];linear=[]
 for j,c in enumerate(stage['consequences']):
  eq=s.sympify(c['equation'],locals=loc);expr=sum(s.Rational(v)*es[int(i)] for i,v in c['combination'].items());checks[f'stage_{k}_consequence_{j}']=s.expand(expr-eq)==0;linear.append(eq)
 if stage.get('contradiction'):
  checks['exact_unit_witness']=s.S.One in linear;checks['contradiction_final']=k==len(cert['stages'])-1;break
 M,rhs=s.linear_eq_to_matrix(linear,active);rr,piv=M.row_join(rhs).rref();assert len(active) not in piv
 new={active[j]:s.expand(rr[i,-1]-sum(rr[i,c]*active[c] for c in range(len(active)) if c!=j)) for i,j in enumerate(piv)};sub={q:s.expand(v.xreplace(new)) for q,v in sub.items()}|new;active=[q for q in active if q not in new]
result={'all_passed':all(checks.values()),'checks':checks,'stages':len(cert['stages']),'conclusion':'The full Jacobi slice a=b=1 is empty over C; certificate uses only rational linear combinations and substitutions forced by previous linear equations.'}
print(json.dumps(result,indent=2));assert result['all_passed']

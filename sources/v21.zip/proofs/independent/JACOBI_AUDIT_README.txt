INDEPENDENT FULL TREE JACOBI AUDIT

Run with Python 3 only (standard library; no extra packages):
python3 audit_tree_jacobi_sparse.py PATH_TO_TREE_JACOBI_MODEL_DIRECTORY --output-directory RESULTS_DIRECTORY

All eight expected models must be present. The script reads JSON as data,
parses polynomial expressions with ast (never eval), represents coefficients
as fractions.Fraction, and independently performs sparse polynomial convolution
and differentiation. It does not import SymPy or the root model generator.

The current execution passed249 checks across8 models:
- ten full uppermatrixentries, homogeneousbidegree(2in x,1in z);
- allfivecanonicaldivergenceidentities;
- exactresiduerestrictionforalltengeneratorentriesoneachcomponent;
- parameterizationinjectivitybyrationalGaussianelimination;
- all350Jacobi cubicslots (includingidenticallyzeroslots);
- exactequalityofuniqueJacobi coefficientsetsafterdividingeachbyits
  nonzeroRATIONALleadingcoefficientinorderedparametersz0,z1,...;
- storedmonicQQquadratics, noduplicates, countmetadata;
- fivePfaffians permodel;
- tenuniversaldb-J identitiespermodel BEFOREimposingJacobi;
- EulerprimitiveF andfiveuniversalP*b=0 identitiespermodel.

EachmodelresultincludesinputSHA256 andonecertificateforeachnonzeroJacobi
coefficient: triple, x-monomial, nonzerorationalleadingcoefficient, andzero-based
indexofthestoredmonicequation. Thus the relation
raw_coefficient = rational_leading_coefficient * stored_equation[index]
is fully reproducible. No parameterdivision/localization/radical/saturation
orprimarydecompositionoccurs.

The checks do not imply that these necessary models contain normal actual
Poissonquintics, and the equationcounts are not dimensions, ranks, orminimal
generatorcounts. Completeness of the geometric supports and theoriginal
linearconstraintkernel is verifiedelsewhere; thisauditindependentlychecks
that the recordedparameterizationis injectiveandsatisfiesalllistedlinear
constraints, andthat thefullJacobiidealbuiltfromitispreservedexactly.

#!/usr/bin/env python3
"""Check the eight reducible CI representatives and cone-net identity exactly."""
import json
from pathlib import Path
import sympy as s
x=s.symbols('x0:4'); t=s.Symbol('t'); a,b,c=s.symbols('a b c')
def line(u,v): return [u[i]+t*v[i] for i in range(4)]
e=[list(s.eye(4)[:,i]) for i in range(4)]
tc=[1,t,t*t,t**3];con=[1,t,t*t,0]
models={
 '31_secant':([x[0]*x[2]-x[1]**2,x[1]*x[3]-x[2]**2],[tc,line(e[0],e[3])]),
 '31_tangent':([x[0]*x[3]-x[1]*x[2],x[1]*x[3]-x[2]**2],[tc,line(e[0],e[1])]),
 '22_secant':([x[2]*x[3],x[0]*x[1]-x[2]**2-x[3]**2],[[1,t*t,t,0],[1,t*t,0,t]]),
 '22_tangent':([x[2]*x[3],x[0]*(x[2]+x[3])-x[1]**2],[[1,t,t*t,0],[1,t,0,t*t]]),
 '211_cycle':([x[1]*x[3],x[0]*x[2]-x[1]**2],[con,line(e[0],e[3]),line(e[2],e[3])]),
 '211_triple':([x[2]*x[3],x[0]*x[2]-x[1]**2+x[1]*x[3]],[con,line(e[0],e[3]),line(e[0],[0,1,0,1])]),
 '1111_cycle':([x[0]*x[2],x[1]*x[3]],[line(e[0],e[1]),line(e[1],e[2]),line(e[2],e[3]),line(e[3],e[0])]),
 '1111_concurrent':([x[1]*(x[2]-x[3]),x[2]*(x[1]-x[3])],[line(e[0],e[1]),line(e[0],e[2]),line(e[0],e[3]),line(e[0],[0,1,1,1])]),
}
reports=[]
for name,(qs,rs) in models.items():
    vanish=all(s.expand(q.subs(dict(zip(x,r)),simultaneous=True))==0 for q in qs for r in rs)
    coprime=s.gcd(*qs)==1
    reports.append({'name':name,'all_components_vanish':vanish,'regular_sequence':coprime,'all_passed':vanish and coprime})
q1=x[0]*x[2]-x[1]**2;q2=x[0]*x[3]-x[1]*x[2];q3=x[1]*x[3]-x[2]**2
det=s.factor((s.hessian(a*q1+b*q2+c*q3,x)/2).det())
report={'representatives':reports,'cone_net_determinant':str(det),'cone_net_identity':s.expand(det-(a*c-b*b)**2/16)==0,'all_passed':all(q['all_passed'] for q in reports) and s.expand(det-(a*c-b*b)**2/16)==0}
(Path(__file__).resolve().parent/'ci_representatives_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

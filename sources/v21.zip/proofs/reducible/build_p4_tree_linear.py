#!/usr/bin/env python3
"""Exact canonical-lift linear models for the eight P4-spanning support trees.

These are linear spaces BEFORE Jacobi.  Dimensions are not Poisson-family or
moduli dimensions.  Residue coefficients are intrinsic vector-field parameters.
"""
import json
from pathlib import Path
import sympy as sp

OUT = Path(__file__).resolve().parent / 'tree_linear_models'
OUT.mkdir(exist_ok=True)
t = sp.Symbol('t')
x = sp.symbols('x0:5')
pairs = [(i,j) for i in range(5) for j in range(i+1,5)]
mons = [(i,j) for i in range(5) for j in range(i,5)]

def line(i,j, marks):
    r = [sp.Integer(0)]*5
    r[i],r[j] = sp.Integer(1),t
    return dict(r=r, marks=marks)

def conic(i,j,k, marks):
    r = [sp.Integer(0)]*5
    r[i],r[j],r[k] = sp.Integer(1),t,t*t
    return dict(r=r, marks=marks)

configs = {
    '31_external': [dict(r=[1,t,t*t,t**3,0],marks=['0']),line(0,4,['0'])],
    '22_node': [conic(0,1,2,['0']),conic(0,3,4,['0'])],
    '211_conic_center': [conic(0,1,2,['0','inf']),line(0,3,['0']),line(2,4,['0'])],
    '211_line_center': [conic(0,1,2,['0']),line(0,3,['0','inf']),line(3,4,['0'])],
    '211_triple': [conic(0,1,2,['0']),line(0,3,['0']),line(0,4,['0'])],
    '1111_chain': [line(0,1,['inf']),line(1,2,['0','inf']),line(2,3,['0','inf']),line(3,4,['0'])],
    '1111_triple_tail': [line(0,1,['0','inf']),line(0,2,['0']),line(0,3,['0']),line(1,4,['0'])],
    '1111_concurrent': [line(0,i,['0']) for i in range(1,5)],
}

def coefficient_rows(polynomials, width):
    coeffs = {}
    for j,p in polynomials.items():
        for (degree,), value in sp.Poly(p,t).terms():
            if value:
                coeffs.setdefault(degree, [sp.Integer(0)]*width)[j] += value
    return [coeffs[k] for k in sorted(coeffs) if any(coeffs[k])]

def run(name,components):
    residue_count = 0
    for comp in components:
        comp['r'] = list(map(sp.sympify,comp['r']))
        comp['residue_basis'] = [t**i for i in range(3)
           if not (i==0 and '0' in comp['marks'])
           and not (i==2 and 'inf' in comp['marks'])]
        comp['residue_indices'] = list(range(residue_count,residue_count+len(comp['residue_basis'])))
        residue_count += len(comp['residue_basis'])
    width = 150+residue_count
    rows=[]
    scalar=[]
    for comp in components:
        r = comp['r']
        restricted = [sp.expand(r[k]*r[l]) for k,l in mons]
        scalar += coefficient_rows(dict(enumerate(restricted)),15)
        for k,(i,j) in enumerate(pairs):
            wedge=sp.expand(r[i]*sp.diff(r[j],t)-r[j]*sp.diff(r[i],t))
            polys={15*k+m:5*p for m,p in enumerate(restricted) if p}
            for idx,basis in zip(comp['residue_indices'],comp['residue_basis']):
                polys[150+idx]=sp.expand(basis*wedge)
            rows += coefficient_rows(polys,width)
    restriction_rows=len(rows)
    for out_i in range(5):
        for coord in range(5):
            row=[sp.Integer(0)]*width
            for k,(i,j) in enumerate(pairs):
                if out_i==j:
                    derivative, sign=i,1
                elif out_i==i:
                    derivative, sign=j,-1
                else:
                    continue
                for m,(a,b) in enumerate(mons):
                    if a==derivative and b==coord: row[15*k+m]+=sign
                    if b==derivative and a==coord: row[15*k+m]+=sign
            if any(row): rows.append(row)
    M=sp.Matrix(rows)
    red,pivots=M.rref()
    free=[j for j in range(width) if j not in pivots]
    z=sp.symbols('z0:'+str(len(free)))
    expr={col:par for col,par in zip(free,z)}
    for row,col in enumerate(pivots):
        expr[col]=sp.expand(-sum(red[row,j]*expr[j] for j in free))
    coeffvec=sp.Matrix([expr[i] for i in range(width)])
    assert M*coeffvec==sp.zeros(len(rows),1)
    entries={f'{i}{j}':str(sp.expand(sum(expr[15*k+m]*x[a]*x[b]
                           for m,(a,b) in enumerate(mons))))
             for k,(i,j) in enumerate(pairs)}
    scalar_matrix=sp.Matrix(scalar)
    ideal_basis=scalar_matrix.nullspace()
    residue_matrix=sp.Matrix([[sp.diff(expr[150+i],par) for par in z]
                              for i in range(residue_count)])
    residue_image_rank=residue_matrix.rank()
    residue_relations=residue_matrix.T.nullspace()
    rho=sp.symbols('rho0:'+str(residue_count))
    output={
      'scope':'Linear canonical-lift constraints only; Jacobi not imposed',
      'name':name,'unknowns':width,'coefficient_unknowns':150,
      'residue_unknowns':residue_count,'linear_rank':len(pivots),
      'linear_dimension':len(free),'residue_image_rank':residue_image_rank,
      'residue_relations':[str(sp.expand(sum(v[i]*rho[i] for i in range(residue_count)))) for v in residue_relations],
      'restriction_equation_rows':restriction_rows,'total_equation_rows':len(rows),
      'parameter_order':[str(q) for q in z],
      'free_column_order':free,
      'quadratic_ideal_dimension':len(ideal_basis),
      'quadratic_ideal_basis':[str(sp.expand(sum(vec[k]*x[a]*x[b] for k,(a,b) in enumerate(mons)))) for vec in ideal_basis],
      'components':[dict(parametrization=[str(q) for q in comp['r']],
                         marked_points=comp['marks'],
                         residue_basis=[str(q) for q in comp['residue_basis']],
                         residue_indices=comp['residue_indices']) for comp in components],
      'P_entries':entries,
      'residue_expressions':[str(expr[150+i]) for i in range(residue_count)],
      'checks':{'linear_kernel':True,'quadratic_ideal_dimension_six':len(ideal_basis)==6},
    }
    (OUT/(name+'.json')).write_text(json.dumps(output,indent=2)+'\n')
    return {k:output[k] for k in ('name','unknowns','linear_rank','linear_dimension','residue_unknowns','residue_image_rank','residue_relations','quadratic_ideal_dimension','checks')}

if __name__=='__main__':
    reports=[]
    for name,components in configs.items():
        result=run(name,components)
        reports.append(result)
        print(json.dumps(result),flush=True)
    (OUT/'summary.json').write_text(json.dumps(reports,indent=2)+'\n')

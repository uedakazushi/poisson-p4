#!/usr/bin/env python3
"""Direct polynomial audit of serialized P4 tree models, independent of RREF."""
import json
from pathlib import Path
import sympy as s

ROOT=Path(__file__).resolve().parent
x=s.symbols('x0:5'); t=s.Symbol('t')
reports=[]
for path in sorted((ROOT/'tree_linear_models').glob('*.json')):
    if path.name in ('summary.json','direct_audit.json'): continue
    d=json.loads(path.read_text())
    pars=s.symbols('z0:'+str(d['linear_dimension']))
    env={str(z):z for z in (*x,t,*pars)}
    P=s.zeros(5)
    for key,val in d['P_entries'].items():
        i,j=map(int,key)
        P[i,j]=s.sympify(val,locals=env);P[j,i]=-P[i,j]
    residue=[s.sympify(a,locals=env) for a in d['residue_expressions']]
    div=[s.expand(sum(s.diff(P[j,i],x[j]) for j in range(5))) for i in range(5)]
    checks={'divergence_zero':all(v==0 for v in div)}
    identities=0
    for component in d['components']:
        r=[s.sympify(a,locals=env) for a in component['parametrization']]
        R=sum(residue[k]*s.sympify(a,locals=env)
              for k,a in zip(component['residue_indices'],component['residue_basis']))
        sub=dict(zip(x,r))
        for i in range(5):
            for j in range(i+1,5):
                identity=s.expand(5*P[i,j].subs(sub,simultaneous=True)+R*(r[i]*s.diff(r[j],t)-r[j]*s.diff(r[i],t)))
                assert identity==0,(d['name'],i,j,identity)
                identities+=1
        for g in d['quadratic_ideal_basis']:
            assert s.expand(s.sympify(g,locals=env).subs(sub,simultaneous=True))==0
    checks['all_component_restrictions']=True
    checks['quadratic_ideal_basis_vanishes']=True
    # Linear independence of the full coefficients and residue map.
    expressions=[]
    for i in range(5):
        for j in range(i+1,5):
            expressions+=s.Poly(P[i,j],*x).coeffs()
    expressions+=residue
    A=s.Matrix([[s.diff(a,z) for z in pars] for a in expressions])
    checks['parameter_map_injective']=A.rank()==len(pars)
    reports.append({'name':d['name'],'restriction_identities':identities,'checks':checks,'all_passed':all(checks.values())})
    print(json.dumps(reports[-1]),flush=True)
report={'models':reports,'all_passed':all(a['all_passed'] for a in reports)}
(ROOT/'tree_linear_models'/'direct_audit.json').write_text(json.dumps(report,indent=2)+'\n')


"""Exact E8 conormal nilpotency checks for twisted-cubic plus secant/tangent.
The symbolic ideals are kept exact. Only the later geometric case analysis uses
closed points over C. No Jacobi solution components are counted.
"""
import sympy as s,json
from pathlib import Path
x=s.symbols('x0:4');a=s.symbols('a0:4');b=s.symbols('b0:4');unknowns=a+b;out={};checks={}
param=s.symbols('t');r=s.Matrix([1,param,param**2,param**3])
for kind,q1,q2,linecoords in [('secant',x[0]*x[2]-x[1]**2,x[1]*x[3]-x[2]**2,[0,3]),('tangent',x[0]*x[3]-x[1]*x[2],x[1]*x[3]-x[2]**2,[0,1])]:
 tr=s.expand(sum(s.diff(q1,xx)*vv for xx,vv in zip(x,a))+sum(s.diff(q2,xx)*vv for xx,vv in zip(x,b)))
 linrows=s.Poly(tr,*x).coeffs();sol=list(s.linsolve(linrows,unknowns))[0];params=sorted(set().union(*(v.free_symbols for v in sol)),key=str);A=s.Matrix(sol[:4]);B=s.Matrix(sol[4:]);M=s.Matrix([[sum(s.diff(q,xx)*vv for xx,vv in zip(x,vec)) for vec in[A,B]] for q in[q1,q2]]);det=s.expand(M.det())
 Gq=s.groebner([q1,q2],*x,order='grevlex',domain=s.EX);rem=s.expand(Gq.reduce(det)[1]);ee=s.Poly(rem,*x).coeffs();G=s.groebner(ee,*params,domain=s.QQ)
 checks[f'{kind}_trace_rank_four']=s.linear_eq_to_matrix(linrows,unknowns)[0].rank()==4
 checks[f'{kind}_trace_zero']=s.expand(s.trace(M))==0
 checks[f'{kind}_twisted_cubic_contained']=all(s.expand(q.subs(dict(zip(x,r))))==0 for q in[q1,q2])
 checks[f'{kind}_line_contained']=all(s.expand(q.subs({x[i]:0 for i in range(4) if i not in linecoords}))==0 for q in[q1,q2])
 checks[f'{kind}_quadrics_coprime']=s.gcd(q1,q2)==1
 # Verify transverse independence at one point on each component; this supplies generic reducedness of the CI.
 genericTC={x[0]:1,x[1]:2,x[2]:4,x[3]:8}
 genericL={x[i]:(1 if i in linecoords else 0) for i in range(4)}
 J=s.Matrix([[s.diff(q,xx) for xx in x] for q in [q1,q2]])
 checks[f'{kind}_generically_reduced_on_twisted_cubic']=J.subs(genericTC).rank()==2
 checks[f'{kind}_generically_reduced_on_line']=J.subs(genericL).rank()==2
 if kind=='secant':
  a3,b0,b2,b3=params
  target=[a3*b0,a3*b2,b0*b3,b2*b2,b2*b3,b3*b3]
  gt=s.groebner(target,*params,domain=s.QQ)
  checks['secant_exact_ideal_equality']=all(gt.reduce(e)[1]==0 for e in ee) and all(G.reduce(e)[1]==0 for e in target)
  cases=[({b0:0,b2:0,b3:0},q1,s.Matrix([0,0,0,a3])),({a3:0,b2:0,b3:0},q2,s.Matrix([b0,0,0,0]))]
 else:
  b0,b1,b2,b3=params
  needed=[b3*b3,4*b1*b3+6*b2*b2,2*b0*b2-b1*b1]
  checks['tangent_closedpoint_forcing_polynomials_in_ideal']=all(G.reduce(e)[1]==0 for e in needed)
  cases=[({b1:0,b2:0,b3:0},q2,s.Matrix([b0,0,0,0]))]
 V=q1*A+q2*B
 for j,(sub,Q,d) in enumerate(cases):
  checks[f'{kind}_case_{j}_factorization']=all(s.expand(vv-ww)==0 for vv,ww in zip(V.subs(sub),Q*d))
  checks[f'{kind}_case_{j}_vertex_direction']=s.expand(sum(s.diff(Q,xx)*vv for xx,vv in zip(x,d)))==0
  checks[f'{kind}_case_{j}_quadric_rank_three']=s.hessian(Q,x).rank()==3
 out[kind]={'q1':str(q1),'q2':str(q2),'parameters':list(map(str,params)),'A':list(map(str,A)),'B':list(map(str,B)),'M':[[str(M[i,j]) for j in range(2)]for i in range(2)],'det':str(det),'nilpotent_equations':list(map(str,ee)),'grobner':[str(p.as_expr()) for p in G.polys]}
out['checks']=checks;out['all_passed']=all(checks.values());out['scope']='Necessary conormal conditions; geometric closedpoint exclusions with normal actual D. No scheme decomposition.'
Path(__file__).with_name('ci_31_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));assert out['all_passed']

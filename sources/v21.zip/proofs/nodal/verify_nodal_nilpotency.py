"""Exact symbolic certificate for the nodal E8 normal-to-hyperplane reduction.
Requires SymPy. Does not solve the full Jacobi scheme or use numerical samples.
"""
import sympy as s,json,argparse
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('--model',type=Path,default=Path('p4_poisson_completeness_v20/data/quartic_models/nodal_model.json'));parser.add_argument('--output',type=Path,default=None);args=parser.parse_args()
x=s.symbols('x0:4');u,v,w,k=s.symbols('u v w k')
q1=x[1]*x[3]-x[2]**2;q2=x[0]*x[2]-x[1]**2-x[3]**2
A=s.Matrix([u,2*k,v,w]);B=s.Matrix([2*v,w/s.Integer(2),0,k]);V=q1*A+q2*B
M=s.Matrix([[sum(s.diff(q,xx)*vv for xx,vv in zip(x,D)) for D in [A,B]] for q in[q1,q2]])
tr=s.expand(s.trace(M));det=s.expand(M.det())
# Extract the unique possible pencil coefficients using pivot monomials x1*x3 andx0*x2.
pol=s.Poly(det,*x);alpha=pol.coeff_monomial(x[1]*x[3]);beta=pol.coeff_monomial(x[0]*x[2]);res=s.Poly(s.expand(det-alpha*q1-beta*q2),*x)
equations=[c for m,c in res.terms() if c]
target=[v*v,u*w,v*w,w*w-4*k*k,k*u,k*v]
g=s.groebner(equations,u,v,w,k,domain=s.QQ);gt=s.groebner(target,u,v,w,k,domain=s.QQ)
aa=s.symbols('A0:4');bb=s.symbols('B0:4')
generic_trace=s.expand(sum(s.diff(q1,xx)*vv for xx,vv in zip(x,aa))+sum(s.diff(q2,xx)*vv for xx,vv in zip(x,bb)))
expected_trace=bb[2]*x[0]+(aa[3]-2*bb[1])*x[1]+(bb[0]-2*aa[2])*x[2]+(aa[1]-2*bb[3])*x[3]
checks={
 'generic_trace_formula':s.expand(generic_trace-expected_trace)==0,
 'trace_identically_zero':tr==0,
 'det_pencil_remainder_exact':s.expand(det-alpha*q1-beta*q2-res.as_expr())==0,
 'nilpotency_coeffs_in_target_ideal':all(gt.reduce(e)[1]==0 for e in equations),
 'target_generators_in_nilpotency_ideal':all(g.reduce(e)[1]==0 for e in target),
}
# Closedpoint cases: v=0,uw=uk=0,w²=4k². Ifk=0=>w=0, elseu=0andw=±2k.
closed_cases=[({v:0,w:0,k:0},q1,s.Matrix([u,0,0,0])),({u:0,v:0,w:2*k},q2+2*q1,s.Matrix([0,k,0,k])),({u:0,v:0,w:-2*k},q2-2*q1,s.Matrix([0,-k,0,k]))]
case_data=[]
for i,(sub,Q,dd) in enumerate(closed_cases):
 vsub=V.subs(sub)
 checks[f'case_{i}_vector_factorization']=all(s.expand(aa-bb)==0 for aa,bb in zip(vsub,Q*dd))
 checks[f'case_{i}_direction_is_vertex']=s.expand(sum(s.diff(Q,xx)*vv for xx,vv in zip(x,dd)))==0
 checks[f'case_{i}_quadric_rank_three']=s.hessian(Q,x).rank()==3
 case_data.append({'substitutions':{str(a):str(b) for a,b in sub.items()},'quadric':str(Q),'direction':[str(t) for t in dd]})
# Check direct extraction from thefull v20model (sign V chosen forconvenience).
source=args.model
D=json.loads(source.read_text());z=s.symbols('z0:47');xx=s.symbols('x0:5');loc={str(a):a for a in z+xx};rename={z[12]:u,z[35]:v,z[41]:w,z[43]:k}
for i in range(4):
 expr=s.sympify(D['matrix_upper'][f'{i},4'],locals=loc).subs(xx[4],0).subs(rename)
 checks[f'model_transverse_entry_{i}']=s.expand(expr+V[i])==0
report={'coordinates':list(map(str,x)),'parameters':['u=z12','v=z35','w=z41','k=z43'],'q1':str(q1),'q2':str(q2),'M':[[str(M[i,j]) for j in range(2)]for i in range(2)],'determinant':str(det),'pencil_coefficients':[str(alpha),str(beta)],'remainder_coefficients':list(map(str,equations)),'grobner_basis':list(map(str,g.polys)),'equivalent_ideal_generators':list(map(str,target)),'closedpoint_cases':case_data,'checks':checks,'all_passed':all(checks.values()),'scope':'Necessary Heisenberg conormal condition at generic E8. Case splitting is for geometric closed points over characteristic zero, not scheme equality with reduced cases.'}
output=args.output or Path(__file__).with_name('nodal_nilpotency_results.json');output.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));assert report['all_passed']

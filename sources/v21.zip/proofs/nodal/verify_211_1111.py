"""Exact certificates for four reducible CI E8 exclusions.
Includes the concurrent-star Pfaffian integrability identity. No numerical
sampling is used for polynomial equalities or ideal membership. The only
sample points certify generic reducedness on explicitly parametrized components.
"""
import sympy as s,json
from pathlib import Path
x=s.symbols('x0:4');a=s.symbols('a0:4');b=s.symbols('b0:4');unknowns=a+b;out={};checks={}
t=s.symbols('t');baseconic=[1,t,t*t,0]
models=[
 ('211_cycle',x[0]*x[2]-x[1]**2,x[1]*x[3],[baseconic,[1,0,0,t],[0,0,1,t]]),
 ('211_triple',x[0]*x[2]-x[1]**2+x[1]*x[3],x[2]*x[3],[baseconic,[1,0,0,t],[1,t,0,t]]),
 ('1111_cycle',x[0]*x[2],x[1]*x[3],[[1,t,0,0],[0,1,t,0],[0,0,1,t],[1,0,0,t]]),
 ('1111_star',x[1]*(x[2]-x[3]),x[2]*(x[1]-x[3]),[[1,t,0,0],[1,0,t,0],[1,0,0,t],[1,t,t,t]])]
for kind,q1,q2,components in models:
 tr=s.expand(sum(s.diff(q1,xx)*vv for xx,vv in zip(x,a))+sum(s.diff(q2,xx)*vv for xx,vv in zip(x,b)))
 linrows=s.Poly(tr,*x).coeffs();sol=list(s.linsolve(linrows,unknowns))[0];params=sorted(set().union(*(v.free_symbols for v in sol)),key=str);A=s.Matrix(sol[:4]);B=s.Matrix(sol[4:]);M=s.Matrix([[sum(s.diff(q,xx)*vv for xx,vv in zip(x,vec)) for vec in[A,B]] for q in[q1,q2]]);det=s.expand(M.det())
 Gq=s.groebner([q1,q2],*x,order='grevlex',domain=s.EX);rem=s.expand(Gq.reduce(det)[1]);ee=s.Poly(rem,*x).coeffs();G=s.groebner(ee,*params,domain=s.QQ)
 checks[f'{kind}_trace_zero']=s.expand(s.trace(M))==0
 checks[f'{kind}_trace_rank']=s.linear_eq_to_matrix(linrows,unknowns)[0].rank()==(3 if kind=='1111_star' else 4)
 checks[f'{kind}_quadrics_coprime']=s.gcd(q1,q2)==1
 J=s.Matrix([[s.diff(q,xx) for xx in x] for q in [q1,q2]])
 for j,r in enumerate(components):
  checks[f'{kind}_component_{j}_contained']=all(s.expand(q.subs(dict(zip(x,r))))==0 for q in[q1,q2])
  sample={xx:s.sympify(vv).subs(t,2) for xx,vv in zip(x,r)}
  checks[f'{kind}_component_{j}_generically_reduced']=J.subs(sample).rank()==2
 if kind=='211_cycle':
  a3,b0,b2,b3=params;target=[a3*b0,a3*b2,b0*b3,b2*b3,b3*b3]
  cases=[({b0:0,b2:0,b3:0},q1,s.Matrix([0,0,0,a3])),({a3:0,b3:0},q2,s.Matrix([b0,0,b2,0]))]
 elif kind=='211_triple':
  b0,b1,b2,b3=params;target=[b2*b2,b2*(-2*b1+b3),2*b0*b2-b3*b3]
  cases=[({b2:0,b3:0},q2,s.Matrix([b0,b1,0,0]))]
 elif kind=='1111_cycle':
  a1,a3,b0,b2=params;target=[a1*b0,a1*b2,a3*b0,a3*b2]
  cases=[({a1:0,a3:0},q2,s.Matrix([b0,0,b2,0])),({b0:0,b2:0},q1,s.Matrix([0,a1,0,a3]))]
 else:
  a0,a3,b0,b2,b3=params;target=[a3*b2,a3*b3,b2*b3];cases=[]
  se=s.Matrix([1,0,0,0]);S=a0*q1+b0*q2;V=q1*A+q2*B
  casesstar=[({b2:0,b3:0},q1,a3,s.Matrix([0,0,1,1]),x[1],x[2]-x[3]),({a3:0,b3:0},q2-q1,b2,s.Matrix([0,1,1,0]),x[3],x[1]-x[2]),({a3:0,b2:0},q2,b3,s.Matrix([0,1,0,1]),x[2],x[1]-x[3])]
  checks['star_base_branch_common_factor']=all(s.expand(vv)==0 for vv in V.subs({a3:0,b2:0,b3:0})-S*se)
  directions=[{x[0]:0,x[1]:1,x[2]:0,x[3]:0},{x[0]:0,x[1]:0,x[2]:1,x[3]:0},{x[0]:0,x[1]:0,x[2]:0,x[3]:1},{x[0]:0,x[1]:1,x[2]:1,x[3]:1}]
  for j,(sub,Q,lam,d,u,v) in enumerate(casesstar):
   checks[f'star_branch_{j}_vector_formula']=all(s.expand(vv)==0 for vv in V.subs(sub)-lam*Q*d-S*se)
   checks[f'star_branch_{j}_Q_factors']=s.expand(Q-u*v)==0
   checks[f'star_branch_{j}_Q_rank_two']=s.hessian(Q,x).rank()==2
   checks[f'star_branch_{j}_invariant_coordinates']=s.expand(sum(s.diff(u,xx)*vv for xx,vv in zip(x,d)))==0 and s.expand(sum(s.diff(v,xx)*vv for xx,vv in zip(x,d)))==0
   images=[(u.subs(dd),v.subs(dd))for dd in directions]
   checks[f'star_branch_{j}_both_binary_axes_present']=any(uu!=0 and vv==0 for uu,vv in images) and any(uu==0 and vv!=0 for uu,vv in images)
 V=q1*A+q2*B
 for j,(sub,Q,d) in enumerate(cases):
  checks[f'{kind}_branch_{j}_common_factor']=all(s.expand(vv-ww)==0 for vv,ww in zip(V.subs(sub),Q*d))
  checks[f'{kind}_branch_{j}_Q_reduced']=s.hessian(Q,x).rank()>=2
 gt=s.groebner(target,*params,domain=s.QQ)
 checks[f'{kind}_exact_nilpotency_ideal']=all(gt.reduce(e)[1]==0 for e in ee) and all(G.reduce(e)[1]==0 for e in target)
 out[kind]={'q1':str(q1),'q2':str(q2),'parameters':list(map(str,params)),'A':list(map(str,A)),'B':list(map(str,B)),'M':[[str(s.expand(M[i,j])) for j in range(2)]for i in range(2)],'det':str(det),'remainder_coefficients':list(map(str,ee)),'exact_ideal_generators':list(map(str,target))}
# Universal star Pfaffian identity: all non-0 entries are homogeneousquadrics in y,
# while P0a=c*s*ya+arbitraryfunctions(y). No assumption c!=0 ismade.
s0,y1,y2,y3=x;y=s.Matrix([y1,y2,y3]);c=s.symbols('c');q1=y1*(y2-y3);q2=y2*(y1-y3)
pcoef=s.symbols('p0:12');Qa=s.symbols('Q1:4');P=s.zeros(5)
for j in range(1,4): P[0,j]=c*s0*x[j]+Qa[j-1]
P[0,4]=s.symbols('S')
pairs=[(1,2),(1,3),(1,4),(2,3),(2,4),(3,4)]
for j,(aa,bb) in enumerate(pairs):P[aa,bb]=pcoef[2*j]*q1+pcoef[2*j+1]*q2
for aa in range(5):
 for bb in range(aa):P[aa,bb]=-P[bb,aa]
def pf4(inds):
 i,j,k,l=inds;return s.expand(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])
pf=s.Matrix([(-1)**i*pf4([j for j in range(5) if j!=i])for i in range(5)])
U=s.Matrix([P[1,4],P[2,4],P[3,4]])
checks['star_pfaffian_b0_independent_s']=s.diff(pf[0],s0)==0
checks['star_pfaffian_crossproduct_identity']=all(s.expand(s.diff(pf[i+1],s0)+c*y.cross(U)[i])==0 for i in range(3))
checks['star_pfaffian_b0_euler_degree_four']=s.expand(sum(xx*s.diff(pf[0],xx)for xx in x[1:])-4*pf[0])==0
checks['star_closedness_certificate']=s.expand(sum(x[i]*(s.diff(pf[0],x[i])-s.diff(pf[i],s0))for i in range(1,4))-4*pf[0])==0
out['star_pfaffian_certificate']='4*b0 = sum_{i=1}^3 x_i*(partial_i b0 - partial_0 b_i) on H'
# Binary quinticdoublezerosatthebothaxes.
u,v=s.symbols('u v');cc=s.symbols('c0:6');f=sum(cc[j]*u**(5-j)*v**j for j in range(6));ee=[]
for pt in[{u:1,v:0},{u:0,v:1}]:ee += [s.diff(f,u).subs(pt),s.diff(f,v).subs(pt)]
sol=list(s.linsolve(ee,cc))[0];fs=s.expand(f.subs(dict(zip(cc,sol))))
checks['binary_quintic_double_zeros_factorization']=s.expand(fs-u*u*v*v*(cc[2]*u+cc[3]*v))==0
# The pure-cube normaljet coefficient usedinallcases.
h,Q,R=s.symbols('h Q R');L0,A0,Lq,Lr,Aq,Ar,Bq,Br,dc,fc=s.symbols('L0 A0 Lq Lr Aq Ar Bq Br dc fc')
jet=L0*Q**2+A0*h*Q+A0**2/(4*L0)*h*h+Q*Q*(Lq*Q+Lr*R)+h*Q*(Aq*Q+Ar*R)+dc*h*R*R+h*h*(Bq*Q+Br*R)+fc*h**3
kernel=s.expand(jet.subs(Q,-A0*h/(2*L0)));kp=s.Poly(kernel,h,R)
checks['kernel_jet_no_R_cube']=kp.coeff_monomial(R**3)==0
checks['kernel_jet_hR2_coefficient_exact']=s.simplify(kp.coeff_monomial(h*R**2)-dc)==0
out['checks']=checks;out['all_passed']=all(checks.values());out['scope']='Exact necessary conormal ideals and polynomial identities; closedpoint exclusions use normal actual D, reduced CI support, and E8 jets, not decomposition of the full Jacobi scheme.'
Path(__file__).with_name('211_1111_results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));assert out['all_passed']

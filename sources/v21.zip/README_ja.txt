射影4空間の Poisson 構造 — 研究継続 第21版

主結果
正規な実際の退化五次因子を持つ場合、一般E8型の特異四次支持は
超平面P3に含まれない。特異支持が既約ならq_(5,1)型に限られる。
それ以外の必要支持は、P4全体を張る8つの明示的配置に限られる。
8配置それぞれの全Jacobiイデアルを保存した。実現可能性は未決定。

この8は支持の射影配置数であり、Poisson族や既約成分の数ではない。
線形モデルの40,40,41,41,43,42,44,48も、Poisson族の次元ではない。
全体の既約成分数の下界57は変更していない。

読む順序
1. p4_poisson_completeness_v21.pdf — 証明と主要な数式を含む本文
2. HANDOFF.txt — 次回の研究を再開するための具体的な記録
3. data/tree_jacobi_models/ — 8モデルの全行列、全二次式、Pfaffian、F
4. proofs/ — 独立証明・監査・厳密検証コード
5. data/reproduced/ — 今回再実行した検証結果

PDFの再生成
LuaLaTeX、luatexja、HaranoAjiフォントが使える環境で、このディレクトリから：

  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v21.tex

数学的検証
Python3、SymPy 1.14を用意し、このディレクトリから：

  python3 code/run_checks.py --output-directory /tmp/p4-v21-checks --regenerate-linear-models

これは一時コピー内で計算し、旧版と保存済みモデルを編集しない。
11群の検証を実行し、8つの線形モデルを150係数から再生成して比較する。

全Jacobiイデアルだけを独立に監査する場合、追加パッケージは不要：

  python3 code/audit_tree_jacobi_sparse.py data/tree_jacobi_models --output-directory /tmp/p4-v21-jacobi-audit

標準ライブラリのFractionによる正確な係数計算で、8モデル249項目、
全350係数スロットと保存イデアルの同一性、全80本のdb-J恒等式等を検証する。

モデルの再生成（保存済みデータとは異なる出力先を指定）：

  python3 code/build_p4_tree_linear.py --output-directory /tmp/p4-v21-linear
  python3 code/build_tree_jacobi.py /tmp/p4-v21-linear --output-directory /tmp/p4-v21-jacobi

ファイル不変性の検証：

  python3 code/verify_bundle.py

previous_v20/ の全1566ファイルと previous_v20.pdf は、前版からbyte単位で不変。
さらに古い版は previous_v20/ 内に再帰的に収録されている。
旧版内の「未決定」はその版当時の記録であり、最新の再開地点はHANDOFF.txtである。

主要な注意
・基礎体C、PGL5商を取る前の全射影Jacobiスキームを対象とする。
・正規性は被約化した因子ではなく、実際の退化因子に課す。
・非零有理数の定数倍だけを除いて式を整理し、パラメータ除算は行っていない。
・根基化、飽和、成分分解は未実行。閉点の排除と非被約スキームの主張を分ける。
・B⊂Yはスキームとして成り立つが、B⊂Y_redをスキームとして主張しない。
・P3内の四直線同時交点とP4内の独立な四方向の同時交点を混同しない。

"""Generate full Jacobi ideals from the eight canonical linear tree models.

Only nonzero rational scalar factors and duplicate equations are removed.
No parameter localization, radical, saturation, or component decomposition.
"""
from pathlib import Path
from itertools import combinations
import argparse
import json
import time
import sympy as s

def build(path, destination):
    started=time.monotonic()
    model=json.loads(path.read_text())
    x=s.symbols('x0:5'); z=s.symbols('z0:'+str(model['linear_dimension']))
    local={str(v):v for v in x+z}
    P=s.zeros(5)
    for key,value in model['P_entries'].items():
        i,j=map(int,key);P[i,j]=s.sympify(value,locals=local);P[j,i]=-P[i,j]
    assert all(s.expand(sum(s.diff(P[i,j],x[i]) for i in range(5)))==0 for j in range(5))
    jacobi={}
    equations={}
    nonzero=0
    for i,j,k in combinations(range(5),3):
        J=s.expand(sum(P[i,l]*s.diff(P[j,k],x[l])+P[j,l]*s.diff(P[k,i],x[l])+P[k,l]*s.diff(P[i,j],x[l]) for l in range(5)))
        jacobi[(i,j,k)]=J
        for coefficient in s.Poly(J,*x).coeffs():
            if coefficient==0:continue
            nonzero+=1
            e=s.Poly(coefficient,*z,domain=s.QQ).monic().as_expr()
            equations[s.srepr(e)]=e
    b=[]
    for omitted in range(5):
        a,c,d,e=[i for i in range(5) if i!=omitted]
        b.append(s.expand((-1)**omitted*(P[a,c]*P[d,e]-P[a,d]*P[c,e]+P[a,e]*P[c,d])))
    identities=[]
    for i,j in combinations(range(5),2):
        complement=tuple(k for k in range(5) if k not in (i,j))
        check=s.expand(s.diff(b[j],x[i])-s.diff(b[i],x[j])-(-1)**(i+j+1)*jacobi[complement])==0
        identities.append(check)
    assert all(identities)
    F=s.expand(sum(x[i]*b[i] for i in range(5))/5)
    output={'scope':'Full Jacobi ideal on fixed linear model; normality and nonzero Pfaffian not imposed',
      'linear_model':model,'jacobi_coefficient_slots':350,
      'nonzero_jacobi_coefficients':nonzero,'distinct_monic_jacobi_equations':len(equations),
      'jacobi_equations':[str(equations[k]) for k in sorted(equations)],
      'pfaffians':[str(v) for v in b],'F':str(F),
      'pfaffian_jacobi_identities':identities,
      'parameter_division':False,'all_checks_passed':True}
    destination.mkdir(exist_ok=True,parents=True)
    (destination/(model['name']+'.json')).write_text(json.dumps(output,indent=2)+'\n')
    return {'name':model['name'],'linear_dimension':model['linear_dimension'],
      'nonzero_jacobi_coefficients':nonzero,'distinct_monic_jacobi_equations':len(equations),
      'pfaffian_jacobi_identities_passed':len(identities),'seconds':round(time.monotonic()-started,3)}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('linear_model_directory',type=Path)
    ap.add_argument('--output-directory',type=Path,required=True);args=ap.parse_args()
    reports=[]
    for path in sorted(args.linear_model_directory.glob('*.json')):
        header=json.loads(path.read_text())
        if not isinstance(header,dict) or 'P_entries' not in header:continue
        report=build(path,args.output_directory);reports.append(report);print(json.dumps(report),flush=True)
    assert len(reports)==8, 'Expected exactly eight fixed-support models'
    (args.output_directory/'summary.json').write_text(json.dumps({'models':reports,'all_passed':True},indent=2)+'\n')

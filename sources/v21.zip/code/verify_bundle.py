"""Read-only verification of v21 and all byte-preserved v20 files."""
from pathlib import Path
import hashlib
import json

root=Path(__file__).resolve().parents[1]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
verified=0
for line in (root/'SHA256SUMS.txt').read_text().splitlines():
    expected,relative=line.split('  ',1)
    assert digest(root/relative)==expected,'Bundle mismatch: '+relative
    verified+=1
old=json.loads((root/'data/previous_v20_preservation.json').read_text())
for relative,expected in old['files'].items():
    assert digest(root/'previous_v20'/relative)==expected,'Prior edition changed: '+relative
assert old['file_count']==1566
assert digest(root/'previous_v20.pdf')=='2ef508c25ec44ee6a6c8844adcd8188c86cc8694bc0c6bffb86af37de95dee36'
print(json.dumps({'all_passed':True,'all_files_verified':verified,
 'historical_files_verified':old['file_count'],'historical_pdf_verified':True},indent=2))

#!/usr/bin/env python3
"""Independent exact audit of archived P4 tree Jacobi models.

Uses only the Python standard library (ast + fractions), not SymPy, Singular,
or the model generator. Polynomial multiplication and differentiation are sparse
coefficient operations. Expressions are parsed as data; no eval or executable
input is used. Division in parsed expressions must be by a rational constant.
"""
from __future__ import annotations
import argparse,ast,json,hashlib,time
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path

class Ring:
    def __init__(self,names):
        self.names=tuple(names);self.indices={name:i for i,name in enumerate(names)}
        assert len(self.indices)==len(names)
        self.n=len(names);self.zero=(0,)*self.n
    def one(self):return {self.zero:Q(1)}
    def var(self,i):
        a=list(self.zero);a[i]=1;return {tuple(a):Q(1)}
    def monomial(self,node):
        if isinstance(node,ast.Constant):
            if not isinstance(node.value,int):raise ValueError('Only integer literals are allowed')
            return Q(node.value),self.zero
        if isinstance(node,ast.Name):
            if node.id not in self.indices:raise ValueError('Unknown variable '+node.id)
            e=list(self.zero);e[self.indices[node.id]]=1;return Q(1),tuple(e)
        if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
            c,e=self.monomial(node.operand);return (-c if isinstance(node.op,ast.USub) else c),e
        if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Mult):
            c,e=self.monomial(node.left);d,f=self.monomial(node.right)
            return c*d,tuple(a+b for a,b in zip(e,f))
        if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Div):
            c,e=self.monomial(node.left);d,f=self.monomial(node.right)
            if f!=self.zero or not d:raise ValueError('Division must be by a nonzero rational constant')
            return c/d,e
        if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Pow):
            c,e=self.monomial(node.left);d,f=self.monomial(node.right)
            if f!=self.zero or d.denominator!=1 or d<0:raise ValueError('Exponent must be a nonnegative integer')
            return c**int(d),tuple(a*int(d) for a in e)
        raise ValueError('Expected an expanded polynomial monomial: '+ast.dump(node))
    def parse(self,expression):
        root=ast.parse(expression,mode='eval').body
        pending=[(root,Q(1))];out={}
        while pending:
            node,sign=pending.pop()
            if isinstance(node,ast.BinOp) and isinstance(node.op,(ast.Add,ast.Sub)):
                pending.append((node.left,sign));pending.append((node.right,-sign if isinstance(node.op,ast.Sub) else sign));continue
            if isinstance(node,ast.UnaryOp) and isinstance(node.op,(ast.UAdd,ast.USub)):
                pending.append((node.operand,-sign if isinstance(node.op,ast.USub) else sign));continue
            c,e=self.monomial(node);c*=sign
            if c:out[e]=out.get(e,Q(0))+c
        return {e:c for e,c in out.items() if c}
    def add(self,*polys):
        result={}
        for p in polys:
            for e,c in p.items():result[e]=result.get(e,Q(0))+c
        return {e:c for e,c in result.items() if c}
    def scale(self,p,c):
        c=Q(c);return {e:c*v for e,v in p.items() if c*v}
    def mul(self,p,q):
        out={}
        for e,c in p.items():
            for f,d in q.items():
                a=tuple(u+v for u,v in zip(e,f));out[a]=out.get(a,Q(0))+c*d
        return {e:c for e,c in out.items() if c}
    def power(self,p,n):
        out=self.one()
        for _ in range(n):out=self.mul(out,p)
        return out
    def diff(self,p,i):
        out={}
        for e,c in p.items():
            if e[i]:
                ee=list(e);ee[i]-=1;out[tuple(ee)]=c*e[i]
        return out
    def substitute_x(self,p,images):
        # Only five x-coordinates are substituted; all z and t variables remain.
        out={};powers={(i,k):self.power(images[i],k) for i in range(5) for k in range(3)}
        for e,c in p.items():
            rest=(0,)*5+e[5:];term={rest:c}
            for i,k in enumerate(e[:5]):term=self.mul(term,powers[i,k])
            out=self.add(out,term)
        return out


def normalize_coefficient(coeff):
    if not coeff:return None
    # Lexicographic parameter order z0,z1,... agrees with Poly(...,*z).LC().
    leading=max(coeff);rational_lc=coeff[leading]
    return tuple(sorted((mon,c/rational_lc) for mon,c in coeff.items() if c))

def coefficient_groups(p):
    groups={}
    for e,c in p.items():
        assert e[-1]==0,'Jacobi expression unexpectedly depends on normalization parameter t'
        xmon=e[:5];zmon=e[5:-1]
        group=groups.setdefault(xmon,{})
        group[zmon]=group.get(zmon,Q(0))+c
    return {x:{z:c for z,c in group.items() if c}for x,group in groups.items() if any(group.values())}

def rational_rank(rows,n):
    pivots={}
    for row in rows:
        row={j:Q(v)for j,v in enumerate(row) if v}
        while row:
            j=min(row);v=row[j]
            if j not in pivots:
                pivots[j]={k:w/v for k,w in row.items()};break
            pivot=pivots[j]
            for k,w in pivot.items():
                value=row.get(k,Q(0))-v*w
                if value:row[k]=value
                elif k in row:del row[k]
    return len(pivots)

def audit(path):
    started=time.monotonic();raw=path.read_bytes();data=json.loads(raw);model=data['linear_model']
    nz=model['linear_dimension'];names=['x'+str(i)for i in range(5)]+model['parameter_order']+['t'];r=Ring(names)
    checks={};P=[[{}for _ in range(5)]for _ in range(5)]
    checks['ten_upper_entries']=set(model['P_entries'])=={str(i)+str(j)for i,j in combinations(range(5),2)}
    for key,expr in model['P_entries'].items():
        i,j=map(int,key);P[i][j]=r.parse(expr);P[j][i]=r.scale(P[i][j],-1)
    checks['coordinate_parameter_names']=model['parameter_order']==['z'+str(i)for i in range(nz)]
    checks['all_entries_bidegree_x2_z1']=all(sum(e[:5])==2 and sum(e[5:-1])==1 and e[-1]==0 for i,j in combinations(range(5),2)for e in P[i][j])
    checks['all_five_divergence_identities']=all(not r.add(*(r.diff(P[i][j],i)for i in range(5)))for j in range(5))
    # Verify archived linear map is injective: full coefficient and residue map.
    linear_rows=[]
    for i,j in combinations(range(5),2):
        groups=coefficient_groups(P[i][j])
        for group in groups.values():
            row=[Q(0)]*nz
            for e,c in group.items():
                assert sum(e)==1
                row[e.index(1)]+=c
            linear_rows.append(row)
    residues=[r.parse(expr)for expr in model['residue_expressions']]
    checks['all_residue_expressions_linear']=all(sum(e[:5])==0 and sum(e[5:-1])==1 and e[-1]==0 for p in residues for e in p)
    for p in residues:
        row=[Q(0)]*nz
        for e,c in p.items():row[e[5:-1].index(1)]+=c
        linear_rows.append(row)
    parameter_rank=rational_rank(linear_rows,nz)
    checks['linear_parameterization_injective']=parameter_rank==nz
    checks['dimension_metadata_consistent']=model['unknowns']-model['linear_rank']==nz
    component_checks=[]
    for index,component in enumerate(model['components']):
        images=[r.parse(expr)for expr in component['parametrization']]
        R={}
        for residue_index,basis in zip(component['residue_indices'],component['residue_basis']):
            R=r.add(R,r.mul(residues[residue_index],r.parse(basis)))
        ok=True
        for i,j in combinations(range(5),2):
            wedge=r.add(r.mul(images[i],r.diff(images[j],r.n-1)),r.scale(r.mul(images[j],r.diff(images[i],r.n-1)),-1))
            target=r.scale(r.mul(R,wedge),Q(-1,5))
            ok=ok and r.substitute_x(P[i][j],images)==target
        component_checks.append(ok)
        checks['component_'+str(index)+'_all_ten_residue_restrictions']=ok
    # Reconstruct all 350 Jacobi coefficient slots by sparse convolution.
    jacobi={};generated_set=set();nonzero_count=0;slot_certificates=[];slot_normalizations=[]
    for i,j,k in combinations(range(5),3):
        terms=[]
        for ell in range(5):
            terms += [r.mul(P[i][ell],r.diff(P[j][k],ell)),r.mul(P[j][ell],r.diff(P[k][i],ell)),r.mul(P[k][ell],r.diff(P[i][j],ell))]
        J=r.add(*terms);jacobi[i,j,k]=J;groups=coefficient_groups(J)
        assert all(sum(xmon)==3 and all(sum(zmon)==2 for zmon in coeff)for xmon,coeff in groups.items())
        nonzero_count+=len(groups)
        for xmon,coeff in sorted(groups.items()):
            norm=normalize_coefficient(coeff);generated_set.add(norm);slot_normalizations.append(norm)
            # Each leading coefficient is an exact nonzero rational, hence no parameter division.
            lc=coeff[max(coeff)];slot_certificates.append({'triple':[i,j,k],'x_monomial':list(xmon),'rational_leading_coefficient':str(lc)})
    stored=[];all_monic=True;all_quadratic=True
    for expr in data['jacobi_equations']:
        pp=r.parse(expr);group={}
        for e,c in pp.items():
            all_quadratic=all_quadratic and sum(e[:5])==0 and sum(e[5:-1])==2 and e[-1]==0
            group[e[5:-1]]=c
        assert group
        all_monic=all_monic and group[max(group)]==1
        stored.append(normalize_coefficient(group))
    stored_set=set(stored)
    equation_indices={poly:i for i,poly in enumerate(stored)}
    for certificate,normalization in zip(slot_certificates,slot_normalizations):
        certificate['stored_equation_index']=equation_indices.get(normalization)
    checks['jacobi_350_slots_metadata']=data['jacobi_coefficient_slots']==350
    checks['jacobi_nonzero_coefficient_count']=nonzero_count==data['nonzero_jacobi_coefficients']
    checks['jacobi_stored_all_homogeneous_quadratic']=all_quadratic
    checks['jacobi_stored_all_monic_over_QQ']=all_monic
    checks['jacobi_stored_no_duplicates']=len(stored)==len(stored_set)
    checks['jacobi_exact_normalized_set_equality']=generated_set==stored_set
    checks['jacobi_distinct_count_metadata']=len(generated_set)==data['distinct_monic_jacobi_equations']
    checks['no_parameter_division_asserted']=data['parameter_division'] is False
    # Signed Pfaffians and all ten db-J identities, before imposing Jacobi.
    pf=[]
    for omit in range(5):
        i,j,k,ell=[a for a in range(5)if a!=omit]
        p=r.add(r.mul(P[i][j],P[k][ell]),r.scale(r.mul(P[i][k],P[j][ell]),-1),r.mul(P[i][ell],P[j][k]))
        pf.append(r.scale(p,(-1)**omit))
    checks['all_five_stored_pfaffians_exact']=all(p==r.parse(expr)for p,expr in zip(pf,data['pfaffians'])) and len(data['pfaffians'])==5
    identity_results=[]
    for i,j in combinations(range(5),2):
        complement=tuple(k for k in range(5)if k not in(i,j))
        left=r.add(r.diff(pf[j],i),r.scale(r.diff(pf[i],j),-1))
        right=r.scale(jacobi[complement],(-1)**(i+j+1))
        ok=left==right;identity_results.append(ok);checks['pfaffian_Jacobi_identity_'+str(i)+str(j)]=ok
    F=r.scale(r.add(*(r.mul(r.var(i),pf[i])for i in range(5))),Q(1,5))
    checks['Euler_primitive_F_exact']=F==r.parse(data['F'])
    checks['all_five_universal_Pfaffian_kernel_identities']=all(not r.add(*(r.mul(P[i][j],pf[j])for j in range(5)))for i in range(5))
    report={'model':model['name'],'source_sha256':hashlib.sha256(raw).hexdigest(),'linear_dimension':nz,'independent_linear_parameter_rank':parameter_rank,'components':len(model['components']),'total_jacobi_coefficient_slots':350,'nonzero_jacobi_coefficients':nonzero_count,'distinct_monic_Jacobi_equations':len(generated_set),'checks':checks,'all_passed':all(checks.values()),'seconds':round(time.monotonic()-started,3),'rational_normalization_certificates':slot_certificates}
    return report

def main():
    ap=argparse.ArgumentParser();ap.add_argument('model_directory',type=Path);ap.add_argument('--output-directory',type=Path,required=True);args=ap.parse_args();args.output_directory.mkdir(parents=True,exist_ok=True)
    expected={'1111_chain','1111_concurrent','1111_triple_tail','211_conic_center','211_line_center','211_triple','22_node','31_external'}
    paths=sorted(p for p in args.model_directory.glob('*.json')if p.stem in expected)
    reports=[]
    for path in paths:
        rep=audit(path);(args.output_directory/(path.stem+'_audit.json')).write_text(json.dumps(rep,indent=2)+'\n');reports.append(rep)
        print(json.dumps({k:rep[k]for k in['model','linear_dimension','nonzero_jacobi_coefficients','distinct_monic_Jacobi_equations','all_passed','seconds']}),flush=True)
        if not rep['all_passed']:raise AssertionError(rep['checks'])
    summary={'method':'Independent Python standard-library sparse rational convolution; no SymPy or generator import','all_eight_models_present':{rep['model']for rep in reports}==expected,'number_of_models':len(reports),'total_checks':sum(len(rep['checks'])for rep in reports),'all_passed':all(rep['all_passed']for rep in reports) and {rep['model']for rep in reports}==expected,'models':[{k:rep[k]for k in['model','source_sha256','linear_dimension','nonzero_jacobi_coefficients','distinct_monic_Jacobi_equations','seconds']}for rep in reports]}
    (args.output_directory/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True);assert summary['all_passed']
if __name__=='__main__':main()

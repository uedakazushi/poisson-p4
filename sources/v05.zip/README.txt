射影4空間の Poisson 構造：研究継続 v5
====================================
2026年10月28日。基礎体 C。日本語本文は LuaLaTeX。

主な成果
--------
1. 全射影 Poisson scheme の既約成分数の下界を47から48へ更新した。
   新しい22次元成分の代表は P=x0^2 J+H wedge N。
   D=3(x0=0)+(x0^2+2x1x4+x3^2=0)、quadric rank4。
   全接空間とPGL軌道の次元22を三つの実装で検証した。
2. 45変数の compatible quadratic locus Q では、非冪零 modular field
   の開集合に交わる成分は、既知の10成分に限る。
3. 正則冪零 fixed-trace scheme は被約二直線、中心化群で二軌道。
   一方は既知T4の滑らかな境界、他方は9次元の実際のQ成分。
4. 最小冪零 fixed fiber の被約台は次元9,9,6の三成分。
   二つの9次元成分のSp4移動閉包は、全Qの異なる13次元成分。
   Qで確認した成分は計13。これはP4全体の48とは別の数である。
5. 安定rank2分岐で、coneまたはnonnormalな既約三次Casimirがあれば、
   実際のRat(1,1,3)型となる。中心の有限生成は仮定していない。
6. Rat113/Rat122の外側のA1=A2=0分岐で、非零三次Casimirがあれば
   essential5-variable、normal、noncone、heightJ=3となる。
   一線形分岐にはL^3が残るため、この条件を無条件に述べてはいけない。

正確な定理・仮定・証明はPDFおよびproofs/にある。
完全分類、正確な成分総数、文献上の新規性は主張していない。

収録物
------
p4_poisson_completeness_v5.pdf : 日本語の定理と証明
*.tex                         : LuaLaTeX source
code/                         : 正確な検証コードと独立監査
data/                         : 再生成したJSON証明書、実行記録、PDF確認結果
proofs/                       : 完全な係数表示、補助定理、独立な証明監査
previous_v4/                  : 変更していない前回の記録（v3以下も含む）
research_checkpoints/         : 未確定の次回課題。主定理の根拠に使用しない
HANDOFF.txt                   : 到達点と残存課題の精密な引継ぎ
SHA256SUMS.txt                 : ファイルの内容ハッシュ

再現方法
--------
Python3.12、SymPy1.14.0、NumPy2.3.5で確認した。
標準的なPython環境では必要に応じて次を実行する。

  python3 -m pip install -r requirements.txt
  python3 code/run_v5_checks.py

後者は十二の証明書をdata/へ再生成する。ネットワーク、乱数、浮動小数点の
rank推定は使用しない。実行時に過去の証明書や原稿は変更しない。
一部の現在のコードは previous_v4/previous_v3/code の正確な多項式演算を
再利用するので、そのディレクトリを削除しないこと。
独立した新成分監査はSymPyのみで、過去のPoisson helperをimportしない。

単独実行の出力指定は次の二種類である。

  python3 code/certify_regular_nilpotent.py data
  python3 code/certify_minimal_nilpotent.py data
  python3 code/audit_triple_hyperplane.py data
  python3 code/nodal_cubic_certificate.py data
  python3 code/cubic_surface_certificate.py data
  python3 code/perazzo_cubic_certificate.py data
  python3 code/audit_cubic_central_spaces.py data

  python3 code/mixed_modular.py --output-dir data
  python3 code/certify_mixed.py --output-dir data
  python3 code/independent_audit_triple_hyperplane.py --output-dir data
  python3 code/cross_audit_cubic_cones.py --output-dir data
  python3 code/independent_perazzo_audit.py --output-dir data

cubic_surface_models.py は二つの標準形の正確なモデルを定義する補助module。
証明書は全150係数から解空間の完全性を検証しており、ansatzだけの検査ではない。

PDFの組版
---------
LuaLaTeX、luatexja、HaranoAjiフォントを備えたTeX Liveで次を実行する。

  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v5.tex

PDFは全ページを画像化して確認した。空の記入欄は設けていない。

規約
----
P#(df)^j = sum_i P^{ij} partial_i f
(delta P)^j = sum_i partial_i P^{ij}
P4の成分次元は非零bivectorの定数倍を除いた射影次元。
Qの成分次元はaffine dimension。PGL5の商はまだ取っていない。

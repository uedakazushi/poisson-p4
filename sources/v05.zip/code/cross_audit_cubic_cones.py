#!/usr/bin/env python3
"""Cross-check the written nonnormal-cubic relations and branch row formulas.

This imports the raw central/divergence-free models, whose completeness is
checked separately by the root's full 150-variable calculation. It independently
reconstructs the written parameter substitutions, the displayed equations,
their exact constant spans, and all forbidden-linear-factor row identities.
"""
from pathlib import Path
import argparse,json,sys
import sympy as s
HERE=Path(__file__).resolve().parent
sys.path.append(str(HERE.parent/'p4_v5_stable_work'))
from cubic_surface_models import models,x,y,z,w,t

A,B,C,D,E,F,G,H,I,J,R,U,V,K=s.symbols('A B C D E F G H I J R U V K')
PARAMS=(A,B,C,D,E,F,G,H,I,J,R,U,V,K)

def span_certificate(raw,stated):
    pp=[s.Poly(s.expand(f),*PARAMS) for f in raw+stated]
    mons=sorted({m for p in pp for m,c in p.terms()})
    M=s.Matrix([[p.coeff_monomial(m) for m in mons] for p in pp])
    rawM=M[:len(raw),:];statedM=M[len(raw):,:]
    assert rawM.rank()==statedM.rank()==M.rank()
    _,basis_indices=rawM.T.rref()
    basis=rawM[list(basis_indices),:]
    # Every original and stated row is explicitly in the selected raw basis.
    coefficients,free=basis.T.gauss_jordan_solve(M.T)
    assert free.rows==0
    assert basis.T*coefficients==M.T
    return {'raw_row_count':len(raw),'stated_row_count':len(stated),
            'common_span_rank':basis.rows,'raw_basis_indices':list(basis_indices),
            'all_rows_as_raw_basis_combinations':
             [[str(coefficients[i,j]) for i in range(coefficients.rows)]
              for j in range(coefficients.cols)]}

def checked_row(P,i,sub,expected):
    found=[s.expand(P[i,j].subs(sub,simultaneous=True)) for j in range(5) if j!=i]
    assert found==[s.expand(f) for f in expected],(found,expected)
    assert all(s.rem(f,x,x)==0 for f in found)
    return [str(f) for f in found]

def main(output_dir=HERE):
    output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    _,a,P,raw=models(1)
    conv=dict(zip(a,(A,B,E,C,D,F,G,H,I,J,U,V,K)))
    P1=P.subs(conv,simultaneous=True)
    raw1=[f.subs(conv,simultaneous=True) for f in raw]
    rel1=[2*A*H-C*G+D*F,K*H,A*I-B*F+E*C-U*D/6,
          V*D+2*K*G/3,K*D,2*B*H-C*J+D*I,U*C-2*K*I,
          A*J-B*G+E*D-V*C/2,K*C,B*U,A*U+3*B*V+2*K*E,
          K*B,A*V,K*A]
    cert1=span_certificate(raw1,rel1)
    cert1['K_nonzero_x_row']=checked_row(P1,0,
        {A:0,B:0,C:0,D:0,H:0,I:0,G:0,E:0},
        [K*x*y/2,0,-K*w*x,x*(-F*x/2+U*z/6+3*V*w/2+K*t/2)])
    assert P1[:4,:4].subs({K:0,A:0,B:0,C:0,D:0})==s.zeros(4)

    _,a,P,raw=models(2)
    conv=dict(zip(a,(A,B,E,C,D,F,G,H,I,3*I+R,J,U,V,K)))
    P2=P.subs(conv,simultaneous=True)
    raw2=[f.subs(conv,simultaneous=True) for f in raw]
    rel2=[(B+K)*H+J*C/3-D*I,
          A*H+B*R+3*K*I+K*R-U*C+C*G/3-D*F/3,
          A*I-B*F/3+J*K-U*D-V*C/3-K*F/3+E*C/3,
          3*B*U+3*U*K-3*V*D-2*K*G,
          A*(3*I+R)-B*F+E*C,A*J-B*G+E*D,
          A*U+3*B*V+2*K*E,A*U+B*V+K*E,A*V,K*A,K*B,K*D]
    cert2=span_certificate(raw2,rel2)
    cert2['K_nonzero_x_row']=checked_row(P2,0,
        {A:0,B:0,D:0,E:0},
        [K*x*x,-3*K*x*y,-K*x*z,x*((3*U-G)*y-J*x+V*z)])
    cert2['U_nonzero_y_row']=checked_row(P2,1,
        {K:0,V:0,A:0,B:0,D:0,E:0,J:0,G:3*U},
        [0,C*x*x/3,-C*x*y/3,-F*x*y/3-I*x*x-U*x*z])
    cert2['R_nonzero_x_row']=checked_row(P2,0,
        {K:0,U:0,V:0,A:0,B:0,E:0},
        [0,D*x*x,-D*x*y,-G*x*y-J*x*x])
    cert2['R_nonzero_y_row']=checked_row(P2,1,
        {K:0,U:0,V:0,A:0,B:0,E:0,D:0,G:0,J:0},
        [0,C*x*x/3,-C*x*y/3,-F*x*y/3-I*x*x])
    assert P2[:4,:4].subs({K:0,A:0,B:0,C:0,D:0})==s.zeros(4)
    # Two pivotal eliminations in the R branch, as polynomial identities.
    assert s.expand((rel2[4]-3*rel2[2]).subs({K:0,U:0,V:0})-A*R)==0
    assert s.expand(3*B*(B*R+C*G/3-D*F/3)
                    -C*(B*G-E*D)+D*(B*F-E*C)-3*B*B*R)==0
    report={'F1':cert1,'F2':cert2,
       'all_written_branch_rows_verified':True,
       'all_listed_rows_have_factor_x':True,
       'F2_R_branch_elimination_identities_verified':True,
       'scope':'Verifies written reductions in the supplied full raw models; model completeness and global geometric arguments have separate audits.'}
    (output_dir/'cross_audit_cubic_cones.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'all_checks_passed':True,
                     'F1_span_rank':cert1['common_span_rank'],
                     'F2_span_rank':cert2['common_span_rank']},indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=HERE)
    main(parser.parse_args().output_dir)

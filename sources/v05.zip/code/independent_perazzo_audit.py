#!/usr/bin/env python3
"""Independent tensor-action and forbidden-factor audit of the Perazzo proof.

Uses only SymPy, with no import of the stable agent's models or helpers.
Builds the Jacobian bivectors directly by alternating-index contraction;
checks the displayed three extra tensors, the quotient actions, and the
entire normalized y-row modulo the exact Pluecker ideal.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
import argparse,json
import sympy as s
HERE=Path(__file__).resolve().parent
x,y,z,w,t=s.symbols('x y z w t');X=(x,y,z,w,t)
PAIRS=list(combinations(range(5),2))
MON2=[X[i]*X[j] for i,j in combinations_with_replacement(range(5),2)]
F=x*x*z+x*y*w+y*y*t

def parity(seq):
    return (-1)**sum(seq[i]>seq[j] for i in range(len(seq)) for j in range(i+1,len(seq)))

def tensor(entries):
    P=s.zeros(5)
    for (i,j),f in entries.items():P[i,j]=f;P[j,i]=-f
    return P

def jacobian_form(theta):
    entries={}
    for i,j in PAIRS:
        f=0
        for k in range(5):
            if k in (i,j):continue
            l,m=[r for r in range(5) if r not in (i,j,k)]
            f+=parity((i,j,k,l,m))*s.diff(F,X[k])*theta.get((l,m),0)
        entries[i,j]=s.expand(f)
    return tensor(entries)

def vector(P):
    return s.Matrix([s.Poly(s.expand(P[i,j]),*X).coeff_monomial(mon)
                     for i,j in PAIRS for mon in MON2])

def pfaffian_equations(P,parameters):
    equations=[]
    for i,j,k,l in combinations(range(5),4):
        f=s.expand(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])
        for e in s.Poly(f,*X).coeffs():
            if e!=0:
                e=s.Poly(e,*parameters).monic().as_expr()
                if e not in equations:equations.append(e)
    return equations

def main(output_dir=HERE):
    output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    jac=[jacobian_form({ij:1}) for ij in PAIRS]
    extras=[
      tensor({(0,2):-y*z,(0,3):w*y+x*z,(0,4):-w*x,
              (1,3):-3*y*z,(1,4):3*x*z,(2,3):-2*z*z,
              (2,4):-w*z,(3,4):w*w-6*t*z}),
      tensor({(0,1):-x*y,(0,2):w*y,(0,3):t*y,(0,4):t*x,
              (1,2):-y*z,(1,3):-x*z,(1,4):-w*x,(2,3):w*z,
              (2,4):w*w-2*t*z,(3,4):t*w}),
      tensor({(0,1):x*x/2,(0,2):t*y/2-w*x/2,(0,3):-3*t*x/2,
              (1,2):x*z,(1,3):t*y/2+w*x/2,(1,4):-t*x/2,
              (2,3):3*t*z-w*w/2,(2,4):t*w/2,(3,4):t*t})]
    basis=jac+extras
    for P in basis:
        assert all(s.expand(sum(P[i,j]*s.diff(F,X[i]) for i in range(5)))==0 for j in range(5))
        assert all(s.expand(sum(s.diff(P[i,j],X[i]) for i in range(5)))==0 for j in range(5))
    N=s.Matrix.hstack(*[vector(P) for P in basis])
    assert N.rank()==13
    h,u,v,r=s.symbols('h u v r')
    shear=s.Matrix([[1,0,0,0,0],[h,1,0,0,0],[0,0,1,-h,h*h],
                    [0,0,0,1,-2*h],[0,0,0,0,1]])
    swap=s.Matrix([[0,1,0,0,0],[1,0,0,0,0],[0,0,0,0,1],
                   [0,0,0,1,0],[0,0,1,0,0]])
    reports={}
    for name,T,expected in [
      ('shear',shear,s.Matrix([[1,0,0],[-2*h,1,0],[-2*h*h,2*h,1]])),
      ('swap',swap,s.Matrix([[0,0,s.Rational(1,2)],[0,-1,0],[2,0,0]]))]:
        assert T.det()==1
        substitution=dict(zip(X,T.inv()*s.Matrix(X)))
        assert s.expand(F.subs(substitution,simultaneous=True)-F)==0
        columns=[]
        for P in basis:
            pushed=T*P.subs(substitution,simultaneous=True)*T.T
            coordinates,free=N.gauss_jordan_solve(vector(pushed))
            assert free.rows==0
            columns.append(coordinates)
        action=s.Matrix.hstack(*columns)
        assert action[10:,:10]==s.zeros(3,10)
        assert action[10:,10:]==expected
        reports[name]=[[str(e) for e in row] for row in expected.tolist()]
    D=v*v+2*u*r
    new=s.Matrix([u,v-2*h*u,r+2*h*v-2*h*h*u])
    assert s.expand(new[1]**2+2*new[0]*new[2]-D)==0
    assert new.subs(h,v/(2*u)).applyfunc(s.cancel)==s.Matrix([u,0,D/(2*u)])
    assert s.expand((-v)**2+2*(r/2)*(2*u)-D)==0

    # After the explicit group normalization, overall scaling sets u=1.
    # The Jacobian coefficients are left completely arbitrary.
    theta=s.symbols('c0:10')
    P=sum((c*B for c,B in zip(theta,jac)),s.zeros(5))+extras[0]
    equations=pfaffian_equations(P,theta)
    gb=s.groebner(equations,*theta,order='grevlex',domain=s.QQ)
    assert gb.reduce(s.Integer(1))[1]!=0
    # Verify y divides every full Hamiltonian coefficient modulo rank-two.
    for j in range(5):
        restricted=s.expand(P[1,j].subs(y,0))
        for coefficient in s.Poly(restricted,x,z,w,t).coeffs():
            assert gb.reduce(coefficient)[1]==0
    # The remaining nonzero coefficient makes centrality impossible.
    for coefficient in s.Poly(s.expand(P[1,0]-3*y*y/2),*X).coeffs():
        assert gb.reduce(coefficient)[1]==0
    grad_matrix=s.Matrix([[s.Poly(s.diff(F,zj),*X).coeff_monomial(mon)
                            for zj in X] for mon in MON2])
    assert grad_matrix.rank()==5
    report={
      'independence':'No imports from previous polynomial/Poisson models or helpers',
      'central_divergence_free_basis_rank':13,
      'displayed_extra_tensors_verified':True,
      'exact_quotient_group_actions':reports,
      'discriminant_invariant':True,
      'shear_normalization_identity':'(u,0,(v^2+2ur)/(2u))',
      'normalized_extra_u':1,
      'constant_two_form_pair_order':[list(ij) for ij in PAIRS],
      'normalized_Pluecker_equation_count':len(equations),
      'normalized_Pluecker_Groebner_basis':[str(p.as_expr()) for p in gb.polys],
      'normalized_Pluecker_ideal_is_proper':True,
      'every_y_Hamiltonian_coefficient_divisible_by_y_modulo_ideal':True,
      'Pyx_modulo_ideal':'3*y^2/2',
      'gradient_linear_rank':5,
      'scope':'Independently verifies group actions and normalized forbidden-factor contradiction. Full kernel completeness and initial necessary-equation derivation have separate certificates.'}
    (output_dir/'independent_perazzo_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'all_checks_passed':True,'basis_rank':13,
                     'quotient_actions_verified':list(reports),
                     'normalized_forbidden_factor_verified':True,
                     'Groebner_basis_count':len(gb.polys)},indent=2),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=HERE)
    main(parser.parse_args().output_dir)

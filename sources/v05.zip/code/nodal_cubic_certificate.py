#!/usr/bin/env python3
"""Exact linear algebra behind the nodal plane-cubic Casimir theorem.

Only SymPy is required. No random specialization or floating-point arithmetic.
The nonlinear decomposability step is a uniform identity, verified below.
"""
from pathlib import Path
from itertools import combinations, combinations_with_replacement
import json, sys
import sympy as s

HERE=Path(__file__).resolve().parent
x,y,z,u,v=s.symbols('x y z u v')
XYZ=(x,y,z)
X=(x,y,z,u,v)
F=x**3+y**3+x*y*z
grad=s.Matrix([s.diff(F,t) for t in XYZ])
MON2=[s.prod(XYZ[i] for i in I) for I in combinations_with_replacement(range(3),2)]

def coefficient_matrix(expressions,variables,coefficients):
    equations=[]
    for expr in expressions:
        equations += s.Poly(s.expand(expr),*variables).coeffs()
    return s.linear_eq_to_matrix(equations,coefficients)[0]

def rank_minor(M):
    _,cols=M.rref()
    _,rows=M.T.rref()
    minor=M.extract(rows,cols)
    det=minor.det(method='domain-ge')
    assert det!=0 and len(rows)==len(cols)
    return {'rank':len(cols),'row_indices':list(rows),'column_indices':list(cols),
            'minor_determinant':str(det)}

def main(output_dir):
    # Degree-zero and degree-one syzygies of dF.
    const=s.symbols('c0:3')
    M0=coefficient_matrix([sum(a*b for a,b in zip(const,grad))],XYZ,const)
    linear=s.symbols('l0:9')
    L=s.Matrix([sum(linear[3*i+j]*XYZ[j] for j in range(3)) for i in range(3)])
    M1=coefficient_matrix([L.dot(grad)],XYZ,linear)
    assert M0.rank()==3 and M1.rank()==9

    quad=s.symbols('q0:18')
    Y=s.Matrix([sum(quad[6*i+j]*MON2[j] for j in range(6)) for i in range(3)])
    divergence=sum(s.diff(Y[i],XYZ[i]) for i in range(3))
    M2=coefficient_matrix([Y.dot(grad)],XYZ,quad)
    M2div=coefficient_matrix([Y.dot(grad),divergence],XYZ,quad)
    assert M2.rank()==14 and M2div.rank()==15
    S=[
        s.Matrix([-grad[1],grad[0],0]),
        s.Matrix([-grad[2],0,grad[0]]),
        s.Matrix([0,-grad[2],grad[1]]),
        s.Matrix([-x*z,3*x*x,z*z-9*x*y]),
    ]
    for i,T in enumerate(S):
        assert s.expand(T.dot(grad))==0
        assert s.expand(sum(s.diff(T[j],XYZ[j]) for j in range(3)))==(z if i==3 else 0)
    basis=s.Matrix.hstack(*[s.Matrix([s.Poly(T[i],*XYZ).coeff_monomial(m)
                           for i in range(3) for m in MON2]) for T in S])
    assert basis.rank()==4 and M2*basis==s.zeros(M2.rows,4)
    assert M2div*basis[:,:3]==s.zeros(M2div.rows,3)

    # General quadratic unimodular bivector with F central.
    k=s.symbols('k')
    a=s.symbols('a0:4');b=s.symbols('b0:4');h=s.symbols('h0:6')
    Y=sum((a[i]*S[i] for i in range(4)),s.zeros(3,1))
    Z=sum((b[i]*S[i] for i in range(4)),s.zeros(3,1))
    h0=sum(h[i]*MON2[i] for i in range(6))
    H=h0+v*a[3]*z-u*b[3]*z
    PF=s.Matrix([[0,grad[2],-grad[1]],
                 [-grad[2],0,grad[0]],
                 [grad[1],-grad[0],0]])
    P=s.zeros(5)
    P[:3,:3]=k*PF
    for i in range(3):
        P[i,3]=Y[i];P[3,i]=-Y[i]
        P[i,4]=Z[i];P[4,i]=-Z[i]
    P[3,4]=H;P[4,3]=-H
    assert all(s.expand(sum(P[i,j]*s.diff(F,X[i]) for i in range(5)))==0 for j in range(5))
    assert all(s.expand(sum(s.diff(P[i,j],X[i]) for i in range(5)))==0 for j in range(5))

    # The only potentially nonzero Pluecker components are ij u v.
    for I in combinations(range(5),4):
        i,j,r,t=I
        pf=s.expand(P[i,j]*P[r,t]-P[i,r]*P[j,t]+P[i,t]*P[j,r])
        expected=s.expand(k*H*PF[i,j]-Y[i]*Z[j]+Y[j]*Z[i]) if r==3 and t==4 else 0
        assert s.expand(pf-expected)==0

    # For k!=0, divergence-free Y and Z are Hamiltonians of linear forms.
    ell0,ell1,ell2,m0,m1,m2=s.symbols('ell0 ell1 ell2 m0 m1 m2')
    ell=ell0*x+ell1*y+ell2*z;mm=m0*x+m1*y+m2*z
    de=s.Matrix([ell0,ell1,ell2]);dm=s.Matrix([m0,m1,m2])
    HY=-k*PF*de
    HZ=-k*PF*dm
    HH=k*(de.T*PF*dm)[0]
    normalized=s.zeros(5);normalized[:3,:3]=k*PF
    for i in range(3):
        normalized[i,3]=HY[i];normalized[3,i]=-HY[i]
        normalized[i,4]=HZ[i];normalized[4,i]=-HZ[i]
    normalized[3,4]=HH;normalized[4,3]=-HH
    for C in [F,u+ell,v+mm]:
        assert all(s.expand(sum(normalized[i,j]*s.diff(C,X[i]) for i in range(5)))==0 for j in range(5))
    for I in combinations(range(5),4):
        i,j,r,t=I
        assert s.expand(normalized[i,j]*normalized[r,t]-normalized[i,r]*normalized[j,t]+normalized[i,t]*normalized[j,r])==0

    report={
        'F':str(F),'coordinate_order':[str(t) for t in X],
        'constant_syzygy_dimension':0,'linear_syzygy_dimension':0,
        'quadratic_syzygy_dimension':4,
        'divergence_free_quadratic_syzygy_dimension':3,
        'constant_matrix':rank_minor(M0),'linear_matrix':rank_minor(M1),
        'quadratic_matrix':rank_minor(M2),'quadratic_divergence_matrix':rank_minor(M2div),
        'quadratic_syzygy_basis':[[str(c) for c in T] for T in S],
        'basis_divergences':['0','0','0','z'],
        'general_unimodular_central_bivector_parameter_count':15,
        'general_model_centrality_and_divergence_zero_verified':True,
        'decomposability_identity':'Pf_ijuv=k*H*PF_ij-Y_i*Z_j+Y_j*Z_i; other Pfaffians vanish',
        'linear_casimirs_after_hamiltonian_shifts_verified':True,
        'scope':'Supports the complete proof in nodal_plane_cubic_theorem.txt; no rank2/primitive/stability hypothesis is inferred from numeric samples.',
    }
    output_dir.mkdir(parents=True,exist_ok=True)
    (output_dir/'nodal_cubic_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'all_checks_passed':True,
                     'syzygy_dimensions':[0,0,4,3],
                     'general_central_unimodular_parameters':15},indent=2))

if __name__=='__main__':
    main(Path(sys.argv[1]) if len(sys.argv)>1 else HERE)

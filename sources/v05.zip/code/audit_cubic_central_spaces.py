#!/usr/bin/env python3
"""Independent full150-coefficient central/unimodular linear-space audit.

No Poisson helper modules are imported. Monomial-index assembly includes
all dependencies on the fifth variable; exact rational ranks bound the
entire homogeneous quadratic space, not a preselected ansatz.
"""
from itertools import combinations, combinations_with_replacement, product
from pathlib import Path
from collections import defaultdict
import json, sys
import sympy as s

HERE=Path(__file__).resolve().parent
N=5
PAIRS=list(combinations(range(N),2))
def mon(indices): return tuple(indices.count(i) for i in range(N))
MON2=[mon(list(a)) for a in combinations_with_replacement(range(N),2)]
BASIS=list(product(PAIRS,MON2))
XYZ=s.symbols('x y z w t')

def make_matrix(F):
    grad=[s.Poly(s.diff(F,x),*XYZ) for x in XYZ]
    rows=defaultdict(lambda:[0]*150)
    for col,((i,j),a) in enumerate(BASIS):
        for index,out,sign in [(i,j,1),(j,i,-1)]:
            for b,c in grad[index].terms():
                if c:
                    e=tuple(u+v for u,v in zip(a,b))
                    rows['central',out,e][col]+=sign*int(c)
            if a[index]:
                e=list(a);e[index]-=1
                rows['divergence',out,tuple(e)][col]+=sign*a[index]
    labels=sorted(rows)
    return s.Matrix([rows[label] for label in labels]),labels

def main():
    x,y,z,w,t=XYZ
    cases=[('nodal_plane_cubic',x**3+y**3+x*y*z,15),
           ('nonnormal_surface_1',x*x*z+y*y*w,13),
           ('nonnormal_surface_2',x*y*z+x*x*w+y**3,14),
           ('perazzo_threefold',x*x*z+x*y*w+y*y*t,13)]
    report={}
    for name,F,expected in cases:
        M,labels=make_matrix(F)
        R,pivots=M.rref()
        assert 150-len(pivots)==expected
        free=[j for j in range(150) if j not in pivots]
        K=s.zeros(150,len(free))
        for j,k in enumerate(free):
            K[k,j]=1
            for i,p in enumerate(pivots):K[p,j]=-R[i,k]
        assert M*K==s.zeros(M.rows,len(free))
        # A full-rank exact minor of the reconstructed matrix.
        _,rpivots=M[:,list(pivots)].T.rref()
        det=M.extract(rpivots,pivots).det(method='domain-ge')
        assert det!=0
        report[name]={'F':str(F),'matrix_shape':list(M.shape),
          'rank_over_Q':len(pivots),'kernel_dimension':len(free),
          'pivot_rows':list(rpivots),'pivot_columns':list(pivots),
          'minor_determinant':str(det),'kernel_equations_exact_zero':True,
          'kernel_basis':[[str(e) for e in K[:,j]] for j in range(K.cols)]}
        print(name,'full150_coefficient_kernel_dimension',len(free),flush=True)
    dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE
    dest.mkdir(parents=True,exist_ok=True)
    (dest/'cubic_central_spaces_independent_audit.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()

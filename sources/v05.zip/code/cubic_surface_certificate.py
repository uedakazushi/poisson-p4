#!/usr/bin/env python3
"""Exact certificate for the two nonnormal cubic-cone calculations.

Usage: python3 cubic_surface_certificate.py [OUTPUT_DIRECTORY]
Requires SymPy and sibling cubic_surface_models.py. No prior bundle imports.
All ranks, coefficient identities and minors are over Q. No sampling is used.
"""
from pathlib import Path
from itertools import combinations, combinations_with_replacement
import json, sys
import sympy as s
from cubic_surface_models import models, q, x, y, z, w, t

PAIRS=list(combinations(range(5),2))
MON2=[s.prod(q[i] for i in I) for I in combinations_with_replacement(range(5),2)]
A,B,C,D,E,F,G,H,I,J,R,U,V,K=s.symbols('A B C D E F G H I J R U V K')

def vec(P):
    return s.Matrix([s.Poly(P[i,j],*q).coeff_monomial(m) for i,j in PAIRS for m in MON2])

def rank_witness(M):
    _,cols=M.rref()
    _,rows=M[:,cols].T.rref()
    determinant=M.extract(rows,cols).det(method='domain-ge')
    assert determinant!=0 and len(rows)==len(cols)
    return {'rank':len(cols),'rows':list(rows),'columns':list(cols),
            'minor_determinant':str(determinant)}

def full_linear_matrix(cubic):
    row_data={}
    for col,(ij,mon) in enumerate((ij,m) for ij in PAIRS for m in MON2):
        i,j=ij
        entries=[('central',j,mon*s.diff(cubic,q[i])),
                 ('central',i,-mon*s.diff(cubic,q[j])),
                 ('divergence',j,s.diff(mon,q[i])),
                 ('divergence',i,-s.diff(mon,q[j]))]
        for typ,direction,polynomial in entries:
            for powers,value in s.Poly(polynomial,*q).terms():
                if value:
                    label=(typ,direction,powers)
                    row_data.setdefault(label,{})[col]=value
    labels=sorted(row_data)
    mat=s.zeros(len(labels),150)
    for row,label in enumerate(labels):
        for col,value in row_data[label].items(): mat[row,col]=value
    return mat,labels

def jacobian_matrix(cubic):
    bivectors=[]
    for k,l in PAIRS:
        P=s.zeros(5)
        for i,j in PAIRS:
            comp=tuple(n for n in range(5) if n not in (i,j))
            beta=0
            for r,n in enumerate(comp):
                rem=tuple(m for m in comp if m!=n)
                if rem==(k,l):beta+=(-1)**r*s.diff(cubic,q[n])
            P[i,j]=(-1)**(i+j-1)*beta;P[j,i]=-P[i,j]
        bivectors.append(P)
    return s.Matrix.hstack(*[vec(P) for P in bivectors])

def relations(kind):
    if kind==1:
        return [2*A*H-C*G+D*F,K*H,A*I-B*F+E*C-U*D/6,
                V*D+2*K*G/3,K*D,2*B*H-C*J+D*I,U*C-2*K*I,
                A*J-B*G+E*D-V*C/2,K*C,B*U,A*U+3*B*V+2*K*E,
                K*B,A*V,K*A]
    return [(B+K)*H+J*C/3-D*I,
            A*H+B*R+3*K*I+K*R-U*C+C*G/3-D*F/3,
            A*I-B*F/3+J*K-U*D-V*C/3-K*F/3+E*C/3,
            3*B*U+3*U*K-3*V*D-2*K*G,
            A*(3*I+R)-B*F+E*C,A*J-B*G+E*D,
            A*U+3*B*V+2*K*E,A*U+B*V+K*E,
            A*V,K*A,K*B,K*D]

def parameter_matrix(expressions,params):
    mon=[s.prod(params[i] for i in ij) for ij in combinations_with_replacement(range(len(params)),2)]
    return s.Matrix([[s.Poly(e,*params).coeff_monomial(m) for m in mon] for e in expressions])

def main(out):
    reports=[]
    for kind in (1,2):
        cubic,raw,P,raw_eq=models(kind)
        coeff_basis=s.Matrix.hstack(*[vec(P.diff(a)) for a in raw])
        full,labels=full_linear_matrix(cubic)
        assert full*coeff_basis==s.zeros(full.rows,len(raw))
        basis_rank=rank_witness(coeff_basis)
        full_rank=rank_witness(full)
        assert basis_rank['rank']==len(raw)==(13 if kind==1 else 14)
        assert full_rank['rank']==150-len(raw)
        raw_basis=[P.diff(a) for a in raw]
        jac=jacobian_matrix(cubic)
        assert jac.rank()==10
        jac_coordinates=coeff_basis.gauss_jordan_solve(jac)[0]
        assert coeff_basis*jac_coordinates==jac

        if kind==1:
            transformed=[A,B,E,C,D,F,G,H,I,J,U,V,K]
            params=(A,B,C,D,E,F,G,H,I,J,U,V,K)
            extra=[10,11,12]
            expected_jac=s.zeros(13,10)
            for row,col,val in [(0,9,2),(1,8,-2),(2,7,2),(3,6,2),
                               (4,3,-2),(5,5,-2),(6,2,2),(7,0,1),
                               (8,4,2),(9,1,-2)]: expected_jac[row,col]=val
        else:
            transformed=[A,B,E,C,D,F,G,H,I,3*I+R,J,U,V,K]
            params=(A,B,C,D,E,F,G,H,I,J,R,U,V,K)
            extra=[9,11,12,13]
            expected_jac=s.zeros(14,10)
            for row,col,val in [(0,9,1),(1,8,-1),(2,7,1),(3,3,-3),
                               (4,6,1),(5,2,3),(6,5,-1),(7,0,1),
                               (8,1,-1),(9,1,-3),(10,4,1)]: expected_jac[row,col]=val
        assert jac_coordinates==expected_jac
        T=P.subs(dict(zip(raw,transformed)),simultaneous=True)
        original=[s.expand(e.subs(dict(zip(raw,transformed)),simultaneous=True)) for e in raw_eq]
        claimed=relations(kind)
        original_rows=parameter_matrix(original,params)
        claimed_rows=parameter_matrix(claimed,params)
        rank_original=original_rows.rank();rank_claimed=claimed_rows.rank()
        assert rank_original==rank_claimed==original_rows.col_join(claimed_rows).rank()
        assert rank_claimed==(14 if kind==1 else 12)

        # Verify exact row factors used in the contradiction branches.
        # Logical implications from the relation list are in the theorem.
        if kind==1:
            Pk=T.subs({A:0,B:0,C:0,D:0,E:0,G:0,H:0,I:0})
            assert all(s.expand(Pk[0,j]).subs(x,0)==0 for j in range(5))
            assert s.expand(Pk[0,1]-K*x*y/2)==0
            Pzero=T.subs({A:0,B:0,C:0,D:0,K:0})
            assert Pzero[:4,:4]==s.zeros(4)
            branch_checks=['K_nonzero_x_row_divisible_by_x',
                           'U_or_V_nonzero_forces_zero_four_variable_block']
        else:
            Pk=T.subs({A:0,B:0,D:0,E:0})
            assert all(s.expand(Pk[0,j]).subs(x,0)==0 for j in range(5))
            assert s.expand(Pk[0,1]-K*x*x)==0
            Pzero=T.subs({A:0,B:0,C:0,D:0,K:0})
            assert Pzero[:4,:4]==s.zeros(4)
            Pu=T.subs({A:0,B:0,D:0,E:0,J:0,K:0,V:0,G:3*U})
            assert all(s.expand(Pu[1,j]).subs(x,0)==0 for j in range(5))
            assert s.expand(Pu[1,2]-C*x*x/3)==0
            eqr=[s.expand(e.subs({K:0,U:0,V:0})) for e in claimed]
            assert s.expand(eqr[4]-3*eqr[2]-A*R)==0
            eqr0=[s.expand(e.subs(A,0)) for e in eqr]
            assert s.expand(3*B*eqr0[1]+C*eqr0[5]-D*eqr0[4]-3*B*B*R)==0
            Pr=T.subs({A:0,B:0,D:0,E:0,G:0,J:0,K:0,U:0,V:0})
            assert all(s.expand(Pr[1,j]).subs(x,0)==0 for j in range(5))
            assert s.expand(Pr[1,2]-C*x*x/3)==0
            branch_checks=['K_nonzero_x_row_divisible_by_x',
                           'V_nonzero_forces_zero_four_variable_block',
                           'U_nonzero_y_row_divisible_by_x',
                           'R_branch_AR_and_3B_squared_R_identities',
                           'R_nonzero_y_row_divisible_by_x_after_x_centrality']
        reports.append({
            'kind':kind,'cubic':str(cubic),
            'full_linear_matrix_shape':list(full.shape),
            'full_linear_matrix_rank_witness':full_rank,
            'full_linear_row_labels':[[typ,direction,list(powers)] for typ,direction,powers in labels],
            'basis_rank_witness':basis_rank,'central_unimodular_dimension':len(raw),
            'raw_basis':[{str(ij):str(Pb[ij[0],ij[1]]) for ij in PAIRS if Pb[ij[0],ij[1]]!=0}
                         for Pb in raw_basis],
            'raw_parameter_substitution':[str(p) for p in transformed],
            'constant_two_form_pair_order':[list(ij) for ij in PAIRS],
            'jacobian_coordinates_in_raw_basis':[[str(v) for v in row] for row in jac_coordinates.tolist()],
            'extra_raw_basis_indices':extra,
            'pluecker_equations':[str(s.expand(e)) for e in claimed],
            'pluecker_coefficient_row_space_rank':rank_claimed,
            'pluecker_coefficient_row_space_equality_verified':True,
            'branch_identity_checks':branch_checks,
            'all_checks_passed':True,
        })
    out.mkdir(parents=True,exist_ok=True)
    target=out/'cubic_surface_certificate.json'
    target.write_text(json.dumps({'coordinate_order':[str(v) for v in q],
                                 'computational_domain':'QQ, exact',
                                 'all_checks_passed':True,'cases':reports},indent=2)+'\n')
    print(json.dumps({'all_checks_passed':True,
                      'central_unimodular_dimensions':[13,14],
                      'full_linear_ranks':[137,136],
                      'pluecker_relation_space_dimensions':[14,12],
                      'output':str(target)},indent=2),flush=True)

if __name__=='__main__':
    main(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent)

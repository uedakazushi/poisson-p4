#!/usr/bin/env python3
"""Reduced-support stratification of the minimal-nilpotent fixed-trace fiber.

This certifies three components of the reduced fixed fiber, and subsequently
certifies that the two affine9 planes saturate to distinct dimension13
components of the full compatible quadratic locus. No P4 count is inferred.
"""
from pathlib import Path
from fractions import Fraction as F
import json,sys
import sympy as sp
import certify_regular_nilpotent as c

HERE=Path(__file__).resolve().parent

def main():
    ans=c.m.fixed_trace({(2,0,0,0):F(1,2)})
    Q,t,eq=c.tensor(ans)
    assert len(t)==15 and len(eq)==15 and ans['linear_rank']==45
    # Indices are fixed by the explicit monomial basis, recorded in the output.
    assert sp.expand(eq[13]-t[12]**2)==0
    assert sp.expand(eq[9]-t[14]**2)==0
    assert sp.expand(2*t[13]*eq[7]-2*t[14]*eq[6]-t[13]**3)==0
    reduced_subs={t[12]:0,t[13]:0,t[14]:0}
    ee=[sp.expand(g) for e in eq if (g:=e.subs(reduced_subs))!=0]
    a,b,cc=t[10],t[11],t[9]
    expected=[
      -12*cc*b-2*a*t[1]-2*b*t[5]+b,
      (5*a*b-2*a*t[8]+b*t[7])/3,
      2*(a*t[2]+3*b*b+b*t[8])/3,
      -8*cc*a+2*a*t[5]+a-2*b*t[4],
      (5*a*a-a*t[7]+2*b*t[6])/3,
      -(4*t[0]*a+12*cc*cc-3*cc+4*b*t[3])/3,
    ]
    assert len(ee)==6
    assert all(sp.expand(u-v)==0 for u,v in zip(ee,expected))
    # On a != 0 and b != 0 respectively, the following six dependent
    # coordinates give invertible coefficient matrices, proving exact affine
    # 3-space charts over the base (a,b,c) and consistency of the linear system.
    M=sp.Matrix(ee).jacobian(t[:9])
    cols_a=[1,8,2,5,7,0]
    cols_b=[5,7,8,4,6,3]
    da=sp.factor(M[:,cols_a].det());db=sp.factor(M[:,cols_b].det())
    assert sp.factor(da/a**6).is_Rational
    assert sp.factor(db/b**6).is_Rational
    assert da and db
    # Explicit solve/substitute on both charts provides a second finite check.
    charts={}
    for name,cols,det in [('a_nonzero',cols_a,da),('b_nonzero',cols_b,db)]:
        deps=[t[i] for i in cols]
        mat=M[:,cols]
        constants=sp.Matrix(ee).subs({v:0 for v in deps})
        solution=mat.inv()*(-constants)
        sub=dict(zip(deps,solution))
        assert all(sp.cancel(e.subs(sub,simultaneous=True))==0 for e in ee)
        charts[name]={'dependent_variables':[str(v) for v in deps],
                     'free_variables':[str(v) for v in t[:9] if v not in deps],
                     'determinant':str(det),
                     'solution':{str(v):str(sp.factor(f)) for v,f in sub.items()}}
    boundary=[sp.factor(e.subs({a:0,b:0})) for e in ee]
    assert boundary[:-1]==[0]*5
    assert boundary[-1]==-cc*(4*cc-1)
    # Both affine9 planes satisfy the original, unreduced Jacobi equations.
    for value in [sp.Rational(0),sp.Rational(1,4)]:
        sub={**reduced_subs,a:0,b:0,cc:value}
        assert all(sp.expand(e.subs(sub))==0 for e in eq)
    # Full45 tangent certification at one rational point of each affine9
    # component, together with all nine actual family directions. Multiplying
    # by4 merely clears denominators; the trace remains in the same nonzero
    # minimal nilpotent orbit.
    sats={}
    for label,value in [('rank2',sp.Rational(0)),('rank4',sp.Rational(1,4))]:
        plane=(4*Q.subs({**reduced_subs,a:0,b:0,cc:value})).applyfunc(sp.expand)
        point=plane.subs({t[i]:i+1 for i in range(9)})
        qs=c.sparse(point,1)
        qc=c.quadratic_certificate(point)
        hams=[c.hamiltonian({mon:1}) for mon in c.p.DEGREE_TWO if mon[0]==0]
        orbit=[];traces=[]
        for X in hams:
            A=c.np.zeros((5,5),dtype=c.np.int64)
            for i,poly in enumerate(X):
                for mon,v in poly.items():A[i,mon.index(1)]=v
            deriv=c.v.linear_action_derivative(qs,A)
            orbit.append(c.p.bivector_vector(deriv))
            tr={mon:deriv.get((1,2),{}).get(mon,0)+deriv.get((3,4),{}).get(mon,0)
                for mon in c.p.DEGREE_TWO}
            traces.append([tr[mon] for mon in c.p.DEGREE_TWO])
            assert all(not e for e in c.polar(qs,deriv).values())
        actual=[c.sparse(plane.diff(t[i]),1) for i in range(9)]
        assert all(all(not e for e in c.polar(qs,R).values()) for R in actual)
        family=c.np.column_stack(orbit+[c.p.bivector_vector(R) for R in actual])
        fr,fc=c.rank_cert(family)
        trace_rank=c.rank(c.np.column_stack(traces))
        assert qc['tangent_dimension']==13 and fr==13 and trace_rank==4
        pf=sp.factor(plane[0,1]*plane[2,3]-plane[0,2]*plane[1,3]+plane[0,3]*plane[1,2])
        assert pf==(0 if value==0 else c.x1**4)
        sats[label]={'fixed_plane_t10':str(value),'point_t1_through_t9':list(range(1,10)),
          'scale_for_integer_coefficients':4,
          'point_brackets':{''.join(str(i+1) for i in I):str(point[I]) for I in c.m.old.PAIRS},
          'quadratic_tangent_certificate':qc,'trace_orbit_derivative_rank':trace_rank,
          'actual_Sp4_plus_nine_plane_directions_rank':fr,'actual_family_minor':fc,
          'actual_family_directions_annihilated_by_Jacobi_derivative':True,
          'universal_scaled_plane_Pfaffian':str(pf),'full_quadratic_component_dimension':13}
    out={
      'trace':'x1^2/2','nilpotent_partition':[2,1,1],
      'fixed_trace_linear_rank':ans['linear_rank'],'parameter_count':len(t),
      'free_coefficient_basis':ans['free_basis'],
      'normal_form_brackets':{''.join(str(i+1) for i in I):str(Q[I]) for I in c.m.old.PAIRS},
      'original_Jacobi_generators':[str(sp.factor(e)) for e in eq],
      'verified_nilpotence_memberships':['t13^2 = eq[13]','t15^2 = eq[9]','t14^3 = 2*t14*eq[7]-2*t15*eq[6]'],
      'reduced_support_linear_constraints':['t13=0','t14=0','t15=0'],
      'remaining_six_equations':[str(sp.factor(e)) for e in ee],
      'base_coordinates':{'a':'t11','b':'t12','c':'t10'},
      'open_stratum':'(a,b) != (0,0), affine3 bundle over (A2 minus {0}) times A1',
      'open_dimension':6,'exact_charts':charts,
      'closed_stratum':'a=b=0, c=0 or1/4; each is affine9 in t1,...,t9',
      'reduced_fixed_fiber_irreducible_component_dimensions':[9,9,6],
      'irreducible_components':['a=b=c=t13=t14=t15=0',
                                'a=b=t13=t14=t15=0, c=1/4',
                                'closure of (a,b)!=(0,0) in the six-equation reduced support'],
      'reason_no_missing_components':'The complement of the irreducible open stratum is exactly the two affine9 planes. Neither plane can lie in the dimension6 closure, and the open closure is not contained in the planes.',
      'saturations':sats,
      'centralizer_preserves_each_affine9_component':'An automorphism preserves component dimension; the two dimension9 components have respectively generic rank2 and rank4, so they cannot be permuted.',
      'full_quadratic_new_components':2,
      'full_quadratic_dimension_argument':'Minimal nilpotent trace orbit dimension4 plus fixed fiber dimension9 gives saturation dimension13; the exact family derivative and full tangent dimension both equal13 at each sample.',
      'full_quadratic_distinction':'The two components differ by generic rank2 versus4; both have dimension13, larger than the preceding ten components of dimension10/11 and the regular-nilpotent component of dimension9.',
      'P4_component_count_change':0,
      'claim_scope':'Reduced fixed-trace fiber classification plus two certified full45 dimension13 components; no P4 component assertion, full centralizer-orbit classification, or reducedness of the entire original fixed scheme.',
    }
    dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE
    dest.mkdir(parents=True,exist_ok=True)
    (dest/'minimal_nilpotent_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'fixed_trace_linear_parameters':15,'nilpotent_coordinates':['t13','t14','t15'],
      'open_linear_minors':[str(da),str(db)],'reduced_fixed_fiber_component_dimensions':[9,9,6],
      'new_full_quadratic_component_dimensions':[13,13],
      'P4_component_count_change':0},indent=2))

if __name__=='__main__':main()

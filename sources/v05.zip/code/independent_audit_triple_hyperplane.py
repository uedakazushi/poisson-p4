#!/usr/bin/env python3
"""Independent 350x150 projective Jacobi/orbit audit of the new component.

No import from any previous Poisson or rank calculation. Polynomial operations,
Schouten linearization and orbit columns are reconstructed here; ranks over QQ
are computed by SymPy. Only exact integers and rationals are used.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from collections import defaultdict
import json,argparse
import sympy as sp
HERE=Path(__file__).resolve().parent
PAIRS=list(combinations(range(5),2));TRIPLES=list(combinations(range(5),3));QUADS=list(combinations(range(5),4))

def mon(*ii):return tuple(ii.count(k) for k in range(5))
MON2=[mon(*ii) for ii in combinations_with_replacement(range(5),2)]
MON4=[mon(*ii) for ii in combinations_with_replacement(range(5),4)]
XBASIS=[(I,m) for I in PAIRS for m in MON2]
YBASIS=[(I,m) for I in QUADS for m in MON4]

def add(*polys):
    out=defaultdict(int)
    for pol in polys:
        for m,c in pol.items():out[m]+=c
    return {m:c for m,c in out.items() if c}
def scale(p,c):return {m:c*v for m,v in p.items() if c*v}
def mul(p,q):
    out=defaultdict(int)
    for m,c in p.items():
        for n,d in q.items():out[tuple(a+b for a,b in zip(m,n))]+=c*d
    return {m:c for m,c in out.items() if c}
def dx(p,i):
    out={}
    for m,c in p.items():
        if m[i]:
            n=list(m);n[i]-=1;out[tuple(n)]=c*m[i]
    return out
def ent(P,i,j):
    if i==j:return {}
    return P.get((i,j),{}) if i<j else scale(P.get((j,i),{}),-1)
def jac(P,R=None):
    out={}
    for i,j,k in TRIPLES:
        terms=[]
        for a,b,c in [(i,j,k),(j,k,i),(k,i,j)]:
            for h in range(5):
                terms.append(mul(ent(P,a,h),dx(ent(P if R is None else R,b,c),h)))
                if R is not None:terms.append(mul(ent(R,a,h),dx(ent(P,b,c),h)))
        out[i,j,k]=add(*terms)
    return out
def e_wedge(T):
    return {I:add(*(scale(mul({mon(i):1},T.get(tuple(j for j in I if j!=i),{})),(-1)**k)
                    for k,i in enumerate(I))) for I in QUADS}
def vector(P):return [P.get(I,{}).get(m,0) for I,m in XBASIS]
def action(P,a,b):
    out={}
    for i,j in PAIRS:
        out[i,j]=add(mul({mon(b):1},dx(ent(P,i,j),a)),
                     scale(ent(P,b,j),-int(i==a)),
                     scale(ent(P,i,b),-int(j==a)))
    return out
def vertical(a,b):
    return {(i,j):add({mon(i,b):1} if j==a else {},{mon(j,b):-1} if i==a else {}) for i,j in PAIRS}

def main(output_dir=HERE):
    output_dir=Path(output_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    P={
     (1,2):{mon(0,0):1,mon(1,4):3},
     (1,3):{mon(1,1):-3},
     (1,4):{mon(1,3):3},
     (2,3):{mon(1,2):3,mon(3,4):-1},
     (2,4):{mon(2,3):-3,mon(4,4):1},
     (3,4):{mon(0,0):1,mon(1,4):-1,mon(3,3):1}}
    assert not any(jac(P).values())
    pf=add(mul(ent(P,1,2),ent(P,3,4)),scale(mul(ent(P,1,3),ent(P,2,4)),-1),mul(ent(P,1,4),ent(P,2,3)))
    q={mon(0,0):1,mon(1,4):2,mon(3,3):1}
    assert pf==mul({mon(0,0):1},q)
    qmatrix=sp.zeros(5)
    for a in range(5):
        for b in range(5):
            qmatrix[a,b]=q.get(mon(a,b),0)/(sp.Integer(1) if a==b else sp.Integer(2))
    assert qmatrix.rank()==4
    cols=[]
    for I,m in XBASIS:
        T=e_wedge(jac(P,{I:{m:1}}))
        cols.append([T.get(K,{}).get(n,0) for K,n in YBASIS])
    J=sp.Matrix.hstack(*(sp.Matrix(c) for c in cols))
    V=sp.Matrix.hstack(*(sp.Matrix(vector(vertical(a,b))) for a in range(5) for b in range(5)))
    O=sp.Matrix.hstack(*(sp.Matrix(vector(action(P,a,b))) for a in range(5) for b in range(5)))
    M=sp.Matrix.hstack(V,O,sp.Matrix(vector(P)))
    assert J*M==sp.zeros(J.rows,M.cols)
    rJ=J.rank();rV=V.rank();rM=M.rank()
    assert (rJ,rV,rM)==(103,24,47)
    # The compact Aff(4,1) formula and canonical lift identities.
    H=[{}, {mon(1):3},{mon(2):-3},{mon(3):1},{mon(4):-1}]
    N=[{},{},{mon(4):1},{mon(1):-1},{mon(3):1}]
    Q={(i,j):add(mul(H[i],N[j]),scale(mul(H[j],N[i]),-1)) for i,j in PAIRS}
    compare={I:add(P.get(I,{}),scale(Q.get(I,{}),-1)) for I in PAIRS}
    assert {I:pol for I,pol in compare.items() if pol}=={(1,2):{mon(0,0):1},(3,4):{mon(0,0):1}}
    divergence=[add(*(dx(ent(P,i,j),i) for i in range(5))) for j in range(5)]
    assert divergence==[scale(pol,2) for pol in N]
    # First-index contraction convention P#df=sum_ij Pij f_i partial_j.
    sharpq=[add(*(mul(ent(P,i,j),dx(q,i)) for i in range(5))) for j in range(5)]
    assert sharpq==[scale(mul(q,pol),2) for pol in N]
    report={'audit':'Independent polynomial dictionary implementation; no prior Poisson/rank helper imports',
      'affine_Jacobi_zero':True,'full_Jacobi_matrix_shape':[J.rows,J.cols],
      'rank_full_Jacobi_over_Q':rJ,'rank_vertical_over_Q':rV,
      'rank_vertical_orbit_scale_over_Q':rM,'J_times_M_zero':True,
      'projective_tangent_dimension':125-rJ,'projective_orbit_dimension':rM-25,
      'Pfaffian':'x0^2*(x0^2+2*x1*x4+x3^2)',
      'projective_degeneracy':'x0^3*(x0^2+2*x1*x4+x3^2)',
      'quadric_rank':4,'compact_Aff41_formula_verified':True,'divergence':'2N',
      'canonical_lift':'Pi=P-(2/5)E wedge N',
      'canonical_Darboux_cofactors':{'x0':'-(2/5)N','q':'(6/5)N'},
      'new_full_component_dimension':22,
      'distinction':'Rank 4 excludes the six rank-2 components; the closed quintic locus L^3G excludes the 40 SNC components and the v3 H+2(smooth Q) component.'}
    (output_dir/'independent_triple_hyperplane_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=HERE)
    main(parser.parse_args().output_dir)

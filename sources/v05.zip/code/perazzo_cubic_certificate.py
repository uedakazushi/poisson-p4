#!/usr/bin/env python3
"""Exact Perazzo certificate. Usage: python3 perazzo_cubic_certificate.py [OUTDIR].

Requires sibling cubic_surface_certificate.py, cubic_surface_models.py, and
SymPy. All polynomial and matrix computations are over Q.
"""
from pathlib import Path
from itertools import combinations
import json, sys
import sympy as s
from cubic_surface_certificate import (q,x,y,z,w,t,PAIRS,MON2,vec,
    full_linear_matrix,rank_witness,jacobian_matrix,parameter_matrix)

def main(out):
    cubic=x*x*z+x*y*w+y*y*t
    mat,labels=full_linear_matrix(cubic)
    rank=rank_witness(mat)
    assert rank['rank']==137
    null=mat.nullspace();assert len(null)==13
    N=s.Matrix.hstack(*null)
    assert mat*N==s.zeros(mat.rows,13)
    basis=[]
    for col in null:
        P=s.zeros(5)
        for k,(i,j) in enumerate(PAIRS):
            P[i,j]=sum(col[15*k+l]*MON2[l] for l in range(15))
            P[j,i]=-P[i,j]
        basis.append(P)
    a=s.symbols('a0:13');u,v,r=a[10:]
    P=sum((ak*b for ak,b in zip(a,basis)),s.zeros(5))
    jac=jacobian_matrix(cubic)
    assert jac.rank()==10
    jac_coords=N.gauss_jordan_solve(jac)[0]
    assert jac_coords[10:,:]==s.zeros(3,10)
    assert jac_coords[:10,:].rank()==10

    eq=[];raw_pf=[]
    for i,j,k,l in combinations(range(5),4):
        pf=s.expand(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])
        raw_pf.append(pf)
        for e in s.Poly(pf,*q).coeffs():
            e=s.Poly(e,*a).monic().as_expr() if e!=0 else 0
            if e!=0 and e not in eq:eq.append(e)
    assert len(eq)==17
    essential=[u*(3*u+2*a[2]),a[1]*u+2*u*v+v*a[2],
               6*a[0]*u-2*a[1]*v-2*u*r+v*v-3*r*a[2],
               2*a[0]*u-2*a[1]*v-r*a[2],
               2*a[0]*v-a[1]*r-v*r,r*(4*a[0]-r)]
    rows=parameter_matrix(eq,a);erows=parameter_matrix(essential,a)
    rank_eq=rows.rank()
    assert rows.col_join(erows).rank()==rank_eq
    combinations_essential=rows.T.gauss_jordan_solve(erows.T)[0]
    # Set free symbols in the row representation to zero, retaining identities.
    fresh=set().union(*(e.free_symbols for e in combinations_essential))-set(a)
    combinations_essential=combinations_essential.subs({f:0 for f in fresh})
    assert rows.T*combinations_essential==erows.T

    h=s.symbols('h')
    shear=s.Matrix([[1,0,0,0,0],[h,1,0,0,0],[0,0,1,-h,h*h],
                    [0,0,0,1,-2*h],[0,0,0,0,1]])
    swap=s.Matrix([[0,1,0,0,0],[1,0,0,0,0],[0,0,0,0,1],
                   [0,0,0,1,0],[0,0,1,0,0]])
    action_reports={}
    for name,T,expected in [
        ('shear',shear,s.Matrix([[1,0,0],[-2*h,1,0],[-2*h*h,2*h,1]])),
        ('swap',swap,s.Matrix([[0,0,s.Rational(1,2)],[0,-1,0],[2,0,0]]))]:
        assert T.det()==1
        subs=dict(zip(q,T.inv()*s.Matrix(q)))
        assert s.expand(cubic.subs(subs,simultaneous=True)-cubic)==0
        transformed=[]
        for B in basis:
            pushed=T*B.subs(subs,simultaneous=True)*T.T
            coords=N.gauss_jordan_solve(vec(pushed))[0]
            transformed.append(coords)
        action=s.Matrix.hstack(*transformed)
        assert action[10:,:10]==s.zeros(3,10)
        assert action[10:,10:]==expected
        action_reports[name]={'coordinate_matrix':[[str(e) for e in row] for row in T.tolist()],
                              'full_parameter_action':[[str(e) for e in row] for row in action.tolist()],
                              'extra_quotient_action':[[str(e) for e in row] for row in expected.tolist()]}

    # Exact identities implementing the u != 0 reduction.
    sol={a[2]:-3*u/2,a[1]:-v/2,a[0]:-v*v/(2*u)-3*r/4}
    assert s.cancel(essential[0].subs(sol))==0
    assert s.cancel(essential[1].subs(sol))==0
    assert s.cancel(essential[3].subs(sol))==0
    assert s.cancel(essential[2].subs(sol)+v*v+2*u*r)==0
    new=s.Matrix([u,v-2*h*u,r+2*h*v-2*h*h*u])
    normalized=new.subs(h,v/(2*u)).applyfunc(s.factor)
    assert normalized[0]==u and normalized[1]==0
    assert s.cancel(normalized[2]-(v*v+2*u*r)/(2*u))==0

    basic={a[0]:0,a[1]:0,a[2]:-3*u/2,v:0,r:0}
    reduced=[s.expand(e.subs(basic)) for e in eq]
    targets=[u*a[6]/4,-u*a[4]/2,u*(a[5]+a[9]/6),u*a[6]/2-3*u*a[3]/2]
    indices=[2,3,6,7]
    for i,target in zip(indices,targets):assert s.expand(reduced[i]-target)==0
    branch={**basic,a[6]:0,a[4]:0,a[9]:-6*a[5],a[3]:0}
    normalized_P=P.subs(branch,simultaneous=True).applyfunc(s.expand)
    expected_row=[3*u*y*y/2,0,0,-3*a[5]*y*y-3*u*y*z,
                  3*a[5]*x*y-3*u*w*y/2]
    assert all(s.expand(normalized_P[1,j]-expected_row[j])==0 for j in range(5))
    assert all(s.expand(normalized_P[1,j]).subs(y,0)==0 for j in range(5))

    # The five partial derivatives are independent constants-linearly.
    grad=[s.diff(cubic,zj) for zj in q]
    grad_mat=s.Matrix([[s.Poly(g,*q).coeff_monomial(m) for g in grad] for m in MON2])
    assert grad_mat.rank()==5
    report={'all_checks_passed':True,'coordinate_order':[str(e) for e in q],
            'cubic':str(cubic),'full_linear_matrix_shape':list(mat.shape),
            'full_linear_rank_witness':rank,'central_unimodular_dimension':13,
            'basis':[{str(ij):str(B[ij[0],ij[1]]) for ij in PAIRS if B[ij[0],ij[1]]!=0}
                     for B in basis],
            'jacobian_coordinates':[[str(e) for e in row] for row in jac_coords.tolist()],
            'pluecker_coefficients':[str(e) for e in eq],
            'pluecker_coefficient_row_rank':rank_eq,
            'six_essential_equations':[str(e) for e in essential],
            'essential_equation_row_combinations':[[str(e) for e in row] for row in combinations_essential.tolist()],
            'verified_group_actions':action_reports,
            'normalized_branch_coefficient_indices':indices,
            'normalized_branch_coefficient_expressions':[str(e) for e in targets],
            'normalized_y_row':[str(e) for e in expected_row],
            'gradient_linear_rank':5,
            'scope':'Exact supporting identities for perazzo_cubic_theorem.txt; no numeric samples.'}
    out.mkdir(parents=True,exist_ok=True)
    target=out/'perazzo_cubic_certificate.json'
    target.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'all_checks_passed':True,'full_linear_rank':137,
                      'central_unimodular_dimension':13,
                      'group_actions_verified':['shear','swap'],
                      'normalized_y_row_divisible_by_y':True,
                      'gradient_linear_rank':5,'output':str(target)},indent=2),flush=True)

if __name__=='__main__':
    main(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent)

#!/usr/bin/env python3
"""Exact certificates for the regular-nilpotent modular stratum on A4/P4.

Uses rational coefficient identities, rational RREF, and independent modular
nonzero-minor witnesses.  The original 60-coefficient fixed-trace system is
rebuilt on every run; no numerical fitting or stored tangent rank is used.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from itertools import combinations
import sys,json
import sympy as sp
import numpy as np

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'p4_poisson_completeness_v4'/'previous_v3'/'code'
if not BASE.is_dir(): BASE=HERE.parent/'previous_v4'/'previous_v3'/'code'
MIX=HERE.parent/'p4_v5_mixed_work'
if not MIX.is_dir(): MIX=HERE.parent/'mixed'
if not MIX.is_dir(): MIX=HERE
sys.path[:0]=[str(BASE),str(MIX)]
import mixed_modular as m
import poisson_p4_components_check as p
import verify_rank2_components as v
from build_universal_slice import rref
from verify_quadratic_rmap import hamiltonian

x0,x1,x2,x3,x4=sp.symbols('x0 x1 x2 x3 x4')
xx=sp.Matrix([x1,x2,x3,x4]); xx5=sp.Matrix([x0,x1,x2,x3,x4])
J=sp.zeros(4);J[0,1]=J[2,3]=1;J[1,0]=J[3,2]=-1

def wedge(A,B): return A*B.T-B*A.T
def lie(X,Q,coords):
    D=X.jacobian(coords)
    return (Q.applyfunc(lambda f:sum(X[i]*sp.diff(f,z) for i,z in enumerate(coords)))-D*Q-Q*D.T).applyfunc(sp.expand)
def bracket(X,Y,coords): return Y.jacobian(coords)*X-X.jacobian(coords)*Y
def push(Q,G,scale=1):
    ss=dict(zip(xx,G.inv()*xx))
    return (scale*G*Q.applyfunc(lambda f:f.subs(ss,simultaneous=True))*G.T).applyfunc(sp.expand)
def jac(Q,coords):
    return [sp.expand(sum(Q[i,l]*sp.diff(Q[j,k],coords[l])+Q[j,l]*sp.diff(Q[k,i],coords[l])+Q[k,l]*sp.diff(Q[i,j],coords[l]) for l in range(len(coords)))) for i,j,k in combinations(range(len(coords)),3)]
def polar(Q,R):
    S={I:defaultdict(int,q) for I,q in Q.items()}
    for I,q in R.items():p.add_polynomial(S.setdefault(I,defaultdict(int)),q)
    jq=p.affine_jacobi_coefficients(Q);jr=p.affine_jacobi_coefficients(R)
    out=p.affine_jacobi_coefficients(S)
    for I,q in out.items():
        q=defaultdict(int,q);p.add_polynomial(q,jq[I],-1);p.add_polynomial(q,jr[I],-1)
        out[I]={mon:c for mon,c in q.items() if c}
    return out
def sparse(Q,offset=0):
    out={}
    coords=xx if Q.rows==4 else xx5
    for i,j in combinations(range(Q.rows),2):
        q={}
        for mon,c in sp.Poly(Q[i,j],*coords).terms():
            if c:
                assert c.q==1
                q[((0,)+mon) if Q.rows==4 else mon]=int(c)
        if q:out[i+offset,j+offset]=q
    return out
def tensor(ans):
    ts=sp.symbols('t1:'+str(ans['free_count']+1));Q=sp.zeros(4)
    for (i,j),q in ans['Q'].items():
        for mon,pol in q.items():
            coeff=sum(sp.Rational(c.numerator,c.denominator)*sp.prod(ts[k] for k in im) for im,c in pol.items())
            Q[i,j]+=coeff*sp.prod(z**k for z,k in zip(xx,mon))
        Q[i,j]=sp.expand(Q[i,j]);Q[j,i]=-Q[i,j]
    eq=[sum(sp.Rational(c.numerator,c.denominator)*sp.prod(ts[k] for k in im) for im,c in pol.items()) for pol in ans['row_reduced_equations']]
    return Q,ts,eq
def rank(M):return len(rref(np.asarray(M).tolist())[1])
def rank_cert(M):
    ans=p.modular_rank_certificate(np.asarray(M,dtype=np.int64))
    n=rank(M);assert n==ans['rank_mod_prime'];return n,ans
def quadratic_certificate(Q):
    qs=sparse(Q,1)
    hams=[hamiltonian({mon:1}) for mon in p.DEGREE_TWO if mon[0]==0]
    basis=[v.wedge_fields(A,B) for A,B in combinations(hams,2)]
    assert rank(np.column_stack([p.bivector_vector(R) for R in basis]))==45
    target=[(I,mon) for I in combinations(range(1,5),3) for mon in p.homogeneous_monomials(3) if mon[0]==0]
    cols=[polar(qs,R) for R in basis]
    D=np.array([[col.get(I,{}).get(mon,0) for col in cols] for I,mon in target],dtype=np.int64)
    dr,dc=rank_cert(D)
    orbit=[]
    for X in hams:
        A=np.zeros((5,5),dtype=np.int64)
        for i,poly in enumerate(X):
            for mon,c in poly.items():A[i,mon.index(1)]=c
        orbit.append(p.bivector_vector(v.linear_action_derivative(qs,A)))
    O=np.column_stack(orbit);orr,oc=rank_cert(O)
    return {'Jacobi_derivative_rank_over_Q':dr,'tangent_dimension':45-dr,
            'Sp4_orbit_dimension':orr,'Jacobi_minor':dc,'orbit_minor':oc}

def main():
    s=x1*x4+x3**2/2
    ans=m.fixed_trace({(1,0,0,1):F(1),(0,0,2,0):F(1,2)})
    Q,ts,eq=tensor(ans)
    assert ans['free_count']==5 and ans['linear_rank']==55
    t1,t2,t3,t4,t5=ts
    expected=[t1,t3,t4,(2*t5-1)*(4*t5-1)]
    G=sp.groebner(eq,*ts,order='lex',domain=sp.QQ)
    GG=sp.groebner(expected,*ts,order='lex',domain=sp.QQ)
    assert all(G.reduce(f)[1]==0 for f in expected)
    assert all(GG.reduce(f)[1]==0 for f in eq)
    # These two primitive idempotents prove reduced product decomposition.
    ids=[2-4*t5,4*t5-1]
    assert G.reduce(sum(ids)-1)[1]==0
    assert G.reduce(ids[0]*ids[1])[1]==0
    assert all(G.reduce(f*f-f)[1]==0 for f in ids)
    A=Q.subs({t1:0,t3:0,t4:0,t5:sp.Rational(1,4)}).applyfunc(sp.expand)
    B=Q.subs({t1:0,t3:0,t4:0,t5:sp.Rational(1,2)}).applyfunc(sp.expand)
    Y=sp.Matrix([0,x1,0,0])
    assert lie(Y,A,xx)==sp.Rational(3,2)*A.diff(t2)
    assert lie(Y,B,xx)==-3*B.diff(t2)
    assert lie(Y,A.diff(t2),xx)==sp.zeros(4)
    assert lie(Y,B.diff(t2),xx)==sp.zeros(4)
    N=sp.Matrix([0,x4,-x1,x3]);H=sp.Matrix([3*x1,-3*x2,x3,-x4])
    assert lie(N,Q,xx)==sp.zeros(4)
    assert bracket(H,N,xx)==2*N
    assert lie(H,J,xx)==lie(N,J,xx)==sp.zeros(4)
    assert N.jacobian(xx).rank()==3
    assert (N.jacobian(xx)**2).rank()==2
    assert (N.jacobian(xx)**3).rank()==1
    assert N.jacobian(xx)**4==sp.zeros(4)
    Qnew=2*B.subs(t2,0)
    assert Qnew==wedge(H,N)
    # The other branch is the highest-weight vector of a linear Poisson
    # pencil/module whose regular semisimple points lie in the known T4 orbit.
    Fminus=sp.Matrix([-3*x3,0,4*x4,3*x2])
    assert bracket(N,Fminus,xx)==H
    assert bracket(H,Fminus,xx)==-2*Fminus
    A0=A.subs(t2,0)
    AH=-lie(Fminus,A0,xx)
    AF=-lie(Fminus,lie(Fminus,A0,xx),xx)/2
    assert lie(H,A0,xx)==2*A0
    assert lie(N,A0,xx)==sp.zeros(4)
    assert lie(Fminus,AF,xx)==sp.zeros(4)
    assert lie(N,AH,xx)==-2*A0
    assert lie(N,AF,xx)==AH
    assert lie(H,AH,xx)==sp.zeros(4)
    assert lie(H,AF,xx)==-2*AF
    nn,hh,ff,zz=sp.symbols('n h f z')
    module=nn*A0+hh*AH+ff*AF
    assert jac(module,xx)==[0]*4
    assert jac(module+J,xx)==[0]*4
    smodule=sp.expand(module[0,1]+module[2,3])
    assert sp.expand(smodule-(nn*(x1*x4+x3*x3/2)+hh*(-3*x1*x2-x3*x4)+ff*(3*x2*x3-2*x4*x4)))==0
    modular_matrix=(nn*N+hh*H+ff*Fminus).jacobian(xx)
    cp=sp.factor(modular_matrix.charpoly(zz).as_expr())
    assert sp.expand(cp-(zz**2-hh**2-nn*ff)*(zz**2-9*(hh**2+nn*ff)))==0
    # Explicit rational symplectic transformation to the published T4 normal
    # form; the minus sign is the separately stated scalar multiplication.
    blocks=sp.Matrix([[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]])
    torus=sp.diag(1,1,-2,sp.Rational(-1,2))
    GT=torus*blocks
    assert GT*J*GT.T==J
    T4=sp.zeros(4)
    entries=[-x1*x2,x1*x3,x1*x4+x2*x2,-x2*x3+3*x1*x1,-x2*x4,2*x1*x2+3*x3*x4]
    for (i,j),val in zip(m.old.PAIRS,entries):T4[i,j]=val;T4[j,i]=-val
    assert push(AH,GT,-1)==T4
    assert jac(T4,xx)==[0]*4
    P=sp.zeros(5)
    for i,j in combinations(range(4),2):
        P[i+1,j+1]=x0*x0*J[i,j]+Qnew[i,j]
        P[j+1,i+1]=-P[i+1,j+1]
    assert jac(P,xx5)==[0]*10
    q=x0*x0+2*x1*x4+x3*x3
    pf=sp.expand(P[1,2]*P[3,4]-P[1,3]*P[2,4]+P[1,4]*P[2,3])
    assert sp.expand(pf-x0*x0*q)==0
    assert sp.hessian(q,xx5).rank()==4
    N5=sp.Matrix([0,*N]);Ht=sp.Matrix([x0,*H])
    assert lie(N5,P,xx5)==sp.zeros(5)
    assert lie(Ht,P,xx5)==2*P
    div=sp.Matrix([sum(sp.diff(P[i,j],xx5[i]) for i in range(5)) for j in range(5)])
    assert div==2*N5
    Pi=P-sp.Rational(2,5)*wedge(xx5,N5)
    assert Pi.T*sp.Matrix([1,0,0,0,0])==-sp.Rational(2,5)*x0*N5
    assert (Pi.T*sp.Matrix([sp.diff(q,z) for z in xx5])-sp.Rational(6,5)*q*N5).applyfunc(sp.expand)==sp.zeros(5,1)
    ps=sparse(P)
    D=p.linearized_jacobi_matrix(ps);V=p.vertical_bivector_matrix()
    orbit=[]
    for i in range(5):
        for j in range(5):
            C=np.zeros((5,5),dtype=np.int64);C[i,j]=1
            orbit.append(p.bivector_vector(v.linear_action_derivative(ps,C)))
    M=np.column_stack([V,*orbit,p.bivector_vector(ps)])
    assert not np.any(D@M)
    dr,dc=rank_cert(D);vr,vc=rank_cert(V);mr,mc=rank_cert(M)
    assert (dr,vr,mr)==(103,24,47)
    qa=quadratic_certificate(4*A.subs(t2,0))
    qb=quadratic_certificate(Qnew)
    assert (qa['tangent_dimension'],qa['Sp4_orbit_dimension'])==(10,9)
    assert (qb['tangent_dimension'],qb['Sp4_orbit_dimension'])==(9,9)
    out={'regular_nilpotent_fixed_trace':{
      'trace':str(s),'linear_rank':ans['linear_rank'],'affine_parameter_count':ans['free_count'],
      'Q_brackets':{''.join(str(i+1) for i in I):str(Q[I]) for I in m.old.PAIRS},
      'Jacobi_generators':[str(sp.factor(f)) for f in eq],
      'equal_Groebner_ideal':[str(f) for f in expected],
      'primitive_idempotents':[str(f) for f in ids],
      'scheme':'two disjoint reduced affine lines C[t2] x C[t2]',
      'centralizer_lie_generator':'x1 partial_2','centralizer_parameter_derivatives':['3/2','-3'],
      'centralizer_orbits_on_fixed_trace':2,
      'branch_A_quadratic_certificate':qa,'branch_B_quadratic_certificate':qb,
      'branch_A_containment':{
       'component':'known T4 component, dimension10',
       'F':'-3x3 partial_1 +4x4 partial_3 +3x2 partial_4',
       'R_H_brackets':{''.join(str(i+1) for i in I):str(AH[I]) for I in m.old.PAIRS},
       'R_F_brackets':{''.join(str(i+1) for i in I):str(AF[I]) for I in m.old.PAIRS},
       'universal_linear_module':'n*Q_A+h*R_H+f*R_F',
       'universal_Jacobi_and_J_compatibility':True,
       'modular_characteristic_polynomial':str(cp),
       'semisimple_deformation':'Q_A+epsilon*R_F, epsilon nonzero',
       'symplectic_matrix_from_R_H_to_T4':[[str(v) for v in row] for row in GT.tolist()],
       'separate_scalar_factor_from_R_H_to_T4':'-1',
       'T4_parameters':[-1,0,2,3,1,1,3],
       'branch_A_is_smooth_on_T4':True}},
     'new_component':{
      'Q':'H wedge N','H':'3x1 partial_1 - 3x2 partial_2 + x3 partial_3 - x4 partial_4',
      'N':'x4 partial_2 - x1 partial_3 + x3 partial_4','Lie_H_N':'2N',
      'H_N_symplectic':True,'all_affine_Jacobi_coefficients_zero':True,
      'Pfaffian':str(sp.factor(pf)),'projective_degeneracy_polynomial':str(x0**3*q),
      'quadric_rank':4,'modular_field':'2N',
      'canonical_representative':'P-(2/5)E wedge N',
      'canonical_contraction_dx0':'-(2/5)x0 N','canonical_contraction_dq':'(6/5)q N',
      'projective_stabilizer_generators':['N','x0 partial_0 + H'],
      'Jacobi_rank_over_Q':dr,'vertical_rank_over_Q':vr,'vertical_orbit_scale_rank_over_Q':mr,
      'Jacobi_minor':dc,'vertical_minor':vc,'orbit_minor':mc,'Jacobi_times_orbit_vertical_scale_zero':True,
      'projective_tangent_dimension':125-dr,'projective_orbit_dimension':mr-vr-1,
      'full_ambient_irreducible_component_certified':True,
      'dimension':22,
      'distinction_from_47':'Closed L^3*q degeneracy condition excludes 40 SNC-meeting components and the smooth-double-quadric component; generic rank4 excludes six rank2 components.',
      'claim_scope':'A component additional to the preceding 47; no claim of novelty in the literature or of completeness.'}}
    dest=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE
    dest.mkdir(parents=True,exist_ok=True)
    (dest/'regular_nilpotent_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'fixed_trace_scheme':out['regular_nilpotent_fixed_trace']['scheme'],
      'quadratic_tangents_and_orbits':[[qa['tangent_dimension'],qa['Sp4_orbit_dimension']],[qb['tangent_dimension'],qb['Sp4_orbit_dimension']]],
      'P4_ranks':[dr,vr,mr],'P4_projective_tangent_and_orbit':[125-dr,mr-vr-1],
      'D':'3H + rank4 quadric'},indent=2))

if __name__=='__main__':main()

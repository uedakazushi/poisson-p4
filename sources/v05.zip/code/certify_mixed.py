#!/usr/bin/env python3
"""Exact reduced fixed-trace ideals, deformations, and finite orbit quotient."""
from pathlib import Path
import json,argparse,sys
import mixed_modular as m
import sympy as sp
_saved_argv=sys.argv
try:
    sys.argv=[sys.argv[0]]
    import classify_extensions as e
finally:
    sys.argv=_saved_argv
HERE=Path(__file__).resolve().parent
x,y,z,w,a,A,B,C,eps=sp.symbols('x y z w a A B C eps')
X=sp.Matrix([x,y,z,w]);variables=list(X)
J1=sp.zeros(4);J1[0,1]=1;J1[1,0]=-1
J2=sp.zeros(4);J2[2,3]=1;J2[3,2]=-1
J=J1+J2

def wedge(U,V):return U*V.T-V*U.T
def jac(Q,R=None):
    vals=[]
    for i,j,k in m.old.TRIPLES:
        h=0
        for i,j,k in [(i,j,k),(j,k,i),(k,i,j)]:
            for l in range(4):
                h+=Q[i,l]*sp.diff((Q if R is None else R)[j,k],X[l])
                if R is not None:h+=R[i,l]*sp.diff(Q[j,k],X[l])
        vals.append(sp.expand(h))
    return vals

def push(Q,G,scale=1):
    ss=dict(zip(X,G.inv()*X))
    return (scale*G*Q.applyfunc(lambda f:f.subs(ss,simultaneous=True))*G.T).applyfunc(sp.expand)

def tensor(ans):
    tt=sp.symbols('t1:'+str(ans['free_count']+1))
    Q=sp.zeros(4)
    for (i,j),q in ans['Q'].items():
        term=0
        for mon,pol in q.items():
            coeff=sum(sp.Rational(v.numerator,v.denominator)*sp.prod(tt[h] for h in im) for im,v in pol.items())
            term+=coeff*sp.prod(v**k for v,k in zip(X,mon))
        Q[i,j]=sp.expand(term);Q[j,i]=-Q[i,j]
    return Q,tt

def main(output_dir=HERE):
    output_dir=Path(output_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    q=A*z*z+B*z*w+C*w*w
    Xu=sp.Matrix([-x,y,0,0]);Xq=sp.Matrix([0,0,-sp.diff(q,w),sp.diff(q,z)])
    E1=sp.Matrix([x,y,0,0]);E2=sp.Matrix([0,0,z,w]);u=x*y
    models={
        'M1':(u+q/2)*J1+q/2*J2+wedge(E1/4+(a-sp.Rational(1,4))*Xu,Xq),
        'M2':u*J1+q*J2+a*wedge(Xu,Xq),
        'M3':u/2*J1+(u/2+q)*J2-wedge(Xu,E2)/4+a*wedge(Xu,Xq),
    }
    zero=m.fixed_trace(m.CASES['mixed_zero']);equal=m.fixed_trace(m.CASES['mixed_equal'])
    Q,tt=tensor(zero)
    specs={'M1':[a,0,sp.Rational(1,4)],'M2':[a,0,sp.Rational(1,2)],'M3':[a,sp.Rational(1,2),sp.Rational(1,2)]}
    points={}
    for name,R in models.items():
        assert all(h==0 for h in jac(R)),name
        assert all(h==0 for h in jac(J,R)),name
        assert sp.expand(R[0,1]+R[2,3]-u-q)==0
        N=R.subs({A:sp.Rational(1,2),B:0,C:0}).applyfunc(sp.expand)
        assert N==Q.subs(dict(zip(tt,specs[name]))).applyfunc(sp.expand)
        points[name]=N
    # Exact scheme equality to three disjoint reduced affine lines.
    eq=[sum(sp.Rational(v.numerator,v.denominator)*sp.prod(tt[h] for h in im) for im,v in f.items()) for f in zero['row_reduced_equations']]
    gb=sp.groebner(eq,*tt,order='lex',domain=sp.QQ)
    expected=[tt[1]*(tt[1]-sp.Rational(1,2)),tt[1]*(tt[2]-sp.Rational(1,2)),(tt[2]-sp.Rational(1,4))*(tt[2]-sp.Rational(1,2))]
    gg=sp.groebner(expected,*tt,order='lex',domain=sp.QQ)
    assert all(gb.reduce(f)[1]==0 for f in expected)
    assert all(gg.reduce(f)[1]==0 for f in eq)
    # Explicit primitive orthogonal idempotents of the rank-three coefficient algebra.
    bb,cc=tt[1:]
    ids=[2-4*cc,4*cc-1-2*bb,2*bb]
    assert gb.reduce(sum(ids)-1)[1]==0
    for i,Ei in enumerate(ids):
        assert gb.reduce(Ei*Ei-Ei)[1]==0
        for j,Ej in enumerate(ids):
            if i!=j:assert gb.reduce(Ei*Ej)[1]==0
    # Find a constant rational combination of the original Jacobi coefficients
    # certifying that the mixed-equal fixed-trace scheme is empty.
    jac_equal=m.old.jacobi(equal['Q'])
    recs=sorted((I,mon,pol) for I,v in jac_equal.items() for mon,pol in v.items() if pol)
    mons=sorted({im for I,mon,pol in recs for im in pol},key=lambda t:(-len(t),t))
    rr,piv,comb=e.rref([[pol.get(im,0) for im in mons] for I,mon,pol in recs],certificate=True)
    const=[i for i,row in enumerate(rr) if all(not v for im,v in zip(mons,row) if im) and row[mons.index(())]]
    assert const
    k=const[0];assert rr[k][mons.index(())]==1
    recon={}
    for i,c in comb[k].items():recon=m.old.add(recon,recs[i][2],c)
    assert recon=={():m.F(1)}
    # Connected centralizer: diag(t,t^-1,1,1) and exp(k z partial_w).
    t,kappa=sp.symbols('t kappa',nonzero=True)
    gtor=sp.diag(t,1/t,1,1)
    guni=sp.eye(4);guni[3,2]=kappa
    # The disconnected normalization also permits scalar -1.
    gdisc=sp.Matrix([[0,1,0,0],[-1,0,0,0],[0,0,sp.I,0],[0,0,0,-sp.I]])
    orbit_maps={}
    for name,R in points.items():
        assert push(R,gtor)==R
        assert push(R,guni)==R
        dual=push(R,gdisc,-1)
        anew={'M1':sp.Rational(1,2)-a,'M2':-a,'M3':-a}[name]
        assert dual==R.subs(a,anew).applyfunc(sp.expand),(name,dual,R.subs(a,anew))
        orbit_maps[name]=str(anew)
    # Match the deformed semisimple normal forms to the established G1/G2 families.
    mu,E,AA,BB,CC,DD=sp.symbols('mu E AA BB CC DD')
    def normal(aa,bb,cc,dd,ee):
        vals=[aa*u+bb*z*w,ee*x*z,(cc-ee)*x*w,(-bb-ee)*y*z,(bb-cc+ee)*y*w,cc*u+dd*z*w]
        N=sp.zeros(4)
        for (i,j),v in zip(m.old.PAIRS,vals):N[i,j]=v;N[j,i]=-v
        return N.applyfunc(sp.expand)
    assert models['M1'].subs({A:0,B:mu,C:0}).applyfunc(sp.expand)==normal(1,mu/2,0,mu/2,mu*(a-sp.Rational(1,2)))
    assert models['M2'].subs({A:0,B:mu,C:0}).applyfunc(sp.expand)==normal(1,0,0,mu,a*mu)
    blockswap=sp.Matrix([[0,0,1,0],[0,0,0,1],[1,0,0,0],[0,1,0,0]])
    assert push(models['M3'].subs({A:0,B:mu,C:0}),blockswap)==normal(mu,sp.Rational(1,2),0,sp.Rational(1,2),-a*mu-sp.Rational(1,4))
    report={
        'fixed_trace_linear_dimensions':{'mixed_zero':zero['free_count'],'mixed_equal':equal['free_count']},
        'mixed_zero_exact_ideal_generators':[str(f) for f in eq],
        'mixed_zero_reduced_scheme':'three disjoint affine lines; C[a] x C[a] x C[a]',
        'line_parameters':{name:[str(v) for v in values] for name,values in specs.items()},
        'orthogonal_idempotents':[str(v) for v in ids],
        'mixed_equal_unit_certificate':{
            'coefficient_row_labels':[[list(I),list(mon)] for I,mon,pol in recs],
            'original_equations':[m.old.encode(pol) for I,mon,pol in recs],
            'one_as_rational_combination':[[i,v.numerator,v.denominator] for i,v in comb[k].items()]},
        'universal_binary_quadric_deformation_verified':True,
        'quadric_deformation':'q=(z^2+epsilon*w^2)/2, regular semisimple when epsilon!=0,-1',
        'established_component_containment':{'M1':'G2','M2':'G1','M3':'G2'},
        'centralizer_acts_pointwise':True,'finite_orbit_involutions':orbit_maps,
        'conclusion':'Exactly ten irreducible components of the full quadratic locus meet the open nonnilpotent modular locus; any further component is contained in the nilpotent modular cone.',
        'P4_component_count_change':0,
    }
    (output_dir/'mixed_classification_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({key:report[key] for key in ('mixed_zero_reduced_scheme','established_component_containment','finite_orbit_involutions','conclusion')},indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=HERE)
    main(parser.parse_args().output_dir)

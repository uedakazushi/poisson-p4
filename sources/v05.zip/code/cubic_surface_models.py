"""Exact central+unimodular models for the two nonnormal cubic surfaces.
Completeness is certified by cubic_surface_certificate.py and the theorem.
"""
import sympy as s
import itertools, json, sys
from pathlib import Path
x,y,z,w,t=s.symbols('x y z w t')
q=(x,y,z,w,t)

def models(kind):
    if kind==1:
        F=x*x*z+y*y*w
        B=[
        {(0,1):x*x/2,(0,2):-w*y,(1,2):x*z},
        {(0,1):y*y/2,(0,3):-w*y,(1,3):x*z},
        {(0,4):-w*y,(1,4):x*z},
        {(0,2):y*y/2,(0,3):-x*x/2,(2,3):x*z},
        {(1,2):y*y/2,(1,3):-x*x/2,(2,3):w*y},
        {(0,4):-x*x/2,(2,4):x*z},
        {(1,4):-x*x/2,(2,4):w*y},
        {(2,4):-y*y,(3,4):x*x},
        {(0,4):-y*y/2,(3,4):x*z},
        {(1,4):-y*y/2,(3,4):w*y},
        {(0,4):x*z/6,(1,4):-y*z/2,(2,4):-z*z/3,(3,4):w*z},
        {(0,4):3*w*x/2,(1,4):-w*y/2,(2,4):-3*w*z,(3,4):w*w},
        {(0,1):x*y/2,(0,3):-w*x,(0,4):t*x/2,(1,2):y*z,
         (1,4):-t*y/2,(2,3):2*w*z,(2,4):-t*z,(3,4):t*w}]
    elif kind==2:
        F=x*y*z+x*x*w+y**3
        B=[
        {(0,1):x*y,(0,2):-x*z-3*y*y,(1,2):2*w*x+y*z},
        {(0,1):x*x,(0,3):-x*z-3*y*y,(1,3):2*w*x+y*z},
        {(0,4):-x*z-3*y*y,(1,4):2*w*x+y*z},
        {(1,2):x*x/3,(1,3):-x*y/3,(2,3):x*z/3+y*y},
        {(0,2):x*x,(0,3):-x*y,(2,3):2*w*x+y*z},
        {(1,4):-x*y/3,(2,4):x*z/3+y*y},
        {(0,4):-x*y,(2,4):2*w*x+y*z},
        {(2,4):-x*x,(3,4):x*y},
        {(1,4):-x*x,(2,4):3*x*y,(3,4):x*z},
        {(2,4):-x*y,(3,4):y*y},
        {(0,4):-x*x,(3,4):2*w*x+y*z},
        {(0,4):3*x*y,(1,4):-x*z,(2,4):-3*w*x,(3,4):-3*w*y+z*z},
        {(0,4):x*z,(1,4):-3*w*x,(2,4):9*w*y-z*z,(3,4):w*z},
        {(0,1):x*x,(0,2):-3*x*y,(0,3):-x*z,(1,2):x*z,(1,3):2*w*x,
         (1,4):-t*x,(2,3):-6*w*y+z*z,(2,4):3*t*y,(3,4):t*z}]
    else:
        raise ValueError(kind)
    a=s.symbols('a:'+str(len(B)))
    P=s.zeros(5)
    for ak,b in zip(a,B):
        for (i,j),e in b.items():
            P[i,j]+=ak*e; P[j,i]-=ak*e
    assert all(s.expand(sum(P[i,j]*s.diff(F,q[i]) for i in range(5)))==0 for j in range(5))
    assert all(s.expand(sum(s.diff(P[i,j],q[i]) for i in range(5)))==0 for j in range(5))
    eq=[]
    for i,j,k,l in itertools.combinations(range(5),4):
        pf=s.expand(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])
        for e in s.Poly(pf,*q).coeffs():
            e=s.Poly(e,*a).monic().as_expr() if e!=0 else 0
            if e!=0 and e not in eq: eq.append(e)
    return F,a,P,eq

if __name__=='__main__':
    kind=int(sys.argv[1]);F,a,P,eq=models(kind)
    print('kind',kind,'parameters',len(a),'equations',len(eq),flush=True)
    for e in eq: print(s.factor(e),flush=True)
    if '--groebner' in sys.argv:
        G=s.groebner(eq,*reversed(a),order='grevlex')
        print('groebner',len(G.polys),flush=True)
        for e in G.polys: print(s.factor(e.as_expr()),flush=True)

#!/usr/bin/env python3
"""Exact fixed-trace scheme for an arbitrary quadratic Hamiltonian s on A4."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import sys,json,argparse
HERE=Path(__file__).resolve().parent
for path in [HERE.parent/'p4_poisson_completeness_v4'/'previous_v3'/'code',
             HERE.parent/'previous_v4'/'previous_v3'/'code']:
    if path.is_dir():sys.path.append(str(path))
_saved_argv=sys.argv
try:
    # Keep this entry point's CLI flags out of historical script defaults.
    sys.argv=[sys.argv[0]]
    import semisimple_quadratic as old
    from build_universal_slice import polynomial_row_basis
finally:
    sys.argv=_saved_argv

def coordinate(i):
    m=[0]*4;m[i]=1;return {tuple(m):{():F(1)}}

def lift(pol):return {m:{():F(v)} for m,v in pol.items() if v}

def ham(s):
    return [{m:old.scale(v,-1) for m,v in old.dx(s,1).items()},
            old.dx(s,0),
            {m:old.scale(v,-1) for m,v in old.dx(s,3).items()},
            old.dx(s,2)]

def action(X,Q):
    result={}
    for i,j in old.PAIRS:
        val={}
        for k in range(4):
            val=old.xadd(val,old.xmul(X[k],old.dx(old.entry(Q,i,j),k)))
            val=old.xadd(val,old.xmul(old.entry(Q,k,j),old.dx(X[i],k)),-1)
            val=old.xadd(val,old.xmul(old.entry(Q,i,k),old.dx(X[j],k)),-1)
        result[i,j]=val
    return result

def substitute(poly,ex):
    ans={}
    for m,c in poly.items():
        a={():c}
        for i in m:a=old.mul(a,ex[i])
        ans=old.add(ans,a)
    return ans

def fixed_trace(s):
    s=lift(s);X=ham(s)
    basis=[(I,m) for I in old.PAIRS for m in old.MON2]
    Q={}
    for k,(I,m) in enumerate(basis):Q.setdefault(I,{})[m]={(k,):F(1)}
    equations=[c for q in old.jacobi(old.P0,Q).values() for c in q.values()]
    trace=old.xadd(old.entry(Q,0,1),old.entry(Q,2,3))
    equations+=list(old.xadd(trace,s,-1).values())
    equations +=[c for q in action(X,Q).values() for c in q.values()]
    ex,free,rank=old.solve_linear(equations,len(basis))
    QQ={}
    for k,(I,m) in enumerate(basis):
        if ex[k]:QQ.setdefault(I,{})[m]=ex[k]
    assert all(not c for q in old.jacobi(old.P0,QQ).values() for c in q.values())
    assert all(not c for q in action(X,QQ).values() for c in q.values())
    assert not old.xadd(old.xadd(old.entry(QQ,0,1),old.entry(QQ,2,3)),s,-1)
    jac=old.jacobi(QQ)
    all_eq=[c for q in jac.values() for c in q.values() if c]
    ids,rb=polynomial_row_basis(all_eq)
    return {'free_count':len(free),'free_basis':[basis[i] for i in free],
            'linear_rank':rank,'Q':QQ,'row_reduced_equations':rb,
            'equations':[all_eq[i] for i in ids]}

def encode_result(ans):
    out={k:ans[k] for k in ('free_count','free_basis','linear_rank')}
    out['Q']=[[list(I),[[list(m),old.encode(c)] for m,c in q.items()]] for I,q in ans['Q'].items()]
    out['Jacobi_generators']=[old.encode(q) for q in ans['row_reduced_equations']]
    return out

CASES={'mixed_zero':{(1,1,0,0):F(1),(0,0,2,0):F(1,2)},
       'mixed_equal':{(1,1,0,0):F(1),(0,0,1,1):F(1),(1,0,0,1):F(1)}}

def main(output_dir=HERE):
    output_dir=Path(output_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    out={}
    for name,s in CASES.items():
        ans=fixed_trace(s)
        print(name,'free_count',ans['free_count'],'linear_rank',ans['linear_rank'],flush=True)
        for I,q in ans['Q'].items():print('Q'+''.join(str(i+1) for i in I),old.xstr(q),flush=True)
        print('JACOBI',flush=True)
        for q in ans['row_reduced_equations']:print(old.pstr(q),flush=True)
        out[name]=encode_result(ans)
    (output_dir/'mixed_fixed_trace_equations.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,default=HERE)
    main(parser.parse_args().output_dir)

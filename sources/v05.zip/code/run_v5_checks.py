#!/usr/bin/env python3
"""Recompute all twelve v5 exact certificates from the self-contained bundle."""
from pathlib import Path
import hashlib,json,os,platform,subprocess,sys,tempfile,time

HERE=Path(__file__).resolve().parent
OUT=HERE.parent/'data'
SCRIPTS=[
 ('mixed_modular.py','flag'),
 ('certify_mixed.py','flag'),
 ('certify_regular_nilpotent.py','positional'),
 ('certify_minimal_nilpotent.py','positional'),
 ('audit_triple_hyperplane.py','positional'),
 ('independent_audit_triple_hyperplane.py','flag'),
 ('nodal_cubic_certificate.py','positional'),
 ('cubic_surface_certificate.py','positional'),
 ('perazzo_cubic_certificate.py','positional'),
 ('audit_cubic_central_spaces.py','positional'),
 ('cross_audit_cubic_cones.py','flag'),
 ('independent_perazzo_audit.py','flag'),
]

def main():
    import numpy,sympy
    OUT.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
    results=[]
    with tempfile.TemporaryDirectory(prefix='p4_v5_verify_') as working:
        for name,style in SCRIPTS:
            started=time.monotonic()
            cmd=[sys.executable,str(HERE/name)]
            cmd+=['--output-dir',str(OUT)] if style=='flag' else [str(OUT)]
            proc=subprocess.run(cmd,cwd=working,env=env,text=True,capture_output=True)
            log=OUT/(Path(name).stem+'.log')
            log.write_text(proc.stdout+('\nSTDERR\n'+proc.stderr if proc.stderr else ''))
            rec={'script':name,'exit_code':proc.returncode,
                 'elapsed_seconds':round(time.monotonic()-started,3),
                 'script_sha256':hashlib.sha256((HERE/name).read_bytes()).hexdigest(),
                 'log':log.name}
            results.append(rec)
            print(('PASS' if proc.returncode==0 else 'FAIL'),name,
                  rec['elapsed_seconds'],'seconds',flush=True)
            if proc.returncode:
                print(proc.stdout[-2500:]+proc.stderr[-2500:],flush=True)
                break
    report={'python':platform.python_version(),'numpy':numpy.__version__,
            'sympy':sympy.__version__,'results':results,
            'all_passed':len(results)==len(SCRIPTS) and all(r['exit_code']==0 for r in results),
            'scope':'Twelve v5 exact computations and independent implementations; written proof audits are in proofs/. Previous checkpoints are preserved, not overwritten.'}
    (OUT/'v5_check_results.json').write_text(json.dumps(report,indent=2)+'\n')
    if not report['all_passed']:raise SystemExit(1)

if __name__=='__main__':main()

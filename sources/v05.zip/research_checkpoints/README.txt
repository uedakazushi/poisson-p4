Exploratory checkpoints: NOT theorem inputs
===========================================

minimal_homogenization_samples.json
----------------------------------
For the two certified13D quadratic components, homogenizing the particular
samples ti=i gives fullP4 Jacobi rank97, vertical+orbit+scale47, hence
projective tangent28 and projective orbit22. The Pfaffians at the scaled
samples are x0^2(x0^2+2x1^2) and (x0^2+x1^2)^2. These data neither establish
new P4 components nor establish containment in old ones. The derivative
family has room beyond the orbit. No P4 component increment is inferred.

singular_quadric_tangent_samples.json
------------------------------------
These are finite-field sample rank checks in the rank4-quadric tangent
configuration from v4, not exact uniform ranks or complete classification.
Coordinates(affine)=(a,b,c,d), Q=d+ab, Omega=da wedge dd+db wedge dc.
The diagonal Liouville field weights are(1-s,2s-1,2-2s,s), s!=1.
After a gauge beta->beta+k dQ, a candidate complete form is
 Za=(1-s)a, Zb=(2s-1)b-p,
 Zc=(2-2s)c+r b+t, Zd=s d+p a.
The Q-preserving fields U=partial_b-a partial_d, V=b partial_c, W=partial_c
satisfy [U,V]=W and weights1-2s,4s-3,2s-2. This suggests additional normalized
resonances p!=0 at s1/2 and r!=0 at s3/4; t removable for s!=1.
An anisotropic Liouville configuration at s2/3 has Q=d+a^2+b^2 and weights
(1/3,1/3,2/3,2/3). Completeness of these normal forms has NOT been audited.

The diagonal homogeneous Poisson model (x0 central) is
 P12=(2s-1)x0*b;
 P13=(1-s)(a^2+2x0*c);
 P14=x0*d+(2-2s)ab;
 P23=(1-s)x0*d+s*ab;
 P24=(2s-1)b^2;
 P34=(2-2s)bc-s*ad;
 Pf=(1-s)(x0*d+ab)^2.

A deformation candidate inherited from v4 (still NOT promoted) is
 delta12=2(s-1)ad+4sbc;
 delta13=-4(s-1)c^2;
 delta14=4s*cd;
 delta23=-2(s-1)cd;
 delta24=(2s-1)d^2;
 delta34=0.
Expected Pf(P_s+t delta_s)=(1-s)[(x0d+ab+2tcd)^2+t(ad-2bc)^2].
At t=-1 the two quadratic factors become
 (a-2c)(b+d)+x0d and (a+2c)(b-d)+x0d.
Verify Jacobi, the Pfaffian identity, and the actual deformation/orbit dimension
before using this to assign any component. A tangent direction alone is not
an integrated deformation; a sample rank is not a uniform proof.

These checkpoints are saved to preserve unfinished calculations, not to add
unproved assertions to the main v5 theorems.

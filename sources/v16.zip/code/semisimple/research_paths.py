"""Locate preserved inputs in the live workspace or an extracted v16 bundle."""
from pathlib import Path
import os
HERE=Path(__file__).resolve().parent

def v15_root():
 override=os.environ.get('P4_POISSON_V15_DIR')
 if override:
  root=Path(override).resolve()
  if (root/'code/normal_geometry/rnc4_slices.json').is_file():return root
  raise FileNotFoundError('P4_POISSON_V15_DIR does not contain the preserved v15 inputs')
 for parent in HERE.parents:
  for name in ('previous_v15','p4_poisson_completeness_v15'):
   candidate=parent/name
   if (candidate/'code/normal_geometry/rnc4_slices.json').is_file():return candidate
 raise FileNotFoundError('Preserved v15 inputs not found; set P4_POISSON_V15_DIR')

def v15_geometry_file(name):return v15_root()/'code/normal_geometry'/name

def geometry_root():
 override=os.environ.get('P4_POISSON_V16_GEOMETRY_DIR')
 if override:
  root=Path(override).resolve()
  if (root/'candidate_parameterizations.json').is_file():return root
  raise FileNotFoundError('P4_POISSON_V16_GEOMETRY_DIR is invalid')
 for candidate in [HERE.parent/'work_v16_geometry',HERE.parent/'geometry',HERE.parent/'normal_geometry']:
  if (candidate/'candidate_parameterizations.json').is_file():return candidate
 raise FileNotFoundError('New geometry inputs not found; set P4_POISSON_V16_GEOMETRY_DIR')


def singular_invocation():
 import shutil
 configured=os.environ.get('P4_POISSON_SINGULAR')
 executable=configured or shutil.which('Singular')
 environment=os.environ.copy()
 fallback=Path('/tmp/p4_v16_cas/usr/bin/Singular')
 if not executable and fallback.is_file():
  executable=str(fallback)
  environment.update({'LD_LIBRARY_PATH':'/tmp/p4_v16_cas/usr/lib/x86_64-linux-gnu','SINGULARPATH':'/tmp/p4_v16_cas/usr/share/singular/LIB','SINGULAR_PROCS_DIR':'/tmp/p4_v16_cas/usr/libexec/x86_64-linux-gnu/singular/MOD'})
 if not executable:raise FileNotFoundError('Singular is optional for witness generation; install it or set P4_POISSON_SINGULAR. Independent verifiers do not need it.')
 return executable,environment

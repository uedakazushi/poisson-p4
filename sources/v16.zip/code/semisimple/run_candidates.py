from pathlib import Path
import json,subprocess,os,time,re
R=Path(__file__).resolve().parent;manifest=json.loads((R/'candidate_manifest.json').read_text())
from research_paths import singular_invocation
executable,env=singular_invocation()
rows=[]
for case in manifest:
 caseid=case['id'];start=time.time();log=R/'candidates'/(caseid+'.log')
 with log.open('w') as stream:
  try:p=subprocess.run([executable,'-q',str(R/'candidates'/(caseid+'.sing'))],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=60);status=p.returncode
  except subprocess.TimeoutExpired:status='timeout'
 text=log.read_text();out={'id':caseid,'status':status,'seconds':round(time.time()-start,3),'errors':'?' in text}
 for label in ['SIZE','DIM']:
  m=re.search(label+r'\n(-?\d+)',text);out[label.lower()]=int(m.group(1)) if m else None
 if 'FRED_BEGIN' in text:
  fred=text.split('FRED_BEGIN\n',1)[1].split('FRED_END',1)[0].strip();out['Fred_is_zero']=all(line.split('=',1)[-1].strip().rstrip(',')=='0' for line in fred.splitlines());out['Fred_text_size']=len(fred)
 rows.append(out);print(out,flush=True)
 (R/'candidate_runs.json').write_text(json.dumps(rows,indent=2)+'\n')

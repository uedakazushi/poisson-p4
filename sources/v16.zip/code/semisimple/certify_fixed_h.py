#!/usr/bin/env python3
"""Exact full-scheme certificate for the semisimple fixed subscheme.
Does not assert that all points of the 36-variable slice are fixed.
"""
from pathlib import Path
from fractions import Fraction as F
import hashlib,json,sympy as s
ROOT=Path(__file__).resolve().parent
from research_paths import v15_geometry_file
SOURCE=v15_geometry_file('rnc4_slices.json')
d=json.loads(SOURCE.read_text())
ids=[5,12,13,19,23,29];z=s.symbols('z0:6');t=s.symbols('t')
zero=(0,)*6

def clean(p): return {m:F(c) for m,c in p.items() if c}
def plus(a,b,scale=F(1)):
    c=a.copy()
    for k,v in b.items():
        c[k]=c.get(k,F(0))+scale*v
        if not c[k]:del c[k]
    return c

def mulmon(p,m):return {tuple(a+b for a,b in zip(e,m)):c for e,c in p.items()}
def scaled(p,c):return {m:c*a for m,a in p.items() if c*a}
def order(m):return (sum(m),m)
def serialize(p):return [[list(m),[c.numerator,c.denominator]] for m,c in sorted(p.items())]
def expr(p):return s.Add(*(s.Rational(c.numerator,c.denominator)*s.prod(v**e for v,e in zip(z,m)) for m,c in p.items()))
def fromexpr(e):return {m:F(int(c.p),int(c.q)) for m,c in s.Poly(e,*z).terms() if c}

original=[];original_indices=[]
for i,eq in enumerate(d['cases']['semisimple']['jacobi_equations']):
 p={}
 for mon,c in eq['polynomial']:
  if any(mon[j] for j in range(36) if j not in ids):continue
  m=tuple(mon[j] for j in ids);p[m]=p.get(m,F(0))+F(*c)
 p=clean(p)
 if p and p not in original: original.append(p);original_indices.append(i)
G=s.groebner([expr(p) for p in original],*z,order='grevlex')
generators=[fromexpr(p.as_expr()) for p in G.polys]
print('original distinct',len(original),'GB',len(generators),flush=True)
# Exact Macaulay row reduction with polynomial-expression tracking.
basis={}; histories={};degree_found=None;certificates=None
for bound in range(2,6):
 mons=[m for total in range(bound-1) for m in __import__('itertools').product(range(total+1),repeat=6) if sum(m)==total]
 for i,p in enumerate(original):
  deg=max(map(sum,p))
  for mon in mons:
   if sum(mon)+deg>bound:continue
   v=mulmon(p,mon);history={(i,mon):F(1)}
   while v:
    lead=max(v,key=order)
    if lead not in basis:
     c=v[lead];basis[lead]=scaled(v,1/c);histories[lead]=scaled(history,1/c);break
    c=v[lead];v=plus(v,basis[lead],-c);history=plus(history,histories[lead],-c)
 results=[]
 for g in generators:
  v=g.copy();comb={}
  while v:
   lead=max(v,key=order)
   if lead not in basis:break
   c=v[lead];v=plus(v,basis[lead],-c);comb=plus(comb,histories[lead],c)
  if v:break
  results.append(comb)
 print('Macaulay bound',bound,'rank',len(basis),'targets',len(results),flush=True)
 if len(results)==len(generators): degree_found=bound;certificates=results;break
assert certificates is not None
for g,comb in zip(generators,certificates):
 total={}
 for (i,mon),c in comb.items(): total=plus(total,mulmon(original[i],mon),c)
 assert total==g
assert all(G.reduce(expr(p))[1]==0 for p in original)
# A CRT decomposition into one affine line and two isolated points.
a,b,c,dd,e,f=z
line={a:-14,b:t,c:t+2,dd:-2,e:0,f:0}
point1={a:-16,b:s.Rational(-1,2),c:s.Rational(-1,2),dd:0,e:0,f:0}
point2={a:s.Rational(-38,3),b:s.Rational(-1,2),c:s.Rational(5,6),dd:s.Rational(-4,3),e:0,f:s.Rational(-2,3)}
for branch in [line,point1,point2]: assert all(s.expand(expr(g).subs(branch))==0 for g in generators)
# Three mutually orthogonal idempotents split these branches.
p2=-s.Rational(3,2)*f
p1=(1-p2)*(dd+2)/2
pl=1-p1-p2
for p in [pl,p1,p2]: assert G.reduce(p*p-p)[1]==0
for p,q in [(pl,p1),(pl,p2),(p1,p2)]: assert G.reduce(p*q)[1]==0
# Branch ideals in the CRT summands have the claimed generators.
branch_generators=[
 [a+14,c-b-2,dd+2,e,f],
 [a+16,b+s.Rational(1,2),c+s.Rational(1,2),dd,e,f],
 [a+s.Rational(38,3),b+s.Rational(1,2),c-s.Rational(5,6),dd+s.Rational(4,3),e,f+s.Rational(2,3)]
]
for p,branchg in zip([pl,p1,p2],branch_generators):
 for g in branchg: assert G.reduce(s.expand(p*g))[1]==0
# Reconstruct P and quintic on each branch directly from the v15 lift.
x=s.symbols('x0:5');pairs=[tuple(p) for p in d['pairs']]
def xp(items):return s.Add(*(s.Rational(c[0],c[1])*s.prod(v**e for v,e in zip(x,m)) for m,c in items))
P=s.zeros(5)
for ind,(i,j) in enumerate(pairs):
 P[i,j]=xp(d['cases']['semisimple']['P0_upper'][ind])+sum(z[k]*xp(d['common_direction_matrices'][a][ind]) for k,a in enumerate(ids));P[j,i]=-P[i,j]
def quintic(mat):
 b=[]
 for k in range(5):
  i,j,l,m=[a for a in range(5) if a!=k]
  b.append((-1)**k*(mat[i,j]*mat[l,m]-mat[i,l]*mat[j,m]+mat[i,m]*mat[j,l]))
 return s.expand(sum(x[k]*b[k] for k in range(5))/5)
Q=x[0]*x[4]-x[2]**2;L=x[0]*x[3]-x[1]*x[2];R=x[1]*x[4]-x[2]*x[3]
H=x[0]*x[2]*x[4]-x[0]*x[3]**2-x[1]**2*x[4]+2*x[1]*x[2]*x[3]-x[2]**3
expected=[-x[2]*((2*t+1)*Q**2+4*L*R)/5,s.Rational(8,5)*x[2]*Q*(x[1]*x[3]-x[2]**2),s.Rational(4,45)*(x[1]*x[3]-x[2]**2)*H]
for branch,Fexp in zip([line,point1,point2],expected):assert s.expand(quintic(P.subs(branch))-Fexp)==0
out={
 'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
 'fixed_variable_indices':ids,
 'original_equation_indices':original_indices,
 'groebner_basis':[serialize(g) for g in generators],
 'macaulay_degree_bound':degree_found,
 'membership_certificates':[[[i,list(mon),[c.numerator,c.denominator]] for (i,mon),c in sorted(comb.items())] for comb in certificates],
 'CRT_idempotents':[str(p) for p in [pl,p1,p2]],
 'branches':[{str(k):str(v) for k,v in b.items()} for b in [line,point1,point2]],
 'quintics':[str(s.factor(f)) for f in expected],
 'all_checks_passed':True,
 'scope':'Full fixed subscheme only; normality excluded there by explicit nonzero reducible quintics. Whole 36-variable slice is not asserted classified.'
}
(ROOT/'fixed_h_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['groebner_basis','membership_certificates','branches']},indent=2))

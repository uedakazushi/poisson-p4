#!/usr/bin/env python3
"""QQ Macaulay witnesses for enough consequences to exclude normal h candidates.
Only the hardest 11-variable family is handled here.
"""
from pathlib import Path
from fractions import Fraction as Q
import json,itertools,time,ast
R=Path(__file__).resolve().parent;d=json.loads((R/'candidates/semisimple_d3_s0t0_linear.json').read_text());names=d['parameter_names'];n=len(names);weights=[5,3,1,-1,1,-1,-3,-5,-2,0,2]
qs=[{tuple(m):Q(*c) for m,c in q} for q in d['jacobi_equations']]
def plus(a,b,c=Q(1)):
 r=a.copy()
 for k,v in b.items():
  z=r.get(k,Q(0))+c*v
  if z:r[k]=z
  elif k in r:del r[k]
 return r
def scale(a,c):return {k:v*c for k,v in a.items() if v*c}
def mul(a,b):
 r={}
 for k,v in a.items():
  for m,w in b.items():
   e=tuple(a+b for a,b in zip(k,m));r[e]=r.get(e,Q(0))+v*w
 return {k:v for k,v in r.items() if v}
def parse(st):
 def rec(a):
  if isinstance(a,ast.Constant):return {(0,)*n:Q(a.value)} if a.value else {}
  if isinstance(a,ast.Name):m=[0]*n;m[names.index(a.id)]=1;return {tuple(m):Q(1)}
  if isinstance(a,ast.UnaryOp):return scale(rec(a.operand),-1 if isinstance(a.op,ast.USub) else 1)
  l=rec(a.left);r=rec(a.right)
  if isinstance(a.op,ast.Add):return plus(l,r)
  if isinstance(a.op,ast.Sub):return plus(l,r,-1)
  if isinstance(a.op,ast.Mult):return mul(l,r)
  if isinstance(a.op,ast.Div):assert list(r)==[(0,)*n];return scale(l,1/r[(0,)*n])
  if isinstance(a.op,ast.Pow):
   out={(0,)*n:Q(1)}
   for _ in range(int(r[(0,)*n])):out=mul(out,l)
   return out
  raise ValueError(st)
 return rec(ast.parse(st.replace('^','**'),mode='eval').body)
text=(R/'candidates/hard_h_QQslim.log').read_text();gbstr=[x.strip() for x in text.split('GB_BEGIN\n',1)[1].split('GB_END',1)[0].split(',') if x.strip()]
target_indices=[0,1,14,20,26,31,35,38];targets={i:parse(gbstr[i]) for i in target_indices}
def weight(p):
 ww={sum(a*b for a,b in zip(m,weights)) for m in p};assert len(ww)==1;return ww.pop()
qweights=[weight(q) for q in qs]
def order(m):return (sum(m),tuple(-a for a in reversed(m)))
mons=[]
for deg in range(3):
 for inds in itertools.combinations_with_replacement(range(n),deg):
  m=[0]*n
  for j in inds:m[j]+=1
  mons.append((tuple(m),sum(weights[j] for j in inds)))
certificates={};start=time.time()
for wt in sorted({weight(t) for t in targets.values()}):
 current={i:p for i,p in targets.items() if weight(p)==wt};basis={};history={};count=0
 for mon,mw in mons:
  for ind,q in enumerate(qs):
   if qweights[ind]+mw!=wt:continue
   v={tuple(a+b for a,b in zip(m,mon)):c for m,c in q.items()};h={(ind,mon):Q(1)}
   while v:
    lead=max(v,key=order)
    if lead not in basis:
     coefficient=v[lead];basis[lead]=scale(v,1/coefficient);history[lead]=scale(h,1/coefficient);break
    coefficient=v[lead];v=plus(v,basis[lead],-coefficient);h=plus(h,history[lead],-coefficient)
   count+=1
 for index,targ in current.items():
  v=targ.copy();h={}
  while v:
   lead=max(v,key=order)
   if lead not in basis:break
   coefficient=v[lead];v=plus(v,basis[lead],-coefficient);h=plus(h,history[lead],coefficient)
  if v: print('NOT_FOUND',index,gbstr[index],'weight',wt,flush=True)
  else:
   test={}
   for (ind,mon),a in h.items():test=plus(test,{tuple(x+y for x,y in zip(m,mon)):c for m,c in qs[ind].items()},a)
   assert test==targ
   certificates[index]=[[i,list(m),[c.numerator,c.denominator]] for (i,m),c in sorted(h.items())]
 print('weight',wt,'input_rows',count,'rank',len(basis),'certified',list(certificates),'seconds',round(time.time()-start,3),flush=True)
 (R/'hard_h_support_witnesses.json').write_text(json.dumps({'parameter_names':names,'source_candidate':'semisimple_d3_s0t0_linear','target_G_indices':target_indices,'target_strings':{str(i):gbstr[i] for i in target_indices},'witnesses':{str(i):v for i,v in certificates.items()},'multiplier_degree_bound':2,'all_targets_certified':len(certificates)==len(target_indices)},separators=(',',':'))+'\n')

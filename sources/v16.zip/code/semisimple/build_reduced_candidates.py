#!/usr/bin/env python3
from pathlib import Path
import json,math,time
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
from research_paths import v15_geometry_file,geometry_root
RDIR=Path(__file__).resolve().parent;BASE=RDIR.parent
source=json.loads(v15_geometry_file('rnc4_slices.json').read_text());red=json.loads(v15_geometry_file('rnc4_equation_reduction.json').read_text());geom=json.loads((geometry_root()/'candidate_parameterizations.json').read_text())
U,*u=ring(','.join(f'u{i}' for i in range(36)),QQ)
# Coefficient polynomials of the full h quintic, in the 36 affine parameters.
pairs=source['pairs'];P=[[{} for j in range(5)] for i in range(5)]
for pos,(i,j) in enumerate(pairs):
 pp={tuple(m):U.ground_new(QQ(*q)) for m,q in source['cases']['semisimple']['P0_upper'][pos]}
 for a in range(36):
  for m,q in source['common_direction_matrices'][a][pos]:
   m=tuple(m);pp[m]=pp.get(m,U.zero)+QQ(*q)*u[a]
 P[i][j]=pp;P[j][i]={m:-v for m,v in pp.items()}
Fcoeff={}
for omit in range(5):
 i,j,k,l=[a for a in range(5) if a!=omit]
 for aa,bb,sgn in [(P[i][j],P[k][l],1),(P[i][k],P[j][l],-1),(P[i][l],P[j][k],1)]:
  for m,v in aa.items():
   for n,w in bb.items():
    e=[m[a]+n[a]+int(a==omit) for a in range(5)];e=tuple(e)
    Fcoeff[e]=Fcoeff.get(e,U.zero)+QQ((-1)**omit*sgn,5)*v*w
Fcoeff={m:q for m,q in Fcoeff.items() if q}
universal=[(m,list(q.items())) for m,q in sorted(Fcoeff.items())]
selected=red['semisimple']['selected_original_equation_indices']
Jterms=[]
for index in selected:
 Jterms.append([(tuple(m),QQ(*q)) for m,q in source['cases']['semisimple']['jacobi_equations'][index]['polynomial']])
out=RDIR/'candidates';out.mkdir(exist_ok=True);manifest=[]
for case in geom['cases']:
 if case['residue']!='semisimple':continue
 ts=time.time();names=case['parameter_names'];A,*z=ring(','.join(names),QQ)
 us=[]
 for pp in case['u_polynomials']:
  q=A.zero
  for m,c in pp:q+=A.from_dict({tuple(m):QQ(*c)})
  us.append(q)
 cache={}
 def compose(terms):
  q=A.zero
  for m,c in terms:
   active=tuple(i for i,k in enumerate(m) for _ in range(k))
   if active not in cache:
    vv=A.one
    for i in active:vv*=us[i]
    cache[active]=vv
   q+=c*cache[active]
  return q
 js=[compose(q) for q in Jterms];js=[q for q in js if q];js=list(dict.fromkeys(js))
 fs=[compose(q) for m,q in universal]
 def stringify(q):return str(q).replace('**','^')
 casename=case['id']; qq=out/(casename+'.sing')
 header='ring r=0,('+','.join(names)+'),dp;\noption(redSB);\nideal I='+',\n'.join(stringify(q) for q in js)+';\n'
 tail='int tick=timer;ideal G=slimgb(I);print("ELAPSED");print(timer-tick);print("SIZE");print(size(G));print("DIM");print(dim(G));print("GB_BEGIN");print(G);print("GB_END");\n'
 tail+='ideal Fcoefs='+',\n'.join(stringify(q) for q in fs)+';\nideal Fred=reduce(Fcoefs,G);print("FRED_BEGIN");print(Fred);print("FRED_END");\nquit;\n'
 qq.write_text(header+tail)
 def enc(q):return [[list(m),[int(c.numerator),int(c.denominator)]] for m,c in sorted(q.items())]
 data={'id':casename,'parameter_names':names,'jacobi_equations':[enc(q) for q in js],'quintic_monomials':[list(m) for m,q in universal],'quintic_coefficients':[enc(q) for q in fs],'geometry_case':case}
 (out/(casename+'.json')).write_text(json.dumps(data,separators=(',',':'))+'\n')
 summary={'id':casename,'variables':len(names),'equations':len(js),'max_terms':max(len(q) for q in js)};manifest.append(summary);print(summary,flush=True)
(RDIR/'candidate_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

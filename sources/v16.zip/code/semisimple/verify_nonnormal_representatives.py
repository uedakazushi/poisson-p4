#!/usr/bin/env python3
"""Exact, standard-library witnesses excluding the two primitive h candidates."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations
import json
from research_paths import v15_geometry_file
R=Path(__file__).resolve().parent;source=json.loads(v15_geometry_file('rnc4_slices.json').read_text());pairs=[tuple(z) for z in source['pairs']]
def add(a,b,c=Q(1)):
 p=a.copy()
 for m,v in b.items():
  p[m]=p.get(m,Q(0))+c*v
  if not p[m]:del p[m]
 return p
def mul(a,b):
 p={}
 for m,v in a.items():
  for n,w in b.items():
   t=tuple(x+y for x,y in zip(m,n));p[t]=p.get(t,Q(0))+v*w
 return {m:v for m,v in p.items() if v}
def scale(a,c):return {m:v*c for m,v in a.items() if v*c}
def power(a,k,n):
 p={(0,)*n:Q(1)}
 for _ in range(k):p=mul(p,a)
 return p
def var(i,n):
 m=[0]*n;m[i]=1;return {tuple(m):Q(1)}
def const(v,n):return {(0,)*n:Q(v)} if v else {}
def read(v):return {tuple(m):Q(*q) for m,q in v}
def deriv(p,i):
 out={}
 for m,c in p.items():
  if m[i]:n=list(m);n[i]-=1;out[tuple(n)]=c*m[i]
 return out
def rebuild(us):
 M=[[{} for _ in range(5)] for _ in range(5)]
 for k,(i,j) in enumerate(pairs):
  p=read(source['cases']['semisimple']['P0_upper'][k])
  for a,u in enumerate(us):p=add(p,read(source['common_direction_matrices'][a][k]),u)
  M[i][j]=p;M[j][i]=scale(p,-1)
 return M
def check_poisson(M):
 for j in range(5):
  p={}
  for i in range(5):p=add(p,deriv(M[i][j],i))
  assert not p
 for i,j,k in combinations(range(5),3):
  p={}
  for l in range(5):
   p=add(p,mul(M[i][l],deriv(M[j][k],l)));p=add(p,mul(M[j][l],deriv(M[k][i],l)));p=add(p,mul(M[k][l],deriv(M[i][j],l)))
  assert not p
 x=[var(i,5) for i in range(5)];b=[];F={}
 for omit in range(5):
  i,j,k,l=[v for v in range(5) if v!=omit]
  pf=scale(add(add(mul(M[i][j],M[k][l]),mul(M[i][k],M[j][l]),-1),mul(M[i][l],M[j][k])),(-1)**omit);b.append(pf);F=add(F,mul(x[omit],pf),Q(1,5))
 for i in range(5):assert deriv(F,i)==b[i]
 assert F
 return F
x=[var(i,5) for i in range(5)]
q0=add(mul(x[0],x[2]),power(x[1],2,5),-1);q3=add(mul(x[1],x[3]),power(x[2],2,5),-1);q5=add(mul(x[2],x[4]),power(x[3],2,5),-1)
L=add(mul(x[0],x[3]),mul(x[1],x[2]),-1);RR=add(mul(x[1],x[4]),mul(x[2],x[3]),-1);QQ=add(mul(x[0],x[4]),power(x[2],2,5),-1)
H=add(add(add(add(mul(mul(x[0],x[2]),x[4]),mul(x[0],power(x[3],2,5)),-1),mul(power(x[1],2,5),x[4]),-1),scale(mul(mul(x[1],x[2]),x[3]),2)),power(x[2],3,5),-1)
# Exceptional d2 family.
db=json.loads((R/'candidates/semisimple_d2_s1t1_diagonal_zero.json').read_text());names=db['parameter_names'];values=[1 if v in ['z1','z2'] else 0 for v in names]
us=[]
for pp in db['geometry_case']['u_polynomials']:
 val=Q(0)
 for m,c in pp:
  z=Q(*c)
  for a,e in zip(values,m):z*=Q(a)**e
  val+=z
 us.append(val)
assert {i:u for i,u in enumerate(us) if u}=={5:Q(-14),12:Q(-1),13:Q(1),19:Q(-2)}
FB=check_poisson(rebuild(us));expectedB=scale(mul(x[2],add(power(QQ,2,5),scale(mul(L,RR),4),-1)),Q(1,5));assert FB==expectedB
# C* family: symmetric square-root representative, all P coefficients rational.
dc=json.loads((R/'candidates/semisimple_d3_s0t0_linear.json').read_text());names=dc['parameter_names'];us=[]
for pp in dc['geometry_case']['u_polynomials']:
 val=Q(0)
 for m,c in pp:
  powers=dict(zip(names,m))
  if any(powers[f'z{i}'] for i in range(1,7)) or powers['k0'] or powers['k2']:continue
  zz=powers['z0']+powers['z7'];assert zz%2==0
  val+=Q(*c)*Q(2,3)**(zz//2)*(-1)**powers['k1']
 us.append(val)
FC=check_poisson(rebuild(us));Phi=add(add(add(mul(x[1],power(q0,2,5)),scale(mul(mul(x[2],q0),q5),2)),mul(x[3],power(q5,2,5))),mul(q3,H));assert FC==scale(Phi,Q(2,15))
# The displayed two-parameter singular surface.
t=var(0,2);w=var(1,2);one=const(1,2)
chart=[add(add(power(t,4,2),mul(t,w),-1),{(-1,0):Q(1)}),one,t,power(t,2,2),w]
def substitute(p):
 out={}
 for m,c in p.items():
  term=const(c,2)
  for i,e in enumerate(m):term=mul(term,power(chart[i],e,2))
  out=add(out,term)
 return out
assert not substitute(Phi)
assert all(not substitute(deriv(Phi,i)) for i in range(5))
# Exact torus weights of the whole C* family from the original canonical basis.
xweights=[4,2,0,-2,-4];weights=[]
for M in source['common_direction_matrices']:
 found={sum(xweights[a]*m[a] for a in range(5))-xweights[i]-xweights[j] for (i,j),entry in zip(pairs,M) for m,c in entry}
 assert len(found)==1;weights.append(found.pop())
for i,pp in enumerate(dc['geometry_case']['u_polynomials']):
 laurent={}
 for mon,c in pp:
  e=dict(zip(names,mon))
  if any(e[f'z{j}'] for j in range(1,7)) or e['k0'] or e['k2']:continue
  exponent=e['z0']-e['z7'];laurent[exponent]=laurent.get(exponent,Q(0))+Q(*c)*Q(2,3)**e['z7']*(-1)**e['k1']
 for exponent,coef in laurent.items():
  if coef:assert 5*exponent==weights[i]
report={'independent_standard_library_only':True,'two_bivectors_Poisson_and_divergence_zero':True,'Pfaff_gradient_normalization_verified':True,'d2_reducible_quintic_verified':True,'d3_compact_quintic_verified':True,'d3_five_gradients_zero_on_explicit_surface':True,'surface_coordinates_x2_t_x4_w_independent':True,'torus_weights_a5_bminus5_verified':True,'all_checks_passed':True}
(R/'nonnormal_representatives_independent_verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

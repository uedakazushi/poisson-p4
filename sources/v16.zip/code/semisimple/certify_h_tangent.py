#!/usr/bin/env python3
"""Uniform full-slice tangent certificates along the entire fixed subscheme."""
from pathlib import Path
import json,hashlib,sympy as s
from research_paths import v15_geometry_file
R=Path(__file__).resolve().parent;SOURCE=v15_geometry_file('rnc4_slices.json');RED=SOURCE.with_name('rnc4_equation_reduction.json')
d=json.loads(SOURCE.read_text());red=json.loads(RED.read_text())
u=s.symbols('u0:36');t=s.symbols('t');w=[4,2,0,-2,-4];pairs=d['pairs']
def pol(items):return s.Add(*(s.Rational(c[0],c[1])*s.prod(v**e for v,e in zip(u,m)) for m,c in items))
indices=red['semisimple']['selected_original_equation_indices']
eqs=[pol(d['cases']['semisimple']['jacobi_equations'][i]['polynomial']) for i in indices]
weights=[sorted(set(sum(w[a]*m[a] for a in range(5))-w[i]-w[j] for (i,j),entry in zip(pairs,M) for m,c in entry))[0] for M in d['common_direction_matrices']]
assert all(len(set(sum(w[a]*m[a] for a in range(5))-w[i]-w[j] for (i,j),entry in zip(pairs,M) for m,c in entry))==1 for M in d['common_direction_matrices'])
for e in eqs: assert len({sum(weights[i]*m[i] for i in range(36)) for m,c in s.Poly(e,*u).terms()})==1
J=s.Matrix(eqs).jacobian(u)
line={u[i]:{5:-14,12:t,13:t+2,19:-2}.get(i,0) for i in range(36)}
Mline=J.subs(line);kv=s.Matrix([1 if i in [12,13] else 0 for i in range(36)])
assert Mline*kv==s.zeros(len(eqs),1)
uniform=json.loads((R/'uniform_h.json').read_text())
for wt,cert in uniform.items():
 gcd=s.Poly(0,t)
 for item in cert['certificates']:
  actual=s.expand(Mline.extract(item['rows'],item['columns']).det(method='domain-ge'))
  assert s.expand(actual-s.sympify(item['determinant'],locals={'t':t}))==0
  gcd=s.gcd(gcd,s.Poly(actual,t))
 assert gcd.degree()==0
 assert all(weights[c]==int(wt) for c in cert['certificates'][0]['columns'])
assert sum(x['rank'] for x in uniform.values())==35
points=[{5:-16,12:s.Rational(-1,2),13:s.Rational(-1,2)},{5:s.Rational(-38,3),12:s.Rational(-1,2),13:s.Rational(5,6),19:s.Rational(-4,3),29:s.Rational(-2,3)}]
point_cert=[]
for vals in points:
 P=J.subs({u[i]:vals.get(i,0) for i in range(36)});certs=[]
 for wt in sorted(set(weights)):
  cols=[i for i in range(36) if weights[i]==wt]
  rows=list(P[:,cols].T.rref()[1]); assert len(rows)==len(cols)
  det=P.extract(rows,cols).det();assert det
  certs.append({'weight':wt,'rows':rows,'columns':cols,'determinant':[int(det.p),int(det.q)]})
 assert sum(len(c['columns']) for c in certs)==36
 point_cert.append(certs)
report={'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'equation_indices':indices,'parameter_weights':weights,'line_parameterization':{'u5':'-14','u12':'t','u13':'t+2','u19':'-2','others':'0'},'line_uniform_certificates':uniform,'line_tangent_dimension_everywhere':1,'isolated_point_certificates':point_cert,'isolated_point_tangent_dimensions':[0,0],'all_checks_passed':True,'scope':'Full 36-variable slice tangent matrices, not only weight-zero matrices; no assertion that all components meet the fixed subscheme.'}
(R/'h_tangent_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'line_dimension':1,'point_dimensions':[0,0],'all_checks_passed':True,'line_minor_count':sum(len(v['certificates']) for v in uniform.values()),'isolated_point_minor_count':sum(len(x) for x in point_cert)},indent=2))

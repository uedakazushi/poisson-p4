半単純 residue A_h に関する第16版検証一式
=======================================

主結果
------
幾何学側の rank-one conormal reduction が与える21個の必要パラメータ族について、
正規な五次退化因子を持つ候補は存在しない。
最初から [A_h,P]=0 を仮定していない。実際、最後の族には非不変な C* 族があり、
その非正規性は明示的な特異曲面で証明する。
詳しい論証は PROOF_NOTE_ja.txt。網羅性の幾何学的入力は別途 geometry の原稿による。

標準ライブラリだけの最終検証
--------------------------
このディレクトリを code/semisimple に置き、bundle のトップに previous_v15 を置く。
新しい幾何学側の candidate_parameterizations.json は code/geometry または
code/normal_geometry に置く。別配置なら環境変数
 P4_POISSON_V15_DIR
 P4_POISSON_V16_GEOMETRY_DIR
でそれぞれのディレクトリを指定できる。研究中の workspace も自動認識する。

以下の四コマンドは Python 標準ライブラリだけで動く。Singular/SymPy は不要。

 python3 code/semisimple/verify_fixed_h.py
 python3 code/semisimple/verify_h_tangent.py
 python3 code/semisimple/verify_candidate_witnesses.py
 python3 code/semisimple/verify_nonnormal_representatives.py

verify_candidate_witnesses.py は、canonical な geometry パラメータと候補JSONの一致、
preserved v15 の94生成元への代入、19族の厳密なイデアル一致、d3二族の
2個+8個の一方向イデアル包含を再検証する。
加えて、最後の族の元のJacobi生成元 #3,#17,#71 の三変数への制限、
v の末尾係数と primitive 条件に使う行列も確認する。
その後、verify_nonnormal_representatives.py が両代表のPoisson条件、Pfaff式、
可約性を示す式、C*族のtorus軌道、および五偏微分の特異曲面上の消滅を確認する。

全スキームについての独立の結果
------------------------------
X_h^T=A1 disjoint union pt disjoint union pt を全スキームとして証明。
8個のGB生成元についてdegree4 Macaulay包含証明、逆包含、CRT冪等元を保存。
全36変数X_h内の接空間は直線全域で1、二点で0。
直線の17個の多項式小行列式、二点の22個の有理小行列式を確認する。
従ってこの固定部分は全X_hの開かつ閉な滑らかな部分スキーム。
一般のX_hを固定部分と同一視してはいけない。

再生成（検証には不要）
----------------------
SymPy 1.14.0 により certify_fixed_h.py, certify_h_tangent.py,
build_reduced_candidates.py を実行できる。
各 candidates/*.sing は有理数体上の完全な入力であり、Singular 4.3.2 で実行した。
run_candidates.py は21族すべてに slimgb を用いる。
generate_slim_certificates.py は19族の変換行列証明書を生成する。
残る二族の証明書は weighted_support_certificate.py と
weighted_diagonal_support_certificate.py が Fraction だけで生成する。
前者は数分、後者は十秒程度かかることがあるが、保存済み証明書の検証は数秒。
Singular の実行ファイルは PATH または P4_POISSON_SINGULAR で指定する。

最終成果に含めるファイル
------------------------
EXPORT_MANIFEST.json の listed files を相対パスを保ってコピーする。
.symmetry.log の巨大な旧 lift 出力、36変数GBの時間切れログ、途中の診断コードは
最終成果に不要なので、この一覧には含めていない。
全21候補のスキームを被約化せず同じ形で分類したという主張はしていない。
正規候補を排除する部分では、必要な閉点条件と一方向の包含証明で十分である。

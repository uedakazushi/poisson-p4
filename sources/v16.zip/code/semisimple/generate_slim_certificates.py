from pathlib import Path
import json,subprocess,os,time
R=Path(__file__).resolve().parent;manifest=json.loads((R/'candidate_manifest.json').read_text())
from research_paths import singular_invocation
executable,env=singular_invocation()
rows=[]
# The two hardest families use stored degree-six one-sided certificates.
manifest=[x for x in manifest if x['id'] not in ['semisimple_d3_s0t0_linear','semisimple_d3_s0t0_diagonal_zero']]
for case in manifest:
 name=case['id'];original=(R/'candidates'/(name+'.sing')).read_text();header=original.split('int tick=',1)[0]
 code=header+'matrix T;ideal G=liftstd(I,T,"slimgb");print("GB_BEGIN");int ii;int jj;for(jj=1;jj<=size(G);jj++){print(string(jj)+"|"+string(G[jj]));}print("GB_END");\n'
 code+='print("WITNESS_BEGIN");for(ii=1;ii<=nrows(T);ii++){for(jj=1;jj<=ncols(T);jj++){if(T[ii,jj]!=0){print(string(ii)+"|"+string(jj)+"|"+string(T[ii,jj]));}}}print("WITNESS_END");\n'
 code+='print("CHECK_BEGIN");print(matrix(I)*T-matrix(G));print("CHECK_END");quit;\n'
 path=R/'candidates'/(name+'.certificate.sing');path.write_text(code);out=R/'candidates'/(name+'.certificate.log');start=time.time()
 with out.open('w') as stream:
  try:p=subprocess.run([executable,'-q',str(path)],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180);status=p.returncode
  except subprocess.TimeoutExpired:status='timeout'
 # Do not print potentially large rational coefficients.
 tt=out.read_text();row={'id':name,'status':status,'seconds':round(time.time()-start,3),'bytes':out.stat().st_size,'witness_complete':'WITNESS_END' in tt,'internal_check_complete':'CHECK_END' in tt,'errors':'?' in tt};rows.append(row);print(row,flush=True)
 (R/'slim_certificate_generation.json').write_text(json.dumps(rows,indent=2)+'\n')

#!/usr/bin/env python3
"""Standard-library exact verification of uniform full-h tangent minors.
Polynomial determinants are checked at n+1 rational values with an independently
verified degree bound n; thus this is an exact polynomial identity check.
"""
from pathlib import Path
from fractions import Fraction as Q
import ast,json,hashlib
from research_paths import v15_geometry_file
R=Path(__file__).resolve().parent;S=v15_geometry_file('rnc4_slices.json')
d=json.loads(S.read_text());c=json.loads((R/'h_tangent_certificate.json').read_text())
assert hashlib.sha256(S.read_bytes()).hexdigest()==c['source_sha256']
w=c['parameter_weights'];ids=c['equation_indices'];eqs=[d['cases']['semisimple']['jacobi_equations'][i]['polynomial'] for i in ids]
def add(a,b,coef=Q(1)):
 r=a.copy()
 for k,v in b.items():
  r[k]=r.get(k,Q(0))+coef*v
  if not r[k]:del r[k]
 return r
def mul(a,b):
 r={}
 for k,v in a.items():
  for l,z in b.items():r[k+l]=r.get(k+l,Q(0))+v*z
 return {k:v for k,v in r.items() if v}
def scale(a,k):return {i:v*k for i,v in a.items() if v*k}
def constant(v):return {0:Q(v)} if v else {}
def ev(p,t):return sum(v*Q(t)**k for k,v in p.items())
def deg(p):return max(p) if p else -1
def divrem(a,b):
 q={};r=a.copy()
 while r and deg(r)>=deg(b):
  k=deg(r)-deg(b);v=r[deg(r)]/b[deg(b)];q[k]=q.get(k,Q(0))+v
  r=add(r,{i+k:z*v for i,z in b.items()},-1)
 return q,r
def gcd(a,b):
 while b:a,b=b,divrem(a,b)[1]
 return scale(a,1/a[deg(a)]) if a else {}
def parse(expr):
 def rec(n):
  if isinstance(n,ast.Constant):return constant(n.value)
  if isinstance(n,ast.Name) and n.id=='t':return {1:Q(1)}
  if isinstance(n,ast.UnaryOp):
   a=rec(n.operand);return scale(a,-1) if isinstance(n.op,ast.USub) else a
  if isinstance(n,ast.BinOp):
   a=rec(n.left);b=rec(n.right)
   if isinstance(n.op,ast.Add):return add(a,b)
   if isinstance(n.op,ast.Sub):return add(a,b,-1)
   if isinstance(n.op,ast.Mult):return mul(a,b)
   if isinstance(n.op,ast.Div):assert deg(b)==0;return scale(a,1/b[0])
   if isinstance(n.op,ast.Pow):
    assert deg(b)==0 and b[0].denominator==1 and b[0]>=0
    v=constant(1)
    for i in range(int(b[0])):v=mul(v,a)
    return v
  raise ValueError('unsupported polynomial syntax')
 return rec(ast.parse(expr,mode='eval').body)
def determinant(M):
 M=[list(r) for r in M];n=len(M);det=Q(1)
 for i in range(n):
  k=next((k for k in range(i,n) if M[k][i]),None)
  if k is None:return Q(0)
  if k!=i:M[i],M[k]=M[k],M[i];det=-det
  pivot=M[i][i];det*=pivot
  for k in range(i+1,n):
   a=M[k][i]/pivot
   for j in range(i+1,n):M[k][j]-=a*M[i][j]
 return det

def jacobian(values):
 rows=[]
 for eq in eqs:
  row=[]
  for j in range(36):
   v={}
   for mon,coef in eq:
    if not mon[j]:continue
    term=constant(Q(*coef)*mon[j]);m=list(mon);m[j]-=1
    for i,e in enumerate(m):
     for _ in range(e):term=mul(term,values[i])
    v=add(v,term)
   row.append(v)
  rows.append(row)
 return rows
rowweights=[]
for eq in eqs:
 ws={sum(w[i]*m[i] for i in range(36)) for m,coef in eq};assert len(ws)==1;rowweights.append(ws.pop())
line=[constant({5:-14,19:-2}.get(i,0)) for i in range(36)];line[12]={1:Q(1)};line[13]={1:Q(1),0:Q(2)}
J=jacobian(line)
for r,row in enumerate(J):
 assert not add(row[12],row[13])
 for j,entry in enumerate(row):
  assert deg(entry)<=1
  if entry:assert rowweights[r]==w[j]
minor_count=0;rank=0
for weight,group in c['line_uniform_certificates'].items():
 gg={};rank+=group['rank']
 for cert in group['certificates']:
  rr=cert['rows'];cc=cert['columns'];n=len(cc);p=parse(cert['determinant']);assert deg(p)<=n
  assert all(w[j]==int(weight) for j in cc)
  for val in range(n+1):assert determinant([[ev(J[r][j],val) for j in cc] for r in rr])==ev(p,val)
  gg=gcd(gg,p);minor_count+=1
 assert deg(gg)==0
assert rank==35
points=[{5:-16,12:Q(-1,2),13:Q(-1,2)},{5:Q(-38,3),12:Q(-1,2),13:Q(5,6),19:Q(-4,3),29:Q(-2,3)}]
point_minors=0
for values,groups in zip(points,c['isolated_point_certificates']):
 JJ=jacobian([constant(values.get(i,0)) for i in range(36)]);rank=0
 for cert in groups:
  rr,cc=cert['rows'],cert['columns'];assert all(w[j]==cert['weight'] for j in cc)
  value=determinant([[ev(JJ[r][j],0) for j in cc] for r in rr]);assert value==Q(*cert['determinant']) and value
  rank+=len(cc);point_minors+=1
 assert rank==36
report={'independent_standard_library_only':True,'uniform_line_tangent_dimension':1,'isolated_point_tangent_dimensions':[0,0],'uniform_polynomial_minors_checked':minor_count,'isolated_point_rational_minors_checked':point_minors,'exact_degree_bound_interpolation':True,'all_checks_passed':True}
(R/'h_tangent_independent_verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

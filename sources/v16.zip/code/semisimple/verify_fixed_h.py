#!/usr/bin/env python3
"""Independent standard-library verifier for the fixed-h scheme certificate."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations
import hashlib,json
R=Path(__file__).resolve().parent
from research_paths import v15_geometry_file
S=v15_geometry_file('rnc4_slices.json')
d=json.loads(S.read_text());c=json.loads((R/'fixed_h_certificate.json').read_text())
assert hashlib.sha256(S.read_bytes()).hexdigest()==c['source_sha256']
ids=c['fixed_variable_indices']; pairs=[tuple(x) for x in d['pairs']]
def add(a,b,coef=Q(1)):
 r=a.copy()
 for m,v in b.items():
  r[m]=r.get(m,Q(0))+coef*v
  if not r[m]: del r[m]
 return r

def scale(a,k):return {m:k*v for m,v in a.items() if k*v}
def mult(a,b):
 r={}
 for m,v in a.items():
  for n,w in b.items():
   t=tuple(x+y for x,y in zip(m,n));r[t]=r.get(t,Q(0))+v*w
 return {m:v for m,v in r.items() if v}
def power(a,n):
 r={(0,)*len(next(iter(a))):Q(1)}
 for _ in range(n):r=mult(r,a)
 return r
def derivative(p,i):
 r={}
 for m,v in p.items():
  if m[i]:
   n=list(m);n[i]-=1;r[tuple(n)]=v*m[i]
 return r
def read(p):return {tuple(m):Q(*v) for m,v in p}
def constant(q,n):return {(0,)*n:Q(q)} if q else {}
def var(i,n):
 m=[0]*n;m[i]=1;return {tuple(m):Q(1)}
def expmult(p,m):return {tuple(a+b for a,b in zip(e,m)):v for e,v in p.items()}
def fixed_equation(eq):
 r={}
 for m,v in eq['polynomial']:
  if any(m[i] for i in range(36) if i not in ids):continue
  n=tuple(m[i] for i in ids);r[n]=r.get(n,Q(0))+Q(*v)
 return {m:v for m,v in r.items() if v}
original=[fixed_equation(d['cases']['semisimple']['jacobi_equations'][i]) for i in c['original_equation_indices']]
G=[read(g) for g in c['groebner_basis']]
for g,witness in zip(G,c['membership_certificates']):
 total={}
 for i,m,v in witness:total=add(total,expmult(original[i],tuple(m)),Q(*v))
 assert total==g

def monorder(m):return (sum(m),tuple(-v for v in reversed(m)))
leading=[max(g,key=monorder) for g in G]
def remainder(p):
 p=p.copy();r={}
 while p:
  lead=max(p,key=monorder);value=p[lead]
  for g,lm in zip(G,leading):
   if all(a>=b for a,b in zip(lead,lm)):
    factor=tuple(a-b for a,b in zip(lead,lm));p=add(p,expmult(g,factor),-value/g[lm]);break
  else:r[lead]=p.pop(lead)
 return r
for eq in d['cases']['semisimple']['jacobi_equations']:assert not remainder(fixed_equation(eq))
# Explicit orthogonal idempotents prove the full CRT, without radicalization.
a,b,cc,dd,e,f=[var(i,6) for i in range(6)];one=constant(1,6)
p2=scale(f,Q(-3,2));p1=mult(add(one,scale(f,Q(3,2))),add(one,scale(dd,Q(1,2))));pl=add(add(one,p1,-1),p2,-1)
for p in [pl,p1,p2]:assert not remainder(add(mult(p,p),p,-1))
for p,q in combinations([pl,p1,p2],2):assert not remainder(mult(p,q))
branch_ideals=[
 [add(a,constant(14,6)),add(add(cc,b,-1),constant(-2,6)),add(dd,constant(2,6)),e,f],
 [add(a,constant(16,6)),add(b,constant(Q(1,2),6)),add(cc,constant(Q(1,2),6)),dd,e,f],
 [add(a,constant(Q(38,3),6)),add(b,constant(Q(1,2),6)),add(cc,constant(Q(-5,6),6)),add(dd,constant(Q(4,3),6)),e,add(f,constant(Q(2,3),6))]
]
for idem,ideal in zip([pl,p1,p2],branch_ideals):
 for g in ideal:assert not remainder(mult(idem,g))
# Recompute all Jacobi polynomials on the six-parameter fixed affine space.
P=[[{} for j in range(5)] for i in range(5)]
for k,(i,j) in enumerate(pairs):
 p={tuple(m)+(0,)*6:Q(*v) for m,v in d['cases']['semisimple']['P0_upper'][k]}
 for a,ind in enumerate(ids):
  for m,v in d['common_direction_matrices'][ind][k]:
   z=[0]*6;z[a]=1;n=tuple(m)+tuple(z);p[n]=p.get(n,Q(0))+Q(*v)
 P[i][j]={m:v for m,v in p.items() if v};P[j][i]=scale(P[i][j],-1)
recomputed={}
for i,j,k in combinations(range(5),3):
 jac={}
 for l in range(5):
  jac=add(jac,mult(P[i][l],derivative(P[j][k],l)))
  jac=add(jac,mult(P[j][l],derivative(P[k][i],l)))
  jac=add(jac,mult(P[k][l],derivative(P[i][j],l)))
 for mon,v in jac.items():
  key=((i,j,k),mon[:5]);part=recomputed.setdefault(key,{});part[mon[5:]]=v
expected={}
for eq in d['cases']['semisimple']['jacobi_equations']:
 p=fixed_equation(eq)
 if p:expected[(tuple(eq['triple']),tuple(eq['x_monomial']))]=p
assert recomputed==expected
# Substitute each component and independently verify factorized Pfaff quintics.
x=[var(i,6) for i in range(5)];tt=var(5,6)
branches=[
 [constant(-14,6),tt,add(tt,constant(2,6)),constant(-2,6),{},{}],
 [constant(-16,6),constant(Q(-1,2),6),constant(Q(-1,2),6),{},{},{}],
 [constant(Q(-38,3),6),constant(Q(-1,2),6),constant(Q(5,6),6),constant(Q(-4,3),6),{},constant(Q(-2,3),6)]
]
Q4=add(mult(x[0],x[4]),mult(x[2],x[2]),-1)
L=add(mult(x[0],x[3]),mult(x[1],x[2]),-1)
RR=add(mult(x[1],x[4]),mult(x[2],x[3]),-1)
Cq=add(mult(x[1],x[3]),mult(x[2],x[2]),-1)
H=add(add(add(add(mult(mult(x[0],x[2]),x[4]),mult(x[0],power(x[3],2)),-1),mult(power(x[1],2),x[4]),-1),scale(mult(mult(x[1],x[2]),x[3]),2)),power(x[2],3),-1)
quintics=[scale(mult(x[2],add(mult(add(scale(tt,2),constant(1,6)),power(Q4,2)),scale(mult(L,RR),4))),Q(-1,5)),scale(mult(mult(x[2],Q4),Cq),Q(8,5)),scale(mult(Cq,H),Q(4,45))]
for branch,target in zip(branches,quintics):
 M=[[{} for _ in range(5)] for _ in range(5)]
 for k,(i,j) in enumerate(pairs):
  pp={tuple(m)+(0,):Q(*v) for m,v in d['cases']['semisimple']['P0_upper'][k]}
  for a,ind in enumerate(ids):
   KK={tuple(m)+(0,):Q(*v) for m,v in d['common_direction_matrices'][ind][k]};pp=add(pp,mult(branch[a],KK))
  M[i][j]=pp;M[j][i]=scale(pp,-1)
 result={}
 for k in range(5):
  i,j,l,m=[a for a in range(5) if a!=k]
  pf=add(add(mult(M[i][j],M[l][m]),mult(M[i][l],M[j][m]),-1),mult(M[i][m],M[j][l]))
  result=add(result,mult(x[k],pf),Q((-1)**k,5))
 assert result==target and result
 for i,j,k in combinations(range(5),3):
  jac={}
  for l in range(5):
   jac=add(jac,mult(M[i][l],derivative(M[j][k],l)));jac=add(jac,mult(M[j][l],derivative(M[k][i],l)));jac=add(jac,mult(M[k][l],derivative(M[i][j],l)))
  assert not jac
report={'independent_standard_library_only':True,'source_hash_matched':True,'exact_ideal_equalities_verified':True,'CRT_idempotents_verified':True,'Jacobi_recomputed_from_bivectors':True,'factorized_quintics_verified':True,'all_checks_passed':True}
(R/'fixed_h_independent_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

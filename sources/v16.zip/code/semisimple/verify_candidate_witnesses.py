#!/usr/bin/env python3
"""Independent standard-library checks of candidate consequence certificates."""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations
import re,json,hashlib,time,sys
sys.set_int_max_str_digits(0)
from research_paths import v15_geometry_file,geometry_root
R=Path(__file__).resolve().parent

def add(a,b,c=Q(1)):
 r=a.copy()
 for m,v in b.items():
  z=r.get(m,Q(0))+c*v
  if z:r[m]=z
  elif m in r:del r[m]
 return r
def mul(a,b):
 r={}
 for m,v in a.items():
  for k,w in b.items():
   t=tuple(x+y for x,y in zip(m,k));r[t]=r.get(t,Q(0))+v*w
 return {m:v for m,v in r.items() if v}
def scale(a,c):return {m:v*c for m,v in a.items() if v*c}
def termmul(p,m):return {tuple(a+b for a,b in zip(k,m)):v for k,v in p.items()}
def power(p,n,nvars):
 q={(0,)*nvars:Q(1)}
 for _ in range(n):q=mul(q,p)
 return q
def read(q):return {tuple(m):Q(*v) for m,v in q}
def parse(text,names):
 n=len(names);lookup={name:i for i,name in enumerate(names)};out={}
 for part in re.findall(r'[+-]?[^+-]+',text.replace(' ','')):
  if not part:continue
  sign=-1 if part[0]=='-' else 1;part=part.lstrip('+-');m=[0]*n;c=Q(sign)
  for factor in part.split('*'):
   if not factor:raise ValueError(text)
   if re.fullmatch(r'\d+(?:/\d+)?',factor):c*=Q(factor)
   else:
    v,e=(factor.split('^')+[None])[:2] if '^' in factor else (factor,None)
    assert v in lookup,(v,text);m[lookup[v]]+=int(e) if e is not None else 1
  m=tuple(m);out[m]=out.get(m,Q(0))+c
 return {m:v for m,v in out.items() if v}
def order(m):return(sum(m),tuple(-v for v in reversed(m)))
def reduce_poly(p,gens):
 leading=[max(g,key=order) for g in gens];p=p.copy();remainder={}
 while p:
  lead=max(p,key=order);v=p[lead]
  for g,lm in zip(gens,leading):
   if all(a>=b for a,b in zip(lead,lm)):
    mm=tuple(a-b for a,b in zip(lead,lm));p=add(p,termmul(g,mm),-v/g[lm]);break
  else:remainder[lead]=p.pop(lead)
 return remainder

def verify_substitution(data):
 source=json.loads(v15_geometry_file('rnc4_slices.json').read_text());red=json.loads(v15_geometry_file('rnc4_equation_reduction.json').read_text());us=[read(q) for q in data['geometry_case']['u_polynomials']];n=len(data['parameter_names']);cache={};computed=[]
 for index in red['semisimple']['selected_original_equation_indices']:
  q={}
  for mon,coef in source['cases']['semisimple']['jacobi_equations'][index]['polynomial']:
   active=tuple(i for i,k in enumerate(mon) for _ in range(k))
   if active not in cache:
    p={(0,)*n:Q(1)}
    for i in active:p=mul(p,us[i])
    cache[active]=p
   q=add(q,cache[active],Q(*coef))
  if q and q not in computed:computed.append(q)
 assert computed==[read(q) for q in data['jacobi_equations']]
 return computed

manifest=json.loads((R/'candidate_manifest.json').read_text());results=[];started=time.time()
geometry_cases={row['id']:row for row in json.loads((geometry_root()/'candidate_parameterizations.json').read_text())['cases']}
for case in manifest:
 name=case['id'];data=json.loads((R/'candidates'/(name+'.json')).read_text());names=data['parameter_names'];n=len(names);assert data['geometry_case']==geometry_cases[name];I=verify_substitution(data)
 log=R/'candidates'/(name+'.certificate.log')
 if not log.exists() or 'WITNESS_END' not in log.read_text():
  results.append({'id':name,'status':'awaiting support witness','substitution_verified':True});continue
 text=log.read_text();gb={}
 for line in text.split('GB_BEGIN\n',1)[1].split('GB_END',1)[0].splitlines():
  i,p=line.split('|',1);gb[int(i)-1]=parse(p,names)
 acc={i:{} for i in gb};witness_count=0
 for line in text.split('WITNESS_BEGIN\n',1)[1].split('WITNESS_END',1)[0].splitlines():
  i,j,poly=line.split('|',2);i=int(i)-1;j=int(j)-1;acc[j]=add(acc[j],mul(I[i],parse(poly,names)));witness_count+=1
 assert acc==gb,name
 G=[gb[i] for i in sorted(gb)]
 assert all(not reduce_poly(q,G) for q in I),name
 extra={}
 if name not in ['semisimple_d2_s1t1_diagonal_zero','semisimple_d3_s0t0_linear']:
  powers={}
  for i,symbol in enumerate(names):
   if not symbol.startswith('z'):continue
   m=[0]*n;m[i]=1;v={tuple(m):Q(1)}
   for exponent in [2,4,8,16]:
    if not reduce_poly(power(v,exponent,n),G):powers[symbol]=exponent;break
   assert symbol in powers,(name,symbol)
  for term in ['k0','k2','k1+2/3']:assert not reduce_poly(parse(term,names),G)
  extra['nilpotence_powers']=powers
 elif name=='semisimple_d2_s1t1_diagonal_zero':
  sufficient=['k0','k2','3*k1^2+2*k1','z0^2','z3^2','3*z1*k1-3*z2*k1+2*z1-2*z2','2*z1^2-3*k1-2','2*z2^2-3*k1-2','2*z1*z2+2*z0*z3-3*k1-2']
  for term in sufficient:assert not reduce_poly(parse(term,names),G)
  extra['sufficient_support_constraints']=sufficient
 else:
  extra['hard_GB_verified']=True
 results.append({'id':name,'status':'passed','substitution_verified':True,'ideal_equalities_verified':True,'GB_generators':len(G),'nonzero_witness_entries':witness_count,**extra})
 print(name,'PASS','elapsed',round(time.time()-started,3),flush=True)
 (R/'candidate_independent_verification.json').write_text(json.dumps({'checks':results,'all_21_passed':len(results)==21 and all(x['status']=='passed' for x in results)},indent=2)+'\n')
# Separate degree-six consequence certificates for the two hardest families.
for certificate_file,caseid in [('hard_h_support_witnesses.json','semisimple_d3_s0t0_linear'),('diagonal_h_support_witnesses.json','semisimple_d3_s0t0_diagonal_zero')]:
 path=R/certificate_file
 if not path.exists():continue
 support=json.loads(path.read_text());data=json.loads((R/'candidates'/(caseid+'.json')).read_text());names=data['parameter_names'];I=[read(q) for q in data['jacobi_equations']]
 for index,witness in support['witnesses'].items():
  target=parse(support['target_strings'][index],names);total={}
  for i,mon,v in witness:total=add(total,termmul(I[i],tuple(mon)),Q(*v))
  assert total==target
 print(caseid,'support targets verified',len(support['witnesses']),flush=True)
 if support['all_targets_certified']:
  geometry=data['geometry_case']
  if caseid=='semisimple_d3_s0t0_linear':
   active=[0,7,9]
   def restrict(poly):
    answer={}
    for mon,value in poly.items():
     if any(mon[j] for j in range(len(names)) if j not in active):continue
     mm=tuple(mon[j] for j in active);answer[mm]=answer.get(mm,Q(0))+value
    return {m:v for m,v in answer.items() if v}
   assert restrict(I[3])==parse('2/3*a*b+4/3*k+8/9',['a','b','k'])
   assert restrict(I[17])==parse('-1/2*a*b^3+b^2*k+4/3*b^2',['a','b','k'])
   assert restrict(I[71])==parse('2*a^2*k+2*a^2',['a','b','k'])
   for parameter,index in [('z0',0),('z7',11)]:
    basis=[Q(*v) for v in geometry['v_coefficient_basis'][names.index(parameter)]]
    assert basis==[Q(int(j==index)) for j in range(12)]
  else:
   for j,basis in enumerate(geometry['v_coefficient_basis']):
    values=[Q(*basis[3+4*i]) for i in range(3)]
    assert values==[Q(-int(j==2)),Q(-int(j==5)),Q(0)]
  for row in results:
   if row['id']==caseid:row.update({'status':'passed','one_sided_support_constraints_verified':True,'number_of_constraints':len(support['witnesses'])})
report={'independent_standard_library_only':True,'checks':results,'all_21_passed':len(results)==21 and all(x['status']=='passed' for x in results)}
(R/'candidate_independent_verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'all_21_passed':report['all_21_passed'],'seconds':round(time.time()-started,3)},indent=2))

#!/usr/bin/env python3
"""Independent standard-library exact verifier for the v16 conormal reduction."""
from pathlib import Path
from fractions import Fraction as F
import json

OUT=Path(__file__).resolve().parent
SOURCE=next(p for parent in (OUT,*OUT.parents)
            for folder in ('previous_v15','p4_poisson_completeness_v15')
            if (p:=parent/folder/'code/normal_geometry/rnc4_slices.json').is_file())
source=json.loads(SOURCE.read_text())
geom=json.loads((OUT/'conormal_bracket.json').read_text())
rankone=json.loads((OUT/'rank_one_transvectant.json').read_text())
candidate=json.loads((OUT/'candidate_parameterizations.json').read_text())

def poly(terms):return {tuple(m):F(*c) for m,c in terms if c[0]}
def add(a,b):
    out=a.copy()
    for m,c in b.items():
        out[m]=out.get(m,F(0))+c
        if not out[m]:del out[m]
    return out
def scale(a,c):return {m:c*v for m,v in a.items() if c*v}
def mul(a,b):
    out={}
    for m,c in a.items():
        for n,d in b.items():
            k=tuple(x+y for x,y in zip(m,n));out[k]=out.get(k,F(0))+c*d
    return {k:v for k,v in out.items() if v}
def deriv(a,i):
    out={}
    for m,c in a.items():
        if m[i]:
            mm=list(m);mm[i]-=1;out[tuple(mm)]=c*m[i]
    return out
def evalp(a,x):return sum(c*prod(v**k for v,k in zip(x,m)) for m,c in a.items())
def prod(v):
    r=F(1)
    for x in v:r*=x
    return r
def matmul(A,B):return [[sum(a*b for a,b in zip(row,col)) for col in zip(*B)] for row in A]
def transpose(A):return list(map(list,zip(*A)))
def det(A):
    A=[row[:] for row in A];d=F(1);n=len(A)
    for i in range(n):
        p=next((j for j in range(i,n) if A[j][i]),None)
        if p is None:return F(0)
        if p!=i:A[i],A[p]=A[p],A[i];d=-d
        c=A[i][i];d*=c
        for j in range(i+1,n):
            if A[j][i]:
                r=A[j][i]/c
                for k in range(i+1,n):A[j][k]-=r*A[i][k]
                A[j][i]=F(0)
    return d
def rank(A):
    A=[row[:] for row in A];r=0
    for c in range(len(A[0]) if A else 0):
        p=next((i for i in range(r,len(A)) if A[i][c]),None)
        if p is None:continue
        A[r],A[p]=A[p],A[r];v=A[r][c]
        A[r]=[x/v for x in A[r]]
        for i in range(len(A)):
            if i!=r and A[i][c]:
                v=A[i][c];A[i]=[x-v*y for x,y in zip(A[i],A[r])]
        r+=1
        if r==len(A):break
    return r

L=[[F(0) for _ in range(36)] for _ in range(42)]
for i,j,q in geom['linear_map_sparse']:L[i][j]=F(*q)
T=[[F(0) for _ in range(42)] for _ in range(9)]
for i,j,q in rankone['projection_matrix_sparse']:T[i][j]=F(q)
T_direct=[[F(0) for _ in range(42)] for _ in range(9)]
for col,(i,j,k) in enumerate(geom['coefficient_order']):
    row=k+i+j-1
    value=(1 if i==j else 2)*(6*(i+j)-4*k)
    if value:
        assert 0<=row<=8
        T_direct[row][col]=F(value)
assert T==T_direct
assert matmul(T,L)==[[0]*36 for _ in range(9)]
assert rank(T)==9
rc=candidate['map_rank_certificate']
minor=[[L[i][j] for j in rc['columns']] for i in rc['rows']]
assert det(minor)==F(*rc['determinant'])!=0
kernel=transpose([[F(*q) for q in v] for v in geom['kernel']])
assert rank(kernel)==3 and matmul(L,kernel)==[[0]*3 for _ in range(42)]

# Verify completeness, not just inclusion, of every linear branch basis.
branch_dimensions={}
for row in rankone['cases']:
    d=row['d'];a,b=row['h_exponents'];n=3*(d+1);degree=7-d
    M=[[F(0) for _ in range(n)] for _ in range(2*(degree+1))]
    Qmat=[[F(0) for _ in range(n)] for _ in range(d+3)]
    for i in range(3):
        for j in range(d+1):
            col=i*(d+1)+j;Qmat[i+j][col]=1
            r1=j+i+b;c1=6-3*i-a-2*d+2*j
            r2=j+i+b-1;c2=3*i-b-2*j
            if c1:
                assert 0<=r1<=degree;M[r1][col]=F(c1)
            if c2:
                assert 0<=r2<=degree;M[degree+1+r2][col]=F(c2)
    basis=transpose([[F(q) for q in v] for v in row['basis']]) if row['basis'] else [[] for _ in range(n)]
    dim=len(row['basis'])
    assert rank(M)+dim==n
    assert rank(basis)==dim
    assert matmul(M,basis)==[[0]*dim for _ in M]
    assert rank(matmul(Qmat,basis))==row['Q_image_rank']
    branch_dimensions[(d,a,b)]=dim

# Derive B directly from v15 quadratic P, without SymPy.  Degree is <=14
# before cancellations: two eta-Jacobians (degree<=2 each), dpi along C
# (degree<=8), and normal inverse matrix W (degree<=2). Fifteen rational
# evaluations therefore certify each stored sextic coefficient identity.
fourvars=[{tuple(int(i==j) for i in range(4)):F(1)} for j in range(4)]
def projection_matrix(upper):
    P=[[{} for _ in range(5)] for _ in range(5)]
    for (i,j),term in zip(source['pairs'],upper):
        q={}
        for m,c in poly(term).items():q=add(q,{m[1:]:c})
        P[i][j]=q;P[j][i]=scale(q,-1)
    pi=[[add(add(P[i+1][j+1],scale(mul(fourvars[i],P[0][j+1]),-1)),mul(fourvars[j],P[0][i+1])) for j in range(4)] for i in range(4)]
    return pi
def bracket_at(upper,t):
    pi=projection_matrix(upper);point=[F(t)**i for i in range(1,5)]
    assert all(evalp(q,point)==0 for row in pi for q in row)
    J=[[-2*t,1,0,0],[t*t,-2*t,1,0],[0,t*t,-2*t,1]]
    W=[[0,0,0],[1,0,0],[2*t,1,0],[3*t*t,2*t,1]]
    derivatives=[[[evalp(deriv(pi[i][j],k),point) for k in range(4)] for j in range(4)] for i in range(4)]
    B=[[F(0) for _ in range(3)] for _ in range(3)]
    for r,(a,b) in enumerate(((1,2),(2,0),(0,1))):
        for k in range(3):
            B[r][k]=sum(J[a][i]*derivatives[i][j][l]*W[l][k]*J[b][j] for i in range(4) for j in range(4) for l in range(4))
    return B
def target_at(coeff,t):
    B=[[F(0) for _ in range(3)] for _ in range(3)]
    for (i,j,k),c in zip(geom['coefficient_order'],coeff):B[i][j]+=c*F(t)**k
    for i in range(3):
        for j in range(i):B[i][j]=B[j][i]
    return B
items=[(f'direction_{a}',upper,[L[i][a] for i in range(42)]) for a,upper in enumerate(source['common_direction_matrices'])]
items += [(name,case['P0_upper'],[F(*q) for q in geom['cases'][name]['B0_coefficients']]) for name,case in source['cases'].items()]
for name,upper,coeff in items:
    for t in range(15):assert bracket_at(upper,t)==target_at(coeff,t),(name,t)

# Verify every stored u-polynomial solves L*u=h*v*v^t-B0 identically.
for case in candidate['cases']:
    d=case['d'];a,b=case['h_exponents'];n=case['number_of_parameters'];zcount=n-3
    zero=(0,)*n
    us=[poly(q) for q in case['u_polynomials']]
    vv=[[{} for _ in range(d+1)] for _ in range(3)]
    for z,vec in enumerate(case['v_coefficient_basis']):
        mon=tuple(int(j==z) for j in range(n))
        for i in range(3):
            for k in range(d+1):
                if F(*vec[i*(d+1)+k]):vv[i][k][mon]=F(*vec[i*(d+1)+k])
    v_basis=transpose([[F(*q) for q in v] for v in case['v_coefficient_basis']])
    assert rank(v_basis)==zcount
    if case['branch']=='linear':
        assert zcount==branch_dimensions[(d,a,b)]
    else:
        assert zcount==2*d
        Qmat=[[F(0) for _ in range(3*(d+1))] for _ in range(d+3)]
        for i in range(3):
            for j in range(d+1):Qmat[i+j][i*(d+1)+j]=1
        assert rank(Qmat)+zcount==3*(d+1)
        assert matmul(Qmat,v_basis)==[[0]*zcount for _ in Qmat]
    B0=[F(*q) for q in geom['cases'][case['residue']]['B0_coefficients']]
    for row,(i,j,k) in enumerate(geom['coefficient_order']):
        lhs={}
        for c,q in zip(L[row],us):lhs=add(lhs,scale(q,c))
        rhs={zero:-B0[row]} if B0[row] else {}
        for p in range(d+1):
            for q in range(d+1):
                if b+p+q==k:rhs=add(rhs,mul(vv[i][p],vv[j][q]))
        assert lhs==rhs,(case['id'],row)
    assert len(case['u_polynomials'])==36

assert len(candidate['cases'])==28
assert sum(x['residue']=='semisimple' for x in candidate['cases'])==21
assert sum(x['residue']=='nilpotent' for x in candidate['cases'])==7
result={'all_passed':True,'arithmetic':'Python standard-library fractions.Fraction only',
        'conormal_map_rank':33,'conormal_map_kernel_dimension':3,
        'conormal_map_exact_minor':str(F(*rc['determinant'])),
        'projection_rank':9,'conormal_matrices_independently_derived':len(items),
        'projection_direct_coefficient_formula_verified':True,
        'rational_evaluations_per_matrix':15,'polynomial_degree_bound':14,
        'candidate_families_verified':28,'semisimple_families':21,'nilpotent_families':7,
        'all_branch_bases_verified_complete':True,
        'maximum_parameters':11,'full_Jacobi_claimed':False}
(OUT/'geometry_independent_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

#!/usr/bin/env python3
"""Finite necessary parametrization of all prospective normal RNC4 E8 points.

This parametrizes closed points under the geometric hypotheses. It is NOT an
isomorphism of the full 36-variable scheme, and does not itself assert Poisson.
"""
from pathlib import Path
import json
import sympy as sp

OUT=Path(__file__).resolve().parent
DATA=next(p for parent in (OUT,*OUT.parents)
          for folder in ('previous_v15','p4_poisson_completeness_v15')
          if (p:=parent/folder/'code/normal_geometry/rnc4_slices.json').is_file())

def rat(q): return sp.Rational(q[0],q[1])
def frac(q):
    q=sp.Rational(q);return [int(q.p),int(q.q)]
def encode(f,vs):
    return [[list(m),frac(c)] for m,c in sp.Poly(f,*vs).terms() if c]
def decode(terms,vs):
    return sum(rat(c)*sp.prod(v**a for v,a in zip(vs,m)) for m,c in terms)

def build_data():
    geom=json.loads((OUT/'conormal_bracket.json').read_text())
    rankone=json.loads((OUT/'rank_one_transvectant.json').read_text())
    s,t=sp.symbols('s t')
    L=sp.zeros(42,36)
    for i,j,q in geom['linear_map_sparse']:L[i,j]=rat(q)
    cols=list(L.rref()[1]); rows=list(L[:,cols].T.rref()[1])
    minor=L.extract(rows,cols); inv=minor.inv()
    K=sp.Matrix.hstack(*[sp.Matrix([rat(x) for x in v]) for v in geom['kernel']])
    assert K.shape==(36,3) and L*K==sp.zeros(42,3)
    result={'status':'exhaustive necessary closed-point parametrization under normal RNC4 E8 hypotheses; full Jacobi and normality remain to impose',
            'map_rank_certificate':{'rows':rows,'columns':cols,'determinant':frac(minor.det())},
            'cases':[]}
    for rr in rankone['cases']:
        d=rr['d']; a,b=rr['h_exponents']; h=s**a*t**b
        for branch in ('diagonal_zero','linear'):
            if branch=='diagonal_zero':
                if not d: continue
                basis=[]
                for which in range(2):
                    for k in range(d):
                        f=s**(d-1-k)*t**k
                        vv=(-t*f,s*f,0) if which==0 else (0,-t*f,s*f)
                        basis.append(sp.Matrix([sp.expand(z).coeff(s,d-i).coeff(t,i) for z in vv for i in range(d+1)]))
            else:
                if rr['Q_image_rank']==0: continue
                basis=[sp.Matrix([sp.Rational(z) for z in v]) for v in rr['basis']]
            params=sp.symbols(f'z0:{len(basis)}')
            kvals=sp.symbols('k0:3'); variables=params+kvals
            vec=sum((q*v for q,v in zip(params,basis)),sp.zeros(3*(d+1),1))
            v=sp.Matrix([sum(vec[j*(d+1)+k]*s**(d-k)*t**k for k in range(d+1)) for j in range(3)])
            B=h*v*v.T
            Bcoeff=sp.Matrix([sp.expand(B[i,j]).coeff(s,6-k).coeff(t,k) for i,j,k in geom['coefficient_order']])
            for residue in ('semisimple','nilpotent'):
                if residue=='nilpotent' and b!=0:continue
                B0=sp.Matrix([rat(q) for q in geom['cases'][residue]['B0_coefficients']])
                rhs=Bcoeff-B0
                solution=sp.zeros(36,1)
                selected=inv*rhs.extract(rows,[0])
                for row,val in zip(cols,selected): solution[row]=sp.expand(val)
                solution+=K*sp.Matrix(kvals)
                solution=solution.applyfunc(sp.expand)
                assert (L*solution-rhs).applyfunc(sp.expand)==sp.zeros(42,1)
                caseid=f'{residue}_d{d}_s{a}t{b}_{branch}'
                result['cases'].append({'id':caseid,'residue':residue,'d':d,'h_exponents':[a,b],
                    'branch':branch,'parameter_names':[str(z) for z in variables],
                    'number_of_parameters':len(variables),'v':[str(z) for z in v],
                    'v_coefficient_basis':[[frac(z) for z in vv] for vv in basis],
                    'u_polynomials':[encode(z,variables) for z in solution],
                    'Q_nonzero_required':branch=='linear',
                    'additional_conditions':'v nonzero and primitive; full Jacobi; F nonzero; normal divisor; radical(J_F)=I_RNC4'})
                print(caseid,'parameters',len(variables),flush=True)
    result['number_of_families']=len(result['cases'])
    result['max_number_of_parameters']=max(x['number_of_parameters'] for x in result['cases'])
    (OUT/'candidate_parameterizations.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
    print('TOTAL',len(result['cases']),'MAX PARAMETERS',result['max_number_of_parameters'],flush=True)
    return result

def build_candidate(caseid):
    """Return variables, 5x5 polynomial P, and metadata for one stored family."""
    data=json.loads(DATA.read_text())
    params=json.loads((OUT/'candidate_parameterizations.json').read_text())
    row=next(c for c in params['cases'] if c['id']==caseid)
    x=sp.symbols('x0:5')
    variables=sp.symbols(' '.join(row['parameter_names']))
    us=[decode(f,variables) for f in row['u_polynomials']]
    def xp(terms):return decode(terms,x)
    pairs=[tuple(v) for v in data['pairs']]
    P=sp.zeros(5)
    initial=data['cases'][row['residue']]['P0_upper']
    for k,(i,j) in enumerate(pairs):
        f=xp(initial[k])+sum(us[z]*xp(data['common_direction_matrices'][z][k]) for z in range(36))
        P[i,j]=sp.expand(f);P[j,i]=-P[i,j]
    return x,variables,P,row

if __name__=='__main__':build_data()

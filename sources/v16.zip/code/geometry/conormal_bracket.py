#!/usr/bin/env python3
"""Exact conormal Lie-bracket map for the two v15 RNC4 affine slices."""
from pathlib import Path
import json
import sympy as sp

OUT=Path(__file__).resolve().parent
SOURCE=next(p for parent in (OUT,*OUT.parents)
            for folder in ('previous_v15','p4_poisson_completeness_v15')
            if (p:=parent/folder/'code/normal_geometry/rnc4_slices.json').is_file())
data=json.loads(SOURCE.read_text())
x=sp.symbols('x0:5'); t=sp.symbols('t'); z=sp.symbols('z0:3')
pairs=[tuple(v) for v in data['pairs']]

def poly(terms):
    return sum(sp.Rational(c[0],c[1])*sp.prod(xi**mi for xi,mi in zip(x,m)) for m,c in terms)

def matrix(terms):
    P=sp.zeros(5)
    for ij,term in zip(pairs,terms):
        i,j=ij; P[i,j]=poly(term); P[j,i]=-P[i,j]
    return P

eta=[x[2]-x[1]**2,
     x[3]-2*x[1]*x[2]+x[1]**3,
     x[4]-2*x[1]*x[3]+x[1]**2*x[2]]
J=sp.Matrix([[sp.diff(a,x[i]) for i in range(1,5)] for a in eta])
curve={x[1]:t,x[2]:t*t,x[3]:t**3,x[4]:t**4}
# Derivative of y=(t,y2,y3,y4) with respect to balanced conormal coordinates z.
W=sp.Matrix([[0,0,0],[1,0,0],[2*t,1,0],[3*t*t,2*t,1]])

def conormal(P):
    pi=sp.Matrix(4,4,lambda i,j:sp.expand(P[i+1,j+1]-x[i+1]*P[0,j+1]+x[j+1]*P[0,i+1]).subs(x[0],1))
    assert pi.subs(curve).applyfunc(sp.expand)==sp.zeros(4)
    vals=J*pi*J.T
    B=sp.zeros(3)
    for r,(a,b) in enumerate([(1,2),(2,0),(0,1)]):
        f=sp.expand(vals[a,b])
        assert sp.expand(f.subs(curve))==0
        grad=sp.Matrix(1,4,lambda _,i:sp.diff(f,x[i+1]).subs(curve))
        for k in range(3):
            B[r,k]=sp.expand((grad*W)[k])
    assert B==B.T
    assert all(sp.degree(v,t)<=6 for v in B if v)
    return B

def vector(B):
    return sp.Matrix([sp.expand(B[i,j]).coeff(t,k) for i in range(3) for j in range(i,3) for k in range(7)])

def rational(v):
    q=sp.Rational(v);return [int(q.p),int(q.q)]

K=[matrix(a) for a in data['common_direction_matrices']]
B_K=[conormal(P) for P in K]
L=sp.Matrix.hstack(*[vector(B) for B in B_K])
rank=L.rank(); ker=L.nullspace(); left=L.T.nullspace()
print('Conormal bracket map',L.shape,'rank',rank,'kernel',len(ker),'cokernel',len(left),flush=True)
out={'basis_definition':['eta0=y2-y1^2','eta1=y3-2*y1*y2+y1^3','eta2=y4-2*y1*y3+y1^2*y2'],
     'balanced_conormal_frame':'beta_i=t^2 dx_i-2 st dx_(i+1)+s^2 dx_(i+2), i=0,1,2',
     'coefficient_order':[[i,j,k] for i in range(3) for j in range(i,3) for k in range(7)],
     'matrix_shape':list(L.shape),'rank':rank,
     'linear_map_sparse':[[i,j,rational(L[i,j])] for i in range(42) for j in range(36) if L[i,j]],
     'kernel':[[rational(v) for v in vv] for vv in ker],
     'left_kernel':[[rational(v) for v in vv] for vv in left],
     'direction_bracket_matrices':[[str(z) for z in B] for B in B_K],
     'cases':{}}
for name,entry in data['cases'].items():
    B=conormal(matrix(entry['P0_upper']))
    v=vector(B)
    conditions=[sp.expand((r.T*v)[0]) for r in left]
    print(name,'B0',B,'constraints rhs',conditions,flush=True)
    out['cases'][name]={'B0':[[str(z) for z in B.row(i)] for i in range(3)],
                        'B0_coefficients':[rational(z) for z in v],
                        'linear_conditions_rhs':[rational(z) for z in conditions]}
(OUT/'conormal_bracket.json').write_text(json.dumps(out,indent=2)+'\n')

#!/usr/bin/env python3
"""Identify nine linear jet relations and factor their rank-one restriction."""
from pathlib import Path
import json
import sympy as sp

OUT=Path(__file__).resolve().parent
data=json.loads((OUT/'conormal_bracket.json').read_text())
s,t,u,v=sp.symbols('s t u v')
order=data['coefficient_order']
L=sp.zeros(42,36)
for i,j,q in data['linear_map_sparse']:L[i,j]=sp.Rational(*q)

def project(i,j,k):
    b=sp.zeros(3);b[i,j]=s**(6-k)*t**k;b[j,i]=b[i,j]
    quartic=b[0,0]*u**4+2*b[0,1]*u**3*v+(2*b[0,2]+b[1,1])*u**2*v**2+2*b[1,2]*u*v**3+b[2,2]*v**4
    z=sp.expand(sp.diff(quartic,s,v)-sp.diff(quartic,t,u))
    z=sp.expand(z.subs({u:s,v:t},simultaneous=True))
    return [z.coeff(s,8-a).coeff(t,a) for a in range(9)]

T=sp.Matrix.hstack(*[sp.Matrix(project(*a)) for a in order])
print('Projection rank',T.rank(),'annihilates map',(T*L==sp.zeros(9,36)),flush=True)
assert T.rank()==9 and T*L==sp.zeros(9,36)
for name,row in data['cases'].items():
    vec=sp.Matrix([sp.Rational(*z) for z in row['B0_coefficients']])
    assert T*vec==sp.zeros(9,1)

cases=[]
for d in range(4):
    av=sp.symbols(f'a0:{d+1}');bv=sp.symbols(f'b0:{d+1}');cv=sp.symbols(f'c0:{d+1}')
    variables=av+bv+cv
    aa=sum(av[k]*s**(d-k)*t**k for k in range(d+1))
    bb=sum(bv[k]*s**(d-k)*t**k for k in range(d+1))
    cc=sum(cv[k]*s**(d-k)*t**k for k in range(d+1))
    q=aa*u*u+bb*u*v+cc*v*v
    Q=sp.expand(q.subs({u:s,v:t},simultaneous=True))
    R0=2*aa*s+bb*t;R1=bb*s+2*cc*t
    # Q=0 is always a solution of the rank-one projection equations.
    for a in range(7-2*d):
        b=6-2*d-a
        h=s**a*t**b
        expr=sp.expand((sp.diff(h*q*q,s,v)-sp.diff(h*q*q,t,u)).subs({u:s,v:t},simultaneous=True))
        closed=sp.expand(sp.diff(h*Q*R1,s)-sp.diff(h*Q*R0,t))
        assert expr==2*closed
        # The open Q!=0 branch is exactly 5*h*R=Q*dh+2*h*dQ.
        A=sp.Poly(sp.expand(5*h*R0-Q*sp.diff(h,s)-2*h*sp.diff(Q,s)),s,t)
        B=sp.Poly(sp.expand(5*h*R1-Q*sp.diff(h,t)-2*h*sp.diff(Q,t)),s,t)
        equations=A.coeffs()+B.coeffs()
        M=sp.Matrix([[sp.expand(eq).coeff(z) for z in variables] for eq in equations])
        null=M.nullspace()
        Qmat=sp.Matrix([[sp.expand(sp.Poly(Q,s,t).coeff_monomial(s**(d+2-k)*t**k)).coeff(z) for z in variables] for k in range(d+3)])
        # Some linear-solution vectors may themselves have Q=0; preserve this distinction.
        cols=sp.Matrix.hstack(*null) if null else sp.zeros(len(variables),0)
        qrank=(Qmat*cols).rank()
        cases.append({'d':d,'h_exponents':[a,b],'linear_branch_dimension':len(null),
                      'Q_image_rank':qrank,'basis':[[str(z) for z in vec] for vec in null]})
        print('d',d,'h',a,b,'dim',len(null),'Q rank',qrank,flush=True)

out={'projection_rank':9,'projection_annihilates_full_direction_map':True,
     'projection_matrix_sparse':[[i,j,int(T[i,j])] for i in range(9) for j in range(42) if T[i,j]],
     'convention':'q=a(s,t)u²+b(s,t)uv+c(s,t)v²; Q=q(s,t;s,t); R=(q_u,q_v)|diagonal',
     'rank_one_identity':'Projection(h v v^T)=2*(d_s(h Q R_v)-d_t(h Q R_u))',
     'Q_nonzero_equivalence':'5 h R_i = Q partial_i h + 2 h partial_i Q',
     'cases':cases}
(OUT/'rank_one_transvectant.json').write_text(json.dumps(out,indent=2)+'\n')

#!/usr/bin/env python3
"""Additional necessary E8 isotropy conditions for the hard d=3 branches."""
from pathlib import Path
import json
import sympy as sp
from parameterize_candidates import DATA,decode,encode,build_candidate

OUT=Path(__file__).resolve().parent
data=json.loads(DATA.read_text());params=json.loads((OUT/'candidate_parameterizations.json').read_text())
x=sp.symbols('x0:5');t=sp.symbols('t')
pairs=[tuple(z) for z in data['pairs']]
curve={x[1]:t,x[2]:t*t,x[3]:t**3,x[4]:t**4}
W=sp.Matrix([[0,0,0],[1,0,0],[2*t,1,0],[3*t*t,2*t,1]])
J=sp.Matrix([[-2*t,1,0,0],[t*t,-2*t,1,0],[0,t*t,-2*t,1]])

def matrix(upper):
    P=sp.zeros(5)
    for (i,j),terms in zip(pairs,upper):P[i,j]=decode(terms,x);P[j,i]=-P[i,j]
    return P

def firstA(P):
    pi=sp.Matrix(4,4,lambda i,j:sp.expand(P[i+1,j+1]-x[i+1]*P[0,j+1]+x[j+1]*P[0,i+1]).subs(x[0],1))
    A=sp.zeros(3)
    for i in range(3):
        for k in range(3):
            A[i,k]=sp.expand(sum(sp.diff(pi[0,j],x[l+1]).subs(curve)*J[i,j]*W[l,k] for j in range(4) for l in range(4)))
    return A

A_K=[firstA(matrix(upper)) for upper in data['common_direction_matrices']]
A0={name:firstA(matrix(row['P0_upper'])) for name,row in data['cases'].items()}
assert all(sp.trace(A)==0 for A in A_K)
assert sp.trace(A0['semisimple'])==2*t
assert sp.trace(A0['nilpotent'])==-1
out={'source':'normal first jet {t,eta_i}=sum A_ij eta_j','max_degree_A_directions':int(max(sp.degree(z,t) for A in A_K for z in A if z)),
     'direction_matrices':[[str(z) for z in A] for A in A_K],
     'initial_matrices':{name:[[str(z) for z in A.row(i)] for i in range(3)] for name,A in A0.items()},'cases':{}}
for row in params['cases']:
    if row['d']!=3 or row['branch']!='linear':continue
    vs=sp.symbols(' '.join(row['parameter_names']));env={str(z):z for z in vs};env.update({'s':sp.Integer(1),'t':t})
    us=[decode(q,vs) for q in row['u_polynomials']]
    A=A0[row['residue']].copy()
    for u,K in zip(us,A_K):A+=u*K
    A=A.applyfunc(sp.expand)
    Z=-2*t if row['residue']=='semisimple' else sp.Integer(1)
    v=sp.Matrix([sp.sympify(z,locals=env) for z in row['v']])
    center=(A.T*v+Z*v/2).applyfunc(sp.expand)
    char=sp.expand(sp.trace(A*A)-sp.Rational(7,18)*Z**2)
    equations=[]
    for idx,expr in enumerate(center):
        for (power,),coef in sp.Poly(expr,t).terms():
            if coef:equations.append({'kind':'center','entry':idx,'t_power':power,'polynomial':encode(coef,vs)})
    for (power,),coef in sp.Poly(char,t).terms():
        if coef:equations.append({'kind':'trace_square','t_power':power,'polynomial':encode(coef,vs)})
    out['cases'][row['id']]={'parameters':row['parameter_names'],'equations':equations,
                             'A_matrix':[[str(z) for z in A.row(i)] for i in range(3)],
                             'v':[str(z) for z in v],'Z':str(Z)}
    print(row['id'],'E8necessaryequations',len(equations),'degrees',sorted({sum(m) for e in equations for m,c in e['polynomial']}),flush=True)
    if row['residue']=='semisimple':
        aa=sp.symbols('a',nonzero=True)
        sub={vs[0]:aa,vs[7]:sp.Rational(2,3)/aa,vs[8]:0,vs[9]:-1,vs[10]:0}
        sub.update({vs[i]:0 for i in range(1,7)})
        AF=A.subs(sub).applyfunc(sp.factor)
        centerF=center.subs(sub).applyfunc(sp.factor)
        charF=sp.factor(char.subs(sub))
        print('NEW FAMILY A=',AF,'center=',centerF,'trace square obstruction=',charF,flush=True)
        out['semisimple_primitive_family']={'v':['a*s^3','0','2*t^3/(3*a)'],'kernel':[0,-1,0],
            'A':[[str(z) for z in AF.row(i)] for i in range(3)],'center':[str(z) for z in centerF],
            'trace_square_E8_obstruction':str(charF),'A_characteristic_polynomial':str(AF.charpoly().as_expr().factor())}
(OUT/'first_jet_E8.json').write_text(json.dumps(out,separators=(',',':'))+'\n')

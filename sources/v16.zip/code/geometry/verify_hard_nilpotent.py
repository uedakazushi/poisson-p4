#!/usr/bin/env python3
"""Independent QQ verification of three one-sided hard nilpotent consequences.

Uses only the standard library.  Rebuilds the candidate Jacobi generators
from the preserved v15 equations and v16 parameterization, then verifies
each supplied sum-of-multiples identity directly.  No Groebner software or
finite-field computation is used.
"""
from pathlib import Path
from fractions import Fraction as Q
import argparse, ast, hashlib, json, time

ROOT = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument('--nilpotent', type=Path, default=ROOT.parent/'nilpotent')
args = ap.parse_args()
NIL = args.nilpotent
SOURCE = next(p for parent in (ROOT, *ROOT.parents)
              for folder in ('previous_v15', 'p4_poisson_completeness_v15')
              if (p := parent/folder/'code/normal_geometry/rnc4_slices.json').is_file())
case_id = 'nilpotent_d3_s0t0_linear'
case = next(c for c in json.loads((ROOT/'candidate_parameterizations.json').read_text())['cases']
            if c['id'] == case_id)
names = case['parameter_names']
n = len(names)
one = {(0,)*n: Q(1)}

def decode(raw):
    return {tuple(m): Q(*c) for m, c in raw if c[0]}

def add(a, b, scale=Q(1)):
    out = a.copy()
    for m, c in b.items():
        v = out.get(m, Q(0)) + scale*c
        if v: out[m] = v
        elif m in out: del out[m]
    return out

def mul(a, b):
    out = {}
    for m, c in a.items():
        for k, d in b.items():
            mk = tuple(x+y for x, y in zip(m, k))
            out[mk] = out.get(mk, Q(0)) + c*d
    return {m: c for m, c in out.items() if c}

def parse(s):
    def rec(a):
        if isinstance(a, ast.Constant):
            assert isinstance(a.value, int)
            return {(0,)*n: Q(a.value)} if a.value else {}
        if isinstance(a, ast.Name):
            m = [0]*n; m[names.index(a.id)] = 1
            return {tuple(m): Q(1)}
        if isinstance(a, ast.UnaryOp):
            q = rec(a.operand)
            return {m: (-c if isinstance(a.op, ast.USub) else c) for m, c in q.items()}
        left, right = rec(a.left), rec(a.right)
        if isinstance(a.op, ast.Add): return add(left, right)
        if isinstance(a.op, ast.Sub): return add(left, right, -1)
        if isinstance(a.op, ast.Mult): return mul(left, right)
        if isinstance(a.op, ast.Div):
            assert list(right) == [(0,)*n]
            return {m: c/right[(0,)*n] for m, c in left.items()}
        if isinstance(a.op, ast.Pow):
            assert list(right) == [(0,)*n]
            exponent = right[(0,)*n]
            assert exponent.denominator == 1 and exponent >= 0
            out = one
            for _ in range(int(exponent)): out = mul(out, left)
            return out
        raise ValueError(s)
    return rec(ast.parse(s.replace('^', '**'), mode='eval').body)

start = time.time()
source = json.loads(SOURCE.read_text())
reduction = json.loads(SOURCE.with_name('rnc4_equation_reduction.json').read_text())
u = [decode(p) for p in case['u_polynomials']]
product_cache = {(0,)*36: one}
def monomial_substitution(m):
    m = tuple(m)
    if m not in product_cache:
        out = one
        for i, exponent in enumerate(m):
            for _ in range(exponent): out = mul(out, u[i])
        product_cache[m] = out
    return product_cache[m]

rebuilt = []
seen = set()
for index in reduction['nilpotent']['selected_original_equation_indices']:
    out = {}
    for m, c in source['cases']['nilpotent']['jacobi_equations'][index]['polynomial']:
        out = add(out, monomial_substitution(m), Q(*c))
    key = tuple(sorted(out.items()))
    if out and key not in seen:
        rebuilt.append(out); seen.add(key)

provided = json.loads((NIL/'nilpotent_d3_linear_data.json').read_text())
assert provided['parameter_names'] == names
qs = [decode(p) for p in provided['jacobi_equations']]
assert qs == rebuilt
raw = (NIL/(case_id+'.sing')).read_text().split('ideal I=', 1)[1].split(';', 1)[0]
assert [parse(s.strip()) for s in raw.split(',') if s.strip()] == rebuilt
print('Original v15 substitutions and Singular source agree:', len(qs), 'equations', flush=True)

verified = []
for file in (NIL/'hard_e_support_witnesses_part1.json', ROOT/'nilpotent_weight_minus4_witness.json'):
    cert = json.loads(file.read_text())
    assert cert['parameter_names'] == names and cert['source_candidate'] == case_id
    assert cert['all_targets_certified']
    for index, terms in cert['witnesses'].items():
        target_string = cert['target_strings'][index]
        target = parse(target_string)
        total = {}
        for source_index, monomial, coefficient in terms:
            assert len(monomial) == n and all(isinstance(v, int) and v >= 0 for v in monomial)
            assert sum(monomial) <= 2
            shifted = {tuple(x+y for x, y in zip(m, monomial)): c for m, c in qs[source_index].items()}
            total = add(total, shifted, Q(*coefficient))
        assert total == target
        verified.append({'target': target_string, 'summands': len(terms),
                         'certificate_sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
        print('Verified:', target_string, 'summands:', len(terms), flush=True)

assert {x['target'] for x in verified} == {'z7^2', 'z6^2', '(z3-4*z5)^2'}
report = {'status': 'all exact QQ identities verified independently',
          'source_rebuilt_from_v15': True, 'singular_source_agrees': True,
          'generator_count': len(qs), 'targets': verified,
          'conclusion': 'every closed point has v(0,1)=0; no primitive degree-three v remains',
          'seconds': round(time.time()-start, 3)}
(ROOT/'hard_nilpotent_independent_verification.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))

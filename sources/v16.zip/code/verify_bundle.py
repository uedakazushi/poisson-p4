#!/usr/bin/env python3
"""Read-only verification of the v16 archive and unchanged v15 history."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    expected = {}
    for line in (ROOT / "SHA256SUMS.txt").read_text().splitlines():
        value, name = line.split("  ", 1)
        expected[name] = value
    actual = {p.relative_to(ROOT).as_posix(): digest(p) for p in ROOT.rglob("*")
              if p.is_file() and p != ROOT / "SHA256SUMS.txt"
              and "__pycache__" not in p.parts and p.suffix != ".pyc"}
    assert actual == expected, "Current archive differs from SHA256SUMS.txt"
    history = json.loads((ROOT / "data/previous_v15_preservation.json").read_text())
    old_root = ROOT / "previous_v15"
    old = {p.relative_to(old_root).as_posix(): digest(p)
           for p in old_root.rglob("*") if p.is_file()}
    assert old == history["files"], "Historical v15 files changed"
    assert len(old) == history["file_count"] == 1131
    print(json.dumps({"all_passed": True, "all_files_verified": len(actual),
                      "historical_files_verified": len(old)}, indent=2))


if __name__ == "__main__":
    main()

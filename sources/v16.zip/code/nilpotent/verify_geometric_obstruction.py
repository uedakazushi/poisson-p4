"""Exact QQ checks for the exceptional nilpotent candidate family."""
from pathlib import Path
import sys,json,hashlib,argparse
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--geometry',type=Path,required=True);ap.add_argument('--output',type=Path);args=ap.parse_args()
sys.path.insert(0,str(args.geometry.resolve()))
import sympy as s
from parameterize_candidates import build_candidate
ROOT=Path(__file__).resolve().parent
x,vs,P,meta=build_candidate('nilpotent_d2_s2t0_diagonal_zero')
z0,z1,z2,z3,k0,k1,k2=vs;a,b=s.symbols('a b');pairs=[(i,j) for i in range(5) for j in range(i+1,5)]
def reduced(f,relation):return s.rem(s.expand(f),relation,b).expand()
def quintic(Q,red):
 pf=[]
 for i in range(5):
  j,k,l,m=[j for j in range(5) if j!=i]
  pf.append(red((-1)**i*(Q[j,k]*Q[l,m]-Q[j,l]*Q[k,m]+Q[j,m]*Q[k,l])))
 F=red(sum(x[i]*pf[i] for i in range(5))/5)
 assert all(red(s.diff(F,x[i])-pf[i])==0 for i in range(5))
 return F
# Isolated nonreduced case.
red1=lambda f:reduced(f,b*b-s.Rational(1,20))
P1=P.subs({z0:0,z1:-b,z2:b,z3:0,k0:0,k1:0,k2:-s.Rational(6,5)},simultaneous=True).applyfunc(red1)
F1=quintic(P1,red1);q=x[0]*x[4]-4*x[1]*x[3]+3*x[2]**2
assert s.expand(F1+x[0]*q*q/200)==0
# Non-invariant Ga family.
red2=lambda f:reduced(f,b*b+s.Rational(2,3))
P2=P.subs({z0:a,z1:s.Rational(3,2)*b,z2:b,z3:0,k0:0,k1:0,k2:-s.Rational(1,2)},simultaneous=True).applyfunc(red2)
F2=quintic(P2,red2);F0=F2.subs(a,0)
e=s.Matrix([0,x[0],2*x[1],3*x[2],4*x[3]])
De=lambda f:s.expand(sum(e[i]*s.diff(f,x[i]) for i in range(5)))
D1=De(F0);D2=De(D1);assert De(D2)==0
c=-s.Rational(3,5)*a*b
assert red2(F2-F0-c*D1-c*c*D2/2)==0
r,t=s.symbols('r t');surface={x[0]:1,x[1]:r,x[2]:t,x[3]:(4*r**3-r*t)/3,x[4]:r*r*t}
assert s.expand(F0.subs(surface,simultaneous=True))==0
assert all(s.expand(s.diff(F0,z).subs(surface,simultaneous=True))==0 for z in x)
# Polynomial resultant identity controlling k2 in the diagonal case.
k=s.symbols('k');w=(330*k**3-409*k**2-2311*k-1572)/840
identity=(11*k+58)*w+84*k*k+196*k+112-s.Rational(121,840)*(k+1)*(2*k+1)*(3*k+4)*(5*k+6)
assert s.expand(identity)==0
out={'all_passed':True,'isolated_nonreduced_F':str(s.factor(F1)),'Ga_F0':str(F0),'Ga_family_F':str(F2),'Ga_parameter':str(c),'Ga_parameter_relation':'b^2=-2/3','third_derivative_zero':True,'uniform_Ga_identity':True,'singular_surface':{str(z):str(v) for z,v in surface.items()},'surface_dimension_reason':'x1=r and x2=t are independent affine parameters','all_five_partial_derivatives_vanish':True,'k2_projection_roots':['-1','-4/3','-6/5','-1/2'],'projection_identity_verified':True,'Ga_family_P_upper':[str(P2[i,j]) for i,j in pairs]}
if args.output:args.output.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['Ga_family_F','Ga_family_P_upper']},indent=2))

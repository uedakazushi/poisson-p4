NILPOTENT PART OF THE V16 RNC4 EXCLUSION
=======================================

Copy these final files to code/nilpotent (or another single directory):

PROOF_NOTE.txt
README_final.txt
nilpotent_support_certificates.json
verify_nilpotent_support.py
nilpotent_support_verification.json
verify_geometric_obstruction.py
geometric_obstruction_verification.json
nilpotent_invariant_certificate.json
verify_invariant_slice.py
invariant_slice_verification.json

These ten files are sufficient for the mathematical statements and all their
checks. The other files in the work directory are construction/diagnostic
history, including timed-out or rejected exploratory Groebner calculations;
they are not proof dependencies.

The support proof consists of 23 explicit one-sided QQ ideal-membership
identities for the seven necessary nilpotent parameterizations. The checker
rebuilds the original Jacobi substitutions from the preserved v15 source and
checks every identity using fractions.Fraction. It does not call any CAS,
compute a Groebner basis, take a radical, or use finite fields.

The geometric checker verifies the only non-invariant residual family:
its quintics are a Ga orbit of F0, and F0 is singular on an explicitly
parametrized surface. The isolated remaining nonzero quintic is x0*q^2
up to a nonzero scalar. Thus these cases cannot have a normal divisor.

The independent appendix classifies the additional symmetry locus
Lie(A_e,P)=0: three reduced points, each isolated and reduced also in the
full 36-variable prescribed-residue slice. Its certificate contains two
explicit ideal-inclusion matrices and three nonzero 36-by-36 determinants.
The checker uses SymPy for exact polynomial arithmetic and determinants;
it does not compute a Groebner basis.

Example commands from the bundle root (replace code/geometry if needed):

python3 code/nilpotent/verify_nilpotent_support.py \
  --source previous_v15/code/normal_geometry/rnc4_slices.json \
  --candidates code/geometry/candidate_parameterizations.json \
  --output /tmp/nilpotent_support_verified.json

python3 code/nilpotent/verify_geometric_obstruction.py \
  --geometry code/geometry \
  --output /tmp/nilpotent_geometry_verified.json

python3 code/nilpotent/verify_invariant_slice.py \
  --source previous_v15/code/normal_geometry/rnc4_slices.json \
  --output /tmp/nilpotent_invariant_verified.json

The geometry directory must contain parameterize_candidates.py and its
candidate_parameterizations.json. Its build_candidate function must locate
the preserved v15 source, as in the geometry part of the bundle.

Dependencies: Python standard library for the support check; SymPy 1.14
(or a compatible version) for the geometric and invariant-slice checks.

Scope: the geometric covering lemma is supplied in the geometry part.
Given that lemma, all normal-filtered nilpotent RNC4 candidates are excluded.
This does not claim a complete decomposition of the whole 36-variable
nilpotent Poisson slice. In particular its non-invariant Ga family must not
be discarded by assuming that the residue extension is a symmetry.

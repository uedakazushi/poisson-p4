#!/usr/bin/env python3
"""Verify all seven nilpotent exclusions using exact QQ arithmetic only.

Rebuilds every Jacobi generator from the original v15 equations and the
v16 candidate substitutions. Checks all 23 explicit sum-of-multiples
identities. Requires only the Python standard library; no Groebner solver,
finite field, radical computation or floating point is used.
"""
from pathlib import Path
from fractions import Fraction as Q
import argparse,ast,hashlib,json,time

ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--source',type=Path,required=True,help='v15 rnc4_slices.json')
ap.add_argument('--candidates',type=Path,required=True,help='v16 candidate_parameterizations.json')
ap.add_argument('--certificates',type=Path,default=ROOT/'nilpotent_support_certificates.json')
ap.add_argument('--output',type=Path)
args=ap.parse_args()

def decode(raw):return {tuple(m):Q(*c) for m,c in raw if c[0]}
def add(a,b,scalar=Q(1)):
 out=a.copy()
 for m,c in b.items():
  v=out.get(m,Q(0))+scalar*c
  if v:out[m]=v
  else:out.pop(m,None)
 return out

def mul(a,b):
 out={}
 for m,c in a.items():
  for n,d in b.items():
   mn=tuple(x+y for x,y in zip(m,n));out[mn]=out.get(mn,Q(0))+c*d
 return {m:c for m,c in out.items() if c}

def parse_target(expression,names):
 n=len(names);zero=(0,)*n;one={zero:Q(1)}
 def rec(node):
  if isinstance(node,ast.Constant):
   assert type(node.value) is int
   return {zero:Q(node.value)} if node.value else {}
  if isinstance(node,ast.Name):
   mon=[0]*n;mon[names.index(node.id)]=1
   return {tuple(mon):Q(1)}
  if isinstance(node,ast.UnaryOp):
   assert isinstance(node.op,(ast.USub,ast.UAdd))
   return {m:(-c if isinstance(node.op,ast.USub) else c) for m,c in rec(node.operand).items()}
  assert isinstance(node,ast.BinOp)
  a,b=rec(node.left),rec(node.right)
  if isinstance(node.op,ast.Add):return add(a,b)
  if isinstance(node.op,ast.Sub):return add(a,b,Q(-1))
  if isinstance(node.op,ast.Mult):return mul(a,b)
  if isinstance(node.op,ast.Div):
   assert set(b)=={zero} and b[zero]
   return {m:c/b[zero] for m,c in a.items()}
  if isinstance(node.op,ast.Pow):
   assert set(b)<= {zero}
   exponent=b.get(zero,Q(0));assert exponent.denominator==1 and exponent>=0
   out=one
   for _ in range(int(exponent)):out=mul(out,a)
   return out
  raise ValueError(expression)
 return rec(ast.parse(expression.replace('^','**'),mode='eval').body)

source=json.loads(args.source.read_text())
reduction=json.loads(args.source.with_name('rnc4_equation_reduction.json').read_text())
candidates={c['id']:c for c in json.loads(args.candidates.read_text())['cases']}
certificate=json.loads(args.certificates.read_text())
assert certificate['number_of_cases']==len(certificate['cases'])==7
assert {c['id'] for c in certificate['cases']}=={k for k,c in candidates.items() if c['residue']=='nilpotent'}
reports=[];started=time.time();total_targets=0
for proof in certificate['cases']:
 cid=proof['id'];case=candidates[cid];assert case['residue']=='nilpotent'
 names=case['parameter_names'];assert proof['parameter_names']==names
 n=len(names);one={(0,)*n:Q(1)};u=[decode(p) for p in case['u_polynomials']]
 cache={(0,)*36:one}
 def substitute(m):
  m=tuple(m)
  if m not in cache:
   p=one
   for i,power in enumerate(m):
    for _ in range(power):p=mul(p,u[i])
   cache[m]=p
  return cache[m]
 rebuilt=[];seen=set()
 for idx in reduction['nilpotent']['selected_original_equation_indices']:
  p={}
  for m,c in source['cases']['nilpotent']['jacobi_equations'][idx]['polynomial']:
   p=add(p,substitute(m),Q(*c))
  key=tuple(sorted(p.items()))
  if p and key not in seen:rebuilt.append(p);seen.add(key)
 assert rebuilt==[decode(q) for q in proof['jacobi_equations']],cid+' source equations'
 assert len(proof['targets'])==len(proof['witnesses'])==len(proof['target_strings'])
 for target,witness,label in zip(proof['targets'],proof['witnesses'],proof['target_strings']):
  assert decode(target)==parse_target(label,names),cid+' displayed target'
  p={}
  for idx,multiplier in witness:
   assert 0<=idx<len(rebuilt)
   coeff=decode(multiplier);assert all(len(m)==n and all(isinstance(j,int) and j>=0 for j in m) for m in coeff)
   p=add(p,mul(rebuilt[idx],coeff))
  assert p==decode(target),cid+' identity'
 total_targets+=len(proof['targets'])
 reports.append({'case':cid,'rebuilt_jacobi_generators':len(rebuilt),'verified_targets':proof['target_strings'],'all_passed':True})
 print(cid,'source rebuilt;',len(proof['targets']),'QQ identities verified',flush=True)
assert total_targets==certificate['number_of_targets']==23
report={'all_passed':True,'all_original_substitutions_rebuilt':True,'number_of_cases':7,'number_of_exact_target_identities':23,'arithmetic':'Python standard-library fractions.Fraction only','source_sha256':hashlib.sha256(args.source.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(args.candidates.read_bytes()).hexdigest(),'certificate_sha256':hashlib.sha256(args.certificates.read_bytes()).hexdigest(),'cases':reports,'seconds':round(time.time()-started,3)}
if args.output:args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

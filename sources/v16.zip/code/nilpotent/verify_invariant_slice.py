#!/usr/bin/env python3
"""Verify the strict e-invariant slice and three full-slice tangent minors.

Requires SymPy for rational polynomial arithmetic and determinants, but does
not compute a Groebner basis. Ideal equality is checked through the two
recorded sets of explicit QQ polynomial identities.
"""
from pathlib import Path
import argparse,json,time
import sympy as s
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--source',type=Path,required=True,help='v15 rnc4_slices.json')
ap.add_argument('--certificate',type=Path,default=ROOT/'nilpotent_invariant_certificate.json')
ap.add_argument('--output',type=Path)
args=ap.parse_args();started=time.time()
src=json.loads(args.source.read_text());cert=json.loads(args.certificate.read_text())
red=json.loads(args.source.with_name('rnc4_equation_reduction.json').read_text())
x=s.symbols('x0:5');u=s.symbols('u0:36');pairs=[tuple(p) for p in src['pairs']]
free=s.symbols(' '.join(cert['invariant_free_variables']));loc={str(v):v for v in (*u,*free)}
def decode(raw,vs):return s.Add(*(s.Rational(*c)*s.prod(z**e for z,e in zip(vs,m)) for m,c in raw))
def matrix(upper):
 p=s.zeros(5)
 for (i,j),raw in zip(pairs,upper):p[i,j]=decode(raw,x);p[j,i]=-p[i,j]
 return p
P0=matrix(src['cases']['nilpotent']['P0_upper']);K=[matrix(z) for z in src['common_direction_matrices']]
P=P0+sum((v*q for v,q in zip(u,K)),s.zeros(5));e=s.Matrix([0,x[0],2*x[1],3*x[2],4*x[3]]);M=e.jacobian(x)
lie=(P.applyfunc(lambda p:sum(e[i]*s.diff(p,x[i]) for i in range(5)))-M*P-P*M.T).applyfunc(s.expand)
coefficients=[c for i,j in pairs for c in s.Poly(lie[i,j],*x).coeffs()]
L,b=s.linear_eq_to_matrix(coefficients,u)
sub=s.Matrix([s.sympify(z,locals=loc) for z in cert['invariant_substitution']]);assert (L*sub-b).applyfunc(s.expand)==s.zeros(L.rows,1)
for v in free:assert sub[int(str(v)[1:])]==v
minor=cert['invariance_minor'];det=L.extract(minor['rows'],minor['columns']).det(method='domain-ge');assert det==s.Rational(minor['determinant'])!=0 and len(minor['rows'])==30
# The six displayed free coordinates and the nonzero 30-minor prove that
# this is the complete affine invariance locus.
original=src['cases']['nilpotent']['jacobi_equations'];selected=red['nilpotent']['selected_original_equation_indices']
rebuilt=[]
for idx in selected:
 p=s.expand(decode(original[idx]['polynomial'],tuple(sub)))
 if p!=0:rebuilt.append(p)
I=[decode(z,free) for z in cert['substituted_jacobi_polynomials']];J=[decode(z,free) for z in cert['ideal_generator_polynomials']]
assert len(I)==27 and len(J)==7 and all(s.expand(a-b)==0 for a,b in zip(I,rebuilt)) and len(rebuilt)==27
for p,row in zip(I,cert['I_in_J_coefficients']):assert s.expand(p-sum(decode(c,free)*g for c,g in zip(row,J)))==0
for g,row in zip(J,cert['J_in_I_coefficients']):assert s.expand(g-sum(decode(c,free)*p for c,p in zip(row,I)))==0
# The three quadrics reduce to three distinct points after imposing the
# four linear generators; the simple quadratic in u22 splits into two
# distinct roots, and the u22=5/6 branch splits into two distinct u35 roots.
a,b0=s.symbols('a b')
assert s.expand(J[0].subs({free[0]:a})-(a-s.Rational(5,6))*(a-s.Rational(3,4)))==0
assert J[3:]==list(free[1:5])
assert s.expand(J[1]-(free[0]-s.Rational(5,6))*(free[5]+s.Rational(6,5)))==0
assert s.expand(J[2].subs(free[0],s.Rational(5,6))-(free[5]+1)*(free[5]+s.Rational(4,3)))==0
assert J[2].subs({free[0]:s.Rational(3,4),free[5]:-s.Rational(6,5)})==0
points=[]
for record in cert['points']:
 pt=[s.Rational(v) for v in record['all_u']]
 def evaleq(raw):return sum(s.Rational(*c)*s.prod(z**e for z,e in zip(pt,m)) for m,c in raw)
 assert all(evaleq(eq['polynomial'])==0 for eq in original)
 rows=record['rank_certificate_rows'];assert len(rows)==36
 A=s.zeros(36)
 for r,idx in enumerate(rows):
  for mon,c in original[idx]['polynomial']:
   for j,power in enumerate(mon):
    if power:
     value=s.Rational(*c)*power
     for k,exponent in enumerate(mon):
      exponent-=int(k==j)
      if exponent:value*=pt[k]**exponent
     A[r,j]+=value
 det=A.det(method='domain-ge');assert det==s.Rational(record['rank_certificate_determinant'])!=0
 points.append({'u22_u35':record['ab'],'tangent_dimension_in_full_slice':0,'minor_determinant':str(det)})
assert {tuple(p['u22_u35']) for p in points}=={('5/6','-1'),('5/6','-4/3'),('3/4','-6/5')}
report={'all_passed':True,'complete_invariance_locus_dimension':6,'invariance_rank_minor':str(s.Rational(minor['determinant'])),'original_jacobi_generators_rebuilt':27,'simplified_ideal_generators':7,'both_ideal_inclusions_verified_by_explicit_QQ_identities':True,'three_reduced_points':True,'full_slice_tangent_minors':points,'seconds':round(time.time()-started,3)}
if args.output:args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

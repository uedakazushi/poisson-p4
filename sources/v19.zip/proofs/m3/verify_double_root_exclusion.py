#!/usr/bin/env python3
"""Exact coefficient certificate for all B=0, m=3 double-root branches.

Input: the v18 three-branch necessary normal forms.  No parameter is sampled,
no nonconstant polynomial is divided, and no Groebner basis is required.
The geometric conclusion (a projective singular plane) is proved in the note.
"""
import itertools
import json
from pathlib import Path
import sympy as S

s,t,w,u,v = coords = S.symbols('s t w u v')
mons = [w*w,w*u,w*v,u*u,u*v,v*v]
pairs = list(itertools.combinations(range(5),2))

def put(P,i,j,value):
    P[i,j]=value;P[j,i]=-value

def jac(P,i,j,k):
    return S.expand(sum(P[i,a]*S.diff(P[j,k],coords[a])
        +P[j,a]*S.diff(P[k,i],coords[a])
        +P[k,a]*S.diff(P[i,j],coords[a]) for a in range(5)))

def coefficient(poly,monomial):
    return S.Poly(poly,coords).coeff_monomial(monomial)

def check(actual,expected=0):
    assert S.expand(actual-expected)==0,(actual,expected)

def base_matrix(kind,e=None):
    P=S.zeros(5)
    aa=S.symbols('a0:6')
    d=S.Symbol('d')
    put(P,0,1,(aa[0]*s+aa[1]*t)*w+(aa[2]*s+aa[3]*t)*u+(aa[4]*s+aa[5]*t)*v)
    if kind=='nonzero':
        entries={(0,3):s*v,(0,4):s*w,(1,3):s*w+e*t*v,(1,4):e*t*w}
        R23=-S.Rational(2,3)*w*v
        R24=-S.Rational(2,3)*w*w
        R34=d*w*w+(S.Rational(1,3)-e)*w*u+(S.Rational(1,6)+e/2)*v*v
    else:
        a=S.Symbol('a')
        entries={(0,3):s*w,(1,3):a*t*w+s*v,(1,4):s*w}
        R23=-S.Rational(2,3)*w*w
        R24=S.Integer(0)
        R34=d*w*w+(a-S.Rational(1,3))*w*v
    for (i,j),value in entries.items():put(P,i,j,value)
    qq={}
    for i,j in pairs:
        qq[i,j]=S.symbols(f'q{i}{j}_0:6')
        Q=sum(c*m for c,m in zip(qq[i,j],mons))
        if (i,j)==(2,3):Q=R23
        elif (i,j)==(2,4):Q=R24
        elif (i,j)==(3,4):Q=R34
        elif (i,j)==(0,2):
            Q=sum(c*m for c,m in zip(qq[i,j][:3],mons[:3]))
            if kind=='nonzero' and e==S.Rational(-2,3):Q+=S.Symbol('z')*v*v
        elif kind=='nonzero' and (i,j)==(1,2):
            Q=sum(c*m for c,m in zip(qq[i,j][:3],mons[:3]))
            if e==S.Rational(1,6):Q+=S.Symbol('z')*v*v
        put(P,i,j,P[i,j]+Q)
    return P,aa,qq

# Both nonzero-delta resonances. All six first-order {s,t} coefficients
# are retained; no gauge on {s,t} is necessary.
nonzero_results=[]
for e in [S.Rational(1,6),S.Rational(-2,3)]:
    P,aa,qq=base_matrix('nonzero',e)
    J=jac(P,0,1,3)
    check(coefficient(J,s*u*u),-qq[1,4][3])
    check(coefficient(J,t*u*u),e*qq[0,4][3])
    # On the forced singular plane only the 3x3 (s,t,u)-block survives.
    Pplane=P.subs({w:0,v:0,qq[0,4][3]:0,qq[1,4][3]:0})
    for i,j in pairs:
        if i in (2,4) or j in (2,4):check(Pplane[i,j])
    nonzero_results.append({'e':str(e),'two_coefficients_verified':True,'plane_rank_at_most_two':True})

# Exceptional delta=0 branch: all remaining coefficients are arbitrary.
P,aa,qq=base_matrix('exceptional')
a=S.Symbol('a')
y20,q,y02=qq[1,2][3:6]
B,C=qq[0,2][1:3]
A,U11=qq[0,3][3:5]
V,E=qq[0,4][3:5]
W=qq[1,4][3]
h=aa[3]
Jstw=jac(P,0,1,2);Jstu=jac(P,0,1,3);Jstv=jac(P,0,1,4)
expressions=[
    coefficient(Jstw,s*w*u),
    coefficient(Jstw,s*w*v),
    coefficient(Jstw,t*w*w),
    coefficient(Jstu,s*u*u),
    coefficient(Jstu,s*u*v),
    coefficient(Jstu,t*w*u),
    coefficient(Jstv,s*w*u),
    coefficient(Jstv,s*v*v),
    coefficient(Jstw,u*u*v),
]
expected=[
    2*y20,
    -B+q,
    -a*B-S.Rational(2,3)*h,
    V-y20,
    -h-2*A+E-q,
    a*B-2*a*A+h,
    -h+B-E+2*W,
    -E,
    q*(A+E-B-h)+y20*(2*U11-C-aa[5])+2*y02*V,
]
for lhs,rhs in zip(expressions,expected):check(lhs,rhs)

# Build explicit polynomial identities relative to the ORIGINAL nine Jacobi
# coefficients. Each pivot coefficient below is rational and nonzero.
unit_vectors=[S.eye(9)[:,i] for i in range(9)]
reducers=[]

def reduce_with_rep(poly,rep):
    for variable,g,grep in reducers:
        quotient,remainder=S.div(poly,g,variable)
        check(poly-quotient*g,remainder)
        poly=S.expand(remainder)
        rep=(rep-quotient*grep).applyfunc(S.expand)
    check(poly,sum(rep[i]*expressions[i] for i in range(9)))
    return poly,rep

for index,variable in [(0,y20),(1,B),(2,h),(3,V),(7,E),(4,A)]:
    g,grep=reduce_with_rep(expressions[index],unit_vectors[index])
    pivot=S.diff(g,variable)
    assert pivot.is_Rational and pivot!=0
    reducers.append((variable,g,grep))

f,frep=reduce_with_rep(expressions[5],unit_vectors[5])
g,grep=reduce_with_rep(expressions[8],unit_vectors[8])
check(f,-a*(3*a-1)*q/2)
check(g,3*(3*a-2)*q*q/4)
certificate=(-3*q*frep-(2*a+S.Rational(2,3))*grep).applyfunc(S.expand)
check(sum(certificate[i]*expressions[i] for i in range(9)),q*q)

sub={y20:0,B:q,h:-3*a*q/2,V:0,E:0,A:(3*a-2)*q/4,W:-(3*a+2)*q/4}
check(expressions[6].subs(sub,simultaneous=True))
Pplane=P.subs(sub,simultaneous=True).subs({q:0,w:0,v:0})
for i,j in pairs:
    if i in (2,4) or j in (2,4):check(Pplane[i,j])

# Independent Pfaffian verification of the geometric rank claim.
for i in range(5):
    j,k,l,m=[h0 for h0 in range(5) if h0!=i]
    check(Pplane[j,k]*Pplane[l,m]-Pplane[j,l]*Pplane[k,m]+Pplane[j,m]*Pplane[k,l])

report={
    'all_passed':True,
    'nonzero_delta':nonzero_results,
    'exceptional':{
        'arbitrary_a_and_d_retained':True,
        'all_six_first_order_st_coefficients_retained':True,
        'jacobi_coefficient_identities':9,
        'polynomial_identity':'q^2 = sum_i certificate[i] * JacobiCoefficient[i]',
        'certificate':[str(c) for c in certificate],
        'no_nonconstant_division':True,
        'plane_rank_at_most_two_at_every_closed_point':True,
    },
    'geometric_scope':'No normal actual degeneration quintic in any v18 B=0 double-root m3 branch; not a scheme component count.',
}
Path('double_root_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))

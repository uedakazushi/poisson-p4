#!/usr/bin/env python3
"""Exact identities for the v19 rank-one conormal bracket exclusion.

The proof is in rank1_exclusion.tex.  This checks the identities used there
with every pure-normal quadratic correction retained.  It is not a numerical
search, a Groebner nonexistence certificate, or a completeness assertion.
"""
import itertools
import json
from pathlib import Path

import sympy as S

s,t,w,u,v = coords = S.symbols('s t w u v')
z = (w,u,v)
mons2 = [w*w,w*u,w*v,u*u,u*v,v*v]
checks=[]

def zero(expr, label):
    assert S.expand(expr)==0, (label,S.expand(expr))
    checks.append(label)

def linear(name):
    a,b=S.symbols(name+'s '+name+'t')
    return a*s+b*t

def homogeneous(name, degree):
    monoms=[w**i*u**j*v**(degree-i-j)
            for i in range(degree+1) for j in range(degree-i+1)]
    coeff=S.symbols(f'{name}0:{len(monoms)}')
    return sum(a*m for a,m in zip(coeff,monoms))

def binary_part(expr, degree):
    return S.expand(sum(coeff*s**e[0]*t**e[1]
        for e,coeff in S.Poly(S.expand(expr),s,t).terms() if sum(e)==degree))

def setpair(P,i,j,value):
    P[i,j]=value
    P[j,i]=-value

aw,av,p,q,r,k,ell,m,b = [linear(n) for n in
                           ('aw','av','p','q','r','k','ell','m','b')]
c0,c1,c2=S.symbols('c0 c1 c2')
c=c0*s*s+c1*s*t+c2*t*t
P1=S.zeros(5)
for i,j,value in ((0,1,aw*w+av*v),(0,3,p*w+ell*v),
                  (0,4,q*w),(1,3,r*w+m*v),(1,4,k*w),(3,4,b*w)):
    setpair(P1,i,j,value)
Q=S.zeros(5)
for num,(i,j) in enumerate(itertools.combinations(range(5),2)):
    coeff=S.symbols(f'q{num}_0:6')
    setpair(Q,i,j,sum(a*n for a,n in zip(coeff,mons2)))
P=P1+Q

def pfaff4(M):
    return M[0,1]*M[2,3]-M[0,2]*M[1,3]+M[0,3]*M[1,2]

pf=[]
for i in range(5):
    inds=[j for j in range(5) if j!=i]
    pf.append(S.expand((-1)**i*pfaff4(P.extract(inds,inds))))
C,D,X,Y=Q[2,3],Q[2,4],Q[0,2],Q[1,2]
bs3=b*w*Y-(r*w+m*v)*D+k*w*C
bt3=-b*w*X+(p*w+ell*v)*D-q*w*C
zero(binary_part(pf[0],1)-bs3,'full60_bs3')
zero(binary_part(pf[1],1)-bt3,'full60_bt3')
zero(bs3.subs(w,0)+m*v*D.subs(w,0),'Qwvdivw_from_m')
zero(bt3.subs(w,0)-ell*v*D.subs(w,0),'Qwvdivw_from_ell')

# The first nontrivial Casimir equations, with a completely arbitrary F4,F5.
A4,B4=homogeneous('a4_',4),homogeneous('b4_',4)
F4=s*A4+t*B4
F5=homogeneous('f5_',5)
F=c*w**3+F4+F5
Cas=P*S.Matrix([S.diff(F,x) for x in coords])
expected_u=-(p*w+ell*v)*S.diff(c,s)*w**3 \
           -(r*w+m*v)*S.diff(c,t)*w**3-3*c*C*w*w+b*w*S.diff(F4,v)
expected_v=-q*S.diff(c,s)*w**4-k*S.diff(c,t)*w**4 \
           -3*c*D*w*w-b*w*S.diff(F4,u)
zero(binary_part(Cas[3],2)-expected_u,'full60_Casimir_u_degree4')
zero(binary_part(Cas[4],2)-expected_v,'full60_Casimir_v_degree4')

# Having D=w*D1 forces F4=w*A*v^3+w^2*G2 and C modw=xi*v^2,
# with b*A=xi*c.  Check the coefficient of the FULL Casimir, not merely its
# first normal degree, that kills xi.  G2 has binary degree one.
A=linear('A')
G2=s*homogeneous('g2s_',2)+t*homogeneous('g2t_',2)
xi=S.symbols('xi')
C1,D1=homogeneous('C1_',1),homogeneous('D1_',1)
Pa=P.copy()
setpair(Pa,2,3,w*C1+xi*v*v)
setpair(Pa,2,4,w*D1)
Fa=c*w**3+w*A*v**3+w*w*G2+F5
Casa=Pa*S.Matrix([S.diff(Fa,x) for x in coords])
zero(binary_part(Casa[3].subs(w,0),1)+xi*A*v**5,
     'full_Casimir_u_kills_xi')

# After xi=A=0, divergence zero gives D1_v=-C1_u. Keep all other entries.
mu,lam,alpha,eta,nu=S.symbols('mu lam alpha eta nu')
Pb=P.copy()
setpair(Pb,2,3,w*(mu*w+alpha*u+eta*v))
setpair(Pb,2,4,w*(lam*w+nu*u-alpha*v))
div=[S.expand(sum(S.diff(Pb[i,j],coords[i]) for i in range(5)))
     for j in range(5)]
zero(div[2],'divergence_w_zero')
Z=Pb[3,4]-b*w
Zbar=Z.subs(w,0)
zero(div[4].subs(w,0)-(nu*u-alpha*v+S.diff(Zbar,u)),
     'divergence_v_restriction')
Fb=c*w**3+w*w*G2+F5
Casb=Pb*S.Matrix([S.diff(Fb,x) for x in coords])
C5=F5.subs(w,0)
zero(binary_part(Casb[0].subs(w,0),1)-ell*v*S.diff(C5,u),
     'full_Casimir_s_forces_C5u')
zero(binary_part(Casb[1].subs(w,0),1)-m*v*S.diff(C5,u),
     'full_Casimir_t_forces_C5u')

gamma=S.symbols('gamma')
F5w=homogeneous('f5w_',4)
Fc=c*w**3+w*w*G2+gamma*v**5+w*F5w
Casc=Pb*S.Matrix([S.diff(Fc,x) for x in coords])
zero(Casc[3].subs(w,0)-5*gamma*v**4*Zbar,
     'full_Casimir_u_forces_Zbar')

R=v*(nu*u-alpha*v)
Cnew,Dnew=Pb[2,3],Pb[2,4]
bsnew=b*w*Y-(r*w+m*v)*Dnew+k*w*Cnew
btnew=-b*w*X+(p*w+ell*v)*Dnew-q*w*Cnew
zero(S.diff(bsnew,w).subs(w,0)-(b*Y.subs(w,0)-m*R),
     'mixed_Pfaff_bY_mR')
zero(S.diff(btnew,w).subs(w,0)-(-b*X.subs(w,0)+ell*R),
     'mixed_Pfaff_bX_ellR')

report={'all_passed':True,'checks':checks,'check_count':len(checks),
        'pure_normal_quadratic_coefficients_retained':60,
        'proof_scope':'rank-one conormal bracket, multiplicity three; w divides F',
        'normality_used_only_for_contradiction':True,
        'sympy_version':S.__version__}
out=Path(__file__).with_name('rank1_exact_report.json')
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))

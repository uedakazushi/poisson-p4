"""Exact four-coefficient obstruction; no specialization or numerical sampling."""
import itertools,json
from pathlib import Path
import sympy as S

s,t,w,u,v = coords = S.symbols('s t w u v')
alpha,beta,gamma,rho,x,d = S.symbols('alpha beta gamma rho x d')
mu=-(alpha+beta)/3
mons=[w*w,w*u,w*v,u*u,u*v,v*v]
P=S.zeros(5)
def put(i,j,value): P[i,j]=S.expand(value);P[j,i]=-P[i,j]
def quad(name,mm=mons):
    cc=S.symbols(f'{name}0:{len(mm)}')
    return sum(a*m for a,m in zip(cc,mm)),cc
aw0,aw1,au0,au1,av0,av1 = S.symbols('aw0 aw1 au0 au1 av0 av1')
T,_=quad('T'); X,xc=quad('X',[w*w,w*u,w*v]);Y,yc=quad('Y',[w*w,w*u,w*v])
U,uc=quad('U'); V,vc=quad('V'); R,rc=quad('R'); W,wc=quad('W')
put(0,1,(aw0*s+aw1*t)*w+(au0*s+au1*t)*u+(av0*s+av1*t)*v+T)
put(0,2,x*v*v+X);put(1,2,Y)
put(0,3,s*(alpha*w+rho*gamma*v)+U)
put(0,4,gamma*s*w+V)
put(1,3,t*(beta*w-4*rho*gamma*v)+R)
put(1,4,-4*gamma*t*w+W)
put(2,3,mu*w*w+rho*gamma*w*v)
put(2,4,gamma*w*w)
put(3,4,d*w*w+gamma*w*u-mu*w*v-rho*gamma*v*v)

def jac(i,j,k):
    return S.Poly(S.expand(sum(P[i,a]*S.diff(P[j,k],coords[a])+
            P[j,a]*S.diff(P[k,i],coords[a])+
            P[k,a]*S.diff(P[i,j],coords[a]) for a in range(5))),coords)
Jstw=jac(0,1,2);Jstv=jac(0,1,4)
E1=Jstw.coeff_monomial(t*w*v)
E2=Jstv.coeff_monomial(t*w*u)
E3=Jstv.coeff_monomial(t*u*v)
E4=Jstv.coeff_monomial(t*v*v)
expected=[rho*gamma*(4*xc[1]+au1)+8*gamma*x,
          -2*beta*vc[3]+4*gamma*vc[4]-4*gamma*xc[1],
          8*rho*gamma*vc[3],
          4*rho*gamma*vc[4]+rho*gamma*au1-4*gamma*x]
for actual,target in zip([E1,E2,E3,E4],expected):
    assert S.expand(actual-target)==0,(actual,target)
combination=S.expand(4*gamma*(E1+rho*E2-E4)+beta*E3)
assert S.expand(combination-48*gamma**2*x)==0
result={'all_passed':True,'coefficient_equations':list(map(str,[E1,E2,E3,E4])),
 'monomials':['J_stw[t*w*v]','J_stv[t*w*u]','J_stv[t*u*v]','J_stv[t*v^2]'],
 'certificate':'4*gamma*(E1+rho*E2-E4)+beta*E3 = 48*gamma^2*x',
 'scope':'v18 squarefree B=0 resonance delta=-4gamma; gamma,rho,x nonzero. Swapping s,t treats the second resonance.'}
Path(__file__).with_name('verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

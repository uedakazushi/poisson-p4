"""Exact bidegree (1,4) invariant spaces and curl identities for two pencils."""
import sympy as S
import json
from pathlib import Path
s,t,w,u,v=S.symbols('s t w u v')
z=(w,u,v);H=2*u*w-v*v
mons=[w**i*u**j*v**(4-i-j) for i in range(5) for j in range(5-i)]
cs=S.symbols('c0:30');A=sum(a*b for a,b in zip(cs[:15],mons));B=sum(a*b for a,b in zip(cs[15:],mons))
F=s*A+t*B
def act(D,f):return S.expand(sum(D[i]*S.diff(f,z[i]) for i in range(3)))
def curl(R):return S.Matrix([S.diff(R[2],u)-S.diff(R[1],v),S.diff(R[0],v)-S.diff(R[2],w),S.diff(R[1],w)-S.diff(R[0],u)])
xi,eta,g=S.symbols('xi eta g')
report=[]
for name,Ds,Dt,third,G in [
 ('regular_proportional_lower',S.Matrix([0,w,0]),S.Matrix([0,v,w]),-2*s*w**3*v+t*w*w*H,-eta*w*u+xi*w*v+eta*v*v/2+g*w*w),
 ('moving_rank_one_image',S.Matrix([0,w,0]),S.Matrix([0,0,w]),s*w**3*v-t*w**3*u,w*(xi*v-eta*u+g*w))]:
    polys=[act(Ds,A),act(Dt,B),act(Ds,B)+act(Dt,A)]
    eqs=[co for p in polys for co in S.Poly(p,*z).coeffs()]
    mat,_=S.linear_eq_to_matrix(eqs,cs)
    assert mat.rank()==27
    basis=[s*w**4,t*w**4,third]
    for f in basis:assert act(s*Ds+t*Dt,f)==0
    assert len(S.Poly(third,s,t,w,u,v).terms())>=2
    _,cols=mat.rref();_,rows=mat[:,list(cols)].T.rref();minor=mat.extract(list(rows),list(cols)).det()
    assert minor!=0
    assert all(S.expand(q)==0 for q in curl(S.Matrix([G,0,0]))-xi*Ds-eta*Dt)
    cross=Ds.cross(Dt)
    assert cross[0]!=0 and cross[1]==0 and cross[2]==0
    report.append({'case':name,'coefficient_matrix_shape':list(mat.shape),'rank':27,'kernel_basis':[str(f) for f in basis],'minor_rows':list(rows),'minor_cols':list(cols),'minor_determinant':str(minor),'G':str(G),'Ds_cross_Dt':[str(x) for x in cross],'all_checks_passed':True})
out={'all_passed':True,'cases':report}
Path(__file__).with_name('varying_pencil_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'all_passed':True,'two_full_invariant_spaces_rank27':True,'curl_and_independence_verified':True},indent=2))

"""Rank and identities for the independent ell,q multiplicity-four pencil."""
import itertools,json
from pathlib import Path
import sympy as S
s,t,w,u,v=S.symbols('s t w u v');z=(w,u,v)
mons=[w**i*u**j*v**(4-i-j) for i in range(5) for j in range(5-i)]
coeff=S.symbols('c0:30')
A=sum(c*m for c,m in zip(coeff[:15],mons))
B=sum(c*m for c,m in zip(coeff[15:],mons))
D=S.Matrix([0,s*v,t*w])
F=s*A+t*B
poly=S.Poly(S.expand(sum(D[i]*S.diff(F,z[i]) for i in range(3))),s,t,w,u,v)
mat=S.linear_eq_to_matrix(poly.coeffs(),coeff)[0]
_,cols=mat.rref(); _,rows=mat[:,list(cols)].T.rref()
minor=mat.extract(list(rows),list(cols)).det()
assert len(cols)==27 and minor!=0
bases=[(w**4,0),(0,w**4),(-w*w*v*v,2*w**3*u)]
vecs=[]
for aa,bb in bases:
    vec=S.Matrix([S.Poly(aa,w,u,v).coeff_monomial(m) for m in mons]+[S.Poly(bb,w,u,v).coeff_monomial(m) for m in mons])
    assert mat*vec==S.zeros(mat.rows,1)
    vecs.append(vec)
assert S.Matrix.hstack(*vecs).rank()==3
xi,eta,g=S.symbols('xi eta g')
G=xi*v*v/2-eta*w*u+g*w*w
curl=S.Matrix([0,S.diff(G,v),-S.diff(G,u)])
assert curl==S.Matrix([0,xi*v,eta*w])

rw,ru,rv=S.symbols('rw ru rv')
R=S.Matrix([rw,ru,rv]);Q=S.Matrix([[0,rv,-ru],[-rv,0,rw],[ru,-rw,0]])
u0,u1,u2,w0,w1,w2=S.symbols('u0 u1 u2 w0 w1 w2')
U=S.Matrix([u0,u1,u2]);W=S.Matrix([w0,w1,w2]);P=S.zeros(5)
for k in range(3):P[0,k+2]=xi*D[k]+U[k];P[1,k+2]=eta*D[k]+W[k]
P[2:5,2:5]=Q
for i in range(5):
    for j in range(i+1,5):P[j,i]=-P[i,j]
def pf(ids):
    i,j,k,l=ids
    return P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k]
assert S.expand(pf([1,2,3,4])-eta*D.dot(R)-W.dot(R))==0
assert S.expand(-pf([0,2,3,4])+xi*D.dot(R)+U.dot(R))==0
result={'all_passed':True,'invariant_map_shape':list(mat.shape),'rank':27,
 'nonzero_minor':str(minor),'kernel_dimension':3,
 'invariant_bases':[(str(a),str(b)) for a,b in bases],
 'tangential_pfaffians':True,'curl_identity':True,
 'scope':'Exact invariants and polynomial identities; gcd and geometric exclusion proved in TeX.'}
Path(__file__).with_name('varying_independent_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

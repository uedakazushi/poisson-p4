"""Exact certificates for exclusion of every constant regular J m4 branch.

No random sampling, floating point, or Groebner assumptions are used.
The two non-normal normal-form families satisfy all ten Jacobi identities.
"""
import json
from pathlib import Path
import sympy as S

s,t,w,u,v=S.symbols('s t w u v')
z=(w,u,v); coords=(s,t,w,u,v)
mons=(w*w,w*u,w*v,u*u,u*v,v*v)
D=S.Matrix([0,v,w]); H=2*u*w-v*v
a,b,c=S.symbols('a b c')

def grad(f): return S.Matrix([S.diff(f,x) for x in z])
def div(X): return S.expand(sum(S.diff(X[i],z[i]) for i in range(3)))
def zero(f): return S.expand(f)==0
def qmatrix(R):
    return S.Matrix([[0,R[2],-R[1]],[-R[2],0,R[0]],[R[1],-R[0],0]])
def vec_coeff(X):
    return S.Matrix([S.expand(X[i]).coeff(w,S.degree(m,w)).coeff(u,S.degree(m,u)).coeff(v,S.degree(m,v)) for i in range(3) for m in mons])
def linear_operator(h,eig):
    R=S.Matrix([(2*h-1)*w*u+(1-h)*v*v/2,h*w*w,-h*w*v])
    cs=S.symbols('x0:18')
    X=S.Matrix([sum(cs[6*i+j]*mons[j] for j in range(6)) for i in range(3)])
    L=grad(X.dot(R))-div(X)*R+eig*D.cross(X)
    pols=[co for f in L for co in S.Poly(S.expand(f),*z).coeffs()]
    mat,_=S.linear_eq_to_matrix(pols,cs)
    return mat,R

out={'linear_spaces':[],'families':[]}
for h in [S.Rational(-1,2),S.Integer(2)]:
    if h==S.Rational(-1,2):
        U0=S.Matrix([0,w*w,0])
        W0=S.Matrix([u*w-S.Rational(5,4)*v*v,S.Rational(7,2)*u*u,u*v])
        q=c*w*w-2*a*b*w*v
        C=w*w*(4*a*b*u*v*w-3*a*b*v**3-2*c*u*w*w+c*v*v*w)/4
    else:
        U0=S.Matrix([u*w+S.Rational(5,2)*v*v,-4*u*u,u*v])
        W0=S.Matrix([0,-2*u*w+v*v,0])
        q=-c*H+2*a*b*u*v
        C=H*(2*a*b*u*v*w+a*b*v**3-c*w*H)/2
    R=S.Matrix([(2*h-1)*w*u+(1-h)*v*v/2,h*w*w,-h*w*v])
    Q=qmatrix(R)
    for eig,X0,shift in [(-2,U0,-3),(3,W0,2)]:
        mat,_=linear_operator(h,eig)
        gauges=[shift*zz*D-Q*grad(zz) for zz in z]
        gauge_rank=S.Matrix.hstack(*(vec_coeff(G) for G in gauges)).rank()
        if h==2 and eig==3:
            assert gauge_rank==2 and gauges[0]==S.zeros(3,1)
            vectors=[X0,w*D,gauges[1],gauges[2]]
        else:
            assert gauge_rank==3
            vectors=[X0]+gauges
        basis=S.Matrix.hstack(*(vec_coeff(G) for G in vectors))
        assert mat.rank()==14 and basis.rank()==4 and mat*basis==S.zeros(mat.rows,4)
        _,cols=mat.rref();_,rows=mat[:,list(cols)].T.rref()
        minor=mat.extract(list(rows),list(cols)).det()
        assert minor!=0
        out['linear_spaces'].append({'h':str(h),'eigenvalue':eig,'matrix_shape':list(mat.shape),'rank':14,'gauge_rank':gauge_rank,'minor_rows':list(rows),'minor_cols':list(cols),'minor_determinant':str(minor),'basis_coefficients':[[str(x) for x in row] for row in basis.tolist()]})
    U=a*U0; W=b*W0
    if h==2:
        d=S.symbols('d');qextra=S.symbols('qextra0:6')
        fullg=sum(x*y for x,y in zip(qextra,mons))*R-U.cross(W+d*w*D)
        obstruction=S.Poly(S.expand(S.diff(fullg[1],w)-S.diff(fullg[0],u)),*z).coeff_monomial(w*w*u)
        assert zero(obstruction+5*a*d)
        out['residual_gauge_obstruction']={'W_residual':'d*w*D','curl_component':'d_w g_u - d_u g_w','monomial':'w^2*u','coefficient':str(obstruction),'a_nonzero_reason':'B4=(5a/4)H^2 and A4,B4 independent','deduction':'d=0'}
    A=S.expand(W.dot(R));B=S.expand(-U.dot(R))
    assert all(zero(x) for x in grad(C)-q*R+U.cross(W))
    qc=S.symbols('q0:6');qgen=sum(x*y for x,y in zip(qc,mons))
    cg=qgen*R-U.cross(W)
    pols=[co for i in range(3) for j in range(i) for co in S.Poly(S.expand(S.diff(cg[i],z[j])-S.diff(cg[j],z[i])),*z).coeffs()]
    sols=S.solve(pols,qc,dict=True)
    assert len(sols)==1
    qsol=S.expand(qgen.subs(sols[0]))
    free=set(qc)&qsol.free_symbols
    assert len(free)==1 and zero(qsol.subs(next(iter(free)),c)-q)
    P=S.zeros(5)
    P[0,1]=s*div(W)-t*div(U)+q
    for j in range(3):
        P[0,j+2]=3*s*D[j]+U[j];P[1,j+2]=-2*t*D[j]+W[j]
        for k in range(j+1,3):P[j+2,k+2]=Q[j,k]
    P=P-P.T
    F=s*A+t*B+C
    divergences=[S.expand(sum(S.diff(P[i,j],coords[i]) for i in range(5))) for j in range(5)]
    assert all(zero(q) for q in divergences)
    pf=[]
    for i in range(5):
        ii=[j for j in range(5) if j!=i];j,k,l,m=ii
        pf.append((-1)**i*(P[j,k]*P[l,m]-P[j,l]*P[k,m]+P[j,m]*P[k,l]))
    assert all(zero(pf[i]-S.diff(F,coords[i])) for i in range(5))
    jac=[]
    for i in range(5):
      for j in range(i+1,5):
       for k in range(j+1,5):
        jac.append(S.expand(sum(P[i,l]*S.diff(P[j,k],coords[l])+P[j,l]*S.diff(P[k,i],coords[l])+P[k,l]*S.diff(P[i,j],coords[l]) for l in range(5))))
    assert len(jac)==10 and all(zero(q) for q in jac)
    if h==S.Rational(-1,2):
        assert all(zero(S.diff(F,x).subs({w:0,v:0})) for x in coords)
        geometry='F lies in (w,v)^2: a projective plane is singular'
    else:
        assert S.rem(F,H,w)==0
        geometry='H divides F: the actual projective degeneracy divisor is not normal'
    out['families'].append({'h':str(h),'U':[str(x) for x in U],'W':[str(x) for x in W],'S2':str(q),'F':str(S.factor(F)),'all_divergence_pfaff_gradient_jacobi_checks':True,'normality_obstruction':geometry})

# Trace-zero rank-one V=t*d_s, R=w^2 e_w. The w-component of the
# leading normal Pfaff equation determines W_u once W_v=w L.
rho,dw,du,dv,lw,lu,lv=S.symbols('rho dw du dv lw lu lv')
L=lw*w+lu*u+lv*v; divU=dw*w+du*u+dv*v
W=S.Matrix([-2*rho*w*w, v*L+(6*rho*u+divU)*w-2*rho*v*v,w*L])
B=rho*w*w*H;R=S.Matrix([w*w,0,0])
assert all(zero(x) for x in grad(B)+divU*R+D.cross(W))
assert W.subs({w:0,v:0})==S.zeros(3,1)
out['nilpotent_case']={'leading_pfaff_identity_verified':True,'W_v_divisible_w_reason':'w-component modulo w gives v W_v = 0 modulo w','W_v_after_division':'w*L','W_u_after_division':str(W[1]),'W_vanishing_on_u_axis':True,'gradient_C_on_u_axis':'S2*R-U cross W = 0'}
out['all_passed']=True
Path(__file__).with_name('constant_regular_certificate.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'all_passed':True,'four_linear_spaces_rank14':True,'two_families_all_ten_jacobi':True,'nilpotent_case_exact':True},indent=2))

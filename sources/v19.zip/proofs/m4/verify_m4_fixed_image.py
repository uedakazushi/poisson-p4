#!/usr/bin/env python3
"""Exact identities for the v19 fixed common image exclusion in multiplicity 4."""
import itertools
import json
from pathlib import Path
import sympy as S

s,t,w,u,v=coords=S.symbols('s t w u v')
mons=[w*w,w*u,w*v,u*u,u*v,v*v]
checks=[]
def zero(x,label):
    assert S.expand(x)==0,(label,S.expand(x))
    checks.append(label)
def lin(name):
    a,b=S.symbols(name+'s '+name+'t')
    return a*s+b*t
def homo(name,d):
    mon=[w**i*u**j*v**(d-i-j) for i in range(d+1) for j in range(d-i+1)]
    coeff=S.symbols(f'{name}0:{len(mon)}')
    return sum(a*m for a,m in zip(coeff,mon))
def pair(P,i,j,x):
    P[i,j]=x;P[j,i]=-x
def binary(expr,d):
    return sum(a*s**ij[0]*t**ij[1]
               for ij,a in S.Poly(S.expand(expr),s,t).terms() if sum(ij)==d)
def pf4(M):
    return M[0,1]*M[2,3]-M[0,2]*M[1,3]+M[0,3]*M[1,2]

p,r,ell,m,aw,au,av=[lin(n) for n in ('p','r','ell','m','aw','au','av')]
L=p*w+ell*v;N=r*w+m*v
P1=S.zeros(5)
pair(P1,0,1,aw*w+au*u+av*v)
pair(P1,0,3,L);pair(P1,1,3,N)
Q=S.zeros(5)
for n,(i,j) in enumerate(itertools.combinations(range(5),2)):
    aa=S.symbols(f'q{n}_0:6')
    pair(Q,i,j,sum(a*m for a,m in zip(aa,mons)))
P=P1+Q
pf=[]
for i in range(5):
    ind=[j for j in range(5) if i!=j]
    pf.append((-1)**i*pf4(P.extract(ind,ind)))
zero(binary(pf[0],1)+N*Q[2,4],'Pfaff3_s_forces_Qwv')
zero(binary(pf[1],1)-L*Q[2,4],'Pfaff3_t_forces_Qwv')
F4=s*homo('A',4)+t*homo('B',4)
F5=homo('f',5)
cas=P*S.Matrix([S.diff(F4+F5,x) for x in coords])
zero(binary(cas[0],2)-L*S.diff(F4,u),'Casimir_s_forces_F4u')
zero(binary(cas[1],2)-N*S.diff(F4,u),'Casimir_t_forces_F4u')

pair(P,2,4,0)
C,Z=P[2,3],P[3,4]
div=[sum(S.diff(P[i,j],coords[i]) for i in range(5)) for j in range(5)]
zero(div[2]+S.diff(C,u),'divergence_w_forces_Cu')
zero(div[4]-S.diff(Z,u),'divergence_v_forces_Zu')
X,Y,V,T=P[0,2],P[1,2],P[0,4],P[1,4]
pf=[]
for i in range(5):
    ind=[j for j in range(5) if i!=j]
    pf.append((-1)**i*pf4(P.extract(ind,ind)))
zero(pf[0]-(C*T+Z*Y),'full_Pfaff_s')
zero(pf[1]-(-C*V-Z*X),'full_Pfaff_t')
zero(pf[3]-(X*T-V*Y),'full_Pfaff_u')

cp,zp,H,K,X0,Y0,V0,T0=S.symbols('cp zp H K X0 Y0 V0 T0')
xx=X0+cp*H;vv=V0-zp*H;yy=Y0+cp*K;tt=T0-zp*K
zero(xx*tt-vv*yy-(X0*T0-V0*Y0+H*(cp*T0+zp*Y0)-K*(cp*V0+zp*X0)),
     'coprime_syzygy_determinant')
zero(cp*tt+zp*yy-(cp*T0+zp*Y0),'syzygy_preserves_A_over_g')
zero(-cp*vv-zp*xx-(-cp*V0-zp*X0),'syzygy_preserves_B_over_g')
report={'all_passed':True,'checks':checks,'check_count':len(checks),
        'pure_normal_quadratic_coefficients_retained':60,
        'conclusion_proved_in_text':'F belongs to (w,v)^2; singular locus contains a plane',
        'sympy_version':S.__version__}
Path(__file__).with_name('m4_fixed_image_report.json').write_text(
    json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

#!/usr/bin/env python3
"""Exact checks for the moving-image rank-one m4 exclusion."""
import itertools
import json
from pathlib import Path
import sympy as S

s,t,w,u,v=S.symbols('s t w u v')
coords=(s,t,w,u,v)
checks=[]
def zero(expr,label):
    assert S.expand(expr)==0,(label,S.expand(expr))
    checks.append(label)
def pair(P,i,j,expr):
    P[i,j]=expr;P[j,i]=-expr
def homogeneous(name,d):
    mm=[w**i*u**j*v**(d-i-j) for i in range(d+1) for j in range(d-i+1)]
    aa=S.symbols(f'{name}0:{len(mm)}')
    return sum(a*m for a,m in zip(aa,mm)),aa,mm
def pf4(M):
    return M[0,1]*M[2,3]-M[0,2]*M[1,3]+M[0,3]*M[1,2]
def binary(expr,d):
    return sum(a*s**ij[0]*t**ij[1]
               for ij,a in S.Poly(S.expand(expr),s,t).terms() if sum(ij)==d)

A,ac,mm=homogeneous('a',4);B,bc,_=homogeneous('b',4)
expr=S.expand(s*S.diff(s*A+t*B,u)+t*S.diff(s*A+t*B,v))
rows=S.Poly(expr,s,t,w,u,v).coeffs()
mat,_=S.linear_eq_to_matrix(rows,ac+bc)
ker=mat.nullspace()
assert len(ker)==3
aa,bb,hh=S.symbols('aa bb hh')
An=aa*w**4+hh*w**3*v;Bn=bb*w**4-hh*w**3*u
zero(s*S.diff(s*An+t*Bn,u)+t*S.diff(s*An+t*Bn,v),
     'displayed_invariant_forms')
checks.append('full_30_coefficient_invariant_kernel_dimension3')

P=S.zeros(5)
st,_,_=homogeneous('pst',1)
pair(P,0,1,s*st+t*homogeneous('ptt',1)[0])
pair(P,0,3,s*w);pair(P,0,4,t*w)
for n,(i,j) in enumerate(itertools.combinations(range(5),2)):
    q,_,_=homogeneous(f'q{n}_',2)
    pair(P,i,j,P[i,j]+q)
inds=[0,2,3,4]
pft=-pf4(P.extract(inds,inds))
zero(binary(pft,1)-w*(s*P[2,4]-t*P[2,3]),'mixed_Pfaff_C_D_zero')
pair(P,2,3,0);pair(P,2,4,0)
Z=P[3,4]
div=[sum(S.diff(P[i,j],coords[i]) for i in range(5)) for j in range(5)]
zero(div[3]-(w-S.diff(Z,v)),'divergence_u')
zero(div[4]-S.diff(Z,u),'divergence_v')
d=S.symbols('d')
pair(P,3,4,w*(v+d*w))
pf=[]
for i in (0,1):
    ind=[j for j in range(5) if j!=i]
    pf.append((-1)**i*pf4(P.extract(ind,ind)))
zero(pf[0]-P[1,2]*w*(v+d*w),'full_Pfaff_s')
zero(pf[1]+P[0,2]*w*(v+d*w),'full_Pfaff_t')
zero(Bn.subs(v,-d*w)-w**3*(bb*w-hh*u),'linear_factor_obstruction')

report={'all_passed':True,'checks':checks,'check_count':len(checks),
 'invariant_kernel_dimension':3,'coefficient_matrix_rank':mat.rank(),
 'sympy_version':S.__version__}
Path(__file__).with_name('m4_moving_rank1_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

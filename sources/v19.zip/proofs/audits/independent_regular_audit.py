#!/usr/bin/env python3
"""Independent targeted audit of the v19 constant-regular-J argument."""
import json
from pathlib import Path
import sympy as S

w,u,v=S.symbols('w u v');z=(w,u,v)
alpha,beta,d=S.symbols('alpha beta d')
q=S.symbols('q0:6')
mons=(w*w,w*u,w*v,u*u,u*v,v*v)
H=2*u*w-v*v;D=S.Matrix([0,v,w])
checks=[]
def check(expr,label):
    assert S.expand(expr)==0,(label,S.expand(expr))
    checks.append(label)

# Rebuild the residual h=2 obstruction independently, including every S2 term.
R=S.Matrix([3*u*w-S.Rational(1,2)*v*v,2*w*w,-2*w*v])
U=alpha*S.Matrix([u*w+S.Rational(5,2)*v*v,-4*u*u,u*v])
W=beta*S.Matrix([0,-H,0])+d*w*D
S2=sum(a*m for a,m in zip(q,mons))
G=S2*R-U.cross(W)
closed=S.expand(S.diff(G[1],w)-S.diff(G[0],u))
coefficient=S.Poly(closed,w,u,v).coeff_monomial(w*w*u)
check(coefficient+5*alpha*d,'h2_full_S2_residual_coefficient')

# Compute the actual shear directions, not merely their declared ranks.
def Q(R):
    return S.Matrix([[0,R[2],-R[1]],[-R[2],0,R[0]],[R[1],-R[0],0]])
def grad(f):return S.Matrix([S.diff(f,x) for x in z])
for h in (S.Rational(-1,2),S.Integer(2)):
    RR=S.Matrix([(2*h-1)*u*w+(1-h)*v*v/2,h*w*w,-h*w*v])
    for shift,label in ((-3,'U'),(2,'W')):
        gauges=[shift*x*D-Q(RR)*grad(x) for x in z]
        vectors=S.Matrix([[S.Poly(GG[i],w,u,v).coeff_monomial(mm)
                            for GG in gauges] for i in range(3) for mm in mons])
        expected=2 if h==2 and label=='W' else 3
        assert vectors.rank()==expected
        checks.append(f'shear_rank_h{h}_{label}_{expected}')
        if expected==2:
            assert gauges[0]==S.zeros(3,1)
            full=vectors.row_join(S.Matrix([S.Poly((w*D)[i],w,u,v).coeff_monomial(mm)
                                           for i in range(3) for mm in mons]))
            assert full.rank()==3
            checks.append('h2_W_residual_wD_not_gauge')

# Nilpotent rank-one V=t*d_s; preserve arbitrary linear div(U), arbitrary L.
rho=S.symbols('rho',nonzero=True)
l0,l1,l2,e0,e1,e2=S.symbols('l0 l1 l2 e0 e1 e2')
L=l0*w+l1*u+l2*v;divU=e0*w+e1*u+e2*v
Rn=S.Matrix([w*w,0,0])
Wn=S.Matrix([-2*rho*w*w,
              v*L+(6*rho*u+divU)*w-2*rho*v*v,w*L])
Bn=rho*w*w*H
res=grad(Bn)+divU*Rn+D.cross(Wn)
for i in range(3):check(res[i],f'nilpotent_full_normal_Pfaff_{i}')
assert Wn.subs({w:0,v:0})==S.zeros(3,1)
checks.append('nilpotent_W_vanishes_on_u_axis')

# The homogeneous-degree-five gradient criterion used to conclude C in I^2.
mm=[w**i*u**j*v**(5-i-j) for i in range(6) for j in range(6-i)]
cc=S.symbols('c0:21');C=sum(a*m for a,m in zip(cc,mm))
bad=[m for m in mm if S.degree(m,w)+S.degree(m,v)<2]
assert set(bad)=={u**5,u**4*w,u**4*v}
partials=[S.expand(S.diff(C,x).subs({w:0,v:0})) for x in z]
rows=[S.Poly(expr,u).coeffs() for expr in partials]
mat,_=S.linear_eq_to_matrix([co for row in rows for co in row],cc)
assert mat.rank()==3
checks.append('gradient_axis_vanishing_exactly_kills_I2_obstructions')

report={'all_passed':True,'checks':checks,'check_count':len(checks),
 'residual_coefficient':str(coefficient),'sympy_version':S.__version__}
Path(__file__).with_name('independent_regular_audit_report.json').write_text(
    json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

"""Independent small-algebra and finite-tail audit of U1 infinity.

No Poisson or Kuranishi helper is imported, and no old files are modified.
The all-orders logical argument is recorded in the companion .txt file.
This script checks the graded algebra, the finite HF evidence and Macaulay
thresholds, and the unique DVR torsion partition compatible with the evidence.
"""
from pathlib import Path
from itertools import combinations, combinations_with_replacement
from math import comb
import hashlib
import json
import sympy as s

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'infinity'
b, L, k, p, q, z = s.symbols('b L k p q z')
A = s.Rational(1179, 23552)
B = s.Rational(305, 2944)
C = s.Rational(1323, 11776)
D = s.Rational(9, 46)
E = s.Rational(57, 184)
alpha = L**2 - s.Rational(9, 32)*k**2
beta = L*k - k**2/2
cubics = [b*alpha-A*k**3, b*beta-B*k**3,
          L**3-C*k**3, L**2*k-D*k**3, L*k**2-E*k**3]
variables = (b, L, k, p, q)
quadrics = [p*v for v in variables] + [q*v for v in variables]
J = s.groebner(quadrics+[L*f for f in cubics], *variables,
               order='grevlex', domain=s.QQ)
K = s.groebner(cubics, b, L, k, order='grevlex', domain=s.QQ)
Ks = s.groebner([alpha, beta], b, L, k,
                order='grevlex', domain=s.QQ)

def hilbert_series(gb):
    leads = [f.LM(order=gb.order).exponents for f in gb.polys]
    n = len(gb.gens)
    numerator = {}
    for size in range(len(leads)+1):
        for chosen in combinations(leads, size):
            degree = sum(max(row[j] for row in chosen)
                         for j in range(n)) if chosen else 0
            numerator[degree] = numerator.get(degree, 0)+(-1)**size
    return s.cancel(sum(c*z**d for d,c in numerator.items())/(1-z)**n)

HK = (1+2*z+z**2)/(1-z)+2*z**2+z**3
Hfree = (1+2*z+z**2)/(1-z)
HN = z*HK+2*z
HB = 1/(1-z)**2+HN
assert s.cancel(hilbert_series(K)-HK) == 0
assert s.cancel(hilbert_series(Ks)-Hfree) == 0
assert s.cancel(hilbert_series(J)-HB) == 0
assert s.cancel(HB-(1+3*z-3*z**2+3*z**3-4*z**4+z**6)/(1-z)**2) == 0
assert all(Ks.reduce(f)[1] == 0 for f in cubics)
assert K.reduce(b*b*alpha)[1] == K.reduce(b*b*beta)[1] == 0
assert Ks.reduce(k**3)[1] == 0

# Finite-length submodule of the graded nilmodule: dimensions 2,2,1
# in degrees 1,3,4.  The HFs above show that these five vectors exhaust it.
torsion_basis = [p, q, L*alpha, L*beta, L*k**3]
normal_forms = [J.reduce(f)[1] for f in torsion_basis]
monomials = sorted(set().union(*[set(s.Poly(f,*variables).monoms())
                                  for f in normal_forms]))
matrix = s.Matrix([[s.Poly(f,*variables).coeff_monomial(m)
                    for m in monomials] for f in normal_forms])
assert matrix.rank() == 5
assert all(J.reduce(v*L*k**3)[1] == 0 for v in variables)
assert J.reduce(L**4-C*L*k**3)[1] == 0
assert J.reduce(L**4)[1] != 0
assert J.reduce(L**5)[1] == 0
assert J.reduce(b*L*alpha-A*L*k**3)[1] == 0
assert J.reduce(b*L*beta-B*L*k**3)[1] == 0
assert all(J.reduce(b*b*f)[1] == 0 for f in torsion_basis)

data = json.loads((SOURCE/'fiber_lengths_fast_6.json').read_text())
expected = {1:[1,4,3,3,1,1,1], 2:[1,5,5,7,3,2,2],
            3:[1,5,6,9,7,4,3]}
lengths = {}
thresholds = {}
for record in data['reports']:
    n = record['power']; hf = record['Hilbert_function']
    assert hf == expected[n]
    base = [min(i+1,n) for i in range(len(hf))]
    assert record['base_Hilbert_function'] == base
    d = next(i for i in range(max(1,n),len(hf))
             if hf[i] == n and all(j == n for j in hf[i:]))
    assert n <= d
    # For n<=d its degree-d Macaulay representation is a sum of n
    # consecutive unit binomial coefficients, so the growth bound is n.
    macaulay_growth = sum(comb(d-j+1,d-j+1) for j in range(n))
    assert macaulay_growth == n
    thresholds[n] = d
    lengths[n] = sum(x-y for x,y in zip(hf,base))
    assert lengths[n] == record['nil_length']
assert lengths == {1:7,2:12,3:17}
assert thresholds == {1:4,2:5,3:6}

def partitions(total, largest=None):
    if total == 0:
        yield ()
        return
    if largest is None:
        largest = total
    for a in range(min(total,largest),0,-1):
        for tail in partitions(total-a,a):
            yield (a,)+tail

compatible = []
for total in range(6):
    for blocks in partitions(total):
        if all(4*n+sum(min(n,a) for a in blocks) == lengths[n]
               for n in lengths):
            compatible.append(blocks)
assert compatible == [(3,1,1)]

# Confirm that the cached complete residual jets cite precisely the current
# calculation sources.  This is provenance, not a second Jacobi solver.
jet = json.loads((SOURCE/'jet_residuals_6.json').read_text())
hash_checks = {name:hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()==digest
               for name,digest in jet['source_sha256'].items()}
assert all(hash_checks.values())
assert jet['degree'] == 6 and jet['rows'] == 350
assert jet['variables'] == ['b','u','v','p','q']
assert [part['degree'] for part in jet['residuals']] == [2,3,4,5,6]

out = {
 'all_passed':True,
 'scope':'Independent small algebra, finite HF tail thresholds, and DVR partition; logical all-order audit is in the companion txt.',
 'graded_nil_Hilbert_series':str(HN),
 'graded_nil_multiplicity':4,
 'graded_finite_torsion_length':5,
 'graded_finite_torsion_degrees':{'1':2,'3':2,'4':1},
 'graded_b_torsion_blocks':[2,1,1,1],
 'L4_coefficient':str(C),
 'Macaulay_tail_thresholds':thresholds,
 'nil_quotient_lengths':lengths,
 'actual_DVR_rank':4,
 'unique_actual_DVR_torsion_blocks':list(compatible[0]),
 'jet_provenance_checks':hash_checks,
 'important_limit':'in(I)=J determines the full associated graded ring, not a formal algebra isomorphism B=C[[b,L,k,p,q]]/J.'
}
(HERE/'infinity_all_orders_independent_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

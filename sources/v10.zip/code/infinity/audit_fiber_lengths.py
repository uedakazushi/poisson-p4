"""Exact audit of the three fibre lengths and the finite DVR module conclusion."""
from pathlib import Path
from itertools import combinations_with_replacement
import json
HERE=Path(__file__).resolve().parent
fast=json.loads((HERE/'fiber_lengths_fast_6.json').read_text())
assert [r['power'] for r in fast['reports']]==[1,2,3]
naive1=json.loads((HERE/'fiber_lengths_naive_6.json').read_text())['reports'][0]
naive2=json.loads((HERE/'fiber_lengths_naive_5.json').read_text())['reports'][0]
fast5=json.loads((HERE/'fiber_lengths_fast_5.json').read_text())['reports'][0]
assert naive1['power']==1 and naive2['power']==2 and fast5['power']==2
assert naive1['Hilbert_function']==fast['reports'][0]['Hilbert_function']
assert naive2['Hilbert_function']==fast5['Hilbert_function']==fast['reports'][1]['Hilbert_function'][:6]
lengths=[];plateaus=[]
for report in fast['reports']:
 n=report['power'];hf=report['Hilbert_function'];base=report['base_Hilbert_function']
 assert base==[min(d+1,n) for d in range(len(hf))]
 d=next(d for d in range(n,len(hf)) if hf[d]==n)
 assert all(value==n for value in hf[d:])
 length=sum(a-b for a,b in zip(hf,base))
 assert length==report['nil_length']
 lengths.append(length);plateaus.append(d)
assert lengths==[7,12,17] and plateaus==[4,5,6]
possible=[]
for count in range(1,6):
 for parts in combinations_with_replacement(range(1,6),count):
  if sum(parts)>5:continue
  if all(4*n+sum(min(n,e) for e in parts)==lengths[n-1] for n in [1,2,3]):possible.append(parts)
assert possible==[(1,1,3)]
out={'all_passed':True,'independent_full_Macaulay_checks':{'power1_degree6':True,'power2_degree5':True},'power2_degrees5and6_agree':True,'nil_fiber_lengths':lengths,'Macaulay_plateau_degrees':plateaus,'free_DVR_rank':4,'point_torsion_length_upper_bound':5,'unique_torsion_exponents':list(possible[0]),'point_torsion_length':sum(possible[0]),'scope':'The plateau extension uses Macaulay growth and the actual smooth T16 quotient as proved in the article. No inference solely from repeated finite values is made.'}
(HERE/'fiber_lengths_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

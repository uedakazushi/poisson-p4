from pathlib import Path
from itertools import combinations_with_replacement
import json,ast,time
import sympy as s
from exact_calculus import Calculus
from full_kuranishi import Slice,actual,rk,rref,inverse,kernel
HERE=Path(__file__).resolve().parent

def setup():
 C=Calculus(5);t,x,y,z,w=C.x
 P=C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,(2,3):-z*z/2,(2,4):x*z+y*(x+2*z),(3,4):t*t+z*z+x*z})
 rec=json.loads((HERE/'binary_samples.json').read_text())['xz']
 norms=[C.tensor({tuple(ast.literal_eval(k)):s.sympify(v,locals=dict(zip(map(str,C.x),C.x))) for k,v in d.items()}) for d in rec['normals']]
 mag=C.tensor({(2,4):t*z})
 sl=Slice(C,P)
 sl.R=[mag]+norms;sl.Rv=[C.vector(q) for q in sl.R];sl.u=s.symbols('b u v p q')
 assert all(not any(sl.D*v) for v in sl.Rv)
 sl.coefficients={1:{tuple(int(i==j) for j in range(5)):R for i,R in enumerate(sl.R)}}
 assert rk(s.Matrix.hstack(sl.A,*sl.Rv,sl.W))==150
 return sl

def monpol(sl,d):return [s.prod(u**a for u,a in zip(sl.u,m)) for m in sl.monomials(d)]
def torows(M,mons):
 rr,piv=rref(M)
 return [s.factor(sum(rr[i,j]*m for j,m in enumerate(mons))) for i in range(len(piv))]
def reduced_matrix(M,mons,gb,variables,d):
 new=[]
 for i in range(M.rows):
  if not any(M.row(i)):continue
  f=s.expand(sum(v*m for v,m in zip(M.row(i),mons)))
  g=s.Poly(gb.reduce(f)[1],*variables)
  if not g.is_zero:new.append([g.coeff_monomial(m) for m in mons])
 return s.Matrix(new) if new else s.zeros(0,len(mons))

def main():
 start=time.time();sl=setup();C=sl.C
 Q=sl.solve_order(2);m2=monpol(sl,2);eq2=torows(Q,m2)
 print('QUADRATIC',eq2,flush=True)
 U=sl.solve_order(3);m3=monpol(sl,3)
 rows=rref(Q.T)[1];cols=rref(Q[rows,:])[1];Q0=Q.extract(rows,cols)
 Q3=U-Q[:,cols]*inverse(Q0)*U[rows,:]
 assert not any(Q3[rows,:])
 gb=s.groebner(eq2,*sl.u,order='grevlex',domain=s.QQ)
 new3=reduced_matrix(Q3,m3,gb,sl.u,3);eq3=torows(new3,m3)
 print('NEW CUBIC MOD QUADRATIC',eq3,flush=True)
 # Full infinitesimal stabilizer and its action on the five-dimensional slice.
 V=s.Matrix.hstack(*[C.vector(C.vertical(i,j)) for i in range(5) for j in range(5)]);V=V[:,rref(V)[1]]
 fields=[];lies=[]
 for i in range(5):
  for j in range(5):
   if i==j==4:continue
   X=s.zeros(5,1);X[i]=C.x[j];fields.append(X);lies.append(C.vector(C.lie(sl.P,X)))
 T=s.Matrix.hstack(*lies,C.vector(sl.P),V);KS=kernel(T)
 full=sl.A.row_join(s.Matrix.hstack(*sl.Rv));freerows=rref(full.T)[1];invfull=inverse(full[freerows,:])
 stab=[]
 for j in range(KS.cols):
  X=sum((KS[i,j]*F for i,F in enumerate(fields)),s.zeros(5,1));alpha=KS[len(fields),j]
  imgs=[]
  for R in sl.R:
   im=C.vector(C.lie(R,X))+alpha*C.vector(R);sol=invfull*im[freerows,:]
   assert full*sol==im
   imgs.append(sol[-5:,:])
  mat=s.Matrix.hstack(*imgs)
  stab.append({'field':list(map(str,X)),'scale_correction':str(alpha),'slice_action':[[str(v) for v in row] for row in mat.tolist()]})
 out={'point':C.encode(sl.P),'ranks':{'fullJacobi':len(sl.wcols),'group_vertical_scale':sl.group_rank,'magnetic_actual':48},'variables':list(map(str,sl.u)),'slice_basis':[C.encode(R) for R in sl.R],'quadratic_equations':list(map(str,eq2)),'new_cubic_initial_equations':list(map(str,eq3)),'elimination_rows':sl.rows,'elimination_columns':sl.wcols,'quadratic_generator_rows':rows,'quadratic_generator_columns':cols,'stabilizers':stab,'jets':[{ 'degree':d,'multiindex':list(k),'tensor':C.encode(v)} for d,js in sl.coefficients.items() for k,v in js.items()],'seconds':time.time()-start}
 (HERE/'infinity_slice.json').write_text(json.dumps(out,indent=2)+'\n')
 print('STAB',stab,flush=True);print('DONE',out['seconds'],flush=True)

if __name__=='__main__':main()

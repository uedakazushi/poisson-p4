from pathlib import Path
import json
from magnetic_family import sample
HERE=Path(__file__).resolve().parent
out={}
for name,values in [('v7',[0,0,0,1,2,3]),('xz',[0,0,0,0,1,0]),('z2',[0,0,0,0,0,1]),('zero',[0,0,0,0,0,0])]:
 out[name]=sample(values)
(HERE/'binary_samples.json').write_text(json.dumps(out,indent=2)+'\n')

from infinity_slice import *
import sys,hashlib

def main():
 start=time.time();sl=setup();maxd=int(sys.argv[1]) if len(sys.argv)>1 else 6
 entries=[]
 for d in range(2,maxd+1):
  M=sl.solve_order(d)
  entries.append({'degree':d,'monomials':[list(m) for m in sl.monomials(d)],'entries':[[i,j,str(v)] for (i,j),v in M.todok().items() if v]})
  data={'degree':d,'rows':350,'variables':list(map(str,sl.u)),'residuals':entries,'source_sha256':{name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in ['exact_calculus.py','full_kuranishi.py','infinity_slice.py','binary_samples.json']},'seconds':time.time()-start}
  (HERE/f'jet_residuals_{d}.json').write_text(json.dumps(data,indent=2)+'\n')
  print('saved',d,'nonzeroentries',len(entries[-1]['entries']),'seconds',data['seconds'],flush=True)

if __name__=='__main__':main()

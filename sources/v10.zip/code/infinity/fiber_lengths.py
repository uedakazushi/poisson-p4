from infinity_slice import *
import sys

def run_span(M,keys,n,d):
 rr,piv=rref(M);basis=rr[:len(piv),:];idx={m:i for i,m in enumerate(keys)}
 multipliers=[m for j in range(d-1) for m in sl_monomials(5,j) if m[0]<n]
 rows=[]
 for row in basis.tolist():
  nz=[(keys[i],v) for i,v in enumerate(row) if v]
  for multi in multipliers:
   new={}
   for k,val in nz:
    e=tuple(a+b for a,b in zip(k,multi))
    if e[0]<n and sum(e)<=d:new[idx[e]]=val
   if new:rows.append(new)
 mat=s.MutableSparseMatrix(len(rows),len(keys),{(i,j):v for i,row in enumerate(rows) for j,v in row.items()})
 _,piv=rref(mat)
 return piv

def sl_monomials(n,d):return [tuple(a.count(i) for i in range(n)) for a in combinations_with_replacement(range(n),d)]

def main():
 start=time.time();sl=setup();maxd=int(sys.argv[1]) if len(sys.argv)>1 else 6
 for d in range(2,maxd+1):
  sl.solve_order(d);print('solved',d,'seconds',time.time()-start,flush=True)
 # No b-coordinate change is used. Restrict actual originalmagnetic b by b^n.
 # Implicit corrections are in the fixed98-coordinate complement.
 reports=[]
 powers=[int(v) for v in sys.argv[2:]] or [1,2,3]
 for n in powers:
  keys=[m for d in range(2,maxd+1) for m in sl.monomials(d) if m[0]<n]
  blocks=[]
  for d in range(2,maxd+1):
   cols=[i for i,m in enumerate(sl.monomials(d)) if m[0]<n]
   blocks.append(sl.residuals[d][:,cols])
  M=s.Matrix.hstack(*blocks);piv=run_span(M,keys,n,maxd)
  hf=[1]
  for d in range(1,maxd+1):
   moncount=sum(m[0]<n for m in sl_monomials(5,d))
   idealcount=sum(sum(keys[j])==d for j in piv)
   hf.append(moncount-idealcount)
  base=[min(d+1,n) for d in range(maxd+1)]
  report={'power':n,'Hilbert_function':hf,'T16_base_Hilbert_function':base,'partial_nil_length':sum(a-b for a,b in zip(hf,base)),'last_value':hf[-1],'plateau_proven_if_last_equals_power':hf[-1]==n and maxd>=n}
  reports.append(report);print('FIBER',report,'seconds',time.time()-start,flush=True)
 assert [r['power'] for r in reports]==powers
 (HERE/f'fiber_lengths_naive_{maxd}.json').write_text(json.dumps({'degree':maxd,'reports':reports,'seconds':time.time()-start},indent=2)+'\n')

if __name__=='__main__':main()

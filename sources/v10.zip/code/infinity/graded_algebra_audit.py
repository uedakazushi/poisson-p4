"""Independent commutative-algebra audit; no Poisson helper is imported."""
from pathlib import Path
from itertools import combinations_with_replacement
import json
import sympy as s
HERE=Path(__file__).resolve().parent
b,u,v,p,q,L,k,T=s.symbols('b u v p q L k T')
rec=json.loads((HERE/'higher_initial_4.json').read_text())
quartics=[s.sympify(f) for f in rec['new_initial_equations_mod_quadratics']]
assert len(quartics)==5
cubics=[]
for f in quartics:
 quotient,rem=s.div(f,2*u+v,u,v,b,domain=s.QQ)
 assert rem==0
 cubics.append(s.expand(quotient.subs({u:(L-k)/2,v:k},simultaneous=True)))
G=s.groebner(cubics,b,L,k,domain=s.QQ,order='grevlex')
A=s.Rational(1179,23552);B=s.Rational(305,2944)
C=s.Rational(1323,11776);D=s.Rational(9,46);E=s.Rational(57,184)
alpha=L**2-s.Rational(9,32)*k**2;beta=L*k-k**2/2
five=[b*alpha-A*k**3,b*beta-B*k**3,L**3-C*k**3,L**2*k-D*k**3,L*k**2-E*k**3]
G2=s.groebner(five,b,L,k,domain=s.QQ,order='grevlex')
assert G==G2
assert G.reduce(L**4)[1]==G.reduce(k**4)[1]==0
assert all(f.subs({L:0,k:0})==0 for f in five)
assert G.reduce(k**3)[1]!=0
assert G.reduce(b*alpha-A*k**3)[1]==G.reduce(b*beta-B*k**3)[1]==0
assert G.reduce(b*k**3)[1]==0
# The saturation byb is the quadratic complete intersectionK=(alpha,beta).
K=s.groebner([alpha,beta],b,L,k,domain=s.QQ,order='grevlex')
assert all(K.reduce(f)[1]==0 for f in five)
assert K.reduce(k**3)[1]==0
assert G.reduce(b*b*alpha)[1]==G.reduce(b*b*beta)[1]==0
# alpha,beta,k^3 are independent and form the whole finite torsion quotient.
assert s.Matrix([[s.Poly(f,L,k).coeff_monomial(m) for m in [L**2,L*k,k**2]] for f in [alpha,beta]]).rank()==2
assert G.reduce(beta-(B/A)*alpha)[1]!=0
assert G.reduce(b*(beta-(B/A)*alpha))[1]==0
leads=[f.LM(order=G.order).exponents for f in G.polys]
hf=[]
for d in range(13):
 mon=[tuple(a.count(i) for i in range(3)) for a in combinations_with_replacement(range(3),d)]
 hf.append(sum(not any(all(x>=y for x,y in zip(m,e)) for e in leads) for m in mon))
assert hf==[1,3,6,5]+[4]*9
H=(1+2*T+T**2)/(1-T)+2*T**2+T**3
HN=T*H+2*T
HS=1/(1-T)**2+HN
assert s.factor(HS-(1+3*T-3*T**2+3*T**3-4*T**4+T**6)/(1-T)**2)==0
# A linear parameterchange simplifies the displayed cubic ideal.
bp=b-L/2+s.Rational(7,16)*k
assert G.reduce(bp*alpha)[1]==G.reduce(bp*beta)[1]==0
out={'all_passed':True,'J3_five_generators':list(map(str,five)),'J3_radical':'(L,k)','saturation_by_b':'(L^2-9*k^2/32,L*k-k^2/2)','J3_Hilbert_function_degrees0to12':hf,'J3_Hilbert_series':str(H),'normal_module_Hilbert_series':str(HN),'full_slice_Hilbert_series':str(HS),'full_slice_Hilbert_function_degrees0to8':[int(s.series(HS,T,0,9).removeO().coeff(T,i)) for i in range(9)],'normal_module_multiplicity':4,'graded_point_torsion_length':5,'graded_point_torsion_degrees':{'1':2,'3':2,'4':1},'graded_point_torsion_b_blocks':[2,1,1,1],'simplifying_linear_parameter':'b-L/2+7*k/16 = b-u-v/16','scope':'This script audits the finite graded algebra. The passage to all orders uses the separate proof with actual T16 and universal generic-axis length4.'}
(HERE/'graded_algebra_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

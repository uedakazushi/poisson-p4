from infinity_slice import *
from sympy.polys.matrices import DomainMatrix

def point_matrix(xs,B):
 t,x,y,z,w=xs;M=s.zeros(5)
 for ij,f in {(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,(2,3):-z*z/2,(2,4):B+y*(x+2*z),(3,4):t*t+z*z+x*z}.items():M[ij]=f
 return M-M.T

def main():
 sl=setup();C=sl.C;t,x,y,z,w=C.x
 c00,c10,c01,c20,c11,c02=s.symbols('c00 c10 c01 c20 c11 c02')
 B=c00*t*t+c10*t*x+c01*t*z+c20*x*x+c11*x*z+c02*z*z
 f=c10*t+s.Rational(2,3)*c20*x-c00*z
 g=(2*c02-s.Rational(16,3)*c20+2*c00)*z
 YY=s.Matrix([t,x,y+f,z,w+g]);H=YY.jacobian(C.x)
 transformed=(H*point_matrix(C.x,B)*H.T).subs({y:y-f,w:w-g},simultaneous=True).applyfunc(s.expand)
 essential=(c01-2*c10)*t*z+(c11-4*c20)*x*z
 assert all(s.expand(v)==0 for v in transformed-point_matrix(C.x,essential))
 c=s.symbols('c',nonzero=True);kk,ll=s.symbols('k l')
 D=s.diag(1,1,c,1,c)
 scaled=(D*point_matrix(C.x,kk*t*z+ll*x*z)*D.T/c).subs({y:y/c,w:w/c},simultaneous=True).applyfunc(s.expand)
 assert all(s.expand(v)==0 for v in scaled-point_matrix(C.x,c*kk*t*z+c*ll*x*z))
 # Direct derivative supplied by independent actualT16confluence.
 dk=C.tensor({(1,2):-4*t*(y+z),(1,3):-4*t*z,(1,4):4*t*(w+4*y-4*z),(2,4):-4*t*y,(3,4):-4*t*z})
 coords=sl.A.row_join(s.Matrix.hstack(*sl.Rv));rows=rref(coords.T)[1]
 solution=inverse(coords[rows,:])*C.vector(dk)[rows,:]
 assert coords*solution==C.vector(dk)
 normal=list(solution[-5:,:]);assert normal==[-4,-8,16,0,0]
 free=[j for j in range(150) if j not in sl.wcols]
 coorddet=DomainMatrix.from_Matrix(coords[free,:]).convert_to(s.QQ).det()
 jacdet=DomainMatrix.from_Matrix(sl.D.extract(sl.rows,sl.wcols)).convert_to(s.QQ).det()
 # The degree4initial equations, afterL=2u+v andk=v.
 rec=json.loads((HERE/'higher_initial_4.json').read_text());b,u,v,p,q=sl.u;L,k,T=s.symbols('L k T')
 quartics=[s.sympify(z) for z in rec['new_initial_equations_mod_quadratics']]
 cubics=[s.factor((z/(2*u+v)).subs(u,(L-k)/2).subs(v,k)) for z in quartics]
 gb=s.groebner(cubics,b,L,k,order='grevlex',domain=s.QQ)
 leads=[poly.LM(order=gb.order).exponents for poly in gb.polys]
 h=[]
 for d in range(13):
  mons=[tuple(a.count(i) for i in range(3)) for a in combinations_with_replacement(range(3),d)]
  h.append(sum(not any(all(x>=y for x,y in zip(m,e)) for e in leads) for m in mons))
 expected=[1,3,6,5]+[4]*9
 assert h==expected
 H=(1+2*T+T*T)/(1-T)+2*T*T+T**3
 HN=T*H+2*T
 assert s.limit((1-T)*HN,T,1)==4
 alpha=L*L-s.Rational(9,32)*k*k;beta=L*k-k*k/2
 A=s.Rational(1179,23552);BB=s.Rational(305,2944)
 for z in [b*alpha-A*k**3,b*beta-BB*k**3,b*k**3,k**4]:assert gb.reduce(z)[1]==0
 assert gb.reduce(k**3)[1]!=0
 out={'all_passed':True,'magnetic_shear_f':str(f),'magnetic_shear_g':str(g),'essential_magnetic_pair':[str(c01-2*c10),str(c11-4*c20)],'scaling_law':'(k,l) maps to (c*k,c*l) by y,w scalingc andPoisson scaling1/c','v7_pair':[0,-2],'infinity_representative':'B=x*z','subgroup_quotient_note':'This is the explicit fiber subgroup quotient, not a claimed complete PGL orbit quotient.','full_ranks':{'Jacobi':98,'group_vertical_scalar':47,'actual_with_magnetic_b':48,'full_tangent_projective':27,'orbit_projective':22},'Jacobi_minor':{'rows':sl.rows,'columns':sl.wcols,'determinant':str(jacdet)},'full_slice_coordinates_minor':{'rows':free,'determinant':str(coorddet)},'T16_derivative_normal_in_buvpq':list(map(str,normal)),'J3_generators_in_bLk':list(map(str,cubics)),'J3_Groebner_basis':list(map(lambda f:str(f.as_expr()),gb.polys)),'J3_Hilbert_function_degrees0to12':h,'J3_Hilbert_series':str(H),'normal_module_Hilbert_series':str(HN),'normal_module_dimension':1,'normal_module_multiplicity':4,'graded_point_torsion_length':5,'graded_point_torsion_degrees':{'1':2,'3':2,'4':1},'graded_point_torsion_b_blocks':[2,1,1,1],'J3_torsion_relations':{'alpha':str(alpha),'beta':str(beta),'b_alpha_coefficient_k3':str(A),'b_beta_coefficient_k3':str(BB)}}
 (HERE/'infinity_geometry_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:out[k] for k in ['all_passed','full_ranks','T16_derivative_normal_in_buvpq','normal_module_Hilbert_series','graded_point_torsion_length']},indent=2),flush=True)

if __name__=='__main__':main()

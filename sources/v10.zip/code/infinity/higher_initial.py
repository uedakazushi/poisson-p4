from infinity_slice import *
from itertools import product
import sys

def mon_list(n,d):return [tuple(v.count(i) for i in range(n)) for v in combinations_with_replacement(range(n),d)]
def truncated_span(M,keys,maxdegree):
 # Rows encode generators whose lowest degree is2; include every multiple
 # of degree<=maxdegree-2. Ascending-degree column order computes the
 # truncated local standard basis by exact linear algebra.
 rr,piv=rref(M);basis=rr[:len(piv),:]
 idx={m:i for i,m in enumerate(keys)}
 multipliers=[m for d in range(maxdegree-1) for m in mon_list(5,d)]
 rows=[]
 for row in basis.tolist():
  nz=[(keys[i],v) for i,v in enumerate(row) if v]
  for multi in multipliers:
   new={}
   for k,val in nz:
    e=tuple(a+b for a,b in zip(k,multi))
    if sum(e)<=maxdegree:new[idx[e]]=val
   if new:rows.append(new)
 mat=s.MutableSparseMatrix(len(rows),len(keys),{(i,j):v for i,row in enumerate(rows) for j,v in row.items()})
 rr,piv=rref(mat)
 return rr[:len(piv),:],piv

def main():
 start=time.time();sl=setup();maxd=int(sys.argv[1]) if len(sys.argv)>1 else 4
 for d in range(2,maxd+1):
  sl.solve_order(d);print('solved',d,'time',time.time()-start,flush=True)
 Q=sl.residuals[2];U=sl.residuals[3];rows=rref(Q.T)[1];cols=rref(Q[rows,:])[1];Qi=inverse(Q.extract(rows,cols))
 Qcan=Qi*Q[rows,:];Ccan=Qi*U[rows,:]
 m2=monpol(sl,2);m3=monpol(sl,3);eq2=torows(Q,m2);gb=s.groebner(eq2,*sl.u,domain=s.QQ)
 tails=[]
 for i in range(len(rows)):
  quadratic=s.expand(sum(a*m for a,m in zip(Qcan.row(i),m2)))
  cubic=s.expand(sum(a*m for a,m in zip(Ccan.row(i),m3)))
  tails.append({'quadratic':str(quadratic),'cubic_mod_quadratics':str(s.factor(gb.reduce(cubic)[1]))})
 print('CUBIC TAILS',tails,flush=True)
 keys=[m for d in range(2,maxd+1) for m in sl.monomials(d)]
 M=s.Matrix.hstack(*[sl.residuals[d] for d in range(2,maxd+1)])
 basis,piv=truncated_span(M,keys,maxd)
 new=[]
 for i,j in enumerate(piv):
  if sum(keys[j])!=maxd:continue
  p=s.expand(sum(v*s.prod(u**a for u,a in zip(sl.u,m)) for v,m in zip(basis.row(i),keys)))
  rem=s.factor(gb.reduce(p)[1])
  if rem:new.append(rem)
 if new:
  mm=monpol(sl,maxd);N=s.Matrix([[s.Poly(f,*sl.u).coeff_monomial(m) for m in mm] for f in new]);new=torows(N,mm)
 print('NEW INITIAL AT DEGREE',maxd,new,'time',time.time()-start,flush=True)
 out={'maxdegree':maxd,'variables':list(map(str,sl.u)),'quadratic_equations':list(map(str,eq2)),'canonical_cubic_tails':tails,'new_initial_equations_mod_quadratics':list(map(str,new)),'truncated_ideal_vector_space_dimension':len(piv),'residual_generators':[],'seconds':time.time()-start}
 rr,pp=rref(M)
 for i in range(len(pp)):
  out['residual_generators'].append(str(s.factor(sum(v*s.prod(u**a for u,a in zip(sl.u,m)) for v,m in zip(rr.row(i),keys)))))
 (HERE/f'higher_initial_{maxd}.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()

"""Exact truncated local division before the small pure-variable row reduction."""
from pathlib import Path
from itertools import combinations_with_replacement
import json,sys,time
import sympy as s
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent

def rr(M):
 R,p=DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref();return R.to_Matrix(),list(p)
def mon(n,d):return [tuple(a.count(i) for i in range(n)) for a in combinations_with_replacement(range(n),d)]
def add(a,b):return tuple(x+y for x,y in zip(a,b))
def divides(a,b):return all(x<=y for x,y in zip(a,b))

def main():
 maxd=int(sys.argv[1]) if len(sys.argv)>1 else 6
 powers=[int(v) for v in sys.argv[2:]] or [1,2,3]
 start=time.time();data=json.loads((HERE/f'jet_residuals_{maxd}.json').read_text())
 raw=[{} for _ in range(350)]
 for rec in data['residuals']:
  keys=list(map(tuple,rec['monomials']))
  for i,j,val in rec['entries']:raw[i][keys[j]]=s.Rational(val)
 keys2=mon(5,2);Q=s.Matrix([[f.get(k,0) for k in keys2] for f in raw]);rows=rr(Q.T)[1];cols=rr(Q[rows,:])[1]
 Qi=DomainMatrix.from_Matrix(Q.extract(rows,cols)).convert_to(s.QQ).inv().to_Matrix()
 G=[]
 for i in range(len(rows)):
  out={}
  for j,r in enumerate(rows):
   c=Qi[i,j]
   if c:
    for k,val in raw[r].items():out[k]=out.get(k,0)+c*val
  G.append({k:s.cancel(v) for k,v in out.items() if v})
 lead=[keys2[j] for j in cols]
 assert all(g.get(l)==1 for g,l in zip(G,lead))
 results=[]
 for n in powers:
  generators=[{k:v for k,v in g.items() if k[0]<n} for g in G]
  keys=[m for d in range(2,maxd+1) for m in mon(5,d) if m[0]<n]
  ordered=sorted(keys,key=lambda m:(sum(m),m));rewrites={}
  for m in keys:
   if m[3]+m[4]==0:continue
   j=next(i for i,l in enumerate(lead) if divides(l,m))
   multi=tuple(a-b for a,b in zip(m,lead[j]))
   rewrites[m]={add(k,multi):val for k,val in generators[j].items() if sum(k)+sum(multi)<=maxd and k[0]+multi[0]<n}
   assert rewrites[m].get(m)==1
  pure=[m for m in keys if m[3]+m[4]==0];pindex={m:i for i,m in enumerate(pure)}
  def reduce(f):
   out=dict(f)
   for m in ordered:
    coeff=out.get(m,0)
    if not coeff or m not in rewrites:continue
    for k,val in rewrites[m].items():
     new=out.get(k,0)-coeff*val
     if new:out[k]=new
     elif k in out:del out[k]
   assert all(k[3]+k[4]==0 for k in out)
   return out
  pure_gens=[]
  for f in raw:
   red=reduce({k:v for k,v in f.items() if k[0]<n})
   if red:pure_gens.append([red.get(m,0) for m in pure])
  R,piv=rr(s.Matrix(pure_gens)) if pure_gens else (s.zeros(0,len(pure)),[])
  H=[{m:R[i,j] for j,m in enumerate(pure) if R[i,j]} for i in range(len(piv))]
  print('power',n,'pure_basis',len(H),'pure_columns',len(pure),'seconds',time.time()-start,flush=True)
  relations=[]
  for gen in generators+H:
   if not gen:continue
   mindeg=min(map(sum,gen))
   for deg in range(maxd-mindeg+1):
    for multi in mon(5,deg):
     if multi[0]>=n:continue
     shifted={add(k,multi):val for k,val in gen.items() if sum(k)+deg<=maxd and k[0]+multi[0]<n}
     red=reduce(shifted)
     if red:relations.append([red.get(m,0) for m in pure])
  print('power',n,'pure_relations',len(relations),'seconds',time.time()-start,flush=True)
  _,piv=rr(s.Matrix(relations)) if relations else (None,[])
  hf=[1]
  for d in range(1,maxd+1):
   count=sum(m[0]<n and (d==1 or m[3]+m[4]==0) for m in mon(5,d))
   killed=sum(sum(pure[j])==d for j in piv)
   hf.append(count-killed)
  base=[min(i+1,n) for i in range(maxd+1)]
  result={'power':n,'Hilbert_function':hf,'base_Hilbert_function':base,'nil_length':sum(a-b for a,b in zip(hf,base)),'plateau_proved':hf[-1]==n and maxd>=n}
  results.append(result);print('RESULT',result,'seconds',time.time()-start,flush=True)
 assert [r['power'] for r in results]==powers
 output=HERE/f'fiber_lengths_fast_{maxd}.json'
 temporary=output.with_suffix('.json.tmp')
 temporary.write_text(json.dumps({'degree':maxd,'reports':results,'seconds':time.time()-start},indent=2)+'\n')
 temporary.replace(output)

if __name__=='__main__':main()

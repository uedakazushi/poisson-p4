"""Finite equivariant positive-weight Poisson deformation slice at magnetic zero."""
from pathlib import Path
import json,ast,time
from exact_calculus import *
from full_kuranishi import actual,rk,rref,inverse
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
C.pol=lambda f:{m:v for m,v in s.Poly(s.expand(f),*C.x).terms() if v}
def read(data):return C.tensor({tuple(ast.literal_eval(k)):s.sympify(v,locals=dict(zip(['t','x','y','z','w'],C.x))) for k,v in data.items()})
def add(*args):return C.from_vector(sum((C.vector(a) for a in args),s.zeros(150,1)))
def mul(f,P):return C.from_vector(f*C.vector(P))
ref=json.loads((HERE/'u1_zero_magnetic.json').read_text());norm=[read(a) for a in ref['full_slice_basis']]
P0=C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,(2,3):-z*z/2,(2,4):y*(x+2*z),(3,4):t*t+x*z+z*z})
D=C.derivative(P0,True);_,cols=rref(D);DW=D[:,cols];_,rows=rref(DW.T);Mi=inverse(DW[rows,:]);W=s.eye(150)[:,cols]
a,b,p,q=s.symbols('a b p q');pars=[a,b,p,q]
P1=add(mul(a,norm[0]),mul(b,norm[1]));N2=add(mul(p,norm[2]),mul(q,norm[5]))
rhs2=C.euler_vector(C.jacobi(P1));P2=add(N2,C.from_vector(-W*Mi*rhs2[rows,:]))
rhs3=C.euler_vector(C.polar(P1,P2));P3=C.from_vector(-W*Mi*rhs3[rows,:])
P=add(P0,P1,P2,P3)
eqs=[s.factor(f) for f in C.euler_vector(C.jacobi(P)) if s.expand(f)!=0]
print('equations',len(eqs),'maxdegree',max(s.Poly(f,*pars).total_degree() for f in eqs),flush=True)
# Linear compression of the coefficient equations before Groebner reduction.
mons=sorted({m for f in eqs for m,v in s.Poly(f,*pars).terms()})
MM=s.Matrix([[s.Poly(f,*pars).coeff_monomial(s.prod(z**e for z,e in zip(pars,m))) for m in mons] for f in eqs]);_,idx=rref(MM.T);small=[eqs[i] for i in idx]
print('independent',len(small),flush=True)
gb=s.groebner(small,*pars,order='grevlex');polys=[s.factor(f.as_expr()) for f in gb.polys]
print('GB',list(map(str,polys)),flush=True)
out={'variables':list(map(str,pars)),'weights':[1,1,2,2],'weighted_polynomial_family':C.encode(P),'full_projective_Jacobi_generators':[str(f) for f in polys],'independent_raw_equations':[str(f) for f in small],
 'scope':'Exact full projective Jacobi equations of a positive-weight four-parameter slice; not the full six-parameter local scheme.'}
(HERE/'zero_positive_slice.json').write_text(json.dumps(out,indent=2)+'\n')
print('DONE',flush=True)

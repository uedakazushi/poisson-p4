"""Independent small commutative-algebra audit of the infinity tangent cone."""
from pathlib import Path
import json
import sympy as s
HERE=Path(__file__).resolve().parent
b,u,v,p,q,z=s.symbols('b u v p q z');L=2*u+v
ref=json.loads((HERE.parent/'infinity/higher_initial_4.json').read_text())
quartics=[s.sympify(f,locals={'b':b,'u':u,'v':v,'p':p,'q':q}) for f in ref['new_initial_equations_mod_quadratics']]
G3=[s.cancel(f/L) for f in quartics]
assert all(f.is_polynomial(b,u,v) and s.Poly(f,b,u,v).total_degree()==3 for f in G3)
GB=s.groebner(G3,u,v,b,order='grevlex')
K=[u*u-s.Rational(9,128)*v*v,u*v+v*v/4]
KB=s.groebner(K,u,v,b,order='grevlex')
sat=s.groebner(G3+[1-z*b],z,u,v,b,order='lex')
sat0=[f.as_expr() for f in sat.polys if not f.as_expr().has(z)]
SB=s.groebner(sat0,u,v,b,order='grevlex')
assert all(SB.reduce(f)[1]==0 for f in K)
assert all(KB.reduce(f)[1]==0 for f in sat0)
def hilbert(gb,d):
 lms=[f.LM(order=gb.order).exponents for f in gb.polys]
 return sum(not any(all(a>=c for a,c in zip(m,n)) for n in lms)
  for i in range(d+1) for j in range(d-i+1) for m in [(i,j,d-i-j)])
h=[hilbert(GB,d) for d in range(12)];hk=[hilbert(KB,d) for d in range(12)]
assert h==[1,3,6,5]+[4]*8
assert hk==[1,3]+[4]*10
assert [a-c for a,c in zip(h,hk)]==[0,0,2,1]+[0]*8
assert all(GB.reduce(b*b*f)[1]==0 for f in K)
assert GB.reduce(b*K[0])[1]!=0
# p andq are two additional degree1 socle elements in the full tangentcone.
hm=[0]+h[:-1];hm[1]+=2
assert hm==[0,3,3,6,5]+[4]*7
out={'all_passed':True,'quartics':[str(f) for f in quartics],
 'colon_cubic_ideal':[str(f) for f in G3],
 'saturation_by_b':[str(f.as_expr()) for f in SB.polys],
 'Hilbert_function_cubic_quotient':h,'Hilbert_function_saturated_quotient':hk,
 'nilradical_module_Hilbert_function':hm,'axis_multiplicity':4,
 'finite_length_torsion_of_cubic_quotient':3,'finite_length_torsion_of_full_graded_nilmodule':5,
 'graded_nilmodule_series':'t*(1+2*t+t^2)/(1-t)+2*t+2*t^3+t^4',
 'scope':'This audits the graded algebra. The identification with the full initial ideal additionally uses the actual T16 surface and the all-order multiplicity proof.'}
(HERE/'infinity_tangent_cone_independent_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',h,hm)

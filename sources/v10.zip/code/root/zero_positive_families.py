from pathlib import Path
import json,ast
from exact_calculus import *
from full_kuranishi import actual,rk,rref
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
C.pol=lambda f:{m:v for m,v in s.Poly(s.expand(f),*C.x).terms() if v}
a,b,p,q=s.symbols('a b p q');pars=[a,b,p,q]
ref=json.loads((HERE/'zero_positive_slice.json').read_text())
P=C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals=dict(zip(['t','x','y','z','w'],C.x))|dict(zip(ref['variables'],pars))) for I,f in ref['weighted_polynomial_family'].items()})
eqs=[s.sympify(f,locals=dict(zip(ref['variables'],pars))) for f in ref['full_projective_Jacobi_generators']]
sub={p:-s.Rational(4,3)*(a+b)**2,q:-8*(a+b)*(a-11*b)}
assert all(s.expand(f.subs(sub,simultaneous=True))==0 for f in eqs)
Fam=C.tensor({I:C.expr(f).subs(sub,simultaneous=True) for I,f in P.items()})
assert C.euler_vector(C.jacobi(Fam)).applyfunc(s.expand)==s.zeros(350,1)
def pf(M):
 f=0
 for i in range(5):
  j,k,l,m=[j for j in range(5) if j!=i]
  f+=(-1)**i*C.x[i]*(M[j,k]*M[l,m]-M[j,l]*M[k,m]+M[j,m]*M[k,l])
 return s.factor(f)
out={'branch1_parameters':{str(z):str(v) for z,v in sub.items()},'polynomial_family':C.encode(Fam),'full_projective_Poisson':True,'points':{}}
for aa,bb in [(0,0),(1,0),(0,1),(1,1),(2,1)]:
 ss={a:aa,b:bb};Ppt=C.tensor({I:C.expr(f).subs(ss) for I,f in Fam.items()});D=C.derivative(Ppt,True);A=actual(C,Ppt)
 dirs=[C.vector(C.tensor({I:s.diff(C.expr(f),z).subs(ss) for I,f in Fam.items()})) for z in [a,b]]
 info={'fullJacobi_rank':rk(D),'group_rank':rk(A),'actual_family_rank':rk(A.row_join(s.Matrix.hstack(*dirs))),'degeneracy_quintic':str(pf(C.as_matrix(Ppt)))}
 print(aa,bb,info,flush=True);out['points'][str((aa,bb))]=info
(HERE/'zero_positive_families.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',flush=True)

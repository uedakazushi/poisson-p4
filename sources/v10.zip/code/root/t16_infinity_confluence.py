"""Exact extension of the known T16 confluence to the U1 infinity chart."""
from pathlib import Path
import json,ast
from exact_calculus import *
from full_kuranishi import actual,rk,rref,kernel,primitive
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
C.pol=lambda f:{m:v for m,v in s.Poly(s.expand(f),*C.x).terms() if v}
b,k,h,eta=s.symbols('b k h eta')
ref=json.loads((HERE/'t16_reference.json').read_text())
M=s.zeros(5)
for key,val in ref['family'].items():
 i,j=ast.literal_eval(key);M[i,j]=s.sympify(val,locals=dict(zip(['t','x','y','z','w'],C.x))|{'h':h,'eta':eta});M[j,i]=-M[i,j]
G=s.Matrix([t,x,b*y-2*z,z,b*w+8*z+2*b*z]).jacobian(C.x)
sub=dict(zip(C.x,G.inv()*s.Matrix(C.x)))
F=((G*M.subs({eta:-2/b,h:b*k},simultaneous=True)*G.T)/b).subs(sub,simultaneous=True).applyfunc(s.cancel)
print('polynomial',all(f.is_polynomial(*C.x,b,k) for f in F),flush=True)
assert all(f.is_polynomial(*C.x,b,k) for f in F)
F=F.applyfunc(s.expand)
def point(bb):return C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,(2,3):-z*z/2,(2,4):x*z+bb*t*z+y*(x+2*z),(3,4):t*t+x*z+z*z})
assert F.subs(k,0)==C.as_matrix(point(b))
PF=C.tensor({I:F[I] for I in C.pairs})
assert C.cubic_vector(C.jacobi(PF)).applyfunc(s.expand)==s.zeros(350,1)
out={'polynomial_family':C.encode(PF),'source_equals_infinity_magnetic_chart':True,'affine_Poisson':True,'points':{}}
for bv,kv in [(0,0),(0,1),(0,2),(1,0),(1,1)]:
 P=C.tensor({I:F[I].subs({b:bv,k:kv}) for I in C.pairs});D=C.derivative(P,True);A=actual(C,P)
 db=C.vector(C.tensor({I:s.diff(F[I],b).subs({b:bv,k:kv}) for I in C.pairs}));dk=C.vector(C.tensor({I:s.diff(F[I],k).subs({b:bv,k:kv}) for I in C.pairs}))
 info={'D_rank':rk(D),'group_rank':rk(A),'family_rank':rk(A.row_join(db).row_join(dk)),'derivative_k':C.encode(C.from_vector(dk))}
 print(bv,kv,info,flush=True);out['points'][str((bv,kv))]=info
 if (bv,kv)==(0,0):
  magnetic=A.row_join(db);_,ap=rref(magnetic);AA=magnetic[:,ap];K=kernel(D);_,piv=rref(AA.row_join(K));NN=[primitive(K[:,j-AA.cols]) for j in piv if j>=AA.cols]
  N=s.Matrix.hstack(AA,*NN);sol,pars=N.gauss_jordan_solve(dk);assert pars.rows==0
  out['normal_coordinates_dk']=[str(q) for q in sol[-len(NN):]];out['normal_basis']=[C.encode(C.from_vector(q)) for q in NN]
  print('source normal',out['normal_coordinates_dk'],flush=True)
out['all_passed']=True
(HERE/'t16_infinity_confluence.json').write_text(json.dumps(out,indent=2)+'\n')

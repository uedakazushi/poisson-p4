"""Exact reduced decomposition of the positive-weight subslice (not the full germ)."""
from pathlib import Path
import ast,json
import sympy as s
from exact_calculus import Calculus
from full_kuranishi import actual,rk

HERE=Path(__file__).resolve().parent
C=Calculus(5); C.x=s.symbols('t x y z w'); t,x,y,z,w=C.x
C.pol=lambda f:{m:v for m,v in s.Poly(s.expand(f),*C.x).terms() if v}
a,b,p,q,P,Q,h,e=s.symbols('a b p q P Q h e')
ref=json.loads((HERE/'zero_positive_slice.json').read_text())
sy=dict(zip(['t','x','y','z','w'],C.x))|dict(zip(ref['variables'],[a,b,p,q]))
raw=[s.sympify(f,locals=sy) for f in ref['independent_raw_equations']]
shift={p:P-s.Rational(4,3)*(a+b)**2,q:Q-8*(a+b)*(a-11*b)}
shifted=[s.expand(f.subs(shift,simultaneous=True)) for f in raw]
F=(14*a-b)*P+3*(a+b)*Q
H=3*P+Q+15*b*(a+b)
G1=s.groebner(shifted,P,Q,a,b,domain=s.QQ)
G2=s.groebner([F,P*H],P,Q,a,b,domain=s.QQ)
assert list(G1)==list(G2)

def intersection(A,B):
    z=s.Dummy('z');gb=s.groebner([z*f for f in A]+[(1-z)*f for f in B],z,P,Q,a,b,domain=s.QQ)
    return [f for f in gb if not f.has(z)]
components=[[P,Q],[P,a+b],[H,(a-2*b)*P-9*b*(a+b)**2]]
gi=s.groebner(intersection(intersection(components[0],components[1]),components[2]),P,Q,a,b,domain=s.QQ)
assert list(gi)==list(G2), 'the exact positive ideal is already radical'
assert s.gcd(a-2*b,9*b*(a+b)**2)==1

base=C.tensor({tuple(ast.literal_eval(k)):s.sympify(f,locals=sy) for k,f in ref['weighted_polynomial_family'].items()})
def pf(M):
    f=0
    for i in range(5):
        j,k,l,m=[j for j in range(5) if j!=i]
        f+=(-1)**i*C.x[i]*(M[j,k]*M[l,m]-M[j,l]*M[k,m]+M[j,m]*M[k,l])
    return s.factor(f)

# Polynomial parametrizations on charts meeting the source.
families={
  'plane':({a:-e,b:e,p:0,q:h},[e,h],[(0,0),(1,0),(0,1),(1,1),(1,2)]),
  'third':({a:h*e,b:e,p:(h+1)**2*(35-4*h)*e**2/(3*(h-2)),q:(h+1)*(-8*h*h+62*h-173)*e**2/(h-2)},[e,h],[(0,0),(1,0),(1,1),(1,3)])
}
out={'scope':'exact restricted positive-weight four-parameter subslice, not the full six-parameter germ',
     'shift':{str(k):str(v) for k,v in shift.items()},
     'ideal':[str(F),str(P*H)],'exact_ideal_is_radical':True,
     'minimal_primes':[[str(f) for f in cc] for cc in components], 'families':{}}
for name,(sub,pars,pts) in families.items():
    assert all(s.cancel(f.subs(sub,simultaneous=True))==0 for f in raw)
    tensor=C.tensor({I:s.cancel(C.expr(f).subs(sub,simultaneous=True)) for I,f in base.items()})
    assert C.euler_vector(C.jacobi(tensor)).applyfunc(s.cancel)==s.zeros(350,1)
    result={'parameters':list(map(str,pars)), 'parameter_substitution':{str(k):str(v) for k,v in sub.items()},
            'full_projective_Poisson':True,'tensor':C.encode(tensor),'points':{}}
    for ee,hh in pts:
        at={e:ee,h:hh}
        pt=C.tensor({I:s.cancel(C.expr(f).subs(at)) for I,f in tensor.items()})
        D=C.derivative(pt,True); A=actual(C,pt)
        cols=[C.vector(C.tensor({I:s.diff(C.expr(f),v).subs(at) for I,f in tensor.items()})) for v in pars]
        rec={'fullJacobi_rank':rk(D),'group_rank':rk(A),'actual_family_rank':rk(A.row_join(s.Matrix.hstack(*cols))),
             'degeneracy_quintic':str(pf(C.as_matrix(pt)))}
        result['points'][str((ee,hh))]=rec
        print(name,ee,hh,rec,flush=True)
    out['families'][name]=result
out['all_passed']=True
target=HERE/'zero_positive_decomposition.json'
tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(out,indent=2)+'\n');tmp.replace(target)
print('ALL PASSED',flush=True)

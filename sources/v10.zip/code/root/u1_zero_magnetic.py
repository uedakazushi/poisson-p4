"""Zero magnetic class: actual three-parameter family and full tangent cone."""
from pathlib import Path
import json,ast
from exact_calculus import *
from full_kuranishi import actual,rk,rref,kernel,primitive,Slice
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
C.pol=lambda f:{m:v for m,v in s.Poly(s.expand(f),*C.x).terms() if v}
c,d,k,h,eta=s.symbols('c d k h eta')
ref=json.loads((HERE/'t16_reference.json').read_text());M=s.zeros(5)
for key,val in ref['family'].items():
 i,j=ast.literal_eval(key);M[i,j]=s.sympify(val,locals=dict(zip(['t','x','y','z','w'],C.x))|{'h':h,'eta':eta});M[j,i]=-M[i,j]
G=s.Matrix([t,x,c*y-2*d*z,z,c*w+8*d*z+2*c*z]).jacobian(C.x)
sub=dict(zip(C.x,G.inv()*s.Matrix(C.x)))
F=((G*M.subs({eta:-2*d/c,h:c*k},simultaneous=True)*G.T)/c).subs(sub,simultaneous=True).applyfunc(s.cancel)
assert all(f.is_polynomial(*C.x,c,d,k) for f in F)
F=F.applyfunc(s.expand)
P0=C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,(2,3):-z*z/2,(2,4):y*(x+2*z),(3,4):t*t+x*z+z*z})
assert F.subs(k,0)==C.as_matrix(P0)+C.as_matrix(C.tensor({(2,4):c*t*z+d*x*z}))
PF=C.tensor({I:F[I] for I in C.pairs})
assert C.cubic_vector(C.jacobi(PF)).applyfunc(s.expand)==s.zeros(350,1)
out={'universal_magnetic_T16_family':C.encode(PF),'source_equals_full_magnetic_plane':True,'affine_Jacobi_zero':True,'points':{}}
for cv,dv,kv in [(0,0,0),(0,0,1),(0,1,0),(1,0,0),(1,1,1)]:
 ss={c:cv,d:dv,k:kv};P=C.tensor({I:F[I].subs(ss) for I in C.pairs});D=C.derivative(P,True);A=actual(C,P)
 dirs=[C.vector(C.tensor({I:s.diff(F[I],a).subs(ss) for I in C.pairs})) for a in [c,d,k]]
 info={'D_rank':rk(D),'group_rank':rk(A),'family_rank':rk(A.row_join(s.Matrix.hstack(*dirs)))}
 print(ss,info,flush=True);out['points'][str((cv,dv,kv))]=info
S=Slice(C,P0);print('slice',len(S.R),flush=True);S.solve_order(2);eqs=S.residual_polynomials(2)
gb=s.groebner(eqs,*S.u,order='grevlex')
out['full_slice_basis']=[C.encode(q) for q in S.R];out['variables']=list(map(str,S.u));out['quadratic_ideal']=[str(q.as_expr()) for q in gb.polys]
X=s.Matrix([0,0,y,0,w])
op0=C.vector(C.lie(P0,X));assert op0==-C.vector(P0)
A=S.A;N=s.Matrix.hstack(A,*S.Rv);op=[]
for R in S.R:
 v=C.vector(C.lie(R,X))+C.vector(R);sol,params=N.gauss_jordan_solve(v);assert params.rows==0;op.append(sol[-len(S.R):,:])
W=s.Matrix.hstack(*op);out['torus_slice_action']=list(map(lambda row:list(map(str,row)),W.tolist()));out['weights']={str(a):int(m) for a,m in W.eigenvals().items()}
print('weights',out['weights'],flush=True);print('quadratic ideal',out['quadratic_ideal'],flush=True)
out['all_passed']=True
(HERE/'u1_zero_magnetic.json').write_text(json.dumps(out,indent=2)+'\n')

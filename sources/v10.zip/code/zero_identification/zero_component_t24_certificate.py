"""Exact PGL identification of the positive U1 zero-magnetic branch with T24."""
from pathlib import Path
import json,ast,hashlib
from engine import *
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
C.pol=lambda f:{m:q for m,q in s.Poly(s.expand(f),*C.x).terms() if q}
aa,bb,h=s.symbols('a b h');rho=s.sqrt(3)
ref=json.loads((HERE/'zero_component_reference.json').read_text())
loc=dict(zip(['t','x','y','z','w'],C.x))|{'a':aa,'b':bb}
F=C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals=loc) for I,f in ref['polynomial_family'].items()})
zero=lambda M:all(s.expand(q)==0 for q in M)
assert zero(C.euler_vector(C.jacobi(F)))
FM=C.as_matrix(F);P0=C.tensor({I:C.expr(f).subs({aa:0,bb:0}) for I,f in F.items()})
expected=C.tensor({(1,2):t*t-z*z,(1,4):-(x*x+8*x*z+8*z*z)/2,
 (2,3):-z*z/2,(2,4):y*(x+2*z),(3,4):t*t+x*z+z*z})
assert zero(C.vector(P0)-C.vector(expected))
P1=C.tensor({I:C.expr(f).subs({aa:0,bb:1}) for I,f in F.items()});M1=C.as_matrix(P1)
curve=FM.subs({aa:0,bb:h}).applyfunc(s.expand)
G=s.diag(1,1,1/h,1,1/h);Ginv=G.inv()
orbit_curve=(h*G*M1.subs(dict(zip(C.x,Ginv*s.Matrix(C.x))),simultaneous=True)*G.T).applyfunc(s.expand)
assert zero(curve-orbit_curve)

# The five eigen-linear forms, arranged in catalog T24 order(U,A,V,B,T).
forms=s.Matrix([
 t/6+w+2*y+rho*x/18+rho*z/9,
 t/6+w+2*y-rho*x/18-rho*z/9,
 t/2+w-10*y+rho*z/2,
 t/2+w-10*y-rho*z/2,
 t/2+w+2*y])
L=forms.jacobian(C.x);assert L.det()!=0
Z=s.symbols('U A V B T');U,A,V,B,T=Z
Pnew=(L*M1*L.T).subs(dict(zip(C.x,L.inv()*s.Matrix(Z))),simultaneous=True).applyfunc(s.expand)
W=s.Matrix([s.cancel(Pnew[4,i]/T) for i in range(5)])
assert all(s.Poly(f,*Z).total_degree()<=1 for f in W)
E=s.Matrix(Z);Pc=(Pnew-(E*W.T-W*E.T)).applyfunc(s.expand)
assert Pc[4,:]==s.zeros(1,5)
p,q,r=s.symbols('p q r');D=Calculus(5);D.x=Z
D.pol=lambda f:{m:c for m,c in s.Poly(s.expand(f),*Z).terms() if c}
Template=D.tensor({(0,1):U*A+p*T*T,(0,2):-U*V+q*A*T,(0,3):-U*B,
 (1,2):A*V,(1,3):A*B+r*U*T,(2,3):2*V*B+q*r*T*T/2})
assert zero(D.cubic_vector(D.jacobi(Template)))
TM=D.as_matrix(Template)
spec={p:s.Rational(5,27),q:-2,r:2}
assert zero(Pc-4*rho*TM.subs(spec))
pf=s.factor(TM[0,1]*TM[2,3]-TM[0,2]*TM[1,3]+TM[0,3]*TM[1,2])

# Identify the three smoothing weights and the period line with catalog T24.
catalog=json.loads((HERE/'catalog.json').read_text())['diagrams'];diag=next(d for d in catalog if d['id']=='T24')
bires=s.Matrix(diag['biresidue_example']);lam=(bires+s.ones(5)/5).inv()-s.ones(5)/5
lam=s.Matrix(5,5,lambda i,j:lam[i,j]-lam[4,j]+lam[4,i])
template_log=s.zeros(5)
for i in range(5):
 for j in range(i+1,5):
  template_log[i,j]=s.Poly(TM[i,j].subs({p:0,q:0,r:0}),*Z).coeff_monomial(Z[i]*Z[j]);template_log[j,i]=-template_log[i,j]
assert template_log==-2*lam
expected_edges=[((0,1),(0,0,0,0,2)),((0,2),(0,1,0,0,1)),((1,3),(1,0,0,0,1))]
for edge,(pair,mon) in zip(diag['edges'],expected_edges):
 assert tuple(edge['edge'])==pair and tuple(int(edge['orders'].get(str(k),0)) for k in range(5))==mon
weights=s.Matrix([[mon[k]-int(k in pair) for k in range(5)] for pair,mon in expected_edges]);assert weights.rank()==3

def piv(X):return list(DomainMatrix.from_Matrix(X).convert_to(s.QQ).rref()[1])
def minor(X):
 cols=piv(X);Y=X[:,cols];rows=piv(Y.T);det=s.QQ.to_sympy(DomainMatrix.from_Matrix(Y[rows,:]).convert_to(s.QQ).det())
 assert det
 return {'rank':len(cols),'rows':rows,'columns':cols,'determinant':str(det)}
def actual(P):
 vv=[C.vertical(i,j) for i in range(5) for j in range(5)]+[P]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=C.x[j];vv.append(C.lie(P,X))
 return s.Matrix.hstack(*map(C.vector,vv))
points={}
for name,P,subs in [('source',P0,{aa:0,bb:0}),('regular_T24',P1,{aa:0,bb:1})]:
 J=C.derivative(P,True);ACT=actual(P)
 tangent=[C.vector(C.tensor({I:s.diff(C.expr(f),par).subs(subs) for I,f in F.items()})) for par in(aa,bb)]
 ALL=ACT.row_join(s.Matrix.hstack(*tangent));assert zero(J*ALL)
 points[name]={'Jacobi':minor(J),'group_vertical_scale':minor(ACT),'actual_two_parameter_family':minor(ALL)}
assert points['source']['Jacobi']['rank']==98 and points['source']['group_vertical_scale']['rank']==46 and points['source']['actual_two_parameter_family']['rank']==48
assert points['regular_T24']['Jacobi']['rank']==102 and points['regular_T24']['group_vertical_scale']['rank']==48 and points['regular_T24']['actual_two_parameter_family']['rank']==48
out={'all_passed':True,'identified_component':'T24','reference_sha256':hashlib.sha256((HERE/'zero_component_reference.json').read_bytes()).hexdigest(),
 'curve':'F(a=0,b=h), h=0 source; every h!=0 is in the regular T24 open orbit',
 'curve_orbit_identity':'F(0,h)=h*G_h*F(0,1)(G_h^(-1)x)*G_h^T, G_h=diag(1,1,1/h,1,1/h)',
 'all_two_parameter_projective_Jacobi_zero':True,'source_exact_zero_magnetic_U1':True,
 'linear_forms':list(map(str,forms)),'linear_change':str(L),'linear_determinant':str(s.simplify(L.det())),
 'vertical_vector':list(map(str,W)),'projective_scalar':'4*sqrt(3)',
 'T24_template':D.encode(Template),'template_universal_affine_Jacobi_zero':True,'template_Pfaffian':str(pf),
 'template_parameters':{str(k):str(v) for k,v in spec.items()},'catalog_period_matrix':str(lam),'template_log_matrix':str(template_log),
 'catalog_smoothing_weights':[list(map(int,w)) for w in weights.tolist()],'smoothing_weight_rank':3,'points':points,
 'scope':'Identifies one actual component through the zero-magnetic point; not a complete local-ring or all-component statement.'}
(HERE/'zero_component_t24_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print({'component':'T24','determinant':out['linear_determinant'],'vertical':out['vertical_vector'],'generic_ranks':[102,48,48],'source_ranks':[98,46,48]},flush=True)
print('PASS',flush=True)

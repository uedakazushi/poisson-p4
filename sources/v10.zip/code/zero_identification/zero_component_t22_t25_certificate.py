"""Exact PGL identification and actual degeneration curves for T22 and T25."""
from pathlib import Path
import json,ast,hashlib
from engine import *
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
C.pol=lambda f:{m:q for m,q in s.Poly(s.expand(f),*C.x).terms() if q}
e,h,k=s.symbols('e h k');rho=s.sqrt(3);tau=s.sqrt(2)
loc=dict(zip(['t','x','y','z','w'],C.x))|{'e':e,'h':h}
ref=json.loads((HERE/'zero_component_other_branches_reference.json').read_text())
catalog=json.loads((HERE/'catalog.json').read_text())['diagrams']
Z=s.symbols('U A V B T');U,A,V,B,T=Z;p,q,r=s.symbols('p q r')
D=Calculus(5);D.x=Z;D.pol=lambda f:{m:c for m,c in s.Poly(s.expand(f),*Z).terms() if c}
zero=lambda M:all(s.expand(f)==0 for f in M)
templates={
'T22':D.tensor({(0,1):U*A+p*T*T,(0,2):-U*V+q*T*T,(0,3):-U*B,
 (1,2):A*V,(1,3):A*B+r*T*T,(2,3):V*B}),
'T25':D.tensor({(0,1):U*A+p*T*T,(0,2):-U*V+q*A*A,(0,3):-U*B,
 (1,2):A*V,(1,3):A*B+r*U*U,(2,3):3*V*B+s.Rational(2,3)*q*r*U*A-p*q*r*T*T/3})}
forms={
'T22':s.Matrix([w+2*y+tau*x/2+tau*z,w+2*y-tau*x/2-tau*z,z-tau*y,z+tau*y,t]),
'T25':s.Matrix([4*t/17+w+rho*x/17+2*y+2*rho*z/17,
4*t/17+w-rho*x/17+2*y-2*rho*z/17,
4*t/17+w-rho*x/51-74*y/17+10*rho*z/51,
4*t/17+w+rho*x/51-74*y/17-10*rho*z/51,t/2+w+2*y])}
spec={'T22':{p:4,q:-tau,r:-tau},'T25':{p:s.Rational(32,289),q:-1,r:1}}
scale={'T22':tau,'T25':3*rho};catalogscale={'T22':-1,'T25':-3}
edges={'T22':[((0,1),(0,0,0,0,2)),((0,2),(0,0,0,0,2)),((1,3),(0,0,0,0,2))],
'T25':[((0,1),(0,0,0,0,2)),((0,2),(0,2,0,0,0)),((1,3),(2,0,0,0,0))]}
expected=C.tensor({(1,2):t*t-z*z,(1,4):-(x*x+8*x*z+8*z*z)/2,
 (2,3):-z*z/2,(2,4):y*(x+2*z),(3,4):t*t+x*z+z*z})
def piv(X):return list(DomainMatrix.from_Matrix(X).convert_to(s.QQ).rref()[1])
def minor(X):
 cols=piv(X);Y=X[:,cols];rows=piv(Y.T);det=s.QQ.to_sympy(DomainMatrix.from_Matrix(Y[rows,:]).convert_to(s.QQ).det())
 assert det
 return {'rank':len(cols),'rows':rows,'columns':cols,'determinant':str(det)}
def actual(P):
 vv=[C.vertical(i,j) for i in range(5) for j in range(5)]+[P]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=C.x[j];vv.append(C.lie(P,X))
 return s.Matrix.hstack(*map(C.vector,vv))
out={'reference_sha256':hashlib.sha256((HERE/'zero_component_other_branches_reference.json').read_bytes()).hexdigest(),'components':{}}
for name,label,sub,curve_sub in [('plane','T22',{e:0,h:1},{e:0,h:k*k}),('third','T25',{e:1,h:0},{e:k,h:0})]:
 fam=ref['families'][name]
 F=C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals=loc) for I,f in fam['tensor'].items()})
 FM=C.as_matrix(F);M1=FM.subs(sub).applyfunc(s.expand)
 P1=C.tensor({I:C.expr(f).subs(sub) for I,f in F.items()})
 curve=FM.subs(curve_sub).applyfunc(s.expand)
 assert zero(curve.subs(k,0)-C.as_matrix(expected))
 G=s.diag(1,1,1/k,1,1/k)
 orbit=(k*G*M1.subs(dict(zip(C.x,G.inv()*s.Matrix(C.x))),simultaneous=True)*G.T).applyfunc(s.expand)
 assert zero(curve-orbit)
 assert zero(C.euler_vector(C.jacobi(P1)))
 L=forms[label].jacobian(C.x);assert s.simplify(L.det())!=0
 Pnew=(L*M1*L.T).subs(dict(zip(C.x,L.inv()*s.Matrix(Z))),simultaneous=True).applyfunc(s.expand)
 W=s.Matrix([s.cancel(Pnew[4,i]/T) for i in range(5)]);E=s.Matrix(Z)
 assert all(s.Poly(f,*Z).total_degree()<=1 for f in W)
 Pc=(Pnew-(E*W.T-W*E.T)).applyfunc(s.expand)
 assert Pc[4,:]==s.zeros(1,5)
 Template=templates[label];TM=D.as_matrix(Template)
 assert zero(D.cubic_vector(D.jacobi(Template)))
 assert zero(Pc-scale[label]*TM.subs(spec[label]))
 diag=next(d for d in catalog if d['id']==label);Bres=s.Matrix(diag['biresidue_example'])
 lam=(Bres+s.ones(5)/5).inv()-s.ones(5)/5
 lam=s.Matrix(5,5,lambda i,j:lam[i,j]-lam[4,j]+lam[4,i]);log=s.zeros(5)
 for i in range(5):
  for j in range(i+1,5):
   log[i,j]=s.Poly(TM[i,j].subs({p:0,q:0,r:0}),*Z).coeff_monomial(Z[i]*Z[j]);log[j,i]=-log[i,j]
 assert log==catalogscale[label]*lam
 for edge,(pair,mon) in zip(diag['edges'],edges[label]):
  assert tuple(edge['edge'])==pair and tuple(int(edge['orders'].get(str(i),0)) for i in range(5))==mon
 weights=s.Matrix([[mon[i]-int(i in pair) for i in range(5)] for pair,mon in edges[label]])
 assert weights.rank()==3
 J=C.derivative(P1,True);ACT=actual(P1)
 assert zero(J*ACT)
 full=minor(J);group=minor(ACT);assert full['rank']==102 and group['rank']==48
 pf=s.factor(TM[0,1]*TM[2,3]-TM[0,2]*TM[1,3]+TM[0,3]*TM[1,2])
 data={'identified_component':label,'branch':name,'representative_substitution':{str(a):str(b) for a,b in sub.items()},
 'curve_substitution':{str(a):str(b) for a,b in curve_sub.items()},'curve_source_is_exact_zero_magnetic_U1':True,
 'curve_orbit_identity':'F_curve(k)=k*G_k*P1(G_k^(-1)x)*G_k^T, G_k=diag(1,1,k^(-1),1,k^(-1))',
 'all_nonzero_curve_points_regular_open_orbit':True,'linear_forms':list(map(str,forms[label])),'linear_change':str(L),
 'linear_determinant':str(s.simplify(L.det())),'vertical_vector':list(map(str,W)),'projective_scalar':str(scale[label]),
 'template':D.encode(Template),'template_parameters':{str(a):str(b) for a,b in spec[label].items()},
 'template_universal_affine_Poisson':True,'template_Pfaffian':str(pf),
 'catalog_central_period_matrix':str(lam),'catalog_log_scale':str(catalogscale[label]),
 'smoothing_weight_rank':3,'Jacobi_certificate':full,'group_certificate':group}
 out['components'][label]=data
 print({'component':label,'determinant':data['linear_determinant'],'fullJacobi':102,'group':48},flush=True)
out['all_passed']=True
out['scope']='Exact incidence with previously counted T22 and T25. Does not increase component lower bound or classify the full source germ.'
(HERE/'zero_component_t22_t25_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',flush=True)

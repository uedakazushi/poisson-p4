from pathlib import Path
import json,ast,time
import sympy as s
from ab_local_engine import Calculus,rank
from explore_relative import model,simple_normals,actual
from compact_normal import normal_R,normal_S
HERE=Path(__file__).resolve().parent
start=time.time();C=Calculus(5);C.x=s.symbols('t u a v b');t,u,a,v,b=C.x
C.pol=lambda f:{m:c for m,c in s.Poly(s.expand(f),*C.x).terms() if c}
aa,mu,nu,r,h,p,q=s.symbols('a0 mu nu r s p q');c0=1+aa
loc={str(v):v for v in (*C.x,aa,mu,nu,r,h,p,q)}
R=normal_R(C,c0,mu,h)
RM=C.as_matrix(R)
phi=s.Matrix([s.I*t,v,b,-u,-a]);L=phi.jacobian(C.x);old=L.inv()*s.Matrix(C.x)
SM=-(L*RM.subs({mu:s.I*nu,h:-s.I*r},simultaneous=True)*L.T).subs(dict(zip(C.x,old)),simultaneous=True)
SM=SM.applyfunc(s.expand);assert not any(f.has(s.I) for f in SM)
S=normal_S(C,c0,nu,r)
assert all(s.expand(f)==0 for f in C.as_matrix(S)-SM)
Q=model(C,c0,mu,nu,r,h)
Fp=8*(1+12*mu*h)*nu+3*c0*h;Fq=8*(1+12*nu*r)*mu+3*c0*r
subs_p={r:0,nu:-3*c0*h/(8*(1+12*mu*h))}
subs_q={h:0,mu:-3*c0*r/(8*(1+12*nu*r))}
assert all(s.expand(f)==0 for f in C.euler_vector(C.jacobi(Q)))
LP=C.euler_vector(C.polar(Q,R));LQ=C.euler_vector(C.polar(Q,S))
assert all(s.cancel(f.subs(subs_p))==0 for f in LP)
assert all(s.cancel(f.subs(subs_q))==0 for f in LQ)
zero={aa:0,mu:0,nu:0,r:0,h:0};R0,S0=simple_normals(C)
assert C.vector(R).subs(zero)==2*C.vector(R0)
assert C.vector(S).subs(zero)==2*C.vector(S0)
Q0=model(C,1,0,0,0,0);D=C.derivative(Q0,True);G=actual(C,Q0)
family=s.Matrix.hstack(*[C.vector(C.tensor({I:s.diff(C.expr(f),z).subs(zero) for I,f in Q.items()})) for z in (aa,mu,nu,r,h)])
ACT=G.row_join(family)
assert [rank(D),rank(G),rank(ACT),rank(ACT.row_join(C.vector(R).subs(zero)).row_join(C.vector(S).subs(zero)))]==[98,45,50,52]
coords=s.Matrix([aa,r,Fp,h,Fq]);theta=s.Matrix([aa,mu,nu,r,h]);jac=coords.jacobian(theta).subs(zero)
assert jac.det()!=0
muprime=mu+12*mu*nu*r+3*aa*r/8
nuprime=nu+12*mu*nu*h+3*aa*h/8
assert s.expand(Fq-(8*muprime+3*r))==0
assert s.expand(Fp-(8*nuprime+3*h))==0
straight=s.Matrix([aa,muprime,nuprime,r,h]).jacobian(theta)
assert straight.subs(zero)==s.eye(5)
assert s.expand(straight.det()-(1+12*mu*h+12*nu*r))==0
# Direct polynomial-ideal verification of the universal Euler-Jacobi equation.
# All quadratic terms in p,q vanish in the candidate square-zero algebra;
# the two linear terms are reduced by a Groebner basis of each smooth support.
gp=s.groebner([r,Fp],r,nu,mu,h,aa,domain=s.QQ)
gq=s.groebner([h,Fq],h,mu,nu,r,aa,domain=s.QQ)
assert all(gp.reduce(s.expand(f))[1]==0 for f in LP)
assert all(gq.reduce(s.expand(f))[1]==0 for f in LQ)
out={'all_passed':True,'scope':'Exact full projective Euler-Jacobi identities for a universal square-zero family; all-order formal theorem proved separately.',
 'source':C.encode(Q0),'toric_family':C.encode(Q),'normal_R':C.encode(R),'normal_S':C.encode(S),
 'universal_square_zero_family':'Q+(p/2)*R+(q/2)*S',
 'support_p':['r',str(Fp)],'support_q':['s',str(Fq)],'ideal_generators':['p**2','p*q','q**2','r*p',str(Fp*p),'s*q',str(Fq*q)],
 'normal_source_scalings':[2,2],'all350_linear_support_identities':True,'polynomial_ideal_membership_verified':True,
 'identity_linear_support_straightening':{'mu_prime':str(muprime),'nu_prime':str(nuprime),'Jacobian_determinant':str(s.factor(straight.det()))},
 'actual_source_ranks':[98,45,50,52],'base_coordinate_order':['a0','r','Fp','s','Fq'],'base_coordinate_Jacobian':str(jac),'base_coordinate_Jacobian_determinant':str(jac.det()),
 'simplified_complete_local_ring':'C[[b1,...,b20,t,alpha,beta,gamma,delta,p,q]]/(p²,pq,q²,alpha*p,beta*p,gamma*q,delta*q)',
 'elapsed':time.time()-start}
(HERE/'square_zero_family_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS exact square-zero family; source tangent isomorphism; support-coordinate automorphism',flush=True)

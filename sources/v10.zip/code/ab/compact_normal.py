"""Compact polynomial AB support normal; no matrix inversions are required."""
from pathlib import Path
import ast,json
import sympy as s
from ab_local_engine import Calculus
HERE=Path(__file__).resolve().parent

def normal_R(C,c,mu,h):
 c,mu,h=map(s.sympify,(c,mu,h))
 t,u,a,v,b=C.x;d=1+12*mu*h;K=d*d+6*c*c*h*h
 L=K-c*d*(2*d+1)/3;M=c*c*h+2*mu*d
 return C.tensor({
 (0,1):4*a*h*d*(4*M*t-c*(2*d+1)*u/3),
 (0,2):-s.Rational(2,3)*a*a*h*c*d*(4*d-1),
 (0,3):-8*a*h*h*c*d*(h*b+2*t),
 (0,4):-a*(4*L*t+c*h*d*v),
 (1,2):-s.Rational(4,3)*a*a*d*(2*K+d),
 (1,3):-8*a*h*(K*(t+h*b)+c*h*d*u),
 (1,4):a*(16*d*M*t-K*(4*u+v)),
 (2,3):-8*a*a*h*h*c*d,
 (2,4):-2*a*a*(2*K-c*d),
 (3,4):-4*a*(L*v+2*c*h*d*t)})

def normal_S(C,c,nu,r):
 t,u,a,v,b=C.x
 RR=C.as_matrix(normal_R(C,c,s.I*nu,-s.I*r))
 L=s.Matrix([s.I*t,v,b,-u,-a]).jacobian(C.x);old=L.inv()*s.Matrix(C.x)
 SM=-(L*RR*L.T).subs(dict(zip(C.x,old)),simultaneous=True).applyfunc(s.expand)
 return C.tensor({I:SM[I] for I in C.pairs})

def main():
 C=Calculus(5);C.x=s.symbols('t u a v b');C.pol=lambda f:{m:v for m,v in s.Poly(s.expand(f),*C.x).terms() if v}
 aa,mu,h=s.symbols('a0 mu s');c=1+aa
 loc={str(x):x for x in (*C.x,aa,mu,h)}
 old=json.loads((HERE/'exact_p_support.json').read_text())
 ref=C.tensor({ast.literal_eval(I):s.sympify(v,locals=loc) for I,v in old['normal'].items()})
 R=normal_R(C,c,mu,h)
 assert all(s.expand(f)==0 for f in C.vector(R)-C.vector(ref))
 print('PASS compact polynomial normal equals exact elimination certificate',flush=True)

if __name__=='__main__':main()

from pathlib import Path
import json,math
import sympy as s
from sympy.polys.matrices import DomainMatrix
from ab_local_engine import Calculus,rank
from explore_relative import model,simple_normals,actual
HERE=Path(__file__).resolve().parent
def piv(M):return list(DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1])
C=Calculus(5);C.x=s.symbols('t u a v b');C.pol=lambda f:{m:c for m,c in s.Poly(s.expand(f),*C.x).terms() if c}
aa,mu,nu,r,h,p,q=s.symbols('a0 mu nu r s p q');theta=(aa,mu,nu,r,h);pars=theta+(p,q)
Q=model(C,1+aa,mu,nu,r,h);zero=dict.fromkeys(theta,0);Q0=model(C,1,0,0,0,0)
assert all(s.expand(f)==0 for f in C.cubic_vector(C.jacobi(Q)))
D=C.derivative(Q0,True);G=actual(C,Q0)
families=[C.tensor({I:s.diff(C.expr(f),z).subs(zero) for I,f in Q.items()}) for z in theta]
N=[*families,*simple_normals(C)];NV=s.Matrix.hstack(*map(C.vector,N));ACT=G.row_join(NV[:,:5])
assert [rank(D),rank(G),rank(ACT),rank(G.row_join(NV))]==[98,45,50,52]
mon=[(i,j) for i in range(7) for j in range(i,7)]
Obs=s.Matrix.hstack(*[C.euler_vector(C.polar(N[i],N[j]))/(2 if i==j else 1) for i,j in mon])
cols=piv(D);DD=D[:,cols];rows=piv(DD.T);res=Obs-DD*DD[rows,:].inv()*Obs[rows,:]
rr=piv(res.T);eq=[s.expand(sum(res[k,l]*pars[i]*pars[j] for l,(i,j) in enumerate(mon))) for k in rr]
target=[p*p,p*q,q*q,r*p,(8*nu+3*h)*p,h*q,(8*mu+3*r)*q]
assert len(rr)==7 and s.groebner(eq,*pars,domain=s.QQ)==s.groebner(target,*pars,domain=s.QQ)
# The indicated invertible linear base change produces a monomial ideal.
U,V=s.symbols('U V');lin={mu:(U-3*r)/8,nu:(V-3*h)/8}
mono=[p*p,p*q,q*q,r*p,V*p,h*q,U*q]
assert [s.expand(f.subs(lin)) for f in target]==mono
hilbert=[2*math.comb(d+1,2) for d in range(1,9)]
out={'all_passed':True,'source_ranks':{'full_Jacobi':98,'group_vertical_scale':45,'actual_toric':50,'actual_plus_normals':52},'projective_dimensions':{'orbit':20,'toric':25,'tangent':27},'quadratic_ideal_generators':list(map(str,target)),'quadratic_cokernel_rows':rr,'quadratic_forms':list(map(str,eq)),'monomial_base_change':{str(k):str(v) for k,v in lin.items()},'normal_module_Hilbert_series':'2*z/(1-z)^3','normal_module_hilbert_degrees1to8':hilbert,'formal_consequences_proved_in_text':{'finite_A_module_generators':['1','p','q'],'dim_M_at_most':3,'dim3_multiplicity_at_most':2,'extra_projective_component_dimension_at_most':23,'extra_dimension23_formal_branch_multiplicity_sum_at_most':2},'not_asserted':['complete local-ring presentation','nilpotence of M','absence of lower-dimensional components']}
(HERE/'finite_algebra_inputs.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS full coefficient ranks, quadratic ideal, and normal-module Hilbert upper bound',flush=True)

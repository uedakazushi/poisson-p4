from pathlib import Path
import json,math
import sympy as s
HERE=Path(__file__).resolve().parent
alpha,beta,gamma,delta,p,q,z=s.symbols('alpha beta gamma delta p q z')
xs=(alpha,beta,gamma,delta,p,q)
I=[p*p,p*q,q*q,alpha*p,beta*p,gamma*q,delta*q]
P=[p,q];Qp=[q,p*p,alpha,beta];Qq=[p,q*q,gamma,delta]
def gb(L):return s.groebner(L,*xs,domain=s.QQ)
def intersect(A,B):
 G=s.groebner([z*f for f in A]+[(1-z)*g for g in B],z,*xs,domain=s.QQ)
 return [f.as_expr() for f in G.polys if not f.as_expr().has(z)]
intersection=intersect(intersect(P,Qp),Qq)
assert gb(intersection)==gb(I)
# Degree-d monomials in the homogeneous model, omitting the smooth tau.
def monomials(d,n):
 if n==1:return [(d,)]
 return [(i,)+m for i in range(d+1) for m in monomials(d-i,n-1)]
lead=[(0,0,0,0,2,0),(0,0,0,0,1,1),(0,0,0,0,0,2),
       (1,0,0,0,1,0),(0,1,0,0,1,0),(0,0,1,0,0,1),(0,0,0,1,0,1)]
values=[]
for d in range(8):
 count=sum(not any(all(x>=y for x,y in zip(m,k)) for k in lead) for m in monomials(d,6))
 expected=math.comb(d+3,3)+(2*d if d>=1 else 0)
 assert count==expected;values.append(count)
out={'all_passed':True,'ideal':list(map(str,I)),'primary_decomposition':{'prime':list(map(str,P)),'p_primary':list(map(str,Qp)),'q_primary':list(map(str,Qq))},'nilradical_generators':['p','q'],'nilradical_square_zero':True,'associated_primes':['(p,q)','(p,q,alpha,beta)','(p,q,gamma,delta)'],'extra_intersection_associated_prime':False,'Hilbert_series_without_tau':'1/(1-z)^4+2*z/(1-z)^2','Hilbert_values_degrees0to7_without_tau':values,'Hilbert_series_with_tau':'1/(1-z)^5+2*z/(1-z)^3','full_projective_dimensions':{'reduced_component':25,'embedded_strata':[23,23],'embedded_support_intersection':21},'closed_toric_fibre_basis':['1','p','q']}
(HERE/'square_zero_local_algebra.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS primary decomposition, square-zero module, Hilbert series and dimensions',flush=True)

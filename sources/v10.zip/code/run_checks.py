"""Reproduce v10 certificates in an isolated copy; leave distributed sources intact.

Python 3.12 / SymPy 1.14.0. No network access is used.
The optional --slow-independent switch also reruns the two large naive
Macaulay computations; their completed independent certificates are always
compared by the standard audit.
"""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile,time

CODE=Path(__file__).resolve().parent
PACKAGE=CODE.parent

def normalize(value):
    if isinstance(value,dict):
        return {k:normalize(v) for k,v in value.items()
                if k not in {'seconds','elapsed','elapsed_seconds','execution_seconds'}}
    if isinstance(value,list):return [normalize(v) for v in value]
    return value

def compare_json(expected,actual):
    e=json.loads(expected.read_text());a=json.loads(actual.read_text())
    assert normalize(e)==normalize(a),f'Certificate mismatch: {actual.name}'
    if isinstance(a,dict) and 'all_passed' in a:
        assert a['all_passed'] is True
    return hashlib.sha256(actual.read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=PACKAGE.parent/'p4_v10_check_results')
    parser.add_argument('--slow-independent',action='store_true')
    args=parser.parse_args();output=args.output.resolve()
    output.mkdir(parents=True,exist_ok=True)
    # Dependencies are executed in order. Every expected JSON is compared in full,
    # ignoring only elapsed wall time, not mathematical content or source hashes.
    checks=[
      ('ab_inputs','ab',['certify_finite_algebra_inputs.py'],['finite_algebra_inputs.json']),
      ('ab_exact_family','ab',['certify_square_zero_family.py'],['square_zero_family_certificate.json']),
      ('ab_local_algebra','ab',['verify_square_zero_algebra.py'],['square_zero_local_algebra.json']),
      ('ab_independent_matrix','independent_ab',['audit_ab_square_zero.py'],['ab_square_zero_independent_audit.json']),
      ('t16_infinity_family','root',['t16_infinity_confluence.py'],['t16_infinity_confluence.json']),
      ('infinity_basis','infinity',['binary_samples.py'],['binary_samples.json']),
      ('infinity_full_slice','infinity',['infinity_slice.py'],['infinity_slice.json']),
      ('infinity_complete_initial_4','infinity',['higher_initial.py','4'],['higher_initial_4.json']),
      ('infinity_geometry','infinity',['infinity_geometry_certificate.py'],['infinity_geometry_certificate.json']),
      ('infinity_graded_algebra','infinity',['graded_algebra_audit.py'],['graded_algebra_audit.json']),
      ('infinity_graded_independent','root',['audit_infinity_tangent_cone.py'],['infinity_tangent_cone_independent_audit.json']),
      ('infinity_residuals_6','infinity',['build_jet_cache.py','6'],['jet_residuals_6.json']),
      ('infinity_fiber_5','infinity',['fiber_lengths_fast.py','5','2'],['fiber_lengths_fast_5.json']),
      ('infinity_fibers_6','infinity',['fiber_lengths_fast.py','6','1','2','3'],['fiber_lengths_fast_6.json']),
      ('infinity_fiber_audit','infinity',['audit_fiber_lengths.py'],['fiber_lengths_audit.json']),
      ('infinity_all_orders_audit','independent_infinity',['infinity_all_orders_independent_audit.py'],['infinity_all_orders_independent_audit.json']),
      ('zero_t16_family','root',['u1_zero_magnetic.py'],['u1_zero_magnetic.json']),
      ('zero_positive_slice','root',['zero_positive_slice.py'],['zero_positive_slice.json']),
      ('zero_t24_family','root',['zero_positive_families.py'],['zero_positive_families.json']),
      ('zero_positive_decomposition','root',['zero_positive_decomposition.py'],['zero_positive_decomposition.json']),
      ('zero_t24_identification','zero_identification',['zero_component_t24_certificate.py'],['zero_component_t24_certificate.json']),
      ('zero_t22_t25_identification','zero_identification',['zero_component_t22_t25_certificate.py'],['zero_component_t22_t25_certificate.json']),
      ('catalog_all_three_path5','catalog',['path5_models.py'],['path5_models.json']),
    ]
    if args.slow_independent:
        checks[14:14]=[
          ('infinity_naive_b2_degree5','infinity',['fiber_lengths.py','5','2'],['fiber_lengths_naive_5.json']),
          ('infinity_naive_b_degree6','infinity',['fiber_lengths.py','6','1'],['fiber_lengths_naive_6.json'])]
    reports=[];started=time.time()
    env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
    with tempfile.TemporaryDirectory(prefix='p4_v10_reproduce_') as tmp:
        work=Path(tmp)/'code';shutil.copytree(CODE,work,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        for index,(name,sub,command,certificates) in enumerate(checks,1):
            start=time.time()
            proc=subprocess.run([sys.executable,*command],cwd=work/sub,env=env,
                                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            (output/f'{index:02d}_{name}.log').write_text(proc.stdout)
            assert proc.returncode==0,f'{name} failed; see {output}'
            hashes={}
            for filename in certificates:
                path=work/sub/filename
                assert path.is_file(),f'{name}: missing output {filename}'
                destination=output/'certificates'/sub/filename
                destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,destination)
                hashes[filename]=compare_json(CODE/sub/filename,path)
            reports.append({'name':name,'command':[sys.executable,*command],
                            'exit_code':proc.returncode,'certificate_sha256':hashes,
                            'seconds':round(time.time()-start,3),'passed':True})
            print(f'{index:02d}/{len(checks)} PASS {name} ({reports[-1]["seconds"]}s)',flush=True)
    assert len(reports)==len(checks) and all(r['passed'] for r in reports)
    result={'all_passed':True,'check_count':len(reports),'slow_independent_rerun':args.slow_independent,
            'python_version':sys.version,'reports':reports,'seconds':time.time()-started,
            'scope':'Exact finite coefficient certificates and independent algebra; all-order mathematical arguments are in the paper and proofs directory.'}
    target=output/'verification_summary.json';tmp=target.with_suffix('.tmp')
    tmp.write_text(json.dumps(result,indent=2)+'\n');tmp.replace(target)
    print('ALL CHECKS PASSED',flush=True)

if __name__=='__main__':main()

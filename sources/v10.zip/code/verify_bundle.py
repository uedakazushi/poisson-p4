"""Read-only integrity check of the complete distributed v10 source bundle."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent.parent
data=json.loads((ROOT/'manifest.json').read_text())
assert data['algorithm']=='SHA256'
actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*')
        if p.is_file() and p.name!='manifest.json' and '__pycache__' not in p.parts}
expected=set(data['files'])
# Historical editions have their own manifests; these are regular payload files.
actual.update(str(p.relative_to(ROOT)) for p in (ROOT/'previous_v9').rglob('manifest.json'))
assert actual==expected,{'unlisted':sorted(actual-expected),'absent':sorted(expected-actual)}
missing=[];mismatch=[]
for name,digest in data['files'].items():
    path=ROOT/name
    if not path.is_file():missing.append(name)
    elif hashlib.sha256(path.read_bytes()).hexdigest()!=digest:mismatch.append(name)
assert not missing and not mismatch,{'missing':missing,'mismatch':mismatch}
previous=json.loads((ROOT/'data/previous_v9_preservation.json').read_text())
assert len(previous['sha256'])==previous['file_count']
assert all(hashlib.sha256((ROOT/'previous_v9'/name).read_bytes()).hexdigest()==digest
           for name,digest in previous['sha256'].items())
print(json.dumps({'all_passed':True,'verified_files':len(data['files']),
                  'previous_v9_files_unchanged':previous['file_count']},indent=2))

射影4空間の Poisson 構造の分類に向けて — 研究継続ノート第10版
================================================================

本版は複素数上の全射影 Poisson スキームを扱う。PGL_5 商は取らない。
日本語論文は LuaLaTeX で組版し、記入欄・フォームは設けない。
大域成分数の既存下界57は維持する。完全分類の完了は主張しない。

主な結果
--------
1. AB点の全完成局所環を決定した。
   C[[orbit20,tau,alpha,beta,gamma,delta,p,q]] /
     (p²,pq,q²,alpha*p,beta*p,gamma*q,delta*q)。
   唯一の被約成分は25次元の標準トーリックT01。
   二つの23次元支持上に平方零構造があり、支持の交叉は21次元。
   交叉だけに支持された追加の随伴素点はない。T27を含む他成分は通らない。

2. U1の非零磁気クラスの無限遠B=xzを調べた。
   唯一の被約成分は24次元T16。全次数の随伴次数環を決定した。
   軌道22変数を除いた冪零根基NはN^4≠0,N^5=0で、N^4は一次元socle。
   磁気変数bについてN≅C[[b]]^4⊕C[[b]]/(b^3)⊕C[[b]]/(b)⊕C[[b]]/(b)。
   閉軌道に横断する有限長部分の長さは5。
   完成環の非斉次な積を随伴次数環の積と同一視してはいない。

3. 零磁気B=0を通る既知の成分を少なくとも六つ確定した。
   T16,T18,T20,T22,T24,T25。T16が24次元、残りは23次元。
   正重み四変数スライスは(F,P H)という被約完全交叉で、二平面とA2曲面に分解する。
   T22,T24,T25への三曲線を明示的なPGL変換で同定した。
   T18,T20の包含は、前版の特殊磁気点の軌道を零磁気へ縮めることから従う。
   この六成分が零磁気点を通る全成分かは未決定。
   全局所次元は24以上25以下。全六変数の完成環は残る。

構成
----
p4_poisson_completeness_v10.pdf  日本語論文
p4_poisson_completeness_v10.tex  LuaLaTeX本文の入口
preamble.tex, sections/         本文・証明・明示的な座標変換
proofs/                        全次数証明と独立確認記録
code/                          再現コードと正確な係数証明書
data/reproduced/               新版を独立作業コピーで再実行した結果
data/previous_v9_preservation.json 前版の内容比較
HANDOFF.txt                    次回研究の到達点と未解決問題
previous_v9/                   第9版の623ファイルの変更しない写し
manifest.json                  配布時点のSHA256

再現
----
Python 3.12、SymPy 1.14.0を使用した。計算にネットワークアクセスは不要。

  python3 code/verify_bundle.py
  python3 code/run_checks.py --output /absolute/path/check-results

後者は一時コピーで23項目を実行し、数学的JSONを配布証明書と比較する。
配布状態のソースや previous_v9 は変更しない。経過時間だけは比較から除く。
全次数への移行には本文の証明も必要であり、計算の成功だけを論証の代わりにしない。

大きい独立Macaulay計算も再実行する場合：
  python3 code/run_checks.py --output /absolute/path/check-results --slow-independent

論文の組版：
  latexmk -lualatex p4_poisson_completeness_v10.tex

LuaTeXja、HaranoAji、amsmath、amsthm、mathtools、hyperrefなどが必要。
全ての次元は複素次元である。

前版の補完
----------
第9版の付録JSONで欠けていたT38項目を、本版側でT36,T37,T38の全三例を再計算して補完した。
各例の全Jacobi階数101、射影軌道次元24を再確認した。
第9版自体は変更していない。

既知文献と本研究を区別する
------------------------
MPSの定理はSNC log symplectic軌跡に交わる40成分の分類である。
T01〜T40は前版から固定した本研究のカタログ番号。
本版の局所環・冪零構造は、本文の証明と付属係数証明書に基づく研究結果である。
独立検算は研究内で行ったもので、外部査読を受けたという意味ではない。

"""Exact symbolic checks of the two sensitive rank-three normal expressions.

Requires SymPy. These checks support, but do not replace, the proofs in
rank3_quadratic_casimir.md. The input polynomials and coefficients are symbolic.
"""

import sympy as s

z1, z2, z3, t, u = x = s.symbols("z1 z2 z3 t u")
a = s.symbols("a1:4")
b = s.symbols("b1:4")
d = s.symbols("d1:4")
rs = s.symbols("r0:6")
ss = s.symbols("s0:6")


def add(*forms):
    out = {}
    for form in forms:
        for k, v in form.items():
            out[k] = out.get(k, 0) + v
    return {k: s.expand(v) for k, v in out.items() if s.expand(v) != 0}


def mul(c, form):
    return {k: s.expand(c * v) for k, v in form.items() if s.expand(c * v) != 0}


def wedge(left, right):
    out = {}
    for p, v in left.items():
        for q, w in right.items():
            if set(p) & set(q):
                continue
            inv = sum(i > j for i in p for j in q)
            k = tuple(sorted(p + q))
            out[k] = out.get(k, 0) + (-1) ** inv * v * w
    return {k: s.expand(v) for k, v in out.items() if s.expand(v) != 0}


def diff(f):
    return {(i,): s.diff(f, var) for i, var in enumerate(x) if s.diff(f, var) != 0}


def ext(form):
    return add(*(wedge(diff(v), {k: 1}) for k, v in form.items()))


def equal(name, left, right):
    delta = add(left, mul(-1, right))
    if delta:
        raise AssertionError((name, delta))
    print(name + ": verified identically")


zz = (z1, z2, z3)
mon = [zz[i] * zz[j] for i in range(3) for j in range(i, 3)]
R = sum(c * m for c, m in zip(rs, mon))
S = sum(c * m for c, m in zip(ss, mon))
A = sum(c * z for c, z in zip(a, zz))
B1 = sum(c * z for c, z in zip(b, zz))
D = sum(c * z for c, z in zip(d, zz))
af, bf, df = diff(A), diff(B1), diff(D)
alpha = add(diff(R), mul(A, bf))
lam = add(diff(S), mul(A, df))
dt, du = diff(t), diff(u)
gamma0 = add(wedge(af, lam), wedge(alpha, bf))
original = add(
    gamma0,
    mul(t, wedge(af, bf)),
    mul(u, wedge(af, df)),
    wedge(dt, add(alpha, mul(t, af), mul(u, bf))),
    wedge(du, add(lam, mul(t, bf), mul(u, df))),
    mul(t, wedge(dt, du)),
)
v, w = u + A, t - B1
normal = add(
    wedge(diff(v), diff(S + v * D)),
    wedge(diff(w), diff(R + v * B1)),
    mul(w, wedge(diff(w), diff(v))),
)
equal("h=t substitution (N)", original, normal)

# h=z1, independent-row case 5a.
h = z1
e = diff(h)
beta0 = diff(B1)
alpha = add(diff(R), mul(A, beta0))
lam = mul(h, beta0)
original = add(
    wedge(alpha, beta0),
    mul(t, wedge(af, beta0)),
    mul(u, wedge(e, beta0)),
    wedge(dt, add(alpha, mul(t, af), mul(u, e))),
    wedge(du, lam),
    mul(h, wedge(dt, du)),
)
factored = wedge(add(dt, mul(-1, beta0)), add(alpha, mul(t, af), mul(u, e), mul(h, du)))
equal("h=z1 independent-row factorization", original, factored)

# h=z1, determinant-zero scalar case 5b.
original = add(
    wedge(beta0, diff(S)),
    mul(t, wedge(e, beta0)),
    wedge(dt, mul(h, beta0)),
    wedge(du, add(diff(S), mul(-t, e))),
    mul(h, wedge(dt, du)),
)
factored = wedge(add(du, beta0), diff(S - h * t))
equal("h=z1 scalar determinant-zero factorization", original, factored)

# Verify the elementary one-form lemma as an exact linear system.
ell = s.symbols("ell0:9")
lf = {(i,): sum(ell[3 * i + j] * zz[j] for j in range(3)) for i in range(3)}
for name, Q in [("nonisotropic", z1**2 + z2**2 + z3**2), ("isotropic", z1*z2 + z3**2)]:
    condition = wedge(diff(Q), add(mul(h, ext(lf)), mul(-1, wedge(e, lf))))
    equations = [c for p in condition.values() for c in s.Poly(p, *zz).coeffs()]
    matrix, _ = s.linear_eq_to_matrix(equations, ell)
    assert matrix.rank() == 5
    generators = [diff(Q)] + [mul(h, {(i,): 1}) for i in range(3)]
    for gen in generators:
        equal("one-form lemma " + name, wedge(diff(Q), add(mul(h, ext(gen)), mul(-1, wedge(e, gen)))), {})
    print("one-form lemma " + name + ": solution space has dimension 4, exactly the stated span")


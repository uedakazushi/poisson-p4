#!/usr/bin/env python3
"""Exact projective Jacobi equations for W+q*C, with10 constant parameters."""
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent
import sys
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parent/"data"
OUT.mkdir(parents=True,exist_ok=True)
N=5
PAIRS=list(combinations(range(N),2))
TRIPLES=list(combinations(range(N),3))
QUADS=list(combinations(range(N),4))
def mon(*indices):
    e=[0]*N
    for i in indices:e[i]+=1
    return tuple(e)
def clean(p):return {m:c for m,c in p.items() if c}
def add(a,b,k=1):
    out=defaultdict(F,a)
    for m,c in b.items():out[m]+=k*c
    return clean(out)
def mul(a,b):
    out=defaultdict(F)
    for m,c in a.items():
        for n,d in b.items():out[tuple(sorted(m+n))]+=c*d
    return clean(out)
def scale(a,k):return {m:c*k for m,c in a.items() if c*k}
def xadd(a,b,k=1):
    out={m:c.copy() for m,c in a.items()}
    for m,c in b.items():out[m]=add(out.get(m,{}),c,k)
    return {m:c for m,c in out.items() if c}
def xmul(a,b):
    out={}
    for m,c in a.items():
        for n,d in b.items():
            e=tuple(i+j for i,j in zip(m,n))
            out[e]=add(out.get(e,{}),mul(c,d))
    return {m:c for m,c in out.items() if c}
def dx(a,i):
    out={}
    for m,c in a.items():
        if m[i]:
            e=list(m);e[i]-=1
            out[tuple(e)]=scale(c,m[i])
    return out
def ent(B,i,j):
    if i==j:return {}
    if i<j:return B.get((i,j),{})
    return {m:scale(c,-1) for m,c in B.get((j,i),{}).items()}
def sign(seq):
    if len(set(seq))!=len(seq):return 0
    return (-1)**sum(seq[i]>seq[j] for i in range(len(seq)) for j in range(i+1,len(seq)))
def jacobi(B):
    out={}
    for T in TRIPLES:
        q={}
        for i,j,k in (T,T[1:]+T[:1],T[2:]+T[:2]):
            for h in range(N):q=xadd(q,xmul(ent(B,i,h),dx(ent(B,j,k),h)))
        out[T]=q
    return out
def projective_jacobi(B):
    out={I:{} for I in QUADS}
    for T,q in jacobi(B).items():
        for h in range(N):
            sg=sign((h,)+T)
            if not sg:continue
            dest=out[tuple(sorted((h,)+T))]
            for m,c in q.items():
                e=list(m);e[h]+=1;e=tuple(e)
                dest[e]=add(dest.get(e,{}),c,sg)
    return {I:{m:c for m,c in q.items() if c} for I,q in out.items()}
def rref(matrix,certificate=False):
    A=[[F(v) for v in row] for row in matrix]
    if not A:return ([],[],[]) if certificate else ([],[])
    tr=[{i:F(1)} for i in range(len(A))] if certificate else None
    piv=[];k=0
    for j in range(len(A[0])):
        row=next((i for i in range(k,len(A)) if A[i][j]),None)
        if row is None:continue
        A[k],A[row]=A[row],A[k]
        if certificate:tr[k],tr[row]=tr[row],tr[k]
        d=A[k][j];A[k]=[v/d for v in A[k]]
        if certificate:tr[k]=scale(tr[k],1/d)
        for i in range(len(A)):
            if i!=k and A[i][j]:
                d=A[i][j];A[i]=[v-d*w for v,w in zip(A[i],A[k])]
                if certificate:tr[i]=add(tr[i],tr[k],-d)
        piv.append(j);k+=1
        if k==len(A):break
    return (A[:k],piv,tr[:k]) if certificate else (A[:k],piv)
def row_basis(polys,certificate=False):
    mons=sorted({m for q in polys for m in q},key=lambda m:(-len(m),m))
    result=rref([[q.get(m,0) for m in mons] for q in polys],certificate)
    rr,piv=result[:2]
    rb=[{m:c for m,c in zip(mons,row) if c} for row in rr]
    return (rb,mons,result[2]) if certificate else (rb,mons)
def subst(q,ex):
    out={}
    for m,c in q.items():
        z={():c}
        for i in m:z=mul(z,ex[i])
        out=add(out,z)
    return out
def encode(q):return [[list(m),c.numerator,c.denominator] for m,c in sorted(q.items())]
def pstr(q,names):
    return ' + '.join(str(c)+'*'+('*'.join(names[i] for i in m) or '1') for m,c in sorted(q.items(),key=lambda z:(len(z[0]),z[0]))) or '0'
Q={mon(0,4):{():F(1)},mon(2,2):{():F(1)},mon(1,3):{():F(1)}}
H=[{mon(i):{():F(i)}} if i else {} for i in range(N)]
Nv=[{}, {mon(0):{():F(-1)}},{mon(1):{():F(-1)}},{mon(2):{():F(2)}},{mon(3):{():F(1)}}]
W={I:xadd(xmul(H[I[0]],Nv[I[1]]),xmul(H[I[1]],Nv[I[0]]),-1) for I in PAIRS}
B={I:xadd(W[I],{m:{(k,):F(1)} for m in Q}) for k,I in enumerate(PAIRS)}

def polynomial_combination(polys,coeffs):
    result={}
    for i,c in coeffs.items():result=add(result,mul(c,polys[i]))
    return result
def encoded_combination(coeffs):
    return [[i,encode(q)] for i,q in sorted(coeffs.items()) if q]
def xsubst(poly,ex):return {m:z for m,c in poly.items() if (z:=subst(c,ex))}
def pf4(T,I=(1,2,3,4)):
    i,j,k,l=I
    return xadd(xadd(xmul(ent(T,i,j),ent(T,k,l)),xmul(ent(T,i,k),ent(T,j,l)),-1),xmul(ent(T,i,l),ent(T,j,k)))

def main():
    assert not any(jacobi(W).values())
    J=projective_jacobi(B)
    records=sorted((I,m,q) for I,z in J.items() for m,q in z.items() if q)
    original=[q for I,m,q in records]
    rows,mons,combs=row_basis(original,certificate=True)
    for q,c in zip(rows,combs):
        assert q==polynomial_combination(original,{i:{():v} for i,v in c.items()})
    leads=[next(m for m in mons if m in q) for q in rows]
    originals_in_rows=[]
    for q in original:
        coeff={i:{():q[m]} for i,m in enumerate(leads) if q.get(m)}
        assert q==polynomial_combination(rows,coeff)
        originals_in_rows.append(coeff)
    names=['c'+str(i)+str(j) for i,j in PAIRS]
    print('Jacobi nonzero coefficients',len(original),'linear-span rank',len(rows))
    print('Initial row basis:')
    for q in rows:print(pstr(q,names))
    linear=[q for q in rows if max(map(len,q),default=0)<=1]
    print('Pure linear equations:',len(linear))
    lm=[[q.get((i,),0) for i in range(10)]+[-q.get((),0)] for q in linear]
    lr,lp=rref(lm)
    assert 10 not in lp
    free=[i for i in range(10) if i not in lp]
    ex={i:{(j,):F(1)} for j,i in enumerate(free)}
    for row,i in zip(lr,lp):
        v={():row[-1]} if row[-1] else {}
        for j,h in enumerate(free):
            if row[h]:v[(j,)]=-row[h]
        ex[i]=v
    reduced,rm=row_basis([subst(q,ex) for q in original])
    print('Free parameters:',[names[i] for i in free])
    for q in reduced:print(pstr(q,[names[i] for i in free]))
    assert len(rows)==14 and lp==[0,1,2,3,4,5,6,8,9] and free==[7]
    assert reduced==[{(0,0):F(1),(0,):F(-1)}]
    final=[{(i,):F(1)} for i in (0,1,2,3,4,5)]
    final += [{(6,):F(1),(7,):F(-1)},{(8,):F(1)},{(9,):F(1)}]
    final += [{(7,7):F(1),(7,):F(-1)}]
    assert linear==final[:9]
    # Express every row-basis generator in the final ten-generator ideal.
    rows_in_final=[]
    for q in rows:
        rem=dict(q);quot={}
        for j,i in enumerate(lp):
            while True:
                term=next((m for m in rem if i in m),None)
                if term is None:break
                coeff=rem[term];m=list(term);m.remove(i);m=tuple(m)
                t={m:coeff};quot[j]=add(quot.get(j,{}),t)
                rem=add(rem,mul(t,final[j]),-1)
        while any(len(m)>=2 for m in rem):
            term=max(rem,key=len)
            assert all(i==7 for i in term)
            t={term[2:]:rem[term]};quot[9]=add(quot.get(9,{}),t)
            rem=add(rem,mul(t,final[9]),-1)
        assert not rem
        assert q==polynomial_combination(final,quot)
        rows_in_final.append(quot)
    # Converse: nine final linears occur as row-basis elements. For t²-t,
    # use Pf(C)-t -c34*c12+c24*c13-t*(c14-t).
    final_in_rows=[]
    for q in final[:9]:final_in_rows.append({rows.index(q):{():F(1)}})
    pfminus={ (4,9):F(1),(5,8):F(-1),(6,7):F(1),(7,):F(-1)}
    fcomb={rows.index(pfminus):{():F(1)},
           rows.index({(4,):F(1)}):{(9,):F(-1)},
           rows.index({(5,):F(1)}):{(8,):F(1)},
           rows.index({(6,):F(1),(7,):F(-1)}):{(7,):F(-1)}}
    final_in_rows.append(fcomb)
    for q,c in zip(final,final_in_rows):assert q==polynomial_combination(rows,c)
    # Both solutions satisfy full affine Jacobi, and their ranks differ.
    solutions=[[0]*10,[0,0,0,0,0,0,1,1,0,0]]
    for point in solutions:
        ex0={i:{():F(v)} if v else {} for i,v in enumerate(point)}
        BB={I:xsubst(q,ex0) for I,q in B.items()}
        assert not any(jacobi(BB).values())
        assert all(not xsubst(z,ex0) for z in J.values())
        if point==solutions[0]:assert all(not pf4(BB,I) for I in QUADS)
        else:assert pf4(BB)=={m:scale(c,5) for m,c in xmul(Q,Q).items()}
    report={'parameter_names':names,'pair_order':PAIRS,'original_nonzero_equations':len(original),
        'equation_linear_span_rank':len(rows),'row_basis':[encode(q) for q in rows],
        'pure_linear_equation_rank':len(lp),'free_original_indices':free,
        'all_parameters_reconstruction':{names[i]:encode(ex[i]) for i in range(10)},
        'reduced_equations':[encode(q) for q in reduced],
        'original_equation_row_labels':[[list(I),list(m)] for I,m,q in records],
        'original_equations':[encode(q) for q in original],
        'row_basis_as_combinations_of_original_equations':[[[i,v.numerator,v.denominator] for i,v in sorted(c.items())] for c in combs],
        'original_equations_as_combinations_of_row_basis':[encoded_combination(c) for c in originals_in_rows],
        'final_ideal_generators':[encode(q) for q in final],
        'row_basis_as_polynomial_combinations_of_final_generators':[encoded_combination(c) for c in rows_in_final],
        'final_generators_as_polynomial_combinations_of_row_basis':[encoded_combination(c) for c in final_in_rows]}
    (OUT/'extension_equations.json').write_text(json.dumps(report,indent=2)+'\n')
    summary={'base_field':'Q for identities; C for the extension scheme',
        'coordinate_order':['x0','x1','x2','x3','x4'],
        'quadric':'q=x0*x4+x2^2+x1*x3',
        'base_extension':'W=H wedge N',
        'H':'sum_i i*x_i*partial_i',
        'N':'-x0*partial_1-x1*partial_2+2*x2*partial_3+x3*partial_4',
        'ambient_extension_parameter_count':10,
        'projective_Jacobi_nonzero_coefficient_count':len(original),
        'constant_row_span_rank_exact':len(rows),
        'independent_linear_equations':9,
        'linear_equations':['c01=0','c02=0','c03=0','c04=0','c12=0','c13=0','c14-c23=0','c24=0','c34=0'],
        'remaining_parameter':'t=c23=c14','remaining_equation':'t*(t-1)=0',
        'exact_ideal_equality':True,
        'all_row_and_ideal_combination_identities_verified_over_Q':True,
        'normalized_extension_scheme':'Spec(C[t]/(t*(t-1))) = two reduced points',
        'solutions_in_pair_order':solutions,'generic_projective_ranks':[2,4],
        'rank4_solution_affine_Pfaffian':'5*q^2',
        'rank4_solution_projective_degeneracy_polynomial':'5*x0*q^2',
        'full_affine_Jacobi_verified_at_both_solutions':True,
        'scope':'All ambient Poisson extensions with fixed nonzero restriction W|Q, after normalizing its scalar.'}
    (OUT/'extension_certificate.json').write_text(json.dumps(summary,indent=2)+'\n')
    print('Exact ideal equality and both solution identities verified.')
if __name__=='__main__':main()


#!/usr/bin/env python3
"""Exact polynomial certificates for the rank-4 divisorial-zero reduction.

Run from a directory containing poisson_p4_components_check.py, or with that
module's directory in PYTHONPATH. Coefficients are integers; parameters are
formal extra polynomial variables, never numerical samples. No CAS is used.
"""
from collections import defaultdict
import json
import poisson_p4_components_check as p


def polynomial(n,terms):
    ans=defaultdict(int)
    for coefficient,factors in terms:
        mon=[0]*n
        for i in factors:mon[i]+=1
        ans[tuple(mon)]+=coefficient
    return {k:v for k,v in ans.items() if v}


def add(*polys):
    out=defaultdict(int)
    for poly in polys:p.add_polynomial(out,poly)
    return {k:v for k,v in out.items() if v}


def bivector_add(P,Q):
    return {pair:add(P.get(pair,{}),Q.get(pair,{})) for pair in p.PAIRS}


def jacobi_zero(P):
    J=p.affine_jacobi_coefficients(P)
    assert all(not v for v in J.values()),J
    return True


def pfaff4(P):
    return add(p.polynomial_product(P.get((1,2),{}),P.get((3,4),{})),
               {m:-c for m,c in p.polynomial_product(P.get((1,3),{}),P.get((2,4),{})).items()},
               p.polynomial_product(P.get((1,4),{}),P.get((2,3),{})))


def toric(n,lambda_terms):
    return {pair:polynomial(n,[(c,(pair[0],pair[1])+par) for c,par in terms])
            for pair,terms in lambda_terms.items()}


def compatible_certificate(name,P,Q,expected_pfaff):
    assert pfaff4(Q)==expected_pfaff,(name,pfaff4(Q),expected_pfaff)
    return {'name':name,'jacobi_P':jacobi_zero(P),'jacobi_Q':jacobi_zero(Q),
            'jacobi_P_plus_Q':jacobi_zero(bivector_add(P,Q)),
            'toric_pfaffian_nonzero':True}


def run():
    report=[]
    # Almost-abelian generic diagonal model: a,b are independent parameters.
    n=7;a=5;b=6
    P={(1,2):polynomial(n,[(1,(0,0))]),
       (1,4):polynomial(n,[(-1,(0,1,b))]),
       (2,4):polynomial(n,[(1,(0,2,b))]),
       (3,4):polynomial(n,[(1,(0,0)),(-1,(0,3,a))])}
    Q=toric(n,{(1,2):[(1,())],(1,3):[(-1,(b,))],(1,4):[(1,(b,))],
               (2,3):[(1,(b,))],(2,4):[(-1,(b,))],(3,4):[(1,(a,))]})
    report.append(compatible_certificate('almost_abelian_generic',P,Q,
                   polynomial(n,[(1,(1,2,3,4,a))])))
    # Entire irreducible normalized almost-abelian symplectic family.
    n=11;u,v,w,l1,l2,a=range(5,11)
    P={(1,2):polynomial(n,[(1,(0,0))]),
       (1,4):polynomial(n,[(-1,(0,1,u)),(-1,(0,2,w)),(-1,(0,3,l1))]),
       (2,4):polynomial(n,[(-1,(0,1,v)),(1,(0,2,u)),(-1,(0,3,l2))]),
       (3,4):polynomial(n,[(1,(0,0)),(-1,(0,3,a))])}
    report.append({'name':'almost_abelian_full_6_parameter_family','jacobi_P':jacobi_zero(P)})
    # Generic Heisenberg extension, after translation removes exact cocycle.
    n=6;lam=5
    P={(1,2):polynomial(n,[(1,(0,3))]),
       (1,4):polynomial(n,[(-1,(0,1,lam))]),
       (2,4):polynomial(n,[(-1,(0,2)),(1,(0,2,lam))]),
       (3,4):polynomial(n,[(-1,(0,3))])}
    Q=toric(n,{(1,2):[(1,())],(1,4):[(1,(lam,))],
               (2,4):[(1,()),(-1,(lam,))],(3,4):[(1,())]})
    report.append(compatible_certificate('heisenberg_exact_generic',P,Q,
                   polynomial(n,[(1,(1,2,3,4))])))
    # Entire main cocycle branch for trace-one Heisenberg derivation.
    n=11;u,v,w,a,d,e=range(5,11)
    P={(1,2):polynomial(n,[(1,(0,3)),(1,(0,0,a))]),
       (1,4):polynomial(n,[(-1,(0,1,u)),(-1,(0,2,w)),(1,(0,0,d))]),
       (2,4):polynomial(n,[(-1,(0,1,v)),(-1,(0,2)),(1,(0,2,u)),(1,(0,0,e))]),
       (3,4):polynomial(n,[(-1,(0,3)),(-1,(0,0,a))])}
    report.append({'name':'heisenberg_full_main_branch','jacobi_P':jacobi_zero(P)})
    # Exceptional nonexact cocycle, eigenvalues 2,-1 on h3/Z(h3).
    n=5
    P={(1,2):polynomial(n,[(1,(0,3))]),
       (1,4):polynomial(n,[(1,(0,0)),(-2,(0,1))]),
       (2,3):polynomial(n,[(1,(0,0))]),
       (2,4):polynomial(n,[(1,(0,2))]),
       (3,4):polynomial(n,[(-1,(0,3))])}
    Q=toric(n,{(1,2):[(-1,())],(1,3):[(1,())],(1,4):[(2,())],
               (2,3):[(-1,())],(2,4):[(-1,())],(3,4):[(1,())]})
    report.append(compatible_certificate('heisenberg_exceptional_nonexact',P,Q,
                   polynomial(n,[(-2,(1,2,3,4))])))
    # aff(C) x aff(C), all cohomology classes c and deformation parameter t.
    n=7;c=5;t=6
    U=polynomial(n,[(1,(0,)),(1,(t,1))])
    V=polynomial(n,[(1,(0,)),(1,(t,3))])
    P={(1,2):p.polynomial_product(polynomial(n,[(1,(2,))]),U),
       (3,4):p.polynomial_product(polynomial(n,[(1,(4,))]),V),
       (1,3):p.polynomial_product(polynomial(n,[(1,(c,))]),p.polynomial_product(U,V))}
    expected=p.polynomial_product(polynomial(n,[(1,(2,4))]),p.polynomial_product(U,V))
    assert pfaff4(P)==expected
    report.append({'name':'aff_times_aff_toric_deformation','jacobi_all_c_t':jacobi_zero(P),
                   'pfaffian':'x2*x4*(x0+t*x1)*(x0+t*x3)',
                   'SNC_for_t_nonzero':True})
    return {'coefficient_ring':'Z[x0,x1,x2,x3,x4,formal_parameters]',
            'method':'Exact sparse polynomial identities, no numeric specialization',
            'certificates':report}

if __name__=='__main__':print(json.dumps(run(),indent=2))

#!/usr/bin/env python3
"""Additional exact boundary certificates, including the rank<=2 subscheme."""
from collections import defaultdict
import itertools
import json
from pathlib import Path
import sys

import numpy as np

HERE=Path(__file__).resolve().parent
import poisson_p4_components_check as p
import verify_rank2_components as v


def rank_two_linearization(bv):
    monomials=p.homogeneous_monomials(5)
    positions={m:i for i,m in enumerate(monomials)}
    matrix=np.zeros((len(monomials),len(p.BIVECTOR_BASIS)),dtype=np.int64)
    for c,(pair,alpha) in enumerate(p.BIVECTOR_BASIS):
        for other,coeff in bv.items():
            for e in range(5):
                sg=p.permutation_sign((e,)+other+pair)
                if sg:
                    for beta,value in coeff.items():
                        gamma=tuple(a+b+int(k==e) for k,(a,b) in enumerate(zip(alpha,beta)))
                        matrix[positions[gamma],c]+=sg*value
    return matrix


def toric(a,b):
    return {(i,j):{tuple(int(k==i)+int(k==j) for k in range(5)):a[i]*b[j]-a[j]*b[i]}
            for i,j in p.PAIRS}


def orbit(bv):
    cols=[]
    for i,j in itertools.product(range(5),repeat=2):
        m=np.zeros((5,5),dtype=np.int64);m[i,j]=1
        cols.append(p.bivector_vector(v.linear_action_derivative(bv,m)))
    return cols


def certify(name,bv,A2=None,Afull=None):
    V=p.vertical_bivector_matrix()
    J=p.linearized_jacobi_matrix(bv)
    K=rank_two_linearization(bv)
    assert not np.any(J@V) and not np.any(K@V)
    out={'name':name,'Jacobi':p.modular_rank_certificate(J),
         'Jacobi_and_rank2':p.modular_rank_certificate(np.vstack([J,K]))}
    if A2 is not None:
        A=np.column_stack(A2)
        assert not np.any(J@A) and not np.any(K@A)
        out['rank2_family']=p.modular_rank_certificate(np.column_stack([V,A]))
        out['rank2_affine_tangent_upper']=126-out['Jacobi_and_rank2']['rank_mod_prime']
        out['rank2_affine_family_lower']=out['rank2_family']['rank_mod_prime']-24
        assert out['rank2_affine_tangent_upper']==out['rank2_affine_family_lower']
    if Afull is not None:
        A=np.column_stack(Afull)
        assert not np.any(J@A)
        out['full_family']=p.modular_rank_certificate(np.column_stack([V,A]))
        out['full_affine_tangent_upper']=126-out['Jacobi']['rank_mod_prime']
        out['full_affine_family_lower']=out['full_family']['rank_mod_prime']-24
        assert out['full_affine_tangent_upper']==out['full_affine_family_lower']
    return out


def main():
    star={(3,4):{(2,0,0,0,0):1}}
    a=[1,2,3,5,-11];b=[2,7,11,17,-37]
    bv=toric(a,b)
    A2=orbit(bv)
    for i in range(4):
        u=[int(k==i)-int(k==4) for k in range(5)]
        A2.append(p.bivector_vector(toric(u,b)))
        A2.append(p.bivector_vector(toric(a,u)))
    Afull=orbit(bv)
    for i,j in p.PAIRS:
        Afull.append(p.bivector_vector({(i,j):{tuple(int(k==i)+int(k==j) for k in range(5)):1}}))
    aff=v.build_affine_case((3,2))
    report={'prime':p.PRIME,'points':[
        certify('universal_highest_weight',star),
        certify('generic_toric_rank2',bv,A2,Afull),
        certify('Aff32_beta7',aff['bivector'],list(aff['parameter_derivative'].T))]}
    output_dir=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parent/'data'
    output_dir.mkdir(parents=True,exist_ok=True)
    out=output_dir/'boundary_points_certificate.json'
    out.write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()

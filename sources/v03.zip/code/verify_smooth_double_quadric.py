#!/usr/bin/env python3
"""Exact certificates: smooth-double-quadric stratum and rigid rank-four component.

All identity checks use integer polynomial coefficients. Ranks are computed
both over Q by fraction-free row reduction and by nonzero prime-field minors;
no finite-field point sampling is used.
"""
from pathlib import Path
import sys, json, itertools
from collections import defaultdict
import numpy as np
HERE=Path(__file__).resolve().parent
import sys
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parent/"data"
OUT.mkdir(parents=True,exist_ok=True)
import poisson_p4_components_check as p
import closed_quadric_forms as c

# Coordinate order: x0,a,b,c,d. No derivative in x0 occurs in P.
def m(*ii):
 e=[0]*5
 for i in ii:e[i]+=1
 return tuple(e)
P={
 (1,2):{m(1,1):-1,m(0,2):2},
 (1,3):{m(1,2):2,m(0,3):3},
 (1,4):{m(0,4):5,m(2,2):1,m(1,3):2},
 (2,3):{m(0,4):1,m(2,2):5,m(1,3):4},
 (2,4):{m(2,3):2,m(1,4):4},
 (3,4):{m(3,3):3,m(2,4):-8},
}
Q={m(0,4):1,m(2,2):1,m(1,3):1}

def plus5(*args):
 r=defaultdict(int)
 for v in args:p.add_polynomial(r,v)
 return {e:v for e,v in r.items() if v}
def scale5(pol,a):return {e:a*v for e,v in pol.items() if a*v}
def pf4(B,indices=(1,2,3,4)):
 a,b,d,e=indices
 return plus5(p.polynomial_product(p.bivector_entry(B,a,b),p.bivector_entry(B,d,e)),scale5(p.polynomial_product(p.bivector_entry(B,a,d),p.bivector_entry(B,b,e)),-1),p.polynomial_product(p.bivector_entry(B,a,e),p.bivector_entry(B,b,d)))
def div5(B):
 return {j:plus5(*[p.polynomial_derivative(p.bivector_entry(B,i,j),i) for i in range(5)]) for j in range(5)}
def action(a,b):
 R={}
 xx=[0]*5;xx[b]=1
 for i,j in p.PAIRS:
  pol=defaultdict(int)
  p.add_polynomial(pol,p.polynomial_product({tuple(xx):1},p.polynomial_derivative(P.get((i,j),{}),a)))
  if i==a:p.add_polynomial(pol,p.bivector_entry(P,b,j),-1)
  if j==a:p.add_polynomial(pol,p.bivector_entry(P,i,b),-1)
  R[i,j]=dict(pol)
 return p.bivector_vector(R)
def exact_rank(M):
 return c.sparse_rank([{j:int(v) for j,v in enumerate(row) if v} for row in M])[0]
def rank_cert(M):
 cert=p.modular_rank_certificate(M)
 cert['rank_over_Q']=exact_rank(M)
 assert cert['rank_over_Q']==cert['rank_mod_prime']
 return cert

assert not any(p.affine_jacobi_coefficients(P).values())
assert pf4(P)==scale5(p.polynomial_product(Q,Q),5)
# Independent construction from the closed rational symplectic form.
q=c.plus(c.x(3),c.mul(c.x(1),c.x(1)),c.mul(c.x(0),c.x(2)))
beta={0:c.scale(c.x(3),-4),1:c.scale(c.x(2),-3),2:c.scale(c.x(1),2),3:c.x(0)}
alpha=c.primitive_numerator(beta,q)
constructed={}
for ij in c.PAIRS:
 kl=tuple(i for i in range(4) if i not in ij)
 pol=c.scale(alpha[kl],c.sign(ij+kl))
 constructed[tuple(i+1 for i in ij)]={(2-sum(e),)+e:v for e,v in pol.items()}
assert constructed==P
assert not c.closed_numerator(alpha,q)

# Canonical unimodular lift and factor Hamiltonian fields.
def linear(i,k=1):e=[0]*5;e[i]=1;return {tuple(e):k}
N={0:{},1:linear(0,-1),2:linear(1,-1),3:linear(2,2),4:linear(3,1)}
H={i:linear(i,i) for i in range(5)}
h={i:linear(i,i-2) for i in range(5)}
R={0:linear(1,-4),1:linear(2,-6),2:linear(3,3),3:linear(4,4),4:{}}
def vf_bracket(X,Y):
 return {j:plus5(*[p.polynomial_product(X[i],p.polynomial_derivative(Y[j],i)) for i in range(5)],* [scale5(p.polynomial_product(Y[i],p.polynomial_derivative(X[j],i)),-1) for i in range(5)]) for j in range(5)}
def vf_scale(X,a):return {i:scale5(X[i],a) for i in range(5)}
assert vf_bracket(h,R)==R
assert vf_bracket(h,N)==vf_scale(N,-1)
assert vf_bracket(R,N)==vf_scale(h,2)
for X in (h,N,R):
 assert not plus5(*[p.polynomial_product(X[i],p.polynomial_derivative(Q,i)) for i in range(5)])
for i,j in p.PAIRS:
 hn=plus5(p.polynomial_product(H[i],N[j]),scale5(p.polynomial_product(H[j],N[i]),-1))
 assert plus5(hn,Q if (i,j) in ((1,4),(2,3)) else {})==P.get((i,j),{})
assert div5(P)=={i:scale5(N[i],10) for i in range(5)}
Pi={}
for i,j in p.PAIRS:
 ew=plus5(p.polynomial_product(linear(i),N[j]),scale5(p.polynomial_product(linear(j),N[i]),-1))
 Pi[i,j]=plus5(P.get((i,j),{}),scale5(ew,-2))
assert not any(div5(Pi).values())
assert not any(p.affine_jacobi_coefficients(Pi).values())
for j in range(5):
 hq=plus5(*[p.polynomial_product(p.polynomial_derivative(Q,i),p.bivector_entry(Pi,i,j)) for i in range(5)])
 assert hq==p.polynomial_product(Q,N[j])
 assert p.bivector_entry(Pi,0,j)==scale5(p.polynomial_product(linear(0),N[j]),-2)
Fover5=p.polynomial_product(linear(0),p.polynomial_product(Q,Q))
for j in range(5):
 inds=tuple(i for i in range(5) if i!=j)
 assert scale5(pf4(Pi,inds),(-1)**j)==p.polynomial_derivative(Fover5,j)

J=p.linearized_jacobi_matrix(P)
V=p.vertical_bivector_matrix()
orbit_columns=[action(a,b) for a in range(5) for b in range(5)]
assert not np.any(-orbit_columns[5]-orbit_columns[11]+2*orbit_columns[17]+orbit_columns[23])
assert np.array_equal(sum(i*orbit_columns[5*i+i] for i in range(5)),-p.bivector_vector(P))
M=np.column_stack([V,*orbit_columns,p.bivector_vector(P)])
assert not np.any(J@M)
JC,VC,MC=rank_cert(J),rank_cert(V),rank_cert(M)
assert JC['rank_over_Q']==103 and VC['rank_over_Q']==24 and MC['rank_over_Q']==47

# The two normal forms of a smooth projective quadric relative to H.
closed={}
for name,quad in (
 ('transverse',c.plus(c.ONE,*[c.mul(c.x(i),c.x(i)) for i in range(4)])),
 ('tangent',c.plus(c.x(3),*[c.mul(c.x(i),c.x(i)) for i in range(3)])),
):
 rows=defaultdict(dict)
 for column,(ij,e) in enumerate(c.BASIS):
  for key,v in c.closed_numerator({ij:{e:1}},quad).items():rows[key][column]=v
 rowkeys=sorted(rows)
 D=np.array([[rows[key].get(j,0) for j in range(90)] for key in rowkeys],dtype=np.int64)
 idx={b:i for i,b in enumerate(c.BASIS)}
 primitives=[]
 for i in range(4):
  for e in [(0,)*4]+c.monomials(1):
   aa=c.primitive_numerator({i:{e:1}},quad)
   primitives.append({idx[ij,ee]:v for ij,pol in aa.items() for ee,v in pol.items()})
 B=np.array([[col.get(i,0) for col in primitives] for i in range(90)],dtype=np.int64)
 assert not np.any(D@B)
 DC,BC=rank_cert(D),rank_cert(B)
 assert DC['rank_over_Q']==71 and BC['rank_over_Q']==19
 closed[name]={'closure_matrix_shape':list(D.shape),'primitive_matrix_shape':list(B.shape),'closure_rank':DC,'primitive_rank':BC,'D_times_B_is_zero_over_Z':True,'kernel_equals_affine_primitive_image':True,'closure_row_keys':[[list(ijk),list(e)] for ijk,e in rowkeys]}

report={
 'base_field':'C; integer identities and exact Q ranks',
 'coordinates':['x0','a','b','c','d'],
 'normal_form':{str(ij):[[list(e),v] for e,v in sorted(pol.items())] for ij,pol in P.items()},
 'projective_degeneracy_polynomial':'5*x0*(x0*d+b^2+a*c)^2',
 'exact_identities':{'affine_Jacobi_zero':True,'Pfaffian_equals_5Q_squared':True,'closed_rational_form_construction':True,'divergence_P_equals_10N':True,'canonical_lift_unimodular_and_Poisson':True,'canonical_factor_Hamiltonians_XL_minus2N_XQ_N':True,'canonical_Pfaffian_gradient_identity':True,'J_times_vertical_orbit_scale_matrix_zero':True,'stabilizer_fields_W_and_N':True,'P_equals_H_wedge_N_plus_q_times_constant_bivector':True,'principal_sl2_triple_preserves_q':True},
 'Jacobi_rank_certificate':JC,'vertical_rank_certificate':VC,'vertical_orbit_scale_rank_certificate':MC,
 'affine_Poisson_tangent_dimension':23,'projective_Poisson_tangent_dimension':22,'PGL_projective_orbit_dimension':22,
 'closed_form_lemma':closed,
 'conclusions':{'orbit_closure_is_full_irreducible_component':True,'smooth_quadric_H_plus_2Q_stratum_is_one_projective_orbit':True,'transverse_H_is_impossible':True},
 'scope':'No novelty claim. No classification claimed for singular Q or other nonreduced degeneracy types.'
}
out=OUT/'double_quadric_classification_certificate.json'
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'certificate':str(out),'J_rank':103,'V_rank':24,'vertical_orbit_scale_rank':47,'projective_tangent_and_orbit_dimension':22,'closed_form_dimensions':{k:19 for k in closed},'all_checks_passed':True},indent=2))

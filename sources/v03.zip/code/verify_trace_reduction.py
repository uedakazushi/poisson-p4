#!/usr/bin/env python3
"""Universal exact identities and regular-semisimple stratum certificate.

No Groebner calculation is used.  The small ideal decompositions are proved
in regular_semisimple_theorem.txt using elementary Chinese remainders.
"""
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
import json
import semisimple_quadratic as a
HERE=Path(__file__).resolve().parent
import sys
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parent/"data"
OUT.mkdir(parents=True,exist_ok=True)

def xscale(q,c):return {m:a.scale(p,c) for m,p in q.items() if c}
def scalar(c):return {(0,0,0,0):{():F(c)}} if c else {}
def trace(Q):return a.xadd(a.entry(Q,0,1),a.entry(Q,2,3))
def pfaffian(Q):
    return a.xadd(a.xadd(a.xmul(a.entry(Q,0,1),a.entry(Q,2,3)),a.xmul(a.entry(Q,0,2),a.entry(Q,1,3)),-1),a.xmul(a.entry(Q,0,3),a.entry(Q,1,2)))
def matvec(Q,alpha):
    out=[]
    for i in range(4):
        q={}
        for j in range(4):q=a.xadd(q,a.xmul(a.entry(Q,i,j),alpha[j]))
        out.append(q)
    return out
def poly_vector_difference(U,V):return [a.xadd(u,v,-1) for u,v in zip(U,V)]

def mon(i,j):
    m=[0]*4;m[i]+=1;m[j]+=1;return tuple(m)
def universal_torus():
    # A,B,C,D,E are parameters0,...,4.
    A,B,C,D,E=[{(i,):F(1)} for i in range(5)]
    Ff=a.add(C,E,-1);G=a.add(a.scale(B,-1),E,-1);H=a.add(a.add(B,C,-1),E)
    return {(0,1):{mon(0,1):A,mon(2,3):B},(2,3):{mon(0,1):C,mon(2,3):D},
            (0,2):{mon(0,2):E},(0,3):{mon(0,3):Ff},
            (1,2):{mon(1,2):G},(1,3):{mon(1,3):H}}

def canonical_row_span(qs):
    _,rb=a.polynomial_row_basis(qs)
    mons=sorted({m for q in rb for m in q})
    r,p,_=a.rref([[q.get(m,F(0)) for m in mons] for q in rb])
    return [{mons[j]:c for j,c in enumerate(row) if c} for row in r if any(row)]

def signed_permutation_push(Q,sigma,signs,scale=-1):
    """Push by e_i -> signs[i]*e_sigma[i], then multiply the bivector."""
    out={}
    for (i,j),q in Q.items():
        u,v=sigma[i],sigma[j]
        sg=scale*signs[i]*signs[j]*(1 if u<v else -1)
        I=tuple(sorted((u,v)))
        for m,c in q.items():
            mm=[0]*4
            for k in range(4):mm[sigma[k]]=m[k]
            ss=sg
            for k in range(4):ss*=signs[k]**m[k]
            dest=out.setdefault(I,{})
            dest[tuple(mm)]=a.add(dest.get(tuple(mm),{}),a.scale(c,ss))
    return {I:{m:c for m,c in q.items() if c} for I,q in out.items()}

def parameter_substitution(Q,expressions):
    out={}
    for I,q in Q.items():
        for m,c in q.items():
            value={}
            for mon,coef in c.items():
                z={():coef}
                for i in mon:z=a.mul(z,expressions[i])
                value=a.add(value,z)
            if value:out.setdefault(I,{})[m]=value
    return out

def main():
    Q=a.invariant_space(0,0,fix_trace=False)['Q']
    # The helper also computes quadratic Jacobi equations; dimension45 is
    # independent of those equations and uses only constant compatibility.
    s=trace(Q);p=pfaffian(Q);ds=[a.dx(s,i) for i in range(4)]
    assert all(not q for q in a.jacobi(a.P0,Q).values())
    divergence=[]
    for j in range(4):
        d={}
        for i in range(4):d=a.xadd(d,a.dx(a.entry(Q,i,j),i))
        divergence.append(d)
    Xs=[xscale(a.dx(s,1),-1),a.dx(s,0),xscale(a.dx(s,3),-1),a.dx(s,2)]
    assert not any(poly_vector_difference(divergence,Xs))
    # N=Q*Pi0^{-1}; this convention gives tr(N)=2s.
    N=[[a.entry(Q,i,1),xscale(a.entry(Q,i,0),-1),a.entry(Q,i,3),xscale(a.entry(Q,i,2),-1)] for i in range(4)]
    for i in range(4):
        for j in range(4):
            value={}
            for k in range(4):value=a.xadd(value,a.xmul(N[i][k],N[k][j]))
            value=a.xadd(value,a.xmul(s,N[i][j]),-1)
            if i==j:value=a.xadd(value,p)
            assert not value,(i,j)
    # C=(s Pi0-Q)ds-Pi0 dp.  With our Jacobi convention C is minus
    # (J023,J123,J012,J013), so vanishing is exactly equivalent.
    sP0={I:a.xmul(s,q) for I,q in a.P0.items()}
    spminusq={I:a.xadd(sP0.get(I,{}),Q.get(I,{}),-1) for I in a.PAIRS}
    C=poly_vector_difference(matvec(spminusq,ds),matvec(a.P0,[a.dx(p,i) for i in range(4)]))
    J=a.jacobi(Q)
    Jordered=[J[I] for I in ((0,2,3),(1,2,3),(0,1,2),(0,1,3))]
    assert all(not a.xadd(c,j) for c,j in zip(C,Jordered))
    # Exhaustive list of extra scalar resonances for weights (1,-1,b,-b).
    ww=((1,0),(-1,0),(0,1),(0,-1));ratios=set();raw_torus=0
    for I in a.PAIRS:
        for m in a.MON2:
            d=tuple(sum(ww[i][k] for i in I)-sum(m[i]*ww[i][k] for i in range(4)) for k in range(2))
            if d==(0,0):raw_torus+=1
            elif d[1]:ratios.add(F(-d[0],d[1]))
    assert ratios=={F(0),F(1),F(-1),F(3),F(-3),F(1,3),F(-1,3)}
    T=universal_torus();tj=a.jacobi(T)
    assert all(not q for q in a.jacobi(a.P0,T).values())
    coeffs=[q for f in tj.values() for q in f.values()]
    # I=(BC,C(A-C),B(D-B)).
    expected=[{(1,2):F(1)},{(0,2):F(1),(2,2):F(-1)},{(1,3):F(1),(1,1):F(-1)}]
    assert canonical_row_span(coeffs)==canonical_row_span(expected)
    tp=pfaffian(T)
    expectp={(2,2,0,0):{(0,2):F(1)},(1,1,1,1):{(0,3):F(1)},(0,0,2,2):{(1,3):F(1)}}
    assert not a.xadd(tp,expectp,-1)
    # Check the five displayed resonance generators have exactly the same
    # constant rational row span as all coordinate Jacobi coefficients.
    res=a.invariant_space(1,3)
    # Parameter order P,R,H,C,D (0,...,4).
    fD={():F(9),(4,):F(-9),(4,4):F(2)}
    fC={(3,4):F(1),(3,):F(-3)}
    fR={(1,2):F(1),(1,4):F(1),(1,):F(-2)}
    fP={(0,2):F(1),(0,3):F(1),(0,):F(-1)}
    fK={(0,1):F(1),(3,3):F(-1),(3,4):F(1,6)}
    assert canonical_row_span(res['equations'])==canonical_row_span([fD,fC,fR,fP,fK])
    # Universal signed-permutation verification of the Weyl identifications.
    T7=universal_torus()
    T7[0,3][mon(1,1)]={(5,):F(1)}
    T7[1,2][mon(0,0)]={(6,):F(1)}
    ex={i:{(i,):F(1)} for i in range(7)}
    ex[4]={(1,):F(-1),(2,):F(1),(4,):F(-1)}
    ex[5]={(6,):F(1)};ex[6]={(5,):F(1)}
    pushed=signed_permutation_push(T7,(1,0,3,2),(-1,1,-1,1),scale=-1)
    assert pushed==parameter_substitution(T7,ex)
    ex2={0:{(3,):F(1)},1:{(2,):F(1)},2:{(1,):F(1)},3:{(0,):F(1)},4:{(4,):F(-1)}}
    assert signed_permutation_push(T,(2,3,0,1),(1,1,1,1),scale=1)==parameter_substitution(T,ex2)
    report={
      'base':'Pi0=d1 wedge d2+d3 wedge d4',
      'quadratic_compatible_dimension':45,
      'universal_divergence_equals_trace_hamiltonian_exact':True,
      'universal_N_squared_minus_sN_plus_pI_exact_zero':True,
      'universal_Lenard_Jacobi_identity_exact':True,
      'Jacobi_coordinate_order_in_Lenard_identity':[[1,3,4],[2,3,4],[1,2,3],[1,2,4]],
      'generic_torus_invariant_raw_dimension':raw_torus,
      'finite_resonance_ratios':[[r.numerator,r.denominator] for r in sorted(ratios)],
      'infinite_resonance_is_a_equals_zero':True,
      'regular_semisimple_exception_ratios':['3','-3','1/3','-1/3'],
      'universal_torus_Jacobi_row_span_equals_three_displayed_quadrics':True,
      'resonance3_Jacobi_row_span_equals_five_displayed_polynomials':True,
      'Weyl_P_R_pairing_universal_signed_permutation_identity':True,
      'Weyl_Darboux_block_swap_universal_identity':True,
      'generic_trace_fiber_reduced_components':3,
      'resonance3_fixed_trace_reduced_components':{'affine_lines':9,'punctured_affine_line':1},
      'regular_semisimple_quadratic_locus_components':{'dimension11':2,'dimension10':4},
      'scope':'Components of the homogeneous-quadratic compatible locus only; no assertion of new P4 components.'
    }
    (OUT/'trace_reduction_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()

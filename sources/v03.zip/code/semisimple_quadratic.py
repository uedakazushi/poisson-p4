#!/usr/bin/env python3
"""Exact resonance spaces for compatible homogeneous quadratics on A4.

Only Python's standard library and the v2 rational linear-algebra helper are
used.  A parameter monomial is a sorted tuple of parameter indices; an empty
tuple denotes 1.  All coefficients are rational.
"""
from collections import defaultdict
from fractions import Fraction as F
from itertools import combinations, combinations_with_replacement
from pathlib import Path
import json, sys

HERE=Path(__file__).resolve().parent
import sys
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parent/"data"
OUT.mkdir(parents=True,exist_ok=True)
from build_universal_slice import rref, polynomial_row_basis

PAIRS=list(combinations(range(4),2))
TRIPLES=list(combinations(range(4),3))
MON2=[]
for ij in combinations_with_replacement(range(4),2):
    a=[0]*4
    for i in ij:a[i]+=1
    MON2.append(tuple(a))

def clean(p):return {m:c for m,c in p.items() if c}
def add(a,b,c=1):
    d=defaultdict(F,a)
    for m,v in b.items():d[m]+=c*v
    return clean(d)
def mul(a,b):
    d=defaultdict(F)
    for m,c in a.items():
        for n,e in b.items():d[tuple(sorted(m+n))]+=c*e
    return clean(d)
def scale(a,c):return {m:c*v for m,v in a.items() if c*v}

# Polynomial in coordinates, with parameter polynomials as coefficients.
def xadd(a,b,c=1):
    d={m:dict(p) for m,p in a.items()}
    for m,p in b.items():d[m]=add(d.get(m,{}),p,c)
    return {m:p for m,p in d.items() if p}
def xmul(a,b):
    d={}
    for m,c in a.items():
        for n,e in b.items():
            k=tuple(x+y for x,y in zip(m,n))
            d[k]=add(d.get(k,{}),mul(c,e))
    return {m:p for m,p in d.items() if p}
def dx(a,i):
    d={}
    for m,c in a.items():
        if m[i]:
            k=list(m);k[i]-=1;d[tuple(k)]=scale(c,m[i])
    return d
def entry(Q,i,j):
    if i==j:return {}
    if i<j:return Q.get((i,j),{})
    return {m:scale(c,-1) for m,c in Q.get((j,i),{}).items()}
def jacobi(Q,R=None):
    """Jacobi(Q) or polarization [Q,R], without the self-bracket factor2."""
    out={}
    for I in TRIPLES:
        val={}
        for i,j,k in (I,I[1:]+I[:1],I[2:]+I[:2]):
            for h in range(4):
                val=xadd(val,xmul(entry(Q,i,h),dx(entry(Q if R is None else R,j,k),h)))
                if R is not None:val=xadd(val,xmul(entry(R,i,h),dx(entry(Q,j,k),h)))
        out[I]=val
    return out
P0={(0,1):{(0,0,0,0):{():F(1)}},(2,3):{(0,0,0,0):{():F(1)}}}

def encode(poly):return [[list(m),c.numerator,c.denominator] for m,c in sorted(poly.items())]
def pstr(p,names=None):
    def mon(m):return '*'.join(names[i] if names else f't{i+1}' for i in m) or '1'
    return ' + '.join(str(c)+'*'+mon(m) for m,c in sorted(p.items(),key=lambda z:(len(z[0]),z[0]))) or '0'
def xstr(q,names=None):
    def mon(m):return '*'.join(f'x{i+1}'+(f'^{a}' if a!=1 else '') for i,a in enumerate(m) if a) or '1'
    return ' + '.join('('+pstr(c,names)+')*'+mon(m) for m,c in q.items()) or '0'

def solve_linear(rows,n):
    """Solve rows of affine-linear polynomials=0; return free expressions."""
    M=[[q.get((i,),F(0)) for i in range(n)]+[-q.get((),F(0))] for q in rows if q]
    R,piv,_=rref(M)
    assert n not in piv,'Inconsistent linear equations'
    free=[i for i in range(n) if i not in piv];fi={k:i for i,k in enumerate(free)}
    ex={k:{(fi[k],):F(1)} for k in free}
    for r,k in zip(R,piv):
        q={():r[-1]} if r[-1] else {}
        for j in free:
            if r[j]:q[(fi[j],)]=-r[j]
        ex[k]=q
    return ex,free,len(piv)

def invariant_space(a,b,fix_trace=True):
    weights=(a,-a,b,-b)
    basis=[(I,m) for I in PAIRS for m in MON2 if sum(weights[i] for i in I)==sum(x*y for x,y in zip(weights,m))]
    Q={}
    for k,(I,m) in enumerate(basis):Q.setdefault(I,{})[m]={(k,):F(1)}
    compat=jacobi(P0,Q)
    equations=[p for q in compat.values() for p in q.values()]
    if fix_trace:
        s=xadd(entry(Q,0,1),entry(Q,2,3))
        target={(1,1,0,0):{():F(a)},(0,0,1,1):{():F(b)}}
        equations.extend(xadd(s,target,-1).values())
    ex,free,rank=solve_linear(equations,len(basis))
    QQ={}
    for k,(I,m) in enumerate(basis):
        if ex[k]:QQ.setdefault(I,{})[m]=ex[k]
    jac=jacobi(QQ)
    all_eq=[p for q in jac.values() for p in q.values() if p]
    inds,rb=polynomial_row_basis(all_eq)
    return dict(eigenvalues=weights,raw_invariant_count=len(basis),linear_rank=rank,
                free_count=len(free),free_basis=[basis[i] for i in free],Q=QQ,
                equations=[all_eq[i] for i in inds],row_reduced_equations=rb)

def main():
    report={}
    for name,a,b in [('generic',1,2),('resonance3',1,3),('equal',1,1),('one_zero',1,0)]:
        ans=invariant_space(a,b)
        print('\n'+name+': '+str({k:ans[k] for k in ('raw_invariant_count','linear_rank','free_count')}))
        print('Free coordinates:',ans['free_basis'])
        for I,q in ans['Q'].items():print('Q'+str(I),xstr(q))
        print('Jacobi equations (constant row basis):')
        for q in ans['row_reduced_equations']:print(pstr(q))
        report[name]={k:ans[k] for k in ('eigenvalues','raw_invariant_count','linear_rank','free_count','free_basis')}
        report[name]['Q']=[[list(I),[[list(m),encode(c)] for m,c in q.items()]] for I,q in ans['Q'].items()]
        report[name]['jacobi_equations']=[encode(q) for q in ans['row_reduced_equations']]
    (OUT/'semisimple_strata.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()

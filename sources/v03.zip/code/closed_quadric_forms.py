#!/usr/bin/env python3
"""Exact linear closed-form computation for alpha/Q^2, deg alpha <=2 on A4."""
from itertools import combinations, combinations_with_replacement
from collections import defaultdict
from fractions import Fraction
from math import gcd
from functools import reduce
import json
N=4
PAIRS=list(combinations(range(N),2)); TRIPLES=list(combinations(range(N),3))
def monomials(d):
 out=[]
 for fs in combinations_with_replacement(range(N),d):
  e=[0]*N
  for i in fs:e[i]+=1
  out.append(tuple(e))
 return out
MON=sum((monomials(i) for i in range(3)),[])
BASIS=[(ij,e) for ij in PAIRS for e in MON]
def clean(p):return {e:c for e,c in p.items() if c}
def plus(*args):
 p=defaultdict(int)
 for a in args:
  for e,c in a.items():p[e]+=c
 return clean(p)
def scale(p,c):return {e:v*c for e,v in p.items() if v*c}
def mul(p,q):
 r=defaultdict(int)
 for e,c in p.items():
  for f,d in q.items():r[tuple(a+b for a,b in zip(e,f))]+=c*d
 return clean(r)
def diff(p,i):
 r={}
 for e,c in p.items():
  if e[i]:
   f=list(e);f[i]-=1;r[tuple(f)]=c*e[i]
 return r
def x(i):e=[0]*N;e[i]=1;return {tuple(e):1}
ONE={(0,)*N:1}
def sign(t):return (-1)**sum(t[i]>t[j] for i in range(len(t)) for j in range(i+1,len(t)))
def entry(alpha,ij):return scale(alpha.get(tuple(sorted(ij)),{}),sign(ij))
def closed_numerator(alpha,Q):
 out={}
 for ijk in TRIPLES:
  i,j,k=ijk
  da=plus(diff(entry(alpha,(j,k)),i),scale(diff(entry(alpha,(i,k)),j),-1),diff(entry(alpha,(i,j)),k))
  dqa=plus(mul(diff(Q,i),entry(alpha,(j,k))),scale(mul(diff(Q,j),entry(alpha,(i,k))),-1),mul(diff(Q,k),entry(alpha,(i,j))))
  for e,c in plus(mul(Q,da),scale(dqa,-2)).items():out[ijk,e]=c
 return out

def primitive_numerator(beta,Q):
 out={}
 for i,j in PAIRS:
  out[i,j]=plus(mul(Q,plus(diff(beta.get(j,{}),i),scale(diff(beta.get(i,{}),j),-1))),scale(mul(diff(Q,i),beta.get(j,{})),-1),mul(diff(Q,j),beta.get(i,{})))
 return out

def normalize(r):
 r=clean(r)
 if not r:return r
 g=reduce(gcd,(abs(c) for c in r.values()))
 if r[min(r)]<0:g=-g
 return {k:v//g for k,v in r.items()}
def rank_rows(rows):
 piv={}
 for rr in rows:
  r=normalize(rr)
  while r:
   k=min(r)
   if k not in piv:piv[k]=r;break
   a,b=r[k],piv[k][k]
   r=normalize(plus({(j,):b*v for j,v in r.items()},{(j,):-a*v for j,v in piv[k].items()}))
   r={j[0]:v for j,v in r.items()}
 return len(piv),piv

def sparse_rank(rows):
 piv={}
 for rr in rows:
  r=normalize(rr)
  while r:
   k=min(r)
   if k not in piv:piv[k]=r;break
   a,b=r[k],piv[k][k]
   nr=defaultdict(int)
   for j,v in r.items():nr[j]+=b*v
   for j,v in piv[k].items():nr[j]-=a*v
   r=normalize(nr)
 return len(piv),piv

def compute(Q):
 rows=defaultdict(dict)
 for c,(ij,e) in enumerate(BASIS):
  for key,v in closed_numerator({ij:{e:1}},Q).items():rows[key][c]=v
 rank,piv=sparse_rank(rows.values())
 idx={b:i for i,b in enumerate(BASIS)}
 prim=[]
 for i in range(4):
  for e in [(0,)*4]+monomials(1):
   a=primitive_numerator({i:{e:1}},Q)
   assert not closed_numerator(a,Q)
   prim.append({idx[ij,e]:v for ij,p in a.items() for e,v in p.items()})
 prank,_=sparse_rank(prim)
 return dict(closed_dimension=90-rank,primitive_dimension=prank,kernel_equals_affine_primitives=90-rank==prank)
if __name__=='__main__':
 cases={
 'rank5_transverse':plus(ONE,*[mul(x(i),x(i)) for i in range(4)]),
 'rank5_tangent':plus(x(3),*[mul(x(i),x(i)) for i in range(3)]),
 'rank4_transverse':plus(ONE,*[mul(x(i),x(i)) for i in range(3)]),
 'rank4_tangent':plus(x(3),*[mul(x(i),x(i)) for i in range(2)]),
 'rank3_transverse':plus(ONE,*[mul(x(i),x(i)) for i in range(2)]),
 'rank3_tangent':plus(x(3),mul(x(0),x(0))),
 'rank4_vertex_hyperplane':plus(*[mul(x(i),x(i)) for i in range(4)]),
 'rank3_vertex_hyperplane':plus(*[mul(x(i),x(i)) for i in range(3)]),
 }
 result={k:compute(q) for k,q in cases.items()}
 print(json.dumps(result,indent=2))
 from pathlib import Path
 with (Path(__file__).resolve().parent.parent/'data'/'closed_quadric_forms_results.json').open('w') as f:json.dump(result,f,indent=2)

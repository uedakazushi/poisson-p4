#!/usr/bin/env python3
"""Independent sparse coefficient audit of the tangent-double-quadric bracket.

The Jacobi derivative below is assembled by direct monomial index loops,
independent of the baseline linearized_jacobi_matrix implementation.
"""
from itertools import combinations,combinations_with_replacement,product
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
import sys,json,hashlib
import numpy as np
import poisson_p4_components_check as old
from build_universal_slice import rref
N=5
PAIRS=list(combinations(range(N),2));TRIPLES=list(combinations(range(N),3))
def mon(fs):return tuple(fs.count(i) for i in range(N))
def poly(terms):return {mon(list(fs)):c for c,fs in terms}
P={(1,2):poly([(2,(0,2)),(-1,(1,1))]),
 (1,3):poly([(2,(1,2)),(3,(0,3))]),
 (1,4):poly([(5,(0,4)),(1,(2,2)),(2,(1,3))]),
 (2,3):poly([(1,(0,4)),(5,(2,2)),(4,(1,3))]),
 (2,4):poly([(2,(2,3)),(4,(1,4))]),
 (3,4):poly([(3,(3,3)),(-8,(2,4))])}
def eps(seq):
 if len(set(seq))!=len(seq):return 0
 return (-1)**sum(seq[i]>seq[j] for i in range(len(seq)) for j in range(i+1,len(seq)))
def ent(P,i,j):
 if i==j:return {}
 if i<j:return P.get((i,j),{})
 return {e:-c for e,c in P.get((j,i),{}).items()}
def jac_cross(P,R):
 out=defaultdict(int)
 for T in TRIPLES:
  for i,j,k in (T,(T[1],T[2],T[0]),(T[2],T[0],T[1])):
   for h in range(N):
    for U,V in ((P,R),(R,P)):
     for a,ca in ent(U,i,h).items():
      for b,cb in ent(V,j,k).items():
       if b[h]:
        e=[ai+bi for ai,bi in zip(a,b)];e[h]-=1
        out[T,tuple(e)]+=ca*cb*b[h]
 return {k:v for k,v in out.items() if v}
def main():
    assert not jac_cross(P,P)
    m2=[mon(list(fs)) for fs in combinations_with_replacement(range(N),2)]
    m4=[mon(list(fs)) for fs in combinations_with_replacement(range(N),4)]
    basis=list(product(PAIRS,m2));bidx={b:i for i,b in enumerate(basis)}
    outbasis=list(product(combinations(range(N),4),m4));outidx={b:i for i,b in enumerate(outbasis)}
    J=np.zeros((len(outbasis),len(basis)),dtype=np.int64)
    for col,(pair,exps) in enumerate(basis):
     for (T,e),c in jac_cross(P,{pair:{exps:1}}).items():
      for i in range(N):
       sg=eps((i,)+T)
       if sg:
        f=list(e);f[i]+=1
        J[outidx[tuple(sorted((i,)+T)),tuple(f)],col]+=sg*c
    # Orbit derivative uses direct substitution on monomial coefficients.
    # x_a d/dx_b is represented as (b,a).
    V=np.zeros((150,25),dtype=np.int64)
    A=np.zeros((150,25),dtype=np.int64)
    for col,(b,a) in enumerate(product(range(N),repeat=2)):
     for i in range(N):
      if i!=b:V[bidx[tuple(sorted((i,b))),mon([i,a])],col]+=eps((i,b))
     for (i,j),q in P.items():
      for e,c in q.items():
       if e[b]:
        f=list(e);f[b]-=1;f[a]+=1
        A[bidx[(i,j),tuple(f)],col]+=c*e[b]
       if i==a and b!=j:A[bidx[tuple(sorted((b,j))),e],col]-=c*eps((b,j))
       if j==a and i!=b:A[bidx[tuple(sorted((i,b))),e],col]-=c*eps((i,b))
    pvec=np.array([P.get(pair,{}).get(e,0) for pair,e in basis],dtype=np.int64)
    M=np.column_stack([V,A,pvec])
    assert not np.any(J@M)
    assert np.array_equal(J,old.linearized_jacobi_matrix(P))
    jrank=len(rref(J.tolist())[1]);vrank=len(rref(V.tolist())[1]);mrank=len(rref(M.tolist())[1])
    certJ=old.modular_rank_certificate(J);certM=old.modular_rank_certificate(M)
    assert (jrank,vrank,mrank)==(103,24,47)
    assert (certJ['rank_mod_prime'],certM['rank_mod_prime'])==(103,47)
    # Rank at a concrete projective point: x0=x4=1, x1=x2=x3=0.
    point=(1,0,0,0,1)
    val={I:sum(c*np.prod([x**k for x,k in zip(point,e)]) for e,c in q.items()) for I,q in P.items()}
    pf=val[1,2]*val[3,4]-val[1,3]*val[2,4]+val[1,4]*val[2,3]
    assert pf==5
    report={'full_affine_Jacobi_exact':True,'independent_Jacobi_matrix_matches_baseline':True,
     'JV_JA_JP_exact_zero':True,'jacobi_rank_over_Q':jrank,'vertical_rank_over_Q':vrank,
     'vertical_orbit_scale_rank_over_Q':mrank,'affine_tangent_dimension':126-jrank,
     'affine_orbit_with_scaling_dimension':mrank-vrank,'projective_tangent_dimension':125-jrank,
     'projective_PGL_orbit_dimension':mrank-vrank-1,'rank4_point':point,'rank4_point_pfaffian':int(pf),
     'jacobi_minor_certificate':certJ,'orbit_minor_certificate':certM,
     'conclusion':'Orbit closure is a 22-dimensional projective irreducible component; lower bound rises from46 to47 if previous46 retained.'}
    outdir=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent.parent/'data'
    outdir.mkdir(parents=True,exist_ok=True)
    out=outdir/'rigid_quadric_independent_audit.json'
    out.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if not k.endswith('certificate')},indent=2))

if __name__=="__main__":
    main()

#!/usr/bin/env python3
"""Run the v3 exact certificates with portable imports and output paths.

Usage: python code/run_v3_checks.py [OUTPUT_DIRECTORY]
The previous-v2 large slice computations are preserved separately and are
not rerun by this v3-only driver.
"""
from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else HERE.parent / "data"
OUT.mkdir(parents=True, exist_ok=True)
SCRIPTS = [
    "verify_smooth_double_quadric.py",
    "audit_rigid_quadric.py",
    "classify_extensions.py",
    "audit_extension_certificate.py",
    "semisimple_quadratic.py",
    "verify_trace_reduction.py",
    "tangent_quadratic_points.py",
    "check_rank3_form_identities.py",
]

def main():
    results = []
    for name in SCRIPTS:
        started = time.monotonic()
        result = subprocess.run(
            [sys.executable, str(HERE / name), str(OUT)],
            text=True, capture_output=True, cwd=OUT,
        )
        log = result.stdout + result.stderr
        (OUT / (Path(name).stem + ".log")).write_text(log)
        item = {
            "script": name,
            "returncode": result.returncode,
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "source_sha256": hashlib.sha256((HERE / name).read_bytes()).hexdigest(),
        }
        results.append(item)
        print(json.dumps(item), flush=True)
        if result.returncode:
            print(log, flush=True)
            raise SystemExit(result.returncode)
    import numpy
    import sympy
    report = {
        "python": platform.python_version(),
        "numpy": numpy.__version__,
        "sympy": sympy.__version__,
        "all_eight_v3_checks_passed": True,
        "runs": results,
    }
    (OUT / "reproducibility_check.json").write_text(json.dumps(report, indent=2) + "\n")

if __name__ == "__main__":
    main()

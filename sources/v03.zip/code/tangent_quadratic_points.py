#!/usr/bin/env python3
"""Characteristic-zero tangent certificates at explicit quadratic points."""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
import itertools,json,sys
import numpy as np
HERE=Path(__file__).resolve().parent
import sys
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parent/"data"
OUT.mkdir(parents=True,exist_ok=True)
import poisson_p4_components_check as p
import verify_rank2_components as v
from build_universal_slice import rref
from verify_quadratic_rmap import hamiltonian

def mono(i,j):
    m=[0]*5;m[i]+=1;m[j]+=1;return tuple(m)
def normal(A,B,C,D,E,P=0,R=0):
    Ff=C-E;G=-B-E;H=B-C+E
    Q={(1,2):{mono(1,2):A,mono(3,4):B},
       (3,4):{mono(1,2):C,mono(3,4):D},
       (1,3):{mono(1,3):E},(1,4):{mono(1,4):Ff,mono(2,2):P},
       (2,3):{mono(2,3):G,mono(1,1):R},(2,4):{mono(2,4):H}}
    return {I:{m:c for m,c in q.items() if c} for I,q in Q.items()}
def polar(Q,R):
    S={I:defaultdict(int,q) for I,q in Q.items()}
    for I,q in R.items():p.add_polynomial(S.setdefault(I,defaultdict(int)),q)
    jq=p.affine_jacobi_coefficients(Q);jr=p.affine_jacobi_coefficients(R)
    out=p.affine_jacobi_coefficients(S)
    for I,q in out.items():
        q=defaultdict(int,q);p.add_polynomial(q,jq[I],-1);p.add_polynomial(q,jr[I],-1)
        out[I]={m:c for m,c in q.items() if c}
    return out
def add(Q,R):
    S={I:defaultdict(int,q) for I,q in Q.items()}
    for I,q in R.items():p.add_polynomial(S.setdefault(I,defaultdict(int)),q)
    return {I:{m:c for m,c in q.items() if c} for I,q in S.items()}
def scale(Q,c):return {I:{m:c*d for m,d in q.items()} for I,q in Q.items()}

def main():
    mons=[m for m in p.DEGREE_TWO if m[0]==0]
    ham=[hamiltonian({m:1}) for m in mons]
    basis=[v.wedge_fields(a,b) for a,b in itertools.combinations(ham,2)]
    target=[(I,m) for I in itertools.combinations(range(1,5),3) for m in p.homogeneous_monomials(3) if m[0]==0]
    report={}
    points={
      'generic_split':normal(2,0,0,5,7),
      'generic_mixed':normal(2,5,0,5,7),
      'resonance_extra_hyperbola':normal(-1,0,2,3,1,1,3),
      'resonance_split_P':normal(1,0,0,3,1,1,0),
      'resonance_split_R':normal(1,0,0,3,-1,0,1),
      'resonance_C_half_P_scaled':scale(normal(F(1,2),0,F(1,2),3,1,1,0),2),
      'resonance_C_half_R_scaled':scale(normal(F(1,2),0,F(1,2),3,F(-1,2),0,1),2),
      'resonance_mixed_P_scaled':scale(normal(1,F(3,2),0,F(3,2),F(-1,2),1,0),2),
      'resonance_mixed_R_scaled':scale(normal(1,F(3,2),0,F(3,2),-1,0,1),2),
    }
    P0={(1,2):{mono(0,0):1},(3,4):{mono(0,0):1}}
    for name,Q in points.items():
        assert all(not c for c in p.affine_jacobi_coefficients(Q).values()),name
        S=add(P0,Q)
        assert all(not c for c in p.affine_jacobi_coefficients(S).values()),name
        cols=[polar(Q,R) for R in basis]
        M=np.array([[col.get(I,{}).get(m,0) for col in cols] for I,m in target],dtype=np.int64)
        rank=len(rref(M.tolist())[1])
        full=p.linearized_jacobi_matrix(S)
        fullcert=p.modular_rank_certificate(full)
        # Full rank is certified exactly by rational elimination, not inferred
        # solely from the modular lower bound.
        fullrank=len(rref(full.tolist())[1])
        assert fullrank==fullcert['rank_mod_prime']
        orbit=[]
        for h in ham:
            A=np.zeros((5,5),dtype=np.int64)
            for i,q in enumerate(h):
                for m,c in q.items():A[i,m.index(1)]=c
            orbit.append(p.bivector_vector(v.linear_action_derivative(Q,A)))
        orbitrank=len(rref(np.column_stack(orbit).tolist())[1])
        item={'quadratic_tangent_dimension':45-rank,'quadratic_jacobi_rank_exact':rank,
              'quadratic_modular_certificate':p.modular_rank_certificate(M),
              'Sp4_orbit_dimension':orbitrank,
              'full_P4_affine_tangent_dimension':126-fullrank,
              'full_P4_jacobi_rank_exact':fullrank,
              'full_P4_modular_certificate':fullcert}
        if name in ('generic_split','generic_mixed'):
            if name=='generic_split':
                tangents=[normal(1,0,0,0,0),normal(0,0,0,1,0),normal(0,0,0,0,1)]
            else:
                tangents=[normal(1,0,0,0,0),normal(0,1,0,1,0),normal(0,0,0,0,1)]
            D=np.column_stack(orbit+[p.bivector_vector(t) for t in tangents])
            dr=len(rref(D.tolist())[1]);assert dr==45-rank
            item['quadratic_actual_family_derivative_rank_exact']=dr
            item['quadratic_locus_smooth_component_certificate']=True
        if name.startswith('resonance_'):
            D=np.column_stack(orbit+[p.bivector_vector(Q)])
            dr=len(rref(D.tolist())[1]);assert dr==45-rank
            item['quadratic_actual_family_derivative_rank_exact']=dr
            item['quadratic_locus_smooth_component_certificate']=True
        report[name]=item
        print(name,{k:x for k,x in item.items() if 'certificate' not in k})
    (OUT/'quadratic_tangent_certificates.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()

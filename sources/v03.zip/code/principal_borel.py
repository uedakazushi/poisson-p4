from pathlib import Path
import sys,json
from fractions import Fraction as F
from collections import defaultdict
import numpy as np
import poisson_p4_components_check as p
import verify_rank2_components as v
from build_universal_slice import rref
N=np.zeros((5,5),dtype=int)
for i,c in enumerate((-1,-1,2,1)):N[i+1,i]=c
raw=[i for i,(ij,m) in enumerate(p.BIVECTOR_BASIS) if sum(ij)-sum(k*a for k,a in enumerate(m))==1]
cols=[]
for k in raw:
 ij,m=p.BIVECTOR_BASIS[k];P={ij:{m:1}}
 lie=p.bivector_vector(v.linear_action_derivative(P,N))
 div=np.zeros(25,dtype=int)
 for j in range(5):
  for i in range(5):
   for e,c in p.polynomial_derivative(p.bivector_entry(P,i,j),i).items():div[5*j+e.index(1)]+=c
 cols.append(np.concatenate([lie,div]))
M=np.column_stack(cols)
R,piv,_=rref(M.tolist());free=[k for k in range(len(raw)) if k not in piv]
vs=[];polys=[]
for k in free:
 c=[F(0)]*len(raw);c[k]=1
 for row,j in zip(R,piv):c[j]=-row[k]
 z=np.zeros(150,dtype=object)
 for rr,cc in zip(raw,c):z[rr]=cc
 vs.append(z)
 P={}
 for rr,cc in zip(raw,c):
  if cc:
   ij,m=p.BIVECTOR_BASIS[rr];P.setdefault(ij,{})[m]=cc
 polys.append(P)
print('weight space',len(raw),'highest/divfree dim',len(free))
Jterms=[]
for i,P in enumerate(polys):
 for j in range(i,len(polys)):
  R=polys[j]
  if i==j:K=p.affine_jacobi_coefficients(P)
  else:
   S={ij:dict(P.get(ij,{})) for ij in p.PAIRS}
   for ij,q in R.items():
    for e,c in q.items():S[ij][e]=S[ij].get(e,F(0))+c
   K=p.affine_jacobi_coefficients(S)
   for U in (P,R):
    for ijk,q in p.affine_jacobi_coefficients(U).items():
     for e,c in q.items():K[ijk][e]=K[ijk].get(e,F(0))-c
  Jterms.append((i,j,K))
rows=defaultdict(dict)
for i,j,K in Jterms:
 for ijk,q in K.items():
  for e,c in q.items():
   if c:rows[ijk,e][i,j]=c
mons=[(i,j) for i in range(len(polys)) for j in range(i,len(polys))]
rr,pp,_=rref([[q.get(ij,F(0)) for ij in mons] for q in rows.values()])
print('jacobi monomials',mons)
print('jacobi relations',[[str(c) for c in r] for r in rr[:len(pp)]])
report={'raw_indices':raw,'highest_weight_dimension':len(free),'basis':[[[list(ij),[[list(m),str(c)] for m,c in q.items()]] for ij,q in P.items()] for P in polys],'jacobi_parameter_monomials':mons,'jacobi_equations':[[str(c) for c in r] for r in rr[:len(pp)]]}
((Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent.parent/'data')/'principal_borel_results.json').write_text(json.dumps(report,indent=2)+'\n')
from math import lcm,gcd
from functools import reduce
Bdata=[]
for name,co in [('borel_point_1',(1,-4,1)),('borel_point_2',(1,-11,3)),('borel_point_3',(8,-48,9))]:
 Z={ij:defaultdict(F) for ij in p.PAIRS}
 for c,P in zip(co,polys):
  for ij,q in P.items():
   for e,vv in q.items():Z[ij][e]+=c*vv
 den=reduce(lcm,(c.denominator for q in Z.values() for c in q.values()),1)
 gg=reduce(gcd,(int(c*den) for q in Z.values() for c in q.values()),0)
 P={ij:{e:int(c*den)//gg for e,c in q.items() if c} for ij,q in Z.items()}
 assert not any(p.affine_jacobi_coefficients(P).values())
 J=p.linearized_jacobi_matrix(P);V=p.vertical_bivector_matrix()
 acts=[]
 for i in range(5):
  for j in range(5):
   M=np.zeros((5,5),dtype=int);M[i,j]=1
   acts.append(p.bivector_vector(v.linear_action_derivative(P,M)))
 A=np.column_stack([V,*acts,p.bivector_vector(P)])
 assert not np.any(J@A)
 jr=len(rref(J.tolist())[1]);ar=len(rref(A.tolist())[1])
 f=defaultdict(int)
 for i in range(5):
  a,b,c,d=[j for j in range(5) if j!=i]
  pf=defaultdict(int)
  for j,k,l,m,sg in [(a,b,c,d,1),(a,c,b,d,-1),(a,d,b,c,1)]:
   p.add_polynomial(pf,p.polynomial_product(P.get((j,k),{}),P.get((l,m),{})),sg)
  for e,k in pf.items():
   ee=list(e);ee[i]+=1;f[tuple(ee)]+=(-1)**i*k
 f={e:c for e,c in f.items() if c}
 out={'name':name,'canonical_coefficients':[[list(ij),[[list(e),c] for e,c in q.items()]] for ij,q in P.items() if q],
      'projective_Pfaffian':[[list(e),c] for e,c in f.items()],
      'J_rank':jr,'projective_tangent':125-jr,'PGL_projective_orbit':ar-25}
 Bdata.append(out);print(json.dumps(out))
report['Poisson_points']=Bdata
((Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent.parent/'data')/'principal_borel_results.json').write_text(json.dumps(report,indent=2)+'\n')

#!/usr/bin/env python3
"""Exact Hamiltonian r-map on the 45-dimensional quadratic slice."""
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
import itertools,json,sys
import numpy as np

HERE=Path(__file__).resolve().parent
import poisson_p4_components_check as p
import verify_rank2_components as v
from build_universal_slice import rref,polynomial_row_basis


def hamiltonian(q):
    f=[{} for _ in range(5)]
    for i,j in ((1,2),(3,4)):
        f[j]=p.polynomial_derivative(q,i)
        f[i]={a:-c for a,c in p.polynomial_derivative(q,j).items()}
    return f


def bracket(f,g):
    out=defaultdict(int)
    for i,j in ((1,2),(3,4)):
        p.add_polynomial(out,p.polynomial_product(p.polynomial_derivative(f,i),p.polynomial_derivative(g,j)))
        p.add_polynomial(out,p.polynomial_product(p.polynomial_derivative(f,j),p.polynomial_derivative(g,i)),-1)
    return {a:c for a,c in out.items() if c}


def wedge3(a,b,c):
    out={}
    for I in itertools.combinations(range(1,5),3):
        q=defaultdict(int)
        for perm in itertools.permutations(I):
            sign=p.permutation_sign(perm)
            term=p.polynomial_product(p.polynomial_product(a[perm[0]],b[perm[1]]),c[perm[2]])
            p.add_polynomial(q,term,sign)
        out[I]={m:d for m,d in q.items() if d}
    return out


def main():
    mons=[a for a in p.homogeneous_monomials(2) if a[0]==0]
    functions=[{a:1} for a in mons];ham=[hamiltonian(q) for q in functions]
    ind={a:i for i,a in enumerate(mons)}
    pairs=list(itertools.combinations(range(10),2));triples=list(itertools.combinations(range(10),3))
    target2=list(itertools.product(itertools.combinations(range(1,5),2),mons))
    cubes=[a for a in p.homogeneous_monomials(3) if a[0]==0]
    target3=list(itertools.product(itertools.combinations(range(1,5),3),cubes))
    rho2=np.zeros((60,45),dtype=np.int64);rho3=np.zeros((80,120),dtype=np.int64)
    for col,(a,b) in enumerate(pairs):
        Q=v.wedge_fields(ham[a],ham[b])
        for row,(I,m) in enumerate(target2):rho2[row,col]=Q.get(I,{}).get(m,0)
    for col,(a,b,c) in enumerate(triples):
        Q=wedge3(ham[a],ham[b],ham[c])
        for row,(I,m) in enumerate(target3):rho3[row,col]=Q.get(I,{}).get(m,0)
    # Embedded sl2 example: Q=4*x1*x2*d1^d2 is Poisson, but r fails CYBE.
    r={(0,4):1}
    Q={I:defaultdict(int) for I in p.PAIRS}
    for (a,b),c in r.items():
        biv=v.wedge_fields(ham[a],ham[b])
        for I,q in biv.items():p.add_polynomial(Q[I],q,c)
    Q={I:{m:c for m,c in q.items() if c} for I,q in Q.items()}
    assert all(not q for q in p.affine_jacobi_coefficients(Q).values())
    Pplus={I:dict(q) for I,q in Q.items()}
    for I in ((1,2),(3,4)):
        Pplus.setdefault(I,{})[(2,0,0,0,0)]=1
    assert all(not q for q in p.affine_jacobi_coefficients(Pplus).values())
    rr=defaultdict(int)
    for (a,b),c in r.items():
        for (d,e),f in r.items():
            for i,j,k,l,sg in ((a,d,b,e,1),(a,e,b,d,-1),(b,d,a,e,-1),(b,e,a,d,1)):
                for m,value in bracket(functions[i],functions[j]).items():
                    h=ind[m];sign=p.permutation_sign((h,k,l))
                    if sign:rr[tuple(sorted((h,k,l)))]+=sg*c*f*value*sign
    rr={I:c for I,c in rr.items() if c}
    assert rr,'Example must fail the ordinary CYBE.'
    rrvec=np.array([rr.get(I,0) for I in triples],dtype=np.int64)
    assert not np.any(rho3@rrvec)
    rank2=len(rref(rho2.tolist())[1]);rank3=len(rref(rho3.tolist())[1])
    assert (rank2,rank3)==(45,70)
    report={
        'Hamiltonian_basis_quadratic_exponents':mons,
        'rho2_shape':[60,45],'rho2_rank_exact':rank2,
        'rho2_modular_certificate':p.modular_rank_certificate(rho2),
        'rho3_shape':[80,120],'rho3_rank_exact':rank3,
        'rho3_kernel_dimension':120-rank3,
        'rho3_modular_certificate':p.modular_rank_certificate(rho3),
        'non_CYBE_example':{
            'r_pairs':[[list(I),c] for I,c in r.items()],
            'Schouten_r_r':[[list(I),c] for I,c in sorted(rr.items())],
            'rho3_Schouten_r_r_exact_zero':True,
            'induced_quadratic_bivector':[[list(I),[[list(m),c] for m,c in sorted(q.items())]]
                                        for I,q in Q.items() if q],
            'induced_Jacobi_exact_zero':True,
            'constant_plus_induced_Jacobi_exact_zero':True,
        },
    }
    target=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parent/'data'
    target.mkdir(parents=True,exist_ok=True)
    sym=target
    if (sym/'symplectic_slice_reduced_equations.json').exists():
        data=json.loads((sym/'symplectic_slice_reduced_equations.json').read_text())
        weights=data['parameter_weights']
        def specialise(encoded):
            return {tuple(m):F(n,d) for m,n,d in encoded if all(weights[i]==2 for i in m)}
        equations=[specialise(q) for q in data['equations']]
        assert sum(bool(q) for q in equations)==70
        assert all(len(m)==2 for q in equations for m in q)
        assert len(polynomial_row_basis(equations)[0])==70
        reconstruction=json.loads((sym/'symplectic_slice_equations.json').read_text())
        for record in reconstruction['eliminated_raw_variables']:
            pair,alpha=p.BIVECTOR_BASIS[record['raw_index']]
            w=(4,-1,-1,-1,-1)
            degree=(10+sum(w[i] for i in pair)-sum(a*b for a,b in zip(alpha,w)))//5
            q=specialise(record['polynomial'])
            if degree in (1,3):assert not q
            elif degree==2:assert all(len(m)==1 for m in q)
            else:raise AssertionError('Unexpected eliminated weight.')
        report['linear_zero_specialization']={
            'weight1_variables_set_to_zero':16,'weight2_variables_remaining':45,
            'nonzero_equations':70,'equations_zero':64,
            'equation_degree':2,'equation_span_rank_exact':70,
            'reconstructed_linear_and_cubic_terms_zero':True,
            'reconstructed_quadratic_terms_linear_in_45_parameters':True,
        }
    (target/'quadratic_rmap_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()

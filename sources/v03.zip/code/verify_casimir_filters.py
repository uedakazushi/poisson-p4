#!/usr/bin/env python3
"""Exact low-degree polynomial Casimir spaces for six verified components."""
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
import poisson_p4_components_check as p
import verify_rank2_components as v
from build_universal_slice import rref

def canonical_times_five(P):
    div=[defaultdict(int) for _ in range(5)]
    for j in range(5):
        for i in range(5):p.add_polynomial(div[j],p.polynomial_derivative(p.bivector_entry(P,i,j),i))
    Euler=[p.coordinate_polynomial(i) for i in range(5)]
    vertical=v.wedge_fields(Euler,div)
    out={}
    for pair in p.PAIRS:
        q=defaultdict(int)
        p.add_polynomial(q,P.get(pair,{}),5)
        p.add_polynomial(q,vertical.get(pair,{}),-1)
        out[pair]={m:c for m,c in q.items() if c}
    assert not any(p.affine_jacobi_coefficients(out).values())
    return out

def casimirs(P,degree):
    mon=p.homogeneous_monomials(degree)
    target=p.homogeneous_monomials(degree+1)
    tidx={alpha:i for i,alpha in enumerate(target)}
    matrix=[[0]*len(mon) for _ in range(5*len(target))]
    for k,alpha in enumerate(mon):
        for j in range(5):
            q=defaultdict(int)
            for i in range(5):
                p.add_polynomial(q,p.polynomial_product(p.bivector_entry(P,i,j),p.polynomial_derivative({alpha:1},i)))
            for beta,c in q.items():matrix[j*len(target)+tidx[beta]][k]=c
    rr,pivots,_=rref(matrix)
    free=[k for k in range(len(mon)) if k not in pivots]
    basis=[]
    for f in free:
        coeff={f:F(1)}
        for i,k in enumerate(pivots):
            if rr[i][f]:coeff[k]=-rr[i][f]
        # Independent exact multiplication of each kernel column.
        assert all(sum(F(row[k])*c for k,c in coeff.items())==0 for row in matrix)
        basis.append([{'exponents':mon[k],'numerator':c.numerator,'denominator':c.denominator} for k,c in coeff.items()])
    return {'degree':degree,'domain_dimension':len(mon),'rank_exact':len(pivots),'dimension':len(free),'basis':basis}

def main():
    target=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE.parent/'data'
    target.mkdir(parents=True,exist_ok=True)
    cases=list(v.build_jacobian_cases())+[v.build_log_case(),v.build_lpb_case(p),v.build_affine_case((5,)),v.build_affine_case((4,1))]
    report=[]
    for case in cases:
        P=canonical_times_five(case['bivector'])
        spaces=[casimirs(P,d) for d in (1,2,3)]
        entry={'family':case['name'],'casimir_spaces':spaces}
        report.append(entry)
        print(case['name'],[s['dimension'] for s in spaces],flush=True)
    (target/'low_degree_casimir_certificate.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()

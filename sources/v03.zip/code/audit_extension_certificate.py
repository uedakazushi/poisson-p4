#!/usr/bin/env python3
"""Independent reconstruction and verification of the fixed-quadric extension ideal.

Jacobi coefficients are reconstructed by polarization of direct monomial loops
from audit_rigid_quadric, not by the extension generator's symbolic code.
The supplied row and ideal identities are checked afresh over Q.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict
from itertools import combinations
import json
import sys
from audit_rigid_quadric import P, PAIRS, jac_cross, eps, mon

OUT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / "data"

def wedge_euler(T):
    out = defaultdict(int)
    for (triple, exp), c in T.items():
        for i in range(5):
            sign = eps((i,) + triple)
            if sign:
                e = list(exp)
                e[i] += 1
                out[tuple(sorted((i,) + triple)), tuple(e)] += sign * c
    return {key: c for key, c in out.items() if c}

def decode(q):
    return {tuple(m): F(n, d) for m, n, d in q}

def add(a, b, k=F(1)):
    out = defaultdict(F, a)
    for m, c in b.items():
        out[m] += k * c
    return {m: c for m, c in out.items() if c}

def mul(a, b):
    out = defaultdict(F)
    for m, c in a.items():
        for n, d in b.items():
            out[tuple(sorted(m + n))] += c * d
    return {m: c for m, c in out.items() if c}

def combination(polys, coefficients):
    out = {}
    for i, coefficient in coefficients:
        out = add(out, mul(polys[i], decode(coefficient)))
    return out

def main():
    data = json.loads((OUT / "extension_equations.json").read_text())
    q = {mon([0, 4]): 1, mon([2, 2]): 1, mon([1, 3]): 1}
    W = {pair: dict(poly) for pair, poly in P.items()}
    for pair in ((1, 4), (2, 3)):
        for e, c in q.items():
            W[pair][e] = W[pair].get(e, 0) - c
        W[pair] = {e: c for e, c in W[pair].items() if c}
    C = [{pair: q} for pair in PAIRS]
    assert not wedge_euler(jac_cross(W, W))
    equations = {}

    def record(parameter_monomial, coordinate_polys, scalar=F(1)):
        for label, c in coordinate_polys.items():
            equations[label] = add(equations.get(label, {}), {parameter_monomial: F(c) * scalar})

    for i in range(10):
        record((i,), wedge_euler(jac_cross(W, C[i])))
        record((i, i), wedge_euler(jac_cross(C[i], C[i])), F(1, 2))
    for i, j in combinations(range(10), 2):
        record((i, j), wedge_euler(jac_cross(C[i], C[j])))
    equations = {key: poly for key, poly in equations.items() if poly}
    supplied = {
        (tuple(label[0]), tuple(label[1])): decode(poly)
        for label, poly in zip(data["original_equation_row_labels"], data["original_equations"])
    }
    assert equations == supplied
    original = [decode(q) for q in data["original_equations"]]
    rows = [decode(q) for q in data["row_basis"]]
    final = [decode(q) for q in data["final_ideal_generators"]]
    for q0, coefficients in zip(rows, data["row_basis_as_combinations_of_original_equations"]):
        reconstructed = {}
        for i, n, d in coefficients:
            reconstructed = add(reconstructed, original[i], F(n, d))
        assert reconstructed == q0
    for q0, coefficients in zip(original, data["original_equations_as_combinations_of_row_basis"]):
        assert combination(rows, coefficients) == q0
    for q0, coefficients in zip(rows, data["row_basis_as_polynomial_combinations_of_final_generators"]):
        assert combination(final, coefficients) == q0
    for q0, coefficients in zip(final, data["final_generators_as_polynomial_combinations_of_row_basis"]):
        assert combination(rows, coefficients) == q0
    expected = [{(i,): F(1)} for i in range(6)]
    expected += [{(6,): F(1), (7,): F(-1)}, {(8,): F(1)}, {(9,): F(1)}]
    expected += [{(7, 7): F(1), (7,): F(-1)}]
    assert final == expected
    report = {
        "independent_polarization_reconstruction_matches_all_original_equations": True,
        "original_nonzero_equations": len(original),
        "rational_row_identities_both_directions": True,
        "polynomial_ideal_identities_both_directions": True,
        "final_ideal_generators_match_nine_linears_and_t_squared_minus_t": True,
        "all_arithmetic_exact_over_Q": True,
        "conclusion": "The normalized extension scheme is exactly two reduced points."
    }
    (OUT / "extension_independent_audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()

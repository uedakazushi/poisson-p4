射影4空間の Poisson 構造 — 研究継続 v3
2026-10-28

主要な成果
==========
1. 全 projective Poisson scheme に、前回の46成分と異なる22次元の一般
   rank 4 成分 C_(H+2Q) を確認した。従って下界は47である。
2. 退化因子が H+2Q、Q が滑らかな quadric の分岐を完全分類した。
   H は Q に接し、座標変換と非零定数倍を除いて一意である。
3. 固定した smooth quadric 上の一般的な Aff(C) 型構造の周囲への
   Poisson 延長は、正規化後ちょうど二つの被約点である。
   一方は既知の rank 2 Aff(5) 成分、他方は今回の rank 4 成分に入る。
   相対 Aff(Q) 族は両成分の稠密開軌道 G/B と同型、次元は14+8=22。
4. 定数 symplectic bracket J と compatible な二次 bracket の45変数
   部分で、modular field が正則半単純となる開集合を完全分類した。
   6成分、次元は11,11,10,10,10,10。full P4 の追加6成分とは数えない。
5. 安定/noDiv の rank 2 分岐では、rank 3,4,5 の二次 Casimir があれば
   実際の (1,2,2) Jacobian 表示をもつ。
   既知の二つの rational 成分以外に残る候補は
       A1=A2=0
   または
       A1=C L, A2=C L^2
   を満たす。

対象と限定
==========
基礎体は C。成分の次元は非零 Poisson bivector を定数倍で割った
projective parameter scheme 内の次元であり、PGL5 商の次元ではない。
「少なくとも47」が証明済みであって「ちょうど47」ではない。
S61/S78 の最小素分解、他の rank 4 分岐、残る安定 rank 2 分岐は未解決。
文献上の新規性は主張しない。

読む順番
========
1. p4_poisson_completeness_v3.pdf — 日本語の統合研究ノート。
2. proofs/extension_theorem.txt — 延長 ideal の両方向包含の説明。
3. proofs/regular_semisimple_theorem.txt — 45変数部分の全場合分け。
4. proofs/rank3_quadratic_casimir.txt と rank4_quadratic_casimir.txt —
   詳細な低次数 Casimir の証明。中間結論は統合 PDF の結論で更新。
5. HANDOFF.txt — 次回の継続点、未解決事項、誤解しやすい点。

ディレクトリ
============
code/         v3 の検証コードと、それが使う v2 の exact 基礎コード。
data/         exact JSON、実行ログ、PDF 品質確認、再現性記録。
proofs/       各部分の詳細証明と独立 cross-audit。
previous_v2/  v2 の完全な履歴。baseline/ には前回の46成分の証明書もある。
SHA256SUMS.txt  bundle 内全ファイル（この manifest 自身を除く）の SHA-256。

Python による再現
=================
Python 3.12.14、NumPy 2.3.5、SymPy 1.14.0 で確認済み。
通常の仮想環境なら、bundle のルートで次を実行できる。

    python3 -m venv .venv
    .venv/bin/python -m pip install -r requirements.txt
    .venv/bin/python code/run_v3_checks.py /tmp/p4_v3_check_out

引数を省略すると data/ に結果を再生成する。
driver は次の8本を順に実行し、どれかが失敗すれば停止する。

    verify_smooth_double_quadric.py
    audit_rigid_quadric.py
    classify_extensions.py
    audit_extension_certificate.py
    semisimple_quadratic.py
    verify_trace_reduction.py
    tangent_quadratic_points.py
    check_rank3_form_identities.py

最後の script のみ SymPy が必要。classify_extensions.py は標準
ライブラリだけで standalone に実行できる。行列の rank は有理数体上
で計算し、別に非零小行列式を法1000003で確認している。
有限体の点サンプルや浮動小数点 rank から分類を推測してはいない。

独立な再構成
============
audit_rigid_quadric.py は全 Jacobi 線形化を別の単項式添字実装で作り、
350x150 行列の一致と rank103、vertical rank24、orbit+scale rank47
を確認する。全 projective tangent/orbit dimension はともに22。

audit_extension_certificate.py は W+qC の152係数方程式を独立な
polarization で再構成する。その後、152式と14行基底、14行基底と
最終10生成元の両方向の式をすべて有理数係数で再確認する。
最終 ideal:
  (c01,c02,c03,c04,c12,c13,c14-c23,c24,c34,c23^2-c23).

rank 3 の式変形については symbolic coefficient identity の確認に
加え、完全な証明の独立 cross-audit を保存している。

LaTeX による再組版
==================
日本語 LuaLaTeX、ltjsarticle、Harano Aji fonts を使用する。
書き込み用の枠はない。

    latexmk -lualatex -interaction=nonstopmode -halt-on-error \
      p4_poisson_completeness_v3.tex

作成 PDF は全ページを画像化して確認し、欠字・はみ出し・参照未解決も
検査した。data/pdf_quality_check.json に記録する。

補足計算
========
code/principal_borel.py と data/principal_borel_results.json は、principal
Borel の重み付き不変 lift の三次元部分についての補足記録である。
この部分の projective Poisson 点は三点で、そのうち一つが今回の rank4、
一つが rank2 Aff(5)。第三の rank4 点を別の full component とは数えない。
この任意の補足計算は上の v3 driver には含めていない。

前回の大規模 slice の再現
========================
previous_v2/README.txt を参照。
v3 は v2 の61変数・134方程式、78変数・182方程式を再定義しない。
既知成分の必要な次元分布だけを更新する。

S61: (dimension,count) = (13,1),(14,29),(15,8),(16,3).
S78: (14,3),(15,29),(16,8),(17,3),(20,2),(28,1),(31,1).

これらは完全な最小素分解の出力ではない。

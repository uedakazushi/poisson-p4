射影4空間のPoisson構造 — 研究継続 第11版
========================================

今回の主結果
------------
零磁気点 P*=P_{B=0} において、全射影Poissonスキームの局所次元は正確に24。
被約形式枝は正確に T16,T18,T20,T22,T24,T25 の六つ。
横断完成環Bの随伴次数環を全次数で決定し、随伴支持は六極小枝と
磁気平面・無限遠軸の計八つ。零磁気軌道だけの追加埋め込み支持はない。
nilradical N は N^5=0,N^4≠0。横断depth1、全depth22。

対象は複素数上の全射影Poissonスキーム。PGL商は取らない。
大域成分数の下界57は変更せず、大域的な完全分類は引き続き未完。
次数環と、完成局所環そのものの乗法を区別する。B≅完成(S/J) は未証明。

内容
----
p4_poisson_completeness_v11.pdf  日本語本文（LuaLaTeX、記入欄なし）
p4_poisson_completeness_v11.tex  主TeX
preamble.tex / sections/         全原稿
HANDOFF.txt                     次回の研究用の式・結論・未決定事項
proofs/                         全次数の証明と独立監査
code/zero_jets/                 全6変数jet、準素分解、Hilbert級数、軸加群
code/geometry/                  実際のT18,T20族、T16の接方向、磁気chart同値
code/independent/               多重ベクトル実装を共有しない独立検算
data/reproduced/                再現実行の全ログ・数学的JSON比較結果
previous_v10/                   第10版769ファイルを変更せず保存
manifest.json                   本版の全ファイルハッシュ

検証
----
Python 3.12、SymPy 1.14.0で、厳密有理数演算を用いた。
7項目すべて再実行成功（約74秒；環境により変動）。

必要なPython依存をインストール済みの環境で:

  python3 code/run_checks.py --output /tmp/p4_v11_reproduction
  python3 code/verify_bundle.py

run_checks.pyはコードを一時ディレクトリへ複製して実行するため、
収録された計算結果や旧版を変更しない。経過時間の欄だけを除き、
数学的JSONの全内容を比較する。計算入力の数学的ハッシュも同じ規則で正規化する。

日本語PDFのビルド（LuaTeXjaとHaranoAjiフォントが必要）:

  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v11.tex

証明の区別
----------
5次までの全方程式から J⊂in(I) を得る。
六次で初期イデアルは変わらないが、その安定は全次数の証明ではない。
実際の五曲面の重複度6＋一般磁気nil長さ4＝10を用いて核を次元1以下にし、
一般無限遠軸の長さ5とC[d]自由階数5を用いて残る核を零にする。
この比較により gr(B)=S/J を全次数で証明した。

既知の曲面 T25 はA2型で、一枝なのに接錐が二平面ある。
その片方がT24の接平面と重なるため、接錐の支持数だけで枝数を数えない。
共通座標における短い完成環の正規形、nilradicalの全積、他の境界型の被覆は残る。

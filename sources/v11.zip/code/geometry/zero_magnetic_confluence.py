"""Actual T18/T20 polynomial surfaces through zero magnetic P4 Poisson point.

Derives the surfaces from the already identified v9 confluences, with exact
projective tangent-coordinate certificates in the fixed full six-variable slice.
"""
from pathlib import Path
import ast, json
import sympy as s
from exact_calculus import Calculus
from full_kuranishi import actual, rk, rref

HERE = Path(__file__).resolve().parent
ref = json.loads((HERE / 'reference.json').read_text())
C = Calculus(5)
C.x = s.symbols('t x y z w')
t,x,y,z,w = C.x
h,c,d,k = s.symbols('h c d k')
C.pol = lambda f: {m:v for m,v in s.Poly(s.expand(f),*C.x).terms() if v}
loc = dict(zip(['t','x','y','z','w'],C.x)) | {'h':h,'c':c,'d':d,'k':k}
def read(dic):
    return C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals=loc) for I,f in dic.items()})
P0 = C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,
               (2,3):-z*z/2,(2,4):y*(x+2*z),(3,4):t*t+x*z+z*z})
A0=actual(C,P0)
_,ap=rref(A0)
A=A0[:,ap]
N=[read(q) for q in ref['zero']['full_slice_basis']]
K=A.row_join(s.Matrix.hstack(*[C.vector(q) for q in N]))
assert rk(A)==46 and rk(K)==52
def coordinates(R):
    coeff,free=K.gauss_jordan_solve(C.vector(R))
    assert free.rows==0
    assert K*coeff==C.vector(R)
    return [s.factor(a) for a in coeff[-6:]]

# w -> w+2z removes the quadratic z^2 magnetic term, then scale y,w by c.
G=s.Matrix([t,x,c*y,z,c*w+2*c*z]).jacobian(C.x)
sub=dict(zip(C.x,G.inv()*s.Matrix(C.x)))
out={'all_passed':True,'full_basis_variables':['a','b','p','c','d','q'],
     'transformation':'F_i(c,k)=c^(-1)*(G_c)_*M_i(c*k), G_c=(t,x,c*y,z,c*w+2*c*z)',
     'families':{}}
for tag in ['T18','T20']:
    M=C.as_matrix(read(ref[tag]['family']))
    F=((G*M.subs(h,c*k)*G.T)/c).subs(sub,simultaneous=True).applyfunc(s.cancel)
    assert all(f.is_polynomial(*C.x,c,k) for f in F)
    F=F.applyfunc(s.expand)
    assert F.subs(k,0)==C.as_matrix(P0)+C.as_matrix(C.tensor({(2,4):c*t*z}))
    PF=C.tensor({I:F[I] for I in C.pairs})
    assert C.cubic_vector(C.jacobi(PF)).applyfunc(s.expand)==s.zeros(350,1)
    dirs={u:C.tensor({I:s.diff(F[I],u).subs({c:0,k:0}) for I in C.pairs}) for u in [c,k]}
    co={str(u):list(map(str,coordinates(R))) for u,R in dirs.items()}
    a0,b0,p0,c0,d0,q0=coordinates(dirs[k])
    assert p0==c0==d0==q0==0 and b0!=0
    slope=s.factor(a0/b0)
    report={'family':C.encode(PF),'polynomial_extension_verified':True,
            'affine_Jacobi_zero':True,'source_equals_zero_magnetic':True,
            'k_zero_is_magnetic_c_tz':True,'normal_derivatives':co,
            'a_over_b_slope':str(slope),'points':{}}
    for cv,kv in [(0,0),(0,1),(1,0),(1,1)]:
        ss={c:cv,k:kv}
        P=C.tensor({I:F[I].subs(ss) for I in C.pairs})
        D=C.derivative(P,True)
        A=actual(C,P)
        dc=C.vector(C.tensor({I:s.diff(F[I],c).subs(ss) for I in C.pairs}))
        dk=C.vector(C.tensor({I:s.diff(F[I],k).subs(ss) for I in C.pairs}))
        ranks={'Jacobi_rank':rk(D),'group_rank':rk(A),
               'family_rank':rk(A.row_join(dc).row_join(dk))}
        report['points'][str((cv,kv))]=ranks
        print(tag,ss,ranks,flush=True)
    assert report['points']['(0, 0)']=={'Jacobi_rank':98,'group_rank':46,'family_rank':48}
    out['families'][tag]=report
    print(tag,'normal derivatives',co,flush=True)
    assert slope in [-s.Rational(1,4),-s.Rational(5,8)]
assert out['families']['T18']['a_over_b_slope']=='-5/8'
assert out['families']['T20']['a_over_b_slope']=='-1/4'

# The independently established v10 T16 three-parameter family.
T16=read(ref['zero']['universal_magnetic_T16_family'])
F16=C.as_matrix(T16)
assert F16.subs({c:0,d:0,k:0})==C.as_matrix(P0)
assert C.cubic_vector(C.jacobi(T16)).applyfunc(s.expand)==s.zeros(350,1)
co16={}
for u in [c,d,k]:
    R=C.tensor({I:s.diff(F16[I],u).subs({c:0,d:0,k:0}) for I in C.pairs})
    co16[str(u)]=list(map(str,coordinates(R)))
W16=s.Matrix.hstack(*[s.Matrix([s.sympify(a) for a in co16[str(u)]]) for u in [c,d,k]])
assert rk(W16)==3 and all(W16[0,j]+W16[1,j]==0 for j in range(3))
assert all(W16[i,j]==0 for i in [2,5] for j in range(3))
out['T16_normal_derivatives']=co16
out['T16_normal_rank']=3
out['T16_tangent_ideal']=['p','q','a+b']

# Exact eigenvectors, not merely classes modulo orbit directions.
X=s.Matrix([0,0,y,0,w])
assert C.vector(C.lie(P0,X))+C.vector(P0)==s.zeros(150,1)
weights=[1,1,2,-1,-1,2]
for R,weight in zip(N,weights):
    assert C.vector(C.lie(R,X))+C.vector(R)==weight*C.vector(R)
out['exact_torus_weights']=weights
out['full_slice_basis_are_actual_eigenvectors']=True
print('T16 normal derivatives',co16,flush=True)

# The generic d-axis is exactly the v10 infinity point over C((d)).
# H_d first removes d*x^2 in favor of -4*d*x*z; a fiber dilation then normalizes it.
Pd=C.as_matrix(P0)+C.as_matrix(C.tensor({(2,4):d*x*x}))
H=s.Matrix([t,x,y+s.Rational(2,3)*d*x,z,w-s.Rational(16,3)*d*z]).jacobian(C.x)
Hsub=dict(zip(C.x,H.inv()*s.Matrix(C.x)))
PH=(H*Pd*H.T).subs(Hsub,simultaneous=True).applyfunc(s.expand)
assert PH==C.as_matrix(P0)+C.as_matrix(C.tensor({(2,4):-4*d*x*z}))
scale=-1/(4*d)
L=s.diag(1,1,scale,1,scale)*H
Lsub=dict(zip(C.x,L.inv()*s.Matrix(C.x)))
PL=(-4*d*(L*Pd*L.T)).subs(Lsub,simultaneous=True).applyfunc(s.cancel)
assert PL==C.as_matrix(P0)+C.as_matrix(C.tensor({(2,4):x*z}))
out['d_axis_infinity_equivalence']={
    'source':'P_(d*x^2)',
    'fiber_translation':['t','x','y+2*d*x/3','z','w-16*d*z/3'],
    'translated_magnetic':'-4*d*x*z',
    'combined_coordinates':['t','x','-y/(4*d)-x/6','z','-w/(4*d)+4*z/3'],
    'combined_determinant':str(s.factor(L.det())),
    'Poisson_scalar':'-4*d',
    'target':'P_(x*z)',
    'identity_verified_over_QQ_d':True,
    'requires':'d invertible; in particular over C((d))'
}

# The generic two-dimensional magnetic plane is the nonzero finite v9 chart.
Pcd=C.as_matrix(P0)+C.as_matrix(C.tensor({(2,4):c*t*x+d*x*x}))
Hcd=s.Matrix([t,x,y+c*t+s.Rational(2,3)*d*x,z,w-s.Rational(16,3)*d*z]).jacobian(C.x)
Hcdsub=dict(zip(C.x,Hcd.inv()*s.Matrix(C.x)))
PHcd=(Hcd*Pcd*Hcd.T).subs(Hcdsub,simultaneous=True).applyfunc(s.expand)
assert PHcd==C.as_matrix(P0)+C.as_matrix(C.tensor({(2,4):-2*c*t*z-4*d*x*z}))
Lcd=s.diag(1,1,-1/(2*c),1,-1/(2*c))*Hcd
Lcdsub=dict(zip(C.x,Lcd.inv()*s.Matrix(C.x)))
PLcd=(-2*c*(Lcd*Pcd*Lcd.T)).subs(Lcdsub,simultaneous=True).applyfunc(s.cancel)
assert (PLcd-C.as_matrix(P0)-C.as_matrix(C.tensor({(2,4):t*z+(2*d/c)*x*z}))).applyfunc(s.cancel)==s.zeros(5)
Jz=s.Matrix([t,x,y,z,w-2*z]).jacobian(C.x)
Jzsub=dict(zip(C.x,Jz.inv()*s.Matrix(C.x)))
Pv9=(Jz*PLcd*Jz.T).subs(Jzsub,simultaneous=True).applyfunc(s.cancel)
assert (Pv9-C.as_matrix(P0)-C.as_matrix(C.tensor({(2,4):t*z+z*z+(2*d/c)*x*z}))).applyfunc(s.cancel)==s.zeros(5)
out['generic_magnetic_plane_equivalence']={
    'source':'P_(c*t*x+d*x^2)',
    'fiber_translation':['t','x','y+c*t+2*d*x/3','z','w-16*d*z/3'],
    'translated_magnetic':'-2*c*t*z-4*d*x*z',
    'normalized_coordinates':['t','x','-y/(2*c)-t/2-d*x/(3*c)','z','-w/(2*c)+8*d*z/(3*c)'],
    'normalized_determinant':str(s.factor(Lcd.det())),
    'Poisson_scalar':'-2*c',
    'normalized_target':'P_(t*z+(2*d/c)*x*z)',
    'last_gauge':['t','x','y','z','w-2*z'],
    'v9_target':'P_(t*z+z^2+a*x*z), a=2*d/c',
    'identity_verified_over_QQ_c_d':True,
    'requires':'c invertible; generic d/c is nonzero; valid over Frac(C[[c,d]])'
}
target=HERE/'zero_magnetic_confluence.json'
temp=target.with_suffix('.json.tmp');temp.write_text(json.dumps(out,indent=2)+'\n');temp.replace(target)

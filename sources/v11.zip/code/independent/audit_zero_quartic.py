"""Independent direct Jacobi audit of the v11 dimension certificate.

Does not import the Kuranishi or polynomial-calculus implementation.  The
supplied tensor jet is read as polynomial data, and the full Euler-wedged
Jacobi identity is recomputed with rational sparse polynomial arithmetic.
"""
from collections import defaultdict
from fractions import Fraction
from itertools import combinations, combinations_with_replacement
from pathlib import Path
import ast, hashlib, json, time
import sympy as s
from sympy.polys.matrices import DomainMatrix

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'zero_jets'
X=s.symbols('t x y z w')
U=s.symbols('a b p c d q')
ZERO=(0,)*11
MAXDEG=5

def mathematical_hash(path):
    def clean(value):
        if isinstance(value,dict):
            return {k:clean(v) for k,v in value.items()
                    if k not in {'seconds','elapsed','elapsed_seconds','execution_seconds'}}
        if isinstance(value,list):return [clean(v) for v in value]
        return value
    canonical=json.dumps(clean(json.loads(path.read_text())),sort_keys=True,separators=(',',':'))
    return hashlib.sha256(canonical.encode()).hexdigest()

def parse_poly(expr,parameter_monomial):
    return {tuple(m)+tuple(parameter_monomial):Fraction(int(v.p),int(v.q))
            for m,v in s.Poly(s.sympify(expr,locals=dict(zip(map(str,X),X))),*X).terms() if v}

def add_into(out,poly,factor=1):
    for m,v in poly.items():
        out[m]+=factor*v

def multiply_derivative(left,right,j,maxdegree=MAXDEG):
    out=defaultdict(Fraction)
    for m,v in left.items():
        md=sum(m[5:])
        for n,w in right.items():
            if n[j] and md+sum(n[5:])<=maxdegree:
                k=list(a+b for a,b in zip(m,n));k[j]-=1
                out[tuple(k)]+=v*w*n[j]
    return {m:v for m,v in out.items() if v}

def monomials(n,d):
    return [tuple(z.count(i) for i in range(n))
            for z in combinations_with_replacement(range(n),d)]

def direct_euler(tensor,maxdegree):
    def entry(i,j):
        if i==j:return {}
        if i<j:return tensor.get((i,j),{})
        return {m:-v for m,v in tensor.get((j,i),{}).items()}
    euler={I:defaultdict(Fraction) for I in combinations(range(5),4)}
    for I in combinations(range(5),3):
        i,j,k=I;out=defaultdict(Fraction)
        for aa,bb,cc in [(i,j,k),(j,k,i),(k,i,j)]:
            for ell in range(5):
                add_into(out,multiply_derivative(entry(aa,ell),entry(bb,cc),ell,maxdegree))
        for ell in range(5):
            if ell in I:continue
            sign=(-1)**sum(j<ell for j in I);K=tuple(sorted((ell,)+I))
            for m,v in out.items():
                if v:
                    n=list(m);n[ell]+=1;euler[K][tuple(n)]+=sign*v
    return {I:{m:v for m,v in f.items() if v} for I,f in euler.items()}

def main():
    started=time.time()
    jet_path=SOURCE/'zero_jet_5.json'
    jet=json.loads(jet_path.read_text())
    tensor={(i,j):defaultdict(Fraction) for i,j in combinations(range(5),2)}
    t,x,y,z,w=X
    base={(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,
          (2,3):-z*z/2,(2,4):y*(x+2*z),(3,4):t*t+x*z+z*z}
    for I,f in base.items():add_into(tensor[I],parse_poly(f,(0,)*6))
    for degree,entries in jet['coefficients'].items():
        for parameter_monomial,P in entries:
            assert sum(parameter_monomial)==int(degree)
            for I,expression in P.items():
                add_into(tensor[ast.literal_eval(I)],parse_poly(expression,parameter_monomial))
    tensor={I:{m:v for m,v in f.items() if v} for I,f in tensor.items()}
    def entry(i,j):
        if i==j:return {}
        if i<j:return tensor[i,j]
        return {m:-v for m,v in tensor[j,i].items()}
    jac={}
    for i,j,k in combinations(range(5),3):
        out=defaultdict(Fraction)
        for aa,bb,cc in [(i,j,k),(j,k,i),(k,i,j)]:
            for ell in range(5):
                add_into(out,multiply_derivative(entry(aa,ell),entry(bb,cc),ell))
        jac[i,j,k]={m:v for m,v in out.items() if v}
    euler={I:defaultdict(Fraction) for I in combinations(range(5),4)}
    for I,f in jac.items():
        for ell in range(5):
            if ell in I:continue
            sign=(-1)**sum(j<ell for j in I)
            K=tuple(sorted((ell,)+I))
            for m,v in f.items():
                n=list(m);n[ell]+=1;euler[K][tuple(n)]+=sign*v
    xmons=monomials(5,4)
    rowkeys=[(I,m) for I in combinations(range(5),4) for m in xmons]
    ridx={key:i for i,key in enumerate(rowkeys)}
    keys=[tuple(m) for block in jet['residuals'] for m in block['monomials']]
    kidx={m:i for i,m in enumerate(keys)}
    M=s.zeros(350,len(keys));expected=s.zeros(350,len(keys))
    low_degree_nonzero=[]
    for I,f in euler.items():
        for m,v in f.items():
            if not v:continue
            parameter_degree=sum(m[5:])
            if parameter_degree<2:low_degree_nonzero.append((I,m,str(v)))
            else:M[ridx[I,m[:5]],kidx[m[5:]]]=s.Rational(v.numerator,v.denominator)
    assert not low_degree_nonzero
    offset=0
    for block in jet['residuals']:
        for row,col,value in block['entries']:expected[row,offset+col]=s.Rational(value)
        offset+=len(block['monomials'])
    assert M==expected,'Direct full Jacobi recomputation differs from cached residuals'
    # Independently derive the 98 invertible implicit equations from the full
    # 350 by 150 derivative.  No author-defined matrix is imported.
    base_tensor={I:parse_poly(f,(0,)*6) for I,f in base.items()}
    bivector_keys=[(I,m) for I in combinations(range(5),2) for m in monomials(5,2)]
    D=s.zeros(350,150)
    for col,(I,m) in enumerate(bivector_keys):
        trial={J:f.copy() for J,f in base_tensor.items()}
        trial.setdefault(I,{})[m+(1,0,0,0,0,0)]=Fraction(1)
        ee=direct_euler(trial,1)
        for K,f in ee.items():
            for n,value in f.items():
                if n[5:]==(1,0,0,0,0,0):
                    D[ridx[K,n[:5]],col]=s.Rational(value.numerator,value.denominator)
                else:assert not value
    _,wcols=DomainMatrix.from_Matrix(D).convert_to(s.QQ).rref()
    _,implicit_rows=DomainMatrix.from_Matrix(D[:,list(wcols)].T).convert_to(s.QQ).rref()
    assert len(wcols)==98 and len(implicit_rows)==98
    assert not any(M[list(implicit_rows),:])
    bivindex={key:i for i,key in enumerate(bivector_keys)}
    for I,f in tensor.items():
        for m,v in f.items():
            if sum(m[5:])>=2:assert bivindex[I,m[:5]] in wcols
    # Exact positive-weight polynomial slice: compare every coefficient to the
    # full implicit jet and then check the selected equations at all degrees.
    positive_path=HERE/'zero_positive_slice_reference.json'
    positive=json.loads(positive_path.read_text())
    positive_tensor={}
    for I,f in positive['weighted_polynomial_family'].items():
        expression=s.sympify(f,locals=dict(zip(map(str,X+U),X+U)))
        positive_tensor[ast.literal_eval(I)]={m:Fraction(int(v.p),int(v.q))
                                             for m,v in s.Poly(expression,*X,*U).terms() if v}
    restricted={I:{m:v for m,v in f.items() if m[8]==0 and m[9]==0} for I,f in tensor.items()}
    assert positive_tensor==restricted
    positive_euler=direct_euler(positive_tensor,6)
    for I,f in positive_euler.items():
        for m,value in f.items():
            if ridx[I,m[:5]] in implicit_rows:assert not value
    # The dimension witness concerns the initial term in degree four;
    # degree-five tails of that same linear combination are immaterial.
    keep=[i for i,m in enumerate(keys) if sum(m)<=4]
    M4=M[:,keep];keys4=[keys[i] for i in keep]
    a,b,p,c,d,q=U
    target_poly=s.Poly(c*(a+b)*(4*a+b)*(8*a+5*b),*U)
    target=s.Matrix([target_poly.coeff_monomial(m) for m in keys4])
    _,rows=DomainMatrix.from_Matrix(M4.T).convert_to(s.QQ).rref()
    W=M4[list(rows),:].T
    coeffs,parameters=W.gauss_jordan_solve(target)
    assert parameters.rows==0
    witness=[{'row':i,'quadruple':list(rowkeys[i][0]),'x_monomial':list(rowkeys[i][1]),
              'coefficient':str(v)} for i,v in zip(rows,coeffs) if v]
    assert sum((s.Rational(item['coefficient'])*M4[item['row'],:].T for item in witness),s.zeros(M4.cols,1))==target
    out={'input_mathematical_sha256':mathematical_hash(jet_path),
         'scope':'Full projective 350 Jacobi equations through total parameter degree 5; independent sparse arithmetic. Quartic certificate is checked modulo terms of degree at least 5.',
         'source_helper_imports':False,'direct_Jacobi_matches_all_cached_coefficients':True,
         'base_and_linear_Jacobi_zero':True,'raw_residual_rank_through_degree4':len(rows),
         'independent_full_derivative_rank':len(wcols),
         'implicit_rows':list(implicit_rows),
         'all_implicit_residual_rows_zero_through_degree5':True,
         'all_higher_lift_terms_in_selected_implicit_complement':True,
         'positive_reference_sha256':hashlib.sha256(positive_path.read_bytes()).hexdigest(),
         'positive_slice_equals_exact_full_slice_restriction':True,
         'positive_slice_selected_equations_identically_zero_all_degrees':True,
         'quartic':'c*(a+b)*(4*a+b)*(8*a+5*b)',
         'constant_linear_combination_of_full_residual_rows':witness,
         'identity_verified':True,'seconds':time.time()-started,'all_passed':True}
    tmp=HERE/'audit_zero_quartic.json.tmp';tmp.write_text(json.dumps(out,indent=2)+'\n')
    tmp.replace(HERE/'audit_zero_quartic.json')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()

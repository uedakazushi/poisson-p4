#!/usr/bin/env python3
"""Read-only verification of every v11 artifact and unchanged v10 files."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent.parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def main():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    expected=set(manifest['files'])
    # Historical manifest files are themselves preserved and listed.
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
            and p!=ROOT/'manifest.json'}
    assert actual==expected,{'missing':sorted(expected-actual),'extra':sorted(actual-expected)}
    for name,digest in manifest['files'].items():assert sha(ROOT/name)==digest,name
    old=json.loads((ROOT/'data/previous_v10_preservation.json').read_text())
    for name,digest in old['files'].items():
        assert sha(ROOT/'previous_v10'/name)==digest,name
    print(json.dumps({'all_passed':True,'verified_files':len(expected),
                      'previous_v10_files_unchanged':len(old['files'])},indent=2))
if __name__=='__main__':main()

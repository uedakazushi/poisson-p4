#!/usr/bin/env python3
"""Reproduce the complete v11 exact certificate suite in an isolated copy.

All mathematical JSON is compared. Only elapsed-time fields are ignored.
The source package and its preserved v10 tree are never modified.
"""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, time

ROOT=Path(__file__).resolve().parent.parent
TIMING={'seconds','elapsed','elapsed_seconds','execution_seconds'}
def mathematical(obj):
    if isinstance(obj,dict):
        return {k:mathematical(v) for k,v in obj.items() if k not in TIMING}
    if isinstance(obj,list): return [mathematical(v) for v in obj]
    return obj

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    jobs=[
      ('full_six_variable_jets','zero_jets/zero_full_jet.py',['6'],
       [f'zero_jets/zero_{kind}_{d}.json' for d in range(2,7) for kind in ['jet','initial']]),
      ('homogeneous_algebra','zero_jets/zero_initial_algebra.py',[],['zero_jets/zero_initial_algebra.json']),
      ('eight_primary_pieces','zero_jets/zero_primary_explore.py',[],['zero_jets/zero_primary_explore.json']),
      ('axis_free_module','zero_jets/zero_axis_module.py',[],['zero_jets/zero_axis_module.json']),
      ('actual_families_and_base_changes','geometry/zero_magnetic_confluence.py',[],['geometry/zero_magnetic_confluence.json']),
      ('independent_full_jacobi','independent/audit_zero_quartic.py',[],['independent/audit_zero_quartic.json']),
      ('independent_initial_algebra','independent/audit_zero_algebra.py',[],['independent/audit_zero_algebra.json']),
    ]
    start=time.time();reports=[]
    with tempfile.TemporaryDirectory(prefix='p4_v11_reproduce_') as tmp:
        code=Path(tmp)/'code'
        shutil.copytree(ROOT/'code',code,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
        for name,script,argv,files in jobs:
            tick=time.time()
            proc=subprocess.run([sys.executable,str(code/script),*argv],cwd=code,env=env,
                                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            (out/f'{name}.log').write_text(proc.stdout)
            if proc.returncode:
                raise RuntimeError(f'{name}: exit {proc.returncode}; see {out/name}.log')
            comparisons=[]
            for rel in files:
                expected=json.loads((ROOT/'code'/rel).read_text())
                obtained=json.loads((code/rel).read_text())
                if mathematical(expected)!=mathematical(obtained):
                    mismatch=out/(name+'_mismatch.json')
                    mismatch.write_text(json.dumps({'file':rel,'expected':mathematical(expected),
                        'obtained':mathematical(obtained)},indent=2)+'\n')
                    raise AssertionError(f'Mathematical JSON differs: {rel}; see {mismatch}')
                dest=out/'outputs'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(code/rel,dest)
                comparisons.append({'file':rel,'mathematical_json_equal':True})
            report={'name':name,'script':script,'returncode':0,'passed':True,
                    'comparisons':comparisons,'seconds':time.time()-tick}
            reports.append(report)
            print(name,'PASS',round(report['seconds'],3),flush=True)
    result={'all_passed':True,'checks':reports,'count':len(reports),
            'seconds':time.time()-start,'python':sys.version,
            'source_code_sha256':{str(p.relative_to(ROOT/'code')):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in sorted((ROOT/'code').rglob('*.py'))}}
    target=out/'verification_summary.json';temp=target.with_suffix('.tmp')
    temp.write_text(json.dumps(result,indent=2)+'\n');temp.replace(target)
    print('ALL',len(reports),'CHECKS PASSED',round(result['seconds'],3),flush=True)

if __name__=='__main__':main()

"""Certify the final embedded-axis module in the initial-ideal calculation."""
from zero_initial_algebra import *
from full_kuranishi import rref

def main():
    start=time.time();J=read_j();G=s.groebner(J,*vs,domain=s.QQ,order='grevlex')
    ref=json.loads((HERE/'zero_primary_explore.json').read_text())
    H=[s.sympify(f,locals={str(v):v for v in vs}) for f in ref['intersection_generators']]
    l=a+b
    basis=[d*p,d*q,d*l*(32*a*a-32*a*b-25*b*b)/32,b*d*l*(2*a+b)/2,b**3*d*l]
    basis=[s.expand(G.reduce(f)[1]) for f in basis]
    degrees=[s.Poly(f,*vs).total_degree() for f in basis]
    # All chosen representatives are Groebner-normal and homogeneous of
    # d-degree one.  Every leading monomial of J5 has d-degree at most one.
    # Therefore multiplying these representatives by arbitrary d-powers
    # cannot introduce a new divisible leading monomial: they stay normal.
    assert all(poly.LM(order=G.order).exponents[4]<=1 for poly in G.polys)
    assert all(set(m[4] for m,coeff in s.Poly(f,*vs).terms())=={1} for f in basis)
    # A graded C[d]-linear relation between basis elements is impossible:
    # their total degrees in (a,b,p,c,q) differ except for pairs, where the
    # respective normal forms are linearly independent.
    fiber_vars=(a,b,p,c,q)
    abdegrees=[set(sum(m[i] for i in [0,1,2,3,5]) for m,coeff in s.Poly(f,*vs).terms()) for f in basis]
    assert abdegrees==[{1},{1},{3},{3},{4}]
    for inds in [[0,1],[2,3],[4]]:
        pols=[s.expand(basis[i]/d) for i in inds]
        keys=sorted(set(m for f in pols for m,co in s.Poly(f,*fiber_vars).terms()))
        M=s.Matrix([[s.Poly(f,*fiber_vars).coeff_monomial(s.prod(v**e for v,e in zip(fiber_vars,m))) for f in pols] for m in keys])
        assert len(rref(M)[1])==len(inds)
    def coordinates(f,degree):
        f=s.expand(G.reduce(f)[1]);valid=[i for i,e in enumerate(degrees) if e<=degree]
        forms=[s.expand(d**(degree-degrees[i])*basis[i]) for i in valid]
        keys=sorted(set(m for g in forms+[f] for m,co in s.Poly(g,*vs).terms()))
        M=s.Matrix([[s.Poly(g,*vs).coeff_monomial(s.prod(v**e for v,e in zip(vs,m))) for g in forms] for m in keys])
        rhs=s.Matrix([s.Poly(f,*vs).coeff_monomial(s.prod(v**e for v,e in zip(vs,m))) for m in keys])
        sol,pars=M.gauss_jordan_solve(rhs);assert pars.rows==0
        ans=s.zeros(5,1)
        for i,coeff in zip(valid,sol):ans[i]=coeff*d**(degree-degrees[i])
        assert s.expand(sum(ans[i]*basis[i] for i in range(5))-f)==0
        return ans
    for f in H:
        coordinates(f,s.Poly(f,*vs).total_degree())
    actions={}
    for v in vs:
        action=s.Matrix.hstack(*[coordinates(v*f,degrees[i]+1) for i,f in enumerate(basis)])
        actions[str(v)]=[[str(x) for x in row] for row in action.tolist()]
        if v!=d:
            assert action**5==s.zeros(5)
        else:assert action==d*s.eye(5)
        print('ACTION',v,action,flush=True)
    out={'scope':'Module H/J5 in the homogeneous finite-jet initial subideal; not automatically a module of the full completed local ring.',
         'basis_over_QQ_d':[str(s.factor(f)) for f in basis],'basis_degrees':degrees,
         'free_rank_over_QQ_d':5,'radical_annihilator':'(a,b,p,c,q)',
         'all_initial_monomials_have_d_degree_at_most_one':True,
         'basis_normal_forms_have_d_degree_exactly_one':True,
         'multiplication_actions':actions,'no_finite_length_submodule':True,
         'all_passed':True,'seconds':time.time()-start}
    dest=HERE/'zero_axis_module.json';tmp=dest.with_suffix('.json.tmp');tmp.write_text(json.dumps(out,indent=2)+'\n');tmp.replace(dest)
    print('DONE',time.time()-start,flush=True)

if __name__=='__main__':main()

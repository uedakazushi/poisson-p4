"""Exact algebra of the homogeneous initial ideal certified through order five.

This is NOT an identification of the full associated graded local ring.
Generic lengths are computed over rational-function fields, not from samples.
"""
from pathlib import Path
from itertools import product
import json, time
import sympy as s
HERE=Path(__file__).resolve().parent
a,b,p,c,d,q=s.symbols('a b p c d q'); vs=(a,b,p,c,d,q)

def read_j():
    data=json.loads((HERE/'zero_initial_5.json').read_text())
    return [s.sympify(f,locals={str(v):v for v in vs}) for f in data['initial_ideal_through_degree_groebner']]

def divides(m,n):return all(a<=b for a,b in zip(m,n))

def minimal_mons(mons):
    out=[]
    for m in sorted(set(mons),key=lambda m:(sum(m),m)):
        if not any(divides(x,m) for x in out):out.append(m)
    return out

def numerator(lm,nvars):
    lcms={(0,)*nvars:1}
    for m in lm:
        change={}
        for k,v in lcms.items():
            l=tuple(max(a,b) for a,b in zip(k,m))
            change[l]=change.get(l,0)-v
        for k,v in change.items():
            lcms[k]=lcms.get(k,0)+v
            if not lcms[k]:del lcms[k]
    co={}
    for m,v in lcms.items():co[sum(m)]=co.get(sum(m),0)+v
    return {d:v for d,v in co.items() if v}

def generic_length(gens,name,sub,localvars,fieldvars,unit=1):
    ff=s.QQ.frac_field(*fieldvars)
    raw=[s.expand(f.subs(sub,simultaneous=True)) for f in gens]
    unit=s.sympify(unit).subs(sub,simultaneous=True)
    assert unit.subs(dict.fromkeys(localvars,0))!=0
    if unit!=1:
        z=s.Symbol('_saturation')
        sat=s.groebner(raw+[1-z*unit],z,*localvars,domain=ff,order='lex')
        raw=[f.as_expr() for f in sat.polys if not f.as_expr().has(z)]
    gg=s.groebner(raw,*localvars,domain=ff,order='grevlex')
    lm=minimal_mons([tuple(f.LM(order=gg.order).exponents) for f in gg.polys])
    bounds=[]
    for i in range(len(localvars)):
        pure=[m[i] for m in lm if m[i] and sum(m)==m[i]]
        assert pure,(name,lm,i)
        bounds.append(min(pure))
    standard=[m for m in product(*[range(v) for v in bounds]) if not any(divides(g,m) for g in lm)]
    return {'prime':name,'field_variables':list(map(str,fieldvars)),'local_variables':list(map(str,localvars)),
            'substitution':{str(k):str(v) for k,v in sub.items()},'inverted_unit':str(s.factor(unit)),
            'generic_length':len(standard),'standard_monomials':[str(s.prod(x**e for x,e in zip(localvars,m))) for m in standard],
            'groebner_basis':[str(s.factor(f.as_expr())) for f in gg.polys]}

def main():
    start=time.time();J=read_j();G=s.groebner(J,*vs,order='grevlex')
    lm=minimal_mons([tuple(f.LM(order=G.order).exponents) for f in G.polys])
    coeff=numerator(lm,6);t=s.Symbol('t');num=sum(v*t**d for d,v in coeff.items());HS=s.cancel(num/(1-t)**6)
    print('HS',s.factor(HS),flush=True)
    hf=[int(s.expand(s.series(HS,t,0,16).removeO()).coeff(t,i)) for i in range(16)]
    # First four positive-coordinate primes, then the two other I2 branches.
    v,w=s.symbols('v w')
    cases=[
        ('(p,q,a+b)',{a:v-b},(v,p,q),(b,c,d),1),
        ('(p,q,c,d)',{},(p,q,c,d),(a,b),1),
        ('(p,q,d,4*a+b)',{a:(v-b)/4},(v,p,q,d),(b,c),(a+b)*(8*a+5*b)),
        ('(p,q,d,8*a+5*b)',{a:(v-5*b)/8},(v,p,q,d),(b,c),(a+b)*(4*a+b)),
        ('(c,d,p,a+b)',{a:v-b},(v,p,c,d),(b,q),3*p+q),
        ('(c,d,q+3*p,a-2*b)',{a:v+2*b,q:w-3*p},(v,w,c,d),(b,p),1),
    ]
    reports=[]
    for name,sub,loc,field,unit in cases:
        rec=generic_length(J,name,sub,loc,field,unit);reports.append(rec)
        print('LENGTH',name,rec['generic_length'],rec['groebner_basis'],flush=True)
    # Generic point of the magnetic embedded plane (a,b,p,q), with c,d
    # independent units: the excess over the smooth branch l=a+b=0 has
    # length four.  This is an embedded-module length, not the length of
    # an arbitrarily chosen primary component.
    Fcd=s.QQ.frac_field(c,d)
    magnetic=s.groebner(J,a,b,p,q,domain=Fcd,order='grevlex')
    magnetic_expected=[p,q,(a+b)*(32*a*a-9*b*b),(a+b)*(2*a*b+b*b)]
    magnetic_gb=s.groebner(magnetic_expected,a,b,p,q,domain=Fcd,order='grevlex')
    assert all(magnetic.reduce(f)[1]==0 for f in magnetic_expected)
    assert all(magnetic_gb.reduce(f)[1]==0 for f in J)
    K=s.groebner([32*a*a-9*b*b,2*a*b+b*b],a,b,domain=s.QQ,order='grevlex')
    KLM=[tuple(f.LM(order=K.order).exponents) for f in K.polys]
    Kstd=[m for m in product(range(4),repeat=2) if not any(divides(g,m) for g in KLM)]
    assert len(Kstd)==4
    magnetic_report={'field_variables':['c','d'],'local_variables':['a','b','p','q'],
       'generic_ideal':[str(f) for f in magnetic_expected],
       'excess_module':'(l)/(l*K), l=a+b; isomorphic to QQ(c,d)[a,b]/K',
       'K_generators':['32*a**2-9*b**2','2*a*b+b**2'],
       'K_standard_monomials':[str(a**i*b**j) for i,j in Kstd],
       'embedded_excess_length':4}
    # A smaller exact generating set: remove redundancy by testing membership.
    small=[]
    for f in sorted(J,key=lambda f:s.Poly(f,*vs).total_degree()):
        if small and s.groebner(small,*vs,order='grevlex').reduce(f)[1]==0:continue
        small.append(f)
    assert all(s.groebner(small,*vs,order='grevlex').reduce(f)[1]==0 for f in J)
    # Also choose explicit factored generators more suitable for the paper.
    nice=[(14*a-b)*p+3*(a+b)*q,p*(3*p+q),c*p,c*q,
          b*d*p,a*d*q,b*d*q,d*p*q,d*q*q,
          c*(a+b)*(4*a+b)*(8*a+5*b),
          d*(a+b)*(11776*a**3-11776*a*a*b+11776*a*b*b+21333*b**3),
          b*d*(a+b)*(184*a*a-184*a*b-233*b*b),
          b*b*d*(a+b)*(184*a+127*b),
          b*c*d*(a+b)*(2*a+b)]
    GN=s.groebner(nice,*vs,order='grevlex',domain=s.QQ)
    assert all(G.reduce(f)[1]==0 for f in nice)
    assert all(GN.reduce(f)[1]==0 for f in J)
    out={'scope':'Homogeneous subideal J5 of the true initial ideal, certified by exact full jets to order5; no all-order equality assertion.',
         'variables':list(map(str,vs)),'minimal_monomial_initial_generators':[list(m) for m in lm],
         'Hilbert_numerator_over_1_minus_t_power_6':str(s.expand(num)),
         'Hilbert_series':str(s.factor(HS)),'Hilbert_function_0_to_15':hf,
         'generic_lengths':reports,'smaller_exact_generators':[str(s.factor(f)) for f in small],
         'generic_magnetic_embedded_module':magnetic_report,
         'nice_exact_generators':[str(s.factor(f)) for f in nice],
         'all_passed':True,'seconds':time.time()-start}
    dest=HERE/'zero_initial_algebra.json';tmp=dest.with_suffix('.json.tmp');tmp.write_text(json.dumps(out,indent=2)+'\n');tmp.replace(dest)
    print('DONE',time.time()-start,flush=True)

if __name__=='__main__':main()

"""Exact full six-variable Kuranishi jets at the zero magnetic Poisson tensor.

The ambient projective Jacobi criterion is E wedge [P,P]=0 (350 equations).
No torus invariant or affine-Jacobi restriction is imposed.  Orbit21 and
Euler/scalar25 directions have been split by actual symmetries.  This script
records finite jets only; higher initial equations give valid local upper bounds.
"""
from pathlib import Path
from itertools import combinations_with_replacement
import ast, hashlib, json, sys, time
import sympy as s
from exact_calculus import Calculus
from full_kuranishi import Slice, rref

HERE=Path(__file__).resolve().parent

def setup():
    C=Calculus(5); C.x=s.symbols('t x y z w'); t,x,y,z,w=C.x
    P=C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,
                (2,3):-z*z/2,(2,4):y*(x+2*z),(3,4):t*t+x*z+z*z})
    sl=Slice(C,P); sl.u=s.symbols('a b p c d q')
    ref=json.loads((HERE/'u1_zero_magnetic_reference.json').read_text())
    assert [C.encode(R) for R in sl.R]==ref['full_slice_basis']
    assert sl.group_rank==46 and len(sl.R)==6 and len(sl.wcols)==98
    return sl

def mon(n,d):
    return [tuple(v.count(i) for i in range(n)) for v in combinations_with_replacement(range(n),d)]

def expr(coeffs,keys,variables):
    return s.expand(sum(c*s.prod(u**a for u,a in zip(variables,m)) for c,m in zip(coeffs,keys) if c))

def atomic_json(path,value):
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)

def full_closure(mats,keys,maxdegree):
    M=s.Matrix.hstack(*mats)
    R,piv=rref(M);basis=R[:len(piv),:]
    idx={m:i for i,m in enumerate(keys)}
    multi=[m for d in range(maxdegree-1) for m in mon(6,d)]
    rows=[]
    for row in basis.tolist():
        nz=[(keys[i],v) for i,v in enumerate(row) if v]
        for mm in multi:
            new={}
            for k,val in nz:
                e=tuple(a+b for a,b in zip(k,mm))
                if sum(e)<=maxdegree:new[idx[e]]=val
            if new:rows.append(new)
    N=s.MutableSparseMatrix(len(rows),len(keys),{(i,j):v for i,row in enumerate(rows) for j,v in row.items()})
    R,piv=rref(N)
    return R[:len(piv),:],piv,basis

def main():
    start=time.time();maxdegree=int(sys.argv[1]) if len(sys.argv)>1 else 4
    sl=setup();entries=[];print('SETUP',time.time()-start,flush=True)
    for d in range(2,maxdegree+1):
        M=sl.solve_order(d)
        entries.append({'degree':d,'monomials':[list(m) for m in sl.monomials(d)],
                        'entries':[[i,j,str(v)] for (i,j),v in M.todok().items() if v]})
        cache={'degree':d,'rows':350,'variables':list(map(str,sl.u)),
            'weights':[1,1,2,-1,-1,2],'source_sha256':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in ['exact_calculus.py','full_kuranishi.py','u1_zero_magnetic_reference.json']},
            'residuals':entries,'coefficients':{str(j):[[list(m),sl.C.encode(P)] for m,P in sl.coefficients[j].items() if P] for j in range(1,d+1)},
            'seconds':time.time()-start}
        atomic_json(HERE/f'zero_jet_{d}.json',cache)
        print('SAVED_JET',d,'nonzero',len(entries[-1]['entries']),'seconds',time.time()-start,flush=True)
        keys=[m for j in range(2,d+1) for m in sl.monomials(j)]
        R,piv,raw=full_closure([sl.residuals[j] for j in range(2,d+1)],keys,d)
        initial=[]
        for i,pv in enumerate(piv):
            degree=sum(keys[pv]);f=expr([R[i,j] if sum(k)==degree else 0 for j,k in enumerate(keys)],keys,sl.u)
            initial.append(f)
        gb=s.groebner(initial,*sl.u,order='grevlex')
        polys=[s.factor(g.as_expr()) for g in gb.polys]
        modpq=[s.factor(f.subs({sl.u[2]:0,sl.u[5]:0})) for f in polys]
        modpq=[f for f in modpq if f]
        out={'maxdegree':d,'variables':list(map(str,sl.u)),'full_space_D_rank':98,'orbit_rank':21,
             'truncated_ideal_vector_space_dimension':len(piv),
             'Hilbert_function':[1,6]+[len(mon(6,j))-sum(sum(keys[p])==j for p in piv) for j in range(2,d+1)],
             'initial_ideal_through_degree_groebner':[str(f) for f in polys],
             'relations_mod_p_q':[str(f) for f in modpq],
             'raw_residual_generators':[str(s.factor(expr(raw.row(i),keys,sl.u))) for i in range(raw.rows)],
             'seconds':time.time()-start}
        atomic_json(HERE/f'zero_initial_{d}.json',out)
        print('INITIAL',d,out['Hilbert_function'],'mod_pq',out['relations_mod_p_q'],'GB',[str(f) for f in polys],time.time()-start,flush=True)

if __name__=='__main__':main()

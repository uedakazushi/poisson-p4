"""Certify an exact eight-piece homogeneous primary decomposition of J5.

The equality is explicitly checked by two-way ideal membership.
This is an algebra calculation for J5; full associated-graded equality
requires the separate all-orders comparison argument.
"""
from zero_initial_algebra import *
from itertools import combinations_with_replacement

def intersection(I,J):
    z=s.Symbol('_intersection')
    G=s.groebner([z*f for f in I]+[(1-z)*f for f in J],z,*vs,domain=s.QQ,order='lex')
    out=[f.as_expr() for f in G.polys if not f.as_expr().has(z)]
    return [f.as_expr() for f in s.groebner(out,*vs,domain=s.QQ,order='grevlex').polys]

def main():
    start=time.time();J=read_j();G=s.groebner(J,*vs,domain=s.QQ,order='grevlex')
    l=a+b;F=(14*a-b)*p+3*l*q
    pieces=[
        [p,q,l],
        [p*p,p*q,q*q,F,c,d],
        [p,q,d,4*a+b],
        [p,q,d,8*a+5*b],
        [c,d,p,l],
        [c,d,q+3*p,a-2*b],
        [p,q,l*(32*a*a-9*b*b),l*(2*a*b+b*b),a**4,a**3*b,a*a*b*b,a*b**3,b**4],
    ]
    current=pieces[0]
    for i,Q in enumerate(pieces):
        GQ=s.groebner(Q,*vs,domain=s.QQ,order='grevlex')
        assert all(GQ.reduce(f)[1]==0 for f in J)
        if i:current=intersection(current,Q)
        print('intersection',i,len(current),'sec',time.time()-start,flush=True)
    remainders=[s.factor(G.reduce(f)[1]) for f in current if G.reduce(f)[1]!=0]
    H=s.groebner(current,*vs,domain=s.QQ,order='grevlex')
    assert all(H.reduce(f)[1]==0 for f in J)
    print('extra',len(remainders),list(map(str,remainders)),flush=True)
    lm=minimal_mons([tuple(f.LM(order=H.order).exponents) for f in H.polys]);t=s.Symbol('t')
    HS=s.cancel(sum(v*t**d for d,v in numerator(lm,6).items())/(1-t)**6)
    print('HS intersection',s.factor(HS),flush=True)
    axisvars=(a,b,p,c,q)
    axis_power=[s.prod(z for z in ids) for ids in combinations_with_replacement(axisvars,5)]
    axisgens=[s.expand(f.subs(d,1)) for f in J]+axis_power
    Gaxis=s.groebner(axisgens,*axisvars,domain=s.QQ,order='grevlex')
    Qaxis=[f.as_expr() for f in Gaxis.polys]
    full=intersection(current,Qaxis)
    Gfull=s.groebner(full,*vs,domain=s.QQ,order='grevlex')
    equality=all(G.reduce(f)[1]==0 for f in full) and all(Gfull.reduce(f)[1]==0 for f in J)
    assert equality
    print('FULL_PRIMARY_EQUALITY',equality,'axisGB',[str(s.factor(f)) for f in Qaxis],flush=True)
    out={'scope':'Exact eight-piece primary intersection for J5. The field equal compares only the first seven pieces; full_eight_piece_intersection_equals_J5 is the full decomposition certificate. Full associated-graded equality is a separate theorem.',
        'pieces':[[str(s.factor(f)) for f in Q] for Q in pieces],
        'intersection_generators':[str(s.factor(f)) for f in current],
        'remainders_mod_J5':[str(f) for f in remainders],
        'equal':not remainders,'intersection_Hilbert_series':str(s.factor(HS)),
        'axis_primary_ideal': [str(s.factor(f)) for f in Qaxis],
        'axis_primary_radical':'(a,b,p,c,q)',
        'axis_primary_contains_fifth_power':True,
        'full_eight_piece_intersection_equals_J5':equality,
        'seconds':time.time()-start}
    dest=HERE/'zero_primary_explore.json';tmp=dest.with_suffix('.json.tmp');tmp.write_text(json.dumps(out,indent=2)+'\n');tmp.replace(dest)

if __name__=='__main__':main()

"""Exact T18 confluence to the special U1 magnetic point.

All polynomial identities, tangent ranks, and the normal class are checked
over QQ. The auxiliary sqrt(2) cancels after reparameterization.
"""
from pathlib import Path
import sys,json,ast
HERE=Path(__file__).resolve().parent
from exact_calculus import *
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
h=s.symbols('h');e=s.symbols('e');rt=s.sqrt(2);aa=x/2+z
U=z+t/(2*rt)+e*y;V=z-t/(2*rt)-e*y
A=aa+rt*t+e*w;B=aa-rt*t-e*w
L=s.Matrix([t,U,A,V,B]).jacobian(C.x);Li=L.inv()
c=e;a=e/2-e**2/(4*rt);k=-1/(2*rt)
M=s.zeros(5)
M[1,2]=a*U*A+c*k*B*t;M[3,4]=-a*V*B+c*k*A*t
M[1,3]=c*(U*V+k*k*t*t)
M[1,4]=(a-c)*U*B;M[2,3]=(a-c)*A*V;M[2,4]=(c-a)*A*B
M=M-M.T;Pold=(Li*M*Li.T).applyfunc(s.expand)
new=s.Matrix([t,x,-y,z,4*w+2*y-2*z]);NN=new.jacobian(C.x)
sub={y:-y,w:(w+2*y+2*z)/4,e:rt*h}
P=(NN*Pold*NN.T).subs(sub,simultaneous=True).applyfunc(s.expand)
assert all(f.is_polynomial(*C.x,h) and not f.has(rt) for f in P)
C.pol=lambda f:{m:s.expand(v) for m,v in s.Poly(s.expand(f),*C.x).terms() if v!=0}
PP=C.tensor({I:P[I] for I in C.pairs})
assert all(s.expand(f)==0 for f in C.cubic_vector(C.jacobi(PP)))
P0=C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,(2,3):-z*z/2,
 (2,4):t*z+z*z+y*(x+2*z),(3,4):t*t+x*z+z*z})
assert P.subs(h,0)==C.as_matrix(P0)
F1=s.expand((U*A+k*t*B).subs(sub,simultaneous=True));F2=s.expand((V*B-k*t*A).subs(sub,simultaneous=True))
pf=s.expand(P[1,2]*P[3,4]-P[1,3]*P[2,4]+P[1,4]*P[2,3]);ratio=s.factor(s.cancel(pf/(F1*F2)))
assert not any(ratio.has(v) for v in C.x)
ref=json.loads((HERE/'small_points.json').read_text())[1]
normal=[C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals={f'x{i}':C.x[i] for i in range(5)}) for I,f in q.items()}) for q in ref['normals']]
out={'scope':'An actual one-parameter family in the already catalogued T18 component; no new global component count.',
 'polynomial_rational_family':True,'affine_Jacobi_zero':True,'source_U1_verified':True,'family':C.encode(PP),
 'quadrics':[str(s.factor(F1)),str(s.factor(F2))],'Pfaffian_factor':str(ratio),'points':{}}
def rr(M):return DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1]
def cert(M):
 col=list(rr(M));AA=M[:,col];row=list(rr(AA.T));de=DomainMatrix.from_Matrix(AA[row,:]).convert_to(s.QQ).det()
 return {'rank':len(col),'rows':row,'columns':col,'determinant':str(de)}
for v in [0,1,-1]:
 T=C.tensor({I:P[I].subs(h,v) for I in C.pairs});D=C.derivative(T,True)
 G=[C.vertical(i,j) for i in range(5) for j in range(5)]+[T]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=C.x[j];G.append(C.lie(T,X))
 GM=s.Matrix.hstack(*map(C.vector,G));Tdot=C.tensor({I:s.diff(P[I],h).subs(h,v) for I in C.pairs});Fam=GM.row_join(C.vector(Tdot))
 assert not any(D*Fam)
 info={'full_Jacobi_rank':rank(D),'projective_tangent_dimension':125-rank(D),
       'projective_orbit_dimension':rank(GM)-25,'actual_family_dimension':rank(Fam)-25,
       'Jacobi_minor':cert(D),'family_minor':cert(Fam)}
 if v==0:
  mag=[C.tensor({(2,4):f}) for f in [t*t,t*x,t*z,x*x,x*z,z*z]]
  MM=GM.row_join(s.Matrix.hstack(*map(C.vector,mag)));MM=MM[:,list(rr(MM))]
  KK=MM.row_join(s.Matrix.hstack(*map(C.vector,normal)));sol,pars=KK.gauss_jordan_solve(C.vector(Tdot));assert not pars.rows
  info['normal_coordinates']=list(map(str,sol[-2:,:]));assert sol[-2]+256*sol[-1]==0 and sol[-1]!=0
 else:
  info['quadric_ranks']=[len(DomainMatrix.from_Matrix(s.hessian(f.subs(h,v),C.x)).convert_to(s.QQ.algebraic_field(rt)).rref()[1]) for f in [F1,F2]]
  assert info['quadric_ranks']==[4,4]
  assert info['full_Jacobi_rank']==102 and info['actual_family_dimension']==23
 print(v,info,flush=True);out['points'][str(v)]=info
out['all_passed']=True
(HERE/'t18_confluence_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print('PASS',flush=True)

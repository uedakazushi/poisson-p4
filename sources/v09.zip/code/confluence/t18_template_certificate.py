"""Universal T18 normal form and its two exact toric smoothing edges."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
from exact_calculus import *
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t U A V B');t,U,A,V,B=C.x
a,c,p,q=s.symbols('a c p q')
C.pol=lambda f:{m:s.factor(x) for m,x in s.Poly(s.expand(f),*C.x).terms() if x}
P=C.tensor({(1,2):a*U*A+p*B*t,(3,4):-a*V*B+q*A*t,
 (1,3):c*U*V+p*q*t*t/c,(1,4):(a-c)*U*B,
 (2,3):(a-c)*A*V,(2,4):(c-a)*A*B})
assert all(s.cancel(f)==0 for f in C.cubic_vector(C.jacobi(P)))
M=C.as_matrix(P);pf=s.expand(M[1,2]*M[3,4]-M[1,3]*M[2,4]+M[1,4]*M[2,3])
Q1=U*A+p*B*t/c;Q2=V*B-q*A*t/c
assert s.cancel(pf+a*c*Q1*Q2)==0
log=s.Matrix([[0,a,c,a-c],[-a,0,a-c,c-a],[-c,c-a,0,-a],[c-a,a-c,a,0]])
om=log.inv();res=s.zeros(5)
res[1:5,1:5]=om
for i in range(1,5):res[0,i]=sum(om[i-1,j] for j in range(4));res[i,0]=-res[0,i]
assert (res*s.ones(5,1)).applyfunc(s.cancel)==s.zeros(5,1)
edges=[]
for i,j in C.pairs:
 if s.cancel(res[i,j])==0:continue
 outsiders=[k for k in range(5) if k not in [i,j]]
 theta=[s.cancel((res[j,k]+res[k,i])/res[i,j]) for k in outsiders]
 if all(x.is_Integer and x>=0 for x in theta):
  edges.append({'edge':[i,j],'orders':{str(k):int(x) for k,x in zip(outsiders,theta)}})
assert edges==[{'edge':[1,2],'orders':{'0':1,'3':0,'4':1}}, {'edge':[3,4],'orders':{'0':1,'1':0,'2':1}}]
out={'all_passed':True,'universal_affine_Jacobi_zero':True,'Poisson':C.encode(P),
 'Pfaffian':'-a*c*(U*A+p*B*t/c)*(V*B-q*A*t/c)',
 'generic_quadric_ranks':[4,4],'biresidue_matrix':[[str(s.factor(x)) for x in res.row(i)] for i in range(5)],
 'generic_smoothable_edges':edges,'catalogue_id':'T18',
 'catalogue_permutation_old_to_current':[1,2,3,4,0]}
(HERE/'t18_template_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

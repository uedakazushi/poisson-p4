"""Exact algebra of the v9 local model; geometry is justified in the proof."""
from pathlib import Path
import json
import sympy as s
HERE=Path(__file__).resolve().parent
a,r,v,z=s.symbols('a r v elimination')
variables=(a,r,v)
F=r*r-v*v;G=v*(3*r-v)
I=[v*F,a*v*G];K=[F,G]
def gb(q,vars=variables):return s.groebner(q,*vars,order='lex')
def equal(A,B):
 AA=gb(A);BB=gb(B)
 return all(BB.reduce(f)[1]==0 for f in A) and all(AA.reduce(f)[1]==0 for f in B)
def intersection(A,B):
 GG=gb([z*f for f in A]+[(1-z)*g for g in B],(z,)+variables)
 return [q.as_expr() for q in GG.polys if not q.as_expr().has(z)]
def colon(A,g):
 E=intersection(A,[g]);Q=[s.cancel(f/g) for f in E]
 assert all(q.is_polynomial(*variables) for q in Q)
 return Q
radical=[v*F,a*v]
primes=[[v],[a,r-v],[a,r+v]]
meet=intersection(intersection(primes[0],primes[1]),primes[2])
assert equal(radical,meet)
assert equal(colon(I,a*v),K)
assert gb(I).reduce((a*v)**4)[1]==0
assert gb(I).reduce((a*v)**3)[1]!=0
J=[F,a*G]
assert equal(J,intersection(intersection([a,r-v],[a,r+v]),K))
assert equal(colon(I,v),J)
# K is (r,v)-primary and free of rank4 over C[[a]].
KG=s.groebner(K,r,v,order='grlex');mons=[s.S.One,r,v,v*v]
for mon in [r**3,r*r*v,r*v*v,v**3]:assert KG.reduce(mon)[1]==0
red=[KG.reduce(m)[1] for m in mons]
matrix=s.Matrix([[s.Poly(f,r,v).coeff_monomial(m) for f in red] for m in mons])
assert matrix.det()!=0
assert s.expand(KG.reduce(r*r-v*v)[1])==0
assert s.expand(KG.reduce(3*r*v-v*v)[1])==0
Q=[r**3,v*F,v*G]
assert equal(I,intersection(intersection(intersection([v],[a,r-v]),[a,r+v]),Q))
# Embedded Q is primary: its quotient is free over a and finite in r,v.
QG=s.groebner(Q,r,v,order='grlex')
assert QG.reduce(r**3)[1]==QG.reduce(v**4)[1]==0
out={'all_passed':True,
 'local_model':['v*(r^2-v^2)','a*v^2*(3*r-v)'],
 'minimal_primes':[['v'],['a','r-v'],['a','r+v']],
 'embedded_associated_prime':['r','v'],
 'reduced_ideal':['v*(r^2-v^2)','a*v'],
 'nilradical_generator':'a*v','nilradical_annihilator':['r^2-v^2','v*(3*r-v)'],
 'nilradical_power_zero':4,'nilradical_power_nonzero':3,
 'torsion_module_basis_over_C_a':['a*v','a*r*v','a*v^2','a*v^3'],
 'torsion_module_rank':4,'colon_v_complete_intersection':['r^2-v^2','a*v*(3*r-v)'],
 'colon_v_multiplicity':6,'multiplicity_decomposition':[4,1,1],
 'primary_decomposition_verified':[['v'],['a','r-v'],['a','r+v'],['r^3','v*(r^2-v^2)','v^2*(3*r-v)']],
 'source_smooth_factor_dimension':22,'component_dimensions':[24,23,23],
 'embedded_support_dimension':23,'source_tangent_dimension':25,
 'scope':'This checks algebra of the displayed normal form. The identification with the full Poisson completed local ring additionally uses the universal obstruction and actual-branch proof.'}
(HERE/'special_local_algebra.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

#!/usr/bin/env python3
"""Reproduce the v9 exact-arithmetic certificates in dependency order.

The scripts intentionally regenerate their JSON certificates beside their source
files. This runner writes captured logs and its summary under --output-dir.
No shell is used, and no source from previous_v8 is imported by this runner.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time


CODE = Path(__file__).resolve().parent
ROOT = CODE.parent

# (identifier, script relative to code/, arguments, prerequisite identifiers)
CHECKS = (
    ("universal_kernel", "formal/universal_kernel.py", ("1",), ()),
    ("universal_cubic", "formal/universal_cubic.py", (), ("universal_kernel",)),
    ("generic_embedded_structure", "formal/certify_generic_embedded_structure.py", (),
     ("universal_kernel", "universal_cubic")),
    ("special_local_algebra_formal", "formal/verify_special_local_algebra.py", (), ()),
    ("t18_template", "confluence/t18_template_certificate.py", (), ()),
    ("t18_confluence", "confluence/t18_confluence_certificate.py", (), ("t18_template",)),
    ("t20_template", "geometry/t20_template_certificate.py", (), ()),
    ("t20_confluence", "geometry/t20_branch_certificate.py", (), ("t20_template",)),
    ("independent_t18", "independent/independent_t18_audit.py", (), ("t18_confluence",)),
    ("independent_t20", "independent/independent_t20_audit.py", (), ("t20_confluence",)),
    ("independent_generic", "independent/audit_u1_generic_formal.py", (), ()),
    ("independent_special", "independent/audit_u1_special_formal.py", (), ()),
    ("special_local_algebra_root", "algebra/special_local_algebra.py", (), ()),
    ("path5_models", "catalog/path5_models.py", (), ()),
    ("ab_partial_checkpoint", "../notes/ab_checkpoint/certify_ab_partial.py", (), ()),
)


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "data" / "reproduced",
                        help="Destination for logs and v9_check_results.json.")
    parser.add_argument("--timeout", type=float, default=0,
                        help="Maximum seconds per check; 0 means no timeout.")
    args = parser.parse_args()
    if args.timeout < 0:
        parser.error("--timeout must be nonnegative")
    output_dir = args.output_dir.expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    try:
        import sympy
    except ImportError:
        print("SymPy is required. Install sympy==1.14.0 in the active Python environment.",
              file=sys.stderr)
        return 2

    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONUNBUFFERED"] = "1"
    results = []
    statuses = {}
    summary = {
        "edition": "v9",
        "started_at_utc": utc_now(),
        "python": platform.python_version(),
        "sympy": sympy.__version__,
        "arithmetic": "exact rational/algebraic/polynomial arithmetic; see individual certificates",
        "scope_note": (
            "The AB item is a partial checkpoint, not a completed local-ring classification. "
            "Finite certificates support the all-orders proofs in the paper; "
            "the runner does not replace those proofs."
        ),
        "checks": results,
    }
    summary_path = output_dir / "v9_check_results.json"

    def save_summary() -> None:
        summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
                                encoding="utf-8")

    for index, (name, relative, arguments, dependencies) in enumerate(CHECKS, 1):
        script = (CODE / relative).resolve()
        script.relative_to(ROOT)  # Reject accidental paths outside this bundle.
        log_path = output_dir / f"{index:02d}_{name}.log"
        entry = {
            "index": index,
            "name": name,
            "script": script.relative_to(ROOT).as_posix(),
            "arguments": list(arguments),
            "log": log_path.name,
            "scope": "partial_checkpoint" if name == "ab_partial_checkpoint" else "certificate",
        }
        unmet = [dependency for dependency in dependencies if statuses.get(dependency) != "PASS"]
        if unmet:
            entry.update(status="SKIP", reason="Failed prerequisite: " + ", ".join(unmet))
            log_path.write_text(entry["reason"] + "\n", encoding="utf-8")
        elif not script.is_file():
            entry.update(status="FAIL", reason="Missing script")
            log_path.write_text(f"Missing script: {entry['script']}\n", encoding="utf-8")
        else:
            entry["script_sha256"] = hashlib.sha256(script.read_bytes()).hexdigest()
            started = time.monotonic()
            print(f"[{index:02d}/{len(CHECKS)}] {name}", flush=True)
            try:
                with log_path.open("w", encoding="utf-8") as log:
                    completed = subprocess.run(
                        [sys.executable, str(script), *arguments],
                        cwd=script.parent, env=env, stdout=log, stderr=subprocess.STDOUT,
                        timeout=args.timeout or None, check=False,
                    )
                entry.update(returncode=completed.returncode,
                             status="PASS" if completed.returncode == 0 else "FAIL")
            except subprocess.TimeoutExpired:
                entry.update(status="FAIL", reason=f"Timeout after {args.timeout} seconds")
            except OSError as error:
                entry.update(status="FAIL", reason=str(error))
            entry["elapsed_seconds"] = round(time.monotonic() - started, 3)
        statuses[name] = entry["status"]
        results.append(entry)
        print(f"  {entry['status']}", flush=True)
        save_summary()

    summary["finished_at_utc"] = utc_now()
    summary["counts"] = {status: sum(item["status"] == status for item in results)
                         for status in ("PASS", "FAIL", "SKIP")}
    summary["status"] = "PASS" if all(item["status"] == "PASS" for item in results) else "FAIL"
    save_summary()
    print(f"{summary['status']}: {summary['counts']}; summary: {summary_path}", flush=True)
    return 0 if summary["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

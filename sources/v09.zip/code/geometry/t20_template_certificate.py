#!/usr/bin/env python3
"""Universal T20 template and generic MPS smoothing-diagram identification."""
from engine import *
from pathlib import Path
HERE=Path(__file__).resolve().parent
C=Calculus(4);C.x=s.symbols('U A V B');U,A,V,B=C.x
C.pol=lambda f:{m:s.factor(z) for m,z in s.Poly(s.expand(f),*C.x).terms() if z!=0}
al,be,la,mu=s.symbols('alpha beta lambda mu')
entries={(0,1):-al*U*A+la*B*B,(0,2):(be-3*al/2)*U*V+la*mu*A*B/be,
 (0,3):-(be+al/2)*U*B,(1,2):-(be+al/2)*A*V,
 (1,3):(be+al/2)*A*B,(2,3):al*V*B+mu*A*A}
P=C.tensor(entries);assert all(s.factor(z)==0 for z in C.cubic_vector(C.jacobi(P)))
M=C.as_matrix(P);pf=s.factor(M[0,1]*M[2,3]-M[0,2]*M[1,3]+M[0,3]*M[1,2]);expected=al*(2*be*U*A+la*B*B)*(2*be*V*B-mu*A*A)/(2*be)
assert s.factor(pf-expected)==0
L=M.subs({la:0,mu:0});coord=[U,A,V,B]
log=s.Matrix(4,4,lambda i,j:s.cancel(L[i,j]/(coord[i]*coord[j])))
W=log.inv();res=s.zeros(5)
for i in range(4):
 for j in range(4):res[i+1,j+1]=s.factor(W[i,j])
for i in range(1,5):res[0,i]=sum(res[i,j] for j in range(1,5));res[i,0]=-res[0,i]
forced=[];allorders={}
for i,j in combinations(range(5),2):
 if s.factor(res[i,j])==0:continue
 orders=[s.factor((res[j,k]+res[k,i])/res[i,j]) for k in range(5) if k not in (i,j)]
 allorders[str((i,j))]=[str(z) for z in orders]
 if all(z.is_Integer and z>=0 for z in orders):forced.append({'edge':[i,j],'other_indices':[k for k in range(5) if k not in (i,j)],'orders':[int(z) for z in orders]})
assert forced==[{'edge':[1,2],'other_indices':[0,3,4],'orders':[0,0,2]}, {'edge':[3,4],'other_indices':[0,1,2],'orders':[0,0,2]}]
report={'universal_affine_Jacobi_zero':True,'template':C.encode(P),'Pfaffian':str(pf),'Pfaffian_verified':True,
 'generic_toric_Pfaffian_coefficient':str(s.factor(log[0,1]*log[2,3]-log[0,2]*log[1,3]+log[0,3]*log[1,2])),
 'generic_forced_edges':forced,'all_orders':allorders,'catalog_identification':'T20, after relabeling the isolated t vertex',
 'domain_assumptions':['beta nonzero','alpha beta nonzero for rank4 toric member'],'all_passed':True}
(HERE/'t20_template_certificate.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS',flush=True)

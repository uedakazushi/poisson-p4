#!/usr/bin/env python3
"""Exact T20 confluence integrating the u+128v candidate at the U1 point."""
from engine import *
from pathlib import Path
import ast
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
h,eps,al=s.symbols('h eps alpha');rt=s.sqrt(2);chosen_al=-s.Rational(1,3)+rt*eps/9;be=s.Rational(1,2);ps=s.Rational(1,8);qs=-s.Rational(1,8)
y0,w0=s.symbols('y0 w0');XX=s.Matrix([t,x,y0,z,w0]);hh=x/2+z
U=z-hh/8+3*rt*t/8+eps*w0;A=hh+rt*t+eps*y0
V=z-hh/8-3*rt*t/8-eps*w0;B=hh-rt*t-eps*y0
L=s.Matrix([t,U,A,V,B]).jacobian(XX);Li=L.inv()
PM=s.zeros(5)
PM[1,2]=-al*U*A+ps*B*B;PM[1,3]=(-3*al/2+be)*U*V+(ps*qs/be)*A*B
PM[1,4]=(-al/2-be)*U*B;PM[2,3]=(-al/2-be)*A*V
PM[2,4]=(al/2+be)*A*B;PM[3,4]=al*V*B+qs*A*A
PM=eps*(PM-PM.T)
Pold_general=(Li*PM*Li.T).applyfunc(s.expand)
pole=s.zeros(5);pole[2,4]=rt*t*z*(3*al+1)/(4*eps);pole[4,2]=-pole[2,4]
assert all(s.expand(f).is_polynomial(*XX,eps,al) for f in Pold_general-pole)
Pold=Pold_general.subs(al,chosen_al).applyfunc(s.expand)
assert all(f.is_polynomial(*XX,eps) for f in Pold)
new=s.Matrix([t,x,3*y0/8-w0,z,21*y0/4+2*w0-2*z]);M=new.jacobian(XX)
sol=s.solve([s.Eq(3*y0/8-w0,y),s.Eq(21*y0/4+2*w0-2*z,w)],[y0,w0]);assert len(sol)==2
P=(M*Pold*M.T).subs(sol,simultaneous=True).subs(eps,rt*h).applyfunc(s.expand)
assert all(z.is_polynomial(*C.x,h) and not z.has(rt) for z in P)
C.pol=lambda f:{m:s.expand(z) for m,z in s.Poly(s.expand(f),*C.x).terms() if z!=0}
T=C.tensor({I:P[I] for I in C.pairs})
assert all(s.expand(z)==0 for z in C.cubic_vector(C.jacobi(T)))
U1=C.tensor({(1,2):t*t-z*z,(1,4):-(x*x+8*x*z+8*z*z)/2,(2,3):-z*z/2,(2,4):t*z+z*z+y*(x+2*z),(3,4):t*t+x*z+z*z})
assert P.subs(h,0)==C.as_matrix(U1)
Q1=s.expand((2*be*U*A+ps*B*B).subs(sol,simultaneous=True).subs(eps,rt*h))
Q2=s.expand((2*be*V*B-qs*A*A).subs(sol,simultaneous=True).subs(eps,rt*h))
pf=s.expand(P[1,2]*P[3,4]-P[1,3]*P[2,4]+P[1,4]*P[2,3]);assert s.expand(pf-(1-2*h/3)*Q1*Q2)==0
rec=json.loads((HERE/'u1_source_reference.json').read_text())
def read(dic):return C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals={f'x{i}':C.x[i] for i in range(5)}) for I,f in dic.items()})
Ns=[read(n) for n in rec['normals']]
report={'all_affine_Jacobi_identities':True,'source_equals_U1':True,'rational_polynomial_family':True,
 'unique_generic_pole':str(pole[2,4]),'pole_cancellation_verified':True,
 'family':C.encode(T),'Q1':str(s.factor(Q1)),'Q2':str(s.factor(Q2)),'Pfaffian_scalar':'1-2*h/3',
 'determinant_original_coordinate_map':str(s.factor(L.det())),'final_fiber_determinant':str(M.det()),
 'template_parameters':{'alpha':'-1/3+sqrt(2)*epsilon/9','beta':'1/2','p':'1/8','q':'-1/8'},'points':{}}
def minor_certificate(X):
 cols=list(DomainMatrix.from_Matrix(X).convert_to(s.QQ).rref()[1]);AA=X[:,cols]
 rows=list(DomainMatrix.from_Matrix(AA.T).convert_to(s.QQ).rref()[1]);det=s.QQ.to_sympy(DomainMatrix.from_Matrix(AA[rows,:]).convert_to(s.QQ).det())
 assert det!=0
 return {'rank':len(cols),'rows':rows,'columns':cols,'determinant':str(det)}
for val in [0,1,2]:
 Pt=C.tensor({I:P[I].subs(h,val) for I in C.pairs});D=C.derivative(Pt,True)
 VV=[C.vertical(i,j) for i in range(5) for j in range(5)];O=[]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=C.x[j];O.append(C.lie(Pt,X))
 G=s.Matrix.hstack(*[C.vector(Z) for Z in VV+O+[Pt]])
 Rt=C.tensor({I:s.diff(P[I],h).subs(h,val) for I in C.pairs});GF=G.row_join(C.vector(Rt));assert not any(D*GF)
 info={'Jacobi_rank':rank(D),'projective_tangent':125-rank(D),'projective_orbit':rank(G)-25,'projective_actual_family':rank(GF)-25,
 'Jacobi_minor':minor_certificate(D),'family_minor':minor_certificate(GF)}
 if val==0:
  mags=[C.tensor({(2,4):f}) for f in [t*t,t*x,t*z,x*x,x*z,z*z]]
  F=G.row_join(s.Matrix.hstack(*[C.vector(Z) for Z in mags]));piv=list(DomainMatrix.from_Matrix(F).convert_to(s.QQ).rref()[1]);F=F[:,piv]
  NN=F.row_join(s.Matrix.hstack(*[C.vector(N) for N in Ns]));coeff,free=NN.gauss_jordan_solve(C.vector(Rt));assert free.rows==0
  co=[s.factor(coeff[-2]),s.factor(coeff[-1])];info['normal_coordinates']=[str(c) for c in co]
  assert co[1]!=0 and co[0]+128*co[1]==0
  info['derivative']=C.encode(Rt)
 report['points'][str(val)]=info;print(val,{k:v for k,v in info.items() if k not in ['Jacobi_minor','family_minor','derivative']},flush=True)
report['all_passed']=True
(HERE/'t20_branch_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS',flush=True)

#!/usr/bin/env python3
"""Independent actual-curve and local-algebra audit of the special U1 theorem."""
from audit_u1_generic_formal import *

def main():
    start=time.time();ref=json.loads((HERE/'u1_special_audit_reference.json').read_text())
    uni=json.loads((HERE/'u1_formal_audit_reference.json').read_text())
    P=matrix({(1,2):t*t-z*z,(1,4):-(x*x+8*x*z+8*z*z)/2,(2,3):-z*z/2,
              (2,4):t*z+z*z+y*(x+2*z),(3,4):t*t+x*z+z*z})
    G=actual(P);assert rank(G)==47
    A=G.row_join(vector(matrix({(2,4):x*z})));A=A[:,piv(A)];assert A.cols==48
    NS=s.Matrix.hstack(*[s.Matrix([s.sympify(q,locals={'a':a}).subs(a,0) for q in col]) for col in uni['normal_coefficients']])
    B=A.row_join(NS);free=[j for j in range(150) if j not in uni['columns']]
    BI=inv(B[free,:]);reports={}
    for name,slope in [('T18',256),('T20',128)]:
        F=read_tensor(ref[name]['family']);equal_zero(F.subs(h,0)-P)
        assert not any(jacobi(F).values())
        H=vector(s.diff(F,h).subs(h,0));co=BI*H[free,:];equal_zero(B*co-H)
        cc=list(co[-2:,:]);assert cc[1]!=0 and cc[0]+slope*cc[1]==0
        assert list(map(str,cc))==ref[name]['source_normal']
        assert rank(G.row_join(H))==48
        # One regular generic point confirms an actual 23D image as well as
        # its formally immersed source curve. The catalog names use separate
        # template-identification certificates, not this local-ring argument.
        Q=F.subs(h,1);D=derivative(Q);GG=actual(Q);QQ=GG.row_join(vector(s.diff(F,h).subs(h,1)))
        equal_zero(D*QQ);assert rank(D)==102 and rank(QQ)==48
        reports[name]={'all_affine_Jacobi_zero':True,'source_matches':True,
           'source_normal_coordinates':list(map(str,cc)),
           'source_group_rank':47,'source_group_plus_curve_rank':48,
           'generic_full_Jacobi_rank':102,'generic_actual_rank':48,
           'source_and_generic_projective_family_dimension':23,
           'reference_sha256':ref[name]['sha256']}
        print(name,'actual branch PASS',cc,flush=True)

    # Exact algebra of the proposed full normal form.
    r,ss,elim=s.symbols('r s eliminate');variables=(a,r,ss)
    q=r*r-ss*ss;L=3*r-ss;I=[ss*q,a*ss*ss*L];K=[q,ss*L];J=[q,a*ss*L]
    def gb(polys,vs=variables):return s.groebner(polys,*vs,order='lex')
    def eq(A,B):
        GA,GB=gb(A),gb(B)
        return all(GB.reduce(f)[1]==0 for f in A) and all(GA.reduce(f)[1]==0 for f in B)
    def intersect(A,B):
        E=gb([elim*f for f in A]+[(1-elim)*f for f in B],(elim,)+variables)
        return [f.as_expr() for f in E.polys if not f.as_expr().has(elim)]
    def quotient(A,f):return [s.cancel(g/f) for g in intersect(A,[f])]
    primes=[[ss],[a,r-ss],[a,r+ss]]
    reduced=intersect(intersect(primes[0],primes[1]),primes[2])
    assert eq(reduced,[ss*q,a*ss])
    assert eq(quotient(I,a*ss),K) and eq(quotient(I,ss),J)
    assert eq(J,intersect(intersect([a,r-ss],[a,r+ss]),K))
    embedded=[r**3,ss*q,ss*ss*L]
    assert eq(I,intersect(intersect(intersect(primes[0],primes[1]),primes[2]),embedded))
    QG=gb(embedded);assert QG.reduce(r**3)[1]==QG.reduce(ss**4)[1]==0
    KG=s.groebner(K,r,ss,order='grevlex');basisK=[s.S.One,r,ss,ss*ss]
    for f in [r**3,r*r*ss,r*ss*ss,ss**3]:assert KG.reduce(f)[1]==0
    red=[KG.reduce(f)[1] for f in basisK]
    BM=s.Matrix([[s.Poly(f,r,ss).coeff_monomial(m) for f in red] for m in basisK]);assert BM.det()!=0
    IG=gb(I);assert IG.reduce((a*ss)**4)[1]==0 and IG.reduce((a*ss)**3)[1]!=0
    # Ordinary homogeneous complete intersection J has eventual Hilbert value6.
    JG=s.groebner(J,a,r,ss,order='grevlex');hilbert=[]
    for d in range(7):
        mons=[a**i*r**j*ss**(d-i-j) for i in range(d+1) for j in range(d-i+1)]
        reds=[JG.reduce(m)[1] for m in mons]
        MM=s.Matrix([[s.Poly(f,a,r,ss).coeff_monomial(m) for f in reds] for m in mons])
        hilbert.append(rank(MM))
    assert hilbert==[1,3,5,6,6,6,6]
    # The advertised rescaling preserves the actual parameter on the axis.
    F2=(u+128*v)*(u+256*v);g2=v*(3*u+512*v)
    sub={u:64*r-192*ss,v:ss}
    assert s.expand((v*F2).subs(sub,simultaneous=True)-4096*I[0])==0
    assert s.expand((a*v*g2).subs(sub,simultaneous=True)-64*I[1])==0
    out={'all_passed':True,'engine':'independent direct matrix engine from audit_u1_generic_formal.py',
      'actual_curves':reports,'full_special_local_model':['s*(r^2-s^2)','a*s^2*(3*r-s)'],
      'smooth_factor_dimension':22,'minimal_primes':[['s'],['a','r-s'],['a','r+s']],
      'minimal_component_dimensions':[24,23,23],'embedded_associated_prime':['r','s'],
      'nilradical_generator':'a*s','nilradical_annihilator':['r^2-s^2','s*(3*r-s)'],
      'nilradical_free_rank_over_C_a':4,'nilradical_nilpotence_index':4,
      'colon_s_complete_intersection_Hilbert_values':hilbert,
      'colon_s_multiplicity_decomposition':[4,1,1],
      'primary_decomposition_checked':True,
      'formal_identification_audit':'PASS; see u1_special_independent_audit.txt for node normalization, gluing, localization at three primes, and Cohen-Macaulay exhaustion',
      'source_proof_sha256':ref['proof_sha256'],
      'scope':'The coordinate a is unchanged on the magnetic axis but may change off it; the original fixed-a=0 slice is not identified.',
      'seconds':time.time()-start}
    (HERE/'u1_special_independent_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print('SPECIAL ALL PASS',out['seconds'],flush=True)

if __name__=='__main__':main()

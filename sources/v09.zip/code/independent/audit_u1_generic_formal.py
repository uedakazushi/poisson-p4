#!/usr/bin/env python3
"""Independent direct-matrix audit of the U1 relative formal-ring certificate.

No Poisson-calculus helper from the author, v8, or an older bundle is imported.
The input consists only of explicit tensor coefficients and implicit indices.
All Jacobi identities, derivatives, and group columns are rebuilt here.
"""
from pathlib import Path
from itertools import combinations, combinations_with_replacement
import ast, hashlib, json, time
import sympy as s
from sympy.polys.matrices import DomainMatrix

HERE=Path(__file__).resolve().parent
X=s.symbols('t x y z w');t,x,y,z,w=X
a,h,eta,u,v=s.symbols('a h eta u v')
pairs=list(combinations(range(5),2));tri=list(combinations(range(5),3));quad=list(combinations(range(5),4))
def exponents(d):
    return [tuple(c.count(i) for i in range(5)) for c in combinations_with_replacement(range(5),d)]
m2,m4=exponents(2),exponents(4)
mons2=[s.prod(xx**e for xx,e in zip(X,m)) for m in m2]
basis=[(I,m) for I in pairs for m in m2]

def matrix(entries):
    P=s.zeros(5)
    for I,f in entries.items():P[I]=f;P[I[::-1]]=-f
    return P
def vector(P):
    out=[]
    for I in pairs:
        d=s.Poly(s.expand(P[I]),*X).as_dict()
        out.extend(d.get(m,0) for m in m2)
    return s.Matrix(out)
def from_vector(q):
    return matrix({I:sum(q[k*15+j]*mons2[j] for j in range(15)) for k,I in enumerate(pairs)})
def read_tensor(data):
    loc=dict(zip(['t','x','y','z','w'],X))|{f'x{i}':X[i] for i in range(5)}|{'a':a,'h':h,'eta':eta}
    return matrix({tuple(ast.literal_eval(k)):s.sympify(f,locals=loc) for k,f in data.items()})
def expand(M):return M.applyfunc(s.expand)
def derivatives(P):return [[s.diff(P[i,j],q) for q in X] for i in range(5) for j in range(5)]
def jacobi(P):
    dp=derivatives(P);out={}
    for i,j,k in tri:
        out[i,j,k]=s.expand(sum(P[i,l]*dp[j*5+k][l]+P[j,l]*dp[k*5+i][l]+P[k,l]*dp[i*5+j][l] for l in range(5)))
    return out
def polar(P,R,dp=None):
    if dp is None:dp=derivatives(P)
    dr=derivatives(R);out={}
    for i,j,k in tri:
        out[i,j,k]=s.expand(sum(P[i,l]*dr[j*5+k][l]+P[j,l]*dr[k*5+i][l]+P[k,l]*dr[i*5+j][l]
             +R[i,l]*dp[j*5+k][l]+R[j,l]*dp[k*5+i][l]+R[k,l]*dp[i*5+j][l] for l in range(5)))
    return out
def projective(J):
    out=[]
    for I in quad:
        f=s.expand(sum((-1)**k*X[I[k]]*J[I[:k]+I[k+1:]] for k in range(4)))
        d=s.Poly(f,*X).as_dict();out.extend(d.get(m,0) for m in m4)
    return s.Matrix(out)
def derivative(P):
    dp=derivatives(P);cols=[]
    for I in pairs:
        for m in mons2:cols.append(projective(polar(P,matrix({I:m}),dp)))
    return s.Matrix.hstack(*cols)
def lie(P,Y):
    L=Y.jacobian(X)
    return expand(P.applyfunc(lambda f:sum(Y[i]*s.diff(f,X[i]) for i in range(5)))-L*P-P*L.T)
def actual(P):
    XX=s.Matrix(X);out=[]
    for i in range(5):
        for j in range(5):
            Y=s.zeros(5,1);Y[i]=X[j];out.append(vector(XX*Y.T-Y*XX.T))
    for i in range(5):
        for j in range(5):
            Y=s.zeros(5,1);Y[i]=X[j];out.append(vector(lie(P,Y)))
    out.append(vector(P));return s.Matrix.hstack(*out)
def piv(M):return list(DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1])
def rank(M):return len(piv(M))
def inv(M):return DomainMatrix.from_Matrix(M).convert_to(s.QQ).inv().to_Matrix()
def equal_zero(M):assert all(s.expand(q)==0 for q in M)

def main():
    start=time.time();ref=json.loads((HERE/'u1_formal_audit_reference.json').read_text())
    assert ref['basis_order']==[[list(I),list(m)] for I,m in basis]
    P=matrix({(1,2):t*t-z*z,(1,4):-(x*x+8*x*z+8*z*z)/2,(2,3):-z*z/2,
              (2,4):t*z+z*z+a*x*z+y*(x+2*z),(3,4):t*t+x*z+z*z})
    assert not any(jacobi(P).values())
    D0=derivative(P.subs(a,0));D1=derivative(s.diff(P,a));D=D0+a*D1
    print('Independent full 350 by 150 derivative built',flush=True)
    rows,cols=ref['rows'],ref['columns'];assert len(rows)==len(cols)==100
    M0=D0.extract(rows,cols);MI=inv(M0);N=MI*D1.extract(rows,cols)
    powers=[];T=s.eye(100);ranks=[]
    for j in range(6):
        powers.append(T);T=T*N;ranks.append(rank(T))
    assert ranks==[35,18,8,3,1,0] and T==s.zeros(100)
    MP=sum(((-a)**j*Z*MI for j,Z in enumerate(powers)),s.zeros(100))
    equal_zero(D.extract(rows,cols)*MP-s.eye(100))
    normals=s.Matrix.hstack(*[s.Matrix([s.sympify(q,locals={'a':a}) for q in col]) for col in ref['normal_coefficients']])
    equal_zero(D*normals)
    R,S=[from_vector(normals[:,j]) for j in range(2)]
    G=actual(P);A=G.row_join(vector(s.diff(P,a)))
    equal_zero(D*A)
    assert rank(G.subs(a,0))==47
    ap=piv(A.subs(a,0));assert len(ap)==48
    A=A[:,ap];B=A.row_join(normals);free=[j for j in range(150) if j not in cols]
    field=s.QQ.poly_ring(a);BF=DomainMatrix.from_Matrix(B[free,:]).convert_to(field)
    det=s.factor(field.to_sympy(BF.det()));assert det==-103680
    for Y in [s.Matrix([0,0,0,0,t]),s.Matrix([0,0,z,0,x])]:equal_zero(lie(P,Y))
    print('Universal rank 100, actual 48, normal 2: PASS',flush=True)

    # The supplied jets are proof witnesses; their full identities and the
    # fixed implicit-complement condition are checked without the source solver.
    T2=list(map(read_tensor,ref['second_tensors']));T3=list(map(read_tensor,ref['third_tensors']))
    V2=s.Matrix.hstack(*map(vector,T2));V3=s.Matrix.hstack(*map(vector,T3))
    assert V2[free,:]==s.zeros(50,3) and V3[free,:]==s.zeros(50,4)
    O2=s.Matrix.hstack(projective(jacobi(R)),projective(polar(R,S)),projective(jacobi(S)))
    equal_zero(D*V2+O2)
    T20,T11,T02=T2
    O3=s.Matrix.hstack(projective(polar(R,T20)),
          projective(polar(S,T20))+projective(polar(R,T11)),
          projective(polar(R,T02))+projective(polar(S,T11)),projective(polar(S,T02)))
    residual=expand(D*V3+O3);assert residual[rows,:]==s.zeros(100,4)
    assert list(residual[23,:])==[0,-s.Rational(1,64),-6,-512]
    coeff2=[]
    for i in range(350):
        c1=residual[i,1];g=s.Poly(s.expand(residual[i,2]-384*c1),a)
        quo,rem=s.div(g,s.Poly(3*a,a));assert rem.is_zero
        c2=quo.as_expr();coeff2.append(c2)
        assert residual[i,0]==0 and s.expand(residual[i,3]-32768*c1-512*a*c2)==0
    assert coeff2[23]==0 and coeff2[43]==-6
    print('Universal implicit second jets and integral cubic module: PASS',flush=True)

    # Reconstruct the actual T16 confluence from its linear coordinate map,
    # then gauge it to P_a. No Jacobi conclusion is imported from v8.
    e=s.symbols('e');rt=s.sqrt(2)
    U=z-e*y;AA=x/2+z+rt*t+e*(w/2+y+z)
    V=z+e*y;CC=x/2+z-rt*t-e*(w/2+y+z)
    L=s.Matrix([t,U,AA,V,CC]).jacobian(X);assert s.factor(L.det())==-e*e
    s1=e+eta*e*e;s2=-e+eta*e*e;cc=e+e*e/rt
    PM=matrix({(1,2):s1*(t*t+U*AA),(3,4):s2*(t*t+V*CC),(1,3):cc*U*V,
               (1,4):-cc*U*CC,(2,3):-cc*AA*V,(2,4):cc*AA*CC})
    LI=L.inv();F=expand(expand(LI*PM*LI.T).subs(e,rt*h))
    equal_zero(F-read_tensor(ref['T16_family']))
    GG=s.Matrix([t,x,y-2*a*z,z,w+8*a*z]).jacobian(X)
    subst=dict(zip(X,GG.inv()*s.Matrix(X)))
    F=expand((GG*F.subs(eta,-2*a)*GG.T).subs(subst,simultaneous=True))
    equal_zero(F.subs(h,0)-P)
    assert not any(jacobi(F).values())
    H=vector(s.diff(F,h).subs(h,0));HF=DomainMatrix.from_Matrix(H[free,:]).convert_to(field)
    solnum,solden=BF.solve_den(HF);sol=solnum.to_Matrix()/field.to_sympy(solden)
    equal_zero(B*sol-H);assert list(sol[-2:,:])==[16,0]
    print('Actual smooth relative T16 branch: PASS',flush=True)

    # Commutative-algebra numerical identities used by the all-order proof.
    q1=u*u-32768*v*v;q2=v*(3*u+512*v);cubics=[u**3,u*u*v,u*v*v,v**3]
    C=s.Matrix([[s.Poly(f,u,v).coeff_monomial(m) for f in [u*q1,v*q1,u*q2,v*q2]] for m in cubics])
    assert C.det()==-32768
    K=s.groebner([q1,q2],u,v,order='grevlex');assert all(K.reduce(f)[1]==0 for f in cubics)
    # Four independent standard monomials, and the degree distribution 1,2,1.
    for d,expected in [(0,1),(1,2),(2,1),(3,0)]:
        mon=[u**i*v**(d-i) for i in range(d+1)]
        reds=[K.reduce(f)[1] for f in mon]
        CM=s.Matrix([[s.Poly(f,u,v).coeff_monomial(m) for f in reds] for m in mon])
        assert rank(CM)==expected
    II=[v*q1,v*q2];IB=s.groebner(II,u,v,order='grevlex')
    assert IB.reduce(v**4)[1]==0 and IB.reduce(v**3)[1]!=0
    for d,expected in [(0,1),(1,2),(2,3),(3,2),(4,1),(5,1)]:
        mon=[u**i*v**(d-i) for i in range(d+1)];reds=[IB.reduce(f)[1] for f in mon]
        CM=s.Matrix([[s.Poly(f,u,v).coeff_monomial(m) for f in reds] for m in mon])
        assert rank(CM)==expected
    # The two displayed normal forms are related by an invertible linear map.
    UU,VV=s.symbols('U V');newv=3*VV/(128*rt);newu=UU-s.Rational(512,3)*newv
    new=[s.expand(f.subs({u:newu,v:newv},simultaneous=True)) for f in II]
    target=s.groebner([VV*(UU*UU-VV*VV),UU*VV*VV],UU,VV,extension=rt)
    source=s.groebner(new,UU,VV,extension=rt)
    assert source==target
    out={'all_passed':True,'engine':'standalone direct 5x5 skew matrices; no imported Poisson helper',
      'source_sha256':ref['source_sha256'],'normal_basis_verified':True,
      'universal_Jacobi_minor_nilpotent_power_ranks':ranks,
      'actual_plus_normals_determinant':str(det),'group_rank':47,'actual_rank':48,'full_Jacobi_rank':100,
      'universal_second_jets_in_fixed_complement':True,
      'integral_cubic_module':['v*(u+128*v)*(u+256*v)','a*v^2*(3*u+512*v)'],
      'cubic_witness_rows':[23,43],'actual_T16_derivative_normal_coordinates':[16,0],
      'cubic_multiplication_determinant':str(C.det()),
      'embedded_transverse_module_Hilbert_function':[1,2,1],
      'embedded_transverse_module_length':4,'nilradical_nilpotence_index':4,
      'transverse_ring_Hilbert_values_degrees0_to5':[1,2,3,2,1,1],
      'formal_proof_audit':'PASS; see accompanying independent_audit.txt for relative division, Nakayama, closed-point descent, associated primes, and scope',
      'scope':'Every finite a0 != 0. No conclusion about a0=0 follows from this generic-ring certificate alone.',
      'seconds':time.time()-start}
    (HERE/'u1_generic_independent_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print('ALL PASS',out['seconds'],flush=True)

if __name__=='__main__':main()

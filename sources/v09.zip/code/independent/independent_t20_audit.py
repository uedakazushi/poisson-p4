#!/usr/bin/env python3
"""Helper-free independent T20 reconstruction and full coefficient audit.
No author Poisson engine, saved matrices, or cached rank outputs are imported.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
import sympy as s
from sympy.polys.matrices import DomainMatrix
import json,ast
HERE=Path(__file__).resolve().parent
xs=s.symbols('t x y z w');t,x,y,z,w=xs;h,ep=s.symbols('h epsilon');rt=s.sqrt(2)
pairs=list(combinations(range(5),2));tri=list(combinations(range(5),3));quad=list(combinations(range(5),4))
def mons(d):return [s.prod(xs[i] for i in I) for I in combinations_with_replacement(range(5),d)]
m2=mons(2);m4=mons(4)
def vec(M):
 return s.Matrix([s.Poly(s.expand(M[i,j]),*xs).coeff_monomial(m) for i,j in pairs for m in m2])
def rank(M):return len(DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1])
def Jac(M):
 return {I:s.expand(sum(M[i,l]*s.diff(M[j,k],xs[l]) for i,j,k in [I,(I[1],I[2],I[0]),(I[2],I[0],I[1])] for l in range(5))) for I in tri}
def derivative(M):
 deriv={(i,j,l):s.diff(M[i,j],xs[l]) for i in range(5) for j in range(5) for l in range(5)}
 cols=[]
 for a,b in pairs:
  for mon in m2:
   dm=[s.diff(mon,z) for z in xs];jj={}
   for I in tri:
    f=0
    for i,j,k in [I,(I[1],I[2],I[0]),(I[2],I[0],I[1])]:
     if i==a:f+=mon*deriv[j,k,b]
     if i==b:f-=mon*deriv[j,k,a]
     sig=int((j,k)==(a,b))-int((j,k)==(b,a))
     if sig:f+=sig*sum(M[i,l]*dm[l] for l in range(5))
    jj[I]=s.expand(f)
   ev={I:s.expand(sum((-1)**pos*xs[i]*jj[I[:pos]+I[pos+1:]] for pos,i in enumerate(I))) for I in quad}
   cols.append(s.Matrix([s.Poly(ev[I],*xs).coeff_monomial(m) for I in quad for m in m4]))
 return s.Matrix.hstack(*cols)
def family_matrix(M,R):
 vv=[];oo=[];xvec=s.Matrix(xs)
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=xs[j];AA=X.jacobian(xs)
   vv.append(vec(xvec*X.T-X*xvec.T))
   lie=M.applyfunc(lambda f:sum(X[k]*s.diff(f,xs[k]) for k in range(5)))-AA*M-M*AA.T
   oo.append(vec(lie))
 G=s.Matrix.hstack(*vv,*oo,vec(M));return G,G.row_join(vec(R))
def from_text(dic):
 M=s.zeros(5)
 for I,f in dic.items():
  i,j=ast.literal_eval(I);M[i,j]=s.sympify(f,locals={f'x{k}':xs[k] for k in range(5)});M[j,i]=-M[i,j]
 return M

# Independent final-coordinate construction, without the author's old fibers.
y0=(w+2*z+2*y)/6;w0=(w+2*z-14*y)/16;hh=x/2+z
U=z-hh/8+3*rt*t/8+ep*w0;A=hh+rt*t+ep*y0
V=z-hh/8-3*rt*t/8-ep*w0;B=hh-rt*t-ep*y0
L=s.Matrix([t,U,A,V,B]).jacobian(xs)
al=-s.Rational(1,3)+rt*ep/9;be=s.Rational(1,2);ps=s.Rational(1,8);qs=-ps
Z=s.zeros(5)
Z[1,2]=-al*U*A+ps*B*B;Z[3,4]=al*V*B+qs*A*A
Z[1,3]=(-3*al/2+be)*U*V+ps*qs*A*B/be
Z[1,4]=(-al/2-be)*U*B;Z[2,3]=(-al/2-be)*A*V;Z[2,4]=(al/2+be)*A*B
Z=ep*(Z-Z.T)
P=(L.inv()*Z*L.inv().T).subs(ep,rt*h).applyfunc(s.expand)
assert all(f.is_polynomial(*xs,h) and not f.has(rt) for f in P)
assert all(f==0 for f in Jac(P).values())
Q1=s.expand((2*be*U*A+ps*B*B).subs(ep,rt*h));Q2=s.expand((2*be*V*B-qs*A*A).subs(ep,rt*h))
pf=s.expand(P[1,2]*P[3,4]-P[1,3]*P[2,4]+P[1,4]*P[2,3]);assert s.expand(pf-(1-2*h/3)*Q1*Q2)==0
reference=json.loads((HERE.parent/'geometry/t20_branch_certificate.json').read_text())
Pr=from_text(reference['family']);assert all(s.expand(f)==0 for f in P-Pr)
u1=json.loads((HERE/'u1_source_reference.json').read_text());P0=from_text(u1['point']);assert all(s.expand(f)==0 for f in P.subs(h,0)-P0)
normal=[from_text(n) for n in u1['normals']]
out={'independent_direct_final_coordinate_pullback':True,'no_Poisson_helper_imports':True,
 'rational_polynomial_family':True,'universal_raw_affine_Jacobi_zero':True,
 'source_verified':True,'author_full_tensor_matches':True,'Pfaffian_factor':'1-2*h/3','Pfaffian_verified':True,'points':{}}
for val in [0,1,2]:
 PP=P.subs(h,val);R=P.diff(h).subs(h,val);DD=derivative(PP);G,F=family_matrix(PP,R)
 assert DD*F==s.zeros(350,F.cols)
 rr=rank(DD);gr=rank(G);fr=rank(F);exp=reference['points'][str(val)]
 assert rr==exp['Jacobi_rank'] and gr-25==exp['projective_orbit'] and fr-25==exp['projective_actual_family']
 minors={}
 for label,Mat,key in [('Jacobi',DD,'Jacobi_minor'),('family',F,'family_minor')]:
  sub=exp[key];det=s.QQ.to_sympy(DomainMatrix.from_Matrix(Mat[sub['rows'],sub['columns']]).convert_to(s.QQ).det())
  assert det!=0 and det==s.Rational(sub['determinant'])
  minors[label]={'same_selected_minor_verified':True,'determinant':str(det)}
 info={'Jacobi_rank':rr,'group_rank':gr,'family_rank':fr,'projective_tangent':125-rr,'projective_actual':fr-25,'minors':minors}
 if val==0:
  mags=[]
  for mon in [t*t,t*x,t*z,x*x,x*z,z*z]:
   MM=s.zeros(5);MM[2,4]=mon;MM[4,2]=-mon;mags.append(vec(MM))
  GG=G.row_join(s.Matrix.hstack(*mags));cols=list(DomainMatrix.from_Matrix(GG).convert_to(s.QQ).rref()[1]);GG=GG[:,cols]
  H=GG.row_join(s.Matrix.hstack(*[vec(N) for N in normal]));sol,free=H.gauss_jordan_solve(vec(R));assert not free.rows
  co=list(sol[-2:,:]);assert co==[s.Rational(16,3),-s.Rational(1,24)]
  info['normal_coordinates']=list(map(str,co))
 else:
  field=s.QQ.algebraic_field(rt);qr=[len(DomainMatrix.from_Matrix(s.hessian(qq.subs(h,val),xs)).convert_to(field).rref()[1]) for qq in [Q1,Q2]]
  assert qr==[3,3];info['quadric_ranks']=qr
 out['points'][str(val)]=info;print(val,rr,gr,fr,flush=True)
out['all_passed']=True
(HERE/'independent_t20_audit.json').write_text(json.dumps(out,indent=2)+'\n');print('PASS',flush=True)

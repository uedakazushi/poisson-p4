#!/usr/bin/env python3
"""Read-only SHA256 verification of the files listed in this bundle's manifest."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path, PurePosixPath
import re
import sys


ROOT = Path(__file__).resolve().parent.parent
LINE = re.compile(r"^([0-9a-fA-F]{64})  (.+)$")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", default="SHA256SUMS.txt",
                        help="Manifest path relative to this bundle; default: SHA256SUMS.txt")
    parser.add_argument("--strict", action="store_true",
                        help="Also reject files absent from the manifest, excluding the manifest itself.")
    args = parser.parse_args()
    manifest = (ROOT / args.manifest).resolve()
    try:
        manifest.relative_to(ROOT)
    except ValueError:
        parser.error("The manifest must be inside this bundle")
    if not manifest.is_file():
        print(f"FAIL: manifest not found: {args.manifest}", file=sys.stderr)
        return 1

    listed = set()
    failures = []
    checked = 0
    for number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        match = LINE.fullmatch(line)
        if match is None:
            failures.append(f"Manifest line {number}: invalid SHA256 format")
            continue
        expected, name = match.groups()
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts or "\\" in name:
            failures.append(f"Manifest line {number}: unsafe relative path")
            continue
        if name in listed:
            failures.append(f"Manifest line {number}: duplicate path {name}")
            continue
        listed.add(name)
        path = (ROOT / name).resolve()
        try:
            path.relative_to(ROOT)
        except ValueError:
            failures.append(f"Path resolves outside bundle: {name}")
            continue
        if not path.is_file():
            failures.append(f"Missing file: {name}")
            continue
        if file_sha256(path) != expected.lower():
            failures.append(f"SHA256 mismatch: {name}")
        checked += 1

    if not listed:
        failures.append("Manifest has no file entries")
    if args.strict:
        actual = {path.relative_to(ROOT).as_posix() for path in ROOT.rglob("*")
                  if path.is_file() and path.resolve() != manifest}
        for name in sorted(actual - listed):
            failures.append(f"Unlisted file: {name}")

    if failures:
        for failure in failures:
            print("FAIL:", failure, file=sys.stderr)
        print(f"Checked {checked} file(s); {len(failures)} issue(s).", file=sys.stderr)
        return 1
    print(f"PASS: {checked} file(s) match {manifest.relative_to(ROOT).as_posix()}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

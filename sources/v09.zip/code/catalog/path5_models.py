"""Construct the three P5 toric smoothing models by exact weight recursion."""
from pathlib import Path
import sys,json,math
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
from exact_calculus import *
from sympy.polys.matrices import DomainMatrix
def rr(M): return DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()
HERE=Path(__file__).resolve().parent
C=Calculus(5)
catalog=HERE/'p4_toric_smoothing_diagrams.json'
diagrams=json.loads(catalog.read_text())['diagrams']
out={}
def divfree(P):
 M=C.as_matrix(P)
 return all(s.expand(sum(s.diff(M[i,j],C.x[i]) for i in range(5)))==0 for j in range(5))
def pf(M):
 f=0
 for i in range(5):
  a,b,c,d=[j for j in range(5) if j!=i]
  f+=(-1)**i*C.x[i]*(M[a,b]*M[c,d]-M[a,c]*M[b,d]+M[a,d]*M[b,c])
 return s.factor(f)
for d in diagrams:
 if d['id'] not in ['T36','T37','T38']:continue
 B=s.Matrix(d['biresidue_example']);Pi=(B+s.ones(5)/5).inv()-s.ones(5)/5
 assert Pi+Pi.T==s.zeros(5) and Pi*s.ones(5,1)==s.zeros(5,1)
 denom=s.ilcm(*[q.q for q in Pi]);Pi=Pi*denom
 nums=[int(q) for q in Pi if q];g=math.gcd(*nums);Pi=Pi/g
 P0=C.tensor({I:Pi[I]*C.x[I[0]]*C.x[I[1]] for I in C.pairs})
 assert divfree(P0)
 weights=[];edges=d['edges'];jets={}
 for j,e in enumerate(edges):
  I=tuple(e['edge']);m=tuple(int(e['orders'].get(str(k),0)) for k in range(5))
  weights.append(s.Matrix([m[k]-int(k in I) for k in range(5)]))
  key=tuple(int(k==j) for k in range(4));jets[key]={I:{m:s.S.One}}
 W=s.Matrix.hstack(*weights);left=(W.T*W).inv()*W.T;groups={}
 for k,(I,m) in enumerate(C.basis):
  w=s.Matrix([m[j]-int(j in I) for j in range(5)]);v=left*w
  if W*v!=w or any(z.q!=1 or z<0 for z in v):continue
  key=tuple(map(int,v))
  if any(key):groups.setdefault(key,[]).append(k)
 D=C.derivative(P0,False)
 for key in sorted(groups,key=lambda k:(sum(k),k)):
  if key in jets:
   assert not any(C.cubic_vector(C.polar(P0,jets[key])))
   continue
  rhs=s.zeros(350,1)
  for a in sorted(jets):
   b=tuple(k-z for k,z in zip(key,a))
   if b not in jets or a>b:continue
   rhs+=C.cubic_vector(C.jacobi(jets[a]) if a==b else C.polar(jets[a],jets[b]))
  idx=groups[key];A=D[:,idx]
  if not any(rhs):continue
  rrM,piv=rr(A.row_join(-rhs));rrM=rrM.to_Matrix()
  assert len(idx) not in piv,(d['id'],key,'obstruction')
  vec=s.zeros(150,1)
  for row,j in enumerate(piv):vec[idx[j]]=rrM[row,-1]
  jets[key]=C.from_vector(vec);assert not any(A*vec[idx,:]+rhs)
 P=C.from_vector(C.vector(P0)+sum([C.vector(q) for q in jets.values()],s.zeros(150,1)))
 assert not any(C.cubic_vector(C.jacobi(P)))
 assert divfree(P)
 G=[C.vertical(i,j) for i in range(5) for j in range(5)]+[P]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=C.x[j];G.append(C.lie(P,X))
 GM=s.Matrix.hstack(*map(C.vector,G));DP=C.derivative(P,True)
 info={'id':d['id'],'period_biresidue':d['biresidue_example'],'log_poisson_matrix':str(Pi),'weights':list(map(list,zip(*[list(q) for q in weights]))),'weight_terms':[{'multiindex':list(k),'tensor':C.encode(v)} for k,v in jets.items()],'Poisson':C.encode(P),'degeneracy_quintic':str(pf(C.as_matrix(P))),'affine_Jacobi_zero':True,'unimodular':True,'full_Jacobi_rank':rank(DP),'projective_orbit_dimension':rank(GM)-25}
 print(info,flush=True);out[d['id']]=info
 (HERE/'path5_models.json').write_text(json.dumps(out,indent=2,default=str)+'\n')

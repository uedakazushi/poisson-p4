"""Exact U1 magnetic model and full150 coefficient spaces (v9 local copy)."""
from pathlib import Path
import json,ast
import sympy as s
from exact_calculus import Calculus
from full_kuranishi import actual,rk,rref,kernel
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
def point(a=0):
    return C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,
       (2,3):-z*z/2,(2,4):t*z+z*z+a*x*z+y*(x+2*z),
       (3,4):t*t+x*z+z*z})
def read_tensor(data):
    return C.tensor({tuple(ast.literal_eval(k)):s.sympify(v,locals={f'x{i}':C.x[i] for i in range(5)}) for k,v in data.items()})
def normals():
    return [read_tensor(a) for a in json.loads((HERE/'small_points.json').read_text())[1]['normals']]
def magnetic_directions():
    return [C.tensor({(2,4):m}) for m in [t*t,t*x,t*z,x*x,x*z,z*z]]
def actual_magnetic(P):
    A=actual(C,P)
    return s.Matrix.hstack(A,*[C.vector(R) for R in magnetic_directions()])


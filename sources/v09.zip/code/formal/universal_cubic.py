#!/usr/bin/env python3
"""Full universal cubic Kuranishi obstruction over the U1 magnetic modulus."""
from u1_model import *
from full_kuranishi import inverse
from sympy.polys.matrices import DomainMatrix
import time

def main():
    start=time.time();a=s.symbols('a')
    D0=C.derivative(point(),True);D1=C.derivative(C.tensor({(2,4):x*z}),True)
    rec=json.loads((HERE/'higher_jets.json').read_text());rows=rec['elimination_rows'];cols=rec['elimination_columns']
    Mi=inverse(D0.extract(rows,cols));N=Mi*D1.extract(rows,cols);powers=[s.eye(100)]
    while any(powers[-1]*N):
        powers.append(powers[-1]*N)
        assert len(powers)<10
    inverses=[(-1)**k*Z*Mi for k,Z in enumerate(powers)]
    def polys(M):
        entries={};top=0
        for i in range(M.rows):
            for j in range(M.cols):
                for (d,),v in s.Poly(s.expand(M[i,j]),a).terms():
                    if v:entries.setdefault(d,{})[i,j]=v;top=max(top,d)
        return [s.SparseMatrix(M.rows,M.cols,entries.get(d,{})) for d in range(top+1)]
    def combine(L):return sum((a**i*M for i,M in enumerate(L)),s.zeros(L[0].rows,L[0].cols))
    def eliminate(rhs):
        pp=polys(rhs);cc=[s.zeros(100,rhs.cols) for _ in range(len(pp)+len(inverses)-1)]
        for i,M in enumerate(inverses):
            for j,B in enumerate(pp):cc[i+j]-=M*B[rows,:]
        res=[s.zeros(350,rhs.cols) for _ in range(max(len(pp),len(cc)+1))]
        for i,B in enumerate(pp):res[i]+=B
        for i,T in enumerate(cc):
            res[i]+=D0[:,cols]*T;res[i+1]+=D1[:,cols]*T
        while len(cc)>1 and not any(cc[-1]):cc.pop()
        while len(res)>1 and not any(res[-1]):res.pop()
        lifted=[]
        for T in cc:
            L=s.zeros(150,T.cols)
            for i,c in enumerate(cols):L[c,:]=T[i,:]
            lifted.append(L)
        return combine(lifted),combine(res)
    nn=json.loads((HERE/'universal_kernel.json').read_text())
    rv=s.Matrix.hstack(*[s.Matrix([s.sympify(v,locals={'a':a}) for v in q]) for q in nn['normal_coefficients']])
    R,S=[C.from_vector(rv[:,i]) for i in range(2)]
    rhs2=s.Matrix.hstack(C.euler_vector(C.jacobi(R)),C.euler_vector(C.polar(R,S)),C.euler_vector(C.jacobi(S)))
    T2,res2=eliminate(rhs2);assert res2==s.zeros(350,3)
    print('universal second jets',max(s.degree(v,a) for v in T2 if v),time.time()-start,flush=True)
    T20,T11,T02=[C.from_vector(T2[:,i]) for i in range(3)]
    rhs3=s.Matrix.hstack(C.euler_vector(C.polar(R,T20)),
         C.euler_vector(C.polar(S,T20))+C.euler_vector(C.polar(R,T11)),
         C.euler_vector(C.polar(R,T02))+C.euler_vector(C.polar(S,T11)),C.euler_vector(C.polar(S,T02)))
    T3,res3=eliminate(rhs3)
    res3=res3.applyfunc(s.factor)
    rr=next(i for i in range(res3.rows) if any(res3[i,:]))
    row=res3[rr,:];u,v=s.symbols('u v');f=s.factor((row*s.Matrix([u**3,u*u*v,u*v*v,v**3]))[0])
    assert s.expand(f+v*(u+128*v)*(u+256*v)/64)==0
    jj=next(j for j in range(4) if row[j])
    RR,piv=DomainMatrix.from_Matrix(res3).convert_to(s.QQ.frac_field(a)).rref();RR=RR.to_Matrix()
    generic_equations=[s.factor((RR[i,:]*s.Matrix([u**3,u*u*v,u*v*v,v**3]))[0]) for i in range(len(piv))]
    print('GENERIC cubic rank',len(piv),'equations',generic_equations,flush=True)
    samples={}
    for av in [0,1,2,-1]:
        SR,sp=rref(res3.subs(a,av))
        eq=[s.factor((SR[i,:]*s.Matrix([u**3,u*u*v,u*v*v,v**3]))[0]) for i in range(len(sp))]
        samples[str(av)]={'rank':len(sp),'equations':[str(q) for q in eq]}
    print('SAMPLES',samples,flush=True)
    # Integral row module: f0 and a*g, not just its function-field rank.
    gammas=[s.factor((res3[i,2]-384*res3[i,1])/3) for i in range(350)]
    assert all(res3[i,0]==0 and s.expand(res3[i,3]-32768*res3[i,1]-512*gammas[i])==0 for i in range(350))
    assert all(s.Poly(q,a).eval(0)==0 for q in gammas)
    gamma_gcd=s.Poly(0,a)
    for q in gammas:
        if q:gamma_gcd=s.gcd(gamma_gcd,s.Poly(q,a))
    gamma_gcd=gamma_gcd.monic().as_expr();assert gamma_gcd==a
    witnesses=[(i,q) for i,q in enumerate(gammas) if q and s.degree(q,a)==1]
    assert witnesses
    # A fixed100 minor stays invertible for every a because N^6=0.
    assert powers[-1]*N==s.zeros(100)
    C.pol=lambda f:{m:q for m,q in s.Poly(s.expand(f),*C.x).terms() if q}
    AF=actual_magnetic(point(a));ap=rref(AF.subs(a,0))[1];AB=AF[:,ap].row_join(rv)
    free=[j for j in range(150) if j not in cols]
    det=s.factor(DomainMatrix.from_Matrix(AB[free,:]).convert_to(s.QQ.poly_ring(a)).det().as_expr())
    assert det==414720
    out={'all_passed':True,'parameter':'a','Jacobi_100_minor_constant_nonzero':True,
       'inverse_degree':len(inverses)-1,'nilpotent_index':len(powers),
       'universal_full_Jacobi_rank':100,'actual_plus_normals_free_coordinate_determinant':str(det),
       'universal_second_obstructions_zero':True,
       'universal_cubic_rank':len(piv),'generic_cubic_equations':[str(q) for q in generic_equations],
       'samples':samples,'cubic_pivot_row':rr,'cubic_pivot_polynomial':str(f),
       'integral_cubic_row_module':['v*(u+128*v)*(u+256*v)','a*v^2*(3*u+512*v)'],
       'second_generator_witness':[witnesses[0][0],str(witnesses[0][1])],
       'gamma_coefficient_gcd':str(gamma_gcd),
       'cubic_row_coefficients':[str(s.factor(q)) for q in row],
       'second_tensors':[C.encode(C.from_vector(T2[:,i])) for i in range(3)],
       'third_correction_tensors':[C.encode(C.from_vector(T3[:,i])) for i in range(4)],
       'cubic_residual_column':[str(s.factor(q)) for q in res3[:,jj]],
       'scope':'Universal order3 certificate only; not an all-order principality claim.',
       'seconds':time.time()-start}
    (HERE/'universal_cubic.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS universal cubic',f,'actual determinant',det,time.time()-start,flush=True)

if __name__=='__main__':main()

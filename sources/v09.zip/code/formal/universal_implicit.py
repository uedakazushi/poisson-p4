#!/usr/bin/env python3
"""Study the fixed full100-variable implicit complement over the modulus."""
from u1_model import *
from full_kuranishi import inverse

def main():
    D0=C.derivative(point(),True);D1=C.derivative(C.tensor({(2,4):x*z}),True)
    rec=json.loads((HERE/'higher_jets.json').read_text());rows=rec['elimination_rows'];cols=rec['elimination_columns']
    Mi=inverse(D0.extract(rows,cols));N=Mi*D1.extract(rows,cols)
    powers=[];T=s.eye(100)
    for d in range(1,16):
        T=T*N;powers.append(rk(T))
        if not any(T):break
    print('powers ranks',powers,flush=True)
    out={'nilpotent':not any(T),'power_ranks':powers,'constant_determinant_if_nilpotent':not any(T)}
    (HERE/'universal_implicit.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()

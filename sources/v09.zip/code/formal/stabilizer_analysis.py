#!/usr/bin/env python3
"""Full stabilizer and its action on the U1 two-normal quotient."""
from u1_model import *

def main():
    P=point();D=C.derivative(P,True);N=normals()
    V=s.Matrix.hstack(*[C.vector(C.vertical(i,j)) for i in range(5) for j in range(5)])
    vp=rref(V)[1];V=V[:,vp]
    vv=[];fields=[]
    for i in range(5):
        for j in range(5):
            if i==j==4:continue
            X=s.zeros(5,1);X[i]=C.x[j];fields.append(X)
            vv.append(C.vector(C.lie(P,X)))
    T=s.Matrix.hstack(*vv,C.vector(P),V)
    K=kernel(T);assert K.cols==2
    AM=actual_magnetic(P);piv=rref(AM)[1];AM=AM[:,piv]
    full=AM.row_join(s.Matrix.hstack(*[C.vector(R) for R in N]));assert rk(full)==50
    records=[]
    for j in range(K.cols):
        X=sum((K[i,j]*F for i,F in enumerate(fields)),s.zeros(5,1))
        alpha=K[len(fields),j]
        images=[]
        for R in N:
            # The stabilizer includes the scalar correction and vertical
            # compensation. Its derivative on the normal quotient is
            # Lie_X(R)+alpha R; vertical compensation contributes nothing.
            image=C.vector(C.lie(R,X))+alpha*C.vector(R)
            sol,free=full.gauss_jordan_solve(image);assert free.rows==0
            images.append(sol[-2:,:])
        normal=s.Matrix.hstack(*images)
        mat=X.jacobian(C.x)
        records.append({'field':[str(s.factor(a)) for a in X],'scalar_correction':str(alpha),
                        'eigenvalues':{str(a):b for a,b in mat.eigenvals().items()},
                        'normal_action':[[str(a) for a in row] for row in normal.tolist()]})
    out={'all_passed':True,'stabilizer_dimension':2,'records':records,
         'conclusion':'Both infinitesimal stabilizers are nilpotent and act trivially on the two-normal quotient. No nontrivial semisimple weight grading is furnished by the stabilizer.'}
    (HERE/'stabilizer_analysis.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()

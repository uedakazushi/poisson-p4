#!/usr/bin/env python3
"""Standalone polynomial checks of the proposed/proved U1 formal normal form.

No Poisson helper and no other agent's algebra code is imported.
The bridge from Jacobi to this normal form is the accompanying formal proof.
"""
from pathlib import Path
import json
import sympy as s
HERE=Path(__file__).resolve().parent
a,r,v,z=s.symbols('a r s z');variables=(a,r,v)

def gb(gens):return s.groebner(gens,*variables,order='lex')
def equal(I,J):
    G=gb(I);H=gb(J)
    return all(G.reduce(s.sympify(f))[1]==0 for f in J) and all(H.reduce(s.sympify(f))[1]==0 for f in I)
def intersection(I,J):
    G=s.groebner([z*f for f in I]+[(1-z)*f for f in J],z,*variables,order='lex')
    return [g.as_expr() for g in G.polys if not g.as_expr().has(z)]

def main():
    q=r*r-v*v;ell=3*r-v;I=[v*q,a*v*v*ell];K=[q,v*ell]
    primes=[[v],[a,r-v],[a,r+v]]
    reduced=intersection(intersection(primes[0],primes[1]),primes[2])
    assert equal(reduced,[v*q,a*v])
    assert equal(I+[a*v],reduced)
    f=a*v
    inter=intersection(I,[f]);colon=[s.cancel(g/f) for g in inter]
    assert all(s.Poly(g,*variables).is_zero or s.denom(g)==1 for g in colon)
    assert equal(colon,K)
    G=gb(I);nilpowers=[s.factor(G.reduce(f**i)[1]) for i in range(1,5)]
    assert nilpowers[2]!=0 and nilpowers[3]==0
    Q=s.groebner(K,r,v,order='grevlex')
    cube=[r**3,r*r*v,r*v*v,v**3]
    assert all(Q.reduce(g)[1]==0 for g in cube)
    basis=[s.S.One,r,v,v*v]
    assert all(Q.reduce(g)[1]==g for g in basis)
    J0=[q,a*v*ell]
    assert s.gcd(*J0)==1
    # The exact sequence 0 -> R/J0 --times v--> R/I -> R/(v) -> 0.
    assert equal([s.cancel(g/v) for g in intersection(I,[v])],J0)
    t=s.symbols('t');HJ=(1-t*t)*(1-t**3)/(1-t)**3
    HI=1/(1-t)**2+t*HJ
    HN=t*t*(1+t)**2/(1-t)
    Hred=(1-t*t-t**3+t**4)/(1-t)**3
    assert s.cancel(HI-Hred-HN)==0
    assert s.limit((1-t)*HJ,t,1)==6
    out={'all_passed':True,'ideal':[str(f) for f in I],
      'minimal_primes':[[str(g) for g in p] for p in primes],
      'radical_generators':[str(v*q),str(a*v)],'nilradical_generator':str(a*v),
      'nilradical_annihilator':[str(q),str(v*ell)],'colon_computed_by_exact_ideal_intersection':True,
      'nilpotency_index':4,'nilpotent_power_remainders':[str(p) for p in nilpowers],
      'nilradical_free_basis_over_QQ_a':[str(g) for g in basis],
      'nilradical_rank_over_base':4,'complete_intersection_J0_multiplicity':6,
      'full_Hilbert_series':str(s.factor(HI)),'nilradical_Hilbert_series':str(HN),
      'scope':'Checks the exact commutative algebra of the final normal form. The theorem linking it to all full Poisson equations is separate.'}
    (HERE/'special_local_algebra_independent.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS exact minimal primes, nilradical, colon, index4, free rank4, CI multiplicity6')

if __name__=='__main__':main()

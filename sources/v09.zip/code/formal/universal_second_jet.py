#!/usr/bin/env python3
"""Exact polynomial second jets along the U1 magnetic modulus."""
from u1_model import *
from sympy.polys.matrices import DomainMatrix
import sys,time

def polynomial_solve_fixed_zero(D0,D1,rhs,T0,a,degree):
    """Solve (D0+aD1)T=rhs with T(0)=T0 and bounded polynomial degree."""
    n=D0.cols;m=D0.rows;k=rhs.cols
    assert (D0*T0-rhs.subs(a,0)).applyfunc(s.expand)==s.zeros(m,k)
    maxrhs=max([s.degree(v,a) for v in rhs if v]+[0])
    top=max(degree+1,maxrhs)
    M=s.Matrix.vstack(*[s.Matrix.hstack(*[
        D0 if j+1==i else D1 if j+2==i else s.zeros(m,n)
        for j in range(degree)]) for i in range(1,top+1)])
    rb=s.Matrix.vstack(*[rhs.applyfunc(lambda v:s.expand(v).coeff(a,i)) for i in range(1,top+1)])
    rb[:m,:]-=D1*T0
    E,piv=DomainMatrix.from_Matrix(M.row_join(rb)).convert_to(s.QQ).rref();E=E.to_Matrix()
    if any(p>=M.cols for p in piv):return None
    sol=s.zeros(M.cols,k)
    for i,j in enumerate(piv):sol[j,:]=E[i,-k:]
    assert M*sol==rb
    T=T0.copy()
    for j in range(degree):T+=a**(j+1)*sol[n*j:n*(j+1),:]
    assert ((D0+a*D1)*T-rhs).applyfunc(s.expand)==s.zeros(m,k)
    return T

def main():
    degree=int(sys.argv[1]) if len(sys.argv)>1 else 1;start=time.time()
    a=s.symbols('a');P=point();mag=C.tensor({(2,4):x*z})
    D0=C.derivative(P,True);D1=C.derivative(mag,True)
    rec=json.loads((HERE/'universal_kernel.json').read_text())
    rv=s.Matrix.hstack(*[s.Matrix([s.sympify(v,locals={'a':a}) for v in r]) for r in rec['normal_coefficients']])
    R,S=[C.from_vector(rv[:,i]) for i in range(2)]
    rhs=-s.Matrix.hstack(C.euler_vector(C.jacobi(R)),C.euler_vector(C.polar(R,S)),C.euler_vector(C.jacobi(S)))
    hist=json.loads((HERE/'higher_jets.json').read_text())
    jets={tuple(r['multiindex']):read_tensor(r['tensor']) for r in hist['jets']}
    T0=s.Matrix.hstack(*[C.vector(jets[k]) for k in [(2,0),(1,1),(0,2)]])
    print('solve second jet degree',degree,flush=True)
    T=polynomial_solve_fixed_zero(D0,D1,rhs,T0,a,degree)
    if T is None:print('NO polynomial second jet at this degree',time.time()-start);return
    tensors=[C.from_vector(T[:,i]) for i in range(3)]
    out={'all_passed':True,'parameter':'a','degree':degree,'monomials':['u^2','uv','v^2'],
       'coefficient_columns':[[str(s.factor(v)) for v in T[:,i]] for i in range(3)],
       'second_tensors':[C.encode(Z) for Z in tensors],
       'all_universal_second_jet_identities':True,'seconds':time.time()-start}
    (HERE/'universal_second_jet.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS',out['seconds'],flush=True)

if __name__=='__main__':main()

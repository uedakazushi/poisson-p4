#!/usr/bin/env python3
"""Universal actual T16 branch and the all-order generic U1 embedded structure."""
from u1_model import *
from sympy.polys.matrices import DomainMatrix
import time

def main():
    start=time.time();a,h,eta=s.symbols('a h eta')
    ref=json.loads((HERE/'t16_reference.json').read_text())
    M=s.zeros(5)
    for key,val in ref['family'].items():
        i,j=ast.literal_eval(key)
        M[i,j]=s.sympify(val,locals=dict(zip(['t','x','y','z','w'],C.x))|{'h':h,'eta':eta})
        M[j,i]=-M[i,j]
    # eta=-2a changes the essential magnetic quotient to (1,a).
    # A polynomial fiber translation removes the two resulting gauge terms.
    G=s.Matrix([t,x,y-2*a*z,z,w+8*a*z]).jacobian(C.x)
    sub=dict(zip(C.x,G.inv()*s.Matrix(C.x)))
    F=(G*M.subs(eta,-2*a)*G.T).subs(sub,simultaneous=True).applyfunc(s.expand)
    C.pol=lambda f:{m:q for m,q in s.Poly(s.expand(f),*C.x).terms() if q}
    assert F.subs(h,0)==C.as_matrix(point(a))
    PF=C.tensor({I:F[I] for I in C.pairs})
    assert C.cubic_vector(C.jacobi(PF)).applyfunc(s.expand)==s.zeros(350,1)
    N=json.loads((HERE/'universal_kernel.json').read_text())
    normals=s.Matrix.hstack(*[s.Matrix([s.sympify(q,locals={'a':a}) for q in R]) for R in N['normal_coefficients']])
    P=point(a);A0=actual(C,P).row_join(C.vector(C.tensor({(2,4):x*z})))
    piv=rref(A0.subs(a,0))[1];A=A0[:,piv];assert A.cols==48
    B=A.row_join(normals)
    hist=json.loads((HERE/'higher_jets.json').read_text());cols=hist['elimination_columns'];free=[j for j in range(150) if j not in cols]
    H=C.vector(C.tensor({I:s.diff(F[I],h).subs(h,0) for I in C.pairs}))
    field=s.QQ.poly_ring(a)
    BM=DomainMatrix.from_Matrix(B[free,:]).convert_to(field)
    HM=DomainMatrix.from_Matrix(H[free,:]).convert_to(field)
    solnum,solden=BM.solve_den(HM);sol=solnum.to_Matrix()/field.to_sympy(solden)
    assert (B*sol-H).applyfunc(s.expand)==s.zeros(150,1)
    co=[s.factor(v) for v in sol[-2:,:]];print('actual T16 normal',co,flush=True)
    assert co==[16,0]
    actual_det=s.factor(field.to_sympy(BM.det()));assert actual_det!=0 and not actual_det.has(a)
    # The two stabilizers are independent modulo Euler for every a.
    for X in [s.Matrix([0,0,0,0,t]),s.Matrix([0,0,z,0,x])]:
        assert C.vector(C.lie(P,X)).applyfunc(s.expand)==s.zeros(150,1)
    # The quadratic quotient after factoring the actual smooth branch.
    u,v=s.symbols('u v');q1=u*u-32768*v*v;q2=v*(3*u+512*v)
    mons=[u**3,u*u*v,u*v*v,v**3]
    cubic=s.Matrix([[s.Poly(f,u,v).coeff_monomial(m) for f in [u*q1,v*q1,u*q2,v*q2]] for m in mons])
    det=cubic.det();assert det!=0
    # Exact Hilbert basis for the embedded finite length module.
    GB=s.groebner([q1,q2],u,v,order='grevlex');assert all(GB.reduce(m)[1]==0 for m in mons)
    assert all(GB.reduce(m)[1]!=0 for m in [s.S.One,u,v,v*v])
    out={'all_passed':True,'parameter':'a','generic_condition':'a != 0',
       'T16_polynomial_gauged_family':C.encode(PF),'universal_affine_Poisson':True,
       'specialization_equals_magnetic_family':True,'universal_normal_derivative':[str(q) for q in co],
       'actual_group_plus_single_modulus_and_normals_determinant':str(actual_det),
       'all_finite_parameters_have_group47_actual48_and_fullJac100':True,
       'actual_projective_hypersurface_dimension':24,
       'quadratic_quotient_generators':[str(q1),str(q2)],
       'cubic_multiplication_determinant':str(det),
       'quadratic_complete_intersection_Hilbert_function':[1,2,1],
       'generic_full_completed_local_ring':'C[[a1,...,a23,u,v]]/(v*(u^2-32768*v^2), v^2*(3*u+512*v))',
       'generic_reduced_component':'The known smooth24D T16 component only',
       'embedded_associated_prime':'(u,v)',
       'embedded_module_length':4,
       'normal_form_over_C':'C[[a1,...,a23,U,V]]/(V*(U^2-V^2), U*V^2)',
       'scope':'All-order conclusion uses the explicit actual branch and the formal division/Nakayama lemma in the accompanying proof, not finite-jet extrapolation.',
       'seconds':time.time()-start}
    (HERE/'generic_embedded_structure.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS generic embedded structure',det,time.time()-start,flush=True)

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Polynomial continuation of the two U1 normals over its magnetic modulus."""
from u1_model import *
from sympy.polys.matrices import DomainMatrix
import sys,time

def main():
    deg=int(sys.argv[1]) if len(sys.argv)>1 else 1
    start=time.time();P=point();R=normals();mag=C.tensor({(2,4):x*z})
    D0=C.derivative(P,True);D1=C.derivative(mag,True)
    assert all(D0*C.vector(r)==s.zeros(350,1) for r in R)
    blocks=[]
    for k in range(1,deg+2):
        blocks.append([D0 if j+1==k else D1 if j+2==k else s.zeros(350,150) for j in range(deg)])
    M=s.Matrix.vstack(*[s.Matrix.hstack(*row) for row in blocks])
    rhs=s.zeros(M.rows,2)
    rhs[:350,:]=-D1*s.Matrix.hstack(*[C.vector(r) for r in R])
    aug=M.row_join(rhs)
    print('solve',deg,aug.shape,flush=True)
    E,piv=DomainMatrix.from_Matrix(aug).convert_to(s.QQ).rref();E=E.to_Matrix()
    if any(j>=M.cols for j in piv):
        print('NO polynomial lift at this degree',time.time()-start,flush=True);return
    sol=s.zeros(M.cols,2)
    for i,j in enumerate(piv):sol[j,:]=E[i,-2:]
    assert M*sol==rhs
    a=s.symbols('a');rv=s.Matrix.hstack(*[C.vector(r) for r in R])
    for j in range(deg):rv+=a**(j+1)*sol[150*j:150*(j+1),:]
    assert ((D0+a*D1)*rv).applyfunc(s.expand)==s.zeros(350,2)
    C.pol=lambda f:{m:q for m,q in s.Poly(s.expand(f),*C.x).terms() if q}
    PF=point(a);A=actual_magnetic(PF)
    assert ((D0+a*D1)*A).applyfunc(s.expand)==s.zeros(350,A.cols)
    assert rk(A.subs(a,0).row_join(rv.subs(a,0)))==50
    out={'all_passed':True,'parameter':'a','magnetic_polynomial':'tz+z^2+a*xz','normal_degree':deg,
      'normal_coefficients':[[str(s.factor(b)) for b in rv[:,j]] for j in range(2)],
      'normal_tensors':[C.encode(C.from_vector(rv[:,j])) for j in range(2)],
      'universal_tangent_identity':True,'sample_actual_plus_normals_rank':50,
      'generic_full_Jacobi_rank':100,'seconds':time.time()-start,
      'basis_order':[[list(I),list(m)] for I,m in C.basis]}
    (HERE/'universal_kernel.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS',out['seconds'],flush=True)
    for q in out['normal_tensors']:print(q,flush=True)

if __name__=='__main__':main()

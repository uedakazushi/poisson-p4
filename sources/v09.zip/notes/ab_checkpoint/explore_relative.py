#!/usr/bin/env python3
from pathlib import Path
import json,pickle
import sympy as s
from sympy.polys.matrices import DomainMatrix
from ab_local_engine import Calculus,rank
HERE=Path(__file__).resolve().parent

def piv(M):return list(DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1])
def model(C,A0,mu,nu,r,ss):
    t,u,a,v,b=C.x;A=t+r*a;B=t+ss*b;k2=-s.Rational(1,8);l2=s.Rational(1,8);c11=-s.Rational(1,32)
    return C.tensor({(1,2):A*A-k2*u*u,(3,4):B*B-l2*v*v,
      (1,3):r*ss*(A0*u*v+mu*A*v/k2+nu*u*B/l2+c11*A*B/(k2*l2)),
      (1,4):r*(A0*u*B+mu*A*B/k2+nu*u*v+c11*A*v/k2),
      (2,3):ss*(A0*A*v+mu*u*v+nu*A*B/l2+c11*u*B/l2),
      (2,4):A0*A*B+mu*u*B+nu*A*v+c11*u*v})
def simple_normals(C):
    t,u,a,v,b=C.x
    R=C.tensor({(1,2):-2*a*a,(1,4):-a*(2*u+v/2),(2,4):-a*a})
    S=C.tensor({(2,3):b*(2*v-u/2),(2,4):b*b,(3,4):2*b*b})
    return R,S
def actual(C,Q):
    VV=[C.vertical(i,j) for i in range(5) for j in range(5)];OO=[]
    for i in range(5):
        for j in range(5):
            X=s.zeros(5,1);X[i]=C.x[j];OO.append(C.lie(Q,X))
    return s.Matrix.hstack(*[C.vector(Z) for Z in VV+OO+[Q]])
def main():
    C=Calculus(5);C.x=s.symbols('t u a v b');C.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*C.x).terms() if a}
    a0,mu,nu,r,ss,p,q=s.symbols('a0 mu nu r s p q');pars=(a0,mu,nu,r,ss,p,q)
    T=model(C,1+a0,mu,nu,r,ss);R,S=simple_normals(C);P=C.from_vector(C.vector(T)+p*C.vector(R)+q*C.vector(S))
    T0=C.tensor({I:C.expr(f).subs(dict.fromkeys(pars,0)) for I,f in T.items()});D=C.derivative(T0,True)
    assert not any(C.cubic_vector(C.polar(T0,R))) and not any(C.cubic_vector(C.polar(T0,S)))
    G=actual(C,T0);family=[C.vector(C.tensor({I:s.diff(C.expr(f),z).subs(dict.fromkeys(pars,0)) for I,f in T.items()})) for z in pars[:5]]
    ACT=s.Matrix.hstack(G,*family);assert rank(ACT)==50 and rank(s.Matrix.hstack(ACT,C.vector(R),C.vector(S)))==52
    print('ranks',rank(D),rank(G),rank(ACT),flush=True)
    eqs=[s.factor(v) for v in C.cubic_vector(C.jacobi(P)) if s.expand(v)!=0]
    # Span of coefficient equations over QQ, then exact Groebner basis.
    print('nonzero equations',len(eqs),flush=True)
    for e in eqs:print(e,flush=True)
    gb=s.groebner(eqs,*pars,domain=s.QQ,order='grevlex')
    print('GB',gb,flush=True)
    (HERE/'relative_linear_exploration.json').write_text(json.dumps({'rankD':rank(D),'rank_actual':rank(ACT),'normal_R':C.encode(R),'normal_S':C.encode(S),'equations':list(map(str,eqs)),'groebner_basis':[str(f.as_expr()) for f in gb.polys]},indent=2)+'\n')
if __name__=='__main__':main()

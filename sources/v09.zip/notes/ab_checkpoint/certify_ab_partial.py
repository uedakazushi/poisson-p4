#!/usr/bin/env python3
"""Limited AB v9 facts only.  No full formal-ring or branch claim is made."""
from pathlib import Path
import json
import sympy as s
from ab_local_engine import Calculus,rank
from explore_relative import model,simple_normals,actual
HERE=Path(__file__).resolve().parent

def main():
    C=Calculus(5);C.x=s.symbols('t u a v b');t,u,a,v,b=C.x
    C.pol=lambda f:{m:z for m,z in s.Poly(s.expand(f),*C.x).terms() if z}
    aa,mu,nu,r,ss,p,q=s.symbols('a0 mu nu r s p q');pars=(aa,mu,nu,r,ss,p,q)
    Q=model(C,1+aa,mu,nu,r,ss);R,S=simple_normals(C)
    assert all(s.expand(f)==0 for f in C.cubic_vector(C.jacobi(Q)))
    Q0=model(C,1,0,0,0,0);D=C.derivative(Q0,True);G=actual(C,Q0)
    F=s.Matrix.hstack(G,*[C.vector(C.tensor({I:s.diff(C.expr(f),z).subs(dict.fromkeys(pars,0)) for I,f in Q.items()})) for z in pars[:5]])
    assert [rank(D),rank(G),rank(F),rank(s.Matrix.hstack(F,C.vector(R),C.vector(S)))]==[98,45,50,52]
    assert not any(C.cubic_vector(C.polar(Q0,R))) and not any(C.cubic_vector(C.polar(Q0,S)))
    L=s.Matrix([s.I*t,v,b,-u,-a]).jacobian(C.x);old=L.inv()*s.Matrix(C.x)
    pushed=(L*C.as_matrix(Q0)*L.T).subs(dict(zip(C.x,old)),simultaneous=True).applyfunc(s.expand)
    assert pushed==-C.as_matrix(Q0)
    # This exact ideal describes ONLY the deliberately chosen polynomial
    # ansatz Q(theta)+pR+qS. It is not a versal or completed local ideal.
    PP=C.from_vector(C.vector(Q)+p*C.vector(R)+q*C.vector(S))
    equations=[s.expand(z) for z in C.cubic_vector(C.jacobi(PP)) if s.expand(z)!=0]
    ideal=[v*p for v in pars[:5]]+[v*q for v in pars[:5]]+[p*p,p*q,q*q]
    GB=s.groebner(equations,*pars,domain=s.QQ,order='grevlex')
    assert GB==s.groebner(ideal,*pars,domain=s.QQ,order='grevlex')
    samples=[]
    for c0,m0,n0,r0,s0 in [(1,0,0,0,0),(1,0,-s.Rational(3,8),0,1),
                          (2,0,-s.Rational(3,8),0,1),(2,0,-s.Rational(3,4),0,1),
                          (1,1,-s.Rational(3,8),0,1),(2,1,0,0,0)]:
        QQ=model(C,c0,m0,n0,r0,s0)
        samples.append({'c00':str(c0),'mu':str(m0),'nu':str(n0),'r':str(r0),'s':str(s0),
                        'full_Jacobi_rank':rank(C.derivative(QQ,True))})
    assert [z['full_Jacobi_rank'] for z in samples]==[98,99,100,99,100,99]
    out={'all_passed':True,'scope':'Limited exact reductions and examples; no full local-ring, branch, or nilpotence theorem.',
         'source_ranks':{'Jacobi':98,'group_vertical_scale':45,'toric_actual':50,'actual_plus_normals':52},
         'simple_normal_R':C.encode(R),'simple_normal_S':C.encode(S),
         'projective_involution':'(t,u,a,v,b)->(i*t,v,b,-u,-a), pushforward(P)=-P',
         'raw_ansatz_only':{'formula':'Q_toric(a0,mu,nu,r,s)+p*R+q*S',
                           'exact_ideal_generators':[str(z) for z in ideal],
                           'not_the_full_Kuranishi_ideal':True},
         'rank_variation_samples':samples,
         'unresolved':['full completed local ideal','unique reduced support','embedded nilpotence and its support']}
    (HERE/'ab_partial_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS limited AB v9 reductions; full local problem remains open',flush=True)

if __name__=='__main__':main()

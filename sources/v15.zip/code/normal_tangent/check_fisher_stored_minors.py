#!/usr/bin/env python3
"""Independent exact QQ[t] checker for all ten stored Fisher rank minors.

This does NOT import either matrix construction from the main verifier. It
generates the cyclic Fisher bracket directly and extracts each requested
Jacobi coefficient by exponent arithmetic. The reported minors are recomputed
over QQ[t], so this is not a finite-field rank test.
"""
from functools import lru_cache
from itertools import combinations
from pathlib import Path
import json
import sympy as s
from sympy.polys.matrices import DomainMatrix

t=s.symbols('t')


def monomials(n,d):
    if n==1:
        return [(d,)]
    return [(k,)+tail for k in range(d,-1,-1)
            for tail in monomials(n-1,d-k)]


def mon(i,j):
    return tuple(int(k==i)+int(k==j) for k in range(5))


p={}
for i in range(5):
    for step,terms in [(1,[(i,(i+1)%5,t**5-3),
                           ((i+2)%5,(i+4)%5,-10*t**3),
                           ((i+3)%5,(i+3)%5,5*t**4)]),
                       (2,[(i,(i+2)%5,-3*t**5-1),
                           ((i+3)%5,(i+4)%5,10*t**2),
                           ((i+1)%5,(i+1)%5,5*t)])]:
        j=(i+step)%5
        sign=1 if i<j else -1
        p[tuple(sorted((i,j)))]= {mon(a,b):sign*c for a,b,c in terms}

pairs=list(combinations(range(5),2))
cols=[(ij,m) for ij in pairs for m in monomials(5,2)]
rows=[('j',ijk,m) for ijk in combinations(range(5),3)
      for m in monomials(5,3)] + [
      ('d',(j,),m) for j in range(5) for m in monomials(5,1)]


def coeff(i,j,m):
    if i==j or min(m)<0:
        return 0
    return (1 if i<j else -1)*p[tuple(sorted((i,j)))].get(m,0)


@lru_cache(None)
def matrix_entry(row,col):
    typ,ijk,n=rows[row]
    pair,m=cols[col]
    if typ=='d':
        j=ijk[0]
        if j not in pair:
            return s.Integer(0)
        i=pair[1] if pair[0]==j else pair[0]
        e=list(m);e[i]-=1
        return s.Integer((1 if i<j else -1)*m[i] if tuple(e)==n else 0)
    out=0
    for i,j,k in [ijk,(ijk[1],ijk[2],ijk[0]),(ijk[2],ijk[0],ijk[1])]:
        # R_i,l * partial_l(P_j,k).
        if i in pair:
            ell=pair[1] if pair[0]==i else pair[0]
            sign=1 if i<ell else -1
            e=[n[z]-m[z] for z in range(5)]
            if min(e)>=0:
                e[ell]+=1
                out+=sign*e[ell]*coeff(j,k,tuple(e))
        # P_i,l * partial_l(R_j,k).
        if tuple(sorted((j,k)))==pair:
            sign=1 if j<k else -1
            for ell in range(5):
                if m[ell]:
                    e=[n[z]-m[z]+int(z==ell) for z in range(5)]
                    if min(e)>=0:
                        out+=sign*m[ell]*coeff(i,ell,tuple(e))
    return s.expand(out)


def main():
    target=Path(__file__).with_name('fisher_symbolic_rank.json')
    reports=json.loads(target.read_text())
    assert len(reports)==5
    checked=[]
    for block in reports:
        assert len(block['minors'])==2
        polynomials=[]
        for minor in block['minors']:
            A=s.Matrix([[matrix_entry(i,j) for j in minor['columns']]
                         for i in minor['rows']])
            computed=DomainMatrix.from_Matrix(A).convert_to(s.QQ.poly_ring(t)).det().as_expr()
            expected=s.sympify(minor['determinant'])
            assert s.expand(computed-expected)==0
            polynomials.append(s.Poly(computed,t))
        gcd=s.gcd(*polynomials).monic()
        e=[42,28,29,23,23][block['weight']]
        assert gcd==s.Poly(t**e*(t**10-11*t**5-1),t,domain=s.QQ)
        checked.append({'weight':block['weight'],
                        'minor_size':block['minors'][0]['size'],
                        'two_exact_determinants_checked':True,
                        'gcd_t_exponent':e,'remaining_factor':'t**10-11*t**5-1'})
    output={'independent_matrix_construction':True,
            'coefficient_domain':'QQ[t]',
            'all_ten_stored_determinants_match':True,
            'all_five_gcds_match':True,'blocks':checked}
    result=Path(__file__).with_suffix('.json')
    result.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps(output))


if __name__=='__main__':
    main()

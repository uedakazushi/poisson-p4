#!/usr/bin/env python3
"""Polynomial minor certificates along the Fisher P1, split by H5 weights."""
import json
import time
from pathlib import Path
import sympy as s
from sympy.polys.matrices import DomainMatrix
from fisher_tangent import *

t=s.symbols('t')


def weight(indices,m):
    return (sum(i*e for i,e in enumerate(m))-sum(indices))%5


def polynomial_determinant(A):
    dm=DomainMatrix.from_Matrix(s.Matrix(A)).convert_to(s.QQ.poly_ring(t))
    return s.factor(dm.det().as_expr())


def main():
    P=fisher(t,1)
    rows,A=canonical_tangent_matrix(P)
    A=[[s.expand(a) for a in row] for row in A]
    reports=[]
    for w in range(5):
        rr=[i for i,(_,inds,m) in enumerate(rows) if weight(inds,m)==w]
        cc=[i for i,(inds,m) in enumerate(BASIS) if weight(inds,m)==w]
        B=[[A[i][j] for j in cc] for i in rr]
        for i in rr:
            assert all(A[i][j]==0 for j in range(150) if j not in cc)
        report={'weight':w,'rows':rr,'columns':cc,'minors':[]}
        print('block',w,len(rr),len(cc),flush=True)
        running_gcd=None
        orders=[(list(range(len(rr))),list(range(len(cc)))),
                (list(reversed(range(len(rr)))),list(reversed(range(len(cc)))))]
        for order,(rorder,corder) in enumerate(orders):
            numerical=[[int(B[i][j].subs(t,1)) for j in corder] for i in rorder]
            cert=modular_certificate(numerical)
            br=[rorder[i] for i in cert['nonzero_minor_rows']]
            bc=[corder[j] for j in cert['nonzero_minor_columns']]
            start=time.time()
            det=polynomial_determinant([[B[i][j] for j in bc] for i in br])
            running_gcd=s.Poly(det,t).monic() if running_gcd is None else s.gcd(running_gcd,s.Poly(det,t)).monic()
            print('det',w,order,'seconds',time.time()-start,'gcd',s.factor(running_gcd.as_expr()),flush=True)
            report['minors'].append({'selection_order':order,'size':len(br),
                'rows':[rr[i] for i in br],'columns':[cc[j] for j in bc],
                'determinant':str(det)})
        report['minor_gcd']=str(s.factor(running_gcd.as_expr()))
        exponent=[42,28,29,23,23][w]
        assert s.expand(running_gcd.as_expr()-t**exponent*(t**10-11*t**5-1))==0
        report['gcd_certificate']={'t_exponent':exponent,
                                   'remaining_factor':'t**10-11*t**5-1',
                                   'identity_checked_exactly':True}
        reports.append(report)
        Path(__file__).with_name('fisher_symbolic_rank.json').write_text(json.dumps(reports,indent=2)+'\n')


if __name__=='__main__':
    main()

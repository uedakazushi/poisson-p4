#!/usr/bin/env python3
"""Characteristic-zero kernel/upper-bound and boundary certificates.

Run with SymPy on PYTHONPATH. No finite-field sampling is promoted to a
characteristic-zero assertion: exact kernel vectors provide the upper bounds,
and nonzero integer minors reduced modulo PRIME provide the lower bounds.
"""
from pathlib import Path
import json
import sympy as s
from fisher_tangent import *


def exact_kernel_certificate(matrix):
    M=s.Matrix(matrix)
    null=M.nullspace()
    K=s.Matrix.hstack(*null) if null else s.zeros(M.cols,0)
    assert M*K==s.zeros(M.rows,K.cols)
    integer_columns=[]
    for v in null:
        den=s.ilcm(*(z.q for z in v))
        integer_columns.append([int(z*den) for z in v])
    cert=modular_certificate(matrix,upper_bound=M.cols-len(null))
    cert['exact_integer_kernel_columns']=integer_columns
    cert['kernel_dimension']=len(null)
    return cert


def main():
    a,b=s.symbols('a b')
    family=fisher(a,b)
    # Expand parameter-polynomial identities before checking for zero.
    assert all(s.expand(c)==0 for p in jacobi(family).values() for c in p.values())
    assert all(s.expand(c)==0 for p in divergence(family) for c in p.values())
    familyF=quintic(family)
    for i,g in enumerate(pfaff(family)):
        assert all(s.expand(c)==0 for c in add(diff(familyF,i),scale(g,-1)).values())
    P=fisher(1,1)
    _,A=canonical_tangent_matrix(P)
    P_a={ij:{m:int(s.diff(c,a).subs({a:1,b:1})) for m,c in p.items()}
         for ij,p in family.items()}
    P_b={ij:{m:int(s.diff(c,b).subs({a:1,b:1})) for m,c in p.items()}
         for ij,p in family.items()}
    dirs=[vec(orbit_derivative(P,i,j)) for i in range(5) for j in range(5)] + [vec(P_a),vec(P_b)]
    K=list(map(list,zip(*dirs)))
    assert s.Matrix(A)*s.Matrix(K)==s.zeros(375,27)
    dcert=modular_certificate(K,upper_bound=26)
    pcert=modular_certificate(A,upper_bound=124)
    # The exact kernel family plus its rank26 minor establishes rankA<=124.
    witness=dict(parameters=[1,1],canonical_matrix=pcert,
                 orbit_and_parameter_kernel_matrix=K,
                 orbit_and_parameter_kernel_rank=dcert,
                 affine_tangent_dimension=26,projective_tangent_dimension=25)
    _,I=incidence_matrix(P)
    icert=exact_kernel_certificate(I)
    assert icert['rank_over_Q']==249
    witness['incidence_matrix']=icert
    # A cusp is a special rank4 logcanonical bracket; it is outside normality.
    cusp=fisher(0,1)
    _,C=canonical_tangent_matrix(cusp)
    ccert=exact_kernel_certificate(C)
    assert ccert['rank_over_Q']==119
    _,CI=incidence_matrix(cusp)
    cicert=exact_kernel_certificate(CI)
    assert cicert['rank_over_Q']==244
    kernel_matrix=[row[:150] for row in CI]
    kmcert=exact_kernel_certificate(kernel_matrix)
    assert kmcert['rank_over_Q']==144
    # Verify all fixed-divisor annihilators are automatically canonical here.
    divrows=canonical_tangent_matrix(cusp)[1][350:]
    for v in kmcert['exact_integer_kernel_columns']:
        assert s.Matrix(divrows)*s.Matrix(v)==s.zeros(25,1)
    fixed_basis=kmcert['exact_integer_kernel_columns']
    z=s.symbols('z0:6')
    fixed_P={ij:{m:sum(z[k]*fixed_basis[k][i] for k in range(6))
                  for i,(ij2,m) in enumerate(BASIS) if ij2==ij}
             for ij in PAIRS}
    f=[diff(quintic(cusp),i) for i in range(5)]
    pf=pfaff(fixed_P)
    index=next((i,m) for i in range(5) for m,c in f[i].items() if c)
    i,m=index
    q=s.expand(pf[i].get(m,0)/f[i][m])
    for j in range(5):
        assert all(s.expand(c)==0 for c in add(pf[j],scale(f[j],-q)).values())
    hess=s.hessian(q,z)
    assert hess.rank()==6
    boundary=dict(parameters=[0,1],canonical_matrix=ccert,
                  incidence_matrix=cicert,annihilator=kmcert,
                  affine_tangent_dimension=31,projective_tangent_dimension=30,
                  fixed_divisor_V_dimension=6,fixed_divisor_quadratic=str(q),
                  fixed_divisor_quadratic_rank=6,
                  warning='Not in the normal-quintic open. At rankM144, the maximal-minor scheme has full ambient tangent; incidence tangent is a different object.')
    out=dict(exact_symbolic_family_Jacobi=True,exact_symbolic_family_divergence=True,
             exact_symbolic_family_Pfaffian_gradient=True,
             witness=witness,boundary=boundary)
    path=Path(__file__).with_name('fisher_exact_certificates.json')
    path.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'passed':True,'witness_rank':124,'boundary_rank':119,
                      'incidence_rank':249,'boundary_Vdim':6,'boundary_qrank':6,
                      'output':str(path)}))


if __name__=='__main__':
    main()

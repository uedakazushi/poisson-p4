#!/usr/bin/env python3
"""Exact Fisher-family Poisson and determinantal tangent calculations.

Standalone algebra, no imports from earlier versions. All coefficient operations
are exact. Monomial order is reverse lexicographic in exponent vectors.
Source of the family: T. Fisher, Invariants for the elliptic normal quintic,
equations (38)-(39), https://www.dpmms.cam.ac.uk/~taf1000/papers/invenq.pdf .
"""
from fractions import Fraction
from itertools import combinations
from pathlib import Path
import json
import numpy as np

N = 5
PAIRS = list(combinations(range(5), 2))
TRIPLES = list(combinations(range(5), 3))
PRIME = 1000003


def mons(degree, n=5):
    if n == 1:
        return [(degree,)]
    return [(i,) + q for i in range(degree, -1, -1)
            for q in mons(degree - i, n-1)]


MONS = {d: mons(d) for d in range(7)}
BASIS = [(ij, m) for ij in PAIRS for m in MONS[2]]
BINDEX = {v: i for i, v in enumerate(BASIS)}
X = [{tuple(int(i == j) for j in range(5)): 1} for i in range(5)]


def clean(p):
    return {m: c for m, c in p.items() if c != 0}


def add(*ps):
    out = {}
    for p in ps:
        for m, c in p.items():
            out[m] = out.get(m, 0) + c
    return clean(out)


def scale(p, c):
    return clean({m: a*c for m, a in p.items()})


def mul(p, q):
    out = {}
    for m, a in p.items():
        for n, b in q.items():
            e = tuple(i+j for i, j in zip(m, n))
            out[e] = out.get(e, 0) + a*b
    return clean(out)


def diff(p, i):
    out = {}
    for m, a in p.items():
        if m[i]:
            e = list(m)
            e[i] -= 1
            out[tuple(e)] = a*m[i]
    return clean(out)


def fisher(a=1, b=1):
    alpha = [add(scale(mul(X[i], X[i]), 5*a**4*b),
                 scale(mul(X[(i-1)%5], X[(i+1)%5]), -10*a**3*b**2),
                 scale(mul(X[(i-2)%5], X[(i+2)%5]), a**5-3*b**5))
             for i in range(5)]
    beta = [add(scale(mul(X[i], X[i]), 5*a*b**4),
                scale(mul(X[(i-1)%5], X[(i+1)%5]), -3*a**5-b**5),
                scale(mul(X[(i-2)%5], X[(i+2)%5]), 10*a**2*b**3))
            for i in range(5)]
    return {(0,1):alpha[3], (0,2):beta[1], (0,3):scale(beta[4],-1),
            (0,4):scale(alpha[2],-1), (1,2):alpha[4], (1,3):beta[2],
            (1,4):scale(beta[0],-1), (2,3):alpha[0],
            (2,4):beta[3], (3,4):alpha[1]}


def entry(p, i, j):
    if i < j:
        return p.get((i,j), {})
    if i > j:
        return scale(p.get((j,i), {}), -1)
    return {}


def vec(p):
    return [p.get(ij, {}).get(m, 0) for ij, m in BASIS]


def pfaff(p):
    result=[]
    for i in range(5):
        a,b,c,d=[j for j in range(5) if j != i]
        result.append(scale(add(mul(entry(p,a,b),entry(p,c,d)),
                                scale(mul(entry(p,a,c),entry(p,b,d)),-1),
                                mul(entry(p,a,d),entry(p,b,c))), (-1)**i))
    return result


def quintic(p):
    f=pfaff(p)
    return scale(add(*(mul(X[i],f[i]) for i in range(5))), Fraction(1,5))


def jacobi(p, r=None):
    # r absent: the quadratic Jacobi tensor; r present: its polarization.
    out={}
    for ijk in TRIPLES:
        terms=[]
        for i,j,k in [ijk,(ijk[1],ijk[2],ijk[0]),(ijk[2],ijk[0],ijk[1])]:
            for ell in range(5):
                terms.append(mul(entry(p,i,ell),diff(entry(p if r is None else r,j,k),ell)))
                if r is not None:
                    terms.append(mul(entry(r,i,ell),diff(entry(p,j,k),ell)))
        out[ijk]=add(*terms)
    return out


def divergence(p):
    return [add(*(diff(entry(p,i,j),i) for i in range(5))) for j in range(5)]


def canonical_tangent_matrix(p):
    rows=[('jac',ijk,m) for ijk in TRIPLES for m in MONS[3]] + [
        ('div',(i,),m) for i in range(5) for m in MONS[1]]
    out=[]
    for ij,m in BASIS:
        r={ij:{m:1}}
        jp=jacobi(p,r)
        dv=divergence(r)
        out.append([jp[ijk].get(e,0) if typ=='jac' else dv[ijk[0]].get(e,0)
                    for typ,ijk,e in rows])
    return rows, list(map(list,zip(*out)))


def incidence_matrix(p):
    F=quintic(p)
    f=[diff(F,i) for i in range(5)]
    rows=[(i,m) for i in range(5) for m in MONS[6]]
    rindex={v:j for j,v in enumerate(rows)}
    A=[[0]*276 for _ in rows]
    for col,((i,j),m) in enumerate(BASIS):
        for k,poly,sgn in [(i,f[j],1),(j,f[i],-1)]:
            for n,c in poly.items():
                e=tuple(a+b for a,b in zip(n,m))
                A[rindex[k,e]][col] += sgn*c
    for c,m in enumerate(MONS[5]):
        G={m:1}
        for i in range(5):
            poly=add(*(mul(entry(p,i,j),diff(G,j)) for j in range(5)))
            for e,a in poly.items():
                A[rindex[i,e]][150+c]=a
    return rows,A


def orbit_derivative(p,i,j):
    # Lie derivative L_(x_j d_i) P. Euler i=j sum acts trivially.
    out={}
    for a,b in PAIRS:
        terms=[mul(X[j],diff(entry(p,a,b),i))]
        if a == i:
            terms.append(scale(entry(p,j,b),-1))
        if b == i:
            terms.append(scale(entry(p,a,j),-1))
        out[a,b]=add(*terms)
    return out


def modular_certificate(A,p=PRIME,upper_bound=None):
    a=np.array(A,dtype=np.int64)%p
    original=np.array(A,dtype=np.int64)%p
    ids=list(range(len(A)))
    rr=[];cc=[];rank=0
    for c in range(a.shape[1]):
        cand=np.flatnonzero(a[rank:,c])
        if not len(cand):
            continue
        r=rank+int(cand[0])
        if r != rank:
            a[[rank,r]]=a[[r,rank]]
            ids[rank],ids[r]=ids[r],ids[rank]
        rr.append(ids[rank]);cc.append(c)
        inv=pow(int(a[rank,c]),-1,p)
        a[rank]=a[rank]*inv%p
        lower=np.flatnonzero(a[rank+1:,c])+rank+1
        a[lower]=(a[lower]-a[lower,c,None]*a[rank][None,:])%p
        rank+=1
        if rank == min(a.shape):
            break
    minor=original[np.ix_(rr,cc)]
    det=1
    for c in range(rank):
        cand=np.flatnonzero(minor[c:,c])
        r=c+int(cand[0])
        if r!=c:
            minor[[c,r]]=minor[[r,c]];det=-det
        z=int(minor[c,c]);det=det*z%p
        if c+1<rank:
            fac=minor[c+1:,c]*pow(z,-1,p)%p
            minor[c+1:]=(minor[c+1:]-fac[:,None]*minor[c][None,:])%p
    out=dict(shape=list(original.shape),prime=p,rank_mod_prime=rank,
             nonzero_minor_rows=rr,nonzero_minor_columns=cc,
             minor_determinant_mod_prime=int(det%p))
    if upper_bound is not None:
        assert rank==upper_bound
        out['rank_over_Q']=rank
    return out


def check_numeric(a=1,b=1):
    P=fisher(a,b);F=quintic(P)
    assert all(diff(F,i)==pfaff(P)[i] for i in range(5))
    assert all(not q for q in jacobi(P).values())
    assert all(not q for q in divergence(P))
    rows,A=canonical_tangent_matrix(P)
    cert=modular_certificate(A)
    print('canonical',a,b,cert['rank_mod_prime'],flush=True)
    _,I=incidence_matrix(P)
    icert=modular_certificate(I)
    mcert=modular_certificate([r[:150] for r in I])
    print('incidence',a,b,icert['rank_mod_prime'],'annihilator',mcert['rank_mod_prime'],flush=True)
    return dict(a=a,b=b,canonical_poisson_tangent=cert,
                determinantal_incidence_tangent=icert,annihilator=mcert,
                quintic_terms=[[list(m),int(c)] for m,c in sorted(F.items(),reverse=True)])


if __name__=='__main__':
    out=[check_numeric(1,1),check_numeric(0,1),check_numeric(1,0)]
    path=Path(__file__).with_name('fisher_tangent_numeric.json')
    path.write_text(json.dumps(out,indent=2)+'\n')
    print(path)

#!/usr/bin/env python3
"""Verify all bundled files and the untouched v14 history; writes nothing."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    expected = {}
    for line in (ROOT / 'SHA256SUMS.txt').read_text().splitlines():
        digest, rel = line.split('  ', 1)
        expected[rel] = digest
    actual = {str(p.relative_to(ROOT)): sha256(p) for p in ROOT.rglob('*')
              if p.is_file() and p != ROOT / 'SHA256SUMS.txt'
              and '__pycache__' not in p.parts and p.suffix != '.pyc'}
    assert actual == expected, 'Current bundle differs from SHA256SUMS.txt'
    history = json.loads((ROOT / 'data/previous_v14_preservation.json').read_text())
    archive = ROOT / 'previous_v14'
    old = {str(p.relative_to(archive)): sha256(p)
           for p in archive.rglob('*') if p.is_file()}
    assert old == history['files'], 'v14 history differs from the preservation record'
    assert len(old) == history['file_count'] == 1054
    print(json.dumps({'all_files_verified': len(actual), 'historical_files_verified': len(old),
                      'all_passed': True}, indent=2))


if __name__ == '__main__':
    main()

"""Exact H5-invariant Poisson equations and projective family certificates."""
import itertools, json
from pathlib import Path
import sympy as s

OUT=Path(__file__).resolve().parent
x=s.symbols('x0:5')
a,b,c,d,e,f=s.symbols('a b c d e f')
v=(a,b,c,d,e,f)
P=s.zeros(5)
for i in range(5):
    j=(i+1)%5
    P[i,j]=a*x[i]*x[j]+b*x[(i+2)%5]*x[(i+4)%5]+c*x[(i+3)%5]**2
    P[j,i]=-P[i,j]
    j=(i+2)%5
    P[i,j]=d*x[i]*x[j]+e*x[(i+3)%5]*x[(i+4)%5]+f*x[(i+1)%5]**2
    P[j,i]=-P[i,j]

def primitive(p):
    return s.Poly(p,*v).clear_denoms()[1].primitive()[1].monic().as_expr()

def pfaff(M):
    return M[0,1]*M[2,3]-M[0,2]*M[1,3]+M[0,3]*M[1,2]

if __name__=='__main__':
    div=[s.expand(sum(s.diff(P[i,j],x[i]) for i in range(5))) for j in range(5)]
    assert div==[0]*5
    jac=[]
    for i,j,k in itertools.combinations(range(5),3):
        J=s.expand(sum(P[i,l]*s.diff(P[j,k],x[l])+P[j,l]*s.diff(P[k,i],x[l])+P[k,l]*s.diff(P[i,j],x[l]) for l in range(5)))
        jac.extend(s.Poly(J,*x).coeffs())
    eqs=sorted(set(primitive(q) for q in jac if q!=0),key=str)
    print('Distinct primitive Jacobi coefficients',eqs,flush=True)
    G=s.groebner(eqs,*v,order='grevlex')
    print('Groebner basis length',len(G.polys),flush=True)
    print([str(g.as_expr()) for g in G.polys],flush=True)
    l=s.symbols('l')
    families={
      'q51':[(1-3*l**5)/5,-2*l**2,l,(-3-l**5)/5,2*l**3,l**4],
      'q52':[(1+2*l**5)/5,l**4,-l**2,(2-l**5)/5,-l,l**3],
      'line':[(2-l)/2,l,-(l+2)/2,(l+2)/2,-2,(2-l)/2],
      'toric':[1,0,0,l,0,0]
    }
    for name,values in families.items():
        residual=[s.factor(q.subs(dict(zip(v,values)))) for q in eqs]
        print(name,residual,flush=True)
    pf=[s.expand((-1)**i*pfaff(P.minor_submatrix(i,i))) for i in range(5)]
    F=s.expand(sum(x[i]*pf[i] for i in range(5))/5)
    grad_res=[s.Poly(s.diff(F,x[i])-pf[i],*x).coeffs() for i in range(5)]
    assert all(G.reduce(q)[1]==0 for row in grad_res for q in row)
    rank2eqs=sorted(set(primitive(q) for p in pf for q in s.Poly(p,*x).coeffs() if q!=0),key=str)
    print('rank2 equations',rank2eqs,flush=True)
    OUT.joinpath('derived.json').write_text(json.dumps({
       'coordinates':[str(z) for z in v],
       'jacobi_coefficients':[str(z) for z in eqs],
       'grevlex_basis':[str(g.as_expr()) for g in G.polys],
       'families':{n:[str(z) for z in val] for n,val in families.items()},
       'quintic':str(F),
       'rank2_coefficients':[str(z) for z in rank2eqs]
    },indent=2))

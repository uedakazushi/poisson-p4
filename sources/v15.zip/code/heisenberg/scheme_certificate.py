"""Exact complete-scheme certificate for the strict H5-invariant section."""
import itertools, json, math
from pathlib import Path
import sympy as s
from derive_heisenberg import x,v,a,b,c,d,e,f,P,pfaff
OUT=Path(__file__).resolve().parent
Q=[a*b+2*b*d-2*c*c-e*f,3*a*c+b*f+c*d+e*e,2*a*e+b*c-d*e+2*f*f,a*f-b*b+c*e-3*d*f]

def monomials(n,k):
    if k==1:
        yield (n,)
    else:
        for i in range(n+1):
            for m in monomials(n-i,k-1): yield (i,)+m

def groebner_info(eqs,vs,maxdeg=9):
    G=s.groebner(eqs,*vs,order='grevlex')
    LM=[tuple(g.LM(order=G.order).exponents) for g in G.polys]
    dim=max(sum(mask) for mask in itertools.product([0,1],repeat=len(vs))
          if all(any(m[i] and not mask[i] for i in range(len(vs))) for m in LM))
    H=[sum(not any(all(m[i]>=u[i] for i in range(len(vs))) for u in LM) for m in monomials(n,len(vs))) for n in range(maxdeg+1)]
    # Exact Hilbert series by inclusion-exclusion on the lcm lattice.
    lattice={(0,)*len(vs):1}
    for m in LM:
        updated=lattice.copy()
        for n,k in lattice.items():
            lcm=tuple(max(n[i],m[i]) for i in range(len(vs)))
            updated[lcm]=updated.get(lcm,0)-k
        lattice={n:k for n,k in updated.items() if k}
    t=s.symbols('t')
    numerator=sum(k*t**sum(n) for n,k in lattice.items())
    series=s.factor(numerator/(1-t)**len(vs))
    return G,{'dimension':dim,'leading_monomials':LM,'hilbert_function':H,
              'hilbert_series':str(series)}

def subst(q,vals): return s.expand(q.subs(dict(zip(v,vals)), simultaneous=True))

if __name__=='__main__':
    G,info=groebner_info(Q,v)
    assert info['dimension']==2
    assert info['hilbert_function']==[1,6,17,32,48,64,80,96,112,128]
    p,q,z,u,w=s.symbols('p q z u w')
    C1=[q**5-3*p**5,-10*p*p*q**3,5*p*q**4,-3*q**5-p**5,10*p**3*q*q,5*p**4*q]
    C2=[q**5+2*p**5,5*p**4*q,-5*p*p*q**3,2*q**5-p**5,-5*p*q**4,5*p**3*q*q]
    L0=[u,0,0,w,0,0]
    Lz=[2*u-w,2*w*z,-(2*u+w)*z**3,2*u+w,-4*u*z**4,(2*u-w)*z**2]
    for name,V in [('C1',C1),('C2',C2),('L0',L0),('Lz',Lz)]:
        residual=[s.rem(subst(r,V),z**5-1,z) for r in Q]
        assert residual==[0]*4,(name,residual)
    mon5=[p**i*q**(5-i) for i in range(6)]
    mats=[s.Matrix([[s.Poly(t,p,q).coeff_monomial(m) for m in mon5] for t in V]) for V in [C1,C2]]
    assert all(M.det()!=0 for M in mats)
    info.update({'curve_matrices_determinants':[str(M.det()) for M in mats],
                 'C1':[str(t) for t in C1], 'C2':[str(t) for t in C2],
                 'L0':[str(t) for t in L0], 'Lz':[str(t) for t in Lz]})
    pf=[s.expand((-1)**i*pfaff(P.minor_submatrix(i,i))) for i in range(5)]
    F=s.expand(sum(x[i]*pf[i] for i in range(5))/5)
    r2eq=[t for pfj in pf for t in s.Poly(pfj,*x).coeffs()]
    G2,r2info=groebner_info(Q+r2eq,v)
    assert r2info['hilbert_series']=='-(t + 1)*(t**2 + 4*t + 1)/(t - 1)'
    print('CI',info,flush=True)
    print('Rank2',r2info,flush=True)
    info['rank2']=r2info
    F52=s.factor(subst(F,[3,5,-5,1,-5,5]))
    F51=s.factor(subst(F,[-2,-10,5,-4,10,5]))
    print('F52',F52,flush=True)
    print('F51',F51,flush=True)
    info['F52']=str(F52)
    info['F51']=str(F51)
    J52=[s.diff(F52,t) for t in x]
    J51=[s.diff(F51,t) for t in x]
    for name,J in [('52',J52),('51',J51)]:
        GB,Jinfo=groebner_info(J,x,maxdeg=9)
        print('J'+name,Jinfo,flush=True)
        info['J'+name]=Jinfo
    OUT.joinpath('scheme_certificate.json').write_text(json.dumps(info,indent=2))

"""Compute exact full quadratic Casimir syzygies for an explicit q52 quintic."""
import itertools,json,time
from pathlib import Path
import sympy as s
from derive_heisenberg import x,v,P,pfaff
from scheme_certificate import subst,monomials
OUT=Path(__file__).resolve().parent

if __name__=='__main__':
    P52=P.subs(dict(zip(v,[3,5,-5,1,-5,5])))
    pf=[s.expand((-1)**i*pfaff(P52.minor_submatrix(i,i))) for i in range(5)]
    F=s.expand(sum(x[i]*pf[i] for i in range(5))/5)
    assert all(s.diff(F,x[i])==pf[i] for i in range(5))
    squarefree=(s.Poly(s.gcd(F,s.diff(F,x[0])),*x).total_degree()==0)
    print('squarefree',squarefree,flush=True)
    pairs=list(itertools.combinations(range(5),2))
    m2=list(monomials(2,5));m6=list(monomials(6,5));m1=list(monomials(1,5))
    columns=[(i,j,m) for i,j in pairs for m in m2]
    m6_index={m:k for k,m in enumerate(m6)}
    m1_index={m:k for k,m in enumerate(m1)}
    rows={}
    for k,(i,j,m) in enumerate(columns):
        for r,g,sign in [(i,pf[j],1),(j,pf[i],-1)]:
            for n,c in s.Poly(g,*x).terms():
                deg=tuple(m[t]+n[t] for t in range(5))
                rows[(r*len(m6)+m6_index[deg],k)]=sign*c
        for r,der,sign in [(j,i,1),(i,j,-1)]:
            if m[der]:
                n=tuple(m[t]-(t==der) for t in range(5))
                rows[(5*len(m6)+r*len(m1)+m1_index[n],k)]=sign*m[der]
    mat=s.MutableSparseMatrix(5*len(m6)+25,len(columns),rows)
    print('matrix shape',mat.shape,'nnz',len(rows),flush=True)
    ns=mat.nullspace()
    print('V_F dimension',len(ns),flush=True)
    assert all(mat*b==s.zeros(mat.rows,1) for b in ns)
    pin=s.Matrix([s.Poly(P52[i,j],*x).coeff_monomial(m) for i,j,m in columns])
    assert mat*pin==s.zeros(mat.rows,1)
    K=mat[:5*len(m6),:]
    ks=K.nullspace()
    print('K_F dimension without divergence',len(ks),flush=True)
    OUT.joinpath('q52_fiber.json').write_text(json.dumps({
       'witness':[3,5,-5,1,-5,5], 'quintic':str(F), 'squarefree':squarefree,
       'V_F_dimension':len(ns), 'K_F_dimension':len(ks),
       'matrix_rows':mat.rows, 'matrix_cols':mat.cols,
       'V_F_basis':[[str(c) for c in z] for z in ns]
    },indent=2))

"""Exact scheme intersections and rank-two scheme for the H5 section."""
import json
from pathlib import Path
import sympy as s
from derive_heisenberg import x,v,a,b,c,d,e,f,P,pfaff
from scheme_certificate import Q,subst,groebner_info
OUT=Path(__file__).resolve().parent
p,q,u,w=s.symbols('p q u w')
C1=[q**5-3*p**5,-10*p*p*q**3,5*p*q**4,-3*q**5-p**5,10*p**3*q*q,5*p**4*q]
C2=[q**5+2*p**5,5*p**4*q,-5*p*p*q**3,2*q**5-p**5,-5*p*q**4,5*p**3*q*q]
L0=[u,0,0,w,0,0]
L1=[2*u-w,2*w,-(2*u+w),2*u+w,-4*u,2*u-w]

def curve_ideal(C):
    M=s.Matrix([[s.Poly(t,p,q).coeff_monomial(p**i*q**(5-i)) for i in range(6)] for t in C])
    y=M.inv()*s.Matrix(v)
    return [s.factor(y[i]*y[j+1]-y[i+1]*y[j]) for i in range(5) for j in range(i+1,5)]

def pullback_gcd(eqs,V):
    return s.factor(s.gcd_list([subst(r,V) for r in eqs]))

if __name__=='__main__':
    I1,I2=curve_ideal(C1),curve_ideal(C2)
    info={}
    for name,I,V in [('C1_C2',I1,C2),('C2_C1',I2,C1),('C1_L0',I1,L0),('C2_L0',I2,L0),('C1_L1',I1,L1),('C2_L1',I2,L1)]:
        g=pullback_gcd(I,V)
        info[name]=str(g)
        print(name,g,flush=True)
    # A pair of diagonal twists of L1 cannot meet: a,d identify u,w,
    # while nontrivial z shifts force b=c=e=f=0, impossible on L1.
    # L0 meets L1 only if its last four designated coordinates vanish,
    # also impossible.
    # Pullback of Pfaffian coefficients detects rank two scheme.
    pf=[s.expand((-1)**i*pfaff(P.minor_submatrix(i,i))) for i in range(5)]
    r2=[t for pj in pf for t in s.Poly(pj,*x).coeffs()]
    for name,V in [('C1',C1),('C2',C2),('L0',L0),('L1',L1)]:
        g=pullback_gcd(r2,V)
        info['rank2_'+name]=str(g)
        print('rank2_'+name,g,flush=True)
    # The rank-two ideal is saturated: a+d avoids its twelve points,
    # and quotient by a+d has length twelve, equal to degree.
    _,artinian=groebner_info(Q+r2+[a+d],v,maxdeg=5)
    assert artinian['dimension']==0
    assert artinian['hilbert_function']==[1,5,5,1,0,0]
    info['rank2_artinian_reduction']=artinian
    # Pullback of the five twisted toric lines gives the ten finite cusps.
    M=s.Matrix([L1]).jacobian([u,w])
    line_ideal=[(vec.T*s.Matrix(v))[0] for vec in M.T.nullspace()]
    for name,C in [('C1',C1),('C2',C2)]:
        g=pullback_gcd(line_ideal,C)
        assert s.expand(g-(p*p+p*q-q*q))==0
        info['cusps_on_'+name+'_over_L1']=str(g)
    # Degeneracy on the toric lines is a fixed reduced pentahedron.
    F=s.expand(sum(x[i]*pf[i] for i in range(5))/5)
    assert s.expand(subst(F,L0)-(u*u-u*w-w*w)*s.prod(x))==0
    z=s.symbols('z')
    fourier=s.rem(s.prod(sum(z**(i*j)*x[j] for j in range(5)) for i in range(5)),z**4+z**3+z*z+z+1,z).expand()
    assert s.expand(subst(F,L1)-(4*u*u-w*w)*fourier/5)==0
    info['L0_degeneracy_factor']='u^2-u*w-w^2'
    info['L1_degeneracy_factor']='(4*u^2-w^2)/5'
    info['L1_pentahedron']='product_i(sum_j(zeta^(i*j)*x_j)), zeta primitive5'
    # Rank at all C1/2 intersections of L0 is three, giving nodes.
    Jac=s.Matrix(Q).jacobian(v)
    for name,V in [('C1q',[1,0,0,-3,0,0]),('C1p',[-3,0,0,-1,0,0]),('C2q',[1,0,0,2,0,0]),('C2p',[2,0,0,-1,0,0])]:
        rank=Jac.subs(dict(zip(v,V))).rank()
        info['jacobi_jacobian_rank_'+name]=rank
        print('Jacobi rank',name,rank,flush=True)
    OUT.joinpath('intersections.json').write_text(json.dumps(info,indent=2))

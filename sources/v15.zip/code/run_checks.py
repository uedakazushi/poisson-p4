#!/usr/bin/env python3
"""Reproduce v15 exact certificates without changing any archived source.

Run from any directory: python3 code/run_checks.py
Optional: --output /absolute/path --jobs 4
Requires the versions in requirements.txt. The history is byte-checked separately.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


PACKAGE = Path(__file__).resolve().parents[1]
CASES = [
    ("reduced_divisor_examples", "reduced_fibers/verify_reduced_examples.py", [],
     "reduced_fibers/verify_reduced_examples.json", "code/reduced_fibers/verify_reduced_examples.json"),
    ("heisenberg_jacobi_ideal", "heisenberg/derive_heisenberg.py", [],
     "heisenberg/derived.json", "code/heisenberg/derived.json"),
    ("heisenberg_complete_intersection", "heisenberg/scheme_certificate.py", [],
     "heisenberg/scheme_certificate.json", "code/heisenberg/scheme_certificate.json"),
    ("heisenberg_all_intersections", "heisenberg/intersections.py", [],
     "heisenberg/intersections.json", "code/heisenberg/intersections.json"),
    ("nonnormal_singleton_fiber", "heisenberg/q52_fiber.py", [],
     "heisenberg/q52_fiber.json", "code/heisenberg/q52_fiber.json"),
    ("fisher_exact_tangents", "normal_tangent/fisher_exact_certificates.py", [],
     "normal_tangent/fisher_exact_certificates.json", "code/normal_tangent/fisher_exact_certificates.json"),
    ("fisher_uniform_polynomial_minors", "normal_tangent/fisher_symbolic_rank.py", [],
     "normal_tangent/fisher_symbolic_rank.json", "code/normal_tangent/fisher_symbolic_rank.json"),
    ("fisher_independent_minors", "normal_tangent/check_fisher_stored_minors.py", [],
     "normal_tangent/check_fisher_stored_minors.json", "code/normal_tangent/check_fisher_stored_minors.json"),
    ("rational_quartic_affine_slices", "normal_geometry/rnc4_slices.py", [],
     "normal_geometry/rnc4_slices.json", "code/normal_geometry/rnc4_slices.json"),
    ("rational_quartic_quadratic_reduction", "normal_geometry/reduce_rnc4_equations.py", [],
     "normal_geometry/rnc4_equation_reduction.json", "code/normal_geometry/rnc4_equation_reduction.json"),
    ("rational_quartic_independent_check", "normal_geometry/verify_rnc4_slices.py", [],
     "normal_geometry/rnc4_independent_verification.json", "code/normal_geometry/rnc4_independent_verification.json"),
]


def execute_case(case, output):
    name, script, args, generated_path, expected_path = case
    started = time.monotonic()
    with tempfile.TemporaryDirectory(prefix=f"p4_v15_{name}_") as tmp:
        work = Path(tmp)
        shutil.copytree(PACKAGE / "code", work, dirs_exist_ok=True,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        result = subprocess.run([sys.executable, str(work / script), *args], cwd=work,
                                env=env, capture_output=True, text=True)
        (output / f"{name}.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        record = {"name": name, "script": script, "exit_code": result.returncode,
                  "seconds": round(time.monotonic() - started, 3)}
        try:
            if result.returncode:
                raise RuntimeError(f"exit code {result.returncode}")
            raw = (work / generated_path).read_text() if generated_path else result.stdout
            actual, expected = json.loads(raw), json.loads((PACKAGE / expected_path).read_text())
            if actual != expected:
                raise AssertionError("certificate differs from the archived exact result")
            destination = output / "outputs" / f"{name}.json"
            destination.write_text(json.dumps(actual, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            record.update(passed=True, exact_json_equal=True,
                          source_sha256=hashlib.sha256((PACKAGE / "code" / script).read_bytes()).hexdigest())
        except Exception as exc:
            record.update(passed=False, error=str(exc))
        return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=PACKAGE / "data/reproduced")
    parser.add_argument("--jobs", type=int, default=4)
    args = parser.parse_args()
    output = args.output.resolve()
    (output / "outputs").mkdir(parents=True, exist_ok=True)
    results = []
    with ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        futures = [pool.submit(execute_case, case, output) for case in CASES]
        for future in as_completed(futures):
            record = future.result()
            results.append(record)
            print(f"{record['name']}: {'PASS' if record['passed'] else 'FAIL'}", flush=True)
    order = {case[0]: i for i, case in enumerate(CASES)}
    results.sort(key=lambda record: order[record['name']])
    summary = {"all_passed": all(r["passed"] for r in results), "number_of_checks": len(results),
               "python_version": sys.version.split()[0], "checks": results,
               "scope": "Exact polynomial identities, full-scheme section certificates, uniform polynomial minors and the two unsolved RNC4 slices; scope is explained in the manuscript."}
    (output / "verification_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"all_passed": summary["all_passed"], "number_of_checks": len(results)}), flush=True)
    if not summary["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

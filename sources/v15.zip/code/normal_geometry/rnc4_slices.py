#!/usr/bin/env python3
"""Exact necessary affine slices for the unresolved RNC4 normal case.

Run with PYTHONPATH=/tmp/p4_v6_math python3 rnc4_slices.py.
No claim that these systems have normal-quintic solutions is made.
Outputs exact rational linear basis and all nonzero Jacobi equations for
the two prescribed modular vector fields h and e.
"""
from pathlib import Path
import json
import sympy as sp

OUT = Path(__file__).resolve().parent
x = sp.symbols('x0:5')
u = sp.symbols('u0:36')
pairs = [(i,j) for i in range(5) for j in range(i+1,5)]
triples = [(i,j,k) for i in range(5) for j in range(i+1,5) for k in range(j+1,5)]
quadrics = [x[0]*x[2]-x[1]**2, x[0]*x[3]-x[1]*x[2],
           x[0]*x[4]-x[1]*x[3], x[1]*x[3]-x[2]**2,
           x[1]*x[4]-x[2]*x[3], x[2]*x[4]-x[3]**2]
q = x[0]*x[4]-4*x[1]*x[3]+3*x[2]**2


def div(P):
    return sp.Matrix([sum(sp.diff(P[i,j],x[i]) for i in range(5))
                      for j in range(5)])


def skew_basis(i,j,f):
    R=sp.zeros(5)
    R[i,j],R[j,i]=f,-f
    return R


linear_basis=[skew_basis(i,j,f) for i,j in pairs for f in quadrics]
D=sp.Matrix(25,60,lambda r,c: sp.expand(div(linear_basis[c])[r//5]).coeff(x[r%5]))
rank=D.rank()
kernel=D.nullspace()
assert rank==24 and len(kernel)==36
rank_columns=list(D.rref()[1])
rank_rows=list(D[:,rank_columns].T.rref()[1])
rank_minor=D.extract(rank_rows,rank_columns).det()
assert len(rank_rows)==24 and rank_minor!=0
N=sp.Matrix.hstack(*kernel)
assert D*N==sp.zeros(25,36)
K=[]
for a in range(36):
    R=sp.zeros(5)
    for b in range(60):
        if N[b,a]:
            R+=N[b,a]*linear_basis[b]
    assert div(R)==sp.zeros(5,1)
    K.append(R)


def frac(v):
    v=sp.Rational(v)
    return [int(v.p),int(v.q)]


def xpoly(f):
    return [[list(m),frac(c)] for m,c in sp.Poly(f,*x).terms() if c]


def upoly(f):
    return [[list(m),frac(c)] for m,c in sp.Poly(f,*u).terms() if c]


H=sp.hessian(q,x)
M_h=sp.diag(4,2,0,-2,-4)
M_e=sp.zeros(5)
for i in range(1,5):
    M_e[i,i-1]=i

data={
  'status':'necessary affine slices only; normality and generic E8 not solved',
  'curve':'[s^4:s^3*t:s^2*t^2:s*t^3:t^4]',
  'pairs':pairs,
  'quadrics':[str(z) for z in quadrics],
  'divergence_matrix_shape':[25,60],
  'divergence_rank_exact':rank,
  'divergence_matrix_sparse':[[i,j,int(D[i,j])] for i in range(25) for j in range(60) if D[i,j]],
  'rank_certificate':{'rows':rank_rows,'columns':rank_columns,'determinant':int(rank_minor),
                      'upper_bound_reason':'trace(div Q)=div(div Q)=0'},
  'affine_dimension_each':len(kernel),
  'kernel_N_sparse':[[i,j,frac(N[i,j])] for i in range(60) for j in range(36) if N[i,j]],
  'q':str(q),
  'common_direction_matrices':[[xpoly(R[i,j]) for i,j in pairs] for R in K],
  'cases':{}
}

for name,M in [('semisimple',M_h),('nilpotent',M_e)]:
    A=M*sp.Matrix(x)
    assert sp.expand(sum(A[i]*sp.diff(q,x[i]) for i in range(5)))==0
    S=-M*H.inv()
    assert S.T==-S
    E_wedge_A=sp.Matrix(x)*A.T-A*sp.Matrix(x).T
    P0=-E_wedge_A/5+q*S
    P0=P0.applyfunc(sp.expand)
    assert div(P0).applyfunc(sp.expand)==sp.zeros(5,1)
    s,t=sp.symbols('s t')
    parametrization={x[i]:s**(4-i)*t**i for i in range(5)}
    assert (P0+E_wedge_A/5).subs(parametrization).applyfunc(sp.expand)==sp.zeros(5)
    P=P0.copy()
    for a in range(36):
        P+=u[a]*K[a]
    P=P.applyfunc(sp.expand)
    equations=[]
    for i,j,k in triples:
        jac=sp.expand(sum(P[i,l]*sp.diff(P[j,k],x[l])
                          +P[j,l]*sp.diff(P[k,i],x[l])
                          +P[k,l]*sp.diff(P[i,j],x[l]) for l in range(5)))
        for mon,coef in sp.Poly(jac,*x).terms():
            if coef:
                equations.append({'triple':[i,j,k],'x_monomial':list(mon),
                                  'polynomial':upoly(coef)})
    assert all(sum(m)<=2 for eq in equations for m,c in eq['polynomial'])
    data['cases'][name]={
      'A':[str(z) for z in A],
      'P0_upper':[xpoly(P0[i,j]) for i,j in pairs],
      'P0_upper_readable':[str(P0[i,j]) for i,j in pairs],
      'jacobi_nonzero_coefficient_count':len(equations),
      'jacobi_equations':equations,
      'slice_divergence_verified_exact':True,
      'slice_restriction_verified_exact':True
    }
    print(name,'affine parameters',len(kernel),'Jacobi coefficient equations',len(equations),flush=True)

path=OUT/'rnc4_slices.json'
path.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':'))+'\n')
summary={k:v for k,v in data.items() if k not in ['kernel_N_sparse','common_direction_matrices','cases']}
summary['cases']={k:{a:b for a,b in v.items() if a not in ['P0_upper','jacobi_equations']}
                  for k,v in data['cases'].items()}
(OUT/'rnc4_slices_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('written',path,'bytes',path.stat().st_size)

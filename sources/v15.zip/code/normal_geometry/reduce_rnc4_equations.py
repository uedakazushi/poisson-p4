#!/usr/bin/env python3
"""Exact rational row reduction of the 302 Jacobi coefficient equations.

This is linear algebra on polynomials, not Groebner-basis computation.
Stores 94 selected original equations and exact constant-coefficient
expressions of all 302 equations in their span, for each slice.
"""
from pathlib import Path
from fractions import Fraction as Q
from collections import Counter
import json

ROOT=Path(__file__).resolve().parent
d=json.loads((ROOT/'rnc4_slices.json').read_text())


def update(row,k,v):
    if v:
        row[k]=row.get(k,Q(0))+v
        if not row[k]:del row[k]


def frac(v):return [v.numerator,v.denominator]


out={}
for name,c in d['cases'].items():
    polys=[];mons=set()
    for e in c['jacobi_equations']:
        poly={tuple(i for i,n in enumerate(m) for _ in range(n)):Q(*v)
              for m,v in e['polynomial']}
        mons.update(poly);polys.append(poly)
    mons=sorted(mons,key=lambda m:(-len(m),m));cols={m:i for i,m in enumerate(mons)}
    basis={};selected=[];relations=[]
    for index,poly in enumerate(polys):
        row={cols[m]:v for m,v in poly.items() if v};acc={}
        while row:
            k=min(row)
            if k not in basis:
                scale=row[k];s=len(selected);selected.append(index)
                comb={j:-v/scale for j,v in acc.items()}
                comb[s]=Q(1)/scale
                basis[k]=({j:v/scale for j,v in row.items()},comb)
                relations.append({s:Q(1)})
                break
            fac=row[k];b,comb=basis[k]
            for j,v in b.items():update(row,j,-fac*v)
            for j,v in comb.items():update(acc,j,fac*v)
        else:
            relations.append(acc)
    assert len(selected)==94 and len(relations)==302
    for poly,rel in zip(polys,relations):
        rebuilt={}
        for k,v in rel.items():
            for m,z in polys[selected[k]].items():update(rebuilt,m,v*z)
        assert rebuilt==poly
    degrees=Counter(len(mons[k]) for k in basis)
    assert degrees=={2:94}
    out[name]={
      'rank_over_Q':94,'selected_original_equation_indices':selected,
      'leading_monomials':[list(mons[k]) for k in sorted(basis)],
      'leading_degree_histogram':dict(degrees),
      'all_original_equations_in_selected_span':[
          [[k,frac(v)] for k,v in sorted(r.items())] for r in relations],
      'no_nonzero_affine_linear_polynomial_in_span':True,
      'status':'94 independent quadratic polynomials generate exactly the same ideal as all302; not a Groebner basis or minimal ideal-generator assertion'
    }
    print(name,'exact polynomial row rank',len(selected),'all pivots quadratic',flush=True)
(ROOT/'rnc4_equation_reduction.json').write_text(json.dumps(out,separators=(',',':'))+'\n')

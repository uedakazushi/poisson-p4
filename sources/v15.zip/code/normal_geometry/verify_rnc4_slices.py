#!/usr/bin/env python3
"""Independent standard-library verifier of rnc4_slices.json.

Checks the rank minor and all 36 kernel vectors, both particular solutions,
all prescribed curve restrictions, and every Jacobi coefficient, using only
Fraction and sparse polynomial arithmetic (no SymPy).
"""
from pathlib import Path
from fractions import Fraction as Q
import json

ROOT=Path(__file__).resolve().parent
d=json.loads((ROOT/'rnc4_slices.json').read_text())
pairs=[tuple(a) for a in d['pairs']]
zero=(0,)*5


def plus(out,k,v):
    if v:
        out[k]=out.get(k,Q(0))+v
        if not out[k]: del out[k]


def add(a,b,scale=Q(1)):
    c=a.copy()
    for k,v in b.items(): plus(c,k,scale*v)
    return c


def neg(a): return {k:-v for k,v in a.items()}


def mul(a,b):
    c={}
    for (m,u),v in a.items():
        for (n,w),z in b.items():
            plus(c,(tuple(mi+ni for mi,ni in zip(m,n)),tuple(sorted(u+w))),v*z)
    return c


def diff(a,i):
    c={}
    for (m,u),v in a.items():
        if m[i]:
            n=list(m); n[i]-=1
            plus(c,(tuple(n),u),m[i]*v)
    return c


def read_xpoly(data,param=()):
    return {(tuple(m),param):Q(*c) for m,c in data if c[0]}


def xmon(i):
    m=list(zero);m[i]=1
    return {(tuple(m),()):Q(1)}


def constant_scale(a,v):return {k:v*z for k,z in a.items() if v*z}


def divergence(P):
    ans=[]
    for j in range(5):
        p={}
        for i in range(5):p=add(p,diff(P[i][j],i))
        ans.append(p)
    return ans


def restrict_curve(p):
    out={}
    for (m,u),v in p.items():
        b=sum(i*m[i] for i in range(5))
        a=4*sum(m)-b
        plus(out,((a,b),u),v)
    return out


def determinant(matrix):
    a=[[Q(v) for v in row] for row in matrix]
    det=Q(1)
    for c in range(len(a)):
        r=next((r for r in range(c,len(a)) if a[r][c]),None)
        if r is None:return Q(0)
        if r!=c:a[c],a[r]=a[r],a[c];det=-det
        p=a[c][c];det*=p
        for j in range(c,len(a)):a[c][j]/=p
        for i in range(c+1,len(a)):
            p=a[i][c]
            if p:
                for j in range(c,len(a)):a[i][j]-=p*a[c][j]
    return det


# Rebuild the divergence matrix independently from the six Hankel minors.
X=[xmon(i) for i in range(5)]
qs=[add(mul(X[0],X[2]),mul(X[1],X[1]),-1),
    add(mul(X[0],X[3]),mul(X[1],X[2]),-1),
    add(mul(X[0],X[4]),mul(X[1],X[3]),-1),
    add(mul(X[1],X[3]),mul(X[2],X[2]),-1),
    add(mul(X[1],X[4]),mul(X[2],X[3]),-1),
    add(mul(X[2],X[4]),mul(X[3],X[3]),-1)]
D=[[Q(0) for _ in range(60)] for _ in range(25)]
for a,(i,j) in enumerate(pairs):
    for b,f in enumerate(qs):
        for row,p in [(j,diff(f,i)),(i,neg(diff(f,j)))]:
            for (m,u),c in p.items():
                assert sum(m)==1 and not u
                D[5*row+m.index(1)][6*a+b]=c
assert [[i,j,int(D[i][j])] for i in range(25) for j in range(60) if D[i][j]]==d['divergence_matrix_sparse']
cert=d['rank_certificate']
minor=determinant([[D[i][j] for j in cert['columns']] for i in cert['rows']])
assert minor==cert['determinant'] and minor
assert all(sum(D[6*i][j] for i in range(5))==0 for j in range(60))
N=[[Q(0) for _ in range(36)] for _ in range(60)]
for i,j,c in d['kernel_N_sparse']:N[i][j]=Q(*c)
assert all(sum(D[i][k]*N[k][j] for k in range(60))==0 for i in range(25) for j in range(36))
free=[i for i in range(60) if i not in cert['columns']]
assert all(N[free[i]][j]==(i==j) for i in range(36) for j in range(36))

result={'rank_exact':24,'rank_minor':int(minor),'independent_kernel_vectors':36,'cases':{}}
reduced=json.loads((ROOT/'rnc4_equation_reduction.json').read_text())
for name,case in d['cases'].items():
    P=[[{} for j in range(5)] for i in range(5)]
    for a,(i,j) in enumerate(pairs):
        P[i][j]=read_xpoly(case['P0_upper'][a])
        for k in range(36):
            P[i][j]=add(P[i][j],read_xpoly(d['common_direction_matrices'][k][a],(k,)))
        P[j][i]=neg(P[i][j])
    assert all(not p for p in divergence(P))
    if name=='semisimple': A=[constant_scale(X[i],4-2*i) for i in range(5)]
    else:A=[{}]+[constant_scale(X[i-1],i) for i in range(1,5)]
    for i,j in pairs:
        wedge=add(mul(X[i],A[j]),mul(A[i],X[j]),-1)
        assert not restrict_curve(add(P[i][j],wedge,Q(1,5)))
    expected={}
    for eq in case['jacobi_equations']:
        tr=tuple(eq['triple']);m=tuple(eq['x_monomial'])
        p=expected.setdefault(tr,{})
        for ue,c in eq['polynomial']:
            um=tuple(i for i,n in enumerate(ue) for _ in range(n))
            plus(p,(m,um),Q(*c))
    checked=0
    for i in range(5):
        for j in range(i+1,5):
            for k in range(j+1,5):
                jac={}
                for l in range(5):
                    jac=add(jac,mul(P[i][l],diff(P[j][k],l)))
                    jac=add(jac,mul(P[j][l],diff(P[k][i],l)))
                    jac=add(jac,mul(P[k][l],diff(P[i][j],l)))
                assert jac==expected.get((i,j,k),{})
                checked+=len(set(m for m,u in jac))
    assert checked==case['jacobi_nonzero_coefficient_count']
    red=reduced[name]
    polys=[{tuple(m):Q(*v) for m,v in eq['polynomial']} for eq in case['jacobi_equations']]
    selected=[polys[i] for i in red['selected_original_equation_indices']]
    assert len(selected)==94
    for original,relation in zip(polys,red['all_original_equations_in_selected_span']):
        rebuilt={}
        for k,v in relation:
            for m,c in selected[k].items():plus(rebuilt,m,Q(*v)*c)
        assert rebuilt==original
    # Independence of the homogeneous quadratic parts proves both rank94
    # and absence of a nonzero affine-linear polynomial in the full span.
    pivots={}
    for poly in selected:
        row={m:v for m,v in poly.items() if sum(m)==2}
        while row:
            m=min(row)
            if m not in pivots:
                v=row[m];pivots[m]={n:c/v for n,c in row.items()};break
            v=row[m]
            for n,c in pivots[m].items():plus(row,n,-v*c)
        else:raise AssertionError('Quadratic parts not independent')
    assert len(pivots)==94
    result['cases'][name]={'divergence_exact':True,'restriction_exact':True,
                           'Jacobi_coefficients_independently_verified':checked,
                           'equivalent_selected_quadrics_verified':94,
                           'quadratic_parts_linearly_independent':True,
                           'no_nonzero_affine_linear_polynomial_in_span':True}
    print(name,'all exact checks passed',flush=True)
(ROOT/'rnc4_independent_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

#!/usr/bin/env python3
"""Exact checks for the reduced fixed-divisor theorem's examples.

The general theorem and its arbitrary-base proof are in the manuscript.
This independent file uses no earlier project code. It verifies the full
150-dimensional annihilator of the toric quintic, its quadratic form,
and an explicit failure of the linear criterion for a nonreduced quintic.
"""
from itertools import combinations, combinations_with_replacement
from pathlib import Path
import json
import sympy as s

x = s.symbols('x0:5')
pairs = list(combinations(range(5), 2))
mon2 = [x[i]*x[j] for i, j in combinations_with_replacement(range(5), 2)]


def pfaff(P):
    ans = []
    for i in range(5):
        a,b,c,d = [j for j in range(5) if j != i]
        ans.append(s.expand((-1)**i * (P[a,b]*P[c,d]
                       - P[a,c]*P[b,d] + P[a,d]*P[b,c])))
    return s.Matrix(ans)


def divergence(P):
    return s.Matrix([s.expand(sum(s.diff(P[i,j],x[i])
                                 for i in range(5))) for j in range(5)])


def jacobi(P):
    return {ijk:s.expand(sum(P[i,l]*s.diff(P[j,k],x[l])
              for i,j,k in [ijk, (ijk[1],ijk[2],ijk[0]),
                            (ijk[2],ijk[0],ijk[1])] for l in range(5)))
            for ijk in combinations(range(5),3)}


def annihilator(F):
    f = s.Matrix([s.diff(F,t) for t in x])
    columns = []
    row_keys = set()
    for i,j in pairs:
        for m in mon2:
            z = {}
            for k,g in [(i,m*f[j]),(j,-m*f[i])]:
                for power,c in s.Poly(g,*x).terms():
                    if c:
                        z[(k,power)] = c
            columns.append(z)
            row_keys.update(z)
    rows = sorted(row_keys)
    M = s.SparseMatrix(len(rows),150,
          {(r,c):column[key] for r,key in enumerate(rows)
                            for c,column in enumerate(columns) if key in column})
    return M, M.nullspace()


def main():
    F = s.prod(x)
    f = s.Matrix([s.diff(F,t) for t in x])
    M, basis = annihilator(F)
    assert len(basis) == 6

    u = s.symbols('u12 u13 u14 u23 u24 u34')
    A = s.zeros(5)
    for (i,j),v in zip(combinations(range(1,5),2),u):
        A[i,j],A[j,i] = v,-v
    for i in range(1,5):
        A[0,i] = sum(A[i,j] for j in range(1,5))
        A[i,0] = -A[0,i]
    P = s.Matrix(5,5,lambda i,j:A[i,j]*x[i]*x[j])
    assert A*s.ones(5,1) == s.zeros(5,1)
    assert (P*f).applyfunc(s.expand) == s.zeros(5,1)
    assert divergence(P) == s.zeros(5,1)
    assert all(v == 0 for v in jacobi(P).values())
    q = u[0]*u[5]-u[1]*u[4]+u[2]*u[3]
    assert (pfaff(P)-q*f).applyfunc(s.expand) == s.zeros(5,1)
    H = s.hessian(q,u)
    assert H.rank() == 6

    N = s.zeros(5)
    N[1,2],N[2,1] = x[0]**2,-x[0]**2
    N[3,4],N[4,3] = x[1]**2,-x[1]**2
    G = x[0]**5
    assert divergence(N) == s.zeros(5,1)
    assert N*s.Matrix([s.diff(G,t) for t in x]) == s.zeros(5,1)
    nonzero_jacobi = {''.join(map(str,k)):str(v) for k,v in jacobi(N).items() if v}
    assert nonzero_jacobi == {'234':'-2*x0**2*x1'}
    assert pfaff(N) == s.Matrix([x[0]**2*x[1]**2,0,0,0,0])

    report = {
        'toric_quintic':str(F),
        'annihilator_columns':150,
        'annihilator_rank':150-len(basis),
        'K_F_dimension':len(basis),
        'V_F_dimension':6,
        'q_F':str(q),
        'q_rank':int(H.rank()),
        'q_hessian_determinant':str(H.det()),
        'all_pairwise_compatible':True,
        'nonreduced_counterexample':{
             'F':str(G),'P12':str(N[1,2]),'P34':str(N[3,4]),
             'divergence_zero':True,'P_gradient_zero':True,
             'pfaffians':[str(z) for z in pfaff(N)],
             'nonzero_jacobi':nonzero_jacobi},
        'all_assertions_passed':True
    }
    out=Path(__file__).with_suffix('.json')
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()

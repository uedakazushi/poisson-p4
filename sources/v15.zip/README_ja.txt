射影4空間の Poisson 構造 — 研究継続ノート 第15版
=================================================
2026年10月29日

対象・規約
----------
複素数体上。射影化した全 Poisson スキームを PGL5 で割る前に扱う。
Jacobi 方程式の冪零構造を保持し、次元は複素次元。
PDF に書き込みフォームは設けない。第14版以前の全ファイルは変更しない。

本版の主要結果
--------------
1. 被約な五次式 F を固定すると
   V_F={二次交代行列 P : div P=0, P grad F=0}
   は相互 compatible な Poisson 構造の線形空間である。
   Pfaff(P)=q_F(P) grad F、q_F は二次形式。
   固定退化因子の全スキーム・ファイバーは P(V_F) の q_F!=0 部分。
   非空なら滑らか・既約・有理。rank(q_F)<=6。
   因子も動く相対版を arbitrary-base の分裂単射で証明。
2. 滑らかな楕円曲線からの q_{5,1} の全域で、全射影 Poisson スキームは
   滑らかな25次元。QQ[t] 上の十個の行列式と五個の gcd による一様な証明。
3. 厳密な H5 不変切断は被約な (2,2,2,2) CI。
   二本の有理正規五次曲線と六本の直線、24 node、12個の被約 rank2 点。
   点分類は ORTP の既知の結果。全スキームを独立に検算した。
4. 正規五次因子の reduced singular curve は連結。
   canonical P の係数共通零点が modular residue の零点を与える。
   零点が有限なら (総次数5, generic Etilde6) または (総次数4, generic Etilde8)。
   reduced singular curve が滑らかで residue が非零なら、q51以外に残るのは
   有理正規四次曲線・generic Etilde8 の候補のみ。
5. この候補を、半単純・冪零 residue の二つの affine36 slice に還元。
   各302個の非零 Jacobi 係数は94個の選ばれた二次式の定数係数線形結合。
   全スキームで同じイデアル。存在・不存在は未決。

限界
----
全 P4 Poisson 空間の完全な成分分解は未完。
全体の下界57を変更しない。H5切断の8成分を大域成分数へ加算しない。
normal => q51 は未証明。非被約因子では線形ファイバー定理はそのまま使えない。
RNC4 方程式の解には F!=0、正規性、radical(J_F)=I_C の追加確認が必要。
94個がイデアルの最小生成系・Groebner基底とは主張しない。

ファイル
--------
p4_poisson_completeness_v15.pdf : 日本語の証明を収録した本文
p4_poisson_completeness_v15.tex : LuaLaTeX 主ファイル
preamble.tex, sections/         : 本文ソース
code/reduced_fibers/            : toric例・非被約反例
code/heisenberg/                : H5全スキーム、q52一意復元
code/normal_tangent/            : Fisher一様接空間計算・独立検算
code/normal_geometry/           : RNC4の36変数94方程式と独立検算
proofs/                        : 導出と独立監査、一次文献メモ
data/reproduced/               : 本版の厳密計算の再実行結果
data/previous_v14_preservation.json : 旧版1054ファイルのSHA256
previous_v14/                  : 第14版と再帰的に保存された全旧版
SHA256SUMS.txt                  : 現在の一式のハッシュ一覧

再現手順
--------
Python 3.12、SymPy 1.14.0、NumPy 2.3.5 で実行確認。

  python3 -m pip install -r requirements.txt
  python3 code/run_checks.py --output /tmp/p4_v15_checks --jobs 4
  python3 code/verify_bundle.py

run_checks.py は一時コピーで11項目を実行し、JSONの完全一致を確認する。
--output を一式の外に置けば、同梱の証明書・検証ログ・ハッシュは変更されない。
全般定理の網羅性は本文で証明しており、有限個の計算例で代用しない。

RNC4についてだけ直接再計算する場合は、コードを任意の作業用フォルダに複製し、
同一フォルダで次を順番に実行する。
  python3 rnc4_slices.py
  python3 reduce_rnc4_equations.py
  python3 verify_rnc4_slices.py
後二者はPython標準ライブラリとFractionだけを用いる。

PDF の再構築には LuaLaTeX、latexmk、luatexja、Harano Aji フォントが必要。
  latexmk -lualatex -interaction=nonstopmode -halt-on-error \
    -outdir=/tmp/p4_v15_build p4_poisson_completeness_v15.tex

引用と履歴
----------
一次文献は本文の参考文献を参照。
本ノート内の導出について歴史的な新規性は主張しない。
旧版の未解決事項の記述は歴史として保存し、本版で更新した範囲は本文の最終節に明記。

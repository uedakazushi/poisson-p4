射影4空間の Poisson 構造：研究継続ノート 第8版
================================================
2026年10月29日。基礎体は複素数。

まず読むファイル
----------------
p4_poisson_completeness_v8.pdf
  今回の完全な本文。全空間の成分数の下界57、新たに成分性を確認した二成分、
  AB と U1 の既存成分への包含、有限 jet と未解決問題を説明する。

確定結果
--------
・全射影 Poisson scheme P4 の既約成分数は少なくとも57。
  完全な個数、全境界、全同型類の分類ではない。
・Cplus拡張：被約次元24、一般PGL軌道22、被約有理商2、一般横断長さ2。
  横断環 K[e]/(e^2)。全局所環は一般閉点で C[[a1,...,a24,e]]/(e^2)。
・Cminus拡張：被約次元23、一般PGL軌道21、被約有理商2、一般横断長さ4。
  横断環 K[u,v]/(uv,v^2,u^3)、Hilbert関数(1,2,1)。
・AB全磁気項族：標準トーリック25次元成分へ包含。
  一般磁気点は全schemeの正則25次元点。元の点は局所次元25/接空間27。
・U1全磁気項族：既知の二独立平滑化型24次元成分T16へ包含。
  構成した変形後の一般点は正則24次元。B=tz+z^2の源点は局所次元24/接空間25。
  選んだ二変数形式スライスの最初の式は v(u+128v)(u+256v)。
  v=0方向は明示変形として積分済み。他二方向と全完成局所環は未決定。

全成分の次元は非零定数倍を除き、PGLでは割らない数値。
商の次元を、商の関数体が純超越的という主張と同一視しないこと。
補助45変数空間Qの22成分という第7版の分類を、全P4の成分数へ移さないこと。
一般横断環を元の二変数磁気項の特殊点へ拡張しないこと。

検証
----
Python 3.12.14 / SymPy 1.14.0 で検証。
新規の計算に必要なPython依存は requirements.txt のSymPyのみ。
全rankは有理数上の正確なrank。普遍恒等式は多項式/有理関数として検証する。
15のチェックを収録し、主証明書と独立監査を含む。

このディレクトリで実行：
  python code/run_v8_checks.py --jobs 2 --output-dir /tmp/p4_v8_reproduced

一時的な作業コピーで実行し、code以下の基準の係数を上書きしない。
配布時の実行結果は data/reproduced/v8_check_results.json。
新しい実行ログを配布版data/reproducedに上書きするとSHA256SUMSの一致は失われるため、
上のように別の出力先を使うと配布ファイルをそのまま保存できる。

Cplusの大きな普遍法線は code/cplus/universal_normal.json に全150係数を収録。
主検証はその全350恒等式を検証し、標本で50方向の核の独立性を確認する。
必要なら code/cplus/synthesize_normal.py 2 1 で合成から再実行できる。
この任意の再合成は通常の15チェックには含めない。

独立実装
--------
・code/u1/independent_cminus_audit.py は旧Poisson engineをimportせず、
  多項式行列と座標微分だけでCminusを再検算する。
・code/cminus/audit_cplus_component.py は主Cplusコードをimportせず、
  3変数導分から族を独立に再構成する。
・code/cminus/audit_u1_t16.py は最終線形座標変換から族を再構成し、
  有限fiber translationと3次障害も再計算する。
・ABの多項式Jacobiは対数座標による構成証明に加えて全係数でも検証する。

LuaLaTeXによる本文の再組版
-------------------------
LuaLaTeX、LuaTeX-ja、HaranoAji、latexmkと標準LaTeXパッケージを使用。
このディレクトリで：
  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v8.tex

入力フォームは設けていない。
本文の分割ソースは sections/、全体の定義は preamble.tex。

前版の保存
----------
previous_v7/ の394ファイルは第7版とbyte-identicalである。
第7版が含む旧版もそのまま保存。新計算から以前のコードをimportしない。
data/previous_v7_checksums.json は元の394ファイルのSHA-256。
全配布ファイルの確認：
  python code/verify_bundle.py

次の研究
--------
HANDOFF.txt に次の研究の起点と適用範囲をまとめた。
主な未解決点は、U1の二つの候補方向、AB/Cplus/Cminus特殊点の全局所構造、
固定J互換性の外側のrank4、essential5の残存rank2/Casimir問題である。
論文としての独立査読や文献上の新規性の確定は、本資料の検算とは別である。

#!/usr/bin/env python3
"""Exact polynomial calculus, copied from the independent v7 engine; no old imports."""
from pathlib import Path
from itertools import combinations, combinations_with_replacement
from collections import defaultdict
import ast, hashlib, json, sys
import sympy as s
from sympy.polys.matrices import DomainMatrix

HERE=Path(__file__).resolve().parent

def rank(M):
    return len(DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1])

class Calculus:
    def __init__(self,n):
        self.n=n; self.x=s.symbols('x0:'+str(n))
        self.pairs=list(combinations(range(n),2))
        self.triples=list(combinations(range(n),3))
        self.quads=list(combinations(range(n),4))
        self.m2=self.monomials(2); self.m3=self.monomials(3); self.m4=self.monomials(4)
        self.basis=[(I,m) for I in self.pairs for m in self.m2]
        self.bindex={z:i for i,z in enumerate(self.basis)}
        self.cubic_basis=[(I,m) for I in self.triples for m in self.m3]
        self.cindex={z:i for i,z in enumerate(self.cubic_basis)}
        self.projective_basis=[(I,m) for I in self.quads for m in self.m4]
        self.pindex={z:i for i,z in enumerate(self.projective_basis)}
    def monomials(self,d):
        return [tuple(v.count(i) for i in range(self.n)) for v in combinations_with_replacement(range(self.n),d)]
    def expr(self,f):return s.expand(sum(a*s.prod(x**k for x,k in zip(self.x,m)) for m,a in f.items()))
    def pol(self,f):return {m:s.Rational(a) for m,a in s.Poly(f,*self.x).terms() if a}
    def tensor(self,entries):return {I:self.pol(f) for I,f in entries.items() if f!=0}
    def as_matrix(self,P):
        M=s.zeros(self.n)
        for (i,j),f in P.items():M[i,j]=self.expr(f);M[j,i]=-M[i,j]
        return M
    def from_vector(self,v):
        P={}
        for (I,m),a in zip(self.basis,v):
            if a:P.setdefault(I,{})[m]=a
        return P
    def vector(self,P):
        return s.SparseMatrix(len(self.basis),1,{(self.bindex[I,m],0):a for I,f in P.items() for m,a in f.items() if a})
    def cubic_vector(self,C):
        return s.SparseMatrix(len(self.cubic_basis),1,{(self.cindex[I,m],0):a for I,f in C.items() for m,a in f.items() if a})
    def euler_vector(self,C):
        out=defaultdict(int)
        for I,f in C.items():
            for j in range(self.n):
                if j in I:continue
                sg=(-1)**sum(i<j for i in I);K=tuple(sorted((j,)+I))
                for m,a in f.items():
                    t=list(m);t[j]+=1;out[self.pindex[K,tuple(t)],0]+=sg*a
        return s.SparseMatrix(len(self.projective_basis),1,{k:v for k,v in out.items() if v})
    @staticmethod
    def entry(P,i,j):
        if i==j:return {}
        if i<j:return P.get((i,j),{})
        return {m:-a for m,a in P.get((j,i),{}).items()}
    @staticmethod
    def diff(f,j):
        out={}
        for m,a in f.items():
            if m[j]:
                t=list(m);t[j]-=1;out[tuple(t)]=a*m[j]
        return out
    @staticmethod
    def product(f,g):
        out=defaultdict(int)
        for m,a in f.items():
            for k,b in g.items():out[tuple(u+v for u,v in zip(m,k))]+=a*b
        return {m:a for m,a in out.items() if a}
    @staticmethod
    def add(out,f,mult=1):
        for m,a in f.items():out[m]+=mult*a
    def polar(self,P,R):
        out={}
        for I in self.triples:
            q=defaultdict(int)
            for i,j,k in [I,(I[1],I[2],I[0]),(I[2],I[0],I[1])]:
                for l in range(self.n):
                    self.add(q,self.product(self.entry(P,i,l),self.diff(self.entry(R,j,k),l)))
                    self.add(q,self.product(self.entry(R,i,l),self.diff(self.entry(P,j,k),l)))
            out[I]={m:a for m,a in q.items() if a}
        return out
    def jacobi(self,P):return {I:{m:a/2 for m,a in f.items()} for I,f in self.polar(P,P).items()}
    def derivative(self,P,projective=False):
        vf=self.euler_vector if projective else self.cubic_vector
        return s.Matrix.hstack(*[vf(self.polar(P,{I:{m:s.S.One}})) for I,m in self.basis])
    def lie(self,P,X):
        M=self.as_matrix(P);X=s.Matrix(X);A=X.jacobian(self.x)
        L=M.applyfunc(lambda q:sum(X[i]*s.diff(q,self.x[i]) for i in range(self.n)))-A*M-M*A.T
        return self.tensor({I:s.expand(L[I]) for I in self.pairs})
    def vertical(self,i,j):
        return self.tensor({(a,b):(self.x[a]*self.x[j] if b==i else 0)-(self.x[b]*self.x[j] if a==i else 0) for a,b in self.pairs})
    def lift(self,P,target):
        assert self.n+1==target.n
        return {(i+1,j+1):{(0,)+m:a for m,a in f.items()} for (i,j),f in P.items()}
    def encode(self,P):return {str(I):str(s.factor(self.expr(P.get(I,{})))) for I in self.pairs}

def constant_compatibility(C,J):
    # [J,R] is linear: use its natural16 coordinates, without degree-padding.
    cols=[]
    for I,m in C.basis:
        jj=C.polar(J,{I:{m:s.S.One}})
        cols.append(s.Matrix([jj.get(K,{}).get(tuple(int(i==j) for i in range(C.n)),0) for K in C.triples for j in range(C.n)]))
    M=s.Matrix.hstack(*cols)
    return M,s.Matrix.hstack(*M.nullspace())

def symplectic_orbit(C,J,Q):
    JM=C.as_matrix(J)
    H=[s.prod(x**a for x,a in zip(C.x,m)) for m in C.m2]
    return [C.lie(Q,-JM*s.Matrix([s.diff(h,x) for x in C.x])) for h in H]


#!/usr/bin/env python3
"""Independent U1-to-T16 confluence, full ranks, and magnetic quotient audit."""
from pathlib import Path
import ast,json
import sympy as s
from cminus_calculus import Calculus,rank
from certify_cminus_component import piv,inverse,quintic
from audit_cplus_component import actual
HERE=Path(__file__).resolve().parent

def main():
    C=Calculus(5);C.x=s.symbols('t x y z w');C.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*C.x).terms() if a}
    t,x,y,z,w=C.x;h,eta,e=s.symbols('h eta e');rt=s.sqrt(2)
    U=z-e*y;A=x/2+z+rt*t+e*(w/2+y+z)
    V=z+e*y;B=x/2+z-rt*t-e*(w/2+y+z)
    Z=s.Matrix([t,U,A,V,B]);L=Z.jacobian(C.x);det=s.factor(L.det())
    assert det==-e*e
    s1=e+eta*e*e;s2=-e+eta*e*e;cc=e+e*e/rt
    PM=s.zeros(5)
    entries={(1,2):s1*(t*t+U*A),(3,4):s2*(t*t+V*B),
             (1,3):cc*U*V,(1,4):-cc*U*B,(2,3):-cc*A*V,(2,4):cc*A*B}
    for I,f in entries.items():PM[I]=f;PM[I[::-1]]=-f
    LI=L.inv();F=(LI*PM*LI.T).applyfunc(s.expand).subs(e,rt*h).applyfunc(s.expand)
    for f in F:s.Poly(f,*C.x,h,eta,domain=s.QQ)
    P=C.tensor({I:F[I] for I in C.pairs})
    ref=json.loads((HERE/'u1_t16_reference.json').read_text())
    variables=dict(zip(['t','x','y','z','w'],C.x));variables.update({'h':h,'eta':eta})
    for key,value in ref['confluence_family'].items():
        I=tuple(ast.literal_eval(key));assert s.expand(F[I]-s.sympify(value,locals=variables))==0
    # All affine Jacobi coefficients, independently by direct differentiation.
    for i,j,k in C.triples:
        val=sum(F[i,l]*s.diff(F[j,k],C.x[l])+F[j,l]*s.diff(F[k,i],C.x[l])+F[k,l]*s.diff(F[i,j],C.x[l]) for l in range(5))
        assert s.expand(val)==0
    print('Universal rational confluence and affine Jacobi: PASS',flush=True)
    F1=s.expand((t*t+U*A).subs(e,rt*h));F2=s.expand((t*t+V*B).subs(e,rt*h))
    assert s.expand(quintic(C,P)-t*(1-2*eta*eta*h*h)*F1*F2)==0
    f0=F.subs(h,0)
    U0=s.zeros(5)
    source={(1,2):t*t-z*z,(1,4):-(x*x+8*x*z+8*z*z)/2,(2,3):-z*z/2,
            (2,4):t*z+z*z+y*(x+2*z)-eta*(t*t+x*z/2+z*z),(3,4):t*t+x*z+z*z}
    for I,f in source.items():U0[I]=f;U0[I[::-1]]=-f
    assert (f0-U0).applyfunc(s.expand)==s.zeros(5)

    # Exact finite gauge action: substitute new y=old y+f and w=old w+g.
    aa=s.symbols('a0:3');bb=s.symbols('b0:3');base=(t,x,z)
    ff=sum(a*v for a,v in zip(aa,base));gg=sum(a*v for a,v in zip(bb,base))
    Q=C.tensor({I:source[I].subs(eta,0) for I in source})
    QM=C.as_matrix(Q);Tr=s.Matrix([t,x,y+ff,z,w+gg]).jacobian(C.x)
    moved=(Tr*QM*Tr.T).subs({y:y-ff,w:w-gg},simultaneous=True).applyfunc(s.expand)
    X=s.Matrix([0,t*t-z*z,z*z/2]);Y=s.Matrix([0,-(x*x+8*x*z+8*z*z)/2,t*t+x*z+z*z]);ell=x+2*z
    shift=s.expand(sum(Y[i]*s.diff(ff,base[i])-X[i]*s.diff(gg,base[i]) for i in range(3))-ff*ell)
    for I in C.pairs:assert s.expand(moved[I]-QM[I]-(shift if I==(2,4) else 0))==0
    gauges=[s.diff(shift,a) for a in aa+bb]
    mons=[t*t,t*x,t*z,x*x,x*z,z*z]
    GM=s.Matrix([[s.Poly(f,*base).coeff_monomial(m) for f in gauges] for m in mons])
    wanted=[t*x+2*t*z,x*x+4*x*z,t*t,z*z]
    WW=s.Matrix([[s.Poly(f,*base).coeff_monomial(m) for f in wanted] for m in mons])
    assert rank(GM)==4 and rank(GM.row_join(WW))==4
    print('Finite magnetic gauge action and quotient: PASS',flush=True)
    sample_reports=[]
    for hh in [0,1,2]:
        at={h:hh,eta:0};PP=C.tensor({I:F[I].subs(at) for I in C.pairs})
        D=C.derivative(PP,True);G=actual(C,PP)
        Rh=C.tensor({I:s.diff(F[I],h).subs(at) for I in C.pairs})
        Re=C.tensor({I:s.diff(F[I],eta).subs(at) for I in C.pairs})
        AF=s.Matrix.hstack(G,C.vector(Rh),C.vector(Re))
        assert D*AF==s.zeros(350,AF.cols)
        assert rank(D)==(100 if hh==0 else 101) and rank(G)==47 and rank(AF)==49
        rr={'h':hh,'eta':0,'Jacobi':rank(D),'group_vertical_scale':47,'actual_two_parameters':49,
            'projective_tangent':125-rank(D),'projective_family':24,'projective_orbit':22}
        if hh==0:
            mag=s.Matrix.hstack(G,*[C.vector(C.tensor({(2,4):m})) for m in mons])
            assert rank(mag)==48 and rank(mag.row_join(C.vector(Rh)))==49
            oldvars={f'x{i}':C.x[i] for i in range(5)}
            def read(z):return C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals=oldvars) for I,f in z.items()})
            NN=list(map(read,ref['normals']));M0=mag[:,piv(mag)]
            BM=s.Matrix.hstack(M0,*[C.vector(N) for N in NN]);assert rank(BM)==50 and not any(D*BM)
            sol,pars=BM.gauss_jordan_solve(C.vector(Rh));assert pars.rows==0
            assert list(sol[-2:,:])==[16,0]
            # Recheck the nonzero third Kuranishi equation, not any inference
            # from isolated homogeneous pieces at higher orders.
            J2={tuple(v['multiindex']):read(v['tensor']) for v in ref['second_jets']}
            N,M=NN;Q2=[C.euler_vector(C.jacobi(N)),C.euler_vector(C.polar(N,M)),C.euler_vector(C.jacobi(M))]
            for mon,B2 in zip([(2,0),(1,1),(0,2)],Q2):assert not any(D*C.vector(J2[mon])+B2)
            dp=piv(D);DW=D[:,dp];rows=piv(DW.T);MI=inverse(DW[rows,:])
            for T in J2.values():assert all(C.vector(T)[i]==0 for i in range(150) if i not in dp)
            columns=[C.euler_vector(C.polar(N,J2[2,0])),
                     C.euler_vector(C.polar(N,J2[1,1]))+C.euler_vector(C.polar(M,J2[2,0])),
                     C.euler_vector(C.polar(N,J2[0,2]))+C.euler_vector(C.polar(M,J2[1,1])),
                     C.euler_vector(C.polar(M,J2[0,2]))]
            OO=s.Matrix.hstack(*columns);res=OO-DW*MI*OO[rows,:]
            assert rank(res)==1
            assert all(res[i,0]==0 and res[i,2]==384*res[i,1] and res[i,3]==32768*res[i,1] for i in range(350))
            rr.update({'magnetic_actual_rank':48,'magnetic_plus_curve_rank':49,
                       'curve_normal_coordinates':[16,0],'third_obstruction_rank':1,
                       'third_equation_up_to_nonzero_scalar':'v*(u+128*v)*(u+256*v)',
                       'local_reduced_dimension':24,'source_complete_local_ring':'not determined'})
        sample_reports.append(rr);print('Sample',hh,'PASS',flush=True)
    out={'all_passed':True,'direct_coordinate_determinant':str(det),'affine_Jacobi_universal':True,
         'rational_polynomial_coefficients':True,'source_and_Pfaffian_identities':True,
         'finite_fiber_translation_identity':True,'magnetic_gauge_rank':4,
         'magnetic_quotient':['b_tz-2*b_tx','b_xz-4*b_xx'],
         'all_magnetic_members_covered_by_gauge_scale_and_closure':True,
         'sample_checks':sample_reports,'T16_identification':'After A->A/s1 and C->C/s2, t^2*J+N(s1,0,0,s2,c); existing catalog has T16 dimension24.',
         'confluence_reference_sha256':ref['confluence_source_sha256'],'second_jet_reference_sha256':ref['higher_jet_source_sha256'],
         'scope':'Contains every magnetic U1 point in the existing T16 component; other two tangent lines and source completed local ring are not classified.'}
    (HERE/'u1_t16_independent_audit.json').write_text(json.dumps(out,indent=2)+'\n')
    print('PASS',flush=True)

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Exact certificate: the 23D magnetic Cminus component in full P4.

All universal identities are checked over QQ(b,g), with g nonzero.  Rank
certificates use the point b=0,g=1, which is on the open stratum.  The old
binary Cminus homogenization has g=0 and is NOT assigned this local ring.
Only the self-contained exact polynomial engine in this directory is used.
"""
from pathlib import Path
import json
import sympy as s
from sympy.polys.matrices import DomainMatrix
from cminus_calculus import Calculus,rank

HERE=Path(__file__).resolve().parent

def piv(M):return list(DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1])
def inverse(M):return DomainMatrix.from_Matrix(M).convert_to(s.QQ).inv().to_Matrix()
def zero(M):return all(s.cancel(q)==0 for q in M)

def model(C,b,g):
    t,x,y,z,w=C.x
    return C.tensor({(1,2):t*t+x*x,(2,3):-x*z,
                     (2,4):-x*w-z*z-b*x*z-g*t*z,(3,4):t*t+x*x-2*z*z})

def jets(C,b,g):
    t,x,y,z,w=C.x
    R=C.tensor({(0,2):-x*(2*y-z),(0,4):2*g*t*z+x*x+2*b*x*z,
                (1,2):t*(2*y-z),(1,4):-t*x-2*b*t*z+2*g*x*z})
    S=C.tensor({(0,2):-t*w,(0,3):-4*t*w,(1,2):-x*w,(1,3):-4*x*w,
                (2,3):w*(2*g*t+2*b*x-4*y+3*z)})
    T=C.tensor({
        (0,2):(-b*g*t*z-g*g*x*z+2*x*y-x*z)/(4*g),
        (0,3):-t*x/4,
        (0,4):-(2*b*g*t*x+2*b*x*z+2*g*g*t*t+g*g*x*x-2*g*g*z*z+4*g*t*y+x*x)/(4*g),
        (1,2):-t*(-2*g*g*z+2*y-z)/(4*g),
        (1,3):t*t/4,
        (1,4):-(2*b*g*x*x-2*b*g*z*z-2*b*t*z+g*g*t*x+4*g*x*y-t*x)/(4*g)})
    return R,S,T

def quintic(C,P):
    M=C.as_matrix(P);f=0
    for i in range(5):
        a,b,c,d=[j for j in range(5) if j!=i]
        f+=(-1)**i*C.x[i]*(M[a,b]*M[c,d]-M[a,c]*M[b,d]+M[a,d]*M[b,c])
    return s.factor(f)

def matrices(C,P,b,g):
    VV=[C.vertical(i,j) for i in range(5) for j in range(5)]
    OO=[]
    for i in range(5):
        for j in range(5):
            X=s.zeros(5,1);X[i]=C.x[j];OO.append(C.lie(P,X))
    V=s.Matrix.hstack(*[C.vector(Z) for Z in VV])
    G=s.Matrix.hstack(V,*[C.vector(Z) for Z in OO+[P]])
    PM=C.as_matrix(P)
    family=[C.tensor({I:s.diff(PM[I],k) for I in C.pairs}) for k in [b,g]]
    A=s.Matrix.hstack(G,*[C.vector(Z) for Z in family])
    return V,G,A,family

def main():
    C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
    C.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*C.x).terms() if a}
    b,g=s.symbols('b g');P=model(C,b,g);R,S,T=jets(C,b,g)
    assert zero(C.cubic_vector(C.jacobi(P)))
    assert zero(C.euler_vector(C.polar(P,R)))
    assert zero(C.euler_vector(C.polar(P,S)))
    assert zero(C.euler_vector(C.polar(P,T))+C.euler_vector(C.jacobi(R)))
    stabilizers=[]
    for i,m in [(2,t),(2,x),(4,z)]:
        X=s.zeros(5,1);X[i]=m
        assert zero(C.vector(C.lie(P,X)));stabilizers.append([str(a) for a in X])
    expectedD=t*(t*t+x*x)*(t*t+x*x-2*z*z)
    assert s.expand(quintic(C,P)-expectedD)==0
    print('Universal family, R,S,T, stabilizers, and quintic: PASS',flush=True)

    V,G,A,family=matrices(C,P,b,g)
    at={b:s.S.Zero,g:s.S.One}
    def spec(Z):return C.tensor({I:C.expr(f).subs(at) for I,f in Z.items()})
    P0,R0,S0,T0=map(spec,[P,R,S,T])
    D=C.derivative(P0,True)
    V0,G0,A0=V.subs(at),G.subs(at),A.subs(at)
    E=s.Matrix.hstack(A0,C.vector(R0),C.vector(S0))
    ranks={'Jacobi':rank(D),'vertical':rank(V0),'group_vertical_scale':rank(G0),
           'actual_family':rank(A0),'actual_plus_R_S':rank(E)}
    assert list(ranks.values())==[100,24,46,48,50]
    assert D*E==s.zeros(350,E.cols)
    B=C.euler_vector(C.polar(R0,S0));H=C.euler_vector(C.jacobi(S0));O=C.euler_vector(C.polar(R0,T0))
    quadrank=rank(s.Matrix.hstack(D,B,H));thirdrank=rank(s.Matrix.hstack(D,B,H,O))
    assert quadrank==102 and thirdrank==103
    ap=piv(A0);actual_basis=[C.from_vector(A0[:,j]) for j in ap]
    amb_actual=s.Matrix.hstack(D,*[C.euler_vector(C.polar(R0,Z)) for Z in actual_basis])
    amb_full=s.Matrix.hstack(amb_actual,C.euler_vector(C.polar(R0,R0)),B)
    assert rank(amb_actual)==100 and rank(amb_full)==101 and rank(amb_full.row_join(O))==102
    dp=piv(D);W=s.eye(150)[:,dp];DW=D[:,dp];rows=piv(DW.T);MI=inverse(DW[rows,:])
    # T was selected in the same fixed implicit complement as the point slice.
    assert all(s.cancel(C.vector(T)[j])==0 for j in range(150) if j not in dp)
    assert C.vector(T0)==-W*MI*C.euler_vector(C.jacobi(R0))[rows,:]
    OBS=s.Matrix.hstack(B,H,O);residual=OBS-DW*MI*OBS[rows,:]
    rr=piv(residual.T);minor=residual[rr,:]
    assert len(rr)==3 and minor.det()!=0
    # At g=0 this representative is in the original binary family, whose
    # Jacobi rank drops; we deliberately keep its scheme structure separate.
    binary_at={b:s.Rational(-2,7),g:s.S.Zero}
    PB=C.tensor({I:C.expr(f).subs(binary_at) for I,f in P.items()})
    DB=C.derivative(PB,True);GB=G.subs(binary_at);AB=A.subs(binary_at)
    binary={'b':'-2/7','g':'0','Jacobi_rank':rank(DB),
            'group_vertical_scale_rank':rank(GB),'magnetic_actual_rank':rank(AB),
            'projective_tangent_dimension':125-rank(DB),
            'binary_actual_rank':rank(AB[:,:-1])}
    assert list(binary.values())[2:]==[99,46,48,26,47]
    report={
        'scope':'full projective P4 Poisson scheme, not the auxiliary compatible Q scheme',
        'universal_base':'QQ(b,g), g nonzero','family':C.encode(P),'R':C.encode(R),'S':C.encode(S),'T':C.encode(T),
        'universal_family_and_second_jet_identities':True,'universal_second_correction_in_fixed_implicit_complement':True,
        'three_universal_PGL_stabilizer_fields':stabilizers,
        'sample':{'b':0,'g':1},'sample_ranks':ranks,
        'quadratic_obstruction_rank_mod_Jacobi':quadrank-rank(D),
        'quadratic_normal_ideal':'(u*v,v**2)',
        'third_with_both_quadratic_classes_rank':thirdrank,
        'third_ambiguity':{'actual_rank':rank(amb_actual),'all_kernel_rank':rank(amb_full),'all_kernel_plus_third_rank':rank(amb_full.row_join(O))},
        'residual_columns':['E wedge polar(R,S)','E wedge Jacobi(S)','E wedge polar(R,T)'],
        'residual_rows':rr,'residual_minor':[[str(v) for v in minor.row(i)] for i in range(3)],
        'residual_minor_determinant':str(s.factor(minor.det())),
        'implicit_columns':dp,'implicit_rows':rows,'quintic':str(s.factor(expectedD)),
        'component':{'projective_reduced_dimension':23,'generic_projective_orbit_dimension':21,
                     'reduced_rational_quotient_dimension':2,'generic_projective_tangent_dimension':25,
                     'generic_transverse_ring':'K[u,v]/(u*v,v**2,u**3)','generic_length':4,
                     'generic_closed_point_completed_local_ring':'C[[a1,...,a23,u,v]]/(u*v,v**2,u**3)'},
        'original_Cminus_binary_point':binary,
        'original_binary_scope':'Contained in this 23D component by the explicit magnetic deformation; uniqueness of ambient component and full local scheme at g=0 are not concluded.',
        'all_passed':True}
    (HERE/'cminus_component_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Ranks',ranks,'quadratic',quadrank,'third',thirdrank,flush=True)
    print('Residual minor',minor,'det',s.factor(minor.det()),flush=True)
    print('Binary special point',binary,flush=True)
    print('PASS',flush=True)

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Independent reconstruction/audit of the proposed Cplus 24D component.

No Cplus implementation is imported.  Its family is independently assembled
from the displayed three-variable derivations.  The common exact polynomial
calculus is this directory's local copy of the v7 independently checked engine.
"""
from pathlib import Path
import json
import sympy as s
from sympy.polys.matrices import DomainMatrix
from cminus_calculus import Calculus,rank,symplectic_orbit
from certify_cminus_component import quintic,piv,inverse
HERE=Path(__file__).resolve().parent

def build(C,c,beta):
    h,x,y,z,w=C.x;t,u,v=s.symbols('t u v');q=(t,u,v)
    V=s.Matrix([-8*t*u,5*t*t+2*u*u,-10*t*u+12*u*v])
    W=s.Matrix([2*t*((c-1)*t-4*c*v),-u*((3*c+2)*t-2*c*v),-8*(c-1)*t*v+12*c*v*v+10*u*u])
    a=(2-7*c)*t+18*c*v;b=-8*u
    assert (W.jacobian(q)*V-V.jacobian(q)*W-a*V-b*W).applyfunc(s.expand)==s.zeros(3,1)
    f=t*(u*u+t*v)*(u*u+c*t*v+(1-c)*t*t/2)
    assert s.expand(s.det(s.Matrix.hstack(s.Matrix(q),V,W))-100*f)==0
    T=s.Matrix([[1,0,0],[0,1,1],[s.Rational(1,2),1,-1]])
    M=s.Matrix([[1,1],[1,-1]])/5;sub={t:h,u:x+z,v:x-z+h/2}
    N=(T.inv()*s.Matrix.hstack(V,W).subs(sub,simultaneous=True)*M).applyfunc(s.expand)
    co=(M.det()*M.inv()*s.Matrix([a,b]).subs(sub,simultaneous=True)).applyfunc(s.expand)
    F=s.zeros(5)
    for i,k in enumerate([0,1,3]):
        F[k,2]=N[i,0];F[2,k]=-N[i,0];F[k,4]=N[i,1];F[4,k]=-N[i,1]
    F[2,4]=-co[0]*y-co[1]*w+x*x+beta*h*x;F[4,2]=-F[2,4]
    E=s.Matrix(C.x);X=s.Matrix([0,0,-16*z/5,0,-16*x/5])
    F=(F-E*X.T+X*E.T).applyfunc(s.expand)
    return F

def actual(C,P):
    vv=[C.vertical(i,j) for i in range(5) for j in range(5)]
    oo=[]
    for i in range(5):
        for j in range(5):
            X=s.zeros(5,1);X[i]=C.x[j];oo.append(C.lie(P,X))
    return s.Matrix.hstack(*[C.vector(Z) for Z in vv+oo+[P]])

def main():
    C=Calculus(5);C.x=s.symbols('h x y z w');C.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*C.x).terms() if a}
    h,x,y,z,w=C.x;c,beta=s.symbols('c beta');F=build(C,c,beta)
    P=C.tensor({I:F[I] for I in C.pairs})
    assert all(s.expand(v)==0 for v in C.euler_vector(C.jacobi(P)))
    expected=h*(h*h+2*h*(x-z)+2*(x+z)**2)*(h*h+2*c*h*(x-z)+2*(x+z)**2)
    assert s.expand(quintic(C,P)-expected)==0
    # A second check of Jacobi uses symbolic matrix differentiation directly.
    J={}
    for i,j,k in C.triples:
        J[i,j,k]=s.expand(sum(F[i,l]*s.diff(F[j,k],C.x[l])+F[j,l]*s.diff(F[k,i],C.x[l])+F[k,l]*s.diff(F[i,j],C.x[l]) for l in range(5)))
    for I in C.quads:
        assert s.expand(sum((-1)**a*C.x[I[a]]*J[tuple(j for j in I if j!=I[a])] for a in range(4)))==0
    print('Universal family and independent symbolic Jacobi: PASS',flush=True)
    # Explicit equality with the integer Cplus representative in the source.
    FF=s.zeros(5);qq={(1,2):h*h+x*x+8*x*z-z*z,(1,4):(x-z)*(5*x+z),
                      (2,3):(x-z)*(x+5*z),(2,4):2*(-w*x+w*z-x*y+y*z)+x*x,
                      (3,4):h*h-x*x+8*x*z+z*z}
    for I,f in qq.items():FF[I]=f;FF[I[::-1]]=-f
    assert (F.subs({c:-1,beta:0})-FF).applyfunc(s.expand)==s.zeros(5)
    CQ=Calculus(4);xx,yy,zz,ww=CQ.x;JQ=CQ.tensor({(0,1):1,(2,3):1})
    qorbits=[]
    for a0,b0,c0 in [(s.Rational(1,16),0,0),(1,2,3)]:
        pp=a0*xx*xx+b0*xx*zz+c0*zz*zz
        qv=[xx*xx/16+xx*zz/2-zz*zz/16,0,5*xx*xx/16-xx*zz/4-zz*zz/16,
            xx*xx/16+xx*zz/4-5*zz*zz/16,pp+(zz-xx)*(yy+ww)/8,-xx*xx/16+xx*zz/2+zz*zz/16]
        QQ=CQ.tensor(dict(zip(CQ.pairs,qv)));OO=symplectic_orbit(CQ,JQ,QQ)
        Om=s.Matrix.hstack(*[CQ.vector(Z) for Z in OO]);og=rank(Om.row_join(CQ.vector(QQ)))
        assert rank(Om)==9 and og==10
        qorbits.append({'p':list(map(str,[a0,b0,c0])),'Sp4':9,'Sp4_times_scale':10})
    # Two universal vertical linear stabilizers give orbit dimension <=22.
    shifts=[]
    for i in [2,4]:
        for m in [h,x,z]:
            X=s.zeros(5,1);X[i]=m;shifts.append(X)
    LM=s.Matrix.hstack(*[C.vector(C.lie(P,X)) for X in shifts])
    field=s.QQ.frac_field(c,beta)
    LK=DomainMatrix.from_Matrix(LM).convert_to(field).nullspace().to_Matrix().T
    assert LK.cols==2
    stabilizers=[s.Matrix([0,0,-h,0,h]),
                 s.Matrix([0,0,(c+1)*x+(1-c)*z,0,(1-c)*x+(c+1)*z])]
    assert all(all(s.cancel(v)==0 for v in C.vector(C.lie(P,X))) for X in stabilizers)
    print('Universal two stabilizers:',stabilizers,flush=True)
    GG=actual(C,P)
    fam=[C.tensor({I:s.diff(F[I],a) for I in C.pairs}) for a in [c,beta]]
    AA=s.Matrix.hstack(GG,*[C.vector(Z) for Z in fam])
    ref=json.loads((HERE/'cplus_universal_normal_reference.json').read_text())
    assert ref['coefficient_order']==[[list(I),list(m)] for I,m in C.basis]
    U=s.Matrix([s.sympify(a,locals={'c':c,'beta':beta}) for a in ref['normal_coefficients']])
    UR=C.from_vector(U)
    assert all(s.expand(v)==0 for v in C.euler_vector(C.polar(P,UR)))
    print('Universal polynomial normal: PASS',flush=True)
    reports=[]
    for cv,bv in [(-1,1),(2,1),(3,2)]:
        at={c:cv,beta:bv};PP=C.tensor({I:F[I].subs(at) for I in C.pairs});D=C.derivative(PP,True)
        A=AA.subs(at);G=GG.subs(at)
        assert rank(D)==100 and rank(G)==47 and rank(A)==49
        K=DomainMatrix.from_Matrix(D).convert_to(s.QQ).nullspace().to_Matrix().T
        ids=piv(A.row_join(K));norm=[K[:,i-A.cols] for i in ids if i>=A.cols]
        assert len(norm)==1;R=C.from_vector(norm[0]);H=C.euler_vector(C.jacobi(R))
        assert rank(D.row_join(H))==101
        if (cv,bv)==(-1,1):
            U0=U.subs(at)
            assert rank(A.row_join(U0))==50
            assert rank(D.row_join(C.euler_vector(C.jacobi(C.from_vector(U0)))))==101
        reports.append({'c':cv,'beta':bv,'Jacobi':100,'group_vertical_scale':47,'actual':49,'quadratic_augmented':101,'normal':C.encode(R)})
        print('Sample',cv,bv,'PASS',flush=True)
    (HERE/'cplus_independent_audit.json').write_text(json.dumps({
        'universal_Jacobi_two_implementations':True,'family_equality_to_Cplus':True,
        'Q_group_open_orbit_checks':qorbits,
        'quintic':str(s.factor(expected)),'universal_stabilizers':[[str(q) for q in X] for X in stabilizers],
        'sample_checks':reports,'generic_normal_check':True,
        'generic_rank_argument':'Two universal stabilizers bound the group rank by47, two actual parameters give49, and the universal extra normal gives50 kernel vectors; the point rank100 supplies the opposite bound.',
        'normal_reference_source_sha256':ref['source_sha256'],
        'conclusions':{'reduced_component_dimension':24,'general_PGL_orbit_dimension':22,
                       'reduced_rational_quotient_dimension':2,'general_transverse_ring':'K[e]/(e^2)','general_length':2},
        'all_passed':True},indent=2)+'\n')

if __name__=='__main__':main()

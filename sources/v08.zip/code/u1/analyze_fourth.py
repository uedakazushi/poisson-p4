"""Compare fourth implicit residuals modulo the unique cubic relation."""
from higher_jets import *

def main():
 C,P=point();D=C.derivative(P,True);cols=list(rr(D)[1]);rows=list(rr(D[:,cols].T)[1]);MI=inverse(D.extract(rows,cols));DW=D[:,cols]
 records=json.loads((HERE/'higher_jets.json').read_text())
 jets={tuple(x['multiindex']):read_tensor(C,x['tensor']) for x in records['jets']}
 residuals={};u,v=s.symbols('u v')
 for degree in [3,4]:
  for a in range(degree+1):
   key=(a,degree-a);rhs=s.zeros(350,1)
   for ij in sorted(jets):
    kl=(key[0]-ij[0],key[1]-ij[1])
    if sum(ij)>=degree or kl not in jets or ij>kl:continue
    rhs+=C.euler_vector(C.jacobi(jets[ij]) if ij==kl else C.polar(jets[ij],jets[kl]))
   residuals[key]=rhs-DW*MI*rhs[rows,:]
 B3=s.Matrix.hstack(*[residuals[a,3-a] for a in range(4)])
 B4=s.Matrix.hstack(*[residuals[a,4-a] for a in range(5)])
 assert rank(B3)==1
 pivot=list(rr(B3.T)[1])[0];base=B3[:,0];assert base[pivot]!=0
 coeff=base/base[pivot];f3=s.factor(sum(B3[pivot,a]*u**a*v**(3-a) for a in range(4)))
 Y4=B4-coeff*B4[pivot,:]
 er,ep=rr(Y4);er=er.to_Matrix();g4=[s.factor(sum(er[i,a]*u**a*v**(4-a) for a in range(5))) for i in range(len(ep))]
 G=s.groebner([f3]+g4,u,v,order='grlex')
 print('f3=',f3,flush=True);print('independent quartics=',g4,flush=True);print('groebner=',list(G),flush=True)
 data={'cubic':str(f3),'fourth_initial_forms':[str(f) for f in g4],'initial_groebner_through4':[str(f) for f in G],
 'branch_restrictions':{'v=0':[str(s.factor(f.subs(v,0))) for f in g4],'u=-128v':[str(s.factor(f.subs(u,-128*v))) for f in g4],'u=-256v':[str(s.factor(f.subs(u,-256*v))) for f in g4]}}
 (HERE/'fourth_analysis.json').write_text(json.dumps(data,indent=2)+'\n')
 print(data,flush=True)

if __name__=='__main__':main()

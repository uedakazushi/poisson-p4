"""Finite-order divisibility by a single formal obstruction; not an all-order proof."""
from higher_jets import *

def main():
 C,P=point();D=C.derivative(P,True);cols=list(rr(D)[1]);rows=list(rr(D[:,cols].T)[1]);MI=inverse(D.extract(rows,cols));DW=D[:,cols]
 records=json.loads((HERE/'higher_jets.json').read_text());jets={tuple(x['multiindex']):read_tensor(C,x['tensor']) for x in records['jets']};n=max(map(sum,jets));u,v=s.symbols('u v')
 residuals={};polys={}
 for degree in range(3,n+1):
  Bs=[]
  for a in range(degree+1):
   key=(a,degree-a);rhs=s.zeros(350,1)
   for ij in sorted(jets):
    kl=(key[0]-ij[0],key[1]-ij[1])
    if sum(ij)>=degree or kl not in jets or ij>kl:continue
    rhs+=C.euler_vector(C.jacobi(jets[ij]) if ij==kl else C.polar(jets[ij],jets[kl]))
   Bs.append(rhs-DW*MI*rhs[rows,:])
  M=s.Matrix.hstack(*Bs);residuals[degree]=M;polys[degree]=[s.expand(sum(M[i,a]*u**a*v**(degree-a) for a in range(degree+1))) for i in range(350)]
 pivot=list(rr(residuals[3].T)[1])[0];F={d:polys[d][pivot] for d in polys};coeff={0:[s.cancel(polys[3][i]/F[3]) for i in range(350)]};reports=[]
 for degree in range(4,n+1):
  new=[];rem=[]
  for i in range(350):
   r=s.expand(polys[degree][i]-sum(coeff[d][i]*F[degree-d] for d in coeff if degree-d in F))
   q,z=s.div(r,F[3],u,v);new.append(s.expand(q));rem.append(s.factor(z))
  coeff[degree-3]=new
  equations=sorted(set(str(f) for f in rem if f!=0))
  reports.append({'degree':degree,'all_residuals_divisible_to_this_order':not equations,'remainders':equations})
  print(reports[-1],flush=True)
  if equations:break
 out={'scope':'Finite-order verification only. No formal principality or actual branch existence follows from this certificate alone.','degree':n,'pivot_row':pivot,'single_generator_jets':{str(d):str(s.factor(f)) for d,f in F.items()},'reports':reports}
 (HERE/'principal_jet_check.json').write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()

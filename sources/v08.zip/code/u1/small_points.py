from magnetic_family import *
if __name__=='__main__':
 out=[]
 for val in ([0,1,0,0,0,1],[0,0,1,0,0,1],[0,1,1,0,0,1]):out.append(sample(list(val)))
 (HERE/'small_points.json').write_text(json.dumps(out,indent=2)+'\n')

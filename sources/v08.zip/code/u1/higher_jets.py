"""Exact multivariate implicit-equation jets for generic magnetic U1."""
from full_slice import *
from collections import defaultdict
import time

def read_tensor(C,data):
 return C.tensor({tuple(ast.literal_eval(k)):s.sympify(v,locals=dict(zip(map(str,C.x),C.x))) for k,v in data.items()})

def point():
 C=Calculus(5);t,x,y,z,w=C.x
 P=C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,(2,3):-z*z/2,(2,4):z*z+t*z+x*y+2*y*z,(3,4):t*t+z*z+x*z})
 return C,P

def main():
 start=time.time();C,P=point();D=C.derivative(P,projective=True)
 cols=list(rr(D)[1]);rows=list(rr(D[:,cols].T)[1]);Minv=inverse(D.extract(rows,cols));DW=D[:,cols]
 rec=json.loads((HERE/'small_points.json').read_text())[1]
 normals=[read_tensor(C,x) for x in rec['normals']]
 assert len(normals)==2 and len(cols)==100
 assert all(D*C.vector(x)==s.zeros(350,1) for x in normals)
 jets={(1,0):normals[0],(0,1):normals[1]};residuals={};reports=[]
 maxdegree=int(sys.argv[1]) if len(sys.argv)>1 else 6
 for degree in range(2,maxdegree+1):
  labels=[];out=[];new={}
  keys=sorted(jets)
  for a in range(degree+1):
   key=(a,degree-a);rhs=s.zeros(350,1)
   for ij in keys:
    kl=(key[0]-ij[0],key[1]-ij[1])
    if kl not in jets or ij>kl:continue
    J=C.jacobi(jets[ij]) if ij==kl else C.polar(jets[ij],jets[kl])
    rhs+=C.euler_vector(J)
   sol=-Minv*rhs.extract(rows,[0]);vec=s.zeros(150,1)
   for i,j in enumerate(cols):vec[j]=sol[i]
   rem=rhs+DW*sol
   new[key]=C.from_vector(vec);residuals[key]=rem
   labels.append(key);out.append(rem)
  jets.update(new)
  M=s.Matrix.hstack(*out);red,piv=rr(M);red=red.to_Matrix();u,v=s.symbols('u v')
  eq=[s.factor(sum(red[i,j]*u**a*v**b for j,(a,b) in enumerate(labels))) for i in range(len(piv))]
  record={'degree':degree,'obstruction_rank':len(piv),'equations':[str(f) for f in eq],'seconds':round(time.time()-start,3)}
  reports.append(record);print(record,flush=True)
  output={'point':C.encode(P),'normals':rec['normals'],'ranks':{'Jacobi':len(cols),'magnetic_actual':48},'reports':reports,'jets':[{'multiindex':list(k),'tensor':C.encode(z)} for k,z in sorted(jets.items())], 'elimination_rows':rows,'elimination_columns':cols}
  (HERE/'higher_jets.json').write_text(json.dumps(output,indent=2)+'\n')
  if eq:
   print('NONZERO: later jets use the chosen implicit elimination and must be interpreted modulo preceding relations.',flush=True)
 print('DONE',flush=True)

if __name__=='__main__':main()

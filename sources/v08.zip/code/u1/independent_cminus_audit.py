"""Independent direct-polynomial audit of Cminus, no tensor-engine imports."""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
import ast,json,time
import sympy as s
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent;SOURCE=HERE.parent/'cminus'/'cminus_component_certificate.json'
xx=s.symbols('t x y z w');t,x,y,z,w=xx;b,g=s.symbols('b g');pairs=list(combinations(range(5),2));triples=list(combinations(range(5),3));quads=list(combinations(range(5),4))

def mons(degree):return [s.prod(xx[i] for i in I) for I in combinations_with_replacement(range(5),degree)]
m2=mons(2);m4=mons(4)
def rr(M):return DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()
def rank(M):return len(rr(M)[1])
def read(data):
 P=s.zeros(5)
 for k,v in data.items():
  i,j=ast.literal_eval(k);P[i,j]=s.sympify(v,locals=dict(zip(map(str,xx+(b,g)),xx+(b,g))));P[j,i]=-P[i,j]
 return P
def bivec(P):
 out=[]
 for ij in pairs:
  f=s.Poly(s.expand(P[ij]),*xx);out.extend(f.coeff_monomial(m) for m in m2)
 return s.Matrix(out)
def unvec(vec):
 P=s.zeros(5)
 for k,ij in enumerate(pairs):
  P[ij]=sum(vec[15*k+j]*m for j,m in enumerate(m2));P[ij[::-1]]=-P[ij]
 return P
def polar(P,R):
 out={}
 for i,j,k in triples:
  out[i,j,k]=s.expand(sum(P[a,l]*s.diff(R[c,d],xx[l])+R[a,l]*s.diff(P[c,d],xx[l]) for a,c,d in [(i,j,k),(j,k,i),(k,i,j)] for l in range(5)))
 return out
def project(J):
 out=[]
 for I in quads:
  f=s.Poly(s.expand(sum((-1)**j*xx[a]*J[I[:j]+I[j+1:]] for j,a in enumerate(I))),*xx)
  out.extend(f.coeff_monomial(m) for m in m4)
 return s.Matrix(out)
def bracket(P,R):return project(polar(P,R))
def jac(P):return bracket(P,P)/2
def lie(P,X):
 X=s.Matrix(X);A=X.jacobian(xx)
 return (P.applyfunc(lambda q:sum(X[i]*s.diff(q,xx[i]) for i in range(5)))-A*P-P*A.T).applyfunc(s.expand)
def vertical(i,j):
 E=s.Matrix(xx);X=s.zeros(5,1);X[i]=xx[j]
 return E*X.T-X*E.T
def zero(M):return all(s.cancel(a)==0 for a in M)

def main():
 start=time.time();rec=json.loads(SOURCE.read_text());P,R,S,T=[read(rec[k]) for k in ['family','R','S','T']]
 assert zero(jac(P)) and zero(bracket(P,R)) and zero(bracket(P,S)) and zero(bracket(P,T)+jac(R))
 assert all(s.expand(f)==0 for f in polar(P,P).values())
 for i,m in [(2,t),(2,x),(4,z)]:
  X=s.zeros(5,1);X[i]=m;assert zero(lie(P,X))
 print('UNIVERSAL direct derivatives PASS',round(time.time()-start,2),flush=True)
 at={b:0,g:1};P0,R0,S0,T0=[Z.subs(at) for Z in [P,R,S,T]]
 basis=[unvec(s.eye(150)[:,i]) for i in range(150)]
 D=s.Matrix.hstack(*[bracket(P0,Z) for Z in basis]);VV=[vertical(i,j) for i in range(5) for j in range(5)]
 OO=[]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=xx[j];OO.append(lie(P0,X))
 V=s.Matrix.hstack(*[bivec(Z) for Z in VV]);G=s.Matrix.hstack(V,*[bivec(Z) for Z in OO+[P0]])
 A=s.Matrix.hstack(G,bivec(P.diff(b)),bivec(P.diff(g)));E=s.Matrix.hstack(A,bivec(R0),bivec(S0))
 ranks={'Jacobi':rank(D),'vertical':rank(V),'group_vertical_scale':rank(G),'actual_family':rank(A),'actual_plus_R_S':rank(E)}
 assert ranks==rec['sample_ranks'];assert D*E==s.zeros(350,E.cols)
 B=bracket(R0,S0);H=jac(S0);O=bracket(R0,T0)
 assert rank(s.Matrix.hstack(D,B,H))==102 and rank(s.Matrix.hstack(D,B,H,O))==103
 ap=list(rr(A)[1]);amb=s.Matrix.hstack(D,*[bracket(R0,unvec(A[:,j])) for j in ap]);allamb=s.Matrix.hstack(amb,bracket(R0,R0),B)
 ambiguity=[rank(amb),rank(allamb),rank(allamb.row_join(O))];assert ambiguity==[100,101,102]
 cols=rec['implicit_columns'];rows=rec['implicit_rows'];DW=D[:,cols]
 MI=DomainMatrix.from_Matrix(D.extract(rows,cols)).convert_to(s.QQ).inv().to_Matrix()
 Cobs=s.Matrix.hstack(B,H,O);res=Cobs-DW*MI*Cobs[rows,:];minor=res[rec['residual_rows'],:]
 assert minor.det()==12
 report={'independent_implementation':'SymPy polynomial matrices and coordinate derivatives; imports no prior Poisson engine','universal_identities_verified':True,'sample_ranks':ranks,'quadratic_plus_third_rank':103,'ambiguity_ranks':ambiguity,'minor':[[str(a) for a in minor.row(i)] for i in range(3)],'minor_determinant':str(minor.det()),'seconds':round(time.time()-start,3),'all_passed':True}
 (HERE/'independent_cminus_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)

if __name__=='__main__':main()

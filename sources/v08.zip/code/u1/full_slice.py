"""Full150 first Kuranishi slice at the U1 homogenization."""
from pathlib import Path
from itertools import combinations
import ast,json,os,sys
from exact_calculus import Calculus
import sympy as s
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent

def rr(M):return DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()
def rank(M):return len(rr(M)[1])
def inverse(M):return DomainMatrix.from_Matrix(M).convert_to(s.QQ).inv().to_Matrix()
def kernel(M):
 R,piv=rr(M);R=R.to_Matrix();free=[i for i in range(M.cols) if i not in piv];out=s.zeros(M.cols,len(free))
 for j,f in enumerate(free):
  out[f,j]=1
  for k,p in enumerate(piv):out[p,j]=-R[k,f]
 return out

def setup():
 C=Calculus(5);t,x,y,z,w=C.x;p=x*x+2*x*z+3*z*z
 P=C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,(2,3):-z*z/2,(2,4):p+x*y+2*y*z,(3,4):t*t+z*z+x*z})
 assert not any(C.euler_vector(C.jacobi(P)))
 D=C.derivative(P,projective=True);K=kernel(D)
 VV=[C.vertical(i,j) for i in range(5) for j in range(5)];O=[]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=C.x[j];O.append(C.lie(P,X))
 A=s.Matrix.hstack(*[C.vector(B) for B in VV+O+[P]])
 piv=rr(A.row_join(K))[1];normals=[C.from_vector(K[:,i-A.cols]) for i in piv if i>=A.cols]
 wpiv=rr(D)[1];W=s.eye(150)[:,list(wpiv)];rows=list(rr(D[:,list(wpiv)].T)[1]);M=D.extract(rows,list(wpiv));Minv=inverse(M)
 actual=rank(A);assert actual+len(normals)+len(wpiv)==150
 print('point/slice',{'Jacobi':len(wpiv),'actual':actual,'tangent':K.cols,'normals':len(normals)},flush=True)
 return C,P,D,A,normals,W,rows,Minv

def pf(M):return M[0,1]*M[2,3]-M[0,2]*M[1,3]+M[0,3]*M[1,2]
def quintic(C,P):
 M=C.as_matrix(P)
 return s.factor(sum((-1)**i*C.x[i]*pf(M.extract([j for j in range(5) if j!=i],[j for j in range(5) if j!=i])) for i in range(5)))

def main():
 C,P,D,A,R,W,rows,Minv=setup();n=len(R);u=s.symbols('u0:'+str(n))
 c2=[];labels=[];corrections=[];raw=[]
 for i in range(n):
  for j in range(i,n):
   b=C.euler_vector(C.jacobi(R[i])) if i==j else C.euler_vector(C.polar(R[i],R[j]))
   correction=-W*Minv*b.extract(rows,[0]);res=b+D*correction
   c2.append(res);labels.append(u[i]*u[j]);corrections.append(correction);raw.append(b)
 residual=s.Matrix.hstack(*c2);R2,piv=rr(residual.T);E=R2.to_Matrix()[:len(piv),:]
 # E rows are equations in coefficient labels, so use row reduction on residual itself.
 er,ep=rr(residual);er=er.to_Matrix();eq=[s.factor(sum(er[i,j]*labels[j] for j in range(len(labels)))) for i in range(len(ep))]
 q0=quintic(C,P);dD=[]
 for B in R:
  M=C.as_matrix(P)+s.Symbol('h')*C.as_matrix(B)
  f=sum((-1)**i*C.x[i]*pf(M.extract([j for j in range(5) if j!=i],[j for j in range(5) if j!=i])) for i in range(5))
  dD.append(s.factor(s.diff(f,s.Symbol('h')).subs(s.Symbol('h'),0)))
 out={'point':C.encode(P),'Jacobi_rank':rank(D),'actual_rank':rank(A),'normal_count':n,'normals':[C.encode(B) for B in R],'quadratic_obstructions':[str(q) for q in eq],'quadratic_obstruction_rank':len(eq),'degeneracy':str(q0),'normal_degeneracy_derivatives':[str(a) for a in dD],'elimination_rows':rows,'elimination_columns':list(rr(D)[1]),'second_corrections':[{'monomial':str(m),'tensor':C.encode(C.from_vector(v))} for m,v in zip(labels,corrections)]}
 (HERE/'full_slice.json').write_text(json.dumps(out,indent=2)+'\n')
 print('QUADRATIC IDEAL',eq,flush=True);print('QUINTIC',q0,flush=True);print('dD',dD,flush=True)
 print('R',out['normals'],flush=True)

if __name__=='__main__':main()

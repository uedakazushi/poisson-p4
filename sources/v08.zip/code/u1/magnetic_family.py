"""Actual six-coefficient magnetic extension of U1 in full P4."""
from full_slice import *

def sample(vals):
 C=Calculus(5);t,x,y,z,w=C.x;mons=[t*t,t*x,t*z,x*x,x*z,z*z];B=sum(a*m for a,m in zip(vals,mons))
 P=C.tensor({(1,2):t*t-z*z,(1,4):-x*x/2-4*x*z-4*z*z,(2,3):-z*z/2,(2,4):B+x*y+2*y*z,(3,4):t*t+z*z+x*z})
 assert not any(C.euler_vector(C.jacobi(P)))
 D=C.derivative(P,projective=True)
 VV=[C.vertical(i,j) for i in range(5) for j in range(5)];O=[]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=C.x[j];O.append(C.lie(P,X))
 A=s.Matrix.hstack(*[C.vector(Z) for Z in VV+O+[P]])
 mag=[C.tensor({(2,4):m}) for m in mons];AF=s.Matrix.hstack(A,*[C.vector(Z) for Z in mag])
 assert D*AF==s.zeros(350,AF.cols)
 out={'magnetic_coefficients':vals,'Jacobi_rank':rank(D),'orbit_rank_in150':rank(A),'family_rank_in150':rank(AF),'projective_tangent':125-rank(D),'projective_orbit':rank(A)-25,'projective_family':rank(AF)-25,'degeneracy':str(quintic(C,P))}
 K=kernel(D);piv=rr(AF.row_join(K))[1];R=[C.from_vector(K[:,j-AF.cols]) for j in piv if j>=AF.cols]
 Widx=list(rr(D)[1]);rows=list(rr(D[:,Widx].T)[1]);W=s.eye(150)[:,Widx];Minv=inverse(D.extract(rows,Widx))
 u=s.symbols('u0:'+str(len(R)));labels=[];res=[]
 for i,A0 in enumerate(R):
  for j in range(i,len(R)):
   b=C.euler_vector(C.jacobi(A0)) if i==j else C.euler_vector(C.polar(A0,R[j]))
   res.append(b-D[:,Widx]*Minv*b.extract(rows,[0]));labels.append(u[i]*u[j])
 Qr,qpiv=rr(s.Matrix.hstack(*res)) if res else (None,[])
 eq=[] if not res else [s.factor(sum(Qr.to_Matrix()[i,j]*labels[j] for j in range(len(labels)))) for i in range(len(qpiv))]
 out.update({'normal_count':len(R),'quadratic_obstructions':[str(a) for a in eq],'normals':[C.encode(Z) for Z in R]})
 print(json.dumps(out,indent=2),flush=True)
 return out
if __name__=='__main__':
 results=[sample([2,3,5,1,2,3])]
 (HERE/'magnetic_family.json').write_text(json.dumps(results,indent=2)+'\n')

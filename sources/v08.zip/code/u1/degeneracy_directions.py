"""Infinitesimal quintics for the three U1 cubic-obstruction lines."""
from higher_jets import *

def main():
 C,P=point();rec=json.loads((HERE/'small_points.json').read_text())[1];R,S=[read_tensor(C,d) for d in rec['normals']];h=s.symbols('h');t,x,y,z,w=C.x
 def qmat(M):
  return s.expand(sum((-1)**i*C.x[i]*pf(M.extract([j for j in range(5) if j!=i],[j for j in range(5) if j!=i])) for i in range(5)))
 PM=C.as_matrix(P);D=qmat(PM);G=[]
 def coeff(f):return s.Matrix([s.Poly(f,*C.x).coeff_monomial(s.prod(q**a for q,a in zip(C.x,m))) for m in C.monomials(5)])
 for i in range(5):
  for j in range(5):G.append(coeff(C.x[i]*s.diff(D,C.x[j])))
 base=[]
 for a in range(6):
  for b in range(6-a):base.append(coeff(t**a*x**b*z**(5-a-b)))
 A=s.Matrix.hstack(*G,*base);rA=rank(A);out=[]
 for name,B in [('v=0',R),('u=-128v',C.from_vector(-128*C.vector(R)+C.vector(S))),('u=-256v',C.from_vector(-256*C.vector(R)+C.vector(S)))]:
  d=s.factor(s.diff(qmat(PM+h*C.as_matrix(B)),h).subs(h,0));r=rank(A.row_join(coeff(d)))
  out.append({'branch':name,'dD':str(d),'infinitesimal_essential3_mod_PGL':r==rA})
 print('orbit+cone rank',rA,flush=True);print(json.dumps(out,indent=2),flush=True)
 (HERE/'degeneracy_directions.json').write_text(json.dumps({'quintic':str(s.factor(D)),'orbit_plus_cone_rank':rA,'branches':out},indent=2)+'\n')

if __name__=='__main__':main()

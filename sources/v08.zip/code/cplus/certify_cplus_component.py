#!/usr/bin/env python3
"""Full-P4 component certificate for the Cplus free-conic magnetic family."""
from pathlib import Path
import json
import sympy as s
from sympy.polys.matrices import DomainMatrix
from cplus_family import C,build,c,beta
from full_kuranishi import Slice,actual,rk,rref
HERE=Path(__file__).resolve().parent

def frk(M,field):
    R,piv=DomainMatrix.from_Matrix(M).convert_to(field).rref()
    return len(piv),list(piv)

def main():
    F,M,V,W,coeff=build();h,x,y,z,w=C.x
    # Compact formula displayed in the Japanese theorem, independently
    # expanded against the vector-field construction used by build().
    H=h+4*x-4*z
    Ac=3*h*x-5*h*z+7*x*x-12*x*z+5*z*z
    Bc=5*h*x-3*h*z+5*x*x-12*x*z+7*z*z
    L=2*h+18*x-18*z
    U=s.Matrix([2*h*H,-Ac,0,Bc,0]);Y=s.Matrix([0,0,-1,0,1])
    compact=U*Y.T-Y*U.T
    compact[2,4]+=L*(y+w);compact[4,2]-=L*(y+w)
    assert (F.diff(c)-compact/5).applyfunc(s.expand)==s.zeros(5)
    C.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*C.x).terms() if a}
    PF=C.tensor({I:F[I] for I in C.pairs})
    assert C.euler_vector(C.jacobi(PF)).applyfunc(s.expand)==s.zeros(350,1)
    D=C.derivative(PF,True);G=actual(C,PF)
    family=[C.tensor({I:s.diff(F[I],p) for I in C.pairs}) for p in [c,beta]]
    A=s.Matrix.hstack(G,*[C.vector(R) for R in family])
    assert (D*A).applyfunc(s.expand)==s.zeros(350,A.cols)
    at={c:-1,beta:1};P=C.tensor({I:s.expand(F[I].subs(at)) for I in C.pairs})
    actual_family=[C.tensor({I:s.diff(F[I],p).subs(at) for I in C.pairs}) for p in [c,beta]]
    K=Slice(C,P,extra_actual=actual_family)
    assert (rk(K.D),K.group_rank,K.A.cols,len(K.R))==(100,47,49,1)
    # Two independent universal PGL stabilizers give group<=47, family<=49.
    stabilizers=[s.Matrix([0,0,-h,0,h]),s.Matrix([0,0,(c+1)*x+(1-c)*z,0,(1-c)*x+(c+1)*z])]
    for X in stabilizers:
        assert C.vector(C.lie(PF,X)).applyfunc(s.expand)==s.zeros(150,1)
    # A polynomial normal of bidegree(2,1) was constructed by an exact QQ
    # block linear system. Its150 complete coefficients are proof data.
    normal_path=HERE/'universal_normal.json'
    if not normal_path.exists():normal_path=HERE.parent/'data'/'universal_normal.json'
    normal_data=json.loads(normal_path.read_text())
    assert normal_data['coefficient_order']==[[list(I),list(m)] for I,m in C.basis]
    Ru=s.Matrix([s.sympify(v,locals={'c':c,'beta':beta}) for v in normal_data['normal_coefficients']])
    assert (D*Ru).applyfunc(s.expand)==s.zeros(350,1)
    assert rk(A.subs(at).row_join(Ru.subs(at)))==50
    dr,gr,ar=100,47,49;dp=K.wcols;gp=rref(G.subs(at))[1];ap=rref(A.subs(at))[1]
    print('universal kernel upper bound certified; generic ranks',dr,gr,ar,flush=True)
    O2=K.solve_order(2);assert rk(O2)==1
    nz=next((i,v) for i,v in enumerate(O2[:,0]) if v!=0)
    R=K.R[0];j=C.euler_vector(C.jacobi(R));assert rk(K.D.row_join(j))==101
    # The full quintic degeneracy divisor is read from Euler wedge P wedge P.
    def epsilon(I):return (-1)**sum(I[i]>I[j] for i in range(len(I)) for j in range(i+1,len(I)))
    quintic=0
    for omitted in range(5):
        a,b,d,e=[i for i in range(5) if i!=omitted]
        pf=F[a,b]*F[d,e]-F[a,d]*F[b,e]+F[a,e]*F[b,d]
        quintic+=(-1)**omitted*C.x[omitted]*pf
    quintic=s.factor(quintic)
    expected=h*(h*h+2*h*(x-z)+2*(x+z)**2)*(h*h+2*c*h*(x-z)+2*(x+z)**2)
    assert s.expand(quintic-expected)==0
    report={'all_passed':True,'family':{str(I):str(s.factor(F[I])) for I in C.pairs},
            'field':'QQ(c,beta)','universal_projective_Jacobi_identity':True,
            'displayed_compact_family_matches_construction':True,
            'generic_Jacobi_rank':dr,'generic_vertical_group_scale_rank':gr,'generic_actual_family_rank':ar,
            'generic_projective_tangent_dimension':25,'reduced_projective_component_dimension':24,
            'generic_projective_orbit_dimension':22,'generic_rational_quotient_transcendence_degree':2,
            'sample':{str(k):int(v) for k,v in at.items()},'sample_normal':C.encode(R),
            'sample_quadratic_obstruction_rank':1,'sample_first_nonzero_implicit_residual':[nz[0],str(nz[1])],
            'sample_augmented_Jacobi_rank':101,'generic_transverse_ring':'K[epsilon]/(epsilon^2)','generic_length':2,
            'degeneracy_quintic':str(quintic),'essential_variable_bound':3,
            'universal_stabilizers':[[str(v) for v in X] for X in stabilizers],
            'universal_normal_bidegree':[2,1],'universal_normal_file':normal_path.name,
            'universal_extra_normal_coefficients':[str(v) for v in Ru],
            'exact_generic_pivot_columns':{'Jacobi':dp,'group':gp,'family':ap},
            'scope':'This proves one full24D component containing the Cplus homogenization. It does not yet exclude additional components through its special binary-magnetic point beta=0.'}
    (HERE/'cplus_component_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PASS full24D component, generic length2, rational quotient dimension2',flush=True)

if __name__=='__main__':main()

"""Find a low-degree universal normal using exact rational block equations."""
from pathlib import Path
import json,sys
import sympy as s
from sympy.polys.matrices import DomainMatrix
from cplus_family import C,build,c,beta
from full_kuranishi import Slice,rref,inverse,rk
HERE=Path(__file__).resolve().parent

def run(dc=1,db=1):
    F,*_=build();C.pol=lambda f:{m:a for m,a in s.Poly(s.expand(f),*C.x).terms() if a}
    PF=C.tensor({I:F[I] for I in C.pairs});D=C.derivative(PF,True)
    at={c:-1,beta:1};P=C.tensor({I:F[I].subs(at) for I in C.pairs})
    fam=[C.tensor({I:s.diff(F[I],p).subs(at) for I in C.pairs}) for p in [c,beta]]
    K=Slice(C,P,extra_actual=fam);AR=s.Matrix.hstack(K.A,K.Rv[0]);_,rows=rref(AR.T)
    ell=s.zeros(1,150);temp=inverse(AR[rows,:])[-1,:]
    for j,k in enumerate(rows):ell[k]=temp[j]
    assert ell*K.A==s.zeros(1,49) and (ell*K.Rv[0])[0]==1
    mono=[(i,j) for i in range(dc+1) for j in range(db+1)]
    outmono=sorted({(i+k,j+l) for i,j in mono for k,l in [(0,0),(1,0),(0,1)]})
    oi={m:i for i,m in enumerate(outmono)};data={}
    Dterms=[((0,0),D.subs({c:0,beta:0})),((1,0),D.diff(c)),((0,1),D.diff(beta))]
    count=150*len(mono)
    for a,(i,j) in enumerate(mono):
        for (k,l),DM in Dterms:
            for row,col,v in DM.row_list() if isinstance(DM,s.SparseMatrix) else [(r,cc,DM[r,cc]) for r in range(350) for cc in range(150) if DM[r,cc]]:
                key=(350*oi[i+k,j+l]+row,150*a+col);data[key]=data.get(key,0)+v
    lastrow=350*len(outmono)
    for a,(i,j) in enumerate(mono):
        for col,v in enumerate(ell):
            if v:data[lastrow,150*a+col]=(-1)**i*v
    data[lastrow,count]=1
    L=s.SparseMatrix(lastrow+1,count+1,data)
    print('ansatz matrix',L.shape,'nonzero',len(data),flush=True)
    RR,piv=DomainMatrix.from_Matrix(L).convert_to(s.QQ).rref()
    if count in piv:
        print('NO SOLUTION',dc,db,flush=True);return
    R=RR.to_Matrix();sol=s.zeros(count,1)
    for i,j in enumerate(piv):sol[j]=R[i,count]
    U=s.zeros(150,1)
    for a,(i,j) in enumerate(mono):U+=c**i*beta**j*sol[150*a:150*(a+1),:]
    U=U.applyfunc(s.expand)
    assert (D*U).applyfunc(s.expand)==s.zeros(350,1)
    assert rk(K.A.row_join(U.subs(at)))==50
    report={'degree_c':dc,'degree_beta':db,'coefficient_order':[[list(I),list(m)] for I,m in C.basis],
            'normal_coefficients':[str(v) for v in U],'tensor':C.encode(C.from_vector(U)),
            'universal_tangent_identity':True,'sample_actual_plus_normal_rank':50,'all_passed':True}
    (HERE/'universal_normal.json').write_text(json.dumps(report,indent=2)+'\n')
    print('SUCCESS',report['tensor'],flush=True)

if __name__=='__main__':run(*map(int,sys.argv[1:]))

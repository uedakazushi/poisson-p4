"""Polynomial two-parameter full-P4 family through the Cplus magnetic stratum."""
import sympy as s
from explore_points import C,point
h,x,y,z,w=C.x;c,beta=s.symbols('c beta');base=(h,x,z);E=s.Matrix(base)

def build():
    T=s.Matrix([[1,0,0],[0,1,1],[s.Rational(1,2),1,-1]])
    t,u,v=s.symbols('t u v');newbase=(t,u,v);sub={t:h,u:x+z,v:x-z+h/2}
    V=s.Matrix([-8*t*u,5*t*t+2*u*u,-10*t*u+12*u*v])
    W=s.Matrix([2*t*((c-1)*t-4*c*v),-u*((3*c+2)*t-2*c*v),-8*(c-1)*t*v+12*c*v*v+10*u*u])
    a=(2-7*c)*t+18*c*v;b=-8*u
    assert (W.jacobian(newbase)*V-V.jacobian(newbase)*W-a*V-b*W).applyfunc(s.expand)==s.zeros(3,1)
    q1=u*u+t*v;q2=u*u+c*t*v+(1-c)*t*t/2
    assert s.expand(s.det(s.Matrix.hstack(s.Matrix(newbase),V,W))-100*t*q1*q2)==0
    K=(T.inv()*s.Matrix.hstack(V,W).subs(sub,simultaneous=True)).applyfunc(s.expand)
    P0=C.as_matrix(point((s.Rational(1,16),0,0),16))
    V0=s.Matrix([P0[0,2],P0[1,2],P0[3,2]])-s.Rational(16,5)*z*E
    W0=s.Matrix([P0[0,4],P0[1,4],P0[3,4]])-s.Rational(16,5)*x*E
    # Solve the constant2-by2 change of generators, with polynomial identities.
    mon=[h*h,h*x,h*z,x*x,x*z,z*z]
    def vec(U):return s.Matrix([s.Poly(f,*base).coeff_monomial(m) for f in U for m in mon])
    Kv=s.Matrix.hstack(vec(K[:,0].subs(c,-1)),vec(K[:,1].subs(c,-1)))
    M=Kv.gauss_jordan_solve(s.Matrix.hstack(vec(V0),vec(W0)))[0]
    assert all(not q.free_symbols for q in M)
    VF=(K*M).applyfunc(s.expand)
    coeff=(M.det()*M.inv()*s.Matrix([a,b]).subs(sub,simultaneous=True)).applyfunc(s.expand)
    F=s.zeros(5)
    for i,k in enumerate([0,1,3]):
        F[k,2]=VF[i,0];F[2,k]=-VF[i,0];F[k,4]=VF[i,1];F[4,k]=-VF[i,1]
    F[2,4]=-coeff[0]*y-coeff[1]*w+x*x+beta*h*x;F[4,2]=-F[2,4]
    X=s.Matrix([0,0,-16*z/5,0,-16*x/5]);Euler=s.Matrix(C.x)
    F=(F-(Euler*X.T-X*Euler.T)).applyfunc(s.expand)
    assert F.subs({c:-1,beta:0})==P0
    return F,M,V,W,coeff

if __name__=='__main__':
    F,M,V,W,co=build()
    print('M',M)
    print('F',{str(I):str(s.factor(F[I])) for I in C.pairs})

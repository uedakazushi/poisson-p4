"""Full150 polynomial-bivector Kuranishi slices for projective P4 Poisson.

Vertical translations, GL5, and scalar multiplication are actual symmetries.
All rank and implicit-complement calculations are exact over QQ.
"""
from itertools import combinations_with_replacement
from functools import reduce
import math
import sympy as s
from sympy.polys.matrices import DomainMatrix

def rref(M):
    R,p=DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()
    return R.to_Matrix(),list(p)
def rk(M):return len(rref(M)[1])
def inverse(M):return DomainMatrix.from_Matrix(M).convert_to(s.QQ).inv().to_Matrix()
def kernel(M):
    R,p=rref(M);free=[j for j in range(M.cols) if j not in p];K=s.zeros(M.cols,len(free))
    for i,j in enumerate(free):
        K[j,i]=1
        for k,l in enumerate(p):K[l,i]=-R[k,j]
    return K
def primitive(v):
    l=s.ilcm(*[s.denom(a) for a in v]);v=v*l
    g=reduce(math.gcd,[abs(int(a)) for a in v if a],0)
    return v/g
def actual(C,P):
    A=[C.vertical(i,j) for i in range(5) for j in range(5)]
    for i in range(5):
        for j in range(5):
            X=s.zeros(5,1);X[i]=C.x[j];A.append(C.lie(P,X))
    A.append(P)
    return s.Matrix.hstack(*[C.vector(Z) for Z in A])

class Slice:
    def __init__(self,C,P,extra_actual=None):
        self.C=C;self.P=P
        self.D=C.derivative(P,True)
        A=actual(C,P)
        self.group_rank=rk(A)
        if extra_actual:A=A.row_join(s.Matrix.hstack(*[C.vector(Z) for Z in extra_actual]))
        _,ap=rref(A);self.A=A[:,ap]
        assert not any(self.D*self.A)
        self.K=kernel(self.D)
        _,kp=rref(self.A.row_join(self.K))
        self.Rv=[primitive(self.K[:,i-self.A.cols]) for i in kp if i>=self.A.cols]
        self.R=[C.from_vector(v) for v in self.Rv]
        self.u=s.symbols('u0:'+str(len(self.R)))
        _,self.wcols=rref(self.D);self.DW=self.D[:,self.wcols]
        _,self.rows=rref(self.DW.T);self.Mi=inverse(self.DW[self.rows,:])
        self.W=s.eye(150)[:,self.wcols]
        assert rk(s.Matrix.hstack(self.A,*self.Rv,self.W))==150
        self.coefficients={1:{tuple(int(j==i) for j in range(len(self.R))):R for i,R in enumerate(self.R)}}
        self.residuals={}
    def monomials(self,d):
        n=len(self.R)
        return [tuple(t.count(i) for i in range(n)) for t in combinations_with_replacement(range(n),d)]
    def solve_order(self,d):
        C=self.C;mons=self.monomials(d);index={m:i for i,m in enumerate(mons)}
        known=s.zeros(350,len(mons))
        for a in range(1,d):
            b=d-a
            if a>b:continue
            aa=list(self.coefficients[a].items());bb=list(self.coefficients[b].items())
            for i,(mi,A) in enumerate(aa):
                for j,(mj,B) in enumerate(bb):
                    if a==b and i>j:continue
                    m=tuple(x+y for x,y in zip(mi,mj))
                    pol=C.jacobi(A) if a==b and i==j else C.polar(A,B)
                    known[:,index[m]]+=C.euler_vector(pol)
        correction=-self.Mi*known[self.rows,:]
        residual=known+self.DW*correction
        self.coefficients[d]={m:C.from_vector(self.W*correction[:,i]) for i,m in enumerate(mons)}
        self.residuals[d]=residual
        assert not any(residual[self.rows,:])
        return residual
    def residual_polynomials(self,d):
        R=self.residuals[d];mons=[s.prod(u**a for u,a in zip(self.u,m)) for m in self.monomials(d)]
        _,rows=rref(R.T)
        return [s.factor(sum(c*m for c,m in zip(R.row(i),mons))) for i in rows]

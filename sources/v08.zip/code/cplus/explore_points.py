from pathlib import Path
import json
import sympy as s
from poisson_engine import Calculus,rank
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('h x y z w');h,x,y,z,w=C.x

def point(ps=(1,2,3),scale=1):
    a,b,c=map(s.Rational,ps);p=a*x*x+b*x*z+c*z*z
    q=[x*x/16+x*z/2-z*z/16,0,5*x*x/16-x*z/4-z*z/16,
       x*x/16+x*z/4-5*z*z/16,p+(z-x)*(y+w)/8,-x*x/16+x*z/2+z*z/16]
    vals={I:scale*f for I,f in zip([(1,2),(1,3),(1,4),(2,3),(2,4),(3,4)],q)}
    vals[1,2]+=h*h;vals[3,4]+=h*h
    return C.tensor(vals)

def actual(P):
    V=[C.vertical(i,j) for i in range(5) for j in range(5)]
    O=[]
    for i in range(5):
        for j in range(5):
            X=s.zeros(5,1);X[i]=C.x[j];O.append(C.lie(P,X))
    return s.Matrix.hstack(*[C.vector(R) for R in V+O+[P]])

if __name__=='__main__':
    report=[]
    for ps in [(0,0,0),(1,0,0),(0,1,0),(1,0,1),(1,2,3)]:
        P=point(ps);D=C.derivative(P,True);A=actual(P)
        result={'p':list(ps),'Jacobi_rank':rank(D),'actual_rank':rank(A)}
        report.append(result);print(result,flush=True)
    (HERE/'point_search.json').write_text(json.dumps(report,indent=2)+'\n')

#!/usr/bin/env python3
"""Exact AB-to-toric deformation and full150 tangent certificate.
Only ab_engine (a local standalone full coefficient engine) is imported.
No saved matrices, historical helpers or pycache results are used.
"""
from ab_engine import *
from pathlib import Path
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t u a v b');t,u,a,v,b=C.x
C.pol=lambda f:{m:s.expand(z) for m,z in s.Poly(s.expand(f),*C.x).terms() if z!=0}
r,h,c00,c10,c01,c11=s.symbols('r s c00 c10 c01 c11')
k2=-s.Rational(1,8);l2=s.Rational(1,8)
A=t+r*a;B=t+h*b
entries={(1,2):A*A-k2*u*u,(3,4):B*B-l2*v*v,
 (1,3):r*h*(c00*u*v+c10*A*v/k2+c01*u*B/l2+c11*A*B/(k2*l2)),
 (1,4):r*(c00*u*B+c10*A*B/k2+c01*u*v+c11*A*v/k2),
 (2,3):h*(c00*A*v+c10*u*v+c01*A*B/l2+c11*u*B/l2),
 (2,4):c00*A*B+c10*u*B+c01*A*v+c11*u*v}
U=C.tensor(entries)
assert all(s.expand(z)==0 for z in C.cubic_vector(C.jacobi(U)))
M=C.as_matrix(U)
pf=s.expand(M[1,2]*M[3,4]-M[1,3]*M[2,4]+M[1,4]*M[2,3])
expected=(1-r*h*(c00*c11-c10*c01)/(k2*l2))*(A*A-k2*u*u)*(B*B-l2*v*v)
assert s.expand(pf-expected)==0
# Source AB is transformed by an explicit invertible linear map.
old=s.symbols('t x y z w');t0,x,y,z,w=old
oldM=s.zeros(5)
oldentry={(1,2):t0*t0+x*z/2,(1,4):(x*x+4*z*z)/4,
 (2,3):-(x*x+4*z*z)/16,(2,4):x*x+2*x*z+3*z*z,(3,4):t0*t0+x*z/2}
for (i,j),f in oldentry.items():oldM[i,j]=f;oldM[j,i]=-f
new=s.Matrix([t0,x+2*z,y/2+w/4-3*(x-2*z)/8,x-2*z,y/2-w/4-11*(x+2*z)/8])
L=new.jacobian(old);inverse=L.inv()*s.Matrix(C.x)
trans=(L*oldM*L.T).subs(dict(zip(old,inverse)),simultaneous=True).applyfunc(s.expand)
source_values={r:0,h:0,c00:1,c10:0,c01:0,c11:-s.Rational(1,32)}
assert trans==M.subs(source_values).applyfunc(s.expand)
report={'universal_affine_Jacobi_zero':True,'universal_Pfaffian_identity':str(s.factor(expected)),
 'linear_change':str(L),'linear_change_determinant':str(L.det()),
 'source_transform_verified':True,'family_entries':C.encode(U),'points':{}}

def independent_columns(X):
 piv=list(DomainMatrix.from_Matrix(X).convert_to(s.QQ).rref()[1]);return X[:,piv]
def minor_certificate(X):
 cols=list(DomainMatrix.from_Matrix(X).convert_to(s.QQ).rref()[1]);A=X[:,cols]
 rows=list(DomainMatrix.from_Matrix(A.T).convert_to(s.QQ).rref()[1]);det=s.QQ.to_sympy(DomainMatrix.from_Matrix(A[rows,:]).convert_to(s.QQ).det())
 assert det!=0
 return {'rank':len(cols),'rows':rows,'columns':cols,'determinant':str(det)}
for name,values in [('source',source_values),('generic',{r:0,h:0,c00:1,c10:2,c01:3,c11:-s.Rational(1,32)})]:
 P=C.tensor({I:f.subs(values) for I,f in entries.items()});D=C.derivative(P,True)
 V=[C.vertical(i,j) for i in range(5) for j in range(5)];O=[]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=C.x[j];O.append(C.lie(P,X))
 F=independent_columns(s.Matrix.hstack(*[C.vector(Z) for Z in V+O+[P]]))
 magnet=[C.tensor({(2,4):q}) for q in [t*t,t*u,t*v]]
 Rt=C.tensor({I:s.diff(f,r).subs(values) for I,f in entries.items()})
 St=C.tensor({I:s.diff(f,h).subs(values) for I,f in entries.items()})
 G=s.Matrix.hstack(*[C.vector(Z) for Z in magnet+[Rt,St]])
 FG=F.row_join(G);assert not any(D*FG)
 assert F.cols==45 and rank(FG)==50
 d=rank(D);assert d=={'source':98,'generic':100}[name]
 K=s.Matrix.hstack(*D.nullspace());assert K.cols==150-d
 entry={'Jacobi':minor_certificate(D),'orbit_vertical_scale_rank':F.cols,
 'projective_orbit':F.cols-25,'toric_family':minor_certificate(FG),
 'projective_actual_family_dimension':25,'projective_tangent_dimension':125-d}
 if name=='source':
  H=s.Matrix.hstack(F,G,K);piv=list(DomainMatrix.from_Matrix(H).convert_to(s.QQ).rref()[1]);N=H[:,[i for i in piv if i>=F.cols]]
  assert N.cols==7 and N[:,:5]==G
  nts=[C.from_vector(N[:,i]) for i in range(N.cols)]
  mon=[(i,j) for i in range(N.cols) for j in range(i,N.cols)]
  Obs=s.Matrix.hstack(*[C.euler_vector(C.polar(nts[i],nts[j]))/(2 if i==j else 1) for i,j in mon])
  dpiv=list(DomainMatrix.from_Matrix(D).convert_to(s.QQ).rref()[1]);AA=D[:,dpiv]
  rows=list(DomainMatrix.from_Matrix(AA.T).convert_to(s.QQ).rref()[1]);res=Obs-AA*AA[rows,:].inv()*Obs[rows,:]
  qrows=list(DomainMatrix.from_Matrix(res.T).convert_to(s.QQ).rref()[1]);assert len(qrows)==7
  pars=s.symbols('a0:7');eq=[s.expand(sum(res[k,j]*pars[i]*pars[l] for j,(i,l) in enumerate(mon))) for k in qrows]
  p,q=pars[5:];target=[p*p,p*q,q*q,pars[3]*p,(8*pars[2]+3*pars[4])*p,pars[4]*q,(8*pars[1]+3*pars[3])*q]
  GB=s.groebner(eq,*pars,domain=s.QQ);TB=s.groebner(target,*pars,domain=s.QQ);assert GB==TB
  entry['quadratic_Kuranishi']={'normal_variables':[str(z) for z in pars],
   'normal_basis':[C.encode(Z) for Z in nts], 'cokernel_row_indices':qrows,
   'quadratic_forms':[str(s.factor(e)) for e in eq],
   'ideal_generators':[str(s.factor(e)) for e in target],
   'Groebner_basis':[str(f.as_expr()) for f in GB.polys],
   'scope':'Initial degree-two ideal only; no source branch count or full completed ring is asserted.',
   'local_Krull_dimension_from_upper_bound_and_actual_family':25}
  # Explicit upper rank certificate: every column of the residual belongs to these 7 rows' span.
  assert rank(res)==7
 report['points'][name]=entry
 print(name,entry['projective_tangent_dimension'],entry['projective_actual_family_dimension'],flush=True)
report['all_passed']=True
(HERE/'ab_toric_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS',flush=True)

#!/usr/bin/env python3
"""Exact discrete symmetry of U1 and its action on the two-normal quotient."""
from ab_engine import *
from pathlib import Path
import ast
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
record=json.loads((HERE/'u1_normal_reference.json').read_text())
def read(data):
 return C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals={f'x{i}':C.x[i] for i in range(5)}) for I,f in data.items()})
P=read(record['point']);N=[read(a) for a in record['normals']]
S=s.Matrix([-t,x,-y,z,-w-4*z]).jacobian(C.x);assert S*S==s.eye(5)
sub=dict(zip(C.x,S.inv()*s.Matrix(C.x)))
def push(T):
 A=(S*C.as_matrix(T)*S.T).subs(sub,simultaneous=True).applyfunc(s.expand)
 return C.tensor({I:A[I] for I in C.pairs})
assert C.as_matrix(push(P))==-C.as_matrix(P)
V=[C.vertical(i,j) for i in range(5) for j in range(5)];O=[]
for i in range(5):
 for j in range(5):
  X=s.zeros(5,1);X[i]=C.x[j];O.append(C.lie(P,X))
B=[C.tensor({(2,4):f}) for f in [t*t,t*x,t*z,x*x,x*z,z*z]]
F=s.Matrix.hstack(*[C.vector(A) for A in V+O+[P]+B]);piv=list(DomainMatrix.from_Matrix(F).convert_to(s.QQ).rref()[1]);F=F[:,piv];assert F.cols==48
# The actual magnetic family tangent is preserved.
FF=s.Matrix.hstack(*[-C.vector(push(C.from_vector(F[:,j]))) for j in range(F.cols)])
assert rank(F.row_join(FF))==48
H=F.row_join(s.Matrix.hstack(*[C.vector(A) for A in N]));assert rank(H)==50
mat=[];coordinates=[]
for A in N:
 sol,free=H.gauss_jordan_solve(-C.vector(push(A)));assert free.rows==0
 coordinates.append(sol);mat.append(sol[-2:,:])
normal=s.Matrix.hstack(*mat);assert normal==s.eye(2)
lines=[s.Matrix([1,0]),s.Matrix([-128,1]),s.Matrix([-256,1])]
images=[normal*v for v in lines]
assert s.det(s.Matrix.hstack(images[0],lines[0]))==0
assert s.det(s.Matrix.hstack(images[1],lines[1]))==0
assert s.det(s.Matrix.hstack(images[2],lines[2]))==0
u,v=s.symbols('u v');new=normal*s.Matrix([u,v]);f=v*(u+128*v)*(u+256*v)
ratio=s.cancel(f.subs({u:new[0],v:new[1]},simultaneous=True)/f)
report={'linear_symmetry_matrix':str(S),'S_involution':True,'S_push_P_equals_minus_P':True,
 'actual_magnetic_tangent_preserved':True,'normal_matrix_after_scalar_compensation':str(normal),
 'normal_matrix_entries':[[str(a) for a in row] for row in normal.tolist()],
 'line_images':[str(a) for a in images],'cubic_multiplier':str(ratio),
 'proposed_exchange_of_other_two_lines':False,'each_of_three_lines_is_fixed':True,
 'scope':'This actual projective stabilizer involution acts trivially on the normal quotient and does NOT identify the other two candidate tangent lines. Their existence as branches is not asserted here.',
 'all_passed':True}
(HERE/'u1_discrete_symmetry.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)

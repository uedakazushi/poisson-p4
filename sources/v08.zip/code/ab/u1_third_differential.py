#!/usr/bin/env python3
"""Full homogeneous third Poisson differential, without historical helpers."""
from ab_engine import *
from pathlib import Path
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
P=C.tensor({(1,2):t*t-z*z,(1,4):-(x*x+8*x*z+8*z*z)/2,
 (2,3):-z*z/2,(2,4):t*z+z*z+y*(x+2*z),(3,4):t*t+x*z+z*z})

def wedge_sign(I,J):
 if set(I)&set(J):return None,0
 return tuple(sorted(I+J)),(-1)**sum(i>j for i in I for j in J)

def bracket23(P,T):
 """Odd-symbol Schouten formula, overall sign immaterial to ranks."""
 out={K:defaultdict(int) for K in C.quads}
 for I,f in P.items():
  for J,g in T.items():
   for pos,i in enumerate(I):
    K,sg=wedge_sign(I[:pos]+I[pos+1:],J)
    if sg:C.add(out[K],C.product(f,C.diff(g,i)),sg*(-1)**pos)
   for pos,j in enumerate(J):
    K,sg=wedge_sign(I,J[:pos]+J[pos+1:])
    if sg:C.add(out[K],C.product(C.diff(f,j),g),sg*(-1)**pos)
 return {K:{m:a for m,a in v.items() if a} for K,v in out.items()}

m5=C.monomials(5);idx={m:i for i,m in enumerate(m5)}
def euler4(T):
 out=defaultdict(int)
 for I,f in T.items():
  j=next(j for j in range(5) if j not in I);sg=(-1)**sum(i<j for i in I)
  for m,a in f.items():
   mm=list(m);mm[j]+=1;out[idx[tuple(mm)],0]+=sg*a
 return s.SparseMatrix(126,1,{k:v for k,v in out.items() if v})

D2=C.derivative(P,True)
D3=s.Matrix.hstack(*[euler4(bracket23(P,{I:{m:s.S.One}})) for I,m in C.cubic_basis])
print('D2/D3 ranks',rank(D2),rank(D3),flush=True)
# Verify full affine d^2=0 and descent: vertical trivectors are killed.
for I,m in C.basis:
 T=C.polar(P,{I:{m:s.S.One}})
 assert not any(euler4(bracket23(P,T)))
# D3 times E wedge arbitrary quadratic bivectors is zero after Euler projection.
# The 350x150 map S -> E wedge S has image dimension126.
def euler2(S):
 out=defaultdict(int)
 for I,f in S.items():
  for j in range(5):
   if j in I:continue
   K=tuple(sorted((j,)+I));sg=(-1)**sum(i<j for i in I)
   for m,a in f.items():
    mm=list(m);mm[j]+=1;out[C.cindex[K,tuple(mm)],0]+=sg*a
 return s.SparseMatrix(350,1,{k:v for k,v in out.items() if v})
V3=s.Matrix.hstack(*[euler2({I:{m:s.S.One}}) for I,m in C.basis])
assert rank(V3)==126 and D3*V3==s.zeros(126,150)
cols=list(DomainMatrix.from_Matrix(D3).convert_to(s.QQ).rref()[1]);A=D3[:,cols]
rows=list(DomainMatrix.from_Matrix(A.T).convert_to(s.QQ).rref()[1])
det=s.QQ.to_sympy(DomainMatrix.from_Matrix(A[rows,:]).convert_to(s.QQ).det())
assert det
report={'D2_rank':rank(D2),'D3_full_shape':list(D3.shape),'D3_rank':rank(D3),
 'vertical_trivector_rank':126,'projective_trivector_dimension':224,
 'H3_dimension':224-rank(D2)-rank(D3),'differential_squared_zero':True,
 'descends_to_projective_quotient':True,'minor_rows':rows,'minor_columns':cols,'minor_determinant':str(det)}
(HERE/'u1_third_differential.json').write_text(json.dumps(report,indent=2)+'\n')
print(report,flush=True)

#!/usr/bin/env python3
"""Exact polynomial confluence from the two-independent-smoothing component to U1."""
from ab_engine import *
from pathlib import Path
import ast
HERE=Path(__file__).resolve().parent
C=Calculus(5);C.x=s.symbols('t x y z w');t,x,y,z,w=C.x
h,eta=s.symbols('h eta');e=s.symbols('e');q=s.sqrt(2)
# Temporary old fibers y0,w0; then final y=-y0, w=2w0+2y0-2z.
y0,w0=s.symbols('y0 w0');XX=s.Matrix([t,x,y0,z,w0])
U=z+e*y0;A=x/2+z+q*t+e*w0;V=z-e*y0;B=x/2+z-q*t-e*w0
Z=s.Matrix([t,U,A,V,B]);L=Z.jacobian(XX);Li=L.inv()
PM=s.zeros(5);PM[1,2]=(e+eta*e*e)*(t*t+U*A);PM[3,4]=(-e+eta*e*e)*(t*t+V*B)
c=e+e*e/q
PM[1,3]=c*U*V;PM[1,4]=-c*U*B;PM[2,3]=-c*A*V;PM[2,4]=c*A*B;PM=PM-PM.T
Pold=(Li*PM*Li.T).applyfunc(s.expand)
new=s.Matrix([t,x,-y0,z,2*w0+2*y0-2*z]);M=new.jacobian(XX)
P=(M*Pold*M.T).subs({y0:-y,w0:w/2+y+z,e:q*h},simultaneous=True).applyfunc(s.expand)
assert all(f.is_polynomial(t,x,y,z,w,h) for f in P)
assert all(not f.has(q) for f in P)
C.pol=lambda f:{m:s.expand(v) for m,v in s.Poly(s.expand(f),*C.x).terms() if v!=0}
T=C.tensor({I:P[I] for I in C.pairs})
assert all(s.expand(a)==0 for a in C.cubic_vector(C.jacobi(T)))
U1=C.tensor({(1,2):t*t-z*z,(1,4):-(x*x+8*x*z+8*z*z)/2,
 (2,3):-z*z/2,(2,4):t*z+z*z+y*(x+2*z),(3,4):t*t+x*z+z*z})
assert P.subs({h:0,eta:0})==C.as_matrix(U1)
assert s.expand(P[2,4].subs(h,0)-(t*z+z*z+y*(x+2*z)-eta*(t*t+x*z/2+z*z)))==0
F1=s.expand((t*t+U*A).subs({y0:-y,w0:w/2+y+z,e:q*h},simultaneous=True))
F2=s.expand((t*t+V*B).subs({y0:-y,w0:w/2+y+z,e:q*h},simultaneous=True))
pf=s.expand(P[1,2]*P[3,4]-P[1,3]*P[2,4]+P[1,4]*P[2,3]);assert s.expand(pf-(1-2*eta*eta*h*h)*F1*F2)==0
# Exact magnetic gauge quotient.
Xbase=s.Matrix([0,t*t-z*z,z*z/2]);Ybase=s.Matrix([0,-x*x/2-4*x*z-4*z*z,t*t+x*z+z*z]);base=(t,x,z);ell=x+2*z
gauges=[s.expand(sum(Ybase[i]*s.diff(f,base[i]) for i in range(3))-f*ell) for f in base]+[s.expand(-sum(Xbase[i]*s.diff(g,base[i]) for i in range(3))) for g in base]
mons=[t*t,t*x,t*z,x*x,x*z,z*z]
GM=s.Matrix([[s.expand(f).coeff(m) for f in gauges] for m in mons])
# Use polynomial monomial coefficients (coeff(t*z) etc is unambiguous at degree2).
assert rank(GM)==4
expected_gauges=[t*x+2*t*z,x*x+4*x*z,t*t,z*z]
EM=s.Matrix([[s.expand(f).coeff(m) for f in expected_gauges] for m in mons])
assert rank(GM.row_join(EM))==4
report={'polynomial_rational_family':True,'affine_Jacobi_zero':True,'U1_specialization_verified':True,
 'family':C.encode(T),'quadric1':str(s.factor(F1)),'quadric2':str(s.factor(F2)),
 'Pfaffian_product_verified':True,'coordinate_determinant_before_final_fiber_change':str(L.det()),'final_coordinate_determinant':str(s.factor(L.det()/M.det())),
 'magnetic_gauge_generators':[str(f) for f in gauges],'magnetic_gauge_rank':4,
 'magnetic_quotient_coordinates':['b_tz-2*b_tx','b_xz-4*b_xx'],
 'limiting_magnetic_family':'t*z+z**2-eta*(t**2+x*z/2+z**2)',
 'all_magnetic_U1_members_belong_to_T16_by_gauge_scaling_and_closure':True,'points':{}}
def minor_certificate(X):
 cols=list(DomainMatrix.from_Matrix(X).convert_to(s.QQ).rref()[1]);A=X[:,cols]
 rows=list(DomainMatrix.from_Matrix(A.T).convert_to(s.QQ).rref()[1]);det=s.QQ.to_sympy(DomainMatrix.from_Matrix(A[rows,:]).convert_to(s.QQ).det())
 assert det!=0
 return {'rank':len(cols),'rows':rows,'columns':cols,'determinant':str(det)}
for val in [0,1,2]:
 TT=C.tensor({I:P[I].subs({h:val,eta:0}) for I in C.pairs});D=C.derivative(TT,True)
 Vv=[C.vertical(i,j) for i in range(5) for j in range(5)];O=[]
 for i in range(5):
  for j in range(5):
   X=s.zeros(5,1);X[i]=C.x[j];O.append(C.lie(TT,X))
 G=s.Matrix.hstack(*[C.vector(A) for A in Vv+O+[TT]])
 Bb=[C.tensor({(2,4):f}) for f in [t*t,t*x,t*z,x*x,x*z,z*z]]
 GG=G.row_join(s.Matrix.hstack(*[C.vector(A) for A in Bb]))
 R=C.tensor({I:s.diff(P[I],h).subs({h:val,eta:0}) for I in C.pairs})
 info={'D_rank':rank(D),'projective_tangent':125-rank(D),'projective_orbit':rank(G)-25,
       'orbit_plus_curve':rank(G.row_join(C.vector(R)))-25}
 Edir=C.tensor({I:s.diff(P[I],eta).subs({h:val,eta:0}) for I in C.pairs})
 fullfamily=G.row_join(C.vector(R)).row_join(C.vector(Edir))
 assert not any(D*fullfamily)
 info['group_plus_two_parameter_family']=rank(fullfamily)-25
 info['Jacobi_minor']=minor_certificate(D)
 info['family_minor']=minor_certificate(fullfamily)
 if val==0:
  info['magnetic_actual']=rank(GG)-25
  info['magnetic_plus_curve']=rank(GG.row_join(C.vector(R)))-25
  rec=json.loads((HERE/'u1_normal_reference.json').read_text())
  NN=[C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals={f'x{i}':C.x[i] for i in range(5)}) for I,f in rr.items()}) for rr in rec['normals']]
  piv=list(DomainMatrix.from_Matrix(GG).convert_to(s.QQ).rref()[1]);GG=GG[:,piv]
  H=GG.row_join(s.Matrix.hstack(*[C.vector(Z) for Z in NN]));rhs=C.vector(R)
  sol,pars=H.gauss_jordan_solve(rhs);assert pars.rows==0
  co=[s.factor(sol[-2]),s.factor(sol[-1])];info['normal_coordinates_of_curve']=[str(c) for c in co]
  assert co[1]*(co[0]+128*co[1])*(co[0]+256*co[1])==0 and co!=[0,0]
 report['points'][str(val)]=info;print(val,info,flush=True)
report['all_passed']=True
(HERE/'u1_t16_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS',flush=True)

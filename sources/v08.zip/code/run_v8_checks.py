"""Reproduce v8 certificates in isolated work copies, preserving all reference data."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import argparse,json,os,shutil,subprocess,sys,tempfile,time
ROOT=Path(__file__).resolve().parents[1]
JOBS=[
 ('cplus/certify_cplus_component.py',[],'cplus/cplus_component_certificate.json'),
 ('cminus/certify_cminus_component.py',[],'cminus/cminus_component_certificate.json'),
 ('cminus/audit_cplus_component.py',[],'cminus/cplus_independent_audit.json'),
 ('u1/independent_cminus_audit.py',[],'u1/independent_cminus_audit.json'),
 ('ab/ab_toric_certificate.py',[],'ab/ab_toric_certificate.json'),
 ('ab/u1_t16_certificate.py',[],'ab/u1_t16_certificate.json'),
 ('cminus/audit_u1_t16.py',[],'cminus/u1_t16_independent_audit.json'),
 ('u1/magnetic_family.py',[],'u1/magnetic_family.json'),
 ('u1/small_points.py',[],'u1/small_points.json'),
 ('u1/higher_jets.py',['6'],'u1/higher_jets.json'),
 ('u1/analyze_fourth.py',[],'u1/fourth_analysis.json'),
 ('u1/principal_jet_check.py',[],'u1/principal_jet_check.json'),
 ('u1/degeneracy_directions.py',[],'u1/degeneracy_directions.json'),
 ('ab/u1_third_differential.py',[],'ab/u1_third_differential.json'),
 ('ab/u1_discrete_symmetry.py',[],'ab/u1_discrete_symmetry.json'),
]

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--jobs',type=int,default=1)
 ap.add_argument('--output-dir',type=Path,default=ROOT/'data'/'reproduced')
 args=ap.parse_args();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
 env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
 def run(job):
  script,arguments,report=job;start=time.monotonic();name=Path(script).stem;log=out/(name+'.log')
  with tempfile.TemporaryDirectory(prefix='p4_v8_check_') as tmp:
   stage=Path(tmp)/'code';shutil.copytree(ROOT/'code',stage,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
   with log.open('w') as f:
    proc=subprocess.run([sys.executable,str(stage/script),*arguments],env=env,cwd=stage,stdout=f,stderr=subprocess.STDOUT)
   result_file=stage/report
   if result_file.exists():shutil.copy2(result_file,out/result_file.name)
  return {'script':script,'arguments':arguments,'exit_code':proc.returncode,
          'elapsed_seconds':round(time.monotonic()-start,3),'log':log.name,'report':Path(report).name}
 records=[]
 with ThreadPoolExecutor(max_workers=max(1,args.jobs)) as pool:
  futures=[pool.submit(run,job) for job in JOBS]
  for future in as_completed(futures):
   r=future.result();records.append(r);print(('PASS' if r['exit_code']==0 else 'FAIL')+' '+r['script'],flush=True)
 records.sort(key=lambda r:next(i for i,j in enumerate(JOBS) if j[0]==r['script']))
 result={'all_passed':all(r['exit_code']==0 for r in records),'number_of_checks':len(records),
         'python':sys.version.split()[0],'results':records}
 (out/'v8_check_results.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'all_passed':result['all_passed'],'number_of_checks':len(records)},indent=2))
 return 0 if result['all_passed'] else 1

if __name__=='__main__':raise SystemExit(main())

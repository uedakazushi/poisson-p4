"""Verify the delivered checksums, including the unchanged v7 snapshot."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 old=json.loads((ROOT/'data'/'previous_v7_checksums.json').read_text())
 for f,h in old['sha256'].items():assert sha(ROOT/'previous_v7'/f)==h,f
 assert len(old['sha256'])==394
 count=0
 for row in (ROOT/'SHA256SUMS.txt').read_text().splitlines():
  h,f=row.split('  ',1);assert sha(ROOT/f)==h,f;count+=1
 print(json.dumps({'all_passed':True,'previous_v7_unchanged_files':394,'checked_v8_manifest_files':count},indent=2))
if __name__=='__main__':main()

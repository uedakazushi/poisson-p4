射影4空間の Poisson 構造 — 研究継続 第22版
日付：2026年10月29日（Asia/Tokyo）

今回の到達点
第21版に残った8つの E8 四次支持を全て排除した。
第20・21版の帰着を入力とすると、一般階数4かつ実際の退化五次因子 D が
正規である Poisson 構造は、射影座標変換と非零定数倍を除き q_(5,1) 型である。
被約特異支持 C は滑らかな楕円正規五次曲線、D=Sec(C) となる。

この結論は本研究ノートの複素閉点に関する分類である。
全 P4 の完全分類、Jacobi スキームの被約性、既約成分数の確定は主張しない。
階数2、非正規な被約 D、非被約 D、族の閉包・交わり・冪零構造が残る。
従来の全体の既約成分数の下界57は変更していない。

主要ファイル
  p4_poisson_completeness_v22.pdf   日本語の本文
  p4_poisson_completeness_v22.tex   LuaLaTeX 原稿
  sections/                       証明の本文
  data/e8_jets/                   8モデル・25成分の全 first-jet 必要式
  data/22/                        二つの conic の4証明書
  data/31_ss/                     twisted cubic と直線の SS 七場合
  data/31_nn/                     NN の全場合、全分母例外、二次体証明書
  data/families/                  実在する非正規二族の全 P と F
  data/211_triple_certificate.json 三重点の追加の完全消去証明書
  code/                           検証・生成コード
  audits/                         最終検証結果と独立した幾何学的監査
  proofs/independent/              別の幾何学的証明と入力条件の説明
  previous_v21/                   第21版の全1666ファイルを変更せずに保存
  previous_v21.pdf                第21版 PDF の同一コピー
  SHA256SUMS.txt                  全収録物のハッシュ
  HANDOFF.txt                     次回研究用の詳細な引継ぎ

本文の再コンパイル
LuaLaTeX、luatexja、HaranoAji フォントを含む TeX 環境で、このディレクトリから：

  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v22.tex

latexmk がなければ lualatex を相互参照が確定するまで2～3回実行する。
記入欄、フォーム、入力 widget は含めていない。

証明書の独立再検証（Python 標準ライブラリのみ）

  python3 code/run_checks.py --output-directory /tmp/p4-v22-checks

22:228、211:110、31 SS:1243、31 NN:658、合計2239項目を確認する。
ast/Fraction と疎多項式、一変数 Euclid 演算を用い、数値標本検査はしない。
一般パラメータの全分母を照合し、零点となる全ての例外を別途検証する。
二次体 Q[theta]/(theta^2+13511) の恒等式は両複素埋め込みに適用される。

SymPy による別の座標変換・短い証明書等も含める場合

  python3 -m pip install -r requirements.txt
  python3 code/run_checks.py --output-directory /tmp/p4-v22-all --symbolic

合計10検証群・3229項目。生成器と独立の J P J^T による全25成分の
normal Taylor 展開が850項目、その他の追加検算が140項目である。
検証は指定された出力ディレクトリへ結果を書き、模型・証明書・前版は変更しない。
実行時には通常の Python import cache が code/ に作られることがある。

生成の再現（SymPy 1.14）

  python3 code/build_e8_jets.py previous_v21/data/tree_jacobi_models /tmp/p4-v22-jets
  python3 code/solve_211_triple.py \
    previous_v21/data/tree_jacobi_models/211_triple.json \
    data/e8_jets/211_triple.json /tmp/p4-v22-211-certificate.json

他の大きな線形消去については、全入力式・線形結合・代入を保存している。
独立検証器は保存済み証明書の正しさと入力からの帰属を再確認する。
幾何学的な場合分けと非零条件の網羅性は本文と独立監査で扱い、
係数恒等式の検査がそれに代わるとは主張しない。

ファイル完全性と前版保存の確認

  python3 code/verify_bundle.py

以前の版を再コンパイル・変更してから検査すると、保存ハッシュは当然一致しなくなる。
前版を変更しない複製を作って作業することを推奨する。

二つの例外族の意味
SS rho=-1 では全 Jacobi 条件を満たす族が残るが F=Q2*Q3 となる。
NN s=-1/3 では二つの自由変数が残るが F∈(x2,x3)^2、
[x1^3*x3^2]F=-1/120 となり、全て平面に沿って特異である。
両者を「単位イデアル」と誤記していない。どちらも一般階数4の実在族で、
正規性に反するため今回の分類対象から除外される。
族の表示に現れるパラメータ数は、PGL5 商のモジュライ次元とは限らない。

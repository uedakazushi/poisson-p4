射影4空間の Poisson 構造：研究継続 v4
2026-10-28

主な成果
========
1. 固定した滑らかな二次超曲面上の一般 Poisson 構造の全延長 scheme:
   Rat(1,2) は被約な一点、Log(1,1,1) は被約な affine line、
   Aff は v3 の被約な二点（rank2とrank4）。
2. 一般rank2、因子的零点なし、H^0(T_F)=0 の分岐において
   A1=C L なら A3=L A2。残存一線形分岐は A2=C L²,A3=C L³。
   Cone Casimir と cuspidal plane-cubic cone に関する追加制約。
3. 45変数の compatible quadratic locus に、4個の10次元成分を確認。
   非零半単純 modular field の全点は計10個の確認済み成分に含まれる。
   s=u とs=u+v の固定層は scheme として分類した。
4. rank4の特異二次超曲面Qを二重にもつD=H+2Qについて、
   Hが頂点を通らない配置は不存在、頂点を通り底に接しない配置は一軌道。
   後者は既知23次元成分の滑らかな22次元境界軌道。

全P4成分数の証明済み下界は47のまま。完全分類とは主張しない。
45変数の追加4成分を全P4の追加4成分として数えてはいけない。
文献上の新規性の認定はしていない。

内容
====
p4_poisson_completeness_v4.pdf    日本語のLuaLaTeX研究ノート
*.tex                           対応する完全なsource
code/                           今回のexact verificationと独立実装
data/                           再検証可能な証明書と実行記録
proofs/                         完全証明、独立監査、明示した未検証の次課題
previous_v3/                    変更していない前回記録（内部にv2・baselineを含む）
HANDOFF.txt                     次回の継続に必要な到達点と注意
SHA256SUMS.txt                  本bundleのファイルハッシュ

再現方法
========
Python3、NumPy、SymPy1.14以上を使用する。
確認環境はPython3.12、NumPy2.3.5、SymPy1.14.0。
整数・有理数上の計算のみ。乱数・浮動小数近似を判定に使わない。

bundleのrootから:

    python3 code/run_v4_checks.py

七つの実行がすべてPASSになる。
data/v4_check_results.jsonに結果とコードのハッシュを記録する。
初めの延長計算を独立したSymPy実装でも再構成し、
260/332個のJacobi係数、全ideal、小行列式、制限空間の次元を照合する。
modular固定層は最大九変数の有限なGröbner計算でidealの等式を検証する。
全45変数、61変数、78変数の最小素分解を完了したという意味ではない。

個別の計算:

    python3 code/certify_quadric_extensions.py
    python3 code/independent_audit_extensions.py
    python3 code/zero_eigenvalue_decomposition.py
    python3 code/equal_decomposition.py
    python3 code/verify_nonregular_forms.py
    python3 code/tangent_nonregular.py
    python3 code/verify_t4_boundary.py

結果はdata/に書き込む。
code/の二つの多項式補助モジュールはhistorical helperのコピー。
その他のv3補助コードはprevious_v3/code/から読む。
previous_v3/そのものを移動・省略すると一部のimportが成立しない。
historical helperの単独mainは今回の再現対象ではない。

LuaLaTeXでの再組版:

    latexmk -lualatex -interaction=nonstopmode -halt-on-error \
      p4_poisson_completeness_v4.tex

LuaLaTeX、luatexja、HaranoAjiフォント、通常のAMS/geometry/hyperref packageを使う。
PDFには書き込み欄・フォームを設けていない。

次元の規約
==========
全P4空間は非零Poisson bivectorの定数倍を除いたprojectivization。
PGL5による商はまだ取っていない。
45変数locusはaffine dimension。
固定smoothQ3のRat12/Log111のprojective dimensionsは16/13。
LPT Table1の17/14との不一致は、直接パラメータ数と独立微分rankで確認し、
PDF中に明記した。Affのprojective dimensionは8。

独立監査
========
proofs/independent_extension_audit.txt
proofs/cross_audit_one_linear_cubic.txt
proofs/cross_audit_cone_casimir.txt
proofs/cross_audit_modular_v4.txt

監査とexact checksは再現性のためのものであり、査読・完全分類・新規性の認定ではない。

#!/usr/bin/env python3
"""Recompute all seven v4 exact certificates from this self-contained bundle."""
from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent
OUT=HERE.parent/'data'
OUT.mkdir(parents=True,exist_ok=True)
SCRIPTS=[
    'certify_quadric_extensions.py',
    'independent_audit_extensions.py',
    'zero_eigenvalue_decomposition.py',
    'equal_decomposition.py',
    'verify_nonregular_forms.py',
    'tangent_nonregular.py',
    'verify_t4_boundary.py',
]

def main():
    import numpy
    import sympy
    results=[]
    for name in SCRIPTS:
        started=time.monotonic()
        proc=subprocess.run([sys.executable,str(HERE/name)],cwd=HERE.parent,
                            text=True,capture_output=True)
        log=OUT/(Path(name).stem+'.log')
        log.write_text(proc.stdout+('\nSTDERR\n'+proc.stderr if proc.stderr else ''))
        record={'script':name,'exit_code':proc.returncode,
                'elapsed_seconds':round(time.monotonic()-started,3),
                'script_sha256':hashlib.sha256((HERE/name).read_bytes()).hexdigest(),
                'log':log.name}
        results.append(record)
        print(('PASS' if proc.returncode==0 else 'FAIL'),name,
              record['elapsed_seconds'],'seconds',flush=True)
        if proc.returncode:
            print(proc.stdout[-3000:]+proc.stderr[-3000:],flush=True)
            break
    report={'python':platform.python_version(),'numpy':numpy.__version__,
            'sympy':sympy.__version__,'results':results,
            'all_passed':len(results)==len(SCRIPTS) and all(r['exit_code']==0 for r in results),
            'scope':'Seven v4 exact computations; mathematical proof audits are separately in proofs/.'}
    (OUT/'v4_check_results.json').write_text(json.dumps(report,indent=2)+'\n')
    if not report['all_passed']:raise SystemExit(1)

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Exact normal forms, finite identifications and toric degenerations.

Requires SymPy 1.14 and the bundled v3 coefficient helper.
"""
from pathlib import Path
from fractions import Fraction as F
import itertools,json
import modular_helpers as helper
import semisimple_quadratic as s
import sympy as sp
HERE=Path(__file__).resolve().parent
x=sp.symbols('x1:5')
t=sp.symbols('t1:12')

def matrix_from_ans(ans):
    Q=sp.zeros(4)
    for I,q in ans['Q'].items():
        expr=0
        for m,p in q.items():
            coeff=sum(sp.Rational(c.numerator,c.denominator)*sp.prod(t[i] for i in mon) for mon,c in p.items())
            expr+=coeff*sp.prod(v**k for v,k in zip(x,m))
        Q[I[0],I[1]]=expr;Q[I[1],I[0]]=-expr
    return Q

def push(Q,G,scale=1):
    sub=dict(zip(x,G.inv()*sp.Matrix(x)))
    return (scale*G*Q.applyfunc(lambda q:q.subs(sub,simultaneous=True))*G.T).applyfunc(sp.expand)

def embed_GL2(G):
    M=sp.zeros(4)
    for i in range(2):
        for j in range(2):
            M[2*i,2*j]=G[i,j]
            M[2*i+1,2*j+1]=G.inv().T[i,j]
    return M

def parameters(Q,ans):
    out=[]
    for I,m in ans['free_basis']:
        out.append(sp.Poly(Q[I[0],I[1]],*x).coeff_monomial(sp.prod(v**k for v,k in zip(x,m))))
    return out

def main():
    ans=s.invariant_space(1,1);Q=matrix_from_ans(ans)
    points={name:Q.subs(dict(zip(t,map(sp.Rational,values)))) for name,values in helper.EQUAL_POINTS.items()}
    swap=embed_GL2(sp.Matrix([[0,1],[1,0]]))
    g0=sp.Matrix([[0,1,0,0],[-1,0,0,0],[0,0,0,1],[0,0,-1,0]])
    # Universal Weyl formula on the normalized semisimple Q13 chart.
    a,b,c,d,e,f,g,h,z=sp.symbols('a b c d e f g h z')
    im=[a,g,f,b,c,1+z-e-h,d,e,f,g,h]
    N=Q.subs(dict(zip(t,im)))
    nim=[-b,-f,-g,-a,-d, -(1+z-e-h),-c,1-h,-g,-f,1-e]
    assert push(N,swap)==Q.subs(dict(zip(t,nim))).applyfunc(sp.expand)
    # The complement U=V=0 is an explicit rank-one symmetric matrix orbit.
    Qzero=Q.subs(dict(zip(t,[a,g,f,b,0,0,0,e,f,g,1-e])))
    S=sp.Matrix([[a,e,g],[e,-b,f],[g,f,sp.Rational(1,2)-e]])
    minors=[sp.expand(S.extract(I,K).det()) for I in itertools.combinations(range(3),2)
            for K in itertools.combinations(range(3),2)]
    zeq=[]
    for p in ans['row_reduced_equations']:
        expr=sum(sp.Rational(v.numerator,v.denominator)*sp.prod(t[i] for i in m) for m,v in p.items())
        zeq.append(sp.expand(expr.subs(dict(zip(t,[a,g,f,b,0,0,0,e,f,g,1-e])),simultaneous=True)))
    assert list(sp.groebner(zeq,a,b,e,f,g,domain=sp.QQ))==list(sp.groebner(minors,a,b,e,f,g,domain=sp.QQ))
    tau=sp.Symbol('tau')
    Gup=sp.Matrix([[1,tau],[0,1]])
    R3=sp.Matrix([[1,-tau**2,2*tau],[0,1,0],[0,-tau,1]])
    transformed=push(Qzero,embed_GL2(Gup))
    pp=parameters(transformed,ans)
    Snew=S.subs({a:pp[0],b:pp[3],e:pp[7],f:pp[8],g:pp[9]},simultaneous=True)
    assert (Snew-R3*S*R3.T).applyfunc(sp.expand)==sp.zeros(3)
    W3=sp.Matrix([[0,1,0],[1,0,0],[0,0,-1]])
    pp=parameters(push(Qzero,swap),ans)
    Snew=S.subs({a:pp[0],b:pp[3],e:pp[7],f:pp[8],g:pp[9]},simultaneous=True)
    assert (Snew-W3*S*W3.T).applyfunc(sp.expand)==sp.zeros(3)
    # The normalized dual of E2 lies on Kminus. The dual of E4 has Q13=0,
    # producing the eighth fixed-trace component.
    identifications={}
    for name in ['E1','E2','E3','E4']:
        dual=push(points[name],g0,-1)
        G=sp.eye(2)
        if name=='E1':G=sp.Matrix([[1,0],[1,1]])
        if name=='E2':G=sp.Matrix([[1,0],[2,1]])
        normalized=push(dual,embed_GL2(G))
        pars=parameters(normalized,ans)
        assert Q.subs(dict(zip(t,pars))).applyfunc(sp.expand)==normalized
        identifications[name]={'dual_then_GL2_matrix':[[str(v) for v in row] for row in G.tolist()],
                               'normalized_dual_parameters':[str(v) for v in pars]}
    # Exact display of all brackets and toric degeneration weights.
    weights=[0,1,1,1,2]
    out={}
    for name,R in points.items():
        brackets={''.join(str(i+1) for i in I):str(sp.expand(R[I[0],I[1]])) for I in s.PAIRS}
        pf=sp.expand(R[0,1]*R[2,3]-R[0,2]*R[1,3]+R[0,3]*R[1,2])
        A=sp.Poly(R[0,2],x[0],x[2]);B=sp.Poly(R[1,3],x[1],x[3])
        discU=sp.expand(A.coeff_monomial(x[0]*x[2])**2-4*A.coeff_monomial(x[0]**2)*A.coeff_monomial(x[2]**2))
        discV=sp.expand(B.coeff_monomial(x[1]*x[3])**2-4*B.coeff_monomial(x[1]**2)*B.coeff_monomial(x[3]**2))
        tor=sp.zeros(4);weight_data=[]
        for i,j in s.PAIRS:
            for mon,coef in sp.Poly(R[i,j],*x).terms():
                push_weight=weights[i+1]+weights[j+1]-sum(weights[k+1]*mon[k] for k in range(4))
                assert push_weight>=0
                if not push_weight:
                    expected=tuple(int(k in (i,j)) for k in range(4));assert mon==expected
                    tor[i,j]+=coef*sp.prod(v**k for v,k in zip(x,mon));tor[j,i]=-tor[i,j]
                weight_data.append({'pair':[i+1,j+1],'monomial_exponents':[0]+list(mon),'coefficient':str(coef),'pushforward_weight':push_weight})
        for i,j in [(1,2),(3,4)]:
            weight_data.append({'pair':[i,j],'monomial_exponents':[2,0,0,0,0],'coefficient':'1','pushforward_weight':weights[i]+weights[j]-2*weights[0]})
        torpf=sp.expand(tor[0,1]*tor[2,3]-tor[0,2]*tor[1,3]+tor[0,3]*tor[1,2])
        torpfcoef=sp.simplify(torpf/sp.prod(x));assert torpfcoef!=0
        out[name]={'quadratic_brackets':brackets,'Pfaffian_Q':str(pf),
                   'binary_quadratic_discriminants':[str(discU),str(discV)],
                   'toric_brackets':{''.join(str(i+1) for i in I):str(tor[I[0],I[1]]) for I in s.PAIRS},
                   'toric_Pfaffian_coefficient':str(torpfcoef),'monomial_weights':weight_data}
        print(name,brackets,'discriminants',discU,discV,flush=True)
    report={'normal_forms':out,'Weyl_universal_identity_exact':True,
            'U_V_zero_ideal_equals_symmetric_rank_one_minors':True,
            'U_V_zero_SO3_equivariance_verified_on_generating_unipotents_and_Weyl':True,
            'duality_identifications':identifications,
            'toric_weights':weights,
            'weight_convention':'Pushforward x^alpha*d_i wedge d_j has weight w_i+w_j-alpha dot w.',
            'all_four_have_rank_four_toric_limits':True,
            'ambient_orbit_closures_not_claimed_pairwise_distinct':True}
    (HERE.parent/'data'/'nonregular_normal_forms_certificate.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Exact finite ideal certificates for equal semisimple modular trace.

Requires SymPy >= 1.14 for Groebner reductions. No numerical algebra is used.
"""
from pathlib import Path
import json,sys,time
HERE=Path(__file__).resolve().parent
import modular_helpers
import semisimple_quadratic as s
import sympy as sp

a,b,c,d,e,f,g,h,z=V=sp.symbols('a b c d e f g h z')

def original():
    ans=s.invariant_space(1,1)
    t=sp.symbols('t1:12')
    eq=[sum(sp.Rational(v.numerator,v.denominator)*sp.prod(t[i] for i in m) for m,v in p.items()) for p in ans['row_reduced_equations']]
    return t,eq

def normalized():
    t,eq=original()
    im=[a,g,f,b,c,1+z-e-h,d,e,f,g,h]
    return [sp.expand(q.subs(dict(zip(t,im)),simultaneous=True)) for q in eq]

def curves():
    zero={v:0 for v in V}
    def rule(**kw):
        r=dict(zero);r.update({sp.Symbol(k):v for k,v in kw.items()});return r
    q=sp.Rational(1,2)
    return {
      'L1':rule(h=1,z=z),
      'L2':rule(e=q,h=1,z=z),
      'L3':rule(h=q,z=z),
      'C1':rule(c=c,h=1,z=1),
      'C2':rule(c=c,e=q,h=1,z=1),
      'D1':rule(d=d,h=1,z=-1),
      'D2':rule(d=d,h=q,z=-1),
      'A1':rule(a=a,h=1,z=q),
      'A2':rule(a=a,e=q,h=1,z=q),
      'B1':rule(b=b,h=1,z=-q),
      'B2':rule(b=b,h=q,z=-q),
      'Kplus':rule(a=-c*c/2,c=c,g=-c/2,h=q,z=q),
      'Kminus':rule(b=d*d/2,d=d,e=q,f=-d/2,h=1,z=-q),
    }

def curve_ideal(r):return [v-r[v] for v in V if v!=r[v]]

def main():
    st=time.time();eq=normalized();rules=curves()
    for name,r in rules.items():
        assert all(sp.expand(q.subs(r,simultaneous=True))==0 for q in eq),name
    # Compute the intersection of the thirteen explicit prime ideals. Each
    # is the graph of a polynomial map A1 -> A9, so primality is immediate.
    w=sp.Symbol('w')
    K=[]
    for name,r in rules.items():
        P=curve_ideal(r)
        if not K:K=P
        else:
            G=sp.groebner([w*q for q in K]+[(1-w)*q for q in P],w,*V,order='lex')
            K=[p.as_expr() for p in G.polys if not p.as_expr().has(w)]
        print('intersection',name,'generators',len(K),'seconds',round(time.time()-st,3),flush=True)
    # Verify equality after inverting z. Every original equation belongs to
    # K, and every generator of K becomes a member of I after z^n for an
    # explicitly bounded exponent n.
    GI=sp.groebner(eq,*V,order='grevlex',domain=sp.QQ)
    GK=sp.groebner(K,*V,order='grevlex',domain=sp.QQ)
    assert all(GK.reduce(q)[1]==0 for q in eq)
    powers=[]
    for j,k in enumerate(K):
        for n in range(9):
            if GI.reduce(z**n*k)[1]==0:
                powers.append(n);break
        else:raise AssertionError(('reverse inclusion not certified',j,k))
    # The normalized nonzero-nilpotent Q13=x1^2 is impossible.
    t,orig=original();im=[a,g,f-2,b,c,1-e-h,d,e,f,g,h]
    nil_eq=[sp.expand(q.subs(dict(zip(t,im)),simultaneous=True)) for q in orig]
    nil_gb=sp.groebner(nil_eq,*V[:-1],order='grevlex')
    assert [p.as_expr() for p in nil_gb.polys]==[1]
    report={
      'equal_trace_fixed_affine_dimension':11,
      'Jacobi_generators':9,
      'semisimple_Q13_normalization':'Q13=z*x1*x3; z nonzero',
      'normalized_variable_order':[str(v) for v in V],
      'normalized_original_generators':[str(q) for q in eq],
      'prime_curves':{name:{str(v):str(r[v]) for v in V} for name,r in rules.items()},
      'intersection_generators':[str(k) for k in K],
      'intersection_generator_z_power_for_original_ideal_membership':powers,
      'localized_ideal_equals_radical_prime_intersection':True,
      'normalized_nonzero_nilpotent_ideal_is_unit':True,
      'fixed_equal_trace_scheme_reduced_components':8,
      'dimension_of_each_fixed_equal_trace_component':3,
      'Sp4_times_scaling_saturated_equal_trace_components':6,
      'additional_full_quadratic_components':4,
      'dimension_of_each_additional_full_quadratic_component':10,
      'maximum_z_power':max(powers),
      'elapsed_seconds':time.time()-st,
    }
    (HERE.parent/'data'/'equal_decomposition_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print('exact localized ideal equality',len(K),'generators, max z power',max(powers),flush=True)

if __name__=='__main__':main()

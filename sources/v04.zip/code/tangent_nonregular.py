#!/usr/bin/env python3
"""Exact tangent and orbit ranks for nonregular semisimple trace points."""
from pathlib import Path
from fractions import Fraction as F
import itertools,json,sys
import numpy as np
HERE=Path(__file__).resolve().parent
import modular_helpers
import semisimple_quadratic as s
import tangent_quadratic_points as t

def evaluate(Q,values):
    out={}
    for I,q in Q.items():
        for mon,coeff in q.items():
            c=sum(c*np.prod([values[i] for i in m],dtype=object) for m,c in coeff.items())
            if c:out.setdefault(tuple(i+1 for i in I),{})[(0,)+mon]=F(c)
    return out

def main():
    mons=[m for m in t.p.DEGREE_TWO if m[0]==0]
    ham=[t.hamiltonian({m:1}) for m in mons]
    basis=[t.v.wedge_fields(a,b) for a,b in itertools.combinations(ham,2)]
    target=[(I,m) for I in itertools.combinations(range(1,5),3) for m in t.p.homogeneous_monomials(3) if m[0]==0]
    equal=s.invariant_space(1,1);zero=s.invariant_space(1,0)
    points={
      'equal_G1':(equal,[0,0,0,0,0,2,0,0,0,0,1]),
      'equal_G2':(equal,[0,0,0,0,0,F(3,2),0,F(1,2),0,0,1]),
      'equal_E1':(equal,[0,0,0,0,1,1,0,0,0,0,1]),
      'equal_E2':(equal,[0,0,0,0,1,F(1,2),0,F(1,2),0,0,1]),
      'equal_E3':(equal,[1,0,0,0,0,F(1,2),0,0,0,0,1]),
      'equal_E4':(equal,[1,0,0,0,0,0,0,F(1,2),0,0,1]),
      'equal_both_zero':(equal,[0,0,0,0,0,0,0,0,0,0,1]),
      'zero_d0_generic':(zero,[1,2,3,0,0,0,0]),
      'zero_dhalf_generic':(zero,[1,2,3,F(1,2),0,0,0]),
      'zero_dhalf_embedded':(zero,[0,0,0,F(1,2),0,0,0]),
    }
    P0={(1,2):{t.mono(0,0):1},(3,4):{t.mono(0,0):1}}
    report={}
    for name,(ans,values) in points.items():
        Q=evaluate(ans['Q'],values)
        # Scale half-integers away before integer modular certificates.
        den=1
        from math import lcm
        for q in Q.values():
            for c in q.values():den=lcm(den,c.denominator)
        Q=t.scale(Q,den)
        Q={I:{m:int(c) for m,c in q.items()} for I,q in Q.items()}
        assert all(not c for c in t.p.affine_jacobi_coefficients(Q).values()),name
        S=t.add(P0,Q)
        assert all(not c for c in t.p.affine_jacobi_coefficients(S).values()),name
        cols=[t.polar(Q,R) for R in basis]
        M=np.array([[col.get(I,{}).get(m,0) for col in cols] for I,m in target],dtype=np.int64)
        rank=len(t.rref(M.tolist())[1])
        orbit=[]
        for h in ham:
            A=np.zeros((5,5),dtype=np.int64)
            for i,q in enumerate(h):
                for m,c in q.items():A[i,m.index(1)]=c
            orbit.append(t.p.bivector_vector(t.v.linear_action_derivative(Q,A)))
        orbitrank=len(t.rref(np.column_stack(orbit).tolist())[1])
        orbitplus=len(t.rref(np.column_stack(orbit+[t.p.bivector_vector(Q)]).tolist())[1])
        fixed=[]
        for eq in ans['row_reduced_equations']:
            row=[]
            for j in range(ans['free_count']):
                total=F(0)
                for m,c in eq.items():
                    if j in m:
                        mm=list(m);mm.remove(j)
                        total+=c*m.count(j)*np.prod([values[k] for k in mm],dtype=object)
                row.append(total)
            fixed.append(row)
        fixedrank=len(t.rref(fixed)[1])
        full=t.p.linearized_jacobi_matrix(S)
        fullcert=t.p.modular_rank_certificate(full)
        fullrank=len(t.rref(full.tolist())[1])
        assert fullrank==fullcert['rank_mod_prime']
        item={'parameter_values':[str(x) for x in values],'scaling_denominator':den,
              'fixed_trace_tangent_dimension':ans['free_count']-fixedrank,
              'quadratic_tangent_dimension':45-rank,'quadratic_jacobi_rank_exact':rank,
              'quadratic_modular_certificate':t.p.modular_rank_certificate(M),
              'Sp4_orbit_dimension':orbitrank,'Sp4_times_scale_orbit_dimension':orbitplus,
              'full_P4_affine_tangent_dimension':126-fullrank,
              'full_P4_jacobi_rank_exact':fullrank,'full_P4_modular_certificate':fullcert}
        if name in ('equal_E1','equal_E2','equal_E3','equal_E4'):
            full_orbit=[]
            for i in range(5):
                for j in range(5):
                    A=np.zeros((5,5),dtype=np.int64);A[i,j]=1
                    full_orbit.append(t.p.bivector_vector(t.v.linear_action_derivative(S,A)))
            VF=np.column_stack([t.p.vertical_bivector_matrix()]+full_orbit+[t.p.bivector_vector(S)])
            vrank=len(t.rref(VF.tolist())[1])
            item['full_P4_vertical_plus_GL5_plus_scale_rank_exact']=vrank
            item['full_P4_projective_orbit_dimension']=vrank-25
            item['full_P4_orbit_modular_certificate']=t.p.modular_rank_certificate(VF)
        if name=='equal_both_zero':
            centralizer=[col for mon,col in zip(mons,orbit) if sum(w*power for w,power in zip([0,1,-1,1,-1],mon))==0]
            center_orbit=len(t.rref(np.column_stack(centralizer).tolist())[1])
            family=np.column_stack(centralizer+[t.p.bivector_vector(t.normal(0,0,0,0,1))])
            family_rank=len(t.rref(family.tolist())[1])
            assert center_orbit==2 and family_rank==3
            item['GL2_centralizer_orbit_dimension']=center_orbit
            item['fixed_trace_actual_family_derivative_rank_exact']=family_rank
        report[name]=item
        print(name,{k:v for k,v in item.items() if 'certificate' not in k},flush=True)
        (HERE.parent/'data'/'nonregular_tangent_certificate.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()

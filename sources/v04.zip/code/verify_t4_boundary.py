#!/usr/bin/env python3
"""Full component, toric degeneration, and transverse double-quadric boundary.

Exact integer polynomial identities, rational row ranks, and nonzero prime-field
minor witnesses. No random specialization or floating point calculation.
"""
from singular_quadric_common import *

def certificate(M):
    cert=p.modular_rank_certificate(M)
    rank=c.sparse_rank([{j:int(v) for j,v in enumerate(row) if v} for row in M])[0]
    assert rank==cert['rank_mod_prime']
    cert['rank_over_Q']=rank
    return cert

def certify_point(P):
    assert not any(p.affine_jacobi_coefficients(P).values())
    J=p.linearized_jacobi_matrix(P)
    V=p.vertical_bivector_matrix()
    M=np.column_stack([V,*[action(P,a,b) for a in range(5) for b in range(5)],p.bivector_vector(P)])
    assert not np.any(J@M)
    jc,vc,mc=certificate(J),certificate(V),certificate(M)
    return {'Jacobi':jc,'vertical':vc,'vertical_orbit_scale':mc,
            'J_times_M_zero_over_Z':True,
            'projective_tangent_dimension':125-jc['rank_over_Q'],
            'projective_orbit_dimension':mc['rank_over_Q']-25}

def poly_product(*polys):
    out={(0,)*5:1}
    for pol in polys:out=p.polynomial_product(out,pol)
    return out

def closed_form_certificate(Q):
    rows=defaultdict(dict)
    for j,(ij,e) in enumerate(c.BASIS):
        for key,v in c.closed_numerator({ij:{e:1}},Q).items():rows[key][j]=v
    keys=sorted(rows)
    A=np.array([[rows[key].get(j,0) for j in range(90)] for key in keys],dtype=np.int64)
    idx={b:i for i,b in enumerate(c.BASIS)}
    cols=[]
    for i in range(4):
        for e in [(0,)*4]+c.monomials(1):
            aa=c.primitive_numerator({i:{e:1}},Q)
            cols.append({idx[ij,ee]:v for ij,pol in aa.items() for ee,v in pol.items()})
    B=np.array([[col.get(i,0) for col in cols] for i in range(90)],dtype=np.int64)
    assert not np.any(A@B)
    ac,bc=certificate(A),certificate(B)
    assert ac['rank_over_Q']==71 and bc['rank_over_Q']==19
    return {'closed_map':ac,'primitive_map':bc,'composition_zero_over_Z':True,
            'closed_kernel_dimension':19,'kernel_equals_affine_primitive_image':True,
            'closure_row_keys':[[list(ijk),list(e)] for ijk,e in keys]}

P=transverse();Delta=delta_transverse();R=rigid();T=t4()
assert not any(p.affine_jacobi_coefficients(Delta).values())
assert not any(p.affine_jacobi_coefficients(P).values())
assert not any(p.affine_jacobi_coefficients(R).values())
assert check_conjugacy()

q={mon(0,0):1,mon(2,2):1,mon(1,3):1}
r={mon(1,1):1,mon(2,4):3}
disc={mon(3,3,4,4):9,mon(1,2,3,4):-18,mon(1,1,2,2):-3,
      mon(1,1,1,3):-4,mon(2,2,2,4):-12}
assert pf(P)==poly_product(q,q)
assert pf(Delta)==poly_product(r,r)
assert add(pf(R),scale(pf(P),-1),scale(pf(Delta),-1))==add(scale(poly_product(q,r),2),disc)

weights=(1,0,0,-1,-1)
toric={}
positive=[]
for ij,pol in T.items():
    toric[ij]={}
    for e,v in pol.items():
        wt=sum(a*b for a,b in zip(e,weights))-weights[ij[0]]-weights[ij[1]]
        assert wt>=0
        if wt==0:toric[ij][e]=v
        else:positive.append({'pair':list(ij),'monomial':list(e),'weight':wt,'coefficient':v})
assert pf(toric)=={mon(1,2,3,4):-3}
assert not any(p.affine_jacobi_coefficients(toric).values())

points={'transverse_rank4_double_quadric':certify_point(P),
        'transverse_pencil_general_point':certify_point(R),
        'T4_normal_form':certify_point(T)}
assert points['transverse_rank4_double_quadric']['projective_tangent_dimension']==23
assert points['transverse_rank4_double_quadric']['projective_orbit_dimension']==22
for k in ('transverse_pencil_general_point','T4_normal_form'):
    assert points[k]['projective_tangent_dimension']==23
    assert points[k]['projective_orbit_dimension']==23

closed={
    'H_avoids_vertex':c.plus(*[c.mul(c.x(i),c.x(i)) for i in range(4)]),
    'H_contains_vertex_transverse_to_base':c.plus(c.ONE,*[c.mul(c.x(i),c.x(i)) for i in range(3)]),
    'H_contains_vertex_tangent_to_base':c.plus(c.x(3),c.mul(c.x(0),c.x(0)),c.mul(c.x(1),c.x(1))),
}
report={
    'status':'proved; identifies an already counted MPS component, not a new component',
    'pencil_affine_Jacobi_identically_zero':True,
    'pencil_Pfaffian':'(x0^2+b^2+a*c+t*(a^2+3*b*d))^2+t*disc',
    'disc':'9*c^2*d^2-18*a*b*c*d-3*a^2*b^2-4*a^3*c-12*b^3*d',
    'exact_conjugacy_to_T4':True,
    'old_coordinates_in_new_y':[
        '4*y0','i*(y1+y2-y3+3*y4)','-y1+y2-y3-3*y4',
        'i*(-3*y1-3*y2-y3+3*y4)','y1-y2-y3/3-y4'],
    'conjugacy_scalar':'(i/2)*P_in_new_coordinates=T4',
    'toric_weights':list(weights),'positive_weight_terms':positive,
    'toric_affine_Pfaffian':'-3*x1*x2*x3*x4',
    'points':points,
    'closed_form_lemma_rank4_quadric':{name:closed_form_certificate(Q) for name,Q in closed.items()},
    'conclusions':{
       'T4_projective_orbit_closure_full_component':True,
       'T4_projective_component_dimension':23,
       'T4_meets_SNC_toric_locus':True,
       'T4_is_among_previously_counted_40':True,
       'transverse_rank4_double_quadric_is_smooth_boundary_orbit':True,
    },
}
out=HERE.parent/'data'/'t4_boundary_certificate.json'
out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'certificate':str(out),'all_checks_passed':True,
                  'point_dimensions':{k:(v['projective_tangent_dimension'],v['projective_orbit_dimension']) for k,v in points.items()}},indent=2))

#!/usr/bin/env python3
"""Portable exact helpers for the singular-quadric boundary certificate.

Requires Python 3 and NumPy. The two polynomial/rank helper modules are supplied
unchanged alongside this file.
"""
from pathlib import Path
from fractions import Fraction
from collections import defaultdict
import itertools, json
import numpy as np
import poisson_p4_components_check as p
import closed_quadric_forms as c
HERE=Path(__file__).resolve().parent


def from_primitive(Q,beta):
    alpha=c.primitive_numerator(beta,Q)
    assert not c.closed_numerator(alpha,Q)
    P={}
    for ij in c.PAIRS:
        kl=tuple(i for i in range(4) if i not in ij)
        pol=c.scale(alpha[kl],c.sign(ij+kl))
        P[tuple(i+1 for i in ij)]={(2-sum(e),)+e:v for e,v in pol.items()}
    assert not any(p.affine_jacobi_coefficients(P).values())
    return P

def add(*args):
    out=defaultdict(int)
    for a in args:p.add_polynomial(out,a)
    return {e:v for e,v in out.items() if v}

def scale(pol,t):return {e:t*v for e,v in pol.items() if t*v}

def pf(P):
    return add(p.polynomial_product(p.bivector_entry(P,1,2),p.bivector_entry(P,3,4)),
               scale(p.polynomial_product(p.bivector_entry(P,1,3),p.bivector_entry(P,2,4)),-1),
               p.polynomial_product(p.bivector_entry(P,1,4),p.bivector_entry(P,2,3)))

def action(P,a,b):
    out={}
    e=[0]*5;e[b]=1
    for i,j in p.PAIRS:
        pol=defaultdict(int)
        p.add_polynomial(pol,p.polynomial_product({tuple(e):1},p.polynomial_derivative(P.get((i,j),{}),a)))
        if i==a:p.add_polynomial(pol,p.bivector_entry(P,b,j),-1)
        if j==a:p.add_polynomial(pol,p.bivector_entry(P,i,b),-1)
        out[i,j]={e:v for e,v in pol.items() if v}
    return p.bivector_vector(out)

def transverse():
    Q=c.plus(c.ONE,c.mul(c.x(1),c.x(1)),c.mul(c.x(0),c.x(2)))
    beta={1:c.x(0),2:c.scale(c.x(3),-2),3:c.scale(c.x(2),-1)}
    return from_primitive(Q,beta)

def mon(*ii):
 e=[0]*5
 for i in ii:e[i]+=1
 return tuple(e)

def delta_transverse():
 return {
  (1,2):{mon(1,1):1,mon(2,4):6},
  (1,3):{mon(3,4):6},
  (1,4):{mon(4,4):-3},
  (2,3):{mon(1,3):-4,mon(2,2):-3},
  (2,4):{mon(1,4):2},
  (3,4):{mon(1,1):1},
 }

def inverse(M):
    n=len(M)
    A=[[Fraction(M[i][j]) for j in range(n)]+[Fraction(int(i==j)) for j in range(n)] for i in range(n)]
    for k in range(n):
        j=next(j for j in range(k,n) if A[j][k])
        A[k],A[j]=A[j],A[k]
        u=A[k][k];A[k]=[a/u for a in A[k]]
        for i in range(n):
            if i!=k:
                u=A[i][k]
                if u:A[i]=[a-u*b for a,b in zip(A[i],A[k])]
    return [row[n:] for row in A]

def substitute(pol,M):
    linear=[{mon(j):Fraction(M[i][j]) for j in range(5) if M[i][j]} for i in range(5)]
    out={}
    for e,v in pol.items():
        q={(0,)*5:Fraction(v)}
        for i in range(5):
            for _ in range(e[i]):q=p.polynomial_product(q,linear[i])
        out=add(out,q)
    return out

def transform(P,M):
    """Old coordinates x=M*y; return brackets in the new y coordinates."""
    I=inverse(M)
    Q={ij:substitute(pol,M) for ij,pol in P.items()}
    out={}
    for i,j in p.PAIRS:
        out[i,j]=add(*[scale(Q.get((a,b),{}),I[i][a]*I[j][b]-I[i][b]*I[j][a]) for a,b in p.PAIRS])
    return out

def real_version(P):
    """x=(z0,i*z1,z2,i*z3,z4); multiply new bivector by i."""
    r=(0,1,0,1,0)
    out={}
    for (i,j),pol in P.items():
        new={}
        for e,v in pol.items():
            k=(1+sum(a*b for a,b in zip(e,r))-r[i]-r[j])%4
            assert k%2==0
            new[e]=v*(-1 if k==2 else 1)
        out[i,j]=new
    return out

def rigid():
    P=transverse();D=delta_transverse()
    return {ij:add(P.get(ij,{}),D.get(ij,{})) for ij in p.PAIRS}

def t4():
    return {
        (1,2):{mon(0,0):1,mon(1,2):-1},
        (1,3):{mon(1,3):1},
        (1,4):{mon(1,4):1,mon(2,2):1},
        (2,3):{mon(1,1):3,mon(2,3):-1},
        (2,4):{mon(2,4):-1},
        (3,4):{mon(0,0):1,mon(1,2):2,mon(3,4):3},
    }

def check_conjugacy():
    P=transform(transform(real_version(rigid()),M),D)
    P={ij:scale(pol,Fraction(1,2)) for ij,pol in P.items()}
    assert P=={ij:t4().get(ij,{}) for ij in p.PAIRS}
    return True

M=[[1,0,0,0,0],
   [0,1,1,3,3],
   [0,-1,1,3,-3],
   [0,-3,-3,3,3],
   [0,1,-1,1,-1]]
D=[[Fraction(0) for _ in range(5)] for _ in range(5)]
for i,r in enumerate((4,1,1,Fraction(-1,3),1)):D[i][i]=r


#!/usr/bin/env python3
"""Independent SymPy reconstruction of the fixed-quadric certificates.

Does not import any of the author's Poisson or elimination routines.  It reads
only the JSON certificate, reconstructs both examples from differential forms,
and verifies its coefficient minors and derivative minors over QQ.
"""
from itertools import combinations, combinations_with_replacement
from pathlib import Path
import json
import sympy as s

HERE = Path(__file__).resolve().parent
X = s.symbols('x0:5')
C = s.symbols('c0:10')
PAIRS = list(combinations(range(5), 2))
TRIPLES = list(combinations(range(5), 3))
QUADS = list(combinations(range(5), 4))


def sign(seq):
    return (-1) ** sum(seq[i] > seq[j]
                      for i in range(len(seq)) for j in range(i + 1, len(seq)))


def exponents(indices):
    return tuple(indices.count(i) for i in range(5))


MON2 = [exponents(t) for t in combinations_with_replacement(range(5), 2)]
XS2 = [s.prod(x ** a for x, a in zip(X, m)) for m in MON2]
FORMAL = list(C) + [C[0]*C[7]-C[1]*C[5]+C[2]*C[4],
                   C[0]*C[8]-C[1]*C[6]+C[3]*C[4],
                   C[0]*C[9]-C[2]*C[6]+C[3]*C[5],
                   C[1]*C[9]-C[2]*C[8]+C[3]*C[7],
                   C[4]*C[9]-C[5]*C[8]+C[6]*C[7]]
LEADS = list(C) + [C[0]*C[7], C[0]*C[8], C[0]*C[9],
                  C[1]*C[9], C[4]*C[9]]


def dual_three_form(beta):
    P = s.zeros(5)
    for i, j in PAIRS:
        rest = tuple(k for k in range(5) if k not in (i, j))
        P[i, j] = s.expand(sign((i, j) + rest) * beta[rest])
        P[j, i] = -P[i, j]
    return P


def jacobian(Fs):
    D = s.Matrix([[s.diff(f, x) for x in X] for f in Fs])
    beta = {I: D[:, list(I)].det() for I in TRIPLES}
    return dual_three_form(beta)


def logarithmic(Fs, abc):
    a, b, c = abc
    bcoeff = {(0, 1): 4*a, (0, 2): 4*b, (1, 2): 4*c,
              (0, 3): -2*(a+b), (1, 3): 2*(a-c),
              (2, 3): 2*(b+c)}
    omega = {}
    for u, v in PAIRS:
        omega[u, v] = s.expand(sum(
            bcoeff[i, j] * s.prod(Fs[k] for k in range(4) if k not in (i, j)) *
            (s.diff(Fs[i], X[u])*s.diff(Fs[j], X[v])
             - s.diff(Fs[i], X[v])*s.diff(Fs[j], X[u]))
            for i, j in bcoeff))
    beta = {(i, j, k): s.diff(omega[j, k], X[i])
            - s.diff(omega[i, k], X[j]) + s.diff(omega[i, j], X[k])
            for i, j, k in TRIPLES}
    return dual_three_form(beta)


def extension_rows(P, q):
    B = P.copy()
    for k, (i, j) in enumerate(PAIRS):
        B[i, j] += q*C[k]
        B[j, i] -= q*C[k]
    J = {}
    for i, j, k in TRIPLES:
        J[i, j, k] = s.expand(sum(
            B[i, h]*s.diff(B[j, k], X[h])
            + B[j, h]*s.diff(B[k, i], X[h])
            + B[k, h]*s.diff(B[i, j], X[h]) for h in range(5)))
    records = []
    for I in QUADS:
        z = s.expand(sum((-1)**k * X[i] * J[tuple(j for j in I if j != i)]
                         for k, i in enumerate(I)))
        for m, a in s.Poly(z, *X).terms():
            if a:
                records.append((I, m, s.expand(a)))
    records.sort(key=lambda r: (r[0], r[1]))
    rows = []
    for I, m, a in records:
        poly = s.Poly(a, *C)
        row = [poly.coeff_monomial(t) for t in LEADS]
        assert s.expand(a-s.Add(*(v*f for v, f in zip(row, FORMAL)))) == 0
        rows.append(row)
    return records, s.Matrix(rows)


def vector(P):
    return s.Matrix([s.Poly(P[i, j], *X).coeff_monomial(m)
                     for i, j in PAIRS for m in MON2])


def kernel_columns(q):
    vertical = []
    for direction in range(5):
        for variable in range(5):
            V = s.zeros(5)
            for i, j in PAIRS:
                V[i, j] = X[variable] * (X[i]*int(j == direction)-X[j]*int(i == direction))
                V[j, i] = -V[i, j]
            vertical.append(vector(V))
    qc = []
    for i, j in PAIRS:
        Q = s.zeros(5)
        Q[i, j] = q
        Q[j, i] = -q
        qc.append(vector(Q))
    V = s.Matrix.hstack(*vertical)
    K = s.Matrix.hstack(V, *qc)
    assert V.rank() == 24 and K.rank() == 34
    return V, K


def check_case(name, P, q, derivatives, cert):
    records, M = extension_rows(P, q)
    rank = M.rank()
    fc = cert['formal_rank_certificate']
    assert len(records) == cert['number_of_nonzero_coefficient_equations']
    assert rank == fc['rank']
    mr = fc['row_indices']
    mc = fc['column_indices']
    minor = M.extract(mr, mc)
    assert minor == s.Matrix(cert['minor_matrix'])
    assert minor.det() == s.Rational(fc['minor_determinant'])
    assert [[list(records[i][0]), list(records[i][1])] for i in mr] == cert['minor_row_labels']

    # Verify scheme-theoretic equality directly from the row span.
    rowspace = M.rowspace()
    expected_indices = [i for i in range(10) if i not in cert['free_indices']]
    for i in expected_indices:
        unit = s.zeros(1, 15)
        unit[i] = 1
        assert s.Matrix.vstack(M, unit).rank() == rank
    ex = {C[i]: 0 for i in expected_indices}
    assert all(s.expand(a.subs(ex)) == 0 for _, _, a in records)

    V, K = kernel_columns(q)
    T = s.Matrix.hstack(K, *(vector(D) for D in derivatives))
    dc = cert['fixed_quadric_dimension']['total_rank_certificate']
    assert T.rank() == dc['rank']
    dm = T.extract(dc['row_indices'], dc['column_indices'])
    assert dm.det(method='domain-ge') == s.Rational(dc['minor_determinant'])
    return {'case': name, 'independently_rebuilt_equation_count': len(records),
            'formal_rank': rank, 'formal_minor_determinant': str(minor.det()),
            'kernel_rank': 34, 'derivative_total_rank': int(dc['rank']),
            'derivative_minor_determinant': str(dm.det(method='domain-ge')),
            'fixed_quadric_affine_dimension': int(dc['rank'])-34,
            'exact_ideal_equality': True}


def main():
    data = json.loads((HERE.parent/'data'/'quadric_extension_certificate.json').read_text())
    q = sum(x*x for x in X)
    L = X[0]
    S = sum(a*x*x for a, x in zip((0, 1, 3, 5, 7), X)) + sum(i*X[0]*X[i] for i in range(1, 5))
    P = jacobian((q, L, S))
    derivatives = [jacobian((q, x, S)) for x in X] + [jacobian((q, L, m)) for m in XS2]
    rat = check_case('Rat12', P, q, derivatives, data['Rat12'])
    print(json.dumps(rat), flush=True)

    q = sum(a*x*x for a, x in zip((1, 2, 3, 5, 7), X)) + X[0]*X[3]+X[1]*X[4]
    Fs = [X[0], X[1], X[2], q]
    abc = (1, 7, 17)
    P = logarithmic(Fs, abc)
    derivatives = []
    for k in range(3):
        for x in X:
            changed = Fs.copy()
            changed[k] = x
            derivatives.append(logarithmic(changed, abc))
    derivatives += [logarithmic(Fs, tuple(int(i == k) for i in range(3))) for k in range(3)]
    log = check_case('Log111', P, q, derivatives, data['Log111'])
    print(json.dumps(log), flush=True)

    # A single identity with 15 free quadric coefficients checks universality.
    a = s.symbols('a0:15')
    universal_q = sum(c*m for c, m in zip(a, XS2))
    delta = logarithmic([X[0], X[1], X[2], universal_q], (1, -1, 1))
    delta[3, 4] -= 20*universal_q
    delta[4, 3] += 20*universal_q
    for i, j, k in TRIPLES:
        assert s.expand(X[i]*delta[j, k]-X[j]*delta[i, k]+X[k]*delta[i, j]) == 0

    report = {'audit_method': 'Independent SymPy differential-form reconstruction; no imports from author implementation.',
              'sympy_version': s.__version__, 'Rat12': rat, 'Log111': log,
              'universal_residue_shift_identity_verified': True}
    (HERE.parent/'data'/'independent_extension_audit.json').write_text(json.dumps(report, indent=2)+'\n')
    print('All independent exact checks passed.', flush=True)


if __name__ == '__main__':
    main()

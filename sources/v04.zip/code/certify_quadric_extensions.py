#!/usr/bin/env python3
"""Exact certificates for generic extensions from the two non-affine Q3 types.

Every Jacobi coefficient belongs to the 15-dimensional linear span of the ten
constant-bivector parameters and their five Pluecker quadrics. Maximal minors
at the supplied rational points prove the asserted generic ideal equalities.
This script also checks dimensions of the *fixed* quadric families directly.
"""
from pathlib import Path
from fractions import Fraction as F
import sys, json
import numpy as np

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'p4_poisson_completeness_v3'/'code'
if not BASE.exists(): BASE=HERE.parent/'previous_v3'/'code'
sys.path.insert(0,str(BASE))
import classify_extensions as e
import poisson_p4_components_check as p
import verify_rank2_components as r

PLUCKER=[{(0,7):F(1),(1,5):F(-1),(2,4):F(1)},
         {(0,8):F(1),(1,6):F(-1),(3,4):F(1)},
         {(0,9):F(1),(2,6):F(-1),(3,5):F(1)},
         {(1,9):F(1),(2,8):F(-1),(3,7):F(1)},
         {(4,9):F(1),(5,8):F(-1),(6,7):F(1)}]
FORMAL=[{(i,):F(1)} for i in range(10)]+PLUCKER
LEADS=[(i,) for i in range(10)]+[(0,7),(0,8),(0,9),(1,9),(4,9)]

def determinant(A):
    A=[[F(v) for v in row] for row in A]; d=F(1)
    for j in range(len(A)):
        k=next((k for k in range(j,len(A)) if A[k][j]),None)
        if k is None:return F(0)
        if k!=j:A[k],A[j]=A[j],A[k];d=-d
        a=A[j][j];d*=a
        for k in range(j+1,len(A)):
            c=A[k][j]/a
            if c:
                for h in range(j+1,len(A)):A[k][h]-=c*A[j][h]
                A[k][j]=0
    return d

def exact_rank_minor(M):
    A=[[int(x) if not isinstance(x,F) else x for x in row] for row in M]
    _,cols=e.rref(A)
    _,rows=e.rref(list(map(list,zip(*A))))
    minor=[[A[i][j] for j in cols] for i in rows]
    det=determinant(minor)
    assert det and len(cols)==len(rows)
    return {'rank':len(cols),'row_indices':rows,'column_indices':cols,
            'minor_determinant':str(det)}

def equations(P,q):
    base={I:{m:{():F(c)} for m,c in P.get(I,{}).items() if c} for I in e.PAIRS}
    B={I:e.xadd(base[I],{m:{(k,):F(c)} for m,c in q.items() if c})
       for k,I in enumerate(e.PAIRS)}
    assert not any(e.projective_jacobi(base).values())
    J=e.projective_jacobi(B)
    return sorted((I,m,a) for I,z in J.items() for m,a in z.items() if a)

def extension_certificate(P,q,expected_rank,free_indices):
    records=equations(P,q)
    M=[]
    for I,m,a in records:
        coeff=[a.get(lead,F(0)) for lead in LEADS]
        recon={}
        for c,g in zip(coeff,FORMAL):recon=e.add(recon,g,c)
        assert recon==a, (I,m,a,recon)
        M.append(coeff)
    cert=exact_rank_minor(M)
    assert cert['rank']==expected_rank
    # Recover the exact ideal, with no saturation or radical operation.
    rb,_=e.row_basis([a for I,m,a in records])
    linears=[a for a in rb if max(map(len,a),default=0)<=1]
    required=[{(i,):F(1)} for i in range(10) if i not in free_indices]
    assert linears==required
    ex={i:({(i,):F(1)} if i in free_indices else {}) for i in range(10)}
    assert all(not e.subst(a,ex) for I,m,a in records)
    return {'number_of_nonzero_coefficient_equations':len(records),
            'formal_column_order':['c'+str(i)+str(j) for i,j in e.PAIRS]+
                ['p0123','p0124','p0134','p0234','p1234'],
            'formal_rank_certificate':cert,
            'minor_row_labels':[[list(records[i][0]),list(records[i][1])] for i in cert['row_indices']],
            'minor_matrix':[[str(M[i][j]) for j in cert['column_indices']] for i in cert['row_indices']],
            'row_basis':[e.encode(a) for a in rb],
            'ideal_generators':['c'+str(e.PAIRS[i][0])+str(e.PAIRS[i][1])
                for i in range(10) if i not in free_indices],
            'free_indices':free_indices,
            'exact_ideal_equality_verified':True}

def parameter_dimension(q,columns,expected):
    V=p.vertical_bivector_matrix()
    QC=np.column_stack([p.bivector_vector({I:q}) for I in e.PAIRS])
    K=np.column_stack([V,QC])
    kc=exact_rank_minor(K)
    assert kc['rank']==34
    total=exact_rank_minor(np.column_stack([K]+columns))
    assert total['rank']==34+expected
    return {'kernel_rank':34,'vertical_rank':24,'restriction_kernel_rank':10,
            'total_rank_certificate':total,'intrinsic_affine_dimension':expected,
            'intrinsic_projective_dimension':expected-1}

def main():
    q=p.diagonal_polynomial(2,[1]*5)
    L=p.coordinate_polynomial(0)
    S=p.diagonal_polynomial(2,[0,1,3,5,7])
    for i,a in enumerate([1,2,3,4],1):
        m=[0]*5;m[0]=m[i]=1;S[tuple(m)]=a
    P=p.jacobian_bivector(q,L,S)
    rat=extension_certificate(P,q,15,[])
    derivatives=[p.bivector_vector(p.jacobian_bivector(q,p.coordinate_polynomial(i),S)) for i in range(5)]
    derivatives += [p.bivector_vector(p.jacobian_bivector(q,L,{m:1})) for m in p.DEGREE_TWO]
    rat['fixed_quadric_dimension']=parameter_dimension(q,derivatives,17)
    rat['extension_scheme']='one reduced point'

    q=p.diagonal_polynomial(2,[1,2,3,5,7])
    q[(1,0,0,1,0)]=1;q[(0,1,0,0,1)]=1
    fs=[p.coordinate_polynomial(i) for i in range(3)]+[q]
    pars=[1,7,17]
    P=r.log_bivector(fs,pars)
    log=extension_certificate(P,q,14,[9])
    derivatives=[]
    for k in range(3):
        for i in range(5):
            varied=fs.copy();varied[k]=p.coordinate_polynomial(i)
            derivatives.append(p.bivector_vector(r.log_bivector(varied,pars)))
    derivatives += [p.bivector_vector(r.log_bivector(fs,[int(i==k) for i in range(3)])) for k in range(3)]
    log['fixed_quadric_dimension']=parameter_dimension(q,derivatives,14)
    # The direction (1,-1,1) has projective class 20*q*partial_3 wedge partial_4.
    delta=r.log_bivector(fs,[1,-1,1])
    vec=p.bivector_vector(delta)-20*p.bivector_vector({(3,4):q})
    assert exact_rank_minor(np.column_stack([p.vertical_bivector_matrix(),vec]))['rank']==24
    # Linearity in q makes these 15 checks a universal identity, not a sample.
    for m in p.DEGREE_TWO:
        testfs=fs[:3]+[{m:1}]
        delta=r.log_bivector(testfs,[1,-1,1])
        vec=p.bivector_vector(delta)-20*p.bivector_vector({(3,4):{m:1}})
        assert exact_rank_minor(np.column_stack([p.vertical_bivector_matrix(),vec]))['rank']==24
    log['extension_scheme']='affine line c34; all extensions remain Log1112 rank two'
    log['residue_shift_projectively_equals_20_q_partial34']=True
    log['universal_identity_checked_on_all_15_quadric_monomials']=True
    out={'scope':'Generic normalized restrictions on each of two components of a fixed smooth quadric.',
         'genericity_argument':'Universal rank bounds 15 and 14; nonzero exact maximal minors establish nonempty Zariski open loci.',
         'Rat12':rat,'Log111':log}
    target=HERE.parent/'data'/'quadric_extension_certificate.json'
    target.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:{'formal_rank':v['formal_rank_certificate']['rank'],
                        'scheme':v['extension_scheme'],
                        'intrinsic_projective_dimension':v['fixed_quadric_dimension']['intrinsic_projective_dimension']}
                       for k,v in [('Rat12',rat),('Log111',log)]},indent=2))

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Shared portable dependency discovery for the v4 modular calculations."""
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
for candidate in (
    HERE,
    HERE.parent/'previous_v3'/'code',
    HERE.parent.parent/'previous_v3'/'code',
    HERE.parent/'p4_poisson_completeness_v3'/'code',
    HERE.parent/'p4_v3_quadratic_work',
):
    if candidate.is_dir() and str(candidate) not in sys.path:
        sys.path.append(str(candidate))

EQUAL_POINTS={
    'E1':['0','0','0','0','1','1','0','0','0','0','1'],
    'E2':['0','0','0','0','1','1/2','0','1/2','0','0','1'],
    'E3':['1','0','0','0','0','1/2','0','0','0','0','1'],
    'E4':['1','0','0','0','0','0','0','1/2','0','0','1'],
}


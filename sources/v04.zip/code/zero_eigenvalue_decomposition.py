#!/usr/bin/env python3
"""Exact scheme structure for fixed modular trace s=x1*x2.

Requires SymPy 1.14. The proof file explains the module presentations.
"""
from pathlib import Path
import itertools,json
import modular_helpers
import semisimple_quadratic as s
import sympy as sp
HERE=Path(__file__).resolve().parent
a,b,c,d,e,f,g=V=sp.symbols('a b c d e f g')

def main():
    ans=s.invariant_space(1,0)
    original=[sum(sp.Rational(v.numerator,v.denominator)*sp.prod(V[i] for i in m) for m,v in p.items()) for p in ans['row_reduced_equations']]
    displayed=[a*e+b*g+d*f/2,a*f+2*(c+d)*g,e*f,e*g+f*f/2,f*g,g*g,b*f-2*c*e,e*e,d-2*d*d]
    GI=sp.groebner(original,*V,order='grevlex',domain=sp.QQ)
    GD=sp.groebner(displayed,*V,order='grevlex',domain=sp.QQ)
    assert list(GI)==list(GD)
    # Radical equality: e²,g²,f³ and d(1-2d) are in I, while all original
    # equations vanish on either reduced A3 support.
    assert all(GI.reduce(q)[1]==0 for q in [e*e,g*g,f**3,d*(1-2*d)])
    for value in [0,sp.Rational(1,2)]:
        assert all(sp.expand(q.subs({d:value,e:0,f:0,g:0}))==0 for q in original)
    nil2=[sp.prod(m) for m in itertools.combinations_with_replacement([e,f,g],2)]
    nil3=[sp.prod(m) for m in itertools.combinations_with_replacement([e,f,g],3)]
    A=[a,b,c,e,f,g]
    I0=[sp.expand(q.subs(d,0)) for q in original]
    I1=[sp.expand(q.subs(d,sp.Rational(1,2))) for q in original]
    G0=sp.groebner(I0,*A,order='grevlex',domain=sp.QQ)
    G1=sp.groebner(I1,*A,order='grevlex',domain=sp.QQ)
    L0=[a*e+b*g,a*f+2*c*g,b*f-2*c*e]
    L1=[a*e+b*g+f/4,a*f+(2*c+1)*g,b*f-2*c*e]
    expected0=L0+[e*e,e*f,f*g,g*g,f*f+2*e*g]
    expected1=L1+nil2
    assert list(G0)==list(sp.groebner(expected0,*A,order='grevlex',domain=sp.QQ))
    assert list(G1)==list(sp.groebner(expected1,*A,order='grevlex',domain=sp.QQ))
    assert all(G0.reduce(q)[1]==0 for q in nil3+[a*e*g,b*e*g,c*e*g])
    assert G0.reduce(e*g)[1]!=0
    assert all(G1.reduce(q)[1]==0 for q in nil2)
    M0=sp.Matrix([[a,0,b],[0,a,2*c],[-2*c,b,0]])
    M1=sp.Matrix([[a,sp.Rational(1,4),b],[0,a,2*c+1],[-2*c,b,0]])
    assert M0*sp.Matrix([-b,-2*c,a])==sp.zeros(3,1)
    Delta=a*b+c*c+c/2
    assert sp.expand(M1.det()+Delta)==0
    minors=[M1.extract(I,J).det() for I in itertools.combinations(range(3),2) for J in itertools.combinations(range(3),2)]
    assert list(sp.groebner(minors,a,b,c,domain=sp.QQ))==[1]
    assert list(sp.groebner([Delta,sp.diff(Delta,a),sp.diff(Delta,b),sp.diff(Delta,c)],a,b,c,domain=sp.QQ))==[1]
    # The closed fiber at the origin of the d=0 branch has length5.
    fiber=sp.groebner([q.subs({a:0,b:0,c:0}) for q in expected0],e,f,g,order='grevlex',domain=sp.QQ)
    standard=[]
    for degree in range(4):
        for inds in itertools.combinations_with_replacement(range(3),degree):
            mon=sp.sympify(sp.prod([e,f,g][i] for i in inds))
            remainder=fiber.reduce(mon)[1]
            if remainder!=0 and remainder not in standard:standard.append(remainder)
    monomials=sorted({m for q in standard for m in sp.Poly(q,e,f,g).monoms()})
    fiber_dimension=sp.Matrix([[sp.Poly(q,e,f,g).coeff_monomial(m) for m in monomials] for q in standard]).rank()
    assert fiber_dimension==5
    report={
      'variable_order':[str(v) for v in V],
      'original_Jacobi_generators':[str(q) for q in original],
      'displayed_ideal_generators':[str(q) for q in displayed],
      'displayed_ideal_equals_original':True,
      'radical_generators':[str(e),str(f),str(g),str(d*(1-2*d))],
      'two_reduced_supports_are_affine_3_spaces':True,
      'd0_branch_generators':[str(q) for q in expected0],
      'dhalf_branch_generators':[str(q) for q in expected1],
      'd0_nilradical_cube_zero':True,
      'd0_nilradical_square_one_dimensional_at_origin':True,
      'd0_nilradical_mod_square_is_maximal_ideal_module':'(a,b,c) over C[a,b,c]',
      'd0_origin_fiber_length':5,
      'dhalf_nilradical_square_zero':True,
      'dhalf_nilradical_relation_matrix':[[str(v) for v in row] for row in M1.tolist()],
      'dhalf_nonreduced_support_equation':str(Delta),
      'dhalf_relation_matrix_has_rank_at_least_2_everywhere':True,
      'dhalf_nonreduced_support_is_smooth_affine_quadric':True,
      'orbit_invariant':'h=a*b+(c+d/2)^2, d=0 or1/2',
      'both_reduced_branches_lie_in_regular_semisimple_component_closures':True,
    }
    (HERE.parent/'data'/'zero_eigenvalue_decomposition_certificate.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if not k.endswith('generators') and k!='dhalf_nilradical_relation_matrix'},indent=2))

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Read-only verification of v18 contents and preserved v17 history."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    expected = {}
    for line in (ROOT / "SHA256SUMS.txt").read_text().splitlines():
        value, name = line.split("  ", 1)
        expected[name] = value
    actual = {p.relative_to(ROOT).as_posix(): digest(p) for p in ROOT.rglob("*")
              if p.is_file() and p != ROOT / "SHA256SUMS.txt"
              and "__pycache__" not in p.parts and p.suffix != ".pyc"}
    assert actual == expected, "Current archive differs from SHA256SUMS.txt"
    history = json.loads((ROOT / "data/previous_v17_preservation.json").read_text())
    prior_root = ROOT / "previous_v17"
    prior = {p.relative_to(prior_root).as_posix(): digest(p)
             for p in prior_root.rglob("*") if p.is_file()}
    assert prior == history["files"], "Historical v17 contents changed"
    assert len(prior) == history["count"] == 1392
    assert digest(ROOT / "previous_v17.pdf") == history["pdf_sha256"]
    print(json.dumps({"all_passed": True, "all_files_verified": len(actual),
                      "historical_files_verified": len(prior),
                      "historical_pdf_verified": True}, indent=2))


if __name__ == "__main__":
    main()

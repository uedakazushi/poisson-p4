#!/usr/bin/env python3
"""Run all five v18 exact certificate groups in disposable copies."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
JOBS = [
    ("unimodularization", "local", "verify_unimodularization.py", "verification.json"),
    ("one_point_heisenberg", "local", "verify_one_point_heisenberg.py", "one_point_verification.json"),
    ("multiplicity_three", "m3", "verify_m3_restrictions.py", "verification.json"),
    ("multiplicity_four_flag", "m4", "verify_m4_flag.py", "verification_output.json"),
    ("regular_nilpotent_resonance", "m4", "verify_regular_direction.py", "regular_direction_output.json"),
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    out = (args.output_dir or Path(tempfile.mkdtemp(prefix="p4_v18_reports_"))).resolve()
    (out / "logs").mkdir(parents=True, exist_ok=True)
    (out / "reports").mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="p4_v18_checks_") as tmp:
        base = Path(tmp)

        def run(job):
            label, source, script, report = job
            work = base / label
            shutil.copytree(ROOT / "proofs" / source, work)
            (work / report).unlink(missing_ok=True)
            result = subprocess.run([sys.executable, str(work / script)], cwd=work,
                                    text=True, capture_output=True, check=False)
            (out / "logs" / (label + ".txt")).write_text(result.stdout + result.stderr)
            if result.returncode != 0:
                raise RuntimeError(f"{label} failed; see log")
            data = json.loads((work / report).read_text() if (work / report).exists()
                              else result.stdout)
            if data.get("all_passed") is not True:
                raise RuntimeError(f"{label} did not report all_passed")
            (out / "reports" / (label + ".json")).write_text(json.dumps(data, indent=2) + "\n")
            return {"name": label, "all_passed": True}

        with ThreadPoolExecutor(max_workers=3) as pool:
            results = list(pool.map(run, JOBS))
    summary = {"all_passed": True, "version": 18, "check_count": len(results),
               "checks": results, "archived_originals_modified": False}
    (out / "verification_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"output_directory": str(out), **summary}, indent=2))


if __name__ == "__main__":
    main()

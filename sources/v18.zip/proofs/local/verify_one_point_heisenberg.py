#!/usr/bin/env python3
"""Universal exact audit of the ONE-POINT, not global, Heisenberg lemma."""
from itertools import combinations
import json
import sympy as S

s,t,w,u,v,epsilon=S.symbols('s t w u v epsilon')
coords=(s,t,w,u,v)
normal=(w,u,v)
W=(0,1,3,4)
K=S.zeros(5)
B=S.zeros(5)
for i,j in combinations(W,2):
    K[i,j]=S.Symbol(f'k{i}{j}');K[j,i]=-K[i,j]
    B[i,j]=sum(S.Symbol(f'b{i}{j}_{a}')*z for a,z in enumerate(normal))
    B[j,i]=-B[i,j]
Q=S.zeros(5)
monomials=(w*w,w*u,w*v,u*u,u*v,v*v)
for i,j in combinations(range(5),2):
    Q[i,j]=sum(S.Symbol(f'q{i}{j}_{a}')*z for a,z in enumerate(monomials))
    Q[j,i]=-Q[i,j]
P=s*w*K+t*B+Q

def eval_point_modw(expr):
    return expr.subs({s:1,t:0,w:0}, simultaneous=True)

# A scaling variable extracts the homogeneous component without choosing
# a monomial order in the many free coefficient symbols.
def degree2(expr):
    return S.expand(expr.subs({u:epsilon*u,v:epsilon*v},simultaneous=True)).coeff(epsilon,2)

checks=[]
for i,j,k in combinations(range(5),3):
    expr=0
    for aa,bb,cc in ((i,j,k),(j,k,i),(k,i,j)):
        for ell in range(5):
            expr+=eval_point_modw(P[aa,ell])*eval_point_modw(S.diff(P[bb,cc],coords[ell]))
    actual=degree2(expr)
    expected=eval_point_modw(Q[i,2])*K[j,k]+eval_point_modw(Q[j,2])*K[k,i]+eval_point_modw(Q[k,2])*K[i,j]
    checks.append({'triple':[i,j,k], 'zero_difference':S.expand(actual-expected)==0})

result={
  'global_leading_form':'P1=s*w*K+t*B(w,u,v), row_w(K)=row_w(B)=0',
  'point':'(s,t)=(1,0)',
  'free_K_coefficients':6,
  'free_B_coefficients':18,
  'free_Q_coefficients':60,
  'B_need_not_be_divisible_by_w':True,
  'checked_all_ten_Jacobi_components':checks,
  'all_passed':all(c['zero_difference'] for c in checks),
}
print(json.dumps(result,ensure_ascii=False,indent=2))
assert result['all_passed']

#!/usr/bin/env python3
"""Exact universal first-jet identities, requiring SymPy only."""
from itertools import combinations, product
import json
import sympy as s

x=s.symbols('x0:4')
r=s.symbols('r')
a,b,c,d,e,h=[s.Function(name)(*x) for name in 'abcdeh']
A=s.Matrix([[0,a,b,c],[-a,0,d,e],[-b,-d,0,h],[-c,-e,-h,0]])
Z=s.Matrix([sum(s.diff(A[j,i],x[j]) for j in range(4)) for i in range(4)])
f=a*h-b*e+c*d
P=A.row_join(r*Z).col_join(s.Matrix([list(-r*Z)+[0]]))

def pf4(M):
    return M[0,1]*M[2,3]-M[0,2]*M[1,3]+M[0,3]*M[1,2]

def jac(i,j,k):
    return s.expand(sum(A[i,l]*s.diff(A[j,k],x[l])
          +A[j,l]*s.diff(A[k,i],x[l])
          +A[k,l]*s.diff(A[i,j],x[l]) for l in range(4)))

bp=s.Matrix([(-1)**i*pf4(P.minor_submatrix(i,i)) for i in range(5)])
divergence=[s.simplify(sum(s.diff(P[j,i],(x+(r,))[j]) for j in range(5)))
            for i in range(5)]
pfaffian_errors=[]
for i in range(4):
    others=[j for j in range(4) if j!=i]
    pfaffian_errors.append(s.expand(bp[i]-r*s.diff(f,x[i])
                                  -r*(-1)**i*jac(*others)))
pfaffian_errors.append(s.expand(bp[4]-f))
modular_errors=[]
for i,j in combinations(range(4),2):
    lie=s.expand(sum(Z[k]*s.diff(A[i,j],x[k])
          -A[k,j]*s.diff(Z[i],x[k])-A[i,k]*s.diff(Z[j],x[k])
          for k in range(4)))
    div_jac=s.expand(sum(s.diff(jac(k,i,j),x[k]) for k in range(4)))
    modular_errors.append(s.simplify(lie-div_jac))
div_z=s.expand(sum(s.diff(Z[i],x[i]) for i in range(4)))

# Independent four-dimensional wedge isomorphism certificate.
ka,kb,kc,kd,ke,kh=s.symbols('ka kb kc kd ke kh')
K=s.Matrix([[0,ka,kb,kc],[-ka,0,kd,ke],[-kb,-kd,0,kh],[-kc,-ke,-kh,0]])
triples=list(combinations(range(4),3))
W=s.Matrix([[int(i==col)*K[j,k]+int(j==col)*K[k,i]+int(k==col)*K[i,j]
             for col in range(4)] for i,j,k in triples])
wedge_det=s.factor(W.det())
wedge_check=s.expand(wedge_det-pf4(K)**2)==0

# All degree4 monomials have weight at least12. Higher degrees increase
# the bound by at least3 per added normal variable.
weights=(4,3,3)
degree4=[exp for exp in product(range(5),repeat=3) if sum(exp)==4]
minimum_weight=min(sum(i*j for i,j in zip(exp,weights)) for exp in degree4)
report={
    'divergence_identically_zero':all(v==0 for v in divergence),
    'pfaffian_gradient_difference_equals_signed_jacobi':all(v==0 for v in pfaffian_errors),
    'modular_lie_derivative_equals_divergence_of_jacobi':all(v==0 for v in modular_errors),
    'divergence_of_modular_field_identically_zero':div_z==0,
    'wedge_matrix_determinant':str(wedge_det),
    'wedge_isomorphism_determinant_equals_pfaffian_squared':wedge_check,
    'normal_degree4_monomial_count':len(degree4),
    'normal_degree4_minimum_weight_4_3_3':minimum_weight,
    'pure_cube_weight':3*weights[0],
    'log_discrepancy':sum(weights),
    'lct_bound':'5/6',
}
report['all_passed']=all([report['divergence_identically_zero'],
    report['pfaffian_gradient_difference_equals_signed_jacobi'],
    report['modular_lie_derivative_equals_divergence_of_jacobi'],div_z==0,wedge_check,
    minimum_weight==12])
print(json.dumps(report,ensure_ascii=False,indent=2))
assert report['all_passed']

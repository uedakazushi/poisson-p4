#!/usr/bin/env python3
"""Exact signs and resonance identities for the conditional regular-J sector."""
from itertools import combinations, permutations
import json
from verify_m4_flag import add, mul, scale, power, variable, derivative


def subtract(p, q):
    return add(p, scale(q, -1))


def sum_poly(terms):
    out = {}
    for p in terms:
        out = add(out, p)
    return out


def mv(a, x):
    return [sum_poly(mul(c, d) for c, d in zip(row, x)) for row in a]


def det(a):
    out = {}
    for perm in permutations(range(len(a))):
        sign = (-1) ** sum(perm[i] > perm[j] for i in range(len(a)) for j in range(i+1, len(a)))
        term = {(0,) * 6: sign}
        for i, j in enumerate(perm):
            term = mul(term, a[i][j])
        out = add(out, term)
    return out


def main():
    w, u, v, h, lam, g = [variable(6, i) for i in range(6)]
    from fractions import Fraction
    H = subtract(scale(mul(w, u), 2), power(v, 2))
    G = sum_poly([mul(subtract(scale(h, 2), lam), mul(w, u)),
                  scale(mul(subtract(lam, h), power(v, 2)), Fraction(1, 2)),
                  mul(g, power(w, 2))])
    R = [G, mul(h, power(w, 2)), scale(mul(h, mul(w, v)), -1)]
    D = [{}, v, w]
    assert not sum_poly(mul(x, y) for x, y in zip(R, D))
    curl = [subtract(derivative(R[2], 1), derivative(R[1], 2)),
            subtract(derivative(R[0], 2), derivative(R[2], 0)),
            subtract(derivative(R[1], 0), derivative(R[0], 1))]
    assert curl == [mul(lam, x) for x in D]
    Q = [[{}, R[2], scale(R[1], -1)],
         [scale(R[2], -1), {}, R[0]],
         [R[1], scale(R[0], -1), {}]]
    grad = lambda f: [derivative(f, i) for i in range(3)]
    assert mv(Q, grad(w)) == [mul(mul(h, w), x) for x in D]
    th = subtract(mul(subtract(lam, h), H), scale(mul(g, power(w, 2)), 2))
    assert mv(Q, grad(H)) == [mul(th, x) for x in D]

    basis = [power(w, 4), mul(power(w, 2), H), power(H, 2)]
    T = [[scale(h, 4), scale(g, -2), {}],
         [{}, add(h, lam), scale(g, -4)],
         [{}, {}, scale(subtract(lam, h), 2)]]
    for j, f in enumerate(basis):
        image = sum_poly(mul(T[i][j], basis[i]) for i in range(3))
        assert mv(Q, grad(f)) == [mul(image, x) for x in D]

    pairs = list(combinations(range(3), 2))
    wedge = [[{} for _ in pairs] for _ in pairs]
    for j, (a, b) in enumerate(pairs):
        for k in range(3):
            for left, right, value in [(k, b, T[k][a]), (a, k, T[k][b])]:
                if left == right:
                    continue
                pair = tuple(sorted((left, right)))
                sign = 1 if left < right else -1
                i = pairs.index(pair)
                wedge[i][j] = add(wedge[i][j], scale(value, sign))
    shifted = [[subtract(wedge[i][j], lam) if i == j else wedge[i][j]
                for j in range(3)] for i in range(3)]
    target = scale(mul(h, mul(add(scale(h, 2), lam), subtract(scale(lam, 2), h))), 5)
    assert det(shifted) == target

    den = subtract(scale(h, 3), lam)
    Htilde = add(mul(den, H), scale(mul(g, power(w, 2)), 2))
    eigen = mul(subtract(lam, h), Htilde)
    assert mv(Q, grad(Htilde)) == [mul(eigen, x) for x in D]
    print(json.dumps({'all_passed': True,
                      'divergence_convention': 'delta(P)_j=sum_i partial_i(P_ij)',
                      'curl_R': '+lambda*D',
                      'Q_matrix_grad_w': 'h*w*D',
                      'Q_matrix_grad_H': '((lambda-h)*H-2*g*w^2)*D',
                      'quartic_operator_weights': ['4*h', 'h+lambda', '2*lambda-2*h'],
                      'exterior_square_determinant': '5*h*(2*h+lambda)*(2*lambda-h)',
                      'eigenform_denominator_cleared_identity': True,
                      'scope': 'Conditional constant regular nilpotent J sector; not all m4.'}, indent=2))


if __name__ == '__main__':
    main()

射影4空間の Poisson 構造 — 研究継続ノート 第23版
2026年10月29日

今回の結論
==========
第22版の非正規な二つの例外族 SS と NN は、それぞれ単一の23次元
射影軌道であり、同じ既知の24次元成分 T37 の滑らかな境界軌道である。
一般点間を結ぶ射影変換を具体的に与え、全150係数を
Q[k]/(3k^5+2) で検証した。T37 の開軌道の射影安定化群は
位数10の二面体群 D5。両境界点の全射影安定化群は Gm。
同じ成分には、実際の退化因子が五重超平面となる点も含まれる。
この点の射影接空間は50次元、軌道は16次元で、全Jacobiスキームの特異点。

既知の MPS 四辺鎖モデル（arXiv:2411.10425v1, Example5.6）との全括弧の
一致により T37 と同定する。T37 は本研究のカタログ番号。
今回、全体の成分数の下界57は増えない。全体の完全分類は未完了。

過去の到達点の訂正
==================
被約な階数2以下の部分は第14版で八成分に分類済み。
一般階数2の全Poisson成分は六つである。
第22版の「一般階数2の分類が残る」は広すぎる記述であり、
本版で訂正する。成分の網羅性について残るのは一般階数4側。
階数2の全軌道、境界の交差、局所冪零構造まで決定済みという意味ではない。

読む順番
========
1. p4_poisson_completeness_v23.pdf：日本語の全証明。
2. HANDOFF.txt：研究継続のための正確な到達点と未決定部分。
3. proofs/ss/：SS の全接空間、適合 pencil、非被約端点。
4. proofs/literature/：SS の幾何と MPS/T37 との完全同定。
5. proofs/nn/：NN の全係数、パラメータ消去、尖点因子、全安定化群、
   適合 pencil、SS 一般点への明示的共役。
6. proofs/check_generic_geometry.py：一般 SS 五次式と D5 の別検証。

再現
====
Python 3 と SymPy 1.14.0 が必要。
  python3 code/run_checks.py
  python3 code/verify_bundle.py

run_checks.py は一時コピー内で全生成コードを実行し、配布ファイルを
変更しない。五群1171項目の厳密確認に成功。
全375×150接空間行列の再構成、25本（端点は51本）の独立な核、
非零小行列式の整数Bareiss消去、24本の全軌道方向を含む。
有限体の標本や浮動小数点近似による判定は用いない。
同じ主張を複数実装で照合した確認も総数に含む。

個々の監査だけなら：
  python3 proofs/nn/verify_nn_certificates.py --tangent --output /tmp/nn_audit.json
  python3 code/audit_tangent_stdlib.py proofs/ss/full_tangent.json \
      --output /tmp/ss_tangent_audit.json

LaTeX ソースは p4_poisson_completeness_v23.tex、preamble.tex、sections/。
日本語 LuaLaTeX（luatexja-preset、Harano Aji フォント）で二回以上コンパイル。
PDFに入力フォーム欄はない。

保存した過去の版
================
previous_v22/ に第22版の全1783ファイルをバイト単位で保存。
previous_v22.pdf は同じ第22版PDFの便宜的な複製。
その内部に第21版以前が再帰的に含まれる。
古い版の記述は変更せず、訂正と新しい結論は本版に記す。

主な一次文献
============
M. Matviichuk, B. Pym, T. Schedler:
A local Torelli theorem for log symplectic manifolds, arXiv:2010.08692v2.
https://arxiv.org/abs/2010.08692
Theorem1.4 は SNC locus と交わる40成分の分類。

同著者:
Creating quantum projective spaces by deforming q-symmetric algebras,
arXiv:2411.10425v1, Example5.6, Theorem7.5.
https://arxiv.org/html/2411.10425v1

R. Lima, J. V. Pereira:
A characterization of diagonal Poisson structures, Theorem3.3.
https://w3.impa.br/~jvp/diagonalpoisson.pdf

射程
====
新しい結果は明示された二族と、それらの実際の全Jacobi変形・同定に関する。
非正規な退化因子を持つ全構造、T37の全境界軌道、全局所環を分類した
という主張ではない。過去の正規退化因子の網羅性に依存せず、
今回の成分の結論は接空間・軌道・明示変形から独立に証明される。

"""Run every v23 exact audit in temporary copies, keeping the bundle immutable."""
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser(description=__doc__)
ap.add_argument("--output", type=Path)
args = ap.parse_args()
started = time.monotonic()
groups = []

with tempfile.TemporaryDirectory(prefix="p4_v23_verify_") as td:
    tmp = Path(td)
    shutil.copytree(ROOT / "proofs", tmp / "proofs")
    shutil.copytree(ROOT / "code", tmp / "code")
    (tmp / "data").mkdir()
    jobs = [
        ("full_tangent_stdlib",
         ["code/audit_tangent_stdlib.py",
          "proofs/ss/full_tangent.json",
          "proofs/ss/generic_full_tangent.json",
          "proofs/ss/endpoint_full_tangent.json",
          "proofs/nn/full_tangent_nn.json",
          "proofs/nn/full_tangent_generic_nn_linear.json",
          "--output", "data/full_tangent.json"],
         "data/full_tangent.json", "checks", 372),
        ("ss_pencil",
         ["proofs/ss/analyze_pencil.py"],
         "proofs/ss/pencil.json", "check_count", 23),
        ("ss_geometry_and_MPS",
         ["proofs/literature/verify_ss_geometry_mps.py"],
         "proofs/literature/ss_geometry_mps_certificate.json", "check_count", 48),
        ("NN_and_exact_conjugacy",
         ["proofs/nn/verify_nn_certificates.py", "--tangent"],
         "proofs/nn/nn_verification.json", "check_count", 662),
        ("generic_geometry",
         ["proofs/check_generic_geometry.py"],
         "data/generic_geometry_audit.json", "check_count", 66),
    ]
    for name, cmd, outfile, countkey, expected in jobs:
        stamp = time.monotonic()
        run = subprocess.run([sys.executable, *cmd], cwd=tmp, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if run.returncode:
            print(run.stdout, file=sys.stderr)
            print(run.stderr, file=sys.stderr)
            raise RuntimeError(f"{name} failed with code {run.returncode}")
        result = json.loads((tmp / outfile).read_text())
        assert result["all_passed"] is True, name
        assert result[countkey] == expected, (name, result[countkey], expected)
        item = {"group": name, "all_passed": True, "check_count": expected,
                "seconds": round(time.monotonic()-stamp, 3)}
        groups.append(item)
        print(json.dumps(item), flush=True)

summary = {"all_passed": True, "group_count": len(groups),
           "check_count": sum(g["check_count"] for g in groups),
           "groups": groups, "seconds": round(time.monotonic()-started, 3),
           "scope": "v23 new results. Prior v22 and older proofs are preserved, not re-proved by this run.",
           "arithmetic": "Exact rationals, integer Bareiss minors, and QQ[k]/(3*k**5+2). No floating point sampling.",
           "mutations": "All generators run in temporary copies; archived files remain unchanged."}
if args.output:
    args.output.write_text(json.dumps(summary, indent=2)+"\n")
print(json.dumps(summary, indent=2))

"""Verify all recorded files and byte-for-byte preservation of edition v22."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=ROOT/"SHA256SUMS.txt"
checked=0
for line in manifest.read_text().splitlines():
    digest,name=line.split("  ",1)
    path=ROOT/name
    assert path.is_file(),name
    assert sha(path)==digest,name
    checked+=1
old=json.loads((ROOT/"data/previous_v22_preservation.json").read_text())
for name,digest in old["sha256"].items():
    assert sha(ROOT/"previous_v22"/name)==digest, name
actual={str(p.relative_to(ROOT/"previous_v22")) for p in (ROOT/"previous_v22").rglob("*") if p.is_file()}
assert actual==set(old["sha256"]), "v22 file inventory changed"
assert sha(ROOT/"previous_v22.pdf")==sha(ROOT/"previous_v22/p4_poisson_completeness_v22.pdf")
print(json.dumps({"all_passed":True,"manifest_entries":checked,
                  "previous_v22_files_preserved":len(actual),
                  "previous_v22_pdf_preserved":True},indent=2))

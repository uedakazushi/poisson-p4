"""Independent exact rank/tangent audit. Python stdlib only; no sampling/CAS.

Reconstructs the full linearized equations from the reported concrete P; verifies
rational kernel and a nonzero square minor by integer Bareiss elimination.
It also reconstructs all24 infinitesimal PGL actions and verifies orbit ranks.
"""
import argparse,ast,json,math
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations,combinations_with_replacement
Z=(0,)*5

def clean(p):return {m:c for m,c in p.items() if c}
def add(p,q):
 r=dict(p)
 for m,c in q.items():r[m]=r.get(m,F(0))+c
 return clean(r)
def scale(p,c):return clean({m:v*c for m,v in p.items()})
def mul(p,q):
 r={}
 for m,c in p.items():
  for n,d in q.items():
   v=tuple(a+b for a,b in zip(m,n));r[v]=r.get(v,F(0))+c*d
 return clean(r)
def deriv(p,j):
 r={}
 for m,c in p.items():
  if m[j]:v=list(m);v[j]-=1;r[tuple(v)]=c*m[j]
 return r
XS=[]
for i in range(5):m=list(Z);m[i]=1;XS.append({tuple(m):F(1)})
def parse(text):
 def go(n):
  if isinstance(n,ast.Constant) and type(n.value)==int:return {Z:F(n.value)} if n.value else {}
  if isinstance(n,ast.Name) and n.id in [f'x{i}' for i in range(5)]:return XS[int(n.id[1:])]
  if isinstance(n,ast.UnaryOp):return scale(go(n.operand),-1 if isinstance(n.op,ast.USub) else 1)
  if isinstance(n,ast.BinOp):
   p,q=go(n.left),go(n.right)
   if isinstance(n.op,ast.Add):return add(p,q)
   if isinstance(n.op,ast.Sub):return add(p,scale(q,-1))
   if isinstance(n.op,ast.Mult):return mul(p,q)
   if isinstance(n.op,ast.Div):
    assert set(q)<={Z} and q.get(Z,0);return scale(p,1/q[Z])
   if isinstance(n.op,ast.Pow):
    assert set(q)<={Z};v=q.get(Z,F(0));assert v.denominator==1 and v>=0
    r={Z:F(1)}
    for _ in range(v.numerator):r=mul(r,p)
    return r
  raise ValueError(ast.dump(n))
 return go(ast.parse(text,mode='eval').body)
def matrix(entries):
 P=[[{} for j in range(5)] for i in range(5)]
 for ij,e in entries.items():
  i,j=map(int,ij);P[i][j]=parse(e);P[j][i]=scale(P[i][j],-1)
 return P
def lie(P,Q):
 r={}
 for i,j,k in combinations(range(5),3):
  z={}
  for a,b,c in [(i,j,k),(j,k,i),(k,i,j)]:
   for l in range(5):z=add(z,add(mul(P[a][l],deriv(Q[b][c],l)),mul(Q[a][l],deriv(P[b][c],l))))
  r[i,j,k]=z
 return r
def basis_monomials(d):
 out=[]
 for v in combinations_with_replacement(range(5),d):
  a=[0]*5
  for i in v:a[i]+=1
  out.append(tuple(a))
 return out
def bareiss(A):
 A=[row[:] for row in A];n=len(A);previous=1;sign=1
 for k in range(n-1):
  found=next((i for i in range(k,n) if A[i][k]),None)
  if found is None:return 0
  if found!=k:A[k],A[found]=A[found],A[k];sign=-sign
  pivot=A[k][k]
  for i in range(k+1,n):
   aik=A[i][k]
   for j in range(k+1,n):
    numerator=pivot*A[i][j]-aik*A[k][j]
    assert numerator%previous==0
    A[i][j]=numerator//previous
   A[i][k]=0
  previous=pivot
 return sign*A[-1][-1] if n else 1
def det(A):
 integer=[];den=1
 for row in A:
  l=math.lcm(*(c.denominator for c in row));den*=l;integer.append([int(c*l) for c in row])
 return F(bareiss(integer),den)
def rank(A):
 A=[row[:] for row in A];r=0
 for c in range(len(A[0])):
  p=next((i for i in range(r,len(A)) if A[i][c]),None)
  if p is None:continue
  A[r],A[p]=A[p],A[r];a=A[r][c];A[r]=[v/a for v in A[r]]
  for i in range(r+1,len(A)):
   if A[i][c]:
    a=A[i][c];A[i]=[v-a*w for v,w in zip(A[i],A[r])]
  r+=1
  if r==len(A):break
 return r

def audit(path):
 d=json.loads(path.read_text());checks=[]
 def ck(ok,label):
  assert ok,label;checks.append(label)
 P=matrix(d['P_entries']);pairs=list(combinations(range(5),2));triple=list(combinations(range(5),3));m2=basis_monomials(2);m3=basis_monomials(3);basis=[(ij,m) for ij in pairs for m in m2]
 ck(d['basis']==[{'pair':list(ij),'monomial_exponents':list(m)} for ij,m in basis],'all150coordinates')
 ck(all(not v for v in lie(P,P).values()),'point_is_Poisson')
 ck(all(not sum_polys(deriv(P[i][j],i) for i in range(5)) for j in range(5)),'point_is_canonical')
 M=[[F(0) for j in range(150)] for i in range(375)]
 for col,((i,j),mon) in enumerate(basis):
  Q=[[{} for b in range(5)] for a in range(5)];Q[i][j]={mon:F(1)};Q[j][i]={mon:F(-1)}
  for b in range(5):
   div=sum_polys(deriv(Q[a][b],a) for a in range(5))
   for a in range(5):M[5*b+a][col]=div.get(next(iter(XS[a])),F(0))
  J=lie(P,Q)
  for ii,ijk in enumerate(triple):
   for im,mm in enumerate(m3):M[25+35*ii+im][col]=J[ijk].get(mm,F(0))
 supplied={(int(k.split(',')[0]),int(k.split(',')[1])):F(v) for k,v in d['matrix_entries'].items()}
 ck(supplied=={(i,j):v for i,row in enumerate(M) for j,v in enumerate(row) if v},'all375x150equations_reconstructed')
 K=[[F(v) for v in col] for col in d['kernel_vectors']];free=d['kernel_free_columns']
 ck(len(K)+d['linear_rank']==150,'kernel_rank_count')
 for k,col in enumerate(K):
  ck(all(sum(c*v for c,v in zip(row,col))==0 for row in M),f'kernel_vector{k}')
 ck([[col[j] for j in free] for col in K]==[[F(int(i==j)) for j in range(len(K))] for i in range(len(K))],'kernel_independent_identity_block')
 w=d['rank_witness'];minor=[[M[i][j] for j in w['columns']] for i in w['rows']]
 computed=det(minor);ck(computed!=0 and computed==F(w['determinant']),'exact_rational_rank_minor')
 # Independent linear pushforward reconstruction.
 As=[]
 for i in range(5):
  for j in range(5):
   if i!=j:
    A=[[0]*5 for k in range(5)];A[i][j]=1;As.append(A)
 for i in range(4):
  A=[[0]*5 for k in range(5)];A[i][i]=1;A[4][4]=-1;As.append(A)
 orbit=[]
 for h,A in enumerate(As):
  v=[sum_polys(scale(XS[j],A[i][j]) for j in range(5)) for i in range(5)]
  Q=[[{} for j in range(5)] for i in range(5)]
  for i,j in pairs:
   Q[i][j]=sum_polys([*(scale(P[k][j],A[i][k]) for k in range(5)),*(scale(P[i][k],A[j][k]) for k in range(5)),*(scale(mul(v[k],deriv(P[i][j],k)),-1) for k in range(5))])
  vv=[Q[i][j].get(mon,F(0)) for (i,j),mon in basis];orbit.append(vv)
  ck(vv==[F(c) for c in d['orbit_vectors'][h]],f'orbit_vector{h}')
 O=[list(row) for row in zip(*orbit)];Pv=[P[i][j].get(mon,F(0)) for (i,j),mon in basis];OS=[row+[p] for row,p in zip(O,Pv)]
 ck(rank(O)==d['orbit_rank'],'orbit_rank_exact')
 ck(rank(OS)==d['orbit_plus_scale_rank'],'orbit_plus_scale_rank_exact')
 ck(d['projective_tangent_dimension']==150-d['linear_rank']-1,'projective_tangent_dimension')
 ck(d['projective_orbit_dimension']==d['orbit_plus_scale_rank']-1,'projective_orbit_dimension')
 ck(d['infinitesimal_projective_stabilizer_dimension']==25-d['orbit_plus_scale_rank'],'projective_stabilizer_dimension')
 # Explicit transverse representatives span the quotient.
 Ts=[]
 for e in d['transverse_P_entries']:
  Q=matrix(e);v=[Q[i][j].get(mon,F(0)) for (i,j),mon in basis];Ts.append(v)
  ck(all(sum(a*b for a,b in zip(row,v))==0 for row in M),f'transverse_vector{len(Ts)-1}_is_tangent')
 extended=[row+[col[i] for col in Ts] for i,row in enumerate(OS)]
 ck(rank(extended)==len(K) and len(Ts)==len(K)-d['orbit_plus_scale_rank'],'complete_transverse_complement')
 return {'report':path.name,'all_passed':True,'checks':len(checks),'check_labels':checks,'linear_rank':d['linear_rank'],'projective_tangent_dimension':d['projective_tangent_dimension'],'projective_orbit_dimension':d['projective_orbit_dimension'],'method':'Independent stdlib Fraction sparse polynomial construction, exact rational kernel, integer Bareiss minor determinant, exact orbit Gaussian rank. No CAS/no numerical sampling.'}
def sum_polys(it):
 r={}
 for p in it:r=add(r,p)
 return r
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('reports',nargs='+',type=Path);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args();out=[]
 for path in args.reports:
  r=audit(path);out.append(r);print(json.dumps({k:v for k,v in r.items() if k!='check_labels'}),flush=True)
 result={'all_passed':True,'reports':out,'checks':sum(r['checks'] for r in out)};args.output.write_text(json.dumps(result,indent=2)+'\n')

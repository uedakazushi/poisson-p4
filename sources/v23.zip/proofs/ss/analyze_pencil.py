from pathlib import Path
from itertools import combinations
import json
import sympy as s
R=Path(__file__).resolve().parent
x=s.symbols('x0:5');t=s.Symbol('t');u=s.Symbol('u',nonzero=True);a=s.Symbol('a',nonzero=True);c=s.Symbol('c',nonzero=True)
d=json.loads((R/'full_tangent.json').read_text());pairs=list(combinations(range(5),2))
def load(entries,extra=None):
 P=s.zeros(5)
 for k,v in entries.items():
  i,j=map(int,k);P[i,j]=s.sympify(v,locals={str(v):v for v in x+(t,u,a,c)});P[j,i]=-P[i,j]
 return P
P=load(d['P_entries']);Q=load(d['transverse_P_entries'][0]);B=P+t*Q
checks={}
checks['Q_nonzero']=Q!=s.zeros(5)
for j in range(5):checks[f'divergence_{j}']=s.expand(sum(s.diff(B[i,j],x[i]) for i in range(5)))==0
for i,j,k in combinations(range(5),3):
 J=s.expand(sum(B[i,l]*s.diff(B[j,k],x[l])+B[j,l]*s.diff(B[k,i],x[l])+B[k,l]*s.diff(B[i,j],x[l]) for l in range(5)))
 checks[f'full_pencil_Jacobi_{i}{j}{k}']=J==0
pf=[]
for o in range(5):
 i,j,k,l=[v for v in range(5) if v!=o];pf.append(s.expand((-1)**o*(B[i,j]*B[k,l]-B[i,k]*B[j,l]+B[i,l]*B[j,k])))
F=s.expand(sum(x[i]*pf[i] for i in range(5))/5)
for i in range(5):checks[f'gradient_pfaffian_{i}']=s.expand(s.diff(F,x[i])-pf[i])==0
G=s.diag(u**-2,u**-1,1,u,u*u);xx=G.inv()*s.Matrix(x)
push=G*B.subs(dict(zip(x,xx)),simultaneous=True)*G.T
checks['exact_torus_action']=all(s.expand(v)==0 for v in push-(P+u**5*t*Q))
source=json.loads((R/'ss_source.json').read_text());Pa=load(source['P']);Ga=s.diag(1,1,1,1,c)
checks['a_parameter_removed']=all(s.simplify(v)==0 for v in Ga*Pa.subs(dict(zip(x,Ga.inv()*s.Matrix(x))),simultaneous=True)*Ga.T-Pa.subs(a,c*a))
assert all(checks.values())
out={'all_passed':True,'checks':checks,'check_count':len(checks),'P_entries':d['P_entries'],'Q_entries':d['transverse_P_entries'][0],
'pencil_entries':{f'{i}{j}':str(s.expand(B[i,j])) for i,j in pairs},'F':str(F),'F_by_t_degree':{str(k):str(s.factor(s.expand(F).coeff(t,k))) for k in range(3)},'F_at_1_factorization':str(s.factor(F.subs(t,1))),
'normalization':'diag(1,1,1,1,c)_*P(a)=P(ca)',
'exact_torus':'diag(u^-2,u^-1,1,u,u^2)_*(P+tQ)=P+u^5*tQ'}
(R/'pencil.json').write_text(json.dumps(out,indent=2)+'\n')
(R/'generic_point.json').write_text(json.dumps({'P_entries':{f'{i}{j}':str(s.expand(B[i,j].subs(t,1))) for i,j in pairs}},indent=2)+'\n')
print(json.dumps({'checks':len(checks),'all_passed':True,'F_by_t_degree':out['F_by_t_degree'],'F_at_1_factorization':out['F_at_1_factorization']},indent=2),flush=True)

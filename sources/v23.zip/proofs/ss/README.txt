SS full-deformation certificate package (v23)
============================================

Main conclusion
---------------
Let P be the canonical SS bivector at a=1 from ss_source.json.  Its unique
infinitesimal deformation modulo projective coordinate changes and scale is

    Q14=x0^2, Q23=-2*x0^2/9, Q24=4*x0*x1/3,
    Q34=2*x0*x2/3+x1^2; all other Qij=0.

P+tQ is exactly Poisson for every t.  Every t!=0 lies on the same projective
PGL5 orbit.  That orbit has dimension 24, equal to the tangent dimension of
the FULL projectivized Jacobi scheme.  Its closure is therefore a genuine
24-dimensional irreducible component with an open orbit.  The t=0 SS orbit
has dimension 23 and consists of smooth points of this component and of the
full Jacobi scheme.  These claims use an actual 24-dimensional orbit and
the explicit pencil; they are not inferred from tangent dimensions alone.

The SS parameter a!=0 is removable by diag(1,1,1,1,c), sending a to ca.
The full SS projective stabilizer is Gm, diag(1,r,r^2,r^3,r^4).  The proof
of absence of disconnected stabilizer components uses the independently
verified reduced zero support T0123+L03+L04+L34, explained in the TeX note.

The projective pencil endpoint [Q] has actual divisor 5{x0=0}.  Its full
projective tangent has dimension 50; its projective orbit has dimension 16
and its infinitesimal projective stabilizer has dimension 8.  It is singular
in the full Jacobi scheme because it lies on the proven 24-dimensional
component.  No claim of multiple components through this point is made.

The NN team independently identifies its generic deformation with P+Q by
an explicit PGL5 transformation over Q[k]/(k^5+2/3).  Its files also compute
the generic projective stabilizer D5 of order 10.  Those conjugacy and finite
stabilizer certificates are in the sibling nn_orbits directory, not here.
Do not count the SS and NN generic orbits as different components.  Do not
increment any global component bound without comparing known literature.

Files
-----
ss_component_proof.tex       Mathematical proof in Japanese.
ss_source.json              Read-only copy of the v22 symbolic SS family.
compute_full_tangent.py      Exact rational full-tangent generator (SymPy).
analyze_pencil.py            Exact pencil, torus and parameter normalization.
audit_tangent_stdlib.py      Independent verifier using only Python stdlib.
full_tangent.json            P: full matrix, kernel, minors, orbit, quotient.
generic_point.json           P+Q input.
generic_full_tangent.json    P+Q: corresponding full certificate.
nonreduced_endpoint.json     Q input.
endpoint_full_tangent.json   Q: corresponding full certificate.
pencil.json                 23 exact algebraic checks and quintic formulas.
tangent_audit_stdlib.json    247/247 independent exact checks on all 3 points.

Every tangent certificate contains all 150 coefficient coordinates, all
375 linear equations (25 divergence and 350 Jacobi), an explicit rational
kernel, a nonzero maximal rank minor with its exact determinant, and all
24 sl5 orbit vectors.  The auditor rebuilds the equations directly from P,
checks each kernel vector and an identity free-coordinate block, evaluates
the rank minor by integer Bareiss elimination, reconstructs all orbit
vectors, and checks the full transverse complement.  It does not trust the
generator's matrix entries or reported ranks, use numerical samples, or
rely on SymPy for the independent audit.

Dimension table
---------------
point       matrix rank   affine tangent   projective tangent   proj orbit
P                 125               25                   24           23
P+Q               125               25                   24           24
Q                  99               51                   50           16

For Q, the tensor orbit has dimension 17 and includes scale.  For P and P+Q
scale is independent of the tensor orbit.  This difference is explicitly
included in all projective dimension calculations.

Reproduction (run in this directory)
-----------------------------------
Python 3 is sufficient for the independent audit:

  python3 audit_tangent_stdlib.py full_tangent.json \
    generic_full_tangent.json endpoint_full_tangent.json \
    --output tangent_audit_stdlib.json

The generators require SymPy.  In the current workspace use
PYTHONPATH=/tmp/p4_v6_math before python3; a normal SymPy installation works
without that setting.

  python3 compute_full_tangent.py --source ss_source.json \
    --parameter a=1 --output full_tangent.json
  python3 analyze_pencil.py
  python3 compute_full_tangent.py --source generic_point.json \
    --output generic_full_tangent.json
  python3 compute_full_tangent.py --source nonreduced_endpoint.json \
    --output endpoint_full_tangent.json

The tangent generator accepts arbitrary rational quadratic bivectors in
the same format, using either P or P_entries as the object key; specify
each symbolic parameter by a separate --parameter name=value argument.
The absolute source paths stored in existing reports are provenance only;
the independent auditor is portable and does not open those paths.

Remaining limits
----------------
The factorization string for F(P+Q) in pencil.json is a factorization over
QQ, not an absolute irreducibility certificate.  No geometric conclusion
depends on absolute irreducibility.  The complete P4 classification and
the number of other components through [Q] remain unresolved by this work.

"""Full 150-coefficient canonical-lift tangent at the SS nonnormal example.
All arithmetic is rational. No fixed curve-support condition is imposed.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
from fractions import Fraction as F
import argparse,json,time
import sympy as s
from sympy.polys.matrices import DomainMatrix
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--source',type=Path,default=ROOT/'ss_source.json')
ap.add_argument('--parameter',action='append',default=[])
ap.add_argument('--output',type=Path,default=ROOT/'full_tangent.json')
args=ap.parse_args();SRC=args.source
parameter_substitution={s.Symbol(k):s.sympify(v) for k,v in (item.split('=',1) for item in args.parameter)} if args.parameter else {s.Symbol('a'):s.Integer(1)}
x=s.symbols('x0:5');pairs=list(combinations(range(5),2));triples=list(combinations(range(5),3))
def mons(d):
 out=[]
 for ix in combinations_with_replacement(range(5),d):
  m=[0]*5
  for i in ix:m[i]+=1
  out.append(tuple(m))
 return out
m2=mons(2);m3=mons(3);basis=[(ij,m) for ij in pairs for m in m2]
def poly(e):return {m:F(int(c.p),int(c.q)) for m,c in s.Poly(s.expand(e),*x).terms() if c}
def plus(*polys):
 out={}
 for p in polys:
  for m,c in p.items():out[m]=out.get(m,F(0))+c
 return {m:c for m,c in out.items() if c}
def neg(p):return {m:-c for m,c in p.items()}
def scale(p,c):return {m:c*v for m,v in p.items() if c*v}
def mul(p,q):
 out={}
 for m,c in p.items():
  for n,d in q.items():
   k=tuple(a+b for a,b in zip(m,n));out[k]=out.get(k,F(0))+c*d
 return {m:c for m,c in out.items() if c}
def deriv(p,k):
 out={}
 for m,c in p.items():
  if m[k]:
   n=list(m);n[k]-=1;out[tuple(n)]=c*m[k]
 return out
def bracket(P,Q):
 out={}
 for i,j,k in triples:
  out[i,j,k]=plus(*(plus(mul(P[i,l],deriv(Q[j,k],l)),mul(Q[i,l],deriv(P[j,k],l)),mul(P[j,l],deriv(Q[k,i],l)),mul(Q[j,l],deriv(P[k,i],l)),mul(P[k,l],deriv(Q[i,j],l)),mul(Q[k,l],deriv(P[i,j],l))) for l in range(5)))
 return out
def matrix(P):
 return s.Matrix([[s.Rational(P.get((i,j),{}).get(m,0).numerator,P.get((i,j),{}).get(m,F(0)).denominator) for (i,j),m in basis]]).T
def toP(vec):
 P={(i,j):{} for i in range(5) for j in range(5)}
 for ((i,j),m),c in zip(basis,vec):
  if c:P[i,j][m]=F(int(c.p),int(c.q));P[j,i][m]=-P[i,j][m]
 return P
def rep(P):
 return {str(i)+str(j):str(s.expand(sum(s.Rational(c.numerator,c.denominator)*s.prod(x[k]**m[k] for k in range(5)) for m,c in P[i,j].items()))) for i,j in pairs}
def dumpvec(v):return [str(c) for c in v]
def rref(M):
 dm=DomainMatrix.from_Matrix(M).convert_to(s.QQ);rr,piv=dm.rref();return rr.to_Matrix(),piv
start=time.monotonic();d=json.loads(SRC.read_text());P={(i,j):{} for i in range(5) for j in range(5)}
for key,e in d.get('P',d.get('P_entries')).items():
 i,j=map(int,key);P[i,j]=poly(s.sympify(e).subs(parameter_substitution,simultaneous=True));P[j,i]=neg(P[i,j])
Pv=matrix(P);assert all(not p for p in bracket(P,P).values())
rows=[('div',j,(i,)) for j in range(5) for i in range(5)]+[('jac',ijk,m) for ijk in triples for m in m3]
entries={}
for col,((i,j),m) in enumerate(basis):
 Q={(a,b):{} for a in range(5) for b in range(5)};Q[i,j]={m:F(1)};Q[j,i]={m:F(-1)}
 for jj in range(5):
  dd=plus(*(deriv(Q[ii,jj],ii) for ii in range(5)))
  for ii in range(5):
   mm=tuple(int(k==ii) for k in range(5));c=dd.get(mm,F(0))
   if c:entries[jj*5+ii,col]=s.Rational(c.numerator,c.denominator)
 J=bracket(P,Q)
 for it,ijk in enumerate(triples):
  for im,mm in enumerate(m3):
   c=J[ijk].get(mm,F(0))
   if c:entries[25+it*35+im,col]=s.Rational(c.numerator,c.denominator)
M=s.MutableSparseMatrix(375,150,entries)
print('matrix',M.shape,'nonzero',len(entries),'seconds',time.monotonic()-start,flush=True)
rr,piv=rref(M);free=[j for j in range(150) if j not in piv]
N=s.zeros(150,len(free))
for k,j in enumerate(free):
 N[j,k]=1
 for i,c in enumerate(piv):N[c,k]=-rr[i,j]
assert M*N==s.zeros(375,len(free))
print('full tangent rank',len(piv),'kernel',len(free),'seconds',time.monotonic()-start,flush=True)
# Orbit pushforward derivative A P + P A^t - (Ax).grad P.
As=[];alabel=[]
for i in range(5):
 for j in range(5):
  if i!=j:
   A=s.zeros(5);A[i,j]=1;As.append(A);alabel.append(f'E{i}{j}')
for i in range(4):
 A=s.zeros(5);A[i,i]=1;A[4,4]=-1;As.append(A);alabel.append(f'H{i}')
Ps=s.Matrix(5,5,lambda i,j:sum(s.Rational(c.numerator,c.denominator)*s.prod(x[k]**m[k] for k in range(5)) for m,c in P[i,j].items()))
Ocols=[]
for A in As:
 v=A*s.Matrix(x);Q=A*Ps+Ps*A.T-s.Matrix(5,5,lambda i,j:sum(v[k]*s.diff(Ps[i,j],x[k]) for k in range(5)))
 Ocols.append(matrix({(i,j):poly(Q[i,j]) for i in range(5) for j in range(5)}))
O=s.Matrix.hstack(*Ocols);assert M*O==s.zeros(375,24)
orref,opiv=rref(O);OR=len(opiv)
OS=s.Matrix.hstack(O,Pv);osrr,ospiv=rref(OS)
combined=s.Matrix.hstack(OS,N);crr,cpiv=rref(combined)
trans_indices=[p-25 for p in cpiv if p>=25]
T=N[:,trans_indices];print('orbit rank',OR,'orbit+scale rank',len(ospiv),'transverse',len(trans_indices),flush=True)
# Stabilizers: exact tensor and line.
def kernel(R,piv):
 f=[j for j in range(R.cols) if j not in piv];K=s.zeros(R.cols,len(f))
 for k,j in enumerate(f):
  K[j,k]=1
  for i,c in enumerate(piv):K[c,k]=-R[i,j]
 return K
stab=kernel(orref,opiv);lstab=kernel(osrr,ospiv)
stabA=[]
for k in range(stab.cols):stabA.append(sum((stab[i,k]*As[i] for i in range(24)),s.zeros(5)))
lstabA=[]
for k in range(lstab.cols):lstabA.append({'matrix':[[str(v) for v in row] for row in sum((lstab[i,k]*As[i] for i in range(24)),s.zeros(5)).tolist()],'P_scale_in_relation':str(lstab[24,k])})
# A square rational rank witness, exact determinant.
_,rowpiv=rref(M.T);minor=M[list(rowpiv),list(piv)];det=DomainMatrix.from_Matrix(minor).convert_to(s.QQ).det();detstr=str(s.QQ.to_sympy(det))
print('rank witness determinant chars',len(detstr),flush=True)
report={'source':str(SRC),'point_parameters':{str(k):str(v) for k,v in parameter_substitution.items()},'full_space':'divergence-zero homogeneous quadratic bivectors, full P4 Poisson scheme',
 'basis':[{'pair':list(ij),'monomial_exponents':list(m)} for ij,m in basis],
 'rows':[list(v) for v in rows],'linear_map_shape':list(M.shape),'matrix_entries':{f'{i},{j}':str(v) for (i,j),v in entries.items()},
 'linear_rank':len(piv),'affine_tangent_dimension':len(free),'projective_tangent_dimension':len(free)-1,
 'kernel_free_columns':free,'kernel_vectors':[dumpvec(N[:,i]) for i in range(N.cols)],
 'rank_witness':{'rows':list(rowpiv),'columns':list(piv),'determinant':detstr},
 'orbit_basis_labels':alabel,'orbit_vectors':[dumpvec(O[:,i]) for i in range(24)],'orbit_rank':OR,'orbit_plus_scale_rank':len(ospiv),
 'projective_orbit_dimension':len(ospiv)-1,'infinitesimal_tensor_stabilizer_dimension':stab.cols,'infinitesimal_projective_stabilizer_dimension':lstab.cols,
 'tensor_stabilizer_matrices':[[[str(v) for v in row] for row in A.tolist()] for A in stabA],
 'projective_stabilizer_matrices':lstabA,
 'transverse_dimension':len(trans_indices),'transverse_kernel_indices':trans_indices,'transverse_P_entries':[rep(toP(T[:,i])) for i in range(T.cols)],
 'P_entries':rep(P),'seconds':round(time.monotonic()-start,3)}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['affine_tangent_dimension','projective_tangent_dimension','orbit_rank','projective_orbit_dimension','infinitesimal_projective_stabilizer_dimension','transverse_dimension','seconds']}),flush=True)

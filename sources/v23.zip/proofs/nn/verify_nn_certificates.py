"""Portable exact auditor for the v23 NN family and its T37 identification.

Run: python3 verify_nn_certificates.py [--tangent] [--output REPORT.json]
Requires SymPy. Inputs are local JSON; no network or previous-edition paths.
All conjugacy coefficients are reduced in QQ[k]/(3*k**5+2).
The --tangent option verifies the stored exact rank witnesses and kernels;
full tangent-matrix reconstruction is independently provided in the main v23 audit.
"""
from pathlib import Path
from itertools import combinations, combinations_with_replacement
import argparse, json, hashlib, time
import sympy as s
from sympy.polys.matrices import DomainMatrix

ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--certificate',type=Path,default=ROOT/'nn_final_certificate.json')
ap.add_argument('--tangent',action='store_true')
ap.add_argument('--output',type=Path,default=ROOT/'nn_verification.json')
args=ap.parse_args(); data=json.loads(args.certificate.read_text())
x=s.symbols('x0:5');a,b,c,e,k,t,u,z,lam=s.symbols('a b c e k t u z lam')
pairs=list(combinations(range(5),2));triples=list(combinations(range(5),3))
checks={};details={};start=time.monotonic()
def check(name,condition):
    ok=bool(condition);checks[name]=ok
    if not ok:raise AssertionError(name)
def zero(name,expression):check(name,s.expand(expression)==0)
def matrix(entries):
    P=s.zeros(5)
    for ij,v in entries.items():
        i,j=map(int,ij);P[i,j]=s.sympify(v);P[j,i]=-P[i,j]
    return P

def jacobi(P):
    return [s.expand(sum(P[i,l]*s.diff(P[j,k],x[l])+P[j,l]*s.diff(P[k,i],x[l])+P[k,l]*s.diff(P[i,j],x[l]) for l in range(5))) for i,j,k in triples]
def canonical_F(P):
    F=0
    for h in range(5):
        i,j,l,m=[v for v in range(5) if v!=h]
        F+=x[h]*(-1)**h*(P[i,j]*P[l,m]-P[i,l]*P[j,m]+P[i,m]*P[j,l])/5
    return s.expand(F)
def substitute(P,y):return P.subs(dict(zip(x,y)),simultaneous=True)
def matrix_zero(prefix,P):
    for i,j in pairs:zero(f'{prefix}_{i}{j}',P[i,j])
def zero_scheme(P):return {f'{i}{j}{k}':s.expand(x[i]*P[j,k]-x[j]*P[i,k]+x[k]*P[i,j]) for i,j,k in triples}
def coeff_remainders(prefix,P,var,modulus):
    count=0
    monomials=[]
    for ix in combinations_with_replacement(range(5),2):
        monomials.append(s.prod(x[j] for j in ix))
    for i,j in pairs:
        poly=s.Poly(s.expand(P[i,j]),*x)
        for n,m in enumerate(monomials):
            cc=poly.coeff_monomial(m)
            rem=s.rem(s.Poly(cc,var,domain=s.QQ),s.Poly(modulus,var,domain=s.QQ)).as_expr()
            zero(f'{prefix}_{i}{j}_m{n}',rem);count+=1
    return count

P=matrix(data['NN_family_entries']);P0=matrix(data['P0_entries']);Q=matrix(data['linear_pencil']['Q_entries']);T=matrix(data['conjugacy']['target_entries'])
check('P0_specialization',P.subs({a:0,b:0})==P0)
for name,Pcheck in [('NN_family',P),('P0',P0),('Q',Q),('NN_pencil',P0+t*Q),('SS_generic',T)]:
    for h,jj in enumerate(jacobi(Pcheck)):zero(f'{name}_Jacobi_{triples[h]}',jj)
    for j in range(5):zero(f'{name}_divergence_{j}',sum(s.diff(Pcheck[i,j],x[i]) for i in range(5)))
zero('NN_F_canonical',canonical_F(P)-s.sympify(data['NN_F']))
zero('linear_pencil_F_canonical',canonical_F(P0+t*Q)-s.sympify(data['linear_pencil']['F']))

# Entire parameter family is one actual tensor orbit, without a scale factor.
g=s.Matrix(data['parameter_action']['matrix']);newa=s.sympify(data['parameter_action']['new_a']);newb=s.sympify(data['parameter_action']['new_b'])
Pnew=P.subs({a:newa,b:newb},simultaneous=True)
matrix_zero('Ga2_parameter_action',g*P*g.T-substitute(Pnew,g*s.Matrix(x)))
zero('Ga2_determinant',g.det()-1)
c2,e2=s.symbols('c2 e2')
check('Ga2_group_law',(g*g.subs({c:c2,e:e2})-g.subs({c:c+c2,e:e+e2})).applyfunc(s.expand)==s.zeros(5))
normalizer={c:s.sympify(data['parameter_action']['normalizing_c']),e:s.sympify(data['parameter_action']['normalizing_e'])}
zero('normalizing_a',newa.subs(normalizer));zero('normalizing_b',newb.subs(normalizer))

# Irreducibility and reduced singular support of the NN boundary quintic.
facts=data['P0_quintic'];G=s.sympify(facts['G']);q=s.sympify(facts['q']);rr=s.sympify(facts['r']);ss=s.sympify(facts['s']);U=s.sympify(facts['U'])
zero('G_canonical',G-120*canonical_F(P0))
zero('cusp_identity',x[3]*G+U**2+q**3)
zero('scroll_identity',G+4*x[3]*rr**2+4*x[2]*q*rr+(x[1]-x[4])*q**2)
zero('quadratic_discriminant',s.discriminant(G,x[0])+16*x[3]**2*q**3)
check('q_rank3',s.hessian(q,x).rank()==3)
zero('G_x0_leading',s.Poly(G,x[0]).LC()+4*x[3]**3)
check('G_primitive',s.gcd_list(s.Poly(G,x[0]).all_coeffs())==1)
zero('singular_boundary_forces_x2',s.diff(G,x[1]).subs(x[3],0)+5*x[2]**4)
for j in range(5):zero(f'Pi_singular_{j}',s.diff(G,x[j]).subs({x[2]:0,x[3]:0}))
M=s.Matrix(facts['singular_scroll_matrix']);mins=[M[:,[i,j]].det() for i,j in combinations(range(3),2)]
check('scroll_minors',[s.expand(v) for v in mins]==[s.expand(q),s.expand(rr),s.expand(ss)])
Sgb=s.groebner([q,rr,ss],*x)
for j in range(5):zero(f'Scroll_singular_{j}',Sgb.reduce(s.diff(G,x[j]))[1])
# The cusp chart is an actual polynomial coordinate change on x3=1.
vv,uu,tt,ww=s.symbols('vv uu tt ww')
chart={x[3]:1,x[2]:tt,x[4]:ww,x[1]:tt**2+ww+uu,x[0]:(vv+(tt**2+ww+uu)*tt+tt**3-3*tt*ww)/2}
zero('cusp_chart_q',q.subs(chart,simultaneous=True)-uu)
zero('cusp_chart_U',U.subs(chart,simultaneous=True)-vv)
zero('cusp_chart_G',G.subs(chart,simultaneous=True)+vv**2+uu**3)

# Torus weights make all nonzero pencil parameters projectively equivalent.
H=s.diag(1,u,u**2,u**3,u)
matrix_zero('NN_torus_P0',H*P0*H.T-u**(-1)*substitute(P0,H*s.Matrix(x)))
matrix_zero('NN_torus_Q',H*Q*H.T-u*substitute(Q,H*s.Matrix(x)))
# The compatible pencil is explicitly conjugate to the originally integrated cubic family.
h=s.Matrix(data['gauge_to_cubic']['matrix']);Pc=matrix(data['gauge_to_cubic']['total_P_entries'])
zero('cubic_gauge_determinant',h.det()-1)
matrix_zero('cubic_gauge_identity',h*(P0+t*Q)*h.T-substitute(Pc,h*s.Matrix(x)))

# Full coordinate conjugacy over the exact degree-five number field.
C=s.Matrix(data['conjugacy']['matrix']);scale=s.sympify(data['conjugacy']['tensor_scale']);mod=s.sympify(data['conjugacy']['field_equation'])
Delta=C*(P0+Q)*C.T-scale*substitute(T,C*s.Matrix(x))
details['conjugacy_quadratic_coefficients_checked']=coeff_remainders('NN_to_SS',Delta,k,mod)
zero('conjugacy_determinant_formula',C.det()-s.sympify(data['conjugacy']['matrix_determinant']))
detrem=s.rem(s.Poly(C.det(),k),s.Poly(mod,k)).as_expr()
check('conjugacy_invertible',detrem!=0);details['conjugacy_determinant_in_field']=str(detrem)

# Generic rank-zero curve: C4 plus a line meeting it at two distinct points.
Z=zero_scheme(T);sv,zv=s.symbols('s z')
param=[s.sympify(v) for v in data['generic_zero_support']['SS_quartic_parametrization']]
for name,eq in Z.items():
    zero('SS_C4_zero_'+name,eq.subs(dict(zip(x,param)),simultaneous=True))
    zero('SS_line_zero_'+name,eq.subs({x[0]:0,x[1]:0,x[2]:0}))
zero('SS_Z012_formula',Z['012']-(x[1]**3-x[0]*x[1]*x[2])/3)
zero('SS_Z013_formula',Z['013']-(-x[0]*x[1]*x[3]/6-x[0]*x[2]**2/2+2*x[1]**2*x[2]/3))
zero('SS_Z014_formula',Z['014']-(x[0]**3-x[0]*x[1]*x[4]/2+x[1]**2*x[3]-x[1]*x[2]**2))
zero('SS_Z123_boundary',Z['123'].subs({x[0]:0,x[1]:0})-x[2]**3/2)
NNZ=zero_scheme(P0+Q);nnparam=[s.sympify(v) for v in data['generic_zero_support']['NN_quartic_parametrization']]
for name,eq in NNZ.items():
    zero('NN_C4_zero_'+name,eq.subs(dict(zip(x,nnparam)),simultaneous=True))
    zero('NN_line_zero_'+name,eq.subs({x[2]:0,x[3]:0,x[1]:x[4]}))
# Parametric construction of C sends NN z/s to k(3z-2s)/(3z+2s).
sp=2*sv+3*zv;tp=k*(-2*sv+3*zv)
ssparam=[sp**3*tp,sp**2*tp**2,sp*tp**3,tp**4,2*sp**4]
check('conjugacy_curve_parametrization',(C*s.Matrix(nnparam)-s.Matrix(ssparam)).applyfunc(s.expand)==s.zeros(5,1))

# All automorphisms of C4 plus its secant line come from z -> c z or c/z.
# Exact necessities and sufficiencies inside those two families give D5.
D=s.diag(c,c**2,c**3,c**4,1);R=s.zeros(5);R[0,2]=c;R[1,1]=c**2;R[2,0]=c**3;R[3,4]=c**4/2;R[4,3]=2
for name,A,sgn,pol in [('rotations',D,1,c**5-1),('reflections',R,-1,c**5-s.Rational(4,9))]:
    E=A*T*A.T-lam*substitute(T,A*s.Matrix(x))
    coeff=s.Poly(E[0,1],*x).coeff_monomial(x[0]*x[1] if name=='rotations' else x[1]*x[2])
    zero(name+'_scale_necessity',coeff-(lam-1)*c**3/5 if name=='rotations' else coeff-(lam+1)*c**3/5)
    specialized=E.subs(lam,sgn)
    coeffs=[cc for i,j in pairs for cc in s.Poly(s.expand(specialized[i,j]),*x).coeffs() if cc!=0]
    gcd=s.factor(s.gcd_list(coeffs));details[name+'_coefficient_gcd']=str(gcd)
    # Remove the invertible c-powers; the remaining factor must be pol.
    quotient=s.cancel(gcd/pol)
    cp=s.Poly(quotient,c)
    check(name+'_only_parameter_roots',len(cp.terms())==1 and cp.terms()[0][1]!=0)
    coeff_remainders(name+'_sufficiency',specialized,c,pol)
check('reflection_square',R*R==c**4*s.eye(5))

# Optional exact matrix rank certificates: a nonzero 125x125 minor and 25
# independent kernel columns prove rank exactly125, without generic sampling.
if args.tangent:
    for filename in ['full_tangent_nn.json','full_tangent_generic_nn_linear.json']:
        td=json.loads((ROOT/filename).read_text());label=filename.removesuffix('.json')
        MM=s.zeros(*td['linear_map_shape'])
        for ij,v in td['matrix_entries'].items():
            i,j=map(int,ij.split(','));MM[i,j]=s.sympify(v)
        K=s.Matrix.hstack(*[s.Matrix([s.sympify(v) for v in vv]) for vv in td['kernel_vectors']])
        check(label+'_kernel',MM*K==s.zeros(MM.rows,K.cols))
        check(label+'_kernel_independent',K[td['kernel_free_columns'],:]==s.eye(K.cols))
        rw=td['rank_witness'];minor=MM[rw['rows'],rw['columns']]
        dd=DomainMatrix.from_Matrix(minor).convert_to(s.QQ).det();dd=s.QQ.to_sympy(dd)
        zero(label+'_rank_minor',dd-s.sympify(rw['determinant']));check(label+'_rank_minor_nonzero',dd!=0)
        check(label+'_rank_dimension',len(rw['rows'])+K.cols==150)
        O=s.Matrix.hstack(*[s.Matrix([s.sympify(v) for v in vv]) for vv in td['orbit_vectors']])
        base=matrix(td['P_entries']);pv=[]
        for item in td['basis']:
            i,j=item['pair'];mon=s.prod(x[ii]**power for ii,power in enumerate(item['monomial_exponents']));pv.append(s.Poly(base[i,j],*x).coeff_monomial(mon))
        _,opiv=DomainMatrix.from_Matrix(O).convert_to(s.QQ).rref();_,ospiv=DomainMatrix.from_Matrix(O.row_join(s.Matrix(pv))).convert_to(s.QQ).rref()
        check(label+'_orbit_rank',len(opiv)==td['orbit_rank'])
        check(label+'_projective_orbit',len(ospiv)-1==td['projective_orbit_dimension'])
        if filename=='full_tangent_nn.json':
            qv=[]
            for item in td['basis']:
                i,j=item['pair'];mon=s.prod(x[ii]**power for ii,power in enumerate(item['monomial_exponents']));qv.append(s.Poly(Q[i,j],*x).coeff_monomial(mon))
            _,qpp=DomainMatrix.from_Matrix(O.row_join(s.Matrix(pv)).row_join(s.Matrix(qv))).convert_to(s.QQ).rref()
            check('NN_Q_is_transverse',len(qpp)==25)
report={'all_passed':all(checks.values()),'check_count':len(checks),'checks':checks,'details':details,'certificate_sha256':hashlib.sha256(args.certificate.read_bytes()).hexdigest(),'seconds':round(time.monotonic()-start,3)}
args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ['all_passed','check_count','details','seconds']},indent=2))

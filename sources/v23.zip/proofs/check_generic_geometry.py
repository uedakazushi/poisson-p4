"""Exact identities behind the irreducibility, nonnormality, and D5 proofs.

The proof of irreducibility is the Gauss/discriminant argument in the manuscript;
this script verifies its polynomial identities, not a numerical proxy.
"""
import argparse
import json
from itertools import combinations
from pathlib import Path
import sympy as s

ROOT = Path(__file__).resolve().parents[1]
x = s.symbols("x0:5")
t, c, u, v = s.symbols("t c u v")
local = {str(z): z for z in (*x, t)}
checks = []

def ck(label, value):
    if not value:
        raise AssertionError(label)
    checks.append(label)

def eq(label, expression):
    ck(label, s.cancel(s.expand(expression)) == 0)

def matrix(entries):
    P = s.zeros(5)
    for ij, z in entries.items():
        i, j = map(int, ij)
        P[i, j] = s.sympify(z, locals=local)
        P[j, i] = -P[i, j]
    return P

def push(g, P):
    y = g.inv() * s.Matrix(x)
    return (g * P * g.T).subs(dict(zip(x, y)), simultaneous=True).applyfunc(s.cancel)

d = json.loads((ROOT / "proofs/ss/pencil.json").read_text())
P = matrix(d["pencil_entries"])
F = s.sympify(d["F"], locals=local)
G = s.expand(-90 * F)
A = x[0] * x[1] ** 2
B = -4*t*x[0]**3*x[1]-3*x[0]*x[1]*x[2]*x[3]+3*x[0]*x[2]**3-3*x[1]**3*x[3]+3*x[1]**2*x[2]**2
R = x[0]*x[2]-x[1]**2
L = x[1]*x[3]-x[2]**2
S = 8*t*x[0]*x[1]*R-3*L**2
Z = 2*A*x[4]+B
eq("leading_coefficient", s.Poly(G,x[4]).coeff_monomial(x[4]**2)-A)
eq("linear_coefficient", s.Poly(G,x[4]).coeff_monomial(x[4])-B)
eq("quadratic_discriminant", s.discriminant(G,x[4])+3*R**2*S)
eq("square_completion", 4*A*G-Z**2-3*R**2*S)
discS = 64*t**2*x[1]**6+96*t*x[1]*x[2]*L**2
eq("nonsquare_discriminant", s.discriminant(S,x[0])-discS)
ck("nonsquare_discriminant_nonzero", s.expand(discS) != 0)
eq("B_mod_x0", B.subs(x[0],0)+3*x[1]**2*L)
eq("B_mod_x1", B.subs(x[1],0)-3*x[0]*x[2]**3)
ck("primitive_gcd", s.gcd(A,B) == 1)
eq("S_mod_R", S.subs(x[2],x[1]**2/x[0])+3*L.subs(x[2],x[1]**2/x[0])**2)
surface = {x[2]:x[1]**2/x[0]}
surface[x[4]] = s.cancel((-B/(2*A)).subs(surface))
eq("surface_F", G.subs(surface,simultaneous=True))
for i in range(5):
    eq(f"surface_gradient_{i}", s.diff(G,x[i]).subs(surface,simultaneous=True))

P1 = P.subs(t,1)
triples = list(combinations(range(5),3))
zero = {(i,j,k):s.expand(x[i]*P1[j,k]-x[j]*P1[i,k]+x[k]*P1[i,j]) for i,j,k in triples}
eq("Z012",zero[0,1,2]-(x[1]**3-x[0]*x[1]*x[2])/3)
eq("Z013",zero[0,1,3]-(-x[0]*x[1]*x[3]/6-x[0]*x[2]**2/2+2*x[1]**2*x[2]/3))
eq("Z014",zero[0,1,4]-(x[0]**3-x[0]*x[1]*x[4]/2+x[1]**2*x[3]-x[1]*x[2]**2))
eq("Z123_boundary",zero[1,2,3].subs({x[0]:0,x[1]:0})-x[2]**3/2)
param = [u**3*v,u**2*v**2,u*v**3,v**4,2*u**4]
for triple, pol in zero.items():
    eq(f"quartic_zero_{triple}",pol.subs(dict(zip(x,param)),simultaneous=True))
    eq(f"line_zero_{triple}",pol.subs({x[0]:0,x[1]:0,x[2]:0}))
Sg = s.diag(c,c**2,c**3,c**4,1)
Rg = s.Matrix([[0,0,c,0,0],[0,c**2,0,0,0],[c**3,0,0,0,0],[0,0,0,0,c**4/2],[0,0,0,2,0]])
scaled = push(Sg,P1)-P1
reversedP = push(Rg,P1)+P1
for i,j in combinations(range(5),2):
    for coeff in s.Poly(s.together(scaled[i,j]).as_numer_denom()[0],x).coeffs():
        eq(f"rotation_remainder_{i}{j}_{len(checks)}",s.rem(coeff,c**5-1,c))
    for coeff in s.Poly(s.together(reversedP[i,j]).as_numer_denom()[0],x).coeffs():
        eq(f"reflection_remainder_{i}{j}_{len(checks)}",s.rem(coeff,9*c**5-4,c))
eq("rotation_necessity",s.cancel(scaled[0,4]/(x[2]**2-x[1]*x[3]))-(c**-5-1))
ck("reflection_square",Rg*Rg==c**4*s.eye(5))
report={"all_passed":True,"check_count":len(checks),"checks":checks,
        "method":"Exact rational polynomial identities; irreducibility uses the written nonsquare and Gauss argument.",
        "generic_stabilizer":"D5 of order10; tensor stabilizer mu5"}
ap=argparse.ArgumentParser()
ap.add_argument("--output",type=Path,default=ROOT/"data/generic_geometry_audit.json")
args=ap.parse_args()
args.output.write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"all_passed":True,"check_count":len(checks)}))

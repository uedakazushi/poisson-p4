"""Independent exact certificate: SS geometry and MPS Example 5.6 identification.

Run with SymPy. Input v22 is read only; output is adjacent to this script.
All arithmetic is exact over Q(a,t), not finite-field or numerical sampling.
The scheme-theoretic radical statements are proved in the companion note;
this program checks the identities used in those proofs.
"""
from pathlib import Path
import argparse
import itertools
import json
import sympy as s

HERE = Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input',type=Path,default=HERE/'ss_input.json')
parser.add_argument('--catalog',type=Path,default=HERE/'t37_catalog_reference.json')
args=parser.parse_args()
INPUT = args.input.resolve()
x = s.symbols('x0:5')
y = s.symbols('y0:5')
a, t, u, v, w, z, h = s.symbols('a t u v w z h')
loc = {str(q): q for q in (*x, a)}
raw = json.loads(INPUT.read_text())
P = s.zeros(5)
for key, value in raw['P'].items():
    i, j = map(int, key)
    P[i,j] = s.sympify(value, locals=loc)
    P[j,i] = -P[i,j]

checks = {}
def check(name, cond):
    checks[name] = bool(cond)
    assert cond, name

Q = 3*a*(x[2]**2-x[1]*x[3]) + x[0]*x[4]
C = 3*a*x[2]*(x[2]**2-x[1]*x[3]) + x[1]**2*x[4]
R = x[1]**2-x[0]*x[2]
q = x[2]**2-x[1]*x[3]
F = s.sympify(raw['F'], locals=loc)
check('actual_Pfaffian_factor', s.factor(F+Q*C/(90*a)) == 0)
check('Q_Hessian_determinant', s.det(s.hessian(Q,x)) == 54*a**3)
check('intersection_identity', s.expand(C-x[2]*Q-x[4]*R) == 0)
V = s.Matrix([2*x[0], x[1], 0, -x[3], -2*x[4]])/10
check('P_dQ', (P*s.Matrix([s.diff(Q,xi) for xi in x])-Q*V).applyfunc(s.expand) == s.zeros(5,1))
check('P_dC', (P*s.Matrix([s.diff(C,xi) for xi in x])+C*V).applyfunc(s.expand) == s.zeros(5,1))

# Affine projective bivector, chart x0=1.
p = s.Matrix(4,4,lambda i,j:s.expand(P[i+1,j+1]-x[i+1]*P[0,j+1]+x[j+1]*P[0,i+1]).subs(x[0],1))
qsub = {x[4]:3*a*(x[1]*x[3]-x[2]**2)}
fQ = (x[1]**2-x[2])/x[4]**2
check('Q_rational_Casimir', (p*s.Matrix([s.diff(fQ,xi) for xi in x[1:]])).subs(qsub).applyfunc(s.factor) == s.zeros(4,1))
csub = {x[4]:3*a*x[2]*(x[1]*x[3]-x[2]**2)/x[1]**2}
pc = p[:3,:3].subs(csub)
fC = (x[1]*x[3]-x[2]**2)**2/(x[1]**2*(x[1]**2-x[2]))
check('C_rational_Casimir', (pc*s.Matrix([s.diff(fC,xi) for xi in x[1:4]])).applyfunc(s.factor) == s.zeros(3,1))

surfaces = {
    'S': ([0,0,u,v], -u*v/s.Integer(6)),
    'A': ([u,u*v,u*v**2,0], u*(u-v)/3),
    'B': ([u,u**2,v,3*a*u*(v-u**3)], u*(u**3-v)/6),
}
for name,(coord,biv) in surfaces.items():
    J=s.Matrix(coord).jacobian([u,v])
    expected=biv*(J[:,0]*J[:,1].T-J[:,1]*J[:,0].T)
    observed=p.subs(dict(zip(x[1:],coord)), simultaneous=True)
    check('induced_surface_'+name, (observed-expected).applyfunc(s.expand)==s.zeros(4))

# Projective zero equations are coefficients of E wedge P.
triples=list(itertools.combinations(range(5),3))
Z={ijk:s.factor(x[ijk[0]]*P[ijk[1],ijk[2]]-x[ijk[1]]*P[ijk[0],ijk[2]]+x[ijk[2]]*P[ijk[0],ijk[1]]) for ijk in triples}
check('zero_on_T', all(s.expand(e.subs(dict(zip(x,[1,u,u**2,u**3,0]))))==0 for e in Z.values()))
for i,j in [(0,3),(0,4),(3,4)]:
    sub={x[k]:0 for k in range(5) if k not in (i,j)}
    check('zero_on_L'+str(i)+str(j), all(s.expand(e.subs(sub))==0 for e in Z.values()))
# Identities giving the reverse inclusion in the companion proof.
check('x4_chart_G124', s.expand(Z[(1,2,4)]+x[1]*x[2]*x[4]/6)==0)
check('x4_chart_G134', s.expand(Z[(1,3,4)]-x[4]*(x[1]*x[3]-3*x[2]**2)/6)==0)
check('x4_chart_G234', s.expand(Z[(2,3,4)]-x[4]*(-3*a*x[2]*x[3]+2*x[1]*x[4])/(18*a))==0)
check('x4_chart_G034_on_S', s.expand(Z[(0,3,4)].subs({x[1]:0,x[2]:0})+x[0]*x[3]*x[4]/6)==0)
for j in (1,2,3):
    check('x4_zero_q_'+str(j), s.expand(Z[(0,j,4)].subs(x[4],0)+a*x[j]*q)==0)
# Modulo q, the three remaining equations yield x1 R/3, 2x2 R/3, x3 R/3.
for ijk,expected in [((0,1,2),x[1]*R/3),((0,1,3),2*x[2]*R/3),((0,2,3),x[3]*R/3)]:
    rem=s.rem(s.together(Z[ijk].subs(x[4],0)-expected),q,x[2])
    check('x4_zero_R_'+''.join(map(str,ijk)),s.factor(rem)==0)

# Orders and leading forms in normal coordinates at generic curve points.
curve_subs={
    'T':{x[0]:1,x[1]:u,x[2]:u**2+v,x[3]:u**3+w,x[4]:z},
    'L03':{x[0]:1,x[1]:v,x[2]:w,x[3]:u,x[4]:z},
    'L04':{x[0]:1,x[1]:v,x[2]:w,x[3]:z,x[4]:u},
    'L34':{x[0]:v,x[1]:w,x[2]:z,x[3]:1,x[4]:u},
}
orders={}
for name, sub in curve_subs.items():
    orders[name]={}
    for label,f in [('Q',Q),('C',C),('QC',Q*C)]:
        pol=s.Poly(s.expand(f.subs(sub).subs({v:h*v,w:h*w,z:h*z})),h)
        order=min(k[0] for k,coef in pol.terms())
        orders[name][label]={'order':order,'leading_form':str(s.factor(pol.coeff_monomial(h**order)))}
check('divisor_orders', {k:[orders[k][j]['order'] for j in ['Q','C','QC']] for k in orders}=={'T':[1,1,2],'L03':[1,2,3],'L04':[0,2,2],'L34':[1,2,3]})

# Explicit filtered toric degeneration g_s=diag(s^0,s^0,s^2,s^5,s^6).
weights=[0,0,2,5,6]
lambda_ss=s.zeros(5)
term_weights=[]
for i,j in itertools.combinations(range(5),2):
    for mon,coef in s.Poly(P[i,j],*x).terms():
        wt=weights[i]+weights[j]-sum(k*m for k,m in zip(weights,mon))
        term_weights.append({'entry':str(i)+str(j),'monomial':list(mon),'pushforward_weight':wt})
        is_diag=mon[i]==mon[j]==1 and sum(mon)==2
        check('weight_'+str(i)+str(j)+'_'+str(mon),wt==0 if is_diag else wt>0)
        if is_diag:lambda_ss[i,j]=coef;lambda_ss[j,i]=-coef
A=s.Matrix(4,4,lambda i,j:lambda_ss[i+1,j+1]-lambda_ss[0,j+1]+lambda_ss[0,i+1])
check('toric_limit_nondegenerate',A.det()==s.Rational(1,36))
B=s.zeros(5)
B[1:5,1:5]=A.inv()
for i in range(1,5):
    B[0,i]=-sum(B[j,i] for j in range(1,5));B[i,0]=-B[0,i]
smooth=[]
for i,j in itertools.combinations(range(5),2):
    if not B[i,j]:continue
    theta=(B[j,:]-B[i,:])/B[i,j]
    if all(theta[k].is_integer and theta[k]>=0 for k in range(5) if k not in (i,j)):
        smooth.append({'edge':[i,j],'weight':list(theta)})
check('smoothable_edges', [z['edge'] for z in smooth]==[[0,4],[1,3],[1,4],[2,3]])

# Exact MPS Example 5.6 semiclassical coefficients.
# v=exp(h/30), epsilon=h; an order-m coefficient contributes lim h^(m-1) C(v).
vv=s.exp(h/30)
quantum_coefficients={
 'c2':(2,-vv**12/(1-vv**15)),
 'c2b':(2,1/(vv**5*(1-vv**10))),
 'c3':(3,(1+vv**10)/(vv**5*(1-vv**10)*(1-vv**15))),
 'c4':(4,vv**5*(1-vv**5)*(1+vv**10)/((1-vv**10)**2*(1-vv**15)**2)),
 'c6':(6,vv**2*(1+vv**5+vv**15)/((1-vv**5)**3*(1+vv**5)**4*(1-vv**15)**2)),
}
limits={k:s.limit(h**(m-1)*c,h,0) for k,(m,c) in quantum_coefficients.items()}
check('semiclassical_limits',limits=={'c2':2,'c2b':-3,'c3':12,'c4':-12,'c6':-162})
L=s.Matrix([[0,-6,6,-2,2],[6,0,-3,-1,-2],[-6,3,0,-3,6],[2,1,3,0,-6],[-2,2,-6,6,0]])/30
M=s.Matrix(5,5,lambda i,j:L[i,j]*y[i]*y[j])
g0,g1,g2,g3=s.symbols('g0:4')
extras={
 (1,0):g0*y[2]*y[3]+2*g0*g2*y[4]**2,
 (2,1):g1*y[0]**2,
 (3,2):g2*y[4]**2,
 (4,3):g3*y[1]*y[2]+2*g1*g3*y[0]**2,
 (4,0):-3*g0*g3*y[2]**2,
 (3,0):12*g0*g2*g3*y[2]*y[4],
 (4,1):12*g0*g1*g3*y[0]*y[2],
 (3,1):-12*g0*g1*g2*g3*y[0]*y[4]-162*g0**2*g1*g2*g3**2*y[2]**2,
}
for (i,j),f in extras.items():M[i,j]+=f;M[j,i]-=f
perm=[2,3,1,4,0]
sub_y={x[perm[i]]:y[i] for i in range(5)}
check('diagonal_permutation',lambda_ss.extract(perm,perm)==L)
trans=s.zeros(5)
for (i,j),f in {(1,4):x[0]**2,(2,3):-2*x[0]**2/(9*a),(2,4):4*x[0]*x[1]/3,(3,4):2*x[0]*x[2]/3+x[1]**2}.items():trans[i,j]=f;trans[j,i]=-f
expected=(P+t*trans).extract(perm,perm).subs(sub_y,simultaneous=True)
observed=M.subs({g0:-1/(9*a),g1:-s.Rational(1,2),g2:-t,g3:-a})
check('full_MPS_identification_all_a_t',(expected-observed).applyfunc(s.factor)==s.zeros(5))
check('new_transversal_has_positive_weights',all(weights[i]+weights[j]-sum(k*m for k,m in zip(weights,mon))>0 for i,j in itertools.combinations(range(5),2) for mon,coef in s.Poly(trans[i,j],*x).terms() if coef))

# Match the old project catalogue (the numbering is internal, not MPS's).
catalog=json.loads(args.catalog.read_text())
catalog_perm=[1,4,3,0,2]
check('old_catalog_T37_biresidue',B.extract(catalog_perm,catalog_perm)==s.Matrix(catalog['T37']['period_biresidue']))

result={
 'title':'SS geometry and exact MPS Example 5.6 / catalogue T37 identification',
 'field':'C, parameter a nonzero; identities computed over Q(a,t)',
 'input':str(INPUT),'checks':checks,'check_count':len(checks),'all_passed':all(checks.values()),
 'Q':str(Q),'C':str(C),'R':str(R),
 'Q_Casimir':'(x1**2-x0*x2)/x4**2',
 'C_Casimir':'(x1*x3-x2**2)**2/(x1**2*(x1**2-x0*x2))',
 'global_zero_cubics':{''.join(map(str,k)):str(v) for k,v in Z.items()},
 'reduced_projective_zero_support':'T0123 union L03 union L04 union L34',
 'divisor_orders':orders,'toric_pushforward_weights':term_weights,
 'lambda':lambda_ss.tolist(),'biresidues':B.tolist(),'smoothable_weights':smooth,
 'MPS_coordinate_order':perm,'MPS_gamma':['-1/(9*a)','-1/2','-t','-a'],
 'semiclassical_limits':limits,'MPS_all_brackets_match':True,
 'catalogue_id':'T37','catalogue_biresidue_coordinate_order':catalog_perm,
 'primary_sources':[
  {'url':'https://arxiv.org/html/2411.10425v1','location':'Example 5.6; Section 4.4 and Lemma 5.2 for weight conventions; Theorem 7.6'},
  {'url':'https://arxiv.org/pdf/2010.08692','location':'Theorem 1.4, Table 2, Example 6.24'},
  {'url':'https://w3.impa.br/~jvp/diagonalpoisson.pdf','location':'Theorems 2 and 3.3'},
 ],
 'caveat':'Reduced zero support is proved in the note, not by asserting that the zero scheme is reduced. Generic divisor orders are not zero-scheme lengths.'
}
(HERE/'ss_geometry_mps_certificate.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=str)+'\n')
print(json.dumps({'all_passed':True,'checks':len(checks),'full_MPS_match':True,'catalogue':'T37','output':str(HERE/'ss_geometry_mps_certificate.json')},indent=2))

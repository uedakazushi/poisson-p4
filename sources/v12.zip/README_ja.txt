射影4空間のPoisson構造 — 研究継続 第12版
========================================

対象：複素数上の全射影Poissonスキーム。PGL商は取らない。
零磁気点P*=P_(B=0)の全完備局所環を、21次元軌道因子と六変数横断環Bに分けて扱う。
大域的な完全分類は未完。従来の大域既約成分数の下界57は変更していない。

主要成果
--------
1. 六つの実際の素イデアルを共通形式座標で明示し、B_redそのものを決定。
2. 六枝の全15組のスキーム論的交叉を決定。四組は長さ2の非被約点。
3. gr(B_red)=S/(J+(dL,dp,dq))、gr(N)=(J+(dL,dp,dq))/Jを全次数で決定。
   実際の環が被約でも、その接錐の共有正重み平面には一般長さ2が残る。
4. 正規化座標でN=(dL,dp,d(q−9b²))=dK16。B上の最小生成元数は3。
5. A=C[[c,d]]に対してN/Tは自由階数4。N=A<n,an,bn,b²n>⊕T (A加群として)。
   全環作用と、N/Tの単位を持たない代数としての全乗法を明示。
6. c³T=0。N4=d³C[[d]]ε5、ε5=b³n、n4=(1323/11776)d³ε5。
   磁気平面イデアルhについてh³N=C[[d]]ε5、h4N=0。
7. 正規化されたd=0ファイバーB/(d)は被約。N/dNは非零の平方零代数だが、
   B/(d)への自然写像は零である。
8. 全横断環Bの最小定義方程式数は11。次数は(2,2,2,2,3,3,3,3,3,5,5)。
   Jの最小方程式数14と異なるため、B≇completion(S/J)。A2枝による独立証明もある。

11本は有限の陰関数系で定義した完全な代数的形式冪級数である。
その五次Taylor多項式だけで全環を定義するという主張ではない。
全環の短い乗法表示、Tの作用行列の八定数、Tを含む全積は残る課題である。

文書
----
p4_poisson_completeness_v12.pdf : 日本語研究ノート、LuaLaTeX。記入欄なし。
p4_poisson_completeness_v12.tex, preamble.tex, sections/ : 全TeXソース。
proofs/ : 最小表示・被約標準形・冪零部分についての詳細な全次数証明。
HANDOFF.txt : 次回研究用の数式・依存関係・未解決事項。
previous_v11/ : 第11版の全ファイルを変更せず保存。以前の版も再帰的に含む。

検証と再現
----------
Python 3.12、SymPy 1.14.0で確認。数学JSONは経過時間フィールドだけを除いて完全比較する。
テストは一時的な独立コピーで実行し、この資料および旧版を変更しない。

  python3 -m pip install -r requirements.txt
  PYTHONDONTWRITEBYTECODE=1 python3 code/run_checks.py --output /tmp/p4-v12-checks
  PYTHONDONTWRITEBYTECODE=1 python3 code/verify_bundle.py

標準検証は10項目：
  最小関係空間、14本の標準持ち上げ、斉次最小関係数、完全スライス定義、
  整数有理数だけの独立最小性証明書、三つの厳密な正曲線、被約環と15交叉、
  被約接錐、冪零加群代数、別実装による統合監査。
結果の完全な記録はdata/reproduced/verification_summary.jsonにある。

六次の追加整合性検査は既に完了し、そのJSONも保存している。
再実行を希望する場合は --include-sixth-order を付ける。
これは五次から全次数への証明を代替するものではない。

code/exact/independent_minimality_audit.pyはPython標準ライブラリだけで実行可能。
全350残差の29,050個の正次数単項式倍を11汎関数が殺すことと、評価行列の非零行列式、
14初項の持ち上げを検証する。Schouten/Kuranishi/RREFの実装は読み込まない。

PDFを再組版するには、LuaLaTeX、LuaTeX-ja、HaranoAjiフォント、latexmkを使用する。

  latexmk -lualatex -interaction=nonstopmode -halt-on-error p4_poisson_completeness_v12.tex

マニフェストは収録ファイル全体のSHA-256を保持する。
data/previous_v11_preservation.jsonは旧版の完全保存を確認するための記録である。
検証スクリプトの実行ログと数学的証明は異なるものであり、各全次数主張は本文・proofs/の論証に従う。

"""Record an exact finite implicit definition of the11 minimal formal equations."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parent
BASE=next(p/n for p in [HERE,*HERE.parents] for n in ['previous_v11','p4_poisson_completeness_v11'] if (p/n/'code/zero_jets/zero_initial_algebra.json').is_file())
sys.path.insert(0,str(BASE/'code/zero_jets'))
from zero_full_jet import setup
sl=setup();C=sl.C
ids=[24,25,29,43,95,97,113,115,116,128,140]
assert len(sl.rows)==98 and len(sl.wcols)==98
assert sl.D[sl.rows,sl.wcols]*sl.Mi==__import__('sympy').eye(98)
out={'definition':'Let u=(a,b,p,c,d,q), v=(v0,...,v97). Form P(u,v)=P0+sum(u_i R_i)+sum(v_j E_wcols[j]), where E_k is the coefficient monomial bivector listed below. Let F=E wedge Jacobi(P), in projective_basis_order. The98 equations F[implicit_equation_rows]=0 have a unique formal solution v=w(u) in (u)^2. Define f_i(u)=F[minimal_residual_rows[i]](u,w(u)). The full transverse completed ring is C[[u]]/(f_1,...,f_11), and11 is minimal. These are algebraic formal power series; no polynomial truncation is substituted for them.',
 'variables':list(map(str,sl.u)), 'P0':C.encode(sl.P),'normal_basis':[C.encode(R) for R in sl.R], 'implicit_variables_count':98,
 'coefficient_basis_order':[[list(I),list(m)] for I,m in C.basis], 'projective_basis_order':[[list(I),list(m)] for I,m in C.projective_basis],
 'implicit_coefficient_columns':sl.wcols,'implicit_equation_rows':sl.rows,'minimal_residual_rows':ids,
 'minimal_residual_coordinates':[{'row':i,'wedge_indices':list(C.projective_basis[i][0]),'quartic_exponents':list(C.projective_basis[i][1])} for i in ids],
 'implicit_jacobian_rank':98,'full_derivative_rank':98,'all_passed':True}
HERE.joinpath('slice_definition.json').write_text(json.dumps(out,indent=2)+'\n')
print({'implicit_rows':len(sl.rows),'minimal_residuals':len(ids),'all_passed':True})

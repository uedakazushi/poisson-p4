import sys,json,time
from pathlib import Path
import sympy as s
HERE=Path(__file__).resolve().parent
BASE=next(p/n for p in [HERE,*HERE.parents] for n in ['previous_v11','p4_poisson_completeness_v11'] if (p/n/'code/zero_jets/zero_initial_algebra.json').is_file())
sys.path.insert(0,str(BASE/'code/zero_jets'))
from zero_full_jet import mon,expr
from full_kuranishi import rref
here=Path(__file__).resolve().parent;base=BASE/'code/zero_jets'
refs=json.loads((here/'minimal_equations_5.json').read_text()); ids=refs['original_residual_row_indices'];z=json.loads((base/'zero_jet_5.json').read_text());N=5;vs=s.symbols('a b p c d q')
keys=[m for e in range(2,N+1) for m in mon(6,e)];ki={m:i for i,m in enumerate(keys)}
M=s.zeros(350,len(keys))
for ent in z['residuals']:
 for i,j,val in ent['entries']:M[i,ki[tuple(ent['monomials'][j])]]=s.Rational(val)
M=M[ids,:]
rows=[];tags=[]
for dd in range(4):
 for mm in mon(6,dd):
  for ri,row in enumerate(M.tolist()):
   new={}
   for j,val in enumerate(row):
    if not val:continue
    e=tuple(a+b for a,b in zip(keys[j],mm))
    if sum(e)<=N:new[ki[e]]=val
   if new:rows.append(new);tags.append((ri,mm))
A=s.MutableSparseMatrix(len(rows),len(keys),{(i,j):v for i,row in enumerate(rows) for j,v in row.items()})
_,pa=rref(A.T);A=A[pa,:];tags=[tags[i] for i in pa];print('BASIS',A.shape,flush=True)
assert A.rows==297
Aug,pv=rref(A.row_join(s.eye(A.rows))); B=Aug[:,:len(keys)];T=Aug[:,len(keys):]
assert len(pv)==297 and max(pv)<len(keys);assert T*A==B
# mI basis from nonconstant multiples of selected generators
rowsm=[]
for dd in range(1,4):
 for mm in mon(6,dd):
  for row in M.tolist():
   new={}
   for j,val in enumerate(row):
    if not val:continue
    e=tuple(a+b for a,b in zip(keys[j],mm))
    if sum(e)<=N:new[ki[e]]=val
   if new:rowsm.append(new)
AM=s.MutableSparseMatrix(len(rowsm),len(keys),{(i,j):v for i,row in enumerate(rowsm) for j,v in row.items()})
BM,pm=rref(AM);BM=BM[:len(pm),:];assert len(pm)==286
nice=[s.sympify(f,locals=dict(zip(map(str,vs),vs))) for f in json.loads((base/'zero_initial_algebra.json').read_text())['nice_exact_generators']]
forms=[];comb=[];normal=[]
for f in nice:
 deg=s.Poly(f,*vs).total_degree(); fp=s.Poly(f,*vs)
 row=s.Matrix([[fp.coeff_monomial(s.prod(x**e for x,e in zip(vs,k))) for k in keys]])
 out=s.zeros(1,len(keys));co=s.zeros(1,len(tags))
 for i,p in enumerate(pv):
  if sum(keys[p])!=deg:continue
  c=row[p]
  if c:
   low=B[i,:].applyfunc(lambda x:x)
   for j,k in enumerate(keys):
    if sum(k)>deg:low[j]=0
   row-=c*low;out+=c*B[i,:];co+=c*T[i,:]
 assert not any(row)
 # co is a vector of monomial-multiplied generator terms, turn it into11 polynomial multipliers
 pp=[0]*len(ids)
 for v,(gi,mm) in zip(co,tags):
  if v:pp[gi]+=v*s.prod(x**e for x,e in zip(vs,mm))
 pp=[s.expand(f) for f in pp]
 assert out==co*A
 nr=out.copy()
 for i,p in enumerate(pm):
  if nr[p]:nr-=nr[p]*BM[i,:]
 forms.append(str(s.factor(expr(out,keys,vs))));comb.append([str(s.factor(f)) for f in pp]);normal.append(nr)
 print('LIFT',str(s.factor(f)),'NF nonzero',bool(any(nr)),flush=True)
NF=s.Matrix.vstack(*normal);_,genids=rref(NF.T);assert len(genids)==11
print('CHOSEN',genids,flush=True)
zero=dict.fromkeys(vs,0)
class_matrix=s.Matrix([[s.sympify(v,locals=dict(zip(map(str,vs),vs))).subs(zero) for v in row] for row in comb])
assert len(rref(class_matrix)[1])==11
assert class_matrix[9,:]==s.zeros(1,11) and class_matrix[13,:]==s.zeros(1,11)
assert class_matrix[12,:]==-class_matrix[10,:]/213-s.Rational(968,1065)*class_matrix[11,:]
res={'scope':'Exact algebraic-series generators defined as polynomial combinations of selected11 full Kuranishi residuals; listed Taylor forms only through degree5.', 'raw_generator_row_indices':ids,'standard_basis_leading_forms':[str(s.factor(f)) for f in nice], 'lifted_standard_basis_through_degree5':forms, 'polynomial_multipliers_of_raw_generators':comb,'minimal_generators_indices_in_lifted_standard_basis':genids,'minimal_generators_leading_forms':[str(s.factor(nice[i])) for i in genids],'minimal_generators_through_degree5':[forms[i] for i in genids],'constant_class_matrix_in_raw_residual_basis':[[str(v) for v in row] for row in class_matrix.tolist()],'redundant_classes':{'9':'0','13':'0','12':'-class10/213 - 968*class11/1065'},'all_passed':True}
(here/'adapted_equations.json').write_text(json.dumps(res,indent=2)+'\n')

import sys,json,time
from pathlib import Path
import sympy as s
HERE=Path(__file__).resolve().parent
BASE=next(p/n for p in [HERE,*HERE.parents] for n in ['previous_v11','p4_poisson_completeness_v11'] if (p/n/'code/zero_jets/zero_initial_algebra.json').is_file())
sys.path.insert(0,str(BASE/'code/zero_jets'))
from zero_full_jet import mon,expr
from full_kuranishi import rref
here=Path(__file__).resolve().parent
N=int(sys.argv[1]) if len(sys.argv)>1 else 5
src=BASE/'code/zero_jets'/f'zero_jet_{N}.json'
z=json.loads(src.read_text());vs=s.symbols('a b p c d q')
keys=[m for e in range(2,N+1) for m in mon(6,e)];ki={m:i for i,m in enumerate(keys)}
M=s.zeros(350,len(keys))
for ent in z['residuals']:
 for i,j,val in ent['entries']:M[i,ki[tuple(ent['monomials'][j])]]=s.Rational(val)
R,piv=rref(M);R=R[:len(piv),:]
print('RAW_RANK',R.rows,flush=True)
multis=[m for j in range(1,N-1) for m in mon(6,j)];rows=[]
for row in R.tolist():
 nz=[(keys[i],v) for i,v in enumerate(row) if v]
 for mm in multis:
  new={}
  for k,val in nz:
   e=tuple(a+b for a,b in zip(k,mm))
   if sum(e)<=N:new[ki[e]]=val
  if new:rows.append(new)
MM=s.MutableSparseMatrix(len(rows),len(keys),{(i,j):v for i,row in enumerate(rows) for j,v in row.items()})
RM,pm=rref(MM);RM=RM[:len(pm),:]
_,pall=rref(RM.T.row_join(M.T));ids=[i-RM.rows for i in pall if i>=RM.rows]
RI,pi=rref(RM.col_join(M));RI=RI[:len(pi),:]
print('mI_RANK',RM.rows,'I_RANK',RI.rows,'MINIMAL',len(ids),'ROW_IDS',ids,flush=True)
# dimension of increasing-order filtration of I/mI determined from ranks
levels=[]
for e in range(2,N+1):
 # rank projection I -> low-degree columns; kernel filtration subtler. Find generators of residuals whose truncation to degrees<e vanish using rowops of RI.
 dcols=[i for i,k in enumerate(keys) if sum(k)>=e]
 high=RI[[j for j,p in enumerate(pi) if sum(keys[p])>=e],:]
 _,pv=rref(RM.col_join(high))
 levels.append({'order_at_least':e,'dimension_image_in_I_mod_mI':len(pv)-RM.rows})
if N==5:
    NF=M[ids,:].copy()
    for i,pv in enumerate(pm):
        for j in range(len(ids)):
            if NF[j,pv]:NF[j,:]-=NF[j,pv]*RM[i,:]
    _,quotient_cols=rref(NF)
    assert len(quotient_cols)==11
    dual=s.zeros(len(keys),11)
    for j,col in enumerate(quotient_cols):
        dual[col,j]=1
        for i,pv in enumerate(pm):dual[pv,j]-=RM[i,col]
    evaluation=M[ids,:]*dual
    assert RM*dual==s.zeros(RM.rows,11)
    assert evaluation.det()!=0
    certificate={'monomial_keys':[list(k) for k in keys],
      'functionals':[[[i,str(dual[i,j])] for i in range(len(keys)) if dual[i,j]] for j in range(11)],
      'selected_residual_rows':ids,
      'evaluation_matrix':[[str(v) for v in row] for row in evaluation.tolist()],
      'evaluation_determinant':str(evaluation.det())}
    (here/'minimality_dual_certificate.json').write_text(json.dumps(certificate,indent=2)+'\n')
polys=[str(s.factor(expr(M.row(i),keys,vs))) for i in ids]
print('FILTRATION',levels,flush=True)
for i,f in zip(ids,polys):print('ROW',i,f,flush=True)
assert len(ids)==11 and ids==[24,25,29,43,95,97,113,115,116,128,140]
assert [e['dimension_image_in_I_mod_mI'] for e in levels]==([11,7,2,2] if N==5 else [11,7,2,2,0])
assert (RI.rows,RM.rows)==((297,286) if N==5 else (678,667))
output={'scope':'Exact truncated rank certificate. All-order minimality and generation follow from v11 in(I)=J and max generator degree5, as proved in minimal_presentation_proof.txt.','all_passed':True,'input_filename':src.name,'truncation_degree':N,'raw_rank':R.rows,'truncated_ideal_rank':RI.rows,'truncated_mI_rank':RM.rows,'minimal_number_of_equations':len(ids),'original_residual_row_indices':ids,'filtration':levels,'minimal_equations_through_degree5':polys}
(here/f'minimal_equations_{N}.json').write_text(json.dumps(output,indent=2)+'\n')

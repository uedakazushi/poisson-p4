"""Independent exact certificate audit using only Python's rational arithmetic.

No SymPy, author RREF, Kuranishi, or Poisson calculus modules are imported.
The full350 fifth residuals were independently checked in v11. Here we check
an explicit11-functional lower-bound certificate and all14 standard lifts.
"""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations_with_replacement
import ast,json,hashlib
HERE=Path(__file__).resolve().parent
BASE=next(p/n for p in [HERE,*HERE.parents] for n in ['previous_v11','p4_poisson_completeness_v11'] if (p/n/'code/zero_jets/zero_initial_algebra.json').is_file())
VARIABLES=('a','b','p','c','d','q');ZERO=(0,)*6

def clean(p):return {m:v for m,v in p.items() if v}
def add(p,q,scale=Q(1)):
    r=p.copy()
    for m,v in q.items():r[m]=r.get(m,Q(0))+scale*v
    return clean(r)
def mul(p,q,cutoff=None):
    r={}
    for m,v in p.items():
        for n,w in q.items():
            e=tuple(a+b for a,b in zip(m,n))
            if cutoff is not None and sum(e)>cutoff:continue
            r[e]=r.get(e,Q(0))+v*w
    return clean(r)
def parse(source):
    def walk(n):
        if isinstance(n,ast.Constant):
            assert isinstance(n.value,int);return {ZERO:Q(n.value)} if n.value else {}
        if isinstance(n,ast.Name):
            assert n.id in VARIABLES;return {tuple(int(x==n.id) for x in VARIABLES):Q(1)}
        if isinstance(n,ast.UnaryOp):
            p=walk(n.operand)
            if isinstance(n.op,ast.USub):return {m:-v for m,v in p.items()}
            assert isinstance(n.op,ast.UAdd);return p
        assert isinstance(n,ast.BinOp)
        p=walk(n.left)
        if isinstance(n.op,ast.Pow):
            assert isinstance(n.right,ast.Constant) and isinstance(n.right.value,int) and n.right.value>=0
            r={ZERO:Q(1)}
            for _ in range(n.right.value):r=mul(r,p)
            return r
        q=walk(n.right)
        if isinstance(n.op,ast.Add):return add(p,q)
        if isinstance(n.op,ast.Sub):return add(p,q,-Q(1))
        if isinstance(n.op,ast.Mult):return mul(p,q)
        assert isinstance(n.op,ast.Div) and list(q)==[ZERO] and q[ZERO]
        return {m:v/q[ZERO] for m,v in p.items()}
    return clean(walk(ast.parse(source,mode='eval').body))
def det(matrix):
    a=[row[:] for row in matrix];n=len(a);out=Q(1)
    for i in range(n):
        j=next((j for j in range(i,n) if a[j][i]),None)
        if j is None:return Q(0)
        if j!=i:a[i],a[j]=a[j],a[i];out=-out
        p=a[i][i];out*=p
        for j in range(i+1,n):
            if a[j][i]:
                ratio=a[j][i]/p
                for k in range(i,n):a[j][k]-=ratio*a[i][k]
    return out

def read(name):return json.loads(name.read_text())
def math_digest(path):
    def clean_json(x):
        if isinstance(x,dict):return {k:clean_json(v) for k,v in x.items() if k not in {'seconds','elapsed','elapsed_seconds','execution_seconds'}}
        if isinstance(x,list):return [clean_json(v) for v in x]
        return x
    payload=json.dumps(clean_json(read(path)),sort_keys=True,separators=(',',':')).encode()
    return hashlib.sha256(payload).hexdigest()
jpath=BASE/'code/zero_jets/zero_jet_5.json';jet=read(jpath)
residuals=[{} for _ in range(350)]
for level in jet['residuals']:
    assert level['degree']<=5
    for i,j,value in level['entries']:
        m=tuple(level['monomials'][j]);residuals[i][m]=Q(value)
cert=read(HERE/'minimality_dual_certificate.json');keys=[tuple(m) for m in cert['monomial_keys']]
functionals=[{keys[i]:Q(c) for i,c in terms} for terms in cert['functionals']]
assert len(functionals)==11
by_monomial={}
for j,f in enumerate(functionals):
    for m,v in f.items():by_monomial.setdefault(m,[]).append((j,v))
positive_monomials=[tuple(combo.count(i) for i in range(6)) for d in range(1,4) for combo in combinations_with_replacement(range(6),d)]
checked=0
for f in residuals:
    for mult in positive_monomials:
        acc=[Q(0)]*11
        for m,v in f.items():
            e=tuple(a+b for a,b in zip(m,mult))
            if sum(e)>5:continue
            for j,w in by_monomial.get(e,[]):acc[j]+=v*w
        assert not any(acc)
        checked+=1
ids=cert['selected_residual_rows'];assert len(ids)==11
values=[[sum((v*ell.get(m,Q(0)) for m,v in residuals[i].items()),Q(0)) for ell in functionals] for i in ids]
assert values==[[Q(v) for v in row] for row in cert['evaluation_matrix']]
determinant=det(values);assert determinant!=0 and determinant==Q(cert['evaluation_determinant'])
# Upper bound: polynomial combinations of the11 residuals have every one
# of the14 certified generators of the full initial ideal J as initial form.
adapt=read(HERE/'adapted_equations.json')
nice=read(BASE/'code/zero_jets/zero_initial_algebra.json')['nice_exact_generators']
assert adapt['raw_generator_row_indices']==ids and len(nice)==14
for j,(coefficients,target_source,jet_source) in enumerate(zip(adapt['polynomial_multipliers_of_raw_generators'],nice,adapt['lifted_standard_basis_through_degree5'])):
    lifted={}
    for coeff,row in zip(coefficients,ids):lifted=add(lifted,mul(parse(coeff),residuals[row],cutoff=5))
    assert lifted==parse(jet_source)
    order=min(map(sum,lifted));initial={m:v for m,v in lifted.items() if sum(m)==order}
    assert initial==parse(target_source)
# The explicit redundant classes are also checked by constant multipliers.
class_matrix=[[parse(f).get(ZERO,Q(0)) for f in row] for row in adapt['polynomial_multipliers_of_raw_generators']]
assert class_matrix[9]==[Q(0)]*11 and class_matrix[13]==[Q(0)]*11
assert class_matrix[12]==[-x/Q(213)-Q(968,1065)*y for x,y in zip(class_matrix[10],class_matrix[11])]
chosen=adapt['minimal_generators_indices_in_lifted_standard_basis'];assert len(chosen)==11
assert det([class_matrix[i] for i in chosen])!=0
out={'scope':'Independent pure-Fraction lower and upper certificates for μ(I)=11, using the all-order v11 initial-ideal theorem. No linear-algebra or Kuranishi implementation imported.',
     'full_residuals':350,'positive_monomial_multiples_checked':checked,'annihilating_functionals':11,'evaluation_determinant':str(determinant),'initial_generators_lifted_from_selected_residuals':14,'adapted_minimal_equations':11,'redundant_class_relations_checked':True,'all_passed':True,
     'input_math_sha256':{p.name:math_digest(p) for p in [jpath,HERE/'minimality_dual_certificate.json',HERE/'adapted_equations.json']}}
HERE.joinpath('independent_minimality_audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

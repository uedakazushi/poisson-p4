"""Minimal homogeneous equation count for the exact v11 initial ideal J."""
from pathlib import Path
import sys,json
import sympy as s
HERE=Path(__file__).resolve().parent
BASE=next(p/n for p in [HERE,*HERE.parents] for n in ['previous_v11','p4_poisson_completeness_v11'] if (p/n/'code/zero_jets/zero_initial_algebra.json').is_file())
sys.path.insert(0,str(BASE/'code/zero_jets'))
from zero_full_jet import mon
from full_kuranishi import rref
vs=s.symbols('a b p c d q');jdata=json.loads((BASE/'code/zero_jets/zero_initial_algebra.json').read_text());gens=[s.sympify(f,locals=dict(zip(map(str,vs),vs))) for f in jdata['nice_exact_generators']]
reports=[]
for degree in range(2,6):
 keys=mon(6,degree);ki={m:i for i,m in enumerate(keys)}
 rows=[];multrows=[]
 for f in gens:
  deg=s.Poly(f,*vs).total_degree()
  if deg>degree:continue
  for mult in mon(6,degree-deg):
   row=s.zeros(1,len(keys))
   for m,co in s.Poly(f,*vs).terms():row[ki[tuple(x+y for x,y in zip(m,mult))]]=co
   rows.append(row)
   if degree>deg:multrows.append(row)
 r=len(rref(s.Matrix.vstack(*rows))[1]); rm=len(rref(s.Matrix.vstack(*multrows))[1]) if multrows else 0
 reports.append({'degree':degree,'ideal_dimension':r,'mI_dimension':rm,'new_minimal_generators':r-rm})
assert [x['new_minimal_generators'] for x in reports]==[4,5,1,4]
result={'minimal_number_of_generators':14,'degrees':[2,2,2,2,3,3,3,3,3,4,5,5,5,5],'per_degree':reports,'all_passed':True}
HERE.joinpath('homogeneous_relation_count.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

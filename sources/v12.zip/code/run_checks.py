#!/usr/bin/env python3
"""Reproduce all v12 mathematical certificates in an isolated working tree.

Checks compare every JSON field, except elapsed-time measurements. Preserved
v11 inputs and the delivered source files are not modified by the tests.
"""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, time

ROOT=Path(__file__).resolve().parent.parent
TIMING={'seconds','elapsed','elapsed_seconds','execution_seconds'}

def mathematical(obj):
    if isinstance(obj,dict):return {k:mathematical(v) for k,v in obj.items() if k not in TIMING}
    if isinstance(obj,list):return [mathematical(v) for v in obj]
    return obj

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--include-sixth-order',action='store_true',
                        help='Optional already-recorded sixth-order consistency check')
    args=parser.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    jobs=[
      ('minimal_relations','exact/minimal_equations.py',['5'],['exact/minimal_equations_5.json']),
      ('adapted_formal_generators','exact/adapted_equations.py',[],['exact/adapted_equations.json']),
      ('homogeneous_relation_number','exact/homogeneous_relation_count.py',[],['exact/homogeneous_relation_count.json']),
      ('complete_slice_definition','exact/slice_definition.py',[],['exact/slice_definition.json']),
      ('independent_rational_minimality','exact/independent_minimality_audit.py',[],['exact/independent_minimality_audit.json']),
      ('exact_positive_curves','gluing/positive_branches.py',[],['gluing/positive_branches.json']),
      ('reduced_ring_and_intersections','gluing/reduced_normal_form.py',[],['gluing/reduced_normal_form.json']),
      ('reduced_tangent_cone','gluing/reduced_tangent_cone.py',[],['gluing/reduced_tangent_cone.json']),
      ('nil_module_algebra','nil/verify_nil_initial.py',[],['nil/verify_nil_initial.json']),
      ('independent_combined_audit','independent/audit_v12.py',[],['independent/audit_v12.json']),
    ]
    if args.include_sixth_order:
        jobs.append(('sixth_order_consistency','exact/minimal_equations.py',['6'],['exact/minimal_equations_6.json']))
    reports=[];start=time.time()
    with tempfile.TemporaryDirectory(prefix='p4_v12_reproduce_') as temp:
        tmp=Path(temp)
        shutil.copytree(ROOT/'code',tmp/'code',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        shutil.copytree(ROOT/'previous_v11'/'code',tmp/'previous_v11'/'code',
                        ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        shutil.copyfile(ROOT/'previous_v11'/'HANDOFF.txt',tmp/'previous_v11'/'HANDOFF.txt')
        env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
        for name,script,argv,outputs in jobs:
            tick=time.time()
            p=subprocess.run([sys.executable,str(tmp/'code'/script),*argv],cwd=tmp,
                             env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
            (out/f'{name}.log').write_text(p.stdout)
            if p.returncode:raise RuntimeError(f'{name} failed, see {out/name}.log')
            comparisons=[]
            for rel in outputs:
                expected=json.loads((ROOT/'code'/rel).read_text())
                result=json.loads((tmp/'code'/rel).read_text())
                if mathematical(expected)!=mathematical(result):
                    (out/(name+'_mismatch.json')).write_text(json.dumps({
                        'file':rel,'expected':mathematical(expected),'obtained':mathematical(result)},indent=2)+'\n')
                    raise AssertionError(f'Mathematical output differs: {rel}')
                dest=out/'outputs'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
                shutil.copyfile(tmp/'code'/rel,dest)
                comparisons.append({'file':rel,'mathematical_json_equal':True})
            report={'name':name,'script':script,'passed':True,'returncode':0,
                    'comparisons':comparisons,'seconds':time.time()-tick}
            reports.append(report)
            print(name,'PASS',round(report['seconds'],3),flush=True)
    record={'all_passed':True,'count':len(reports),'checks':reports,
            'seconds':time.time()-start,'python':sys.version,
            'source_code_sha256':{str(p.relative_to(ROOT/'code')):hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in sorted((ROOT/'code').rglob('*.py'))}}
    (out/'verification_summary.json').write_text(json.dumps(record,indent=2)+'\n')
    print('ALL',len(reports),'CHECKS PASSED',round(record['seconds'],3),flush=True)

if __name__=='__main__':main()

from pathlib import Path
import sys,json,ast
import sympy as s
# Works both in the research workspace and in the versioned source archive.
BASE=next(candidate for parent in Path(__file__).resolve().parents
          for candidate in (parent/'previous_v11',parent/'p4_poisson_completeness_v11')
          if (candidate/'HANDOFF.txt').is_file())
sys.path.insert(0,str(BASE/'code'/'zero_jets'))
from zero_full_jet import setup
from full_kuranishi import actual,rref,inverse
sl=setup();C=sl.C
P0=sl.P;M0=C.as_matrix(P0)
C.pol=lambda f:{m:v for m,v in s.Poly(s.expand(f),*C.x).terms() if v}
t,x,y,z,w=C.x
k=s.symbols('k')
Aall=actual(C,P0);_,inds=rref(Aall)
assert Aall[:,inds]==sl.A
All=s.Matrix.hstack(sl.A,*sl.Rv,sl.W)
Bi=inverse(All)
ref=json.loads((BASE/'code'/'geometry'/'reference.json').read_text())
cn=json.loads((BASE/'code'/'geometry'/'zero_magnetic_confluence.json').read_text())
def read(dic):
    return C.tensor({tuple(ast.literal_eval(I)):s.sympify(f,locals=dict(zip(['t','x','y','z','w'],C.x))|{'k':k,'c':s.S.Zero,'d':s.S.Zero}) for I,f in dic.items()})
outputs={}
Xtor=s.Matrix([0,0,y,0,w])
for tag in ['T16','T18','T20']:
    dic=ref['zero']['universal_magnetic_T16_family'] if tag=='T16' else cn['families'][tag]['family']
    FM=C.as_matrix(read(dic))
    F1=C.tensor({I:s.diff(FM[I],k).subs(k,0) for I in C.pairs})
    F2=C.tensor({I:s.diff(FM[I],k,2).subs(k,0)/2 for I in C.pairs})
    co=Bi*C.vector(F1)
    assert co[52:,:]==s.zeros(98,1)
    X=s.zeros(5,1);scale=s.S.Zero;V=s.zeros(150,1)
    for j,orig in enumerate(inds):
        coeff=co[j]
        if orig<25:V+=coeff*Aall[:,orig]
        elif orig<50:
            u,v=divmod(orig-25,5)
            X[u]+=coeff*C.x[v]
        else:scale+=coeff
    assert C.vector(C.lie(P0,X))+scale*C.vector(P0)+V==sl.A*co[:46,:]
    second=C.vector(F2)-C.vector(C.lie(F1,X))-scale*C.vector(F1)+C.vector(C.lie(C.lie(P0,X),X))/2+scale*C.vector(C.lie(P0,X))+scale**2*C.vector(P0)/2
    co2=Bi*second
    one=list(co[46:52]);two=list(co2[46:52])
    coord=[s.factor(one[i]*k+two[i]*k*k) for i in range(6)]
    a,b,p,c,d,q=coord;L=a+b;P=s.factor(p+s.Rational(4,3)*L*L);Q=s.factor(q+8*L*(a-11*b))
    assert s.expand((14*a-b)*P+3*L*Q)==0
    assert s.expand(P*(3*P+Q+15*b*L))==0
    # Exact gauge: X has nilpotent linear matrix, so its flow is I+kX'.
    G=s.eye(5)+k*X.jacobian(C.x)
    assert X.jacobian(C.x)**2==s.zeros(5)
    sub=dict(zip(C.x,G.inv()*s.Matrix(C.x)))
    transformed=(G*FM*G.T).subs(sub,simultaneous=True).applyfunc(s.expand)
    vc=C.vector(C.tensor({I:transformed[I]-M0[I] for I in C.pairs}))
    exact=Bi*vc
    assert [s.expand(u) for u in exact[46:52]]==[s.expand(u) for u in coord]
    for j,orig in enumerate(inds):
        if orig>=25: assert s.expand(exact[j])==0
    # Remove only Euler-vertical terms; all projective coordinates now lie exactly
    # in the fixed full affine slice P0+R*u+W*w.
    vertical=sl.A*exact[:46,:]
    final=vc-vertical
    assert final==sum((sl.Rv[i]*coord[i] for i in range(6)),s.zeros(150,1))+sl.W*exact[52:,:]
    gauged=C.tensor({I:transformed[I]-C.as_matrix(C.from_vector(vertical))[I] for I in C.pairs})
    assert not any(C.euler_vector(C.jacobi(gauged)))
    # Exact equivariance of original family and of final slice coordinates.
    for j in range(1,1+max(s.degree(f,k) for f in FM if f)):
        Fcoef=C.tensor({I:s.expand(FM[I]).coeff(k,j) for I in C.pairs})
        assert C.vector(C.lie(Fcoef,Xtor))+C.vector(Fcoef)==j*C.vector(Fcoef)
    outputs[tag]={'exact_gauge_to_full_slice':True,'gauge_only_vertical_remaining':True,'gauge_matrix':[[str(e) for e in row] for row in G.tolist()],'exact_slice_tensor':C.encode(gauged),'first_normal':list(map(str,one)),'second_normal':list(map(str,two)),'coordinate':list(map(str,coord)),'P':str(P),'Q':str(Q),'L':str(L),'gauge_X':list(map(str,X)),'gauge_scale':str(scale)}
    print(tag,outputs[tag],flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(outputs,indent=2)+'\n')

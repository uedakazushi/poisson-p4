"""Exact graded algebra for the all-order tangent cone of B_red.

The all-order comparison is proved in reduced_normal_form_proof.txt.
"""
from pathlib import Path
import sys,json,time,itertools
import sympy as s
# Works both in the research workspace and in the versioned source archive.
BASE=next(candidate for parent in Path(__file__).resolve().parents
          for candidate in (parent/'previous_v11',parent/'p4_poisson_completeness_v11')
          if (candidate/'HANDOFF.txt').is_file())
sys.path.insert(0,str(BASE/'code'/'zero_jets'))
from zero_initial_algebra import read_j,vs,minimal_mons,numerator,generic_length
start=time.time()
a,b,p,c,d,q=vs;L=a+b;F=(14*a-b)*p+3*L*q
J=read_j()
JR=[F,p*(3*p+q),c*p,c*q,c*L*(4*a+b)*(8*a+5*b),d*L,d*p,d*q]
def GB(A):return s.groebner(A,*vs,domain=s.QQ,order='grevlex')
def equality(A,B):
 GA=GB(A);GBB=GB(B)
 assert all(GA.reduce(f)[1]==0 for f in B)
 assert all(GBB.reduce(f)[1]==0 for f in A)
 return True
assert equality(J+[d*L,d*p,d*q],JR)
z=s.Symbol('z')
def inter(A,B):
 g=s.groebner([z*f for f in A]+[(1-z)*f for f in B],z,*vs,domain=s.QQ,order='lex')
 return [f.as_expr() for f in g.polys if not f.as_expr().has(z)]
primary={
 'Q16':[p,q,L],
 'Qshared':[c,d,F,p*p,p*q,q*q],
 'Q18':[p,q,d,8*a+5*b],
 'Q20':[p,q,d,4*a+b],
 'Q22':[c,d,p,L],
 'Q25prime':[c,d,q+3*p,a-2*b],
}
A=None
for Q in primary.values():A=Q if A is None else inter(A,Q)
assert equality(A,JR)
t=s.Symbol('t')
def HS(A):
 g=GB(A);lm=minimal_mons([tuple(f.LM(order=g.order).exponents) for f in g.polys])
 co=numerator(lm,6)
 return s.cancel(sum(t**j*v for j,v in co.items())/(1-t)**6)
hred=HS(JR);hfull=HS(J);hN=s.cancel(hfull-hred)
hkernel=s.cancel(hred-1/(1-t)**3)
hf=lambda h:[int(s.expand(s.series(h,t,0,16).removeO()).coeff(t,i)) for i in range(16)]
shared=generic_length(JR,'shared plane',{},(p,q,c,d),(a,b),1)
assert shared['generic_length']==2
# Its local generic algebra has a single square-zero normal coordinate.
Ffield=s.QQ.frac_field(a,b)
g=s.groebner(JR,p,q,c,d,domain=Ffield,order='lex')
assert g.reduce(p*p)[1]==0 and g.reduce(q*q)[1]==0
assert g.reduce(q)[1]!=0
out={'scope':'All-order associated graded ring of the reduced transverse completion, established by actual reduced normal form + multiplicity comparison','Jred_generators':[str(s.factor(f)) for f in JR], 'six_primary_components':{k:list(map(str,v)) for k,v in primary.items()},'six_primary_intersection_verified':True,'Hilbert_series_Bred':str(s.factor(hred)),'Hilbert_function_Bred_0_to_15':hf(hred),'Hilbert_series_gr_nilradical':str(s.factor(hN)),'Hilbert_series_kernel_to_T16':str(s.factor(hkernel)),'multiplicity_kernel_to_T16':str(s.limit((1-t)**2*hkernel,t,1)),'shared_plane_generic':shared,'all_passed':True,'elapsed_seconds':time.time()-start}
assert out['multiplicity_kernel_to_T16']=='6'
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['six_primary_components','shared_plane_generic']},indent=2))

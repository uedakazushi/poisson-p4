"""Exact algebra of the six-prime formal reduced normal form.

The simultaneous straightening is justified in reduced_normal_form_proof.txt;
this script verifies the polynomial primes and every pairwise intersection.
"""
from pathlib import Path
import itertools,json,time
import sympy as s
start=time.time()
a,b,p,c,d,q,z=s.symbols('a b p c d q z')
vs=(a,b,p,c,d,q)
L=a+b
P=p+s.Rational(4,3)*L**2
Q=q+8*L*(a-11*b)
H=3*P+Q+15*b*L
primes={
 'T16':[L,p,q-9*b*b],
 'T18':[d,8*a+5*b,p+s.Rational(3,16)*b*b,q-s.Rational(279,8)*b*b],
 'T20':[d,4*a+b,p+3*b*b,q-63*b*b],
 'T22':[c,d,P,L],
 'T24':[c,d,P,Q],
 'T25':[c,d,H,(a-2*b)*P-9*b*L*L],
}
def gb(fs,vars=vs):return s.groebner(fs,*vars,domain=s.QQ,order='grevlex')
def equal(A,B):
 ga=gb(A);gB=gb(B)
 assert all(ga.reduce(f)[1]==0 for f in B)
 assert all(gB.reduce(f)[1]==0 for f in A)
 return True
def inter(A,B):
 g=s.groebner([z*f for f in A]+[(1-z)*f for f in B],z,*vs,domain=s.QQ,order='lex')
 return [f.as_expr() for f in g.polys if not f.as_expr().has(z)]
mag=[a,b,p,q,d]
C16=[c,d,L,p,q-9*b*b]
C18=[c,d,8*a+5*b,P,Q]
C20=[c,d,4*a+b,P+s.Rational(9,4)*b*b,Q+s.Rational(9,2)*b*b]
line=[c,d,L,P,Q]
point=list(vs)
# For double points, all quadratic corrections die modulo b².
def dual(slope):return [c,d,a-slope*b,p,q,b*b]
expect={
 ('T16','T18'):('smooth magnetic c-axis',mag),
 ('T16','T20'):('smooth magnetic c-axis',mag),
 ('T16','T22'):('smooth C16 curve',C16),
 ('T16','T24'):('dual-number point length2',dual(-1)),
 ('T16','T25'):('dual-number point length2',dual(-1)),
 ('T18','T20'):('smooth magnetic c-axis',mag),
 ('T18','T22'):('reduced point length1',point),
 ('T18','T24'):('smooth C18 curve',C18),
 ('T18','T25'):('dual-number point length2',dual(-s.Rational(5,8))),
 ('T20','T22'):('reduced point length1',point),
 ('T20','T24'):('dual-number point length2',dual(-s.Rational(1,4))),
 ('T20','T25'):('smooth C20 curve',C20),
 ('T22','T24'):('smooth common positive line',line),
 ('T22','T25'):('smooth common positive line',line),
 ('T24','T25'):('reduced nodal curve', [c,d,P,Q,b*L]),
}
result={'scope':'Full reduced transverse completed local ring after an explicitly proved equivariant formal change of coordinates; polynomial calculations over QQ','primes':{k:[str(s.factor(f)) for f in fs] for k,fs in primes.items()},'pairs':{},'all_passed':True}
for pair in itertools.combinations(primes,2):
 name,want=expect[pair]
 assert equal(primes[pair[0]]+primes[pair[1]],want)
 result['pairs']['_'.join(pair)]={'type':name,'ideal':[str(f) for f in want],'equality_verified':True}
 print(pair,name,flush=True)
red=None
for tag,ideal in primes.items():
 red=ideal if red is None else inter(red,ideal)
 print('INTERSECTION',tag,'generators',len(red),time.time()-start,flush=True)
result['reduced_ideal_generators']=[str(s.factor(f)) for f in red]
for tag,ideal in primes.items():
 assert all(gb(ideal).reduce(f)[1]==0 for f in red)
# A2 exact coordinate substitution X=a-2b, Y=P-9bX-54b².
X,Y=s.symbols('X Y')
assert s.expand(((a-2*b)*P-9*b*L*L).subs({a:X+2*b,p:Y+9*b*X+54*b*b-s.Rational(4,3)*(X+3*b)**2}))==X*Y-81*b**3
result['A2_coordinate_identity']=True
result['elapsed_seconds']=time.time()-start
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print('DONE',time.time()-start,flush=True)

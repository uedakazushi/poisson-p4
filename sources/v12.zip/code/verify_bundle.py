#!/usr/bin/env python3
"""Verify every delivered byte and every unchanged previous-v11 file."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    manifest=json.loads((ROOT/'manifest.json').read_text())
    actual={str(p.relative_to(ROOT)) for p in ROOT.rglob('*')
            if p.is_file() and p!=ROOT/'manifest.json'}
    assert actual==set(manifest['files'])
    for name,digest in manifest['files'].items():assert sha(ROOT/name)==digest,name
    old=json.loads((ROOT/'data/previous_v11_preservation.json').read_text())
    for name,digest in old['files'].items():assert sha(ROOT/'previous_v11'/name)==digest,name
    print(json.dumps({'all_passed':True,'verified_files':len(actual),
                      'previous_v11_files_unchanged':len(old['files'])},indent=2))
if __name__=='__main__':main()

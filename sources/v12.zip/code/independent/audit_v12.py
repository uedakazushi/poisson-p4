"""Independent exact checks for v12; no author calculus or slice imports.

Rebuilds the minimal relation quotient directly from all 350 residual jets,
checks the three exact polynomial curves by direct Schouten/Euler formulas,
and verifies the nil quotient multiplication and the fourth-power coefficient.
The all-order arguments are in the accompanying proofs, not inferred from jets.
"""
from pathlib import Path
from itertools import combinations, combinations_with_replacement
import ast, json, time, hashlib
import sympy as s
from sympy.polys.matrices import DomainMatrix

START=time.time()
ROOT=Path(__file__).resolve().parents[2]
OLD=ROOT/'previous_v11'
u=s.symbols('a b p c d q'); a,b,p,c,d,q=u

def monos(n,degree):
    return sorted(tuple(t.count(j) for j in range(n))
                  for t in combinations_with_replacement(range(n),degree))

def echelon(M):
    A,cols=DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()
    return A.to_Matrix(),list(cols)

def truncate(f,degree=5):
    return s.Poly.from_dict({m:v for m,v in s.Poly(s.expand(f),*u).terms()
                            if sum(m)<=degree},u).as_expr()

def relation_audit():
    source=OLD/'code/zero_jets/zero_jet_5.json'
    data=json.loads(source.read_text())
    keys=[m for n in range(2,6) for m in monos(6,n)]
    index={m:i for i,m in enumerate(keys)}
    entries={}
    for level in data['residuals']:
        for i,j,v in level['entries']:
            entries[i,index[tuple(level['monomials'][j])]]=s.Rational(v)
    M=s.MutableSparseMatrix(350,len(keys),entries)
    E,piv=echelon(M); E=E[:len(piv),:]
    multiples=[]
    for row in E.tolist():
        nz=[(keys[j],v) for j,v in enumerate(row) if v]
        for degree in range(1,4):
            for mm in monos(6,degree):
                shifted={index[tuple(x+y for x,y in zip(m,mm))]:v
                         for m,v in nz if sum(m)+degree<=5}
                if shifted:multiples.append(shifted)
    MM=s.MutableSparseMatrix(len(multiples),len(keys),
           {(i,j):v for i,row in enumerate(multiples) for j,v in row.items()})
    EM,pm=echelon(MM); EM=EM[:len(pm),:]
    EI,pi=echelon(EM.col_join(M)); EI=EI[:len(pi),:]
    _,selected=echelon(EM.T.row_join(M.T))
    rows=[k-EM.rows for k in selected if k>=EM.rows]
    assert (EM.rows,EI.rows)==(286,297)
    assert rows==[24,25,29,43,95,97,113,115,116,128,140]
    filtered=[]
    for degree in range(2,6):
        high=EI[[i for i,j in enumerate(pi) if sum(keys[j])>=degree],:]
        _,cc=echelon(EM.col_join(high))
        filtered.append(len(cc)-EM.rows)
    assert filtered==[11,7,2,2]
    adapted=json.loads((ROOT/'code/exact/adapted_equations.json').read_text())
    residual=[sum(v*s.prod(x**e for x,e in zip(u,keys[j]))
                  for j,v in enumerate(M.row(i)) if v) for i in rows]
    dictionary=dict(zip(map(str,u),u))
    for leading,jet,coeffs in zip(adapted['standard_basis_leading_forms'],
                      adapted['lifted_standard_basis_through_degree5'],
                      adapted['polynomial_multipliers_of_raw_generators']):
        value=truncate(sum(s.sympify(k,locals=dictionary)*f
                           for k,f in zip(coeffs,residual)))
        assert s.expand(value-s.sympify(jet,locals=dictionary))==0
        poly=s.Poly(value,*u); order=min(sum(m) for m,v in poly.terms())
        initial=sum(v*s.prod(x**e for x,e in zip(u,m))
                    for m,v in poly.terms() if sum(m)==order)
        assert s.expand(initial-s.sympify(leading,locals=dictionary))==0
    return {'I_5_rank':EI.rows,'mI_5_rank':EM.rows,'minimal_relations':11,
            'selected_full_residual_rows':rows,
            'relation_filtration_dimensions':filtered,
            'all_fourteen_polynomial_lift_identities_checked':True}

def curve_audit():
    definition=json.loads((ROOT/'code/exact/slice_definition.json').read_text())
    curves=json.loads((ROOT/'code/gluing/positive_branches.json').read_text())
    x=s.symbols('t x y z w'); k=s.Symbol('k')
    names=dict(zip(map(str,x),x))|{'k':k}
    pairs=list(combinations(range(5),2))
    triples=list(combinations(range(5),3))
    quadruples=list(combinations(range(5),4))
    def read(dic):
        P=s.zeros(5)
        for label,value in dic.items():
            i,j=ast.literal_eval(label);P[i,j]=s.sympify(value,locals=names)
            P[j,i]=-P[i,j]
        return P
    P0=read(definition['P0']); normals=[read(v) for v in definition['normal_basis']]
    forbidden=set(range(150))-set(definition['implicit_coefficient_columns'])
    reports={}
    for tag,record in curves.items():
        P=read(record['exact_slice_tensor'])
        co=[s.sympify(v,locals=names) for v in record['coordinate']]
        remainder=P-P0-sum((v*N for v,N in zip(co,normals)),s.zeros(5))
        for col in forbidden:
            pair,exponents=definition['coefficient_basis_order'][col]
            assert s.Poly(s.expand(remainder[tuple(pair)]),*x).coeff_monomial(tuple(exponents))==0
        jac={}
        for i,j,l in triples:
            jac[i,j,l]=s.expand(sum(P[i,h]*s.diff(P[j,l],x[h])+
                         P[j,h]*s.diff(P[l,i],x[h])+
                         P[l,h]*s.diff(P[i,j],x[h]) for h in range(5)))
        for inds in quadruples:
            value=s.expand(sum((-1)**j*x[inds[j]]*jac[inds[:j]+inds[j+1:]]
                               for j in range(4)))
            assert value==0
        assert co[3]==co[4]==0
        reports[tag]={'exact_full_350_projective_coefficients_zero':True,
                      'exact_membership_in_fixed_implicit_slice':True,
                      'normal_coordinates':list(map(str,co))}
    return reports

def nil_audit():
    L=a+b; F=(14*a-b)*p+3*L*q
    J=[F,p*(3*p+q),c*p,c*q,b*d*p,a*d*q,b*d*q,d*p*q,d*q*q,
       c*L*(4*a+b)*(8*a+5*b),
       d*L*(11776*a**3-11776*a*a*b+11776*a*b*b+21333*b**3),
       b*d*L*(184*a*a-184*a*b-233*b*b),
       b*b*d*L*(184*a+127*b),b*c*d*L*(2*a+b)]
    G=s.groebner(J,*u,domain=s.QQ,order='grevlex')
    rho=s.Rational(1323,11776)
    assert G.reduce(d*L**4-rho*b**3*d*L)[1]==0
    assert G.reduce(b**3*d*L)[1]!=0
    K=s.groebner([32*a*a-9*b*b,2*a*b+b*b],a,b,domain=s.QQ)
    basis=[s.S.One,a,b,b*b]
    def product(v,w):
        # e_i=f_i*n; n^2=d*(a+b)*n.
        return s.expand(d*K.reduce(s.expand((a+b)*v*w))[1])
    table=[[product(v,w) for w in basis] for v in basis]
    expected=[[d*(a+b),-s.Rational(7,32)*d*b*b,d*b*b/2,0],
              [-s.Rational(7,32)*d*b*b,0,0,0],
              [d*b*b/2,0,0,0],[0,0,0,0]]
    assert all(s.expand(table[i][j]-expected[i][j])==0 for i in range(4) for j in range(4))
    # Verify associativity over QQ[d] directly; avoid fractional-field sampling.
    KD=s.groebner([32*a*a-9*b*b,2*a*b+b*b],a,b,domain=s.QQ.poly_ring(d))
    mult=lambda v,w:s.expand(KD.reduce(s.expand(d*(a+b)*v*w))[1])
    for v in basis:
        for w in basis:
            for z in basis:assert s.expand(mult(mult(v,w),z)-mult(v,mult(w,z)))==0
    cube=mult(mult(1,1),1)
    assert s.expand(cube-s.Rational(9,32)*d*d*b*b)==0
    assert mult(cube,1)==0
    return {'quotient_multiplication_table':[[str(s.expand(e)) for e in row] for row in table],
            'associativity_verified':True,'nil_quotient_cube_coefficient':'9/32',
            'fourth_power_axis_coefficient':str(rho),
            'graded_axis_generator_nonzero':True}

if __name__=='__main__':
    out={'scope':'Independent finite algebra and exact polynomial identities; all-order deductions require the accompanying proofs.',
         'minimal_presentation':relation_audit(),
         'exact_positive_curves':curve_audit(),
         'nil_multiplication':nil_audit(),
         'all_passed':True,'seconds':time.time()-START}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({'all_passed':True,'seconds':out['seconds'],
                      'minimal_relations':11,'exact_positive_curves':3,
                      'nil_fourth_power_coefficient':'1323/11776'},indent=2))

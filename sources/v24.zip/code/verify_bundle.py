"""Read-only SHA256 verification of this edition and the immutable v23 snapshot."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]

def verify(root):
    count=0;listed=set()
    for line in (root/'SHA256SUMS.txt').read_text().splitlines():
        want,name=line.split('  ',1)
        path=root/name
        assert path.is_file(),name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==want,name
        listed.add(name);count+=1
    actual={str(p.relative_to(root)) for p in root.rglob('*')
            if p.is_file() and '__pycache__' not in p.parts}
    assert actual==listed|{'SHA256SUMS.txt'},sorted(actual^listed^{'SHA256SUMS.txt'})
    return count

if __name__=='__main__':
    current=verify(ROOT);old=verify(ROOT/'previous_v23')
    assert old==1833
    assert (ROOT/'previous_v23.pdf').read_bytes()==(ROOT/'previous_v23/p4_poisson_completeness_v23.pdf').read_bytes()
    print(json.dumps({'all_passed':True,'current_manifest_entries':current,
                      'previous_v23_files_preserved':old+1},indent=2))

"""Small v24 certificates, independently checked with Python's stdlib only."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
import json
import audit_tangent_stdlib as p

ROOT = Path(__file__).resolve().parents[1]

def audit():
    checks = []
    def ck(value, label):
        assert value, label
        checks.append(label)
    pairs = list(combinations(range(5), 2))
    Q = p.matrix({'14':'x0**2', '23':'-2*x0**2/9',
                  '24':'4*x0*x1/3', '34':'2*x0*x2/3+x1**2'})
    RA = p.matrix({'04':'-2*x0*x1/5', '14':'3*x1**2/5',
                   '24':'-2*x1*x2/5', '34':'-2*x1*x3/5'})
    RB = p.matrix({'04':'-4*x0*x1/5', '14':'x1**2/5', '23':'-2*x1**2/9',
                   '24':'x1*x2/5', '34':'x1*x3/5'})
    R = p.matrix({'12':'24*x0*x4', '13':'18*x1*x4',
                  '23':'-16*x2*x4', '34':'x4**2'})
    source = json.loads((ROOT/'proofs/base/endpoint_full_tangent.json').read_text())
    ck(Q == p.matrix(source['P_entries']), 'literal_Q_matches_published_endpoint')
    ck(R == p.matrix(source['transverse_P_entries'][33]), 'literal_R_is_transverse_R33')

    def plus(A, B):
        return [[p.add(A[i][j], B[i][j]) for j in range(5)] for i in range(5)]
    def div(A):
        return [p.sum_polys(p.deriv(A[i][j], i) for i in range(5)) for j in range(5)]
    def quintic(A):
        result = {}
        for e in range(5):
            i,j,k,l = [q for q in range(5) if q != e]
            pf = p.sum_polys([p.mul(A[i][j],A[k][l]),
                             p.scale(p.mul(A[i][k],A[j][l]),-1),
                             p.mul(A[i][l],A[j][k])])
            result = p.add(result, p.scale(p.mul(p.XS[e],pf), F((-1)**e,5)))
        return result
    for name, A in [('Q',Q),('RA',RA),('RB',RB),('R33',R)]:
        ck(all(not f for f in div(A)), name+'_canonical')
    ck(all(not f for f in p.lie(Q,Q).values()), 'Q_Poisson')
    ck(quintic(Q) == p.parse('-2*x0**5/45'), 'Q_actual_quintic')
    for name, S, cross, square in [
        ('A',RA,'-2*x0**3*x1**2/45','0'),
        ('B',RB,'-4*x0**3*x1**2/45','-2*x0*x1**4/45')]:
        ck(all(not f for f in p.lie(Q,S).values()), name+'_compatible_with_Q')
        ck(all(not f for f in p.lie(S,S).values()), name+'_direction_Poisson')
        linear = p.sum_polys([quintic(plus(Q,S)),p.scale(quintic(Q),-1),p.scale(quintic(S),-1)])
        ck(linear == p.parse(cross), name+'_quintic_linear_term')
        ck(quintic(S) == p.parse(square), name+'_quintic_quadratic_term')

    ck(all(not f for f in p.lie(Q,R).values()), 'R33_is_full_first_order_deformation')
    JR = {ijk:p.scale(f,F(1,2)) for ijk,f in p.lie(R,R).items()}
    mon = (1,0,0,0,2)
    ck(JR[(1,2,3)] == {mon:F(72)} and all(not f for ijk,f in JR.items() if ijk != (1,2,3)),
       'R33_Jacobi_has_exactly_one_coefficient_72')
    def ell(T):
        return T[(1,2,3)].get(mon,F(0))-T[(0,2,4)].get(mon,F(0))/3
    for column, ((i,j), m) in enumerate((ij,m) for ij in pairs for m in p.basis_monomials(2)):
        S = [[{} for j in range(5)] for i in range(5)]
        S[i][j] = {m:F(1)}; S[j][i] = {m:F(-1)}
        ck(ell(p.lie(Q,S)) == 0, 'ell_annihilates_raw_column_'+str(column))
    ck(ell(JR) == 72, 'nonzero_second_order_obstruction')

    def dehom(f):
        out = {}
        for m,c in f.items():
            mm = (0,)+m[1:]
            out[mm] = out.get(mm,F(0))+c
        return p.clean(out)
    QA = [[dehom(Q[i][j]) for j in range(5)] for i in range(5)]
    dar = [p.parse(f) for f in ['x1','x2','x3','x4+6*x1*x3-3*x2**2/2-9*x1**2*x2/2']]
    def bracket(f,g):
        return p.sum_polys(p.mul(p.mul(p.deriv(f,i),QA[i][j]),p.deriv(g,j))
                           for i in range(1,5) for j in range(1,5))
    for i,j in combinations(range(4),2):
        want = {p.Z:F(1)} if (i,j)==(0,3) else {p.Z:F(-2,9)} if (i,j)==(1,2) else {}
        ck(bracket(dar[i],dar[j]) == want, 'Darboux_bracket_'+str(i)+str(j))
    return {'all_passed':True,'check_count':len(checks),'checks':checks,
            'method':'Independent literal matrices; stdlib Fraction polynomial arithmetic; all150 raw correction columns.'}

if __name__ == '__main__':
    print(json.dumps(audit(),indent=2))

"""Audit the frozen v24 package without modifying its files or older editions."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse, json, os, shutil, subprocess, sys, tempfile, time

ROOT=Path(__file__).resolve().parents[1]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',type=Path)
    args=ap.parse_args()
    start=time.monotonic()
    env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
    tasks=[('components','ambient_incidence.py','ambient_incidence.json'),
           ('geometry','verify_endpoint_geometry.py','endpoint_geometry_certificate.json'),
           ('geometry','verify_family_zero_scheme.py','family_zero_scheme_certificate.json'),
           ('obstructions','verify_obstructions.py','verification.json')]
    def run_task(index, task, tmp):
        group,script,report=task
        dest=Path(tmp)/str(index)
        shutil.copytree(ROOT/'proofs'/group,dest,ignore=shutil.ignore_patterns('__pycache__'))
        p=subprocess.run([sys.executable,str(dest/script)],cwd=dest,env=env,text=True,capture_output=True)
        if p.returncode:
            raise RuntimeError(script+' failed\n'+p.stdout+'\n'+p.stderr)
        data=json.loads((dest/report).read_text())
        assert data['all_passed'],script
        return script,data
    results={}
    with tempfile.TemporaryDirectory(prefix='p4_v24_audit_') as tmp:
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures=[pool.submit(run_task,i,task,tmp) for i,task in enumerate(tasks)]
            for fut in as_completed(futures):
                name,data=fut.result();results[name]=data
                print('PASS '+name,flush=True)
    sys.dont_write_bytecode=True
    import audit_short_certificates
    short=audit_short_certificates.audit()
    results['audit_short_certificates.py']=short
    print('PASS audit_short_certificates.py',flush=True)
    # Tie the independently reconstructed family vectors to obstruction inputs.
    comp=results['ambient_incidence.py']
    bi=json.loads((ROOT/'proofs/obstructions/branch_input.json').read_text())
    for typ in ['A','B']:
        assert comp['families'][typ]['family_vector_columns']==bi['family_vector_columns'][typ],typ
    endpoint=(ROOT/'proofs/base/endpoint_full_tangent.json').read_bytes()
    assert endpoint==(ROOT/'proofs/obstructions/endpoint_full_tangent.json').read_bytes()
    assert endpoint==(ROOT/'previous_v23/proofs/ss/endpoint_full_tangent.json').read_bytes()
    link_checks=4
    groups=[]
    for name in [task[1] for task in tasks]+['audit_short_certificates.py']:
        d=results[name]
        count=d.get('check_count',d.get('checks',0))
        assert isinstance(count,int),name
        embedded=sum(a['checks'] for a in d.get('linear_audits',[]))
        groups.append({'script':name,'all_passed':True,'checks':count,
                       'additional_stdlib_linear_checks':embedded})
    summary={'all_passed':True,'groups':groups,'cross_package_checks':link_checks,
             'total_checks':link_checks+sum(g['checks']+g['additional_stdlib_linear_checks'] for g in groups),
             'seconds':round(time.monotonic()-start,3),
             'method':'All validators run on temporary copies; no published source or previous edition is mutated.'}
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()

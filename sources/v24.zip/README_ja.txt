射影4空間の Poisson 構造 — 研究継続 第24版
================================================
2026年10月29日

最初に HANDOFF.txt を読んでください。
目的は複素射影4空間上の Poisson 構造の完全な分類です。
本版は五重超平面を退化因子とする端点の解析を進めた研究ノートです。
全体の分類完了、全5H locusの分類、完成局所環の決定は主張しません。

主な成果
--------
1. v23の端点Qは、既知24次元成分T37と二つの既知28次元成分CA,CBの交点。
   全19パラメータの族とcanonicalなPoisson pencilを明示して実際の所属を証明。
2. CA,CBに共通の16パラメータ磁気族のPGL飽和閉包Mは正確に26次元。
   Qを含み、26 <= dim_Q(CA intersection CB) <= 27。
   交わり全体の次元と尽くしは未決。
3. 軌道を除く34次元の一次変形の全二次障害を計算。
   二次係数行列の階数は53。最低重みの3変数の全二次単項式を含む。
   全150次元の二次補正を許しても延長不能な具体的方向Rを短い式で証明。
4. 端点の全射影安定化群は連結Gm semidirect U7、射影軌道次元16。
5. 零点スキームは四重primary平面＋square-zeroの埋込み直線。
6. 非零五係数族の全PGL同型類はkappa=AE/(CD)で完全に分類される。
   kappa=1/4で全Jacobi接空間が50から51に跳躍。
   kappa=-1では零点スキームがfinite flat degree5のCMなprimary平面になる。
   これらは異なる二つの特殊化。
7. 被約rank<=2部分の8成分の尽くしはv14で完了済み。
   全成分数の既知の下界57=40+6+11を維持。新成分は数えていない。

読むファイル
------------
p4_poisson_completeness_v24.pdf  日本語の証明付き本文
p4_poisson_completeness_v24.tex  LuaLaTeX主ファイル
sections/                      論理順の本文
proofs/components/             二成分への所属と26次元共通族
proofs/geometry/               全安定化群・零スキーム・五係数軌道分類
proofs/obstructions/           全53二次式・34基底・全パラメータ階数証明
code/                         独立監査とbundle検証
data/check_summary.json        全1298項目PASSの集約結果
audits/final_proof_review.json 数学的相互監査と主張の範囲
previous_v23.pdf               前版本文
previous_v23/                  前版配布1834ファイルを変更せず保存

再現手順
--------
Python 3とSymPy 1.14系を使用します。
  python3 -m pip install -r requirements.txt
  python3 code/run_checks.py
  python3 code/verify_bundle.py

run_checks.py は各proofディレクトリを一時領域に複製して実行するため、
配布済み証明書と旧版を変更しません。全5群＋相互照合を約20秒で確認します。
結果ファイルを別に残す場合のみ --output /希望のパス/report.json を指定してください。
標準ライブラリのみの短い検算:
  python3 code/audit_short_certificates.py

LuaLaTeXとluatexja/haranoajiがある環境で:
  lualatex p4_poisson_completeness_v24.tex
  lualatex p4_poisson_completeness_v24.tex
相互参照と目次が安定しない場合のみもう一度実行してください。
書込み可能フォームはありません。

証明書の読み方
--------------
全線形化は150係数、375行（25 divergence＋350 Jacobi）で、階数99。
34個の横断代表、軌道微分、51次元の核、99次正則小行列を含みます。
quadratic_obstructions.jsonのindependent_quadratic_equationsはRREFの53式、
short_basisは元の射影済み行から選んだ53式です。
53という数は二次式の線形包の次元であり、余次元ではありません。
parameter_rank.jsonにはQ(a)上の階数証明と選択小行列式の全零点での証明があります。
有限個のサンプルからの推測ではありません。

必ず保つ区別
------------
成分次元はPGL商を取る前のprojective Poisson schemeの次元です。
表示族の微分像を、成分自体の全Zariski接空間と同一視しません。
零点スキームの冪零構造と、Poisson moduliの局所環の冪零構造は別です。
二次障害の消滅は全高次の延長可能性を意味しません。
五係数族の完全軌道分類を全5H locusの分類へ拡張しません。
既知40という文献の数はSNC locusと交わる成分の数です。

旧版で閉じたrank<=2成分尽くしを再開せず、現在の34変数障害問題と
一般rank4成分の大域的な尽くしを優先してください。

"""Exact universal A/B incidence at the v23 fivefold-hyperplane endpoint.

This verifier is self-contained apart from SymPy.  In particular, every orbit
column is rebuilt from the defining infinitesimal coordinate action; it does
not import tangent certificates, Poisson helper code, or the v6 computation.
"""
from pathlib import Path
from itertools import combinations,combinations_with_replacement
import json
import sympy as s
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent
x=s.symbols('x0:5')
t,a,b,c,d=x
mu=s.Rational(-2,9)
u=s.symbols('u0:3')
hpar=s.symbols('h0:16')
pairs=list(combinations(range(5),2))
def clean(P):return P.applyfunc(s.expand)
def canonical(P):
    D=s.Matrix([sum(s.diff(P[i,j],x[i]) for i in range(5)) for j in range(5)])
    E=s.Matrix(x)
    return clean(P-(E*D.T-D*E.T)/5)
def mat(f,h,kind,mu_coeff=mu):
    P=s.zeros(5)
    P[1,4]=f
    P[2,3]=mu_coeff*(t*t if kind=='A' else f)
    P[2,4]=s.diff(h,c)+(0 if kind=='A' else s.diff(f,a)*b/2)
    P[3,4]=-s.diff(h,b)+(0 if kind=='A' else s.diff(f,a)*c/2)
    return P-P.T
def jac(P):
    return {''.join(map(str,(i,j,k))):s.expand(sum(P[i,l]*s.diff(P[j,k],x[l])+P[j,l]*s.diff(P[k,i],x[l])+P[k,l]*s.diff(P[i,j],x[l]) for l in range(5))) for i,j,k in combinations(range(5),3)}
def quintic(P):
    ans=0
    for e in range(5):
        i,j,k,l=[v for v in range(5) if v!=e]
        ans+=x[e]*(-1)**e*(P[i,j]*P[k,l]-P[i,k]*P[j,l]+P[i,l]*P[j,k])/5
    return s.expand(ans)
mon3=[s.prod(x[i] for i in ind) for ind in combinations_with_replacement(range(4),3) if any(i>=2 for i in ind)]
assert len(mon3)==16
f=sum(v*m for v,m in zip(u,[t*t,t*a,a*a]))
h=sum(v*m for v,m in zip(hpar,mon3))
h0=4*t*a*c/3-t*b*b/3-a*a*b
base={u[0]:1,u[1]:0,u[2]:0}
Hpoly=s.Poly(h0,t,a,b,c)
base.update({v:Hpoly.coeff_monomial(m) for v,m in zip(hpar,mon3)})
Pq=canonical(mat(t*t,h0,'A'))
checks={}
def ck(name,value):
    checks[name]=bool(value)
    assert value,name
mon2=list(combinations_with_replacement(range(5),2))
basis=[{'pair':list(ij),'monomial_exponents':[ind.count(k) for k in range(5)]}
       for ij in pairs for ind in mon2]
def vec(P):
    return s.Matrix([s.Poly(P[i['pair'][0],i['pair'][1]],*x).coeff_monomial(s.prod(x[j]**e for j,e in enumerate(i['monomial_exponents']))) for i in basis])
def rank(M):return len(DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1])
def infinitesimal_action(P,A):
    """Lie derivative along the linear vector field A*x."""
    z=A*s.Matrix(x)
    adv=s.zeros(5)
    for k in range(5):adv+=P.diff(x[k])*z[k]
    return clean(adv-A*P-P*A.T)
orbit=[]
for i in range(5):
    for j in range(5):
        A=s.zeros(5);A[i,j]=1
        orbit.append(vec(infinitesimal_action(Pq,A)))
O=s.Matrix.hstack(*orbit)
OS=O.row_join(vec(Pq))
ck('orbit_linear_rank17',rank(O)==17)
ck('orbit_plus_scale_rank17',rank(OS)==17)
data={}
for kind in ['A','B']:
    raw=mat(f,h,kind);P=canonical(raw)
    ck(kind+'_universal_poisson',all(v==0 for v in jac(P).values()))
    ck(kind+'_universal_canonical',all(s.expand(sum(s.diff(P[i,j],x[i]) for i in range(5)))==0 for j in range(5)))
    expected=mu*t**3*f/5 if kind=='A' else mu*t*f*f/5
    ck(kind+'_universal_actual_quintic',s.expand(quintic(P)-expected)==0)
    ck(kind+'_base_is_Q',clean(P.subs(base)-Pq)==s.zeros(5))
    dirs=[clean(P.diff(v).subs(base)) for v in (*u,*hpar)]
    D=s.Matrix.hstack(*map(vec,dirs))
    full=OS.row_join(D)
    rawpencil=canonical(mat(t*t+s.Symbol('z')*a*a,h0,kind))
    R=clean(rawpencil.diff(s.Symbol('z')))
    ck(kind+'_pencil_tangent_is_u2',R==dirs[2])
    data[kind]={'universal_P_entries':{str(i)+str(j):str(P[i,j]) for i,j in pairs},
                'parameter_directions':[{'parameter':str(v),'entries':{str(i)+str(j):str(W[i,j]) for i,j in pairs}} for v,W in zip((*u,*hpar),dirs)],
                'pencil_direction':{str(i)+str(j):str(R[i,j]) for i,j in pairs},
                'family_differential_rank':rank(D),
                'family_plus_orbit_scale_rank':rank(full),
                'projective_differential_rank':rank(full)-1,
                'family_vector_columns':[[str(v) for v in D[:,j]] for j in range(D.cols)],
                'quintic':str(expected)}
    ck(kind+'_family_differential_rank19',data[kind]['family_differential_rank']==19)
    ck(kind+'_family_orbit_scale_rank28',data[kind]['family_plus_orbit_scale_rank']==28)
DA=s.Matrix.hstack(*[s.Matrix([s.Rational(z) for z in col]) for col in data['A']['family_vector_columns']])
DB=s.Matrix.hstack(*[s.Matrix([s.Rational(z) for z in col]) for col in data['B']['family_vector_columns']])
ra,rb,runion=rank(OS.row_join(DA)),rank(OS.row_join(DB)),rank(OS.row_join(DA).row_join(DB))
inter=ra+rb-runion
ck('joint_affine_span_rank29',runion==29)
ck('affine_differential_intersection_dimension27',inter==27)
DH=DA[:,3:]
common=OS.row_join(DH)
ck('common_actual_magnetic_family_affine_differential_rank27',rank(common)==27)
ck('common_actual_magnetic_family_derivatives_identical',DH==DB[:,3:])
# A 14-dimensional affine coordinate group preserves the common magnetic
# family projectively.  This gives an upper bound 24+16-14=26 for its full
# PGL-saturated image, matching the rank26 lower bound at Q.
gr,g11,g12,g21,g22,gu1,gu2,gal,gbe1,gbe2,gdel,gla,glb,glc=s.symbols(
    'r s11 s12 s21 s22 u1 u2 alpha beta1 beta2 delta ell_a ell_b ell_c')
rho=g11*g22-g12*g21
GM=s.Matrix([[1,0,0,0,0],[gal,gr,0,0,0],
             [gbe1,gu1,g11,g12,0],[gbe2,gu2,g21,g22,0],
             [gdel,gla,glb,glc,rho/gr]])
push=(GM*mat(t*t,h,'A')*GM.T/rho).applyfunc(s.cancel)
ck('common_family_group_determinant',s.cancel(GM.det()-rho**2)==0)
for i,j in [(0,1),(0,2),(0,3),(0,4),(1,2),(1,3)]:
    ck('common_group_preserves_zero_'+str(i)+str(j),push[i,j]==0)
ck('common_group_normalizes_ad',s.cancel(push[1,4]-t*t)==0)
ck('common_group_normalizes_bc',s.cancel(push[2,3]-mu*t*t)==0)
# Derivatives in the new b,c coordinates, at fixed new a,d; the original
# coefficient polynomials are independent of d, so only S^{-1} is needed.
newdiv=(g22*s.diff(push[2,4],b)-g21*s.diff(push[2,4],c)
        -g12*s.diff(push[3,4],b)+g11*s.diff(push[3,4],c))/rho
ck('common_group_remaining_vector_is_Hamiltonian',s.cancel(newdiv)==0)
# The whole nonzero five-coefficient family lies in both components.  Every
# nonzero constant mu is carried to mu=1 by a linear coordinate rescaling.
ga,gb,gc,gd,ge=s.symbols('A B C D E',nonzero=True)
hg=gc*t*a*c-gd*t*b*b/2-ge*a*a*b
Qg=s.zeros(5)
for (i,j),val in {(1,4):ga*t*t,(2,3):gb*t*t,(2,4):gc*t*a,
                  (3,4):gd*t*b+ge*a*a}.items():
    Qg[i,j]=val;Qg[j,i]=-val
ck('all_nonzero_five_coefficients_incident_A',
   clean(canonical(mat(ga*t*t,hg,'A',gb))-Qg)==s.zeros(5))
ck('all_nonzero_five_coefficients_incident_B',
   clean(canonical(mat(ga*t*t,hg,'B',gb/ga))-Qg)==s.zeros(5))
out={'all_passed':all(checks.values()),'checks':checks,'check_count':len(checks),
     'coefficient_basis':basis,
     'orbit_vectors':[[str(v) for v in O[:,j]] for j in range(O.cols)],
     'coordinates':list(map(str,x)),'mu':str(mu),'h0':str(h0),'cubic_monomials':list(map(str,mon3)),
     'parameters':list(map(str,(*u,*hpar))),'base_parameter_values':{str(k):str(v) for k,v in base.items()},
     'Q_entries':{str(i)+str(j):str(Pq[i,j]) for i,j in pairs},'families':data,
     'nonzero_five_coefficient_family_incidence':{
         'h':str(hg),'A_parameters':{'f':'A*x0**2','mu':'B'},
         'B_parameters':{'f':'A*x0**2','mu':'B/A'},
         'assumptions':'A,B,C,D,E nonzero; arbitrary nonzero mu is linearly equivalent to mu=1',
         'scope':'Entire displayed five-coefficient family lies in C_A and C_B; no assertion that T37 contains this entire family.'},
     'joint_differential':{'affine_span_A':ra,'affine_span_B':rb,'affine_union_span':runion,'affine_intersection':inter,
                           'projective_union_span':runion-1,'projective_intersection':inter-1,
                           'quotient_by_projective_orbit':{'A':ra-17,'B':rb-17,'union':runion-17,'intersection':inter-17}},
     'common_actual_magnetic_family':{
         'definition':'A(t^2,h)=B(t^2,h), h arbitrary in the 16-dimensional effective cubic space',
         'affine_differential_with_orbit_and_scale':27,
         'projective_differential_with_orbit':26,
         'transverse_differential':10,
         'preserving_group_dimension':14,
         'preserving_group_matrix':[[str(e) for e in row] for row in GM.tolist()],
         'preserving_group_open_conditions':'r != 0 and det(S) != 0',
         'preserving_group_common_tensor_multiplier':str(rho),
         'full_PGL_saturated_closure_dimension':26,
         'upper_bound_proof':'The free action of the displayed 14-dimensional group on PGL5 times the effective cubic parameter space lies in the fibers; 24+16-14=26.',
         'consequence':'An actual algebraic family in C_A intersection C_B has projective differential rank26 at Q; hence the local intersection dimension is at least26.',
         'scope':'Neither equality for the total intersection dimension nor its scheme structure is claimed.'},
     'scope':'Exact incidence with two previously proved28dim components. Differential images are not asserted to equal component tangent spaces at this special point.'}
(HERE/'ambient_incidence.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k in ['all_passed','check_count','joint_differential']},indent=2))
print(json.dumps({k:{j:v for j,v in z.items() if j in ['pencil_direction','family_differential_rank','projective_differential_rank']} for k,z in data.items()},indent=2))

# Independent mathematical audit of the v24 geometry and obstruction claims

This is a proof audit by the component-incidence agent, independent of the
authoring agents. It is not an assertion that the entire formal local Jacobi
scheme has been classified.

## Geometry and the five-coefficient normal form

I checked the defining equations and arguments in
`geometry/verify_endpoint_geometry.py` and `geometry/endpoint_geometry.tex`.
The substantive conclusions are consistent with the following independent
derivations.

1. **Full PGL necessity for the invariant.** The nonzero quintic
   \(ABt^5/5\) forces any conjugacy between members of the displayed family
   to preserve \(H=(t=0)\), hence to be affine on \(t=1\). The top quadratic
   tensor \(Eu^2\partial_w\wedge\partial_z\) forces preservation of the
   line of linear forms \(u\) and the constant two-plane
   \(\langle\partial_w,\partial_z\rangle\). Consequently
   \(u'=au+\alpha\), \(v'=bu+cv+\beta\). Since \(A\ne0\),
   \(\{u',w'\}=0\) forces the z coefficient of \(w'\) to be zero.
   This proves the full lower-triangular flag form, without assuming a
   diagonal conjugacy.

2. **Coefficient invariant.** In that flag form, comparison of the five
   leading coefficients gives
   \(ajA=\lambda A'\), \(cfB=\lambda B'\),
   \(cjC=\lambda C'a\), \(fjD=\lambda D'c\),
   \(fjE=\lambda E'a^2\). Their indicated quotient cancels all coordinate
   and tensor multipliers and yields \(AE/(CD)=A'E'/(C'D')\).
   Direct substitution of the four diagonal factors displayed in the
   geometry note gives the claimed normal form
   \((8\kappa/9,-2/9,4/3,2/3,1)\). All denominators are nonzero under
   \(ABCDE\ne0\). Thus completeness is proved for that family. It is not
   proved for the full locus with divisor 5H.

3. **Corrected zero scheme.** The corrected ideal I includes the essential
   term \(-t^2w\) in its fifth cubic. For \(J=I+(t^2)\), the stated
   B-module presentation with \(B=\mathbb C[v,w,z]\) and relation vector
   \((2v^2/3,-4w/3,v)\) has primitive coefficients. In a UFD, the quotient
   of a free module by the span of a primitive single vector is torsion-free:
   if \(r m=h v\), primitivity implies \(r\mid h\). The resulting
   B-torsion-free property, together with nilpotence of t and u, proves
   that J is \((t,u)\)-primary. The rank over B is four. The annihilation
   of \(t^2\) by t,u,v and the exact Hilbert-series difference prove
   \(J/I\simeq\mathbb C[w,z](-2)\). Both associated primes occur, so the
   embedded line is present. The regular element w proves irrelevant
   saturation. This supports the fourfold primary plane plus embedded-line
   description, rather than a Cohen–Macaulay fourfold plane alone.

4. **Unique non-Cohen–Macaulay point.** Away from v=w=0 the relation vector
   is unimodular over the local B-ring, so its cokernel is locally free.
   At the one projective point v=w=0, the length-one free resolution is
   minimal over the regular two-dimensional base local ring. Its depth is
   one. The assertion of a unique non-Cohen–Macaulay point on the primary
   plane follows.

5. **Full stabilizer.** The same flag argument gives necessity; the
   remaining coefficient equations determine e,i,h. The parameter a is
   multiplicative, and the displayed diagonal subgroup splits the
   projection to \(\mathbb G_m\). The seven other free parameters give
   the connected unipotent kernel. The argument does not incorrectly
   identify that kernel with a commutative vector group.

The component-incidence note independently strengthens the family statement:
the entire nonzero five-coefficient family lies in both old 28-dimensional
components \(\mathcal C_A,\mathcal C_B\). These are different from the old
23-dimensional zero-log component \(\mathcal C_{5H}\), whose incidence
with Q remains undecided.

## Full second-order obstruction map

I checked `obstructions/build_quadratic_obstructions.py`,
`obstructions/poly_arithmetic.py` and `obstructions/branch_projection.py`.
The following steps are mathematically consistent.

* The full linear map M contains all 25 divergence coefficients and all
  350 Jacobi coefficients; second-order corrections are allowed in all
  150 homogeneous bivector coefficients. Thus the obstruction does not
  restrict corrections to an ansatz.
* The nonzero 99 by 99 minor gives independent image columns and the
  operator \(M_{*,C}(M_{R,C})^{-1}\) interpolates the selected rows. Thus
  \(B-M_{*,C}(M_{R,C})^{-1}B_R\) vanishes exactly when each quadratic
  right-hand side is in the full image of M.
* For the symmetric Schouten bracket, the factor 1/2 on diagonal
  \([T_i,T_i]\) terms and factor 1 on off-diagonal \([T_i,T_j]\) terms
  are exactly the coefficients of the Jacobi polynomial for
  \(\sum z_iT_i\). No polarization factor is missing.
* The 53 by 53 nonzero minor proves the lower quadratic rank bound; the
  identity \(C=C_{*,P}E\), with \(E_{*,P}=I_{53}\), proves the upper
  bound. Hence the quadratic-equation span has exactly dimension 53.
* The six lowest-weight equations are the entire square of the ideal
  \((z_{19},z_{30},z_{33})\). Therefore an ordinary complex first-order
  deformation that extends to order two has zero coefficients in these
  three directions. This is a set-theoretic statement about complex
  tangent vectors; it does not erase those variables from the
  scheme-theoretic local ring.
* The projection of each actual family differential into the transverse
  complement annihilates all 53 equations. In fact their 12-dimensional
  linear span also annihilates these quadratics. Therefore the quadratic
  obstruction alone does not separate the two component directions.

The proper scope is the complete **second-order obstruction map**. It does
not yet give the full completed germ, higher-order obstruction ideal, full
tangent cone, irreducible-component exhaustion, or a proof that the Jacobi
scheme is reduced or nonreduced at Q.

# Two actual 28-dimensional components through the fivefold-hyperplane endpoint

This note concerns the complex projective Poisson scheme
\(\mathscr P\subset\mathbf P H^0(\mathbf P^4,\wedge^2T_{\mathbf P^4})\).
Every dimension below is a dimension before taking a quotient by
\(\mathrm{PGL}_5\), unless the quotient is explicitly stated.

## 1. Endpoint and conventions

Put \((t,a,b,c,d)=(x_0,x_1,x_2,x_3,x_4)\),
\(\mu=-2/9\), and \(E=\sum x_i\partial_i\).
For a skew matrix of quadratic homogeneous coefficients \(P\), use

\[
 (\delta P)^j=\sum_i\partial_iP^{ij},\qquad
 \operatorname{can}(P)=P-\frac15E\wedge\delta P.
\]

This is the divergence-zero representative of the corresponding projective
bivector. Adding an Euler-vertical bivector does not change its projective
class. The normalization of the quintic used in the v23 certificate is

\[
 F(P)=\frac15\sum_{e=0}^4(-1)^e x_e
 \operatorname{Pf}(P_{\{0,1,2,3,4\}\setminus\{e\}}).
\]

Thus a harmless scalar factor \(1/5\) is included in this note's quintic;
its zero divisor is the actual degeneracy divisor.

The endpoint \(Q\) has nonzero upper entries

\[
 Q^{14}=t^2,\qquad Q^{23}=\mu t^2,\qquad
 Q^{24}=\frac43ta,\qquad
 Q^{34}=\frac23tb+a^2.
\]

Its actual quintic is \(F(Q)=-2t^5/45\).

## 2. Two full universal families

Let \(f=f(t,a)\) be any binary quadratic and let
\(h=h(t,a,b,c)\) be any homogeneous cubic, considered modulo cubics in
\(t,a\) alone. There are \(3+(20-4)=19\) effective parameters.
Write

\[
 X_h=-h_c\partial_b+h_b\partial_c,
 \qquad E_{bc}=b\partial_b+c\partial_c.
\]

Define raw homogeneous bivectors

\[
\begin{aligned}
 A(f,h)&=f\partial_a\wedge\partial_d
       +\mu t^2\partial_b\wedge\partial_c
       +\partial_d\wedge X_h,\\
 B(f,h)&=f(\partial_a\wedge\partial_d
       +\mu\partial_b\wedge\partial_c)
       +\partial_d\wedge\left(-\frac12f_aE_{bc}+X_h\right).
\end{aligned}
\]

Both are homogeneous Poisson bivectors for every choice of the parameters.
For example, for

\[
 P=f\partial_a\wedge\partial_d+g\partial_b\wedge\partial_c
       +\partial_d\wedge(Y^b\partial_b+Y^c\partial_c),
\]

with the indicated independence of \(d\), the only possibly nonzero Jacobi
coefficient is \(-fg_a-g(\partial_bY^b+\partial_cY^c)\).
For A, \(g=\mu t^2\) and the second term is zero. For B,
\(g=\mu f\) and \(\operatorname{div}_{bc}Y=-f_a\), so the two terms cancel.
Their canonical representatives are

\[
 A^{\rm can}=A-\frac15E\wedge(f_a\partial_d),\qquad
 B^{\rm can}=B-\frac25E\wedge(f_a\partial_d).
\]

In particular, \(\delta A=f_a\partial_d\) and
\(\delta B=2f_a\partial_d\). The accompanying independent symbolic verifier
checks that these canonical representatives themselves satisfy all ten
homogeneous Jacobi identities, as polynomial identities in all 19 parameters.

Because wedging with E kills the canonical correction, the quintics can be
read from the raw matrices:

\[
 F(A^{\rm can})=\frac\mu5t^3f,
 \qquad F(B^{\rm can})=\frac\mu5tf^2.
\]

For a general binary quadratic with two distinct factors, neither equal to
t, the respective actual divisors are

\[
 3H+H_1+H_2,\qquad H+2H_1+2H_2.
\]

## 3. Precise use of the older component theorem

The dependency is **v6, `ambient_families.tex`, Theorem `thm:AB`**, in the
section `sec:ambient`. It proves that the PGL saturations of the two displayed
19-parameter families with \(\mu=1\) have closures which are distinct
28-dimensional irreducible components of the full projective Poisson scheme.
Both are generically reduced and smooth. Their generic orbit dimension is
22; the Rosenlicht quotient dimension is 6.

The variables in that theorem are
\((x_0,x,y,z,w)=(t,a,d,b,c/\mu)\). The substitution \(c'=c/\mu\), together
with replacing \(h\) by \(h(t,a,b,\mu c')/\mu\), sends the present formulas
to the \(\mu=1\) formulas. Since \(\mu\ne0\) and the entire cubic space is
allowed, the present saturated families are exactly those older components,
denoted \(\mathcal C_A\) and \(\mathcal C_B\).

For audit purposes, v6 proves componentness at the witness
\(f=x_0^2+x^2\), \(h=xzw+z^3+w^3\). Its full projective Jacobi matrix has
350 rows and 150 columns and rank 97. The vertical space has dimension 24;
the vertical, orbit and scale columns together have rank 47; adding the 19
family derivatives gives rank 53. Hence both the full projective Zariski
tangent dimension and the actual saturated-family dimension are
\(150-97-24-1=53-24-1=28\). This is a full-space component theorem, not a
classification inside an invariant ansatz. This v24 verifier establishes the
new incidence and differential ranks; it does not rerun the older component
witness computation.

The two components are distinct also by their general divisor multiplicities.
On the rank-four open set the conditions \(F=L^3q\) and \(F=Lq^2\) are closed:
they are images of projective multiplication maps. The general divisor of B
has multiplicities \((1,2,2)\) and does not satisfy the first condition.
Both components have nonreduced generic degeneracy divisor. In particular
they differ from the known 24-dimensional component \(T_{37}\), whose
incidence with Q was established in v23.

## 4. Exact common basepoint and pencils

Set

\[
 h_0=\frac43tac-\frac13tb^2-a^2b.
\]

Then \((h_0)_c=4ta/3\), \(-(h_0)_b=2tb/3+a^2\), and
\((t^2)_a=0\). Consequently

\[
 \boxed{A^{\rm can}(t^2,h_0)=B^{\rm can}(t^2,h_0)=Q.}
\]

This proves actual incidence in both full components, without interpreting
a tangent vector as an integrable deformation.

An especially small exact deformation is obtained by taking
\(f=t^2+s a^2\), \(h=h_0\). It gives
\(Q+sR_A\) and \(Q+sR_B\), where the only nonzero upper entries are

| Entry | \(R_A\) | \(R_B\) |
|---|---:|---:|
| 04 | \(-2ta/5\) | \(-4ta/5\) |
| 14 | \(3a^2/5\) | \(a^2/5\) |
| 23 | 0 | \(-2a^2/9\) |
| 24 | \(-2ab/5\) | \(ab/5\) |
| 34 | \(-2ac/5\) | \(ac/5\) |

Their exact quintics are

\[
 F(Q+sR_A)=-\frac2{45}t^3(t^2+s a^2),\qquad
 F(Q+sR_B)=-\frac2{45}t(t^2+s a^2)^2.
\]

For every nonzero complex s the displayed divisors already have the indicated
three-hyperplane multiplicities. No assertion that these particular pencil
points are generic or smooth in their 28-dimensional components is needed.

Combining with the established v23 T37 incidence gives the proved lower bound

\[
 \boxed{[Q]\in\mathcal C_A\cap\mathcal C_B\cap T_{37}.}
\]

Thus Q lies on at least three distinct irreducible components of the full
projective Poisson scheme. This does not assert that the list is exhaustive.

## 5. Differential images at the special point

All computations here use the 150 coefficients of homogeneous quadratic
bivectors in the pair order \((01),(02),\ldots,(34)\) and the quadratic
monomial order \(x_0^2,x_0x_1,\ldots,x_4^2\). The canonical family
derivatives lie in the divergence-zero linear subspace. Thus no further
24-dimensional vertical quotient is taken in the following ranks.

Let O be the span of the 25 infinitesimal GL5 columns at Q and Q itself.
The scalar direction is already contained in the orbit column span; hence
\(\dim O=17\), and the projective orbit dimension is 16.
Let \(D_A,D_B\) be the spans of the 19 canonical parameter derivatives at
\((f,h)=(t^2,h_0)\), and put \(W_A=O+D_A\), \(W_B=O+D_B\).
The exact rational ranks are

| Space | Dimension |
|---|---:|
| \(D_A\), \(D_B\) | 19 each |
| \(O\) | 17 |
| \(W_A\), \(W_B\) | 28 each |
| \(W_A+W_B\) | 29 |
| \(W_A\cap W_B\) | 27 |

After quotienting by the scalar line, the two projective differential images
are each 27-dimensional, their sum is 28-dimensional, and their intersection
is 26-dimensional. After quotienting further by the 16-dimensional projective
orbit, the two images each have dimension 11, their sum has dimension 12,
and their intersection has dimension 10.

There is also an **actual common family** realizing this entire differential
intersection. Keep \(f=t^2\) and let all 16 effective coefficients of h vary.
Then \(A^{\rm can}(t^2,h)=B^{\rm can}(t^2,h)\) for every h. At \(h=h_0\),
the span of these 16 derivatives with O has affine dimension 27, so the
saturated common-family map has projective differential rank 26. Its
differential image is therefore exactly the 26-dimensional intersection of
the two differential images above.

In fact the full PGL-saturated closure \(\mathcal M\) of this common magnetic
family has dimension **exactly 26**. For the upper bound, on the affine chart
\(t=1\) consider the coordinate transformations

\[
\begin{aligned}
 a'&=r a+\alpha,\\
 \binom{b'}{c'}&=S\binom bc+u a+\beta,\\
 d'&=\frac{\det S}{r}d+\ell_b b+\ell_c c+\ell_a a+\delta,
\end{aligned}
\]

where \(r\in\mathbb C^*\), \(S\in\mathrm{GL}_2\),
\(u,\beta\in\mathbb C^2\), and
\(\alpha,\delta,\ell_a,\ell_b,\ell_c\in\mathbb C\).
These form a 14-dimensional subgroup of the affine coordinate group.
The two constant brackets transform by the same factor
\(\rho=\det S\): \(\{a',d'\}=\rho\),
\(\{b',c'\}=\mu\rho\). After dividing the tensor by \(\rho\),
all remaining nonzero brackets have the form \(\{b',d'\}=p\),
\(\{c',d'\}=q\), where p and q have degree at most two and are independent
of d'. The Jacobi identity gives \(\partial_{b'}p+\partial_{c'}q=0\), so
\(p=h'_{c'}\), \(q=-h'_{b'}\) for a polynomial h' of degree at most three,
unique modulo polynomials in a'. Homogenization gives exactly the same
16-dimensional effective cubic space. Thus this subgroup acts on the
common family projectively.

On \(\mathrm{PGL}_5\times\mathbb A^{16}\), its action
\((g,h)\mapsto(gk^{-1},k\cdot h)\) is free, and every such 14-dimensional
orbit lies in a fiber of the saturated-family map. Therefore

\[
 \dim\mathcal M\leq24+16-14=26.
\]

The differential rank at Q proves the reverse inequality. Its closure is
irreducible because the parameter space is irreducible. Consequently

\[
 \boxed{\mathcal M\subset\mathcal C_A\cap\mathcal C_B,
        \qquad\dim\mathcal M=26,\qquad[Q]\in\mathcal M.}
\]

This conclusion does not assert smoothness of the entire image closure at Q
or that \(\mathcal M\) is an irreducible component of the intersection.
In particular,

\[
 \dim_{[Q]}(\mathcal C_A\cap\mathcal C_B)\ \geq\ 26.
\]

This lower bound is justified by a genuine parametrized common family. It is
not a dimension inference from intersecting ambient tangent spaces. Since
the two distinct irreducible components both have dimension 28, their
intersection is a proper closed subset of either, so the local dimension
also satisfies the upper bound 27. Thus the proved statement at this stage
is \(26\leq\dim_{[Q]}(\mathcal C_A\cap\mathcal C_B)\leq27\).

These are **images of the differentials of the displayed parametrizations**.
They are not asserted to equal the Zariski tangent spaces of the components
at Q. Indeed the components have dimension 28 whereas these differential
images have projective dimension 27, so the parametrizations lose rank at Q.
This calculation alone decides neither smoothness of the reduced components
at Q nor the scheme structure of their intersection. The full Jacobi tangent
dimension 50 and the 34-dimensional transverse tangent quotient are earlier
v23 results, not the dimensions of these particular family images.

## 6. Reproducibility and limits

Run `python ambient_incidence.py` with SymPy installed. The script independently
constructs the universal canonical matrices, all Jacobi identities, the
quintics, all 19 derivatives and all 25 infinitesimal coordinate-action
columns. It uses exact rational row reduction for every reported rank and
writes `ambient_incidence.json`. It imports neither v23 certificates nor any
older Poisson helper implementation. The JSON contains the complete
coefficient basis and all orbit and family vectors for further auditing or
projection into another transverse basis.

The additional 23-dimensional component with generic divisor 5H from v6,
Theorem `thm:zero_log`, has not been proved incident with Q. It must not be
added to the incidence count on the basis of the shared divisor 5H or the
large endpoint tangent space.

## 7. The entire nonzero five-coefficient family lies in both components

The incidence extends beyond the one endpoint. Consider

\[
 Q(A,B,C,D,E)^{14}=At^2,\quad Q(A,B,C,D,E)^{23}=Bt^2,
 \quad Q(A,B,C,D,E)^{24}=Cta,\quad
 Q(A,B,C,D,E)^{34}=Dtb+Ea^2,
\]

where all five coefficients are nonzero. Put

\[
 h=Ctac-\frac D2tb^2-Ea^2b.
\]

In the universal formulas above, allow the nonzero constant \(\mu\) to be
written explicitly. Then

\[
 Q(A,B,C,D,E)
 =A^{\rm can}_{\mu=B}(At^2,h)
 =B^{\rm can}_{\mu=B/A}(At^2,h).
\]

The canonical corrections are zero because \(\partial_a(At^2)=0\).
As explained in section 3, every nonzero value of \(\mu\) is carried to
\(\mu=1\) by an invertible linear coordinate change. Therefore

\[
 \{[Q(A,B,C,D,E)]:ABCDE\ne0\}
 \subset\mathcal C_A\cap\mathcal C_B.
\]

This is also checked as a rational-function identity in the verifier. In
particular, the normalized one-parameter family with
\((A,B,C,D,E)=(K,-2/9,4/3,2/3,1)\), \(K\ne0\), is contained in both
components. More precisely, the whole five-coefficient family is contained
in the same 26-dimensional common magnetic closure \(\mathcal M\): the
coordinate change
\((a',b',c',d')=(a,b,\mu c/B,d/A)\) puts its two constant brackets into
the fixed form \(\{a',d'\}=1\), \(\{b',c'\}=\mu\), while its remaining
brackets are again magnetic and independent of d'. Its complete PGL
invariant **within this displayed family** is
\(\kappa=AE/(CD)=9K/8\), as established independently in the geometry note.
No incidence of this entire family with \(T_{37}\) is asserted here; only the
special value \(K=1\) has the previously proved T37 incidence. Neither the
normal form nor the invariant classifies the entire 5H locus.

"""Exact rank stratification of Q_a, with rational-function rank certificates.

For each torus-weight block, record a nonzero minor and verify the identity
A = A[:, pivot_columns] * minor^-1 * A[pivot_rows, :].  This certifies both
rank bounds over Q(a). Repeat over Q at every zero of a chosen minor.
"""
from pathlib import Path
import json, time
import sympy as s
from sympy.polys.matrices import DomainMatrix

H=Path(__file__).resolve().parent
D1=json.loads((H/'endpoint_full_tangent.json').read_text())
D2=json.loads((H/'weighted_generic_tangent.json').read_text())
a=s.Symbol('a'); start=time.monotonic()

def mat(d):
    return s.MutableSparseMatrix(375,150,{tuple(map(int,k.split(','))):s.Rational(v)
                                        for k,v in d['matrix_entries'].items()})

def dm(A, parameter=False):
    return DomainMatrix.from_Matrix(A).convert_to(s.QQ.frac_field(a) if parameter else s.QQ)

def certificate(A, rows, cols, parameter=False):
    if A.rows==0 or A.cols==0 or A.is_zero_matrix:
        return {'rank':0,'minor_rows':[],'minor_columns':[],'determinant':'1'}
    field=dm(A,parameter)
    pc=list(field.rref()[1]); pr=list(field.transpose().rref()[1]); r=len(pc)
    minor=field.extract(pr,pc)
    det=minor.domain.to_sympy(minor.det())
    reconstructed=field.extract(list(range(A.rows)),pc).matmul(minor.inv()).matmul(
        field.extract(pr,list(range(A.cols))))
    assert field==reconstructed
    assert det!=0
    return {'rank':r,'minor_rows':[rows[i] for i in pr],
            'minor_columns':[cols[j] for j in pc],'determinant':str(s.factor(det))}

M1=mat(D1); M2=mat(D2); M=M1+(a-1)*(M2-M1)
weights=[sum(b['pair'])-sum(i*c for i,c in enumerate(b['monomial_exponents']))
         for b in D1['basis']]
factors=set(); blocks=[]; usedrows=set()
for w in sorted(set(weights)):
    cc=[i for i,v in enumerate(weights) if v==w]
    rr=[i for i in range(375) if any(M[i,j]!=0 for j in cc)]
    assert not (usedrows & set(rr)); usedrows.update(rr)
    cert=certificate(M[rr,cc],rr,cc,True)
    for f,e in s.factor_list(s.sympify(cert['determinant']),a)[1]:factors.add(str(f))
    record={'weight':w,'row_indices':rr,'column_indices':cc,'rows':len(rr),'cols':len(cc),
            'generic_rank':cert['rank'],'minor_factor':cert['determinant'],
            'rank_certificate':cert}
    blocks.append(record)
    print({'weight':w,'rank':cert['rank'],'minor':cert['determinant']},flush=True)

roots={v for f in factors for v in s.solve(s.sympify(f),a)}
special=[]
for val in sorted(roots,key=str):
    certificates=[]
    for block in blocks:
        rr=block['row_indices'];cc=block['column_indices']
        cert=certificate(M[rr,cc].subs(a,val),rr,cc)
        certificates.append({'weight':block['weight'],**cert})
    rank=sum(c['rank'] for c in certificates)
    record={'a':str(val),'rank':rank,'projective_tangent':149-rank,
            'weight_certificates':certificates}
    special.append(record)
    print({'a':str(val),'rank':rank,'projective_tangent':149-rank},flush=True)
def orbit_matrix(d):
    return s.Matrix.hstack(*[s.Matrix([s.Rational(v) for v in col]) for col in d['orbit_vectors']])
O1=orbit_matrix(D1);O=O1+(a-1)*(orbit_matrix(D2)-O1)
orbit_generic=certificate(O,list(range(150)),list(range(24)),True)
orbit_roots=set(s.solve(s.sympify(orbit_generic['determinant']),a))
orbit_special=[]
for val in sorted(orbit_roots | {s.Rational(2,9)},key=str):
    orbit_special.append({'a':str(val),**certificate(O.subs(a,val),list(range(150)),list(range(24)))})
scale_coefficients=s.zeros(24,1)
for label,value in [('H0',-2),('H1',-1),('H3',1)]:
    scale_coefficients[D1['orbit_basis_labels'].index(label)]=value
x=s.symbols('x0:5')
def point_vector(d):
    return s.Matrix([s.Poly(s.sympify(d['P_entries'][''.join(map(str,b['pair']))]),*x).coeff_monomial(
        s.prod(xx**e for xx,e in zip(x,b['monomial_exponents']))) for b in d['basis']])
Q1=point_vector(D1);Qvector=Q1+(a-1)*(point_vector(D2)-Q1)
assert O*scale_coefficients==5*Qvector
result={'family':'Q_a: Q14=a*x0**2, Q23=-2*x0**2/9, Q24=4*x0*x1/3, Q34=2*x0*x2/3+x1**2',
        'blocks':blocks,'candidate_factors':sorted(factors),'special_values':special,
        'generic_rank':sum(v['generic_rank'] for v in blocks),
        'orbit':{'generic_certificate':orbit_generic,'exceptional_roots':[str(v) for v in sorted(orbit_roots,key=str)],
                 'special_certificates':orbit_special,'scale_relation_coefficients':[str(v) for v in scale_coefficients],
                 'scale_relation':'O(a)*coefficients = 5*Q_a','projective_orbit_dimension_all_a':16},
        'certificate_identity':'A = A[:,pivot_columns] * minor^(-1) * A[pivot_rows,:]',
        'scope':'All a in C; full canonical lift linearization. No numerical sampling.',
        'seconds':time.monotonic()-start}
(H/'parameter_rank.json').write_text(json.dumps(result,indent=2)+'\n')

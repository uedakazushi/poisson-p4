from pathlib import Path
import sympy as s,json
from sympy.polys.matrices import DomainMatrix
H=Path(__file__).resolve().parent
d=json.loads((H/'endpoint_full_tangent.json').read_text());ob=json.loads((H/'quadratic_obstructions.json').read_text());f=json.loads((H/'branch_input.json').read_text());x=s.symbols('x0:5');z=s.symbols('z0:34');piv=lambda M:DomainMatrix.from_Matrix(M).convert_to(s.QQ).rref()[1]
O=s.Matrix.hstack(*[s.Matrix([s.Rational(v) for v in vv]) for vv in d['orbit_vectors']]);op=list(piv(O));N=s.Matrix.hstack(*[s.Matrix([s.Rational(v) for v in vv]) for vv in d['kernel_vectors']]);T=N[:,d['transverse_kernel_indices']];free=d['kernel_free_columns'];K=(O[:,op].row_join(T))[free,:];Ki=DomainMatrix.from_Matrix(K).convert_to(s.QQ).inv().to_Matrix();proj=Ki[17:,:]
Es=[s.sympify(q) for q in ob['independent_quadratic_equations']]
bs={};checks={}
for typ in ['A','B']:
 V=s.Matrix.hstack(*[s.Matrix([s.Rational(v) for v in vv]) for vv in f['family_vector_columns'][typ]]);Z=proj*V[free,:];p=list(piv(Z));Z=Z[:,p];v=s.symbols('v0:'+str(Z.cols));vec=Z*s.Matrix(v)
 vals=[s.expand(q.subs(dict(zip(z,vec)),simultaneous=True)) for q in Es];assert all(q==0 for q in vals)
 bs[typ]=Z
 print(typ,Z.cols,'all53quadraticszero',flush=True)
U=bs['A'].row_join(bs['B']);p=list(piv(U));U=U[:,p];v=s.symbols('v0:'+str(U.cols));vec=U*s.Matrix(v);vals=[s.factor(q.subs(dict(zip(z,vec)),simultaneous=True)) for q in Es]
nonzero=set(str(q) for q in vals if q!=0)
print('unionrank',U.cols,'nonzeroequations',len(nonzero));print(nonzero,flush=True)
result={'projection_to_transverse_coordinates':[[str(e) for e in row] for row in proj.tolist()],'A_basis':[[str(e) for e in row] for row in bs['A'].tolist()],'B_basis':[[str(e) for e in row] for row in bs['B'].tolist()],'A_dimension':bs['A'].cols,'B_dimension':bs['B'].cols,'intersection_dimension':bs['A'].cols+bs['B'].cols-U.cols,'union_dimension':U.cols,'union_basis':[[str(e) for e in row] for row in U.tolist()],'quadratic_obstructions_vanish_on_each_branch_image':True,'restricted_union_equations':sorted(nonzero)}
(H/'branch_projection.json').write_text(json.dumps(result,indent=2)+'\n')

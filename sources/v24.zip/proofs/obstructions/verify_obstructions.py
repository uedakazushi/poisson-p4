"""Independent exact verification of the v24 endpoint obstruction package.

The generator uses Fraction sparse pair brackets. This verifier instead forms
one symbolic bivector R(z), differentiates it in SymPy, and extracts all 595
quadratic coefficient columns at once. Linear/orbit data are separately audited
by the stdlib-only polynomial/Bareiss implementation inherited from v23.
No floating point arithmetic or sample-based rank inference is used.
"""
from pathlib import Path
from itertools import combinations, combinations_with_replacement
from fractions import Fraction
import json, time
import sympy as s
from sympy.polys.matrices import DomainMatrix
import poly_arithmetic as pa

H=Path(__file__).resolve().parent
start=time.monotonic(); checks=[]; check_labels=set()
def ck(ok,label):
    assert ok,label
    if label not in check_labels:
        checks.append(label);check_labels.add(label)
def read(name):return json.loads((H/name).read_text())
def sparse(entries,shape):
    return s.MutableSparseMatrix(*shape,{tuple(map(int,k.split(','))):s.Rational(v)
                                       for k,v in entries.items()})
def rational_matrix(values):return s.Matrix([[s.Rational(v) for v in row] for row in values])
def dm(A,parameter=None):
    return DomainMatrix.from_Matrix(A).convert_to(s.QQ if parameter is None else s.QQ.frac_field(parameter))

# This validates every coordinate, every orbit vector, the complete rational
# kernel, and the nonzero 99x99 rank minor without using SymPy.
linear_audits=[]
for name in ['endpoint_full_tangent.json','weighted_generic_tangent.json']:
    a=pa.audit(H/name);linear_audits.append(a);ck(a['all_passed'],name+'_independent_stdlib_audit')
print('linear and orbit audits complete',time.monotonic()-start,flush=True)

d=read('endpoint_full_tangent.json'); ob=read('quadratic_obstructions.json')
x=s.symbols('x0:5'); z=s.symbols('z0:34'); n=len(z)
pairs=list(combinations(range(5),2)); triples=list(combinations(range(5),3))
m3=pa.basis_monomials(3); m3index={mon:i for i,mon in enumerate(m3)}
zpairs=list(combinations_with_replacement(range(n),2)); zindex={pair:i for i,pair in enumerate(zpairs)}
M=sparse(d['matrix_entries'],(375,150))
T=s.Matrix.hstack(*[s.Matrix([s.Rational(c) for c in d['kernel_vectors'][i]])
                   for i in d['transverse_kernel_indices']])
ck(T.cols==34,'full_transverse_dimension_34')
R=s.zeros(5)
for i,j in pairs:
    R[i,j]=sum(z[k]*s.sympify(entry.get(str(i)+str(j),'0'))
               for k,entry in enumerate(d['transverse_P_entries']))
    R[j,i]=-R[i,j]
J={}
for i,j,k in triples:
    J[i,j,k]=s.expand(sum(R[a,l]*s.diff(R[b,c],x[l])
                          for a,b,c in [(i,j,k),(j,k,i),(k,i,j)] for l in range(5)))
entries={}
for ti,ijk in enumerate(triples):
    for exponents,coefficient in s.Poly(J[ijk],*x,*z).terms():
        if coefficient==0:continue
        mx=tuple(exponents[:5]); mz=exponents[5:]
        indices=tuple(i for i,power in enumerate(mz) for _ in range(power))
        ck(len(indices)==2 and sum(mx)==3,'homogeneous_quadratic_Jacobi_term')
        entries[25+35*ti+m3index[mx],zindex[indices]]=coefficient
B=s.MutableSparseMatrix(375,len(zpairs),entries)
ck(B==sparse(ob['raw_quadratic_entries'],B.shape),'all_375x595_quadratic_coefficients_independently_reconstructed')
ck(ob['quadratic_monomial_pairs']==[list(p) for p in zpairs],'quadratic_monomial_order')
print('symbolic quadratic reconstruction complete',len(entries),time.monotonic()-start,flush=True)

# Projection onto the full cokernel. Both divergence and all Jacobi rows are retained.
rows=ob['projection_rows']; cols=ob['projection_columns']; A=M[rows,cols]
ck(len(rows)==len(cols)==99,'projection_uses_full_rank_99_image')
projection=M[:,cols]*dm(A).inv().to_Matrix()
ck(projection==sparse(ob['projection_matrix_entries'],projection.shape),'exact_image_projection_reconstructed')
ck(projection[rows,:]==s.eye(99),'projection_right_inverse_on_pivot_rows')
C=B-projection*B[rows,:]
ck(C==sparse(ob['projected_quadratic_entries'],C.shape),'full_quadratic_obstruction_matrix_reconstructed')
# Read equations as polynomials, independently rebuilding their coefficient matrix.
E=s.zeros(len(ob['independent_quadratic_equations']),len(zpairs))
for row,formula in enumerate(ob['independent_quadratic_equations']):
    for powers,coefficient in s.Poly(s.sympify(formula),*z).terms():
        ij=tuple(i for i,power in enumerate(powers) for _ in range(power))
        ck(len(ij)==2,'each_stored_equation_is_quadratic')
        E[row,zindex[ij]]=coefficient
w=ob['quadratic_rank_witness']; qr=w['rows']; qc=w['columns']
ck(E.rows==53 and len(qr)==len(qc)==53,'fifty_three_equations_and_minor')
ck(E[:,qc]==s.eye(53),'equation_pivot_identity')
ck(C==C[:,qc]*E,'exact_rank_upper_bound_and_equality_of_equation_spans')
for short in ob['short_basis']:
    row=short['projected_row']
    formula=sum(C[row,col]*z[i]*z[j] for col,(i,j) in enumerate(zpairs))
    ck(s.expand(formula-s.sympify(short['polynomial']))==0,'short_original_equation_row_'+str(row))
minor=[[Fraction(C[i,j]) for j in qc] for i in qr]
qdet=pa.det(minor)
ck(qdet!=0 and qdet==Fraction(w['determinant']),'exact_53x53_Bareiss_rank_lower_bound')

weights=[]
for col in range(T.cols):
    ww={sum(b['pair'])-sum(i*c for i,c in enumerate(b['monomial_exponents']))
        for b,coefficient in zip(d['basis'],T[:,col]) if coefficient}
    ck(len(ww)==1,'homogeneous_transverse_basis_'+str(col));weights.append(ww.pop())
ck(weights==ob['weights'],'all_transverse_torus_weights')
ck([w-5 for w in weights]==ob['relative_weights'],'all_projective_normal_weights')
for row,expected in enumerate(ob['equation_weights']):
    ww={weights[i]+weights[j] for column,(i,j) in enumerate(zpairs) if E[row,column]}
    ck(ww=={expected},'homogeneous_obstruction_equation_'+str(row))
low=[s.sympify(formula) for formula,wgt in zip(ob['independent_quadratic_equations'],ob['equation_weights']) if wgt==-2]
ck(set(low)=={z[19]**2,z[19]*z[30],z[19]*z[33],z[30]**2,z[30]*z[33],z[33]**2},
   'lowest_weight_equations_are_full_square_of_three_coordinates')

# Elementary obstruction certificate for R_33, with a functional vanishing on
# the whole 150-dimensional raw quadratic-bivector domain of the linearization.
R33=pa.matrix(d['transverse_P_entries'][33]); JJ=pa.lie(R33,R33)
JJ={ijk:pa.scale(p,Fraction(1,2)) for ijk,p in JJ.items()}
mon=(1,0,0,0,2)
ck(JJ[(1,2,3)]=={mon:Fraction(72)} and all(not p for ijk,p in JJ.items() if ijk!=(1,2,3)),
   'R33_Jacobi_is_72_x0_x4_squared_partial123')
r123=25+35*triples.index((1,2,3))+m3index[mon]
r024=25+35*triples.index((0,2,4))+m3index[mon]
ell=s.zeros(1,375);ell[0,r123]=1;ell[0,r024]=-s.Rational(1,3)
ck(ell*M==s.zeros(1,150),'explicit_functional_annihilates_all_150_linearized_columns')
ck((ell*B)[0,zindex[(33,33)]]==72,'explicit_second_order_obstruction_is_nonzero')

# Check the A/B tangent-image projections and all obstructions on their sum.
bp=read('branch_projection.json'); bi=read('branch_input.json')
N=s.Matrix.hstack(*[s.Matrix([s.Rational(c) for c in v]) for v in d['kernel_vectors']])
O=s.Matrix.hstack(*[s.Matrix([s.Rational(c) for c in v]) for v in d['orbit_vectors']])
op=list(dm(O).rref()[1]);free=d['kernel_free_columns']
K=(O[:,op].row_join(T))[free,:]
proj=dm(K).inv().to_Matrix()[17:,:]
ck(proj==rational_matrix(bp['projection_to_transverse_coordinates']),'branch_transverse_projection')
branch_bases=[]
for typ in ['A','B']:
    V=s.Matrix.hstack(*[s.Matrix([s.Rational(c) for c in col]) for col in bi['family_vector_columns'][typ]])
    ck(M*V==s.zeros(375,V.cols),'branch_'+typ+'_all_parameter_vectors_tangent')
    Z=proj*V[free,:];pc=list(dm(Z).rref()[1]);Z=Z[:,pc]
    ck(Z==rational_matrix(bp[typ+'_basis']) and Z.cols==11,'branch_'+typ+'_transverse_dimension_11')
    branch_bases.append(Z)
U=branch_bases[0].row_join(branch_bases[1]);U=U[:,list(dm(U).rref()[1])]
ck(U.cols==12 and U==rational_matrix(bp['union_basis']),'two_branch_images_span_dimension_12')
# For a quadratic equation q, E coefficients encode a symmetric form with half
# off-diagonal entries. Restriction vanishes exactly when U^t q U=0.
for row in range(E.rows):
    form=s.zeros(34)
    for col,(i,j) in enumerate(zpairs):
        if i==j:form[i,j]=E[row,col]
        else:form[i,j]=form[j,i]=E[row,col]/2
    ck(U.T*form*U==s.zeros(12),'obstruction_'+str(row)+'_vanishes_on_full_AB_sum')
print('quadratic rank, explicit obstruction, branch restrictions verified',time.monotonic()-start,flush=True)

# Exact parameter-stratification certificate. Jacobi linearization is linear in
# the base point; divergence is constant. The independently audited a=1,2
# matrices therefore determine the full polynomial matrix M(a).
pr=read('parameter_rank.json');d2=read('weighted_generic_tangent.json')
a=s.Symbol('a');Ma=M+(a-1)*(sparse(d2['matrix_entries'],(375,150))-M)
ck(d2['P_entries']=={**d['P_entries'],'14':'2*x0**2'},'parameter_family_endpoints_differ_only_in_Q14')
Qa=s.zeros(5)
for i,j in pairs:
    Qa[i,j]=a*x[0]**2 if (i,j)==(1,4) else s.sympify(d['P_entries'][str(i)+str(j)])
    Qa[j,i]=-Qa[i,j]
ck(all(s.expand(sum(s.diff(Qa[i,j],x[i]) for i in range(5)))==0 for j in range(5)),
   'whole_symbolic_parameter_family_is_canonical')
ck(all(s.expand(sum(Qa[p,l]*s.diff(Qa[q,r],x[l])
                    for p,q,r in [(i,j,k),(j,k,i),(k,i,j)] for l in range(5)))==0
       for i,j,k in triples),'whole_symbolic_parameter_family_is_Poisson')
pf1234=Qa[1,2]*Qa[3,4]-Qa[1,3]*Qa[2,4]+Qa[1,4]*Qa[2,3]
ck(s.expand(x[0]*pf1234/5+2*a*x[0]**5/45)==0,'symbolic_parameter_quintic_minus_2a_x0_fifth_over_45')
used_rows=set();used_cols=set();candidate_factors=set()
def verify_rank_certificate(block,cert,value=None):
    rr=block['row_indices'];cc=block['column_indices'];matrix=Ma[rr,cc]
    if value is not None:matrix=matrix.subs(a,value)
    rank=cert['rank'];mr=cert['minor_rows'];mc=cert['minor_columns']
    label='weight_'+str(block['weight'])+'_a_'+str(value)
    ck(len(mr)==len(mc)==rank,label+'_minor_size')
    if rank==0:
        ck(matrix.is_zero_matrix,label+'_rank_zero');return
    field=dm(matrix,a if value is None else None)
    localr=[rr.index(i) for i in mr];localc=[cc.index(j) for j in mc]
    minor=field.extract(localr,localc)
    det=minor.domain.to_sympy(minor.det())
    ck(det!=0 and s.cancel(det-s.sympify(cert['determinant']))==0,label+'_exact_nonzero_minor')
    reconstructed=field.extract(list(range(matrix.rows)),localc).matmul(minor.inv()).matmul(
        field.extract(localr,list(range(matrix.cols))))
    ck(field==reconstructed,label+'_rank_upper_bound_identity')
for block in pr['blocks']:
    rr=block['row_indices'];cc=block['column_indices']
    ck(not(used_rows & set(rr)) and not(used_cols & set(cc)),'weight_block_disjoint_'+str(block['weight']))
    used_rows.update(rr);used_cols.update(cc)
    ck(rr==[i for i in range(375) if any(Ma[i,j]!=0 for j in cc)],'all_row_support_'+str(block['weight']))
    ck(cc==[i for i,b in enumerate(d['basis']) if sum(b['pair'])-sum(k*e for k,e in enumerate(b['monomial_exponents']))==block['weight']],
       'all_column_weights_'+str(block['weight']))
    verify_rank_certificate(block,block['rank_certificate'])
    ck(s.cancel(s.sympify(block['minor_factor'])-s.sympify(block['rank_certificate']['determinant']))==0,
       'candidate_minor_matches_verified_determinant_'+str(block['weight']))
    ck(block['generic_rank']==block['rank_certificate']['rank'],
       'generic_rank_matches_verified_certificate_'+str(block['weight']))
    for factor,multiplicity in s.factor_list(s.sympify(block['minor_factor']),a)[1]:candidate_factors.add(str(factor))
ck(used_cols==set(range(150)),'all_150_parameter_columns_covered')
ck(sum(b['generic_rank'] for b in pr['blocks'])==99,'generic_full_parameter_rank_99')
ck(candidate_factors==set(pr['candidate_factors']),'all_exceptional_candidate_factors')
roots={v for f in candidate_factors for v in s.solve(s.sympify(f),a)}
ck(roots=={s.sympify(v['a']) for v in pr['special_values']},'every_candidate_root_checked')
for special in pr['special_values']:
    value=s.sympify(special['a'])
    ck(len(special['weight_certificates'])==len(pr['blocks']),str(value)+'_all_weight_certificates_present')
    for block,cert in zip(pr['blocks'],special['weight_certificates']):
        verify_rank_certificate(block,cert,value)
    ck(sum(c['rank'] for c in special['weight_certificates'])==special['rank'],str(value)+'_total_rank')
    expected=97 if value==0 else 98 if value==s.Rational(2,9) else 99
    ck(special['rank']==expected,str(value)+'_claimed_rank_stratum')

# The orbit remains 17-dimensional throughout the parameter line, and scale
# lies in the orbit. This also verifies the normal dimensions 34/35/36.
O2=s.Matrix.hstack(*[s.Matrix([s.Rational(c) for c in v]) for v in d2['orbit_vectors']])
Oa=O+(a-1)*(O2-O)
def verify_orbit_certificate(cert,value=None):
    matrix=Oa if value is None else Oa.subs(a,value)
    field=dm(matrix,a if value is None else None)
    rr=cert['minor_rows'];cc=cert['minor_columns'];minor=field.extract(rr,cc)
    det=minor.domain.to_sympy(minor.det())
    ck(cert['rank']==len(rr)==len(cc)==17,'orbit_rank_17_'+str(value))
    ck(det!=0 and s.cancel(det-s.sympify(cert['determinant']))==0,'orbit_exact_minor_'+str(value))
    reconstructed=field.extract(list(range(150)),cc).matmul(minor.inv()).matmul(field.extract(rr,list(range(24))))
    ck(field==reconstructed,'orbit_rank_upper_bound_'+str(value))
verify_orbit_certificate(pr['orbit']['generic_certificate'])
orbit_roots=set(s.solve(s.sympify(pr['orbit']['generic_certificate']['determinant']),a))
checked_roots=set()
for cert in pr['orbit']['special_certificates']:
    value=s.sympify(cert['a']);checked_roots.add(value);verify_orbit_certificate(cert,value)
ck(orbit_roots<=checked_roots,'all_orbit_exceptional_candidates_checked')
Q=s.zeros(150,1)
for i,b in enumerate(d['basis']):
    key=''.join(map(str,b['pair']));formula=s.sympify(d['P_entries'][key])
    if key=='14':formula=a*x[0]**2
    Q[i,0]=s.Poly(formula,*x).coeff_monomial(s.prod(xx**power for xx,power in zip(x,b['monomial_exponents'])))
coefficients=s.Matrix([s.Rational(v) for v in pr['orbit']['scale_relation_coefficients']])
ck(Oa*coefficients==5*Q,'scale_in_orbit_for_all_parameters')

summary={'all_passed':True,'check_count':len(checks),'checks':checks,
         'linear_audits':linear_audits,
         'quadratic_rank':53,'normal_dimension':34,
         'quadratic_rank_determinant':str(qdet),
         'lowest_obstructed_indices':[19,30,33],
         'AB_sum_dimension':12,'AB_sum_all_quadratics_vanish':True,
         'parameter_rank':{'generic':99,'a=0':97,'a=2/9':98},
         'projective_orbit_dimension_all_a':16,
         'method':'Independent symbolic Jacobi reconstruction; stdlib tangent/orbit and Bareiss audits; exact minor and rank-factorization identities over Q and Q(a).',
         'limitations':'Second-order obstruction map only. No claim of a complete formal slice ideal, reduced local ring, or exhaustive list of components.',
         'seconds':round(time.monotonic()-start,3)}
(H/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['checks','linear_audits']},indent=2),flush=True)

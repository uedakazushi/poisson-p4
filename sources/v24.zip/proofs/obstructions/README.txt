v24 endpoint obstruction package (self-contained)

Main theorem data:
- endpoint_full_tangent.json: all 150 coordinates; full 375x150 linearization;
  exact 99x99 minor; full 51-dimensional kernel; all 24 orbit vectors; 34
  normal representatives. Copied unchanged from v23.
- quadratic_obstructions.json: complete 375x595 quadratic coefficient matrix,
  quotient projection, exact rank 53, 53 equations, 53 independent original
  rows in short_basis, weights, rank minor and row-space factorization.
- branch_input.json / branch_projection.json: parameter derivatives of A/B
  families and their projection to the full 34-dimensional normal space.
- parameter_rank.json: exact all-parameter tangent and orbit stratification,
  with lower-rank minors and upper-rank factorization identities over Q(a)
  and at every candidate exceptional point.
- endpoint_obstructions.tex: proof-ready Japanese exposition.
- verification.json: independent verification result.

Reproduction (requires SymPy; in the current environment use
PYTHONPATH=/tmp/p4_v6_math before python3):
  python3 build_quadratic_obstructions.py
  python3 parameter_rank.py
  python3 branch_projection.py
  python3 verify_obstructions.py

The final verifier is the only required command to audit the saved package.
It reconstructs all quadratic coefficients by a method distinct from the
builder, checks the full linear/orbit data, the exact rank certificates,
the six lowest-weight equations, the explicit nonextendable R33 direction,
the vanishing of all quadratic obstructions on the 12-dimensional sum of
A/B parameter differential images, and all-parameter rank/orbit strata.

Scope: complete second-order obstruction map at Q, NOT a complete formal
local ideal or full tangent cone decomposition. Nilpotents in the local
Poisson ring and the exhaustive list of local components remain unresolved.
The A/B subspaces are differential images, not asserted whole branch tangent
spaces. The a=0 member has generic rank two. The full PGL invariance and completeness of kappa=AE/(CD) are proved in the
companion geometry section of the integrated v24 manuscript.

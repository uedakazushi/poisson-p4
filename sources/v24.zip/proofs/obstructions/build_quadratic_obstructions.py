"""Full second-order obstruction at the v23 nonreduced endpoint.
Independent exact brackets and exact quotient by the full linearized image.
"""
from pathlib import Path
import argparse,json,time,importlib.util
from itertools import combinations,combinations_with_replacement
from fractions import Fraction as F
import sympy as s
from sympy.polys.matrices import DomainMatrix
HERE=Path(__file__).resolve().parent
SRC=HERE/'endpoint_full_tangent.json'
spec=importlib.util.spec_from_file_location('audit',HERE/'poly_arithmetic.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
start=time.monotonic();d=json.loads(SRC.read_text());T=[a.matrix(v) for v in d['transverse_P_entries']];n=len(T)
M=s.MutableSparseMatrix(375,150,{tuple(map(int,ij.split(','))):s.Rational(v) for ij,v in d['matrix_entries'].items()})
rows=d['rank_witness']['rows'];cols=d['rank_witness']['columns'];A=M[rows,cols]
Ainv=DomainMatrix.from_Matrix(A).convert_to(s.QQ).inv().to_Matrix()
Bproj=M[:,cols]*Ainv
assert Bproj[rows,:]==s.eye(len(rows))
print('projection computed',len(rows),time.monotonic()-start,flush=True)
triples=list(combinations(range(5),3));m3=a.basis_monomials(3);monpairs=list(combinations_with_replacement(range(n),2));entries={}
for column,(i,j) in enumerate(monpairs):
 J=a.lie(T[i],T[j]);fac=F(1,2) if i==j else F(1)
 for ti,ijk in enumerate(triples):
  for mi,mon in enumerate(m3):
   v=fac*J[ijk].get(mon,F(0))
   if v:entries[25+35*ti+mi,column]=s.Rational(v.numerator,v.denominator)
B=s.MutableSparseMatrix(375,len(monpairs),entries)
print('quadratic coefficients',B.shape,'nonzero',len(entries),time.monotonic()-start,flush=True)
C=B-Bproj*B[rows,:]
assert C[rows,:]==s.zeros(len(rows),len(monpairs))
# Nonzero equation basis; row-echelon reductions preserve the full degree2 span.
DM=DomainMatrix.from_Matrix(C).convert_to(s.QQ);rr,piv=DM.rref();rr=rr.to_Matrix();r=len(piv)
E=rr[:r,:]
_,rowpiv=DomainMatrix.from_Matrix(C[:,list(piv)].T).convert_to(s.QQ).rref()
qminor=C[list(rowpiv),list(piv)]
qdet=s.QQ.to_sympy(DomainMatrix.from_Matrix(qminor).convert_to(s.QQ).det())
assert qdet!=0
assert E[:,list(piv)]==s.eye(r)
assert C==C[:,list(piv)]*E
print('independent quadratic obstruction equations',r,'nonzero',len(E.todok()),time.monotonic()-start,flush=True)
weights=[]
w=[0,1,2,3,4]
for index in d['transverse_kernel_indices']:
 v=d['kernel_vectors'][index];ww={w[b['pair'][0]]+w[b['pair'][1]]-sum(aa*bb for aa,bb in zip(w,b['monomial_exponents'])) for b,c in zip(d['basis'],v) if c!='0'}
 assert len(ww)==1;weights.append(ww.pop())
z=s.symbols('z0:'+str(n));polys=[];eqwt=[]
for row in E.tolist():
 p=s.expand(sum(c*z[i]*z[j] for c,(i,j) in zip(row,monpairs)))
 polys.append(str(p));wt={weights[i]+weights[j] for c,(i,j) in zip(row,monpairs) if c};assert len(wt)==1;eqwt.append(wt.pop())
short_basis=[]
for row_index in rowpiv:
 row=list(C[row_index,:]);wt={weights[i]+weights[j] for c,(i,j) in zip(row,monpairs) if c}
 assert len(wt)==1
 short_basis.append({'projected_row':row_index,'weight':wt.pop(),
                     'polynomial':str(s.expand(sum(c*z[i]*z[j] for c,(i,j) in zip(row,monpairs))))})
individual=[]
for i in range(n):
 column=monpairs.index((i,i));individual.append({'index':i,'weight':weights[i],'projective_weight':weights[i]-5,'itself_poisson':all(B[row,column]==0 for row in range(375)),'second_order_unobstructed':all(C[row,column]==0 for row in range(375))})
report={'base_point':d['P_entries'],'transverse_entries':d['transverse_P_entries'],'transverse_kernel_indices':d['transverse_kernel_indices'],'weights':weights,'relative_weights':[w-5 for w in weights],'quadratic_monomial_pairs':[list(v) for v in monpairs],'projection_rows':rows,'projection_columns':cols,'projection_matrix_entries':{f'{i},{j}':str(v) for (i,j),v in Bproj.todok().items()},'raw_quadratic_entries':{f'{i},{j}':str(v) for (i,j),v in B.todok().items()},'projected_quadratic_entries':{f'{i},{j}':str(v) for (i,j),v in C.todok().items()},'independent_quadratic_equations':polys,'equation_weights':eqwt,'quadratic_rank':r,'quadratic_rank_witness':{'rows':list(rowpiv),'columns':list(piv),'determinant':str(qdet),'upper_rank_identity':'C = C[:,columns] * E, E[:,columns] = I_53'},'individual_directions':individual,'seconds':round(time.monotonic()-start,3)}
report['short_basis']=short_basis
(HERE/'quadratic_obstructions.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'equations':r,'weights':{q:weights.count(q) for q in sorted(set(weights))},'equationweights':{q:eqwt.count(q) for q in sorted(set(eqwt))},'individual':individual,'seconds':report['seconds']},indent=2),flush=True)

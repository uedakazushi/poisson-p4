"""Exact endpoint geometry, complete stabilizer, and embedded zero scheme.

Standalone SymPy verifier. It verifies the polynomial identities used in the
companion proof; no old-version imports or numerical specialization.
"""
from pathlib import Path
from itertools import combinations, combinations_with_replacement
from functools import reduce
import json
import sympy as s

HERE=Path(__file__).resolve().parent
t,u,v,w,z=s.symbols("t u v w z")
xx=(t,u,v,w,z)
Q=s.zeros(5)
for (i,j),f in {(1,4):t**2,(2,3):-s.Rational(2,9)*t**2,
                (2,4):s.Rational(4,3)*t*u,
                (3,4):s.Rational(2,3)*t*v+u**2}.items():
    Q[i,j]=f;Q[j,i]=-f
checks={}
def ck(name,test):
    checks[name]=bool(test)
    if not test:raise AssertionError(name)
def zero(name,expr):
    ck(name,s.cancel(s.expand(expr))==0)
pairs=list(combinations(range(5),2))
triples=list(combinations(range(5),3))
for j in range(5):
    zero(f"divergence_{j}",sum(s.diff(Q[i,j],xx[i]) for i in range(5)))
for i,j,k in triples:
    zero(f"Jacobi_{i}{j}{k}",sum(Q[i,l]*s.diff(Q[j,k],xx[l])+Q[j,l]*s.diff(Q[k,i],xx[l])+Q[k,l]*s.diff(Q[i,j],xx[l]) for l in range(5)))
F=0
for h in range(5):
    i,j,k,l=[r for r in range(5) if r!=h]
    F+=xx[h]*(-1)**h*(Q[i,j]*Q[k,l]-Q[i,k]*Q[j,l]+Q[i,l]*Q[j,k])/5
zero("actual_quintic",F+s.Rational(2,45)*t**5)

# Polynomial Darboux shear on t=1.
aa=(u,v,w,z)
P=Q[1:,1:].subs(t,1)
J=s.zeros(4);J[0,3]=1;J[3,0]=-1;J[1,2]=-s.Rational(2,9);J[2,1]=s.Rational(2,9)
shear=s.Matrix([u,v,w,z+6*u*w-s.Rational(3,2)*v**2-s.Rational(9,2)*u**2*v])
Ds=shear.jacobian(aa)
ck("Darboux_shear", (Ds*P*Ds.T-J).applyfunc(s.expand)==s.zeros(4))
zero("Darboux_shear_Jacobian",Ds.det()-1)
# A second independent triangular Darboux map.
tri=s.Matrix([u,v-s.Rational(2,3)*u**2,w-s.Rational(2,3)*u*v-u**3/27,z])
Dt=tri.jacobian(aa)
ck("Darboux_triangular",(Dt*P*Dt.T-J).applyfunc(s.expand)==s.zeros(4))
zero("Darboux_triangular_Jacobian",Dt.det()-1)

# Every projective stabilizer preserves actual divisor 5H, so is affine.
# Highest quadratic term u^2 d_w wedge d_z forces the displayed flag form.
a,b,d,g,al,be,ga,de=s.symbols("a b d g alpha beta gamma delta")
ee=(a*b+3*a*a*al)/2
ii=s.Rational(9,2)*a*a*b-6*a**3*al
hh=3*a*a*be-s.Rational(9,2)*a*a*al**2-s.Rational(9,2)*a*d+s.Rational(9,4)*b*b+s.Rational(15,4)*a*b*al
G=s.Matrix([[1,0,0,0,0],[al,a,0,0,0],[be,b,a*a,0,0],
            [ga,d,ee,a**3,0],[de,g,hh,ii,a**4]])
Y=G*s.Matrix(xx)
E=G*Q*G.T-a**5*Q.subs(dict(zip(xx,Y)),simultaneous=True)
for i,j in pairs:zero(f"full_stabilizer_{i}{j}",E[i,j])
zero("stabilizer_determinant",G.det()-a**10)

# Symbolic necessity from the general remaining block matrix.
cc,ff,jj,EE,II,HH,la=s.symbols("c f j e i h lambda")
B=s.Matrix([[1,0,0,0,0],[al,a,0,0,0],[be,b,cc,0,0],
            [ga,d,EE,ff,0],[de,g,HH,II,jj]])
BY=B*s.Matrix(xx)
Delta=B*Q*B.T-la*Q.subs(dict(zip(xx,BY)),simultaneous=True)
necessity={
 "14_constant":(Delta[1,4],a*jj-la),
 "23_constant":(Delta[2,3],s.Rational(2,9)*(la-cc*ff)),
 "24_tu":(s.Poly(Delta[2,4],*xx).coeff_monomial(t*u),s.Rational(4,3)*(cc*jj-la*a)),
 "24_t2":(s.Poly(Delta[2,4],*xx).coeff_monomial(t*t),b*jj-s.Rational(2,9)*cc*II-s.Rational(4,3)*la*al),
 "34_u2":(s.Poly(Delta[3,4],*xx).coeff_monomial(u*u),ff*jj-la*a*a),
 "34_tu":(s.Poly(Delta[3,4],*xx).coeff_monomial(t*u),s.Rational(4,3)*EE*jj-la*(s.Rational(2,3)*b+2*a*al)),
 "34_t2":(s.Poly(Delta[3,4],*xx).coeff_monomial(t*t),d*jj-s.Rational(2,9)*EE*II+s.Rational(2,9)*ff*HH-la*(s.Rational(2,3)*be+al*al)),
}
for name,(left,right) in necessity.items():
    if name.endswith("constant"):left=s.Poly(left,*xx).coeff_monomial(t*t)
    zero("necessity_"+name,left-right)

# Scheme-theoretic projective zero ideal, not just closed point support.
Z={f"{i}{j}{k}":s.expand(xx[i]*Q[j,k]-xx[j]*Q[i,k]+xx[k]*Q[i,j]) for i,j,k in triples}
I=[t**3,t*t*u,t*t*v,t*u*u,u**3+s.Rational(2,3)*t*u*v-t*t*w,
   u*u*v+s.Rational(2,3)*t*v*v-s.Rational(4,3)*t*u*w-s.Rational(2,9)*t*t*z]
gbI=s.groebner(I,t,u,v,w,z,order="grevlex")
gbZ=s.groebner(list(Z.values()),t,u,v,w,z,order="grevlex")
for n,f in enumerate(I):zero(f"I_from_projective_zeros_{n}",gbZ.reduce(f)[1])
for name,f in Z.items():zero("projective_zero_from_I_"+name,gbI.reduce(f)[1])

# Primary fourfold plane, obtained by saturation away from embedded line v=0.
Jid=[t*t,t*u*u,u**3+s.Rational(2,3)*t*u*v,
     u*u*v+s.Rational(2,3)*t*v*v-s.Rational(4,3)*t*u*w]
gbJ=s.groebner(Jid,t,u,v,w,z,order="grevlex")
gbIplus=s.groebner(I+[t*t],t,u,v,w,z,order="grevlex")
for n,f in enumerate(Jid):zero(f"J_equals_I_plus_t2_forward_{n}",gbIplus.reduce(f)[1])
for n,f in enumerate(I+[t*t]):zero(f"J_equals_I_plus_t2_backward_{n}",gbJ.reduce(f)[1])
h=s.Symbol("localizer")
sat=s.groebner(I+[1-h*v],h,t,u,v,w,z,order="lex")
satelim=[f.as_expr() for f in sat.polys if not f.as_expr().has(h)]
satgb=s.groebner(satelim,t,u,v,w,z)
for n,f in enumerate(satelim):zero(f"saturation_in_J_{n}",gbJ.reduce(f)[1])
for n,f in enumerate(Jid):zero(f"J_in_saturation_{n}",satgb.reduce(f)[1])

# Embedded module N=J/I is B/(v)(-2), generated by t^2.
for name,f in {"t":t,"u":u,"v":v}.items():
    zero(f"embedded_annihilator_{name}",gbI.reduce(f*t*t)[1])
zero("embedded_squarezero",gbI.reduce(t**4)[1])

# B=C[v,w,z]-presentation of R/J: generators 1,u,t,tu,u^2,
# with exactly one homogeneous relation of total degree3.
basis=[s.Integer(1),u,t,t*u,u*u]
relation=s.Matrix([0,0,s.Rational(2,3)*v*v,-s.Rational(4,3)*w,v])
zero("primary_B_module_relation",gbJ.reduce(sum(c*f for c,f in zip(relation,basis)))[1])
ck("primary_relation_primitive",s.gcd(s.gcd(v*v,w),v)==1)
tmul=[t,t*u,0,0,0]
umul=[u,u*u,t*u,0,-s.Rational(2,3)*v*t*u]
for n,f in enumerate(basis):
    zero(f"primary_module_t_action_{n}",gbJ.reduce(t*f-tmul[n])[1])
    zero(f"primary_module_u_action_{n}",gbJ.reduce(u*f-umul[n])[1])
zero("t_preserves_primary_relation",sum(c*f for c,f in zip(relation,tmul)))
zero("u_preserves_primary_relation",sum(c*f for c,f in zip(relation,umul)))
zero("nilpotence_u4",gbJ.reduce(u**4)[1])

# Exact monomial-ideal Hilbert numerator by lcm-lattice inclusion-exclusion.
T=s.Symbol("T")
def hilbert(gb):
    mons=[tuple(p.LM(order=gb.order).exponents) for p in gb.polys]
    minimal=[m for m in mons if not any(n!=m and all(a<=b for a,b in zip(n,m)) for n in mons)]
    minimal=list(dict.fromkeys(minimal))
    numerator={}
    for mask in range(1<<len(minimal)):
        lcm=tuple(max([minimal[j][i] for j in range(len(minimal)) if mask&(1<<j)] or [0]) for i in range(5))
        degree=sum(lcm)
        numerator[degree]=numerator.get(degree,0)+(-1)**mask.bit_count()
    return s.expand(sum(c*T**deg for deg,c in numerator.items())),minimal
numI,lmI=hilbert(gbI);numJ,lmJ=hilbert(gbJ)
zero("Hilbert_numerator_I",numI-(1-6*T**3+7*T**4-2*T**5))
zero("Hilbert_primary_presentation_complete",numJ/(1-T)**5-(1+2*T+2*T**2-T**3)/(1-T)**3)
HN=T**2/(1-T)**2
zero("embedded_presentation_complete_by_Hilbert",(numI-numJ)/(1-T)**5-HN)
zero("Hilbert_zero_scheme_reduced_denominator",numI/(1-T)**5-(1+2*T+3*T**2-2*T**3)/(1-T)**3)

# Full orbit classification within the five-nonzero-coefficient triangular family.
A,Bc,C,D,Ec=s.symbols("A B C D E", nonzero=True)
Qgen=s.zeros(5)
for (r,k),f in {(1,4):A*t*t,(2,3):Bc*t*t,(2,4):C*t*u,
                 (3,4):D*t*v+Ec*u*u}.items():
    Qgen[r,k]=f;Qgen[k,r]=-f
kap=A*Ec/(C*D)
normdiag=s.diag(1,1,3*D/(2*Ec),9*C*D/(8*Ec**2),-27*Bc*D/(4*Ec**2))
normscale=-243*Bc*C*D**2/(32*Ec**3)
Qnorm=Qgen.subs({A:8*kap/9,Bc:-s.Rational(2,9),C:s.Rational(4,3),D:s.Rational(2,3),Ec:1},simultaneous=True)
normY=normdiag*s.Matrix(xx)
normdelta=normdiag*Qgen*normdiag.T-normscale*Qnorm.subs(dict(zip(xx,normY)),simultaneous=True)
for r,k in pairs:zero(f"family_normalization_{r}{k}",normdelta[r,k])
At,Bt,Ct,Dtar,Et,sc=s.symbols("At Bt Ct Dt Et scale",nonzero=True)
# Transformation rules from the five leading coefficients in the proof.
rules={At:a*jj*A/sc,Bt:cc*ff*Bc/sc,Ct:cc*jj*C/(sc*a),
       Dtar:ff*jj*D/(sc*cc),Et:ff*jj*Ec/(sc*a*a)}
zero("family_invariant",(At*Et/(Ct*Dtar)).subs(rules,simultaneous=True)-kap)
K=s.Symbol("K",nonzero=True)
Gfamily=G.copy()
Gfamily[4,3]=s.Rational(9,2)*K*a*a*b-6*a**3*al
Gfamily[4,2]=3*a*a*be-s.Rational(9,2)*a*a*al**2-s.Rational(9,2)*K*a*d+s.Rational(9,4)*K*b*b+(s.Rational(27,4)*K-3)*a*b*al
Qfamily=Q.copy();Qfamily[1,4]=K*t*t;Qfamily[4,1]=-K*t*t
fy=Gfamily*s.Matrix(xx)
fd=Gfamily*Qfamily*Gfamily.T-a**5*Qfamily.subs(dict(zip(xx,fy)),simultaneous=True)
for r,k in pairs:zero(f"family_full_stabilizer_{r}{k}",fd[r,k])

report={"all_passed":all(checks.values()),"check_count":len(checks),"checks":checks,
 "coordinates":["t","u","v","w","z"],
 "Q":{f"{i}{j}":str(Q[i,j]) for i,j in pairs},
 "F":str(s.expand(F)),
 "Darboux_shear":[str(f) for f in shear],
 "Darboux_triangular":[str(f) for f in tri],
 "full_stabilizer_matrix":[[str(e) for e in row] for row in G.tolist()],
 "stabilizer_parameters":["a!=0","b","d","g","alpha","beta","gamma","delta"],
 "tensor_scale":"a^5","projective_stabilizer":"Gm semidirect connected unipotent group of dimension7",
 "zero_cubics":{k:str(f) for k,f in Z.items()},
 "zero_ideal":[str(f) for f in I],"primary_fourfold_plane":[str(f) for f in Jid],
 "primary_B_module_relation":[str(f) for f in relation],
 "primary_B_module_generator_degrees":[0,1,1,2,2],
 "embedded_module":"C[w,z](-2), generated by t^2; squarezero",
 "initial_monomials_I":lmI,"initial_monomials_J":lmJ,
 "Hilbert_numerator_over_5vars":str(numI),
 "Hilbert_zero_scheme":"(1+2T+3T^2-2T^3)/(1-T)^3",
 "Hilbert_primary_plane":"(1+2T+2T^2-T^3)/(1-T)^3",
 "Hilbert_embedded_module":"T^2/(1-T)^2",
 "Hilbert_polynomial_zero_scheme":"2*n^2+4*n-1",
 "Hilbert_polynomial_primary_plane":"2*n^2+3*n",
 "Hilbert_polynomial_embedded_module":"n-1",
 "associated_primes":["(t,u)","(t,u,v)"],
 "family_invariant":"kappa=A*E/(C*D), all five coefficients nonzero",
 "family_normalization_diagonal":[str(normdiag[k,k]) for k in range(5)],
 "family_normalization_scale":str(normscale),
 "family_normal_form":"(A,B,C,D,E)=(8*kappa/9,-2/9,4/3,2/3,1)",
 "family_stabilizer":[[str(f) for f in row] for row in Gfamily.tolist()],
 "caveat":"Ass, saturation, and presentation completeness follow by the written exact module argument; no claim of local Jacobi component exhaustion."}
(HERE/"endpoint_geometry_certificate.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({"all_passed":True,"checks":len(checks),"Hilbert":report["Hilbert_zero_scheme"],"stabilizer":report["projective_stabilizer"]},indent=2))

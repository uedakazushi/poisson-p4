"""Exact zero-scheme stratification for Q_K, independent of tangent data."""
from pathlib import Path
from itertools import combinations
import json
import sympy as s

HERE=Path(__file__).resolve().parent
t,u,v,w,z,K,T=s.symbols('t u v w z K T')
x=(t,u,v,w,z)
Q=s.zeros(5)
for (i,j),f in {(1,4):K*t*t,(2,3):-s.Rational(2,9)*t*t,
                (2,4):s.Rational(4,3)*t*u,(3,4):s.Rational(2,3)*t*v+u*u}.items():
    Q[i,j]=f;Q[j,i]=-f
Z={f'{i}{j}{k}':s.expand(x[i]*Q[j,k]-x[j]*Q[i,k]+x[k]*Q[i,j])
   for i,j,k in combinations(range(5),3)}
checks={}
def ck(name,b):
    checks[name]=bool(b)
    if not b:raise AssertionError(name)
def zero(name,f):ck(name,s.cancel(s.expand(f))==0)
def hilbert(gb):
    mons=[tuple(p.LM(order=gb.order).exponents) for p in gb.polys]
    ans=0
    for mask in range(1<<len(mons)):
        deg=sum(max([mons[j][i] for j in range(len(mons)) if mask&(1<<j)] or [0]) for i in range(5))
        ans+=(-1)**mask.bit_count()*T**deg
    return s.cancel(ans/(1-T)**5)

# This factor is the only parameter denominator in the generic ideal derivation.
zero('only_exception_factor',s.Rational(4,3)*Z['034']-Z['124']-(K+s.Rational(8,9))*t*t*v)
Igen=[t**3,t*t*u,t*t*v,t*u*u,u**3+s.Rational(2,3)*t*u*v-K*t*t*w,
      u*u*v+s.Rational(2,3)*t*v*v-s.Rational(4,3)*t*u*w-s.Rational(2,9)*t*t*z]
gg=s.groebner(Igen,*x,order='grevlex',domain=s.QQ.frac_field(K))
for name,f in Z.items():zero('generic_zero_ideal_'+name,gg.reduce(f)[1])
HG=hilbert(gg)
zero('generic_Hilbert',HG-(1+2*T+3*T*T-2*T**3)/(1-T)**3)

# The exceptional point K=-8/9.
k0=-s.Rational(8,9)
Isp=[t**3,t*t*u,t*u*u+s.Rational(2,3)*t*t*v,
     u**3+s.Rational(2,3)*t*u*v+s.Rational(8,9)*t*t*w,
     u*u*v+s.Rational(2,3)*t*v*v-s.Rational(4,3)*t*u*w-s.Rational(2,9)*t*t*z]
gs=s.groebner(Isp,*x,order='grevlex')
gz=s.groebner([f.subs(K,k0) for f in Z.values()],*x,order='grevlex')
for n,f in enumerate(Isp):zero(f'special_in_projective_zeros_{n}',gz.reduce(f)[1])
for name,f in Z.items():zero('special_projective_zeros_'+name,gs.reduce(f.subs(K,k0))[1])
HS=hilbert(gs)
zero('special_Hilbert',HS-(1+2*T+3*T*T-T**3)/(1-T)**3)
basis=[s.Integer(1),u,t,t*u,u*u,t*t]
rel=[0,0,s.Rational(2,3)*v*v,-s.Rational(4,3)*w,v,-s.Rational(2,9)*z]
zero('special_module_relation',gs.reduce(sum(a*b for a,b in zip(rel,basis)))[1])
ck('primitive_relation',s.gcd(s.gcd(s.gcd(v*v,w),v),z)==1)
tmul=[t,t*u,t*t,0,-s.Rational(2,3)*v*t*t,0]
umul=[u,u*u,t*u,-s.Rational(2,3)*v*t*t,
      -s.Rational(2,3)*v*t*u-s.Rational(8,9)*w*t*t,0]
for n,b in enumerate(basis):
    zero(f't_action_{n}',gs.reduce(t*b-tmul[n])[1])
    zero(f'u_action_{n}',gs.reduce(u*b-umul[n])[1])
zero('t_relation_stable',sum(a*b for a,b in zip(rel,tmul)))
zero('u_relation_stable',sum(a*b for a,b in zip(rel,umul)))
zero('nilpotence_t3',gs.reduce(t**3)[1])
zero('nilpotence_u5',gs.reduce(u**5)[1])
zero('module_presentation_complete_by_Hilbert',HS-(1+2*T+3*T*T-T**3)/(1-T)**3)
# Coefficients generate the irrelevant ideal of B, hence the presentation
# is locally split on Proj(B), giving a finite flat degree5 plane thickening.
gcoef=s.groebner([q for q in rel if q!=0],v,w,z)
for n,q in enumerate((v,w,z)):zero(f'coefficient_ideal_irrelevant_{n}',gcoef.reduce(q)[1])

out={'all_passed':all(checks.values()),'check_count':len(checks),'checks':checks,
     'normal_form_parameter':'A=K,B=-2/9,C=4/3,D=2/3,E=1; kappa=9K/8',
     'generic_exception':'K=-8/9, equivalently kappa=-1',
     'generic_ideal':[str(f) for f in Igen],
     'generic_Hilbert':'(1+2T+3T^2-2T^3)/(1-T)^3',
     'generic_description':'primary fourfold plane plus embedded line, as endpoint K=1',
     'special_ideal':[str(f) for f in Isp],
     'special_Hilbert':'(1+2T+3T^2-T^3)/(1-T)^3',
     'special_Hilbert_polynomial':'5*n*(n+1)/2',
     'special_module_generators':[str(f) for f in basis],
     'special_module_relation':[str(f) for f in rel],
     'special_description':'(t,u)-primary fivefold plane, finite flat degree5 over P^2; no embedded associated prime',
     'proof_note':'Primaryness follows from primitive relation over B=C[v,w,z] and t,u nilpotent, exactly as endpoint proof. Projective Cohen-Macaulayness follows from coefficient ideal(v,w,z).',
     'tangent_comparison':'Independent obstruction certificate gives projective tangent50 at kappa=-1; tangent jump occurs instead at kappa=1/4.'}
(HERE/'family_zero_scheme_certificate.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'all_passed':out['all_passed'],'check_count':len(checks),'special_kappa':-1},indent=2))

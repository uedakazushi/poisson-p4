import sys,json,time
sys.path.insert(0,'code')
import sympy as s
from itertools import combinations_with_replacement
from s61_local_cubic_certificate_20261101 import profile
r=json.load(open('reports/S61_R0_MIXED_ORBIT_REDUCTION_20261101.json'));out={}
for label in ['T7','T5']:
 st=time.time();case=r['orbits'][label];point=s.Matrix(case['point61']).applyfunc(s.Rational);loc=profile(point);J=s.Matrix(loc['local']['jacobian']).applyfunc(s.Rational);T=s.Matrix(loc['local']['tangent_basis']).applyfunc(s.Rational);BD=s.Matrix(case['source_beta_differential']).applyfunc(s.Rational);QD=s.Matrix(case['q_orbit_differential']).applyfunc(s.Rational);H=s.Matrix(case['beta_kernel']).applyfunc(s.Rational);C=s.zeros(44,H.cols).row_join(QD)*s.Matrix.hstack(*BD.nullspace());cp=list(C.to_DM().rref()[1]);assert len(cp)==2;C=C[:,cp].col_join(s.zeros(1,2));rr=list(T.T.to_DM().rref()[1]);CT=T[rr,:].inv()*C[rr,:];assert T*CT==C;params=list(CT.T.to_DM().rref()[1]);assert len(params)==2
 v=s.symbols('v:'+str(T.cols));remaining=[v[i] for i in range(T.cols) if i not in params];forms=list(map(s.sympify,loc['initial_quadrics']+loc['initial_cubics']));gb=s.groebner([s.expand(f.subs({v[i]:0 for i in params})) for f in forms],*remaining,order='grevlex');counts=[]
 if gb.is_zero_dimensional:
  lead=[f.LM(order=gb.order).exponents for f in gb.polys]
  for d in range(25):
   exps=[tuple(mon.count(i) for i in range(len(remaining))) for mon in combinations_with_replacement(range(len(remaining)),d)];count=sum(not any(all(a<=b for a,b in zip(l,e)) for l in lead) for e in exps);counts.append(count)
   if not count:break
 print(label,'params',params,'C',CT,'transverse',counts,sum(counts),list(gb),time.time()-st,flush=True);out[label]=dict(local=loc,parameter_rows=params,actual_surface_tangent=[[str(v) for v in row] for row in CT.tolist()],transverse_counts=counts,transverse_bound=sum(counts),groebner=list(map(str,gb)),seconds=time.time()-st);json.dump(out,open('work/r0-mixed-surface-probe.json','w'),indent=2)

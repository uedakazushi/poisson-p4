import sys,json,time
sys.path.insert(0,'code')
import sympy as s
from itertools import combinations_with_replacement
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
r=json.load(open('work/r0-mixed-surface-probe.json'));m=S61();one=[i for i,w in enumerate(m.reduced['parameter_weights']) if w==1];out={}
for label in ['T7','T5']:
 start=time.time();case=r[label];loc=case['local']['local'];point=s.Matrix(loc['point61']).applyfunc(s.Rational);_,F=specialize(m,{i:point[i] for i in one},True);cols=loc['chart_columns'];fixed=next(i for i in range(45) if i not in cols);J=s.Matrix(loc['jacobian']).applyfunc(s.Rational);T=s.Matrix(loc['tangent_basis']).applyfunc(s.Rational);normal=[i for i in range(T.cols) if i not in case['parameter_rows']];T=T[:,normal];n=T.cols;R=list(J.T.to_DM().rref()[1]);C=list(J.to_DM().rref()[1]);U=s.zeros(45,len(R));inv=J[R,C].inv(method='DM')
 for k,c in enumerate(C):U[c,:]=inv[k,:]
 JU=J*U;ms={d:list(combinations_with_replacement(range(n),d)) for d in range(1,9)};index={d:{mon:i for i,mon in enumerate(ms[d])} for d in ms};W={1:T};A={};terms=[]
 for f in F:
  terms.append([([cols.index(i) for i in mon]+[44]*(2-len(mon)),coef) for mon,coef in f.items() if fixed not in mon])
 v=s.symbols('v:'+str(n));gens=[];stats=[]
 for degree in range(2,9 if n==1 else 6):
  Q=s.zeros(135,len(ms[degree]))
  for row,ts in enumerate(terms):
   for (i,j),coef in ts:
    for a in range(1,degree):
     b=degree-a
     for k,ma in enumerate(ms[a]):
      if not W[a][i,k]:continue
      for l,mb in enumerate(ms[b]):
       if W[b][j,l]:Q[row,index[degree][tuple(sorted(ma+mb))]]+=coef*W[a][i,k]*W[b][j,l]
  A[degree]=Q-JU*Q[R,:];W[degree]=-U*Q[R,:]
  # Form the truncated actual ideal and its initial degree-d consequence space.
  mons=sum([ms[d] for d in range(2,degree+1)],[]);ix={mon:i for i,mon in enumerate(mons)};base=s.Matrix.hstack(*[A[d] for d in range(2,degree+1)]);rows=[]
  for row in base.tolist():
   if not any(row):continue
   for md in range(degree-1):
    mults=[()] if md==0 else ms[md]
    for mul in mults:
     rr=[s.S.Zero]*len(mons)
     for c,mon in zip(row,mons):
      if c and len(mon+mul)<=degree:rr[ix[tuple(sorted(mon+mul))]]+=c
     if any(rr):rows.append(rr)
  if rows:
   MM=s.Matrix(rows);lo=MM[:,:len(mons)-len(ms[degree])];hi=MM[:,len(mons)-len(ms[degree]):];pr=list(lo.T.to_DM().rref()[1]);pc=list(lo.to_DM().rref()[1]);rel=hi-lo[:,pc]*lo[pr,pc].inv(method='DM')*hi[pr,:];dr=list(rel.T.to_DM().rref()[1]);new=[s.expand(sum(c*s.prod(v[i] for i in mon) for c,mon in zip(row,ms[degree]))) for row in rel[dr,:].tolist()];gens+=new
  else:dr=[]
  gb=s.groebner(gens,*v,order='grevlex') if gens else None;counts=[]
  if gb is not None and gb.is_zero_dimensional:
   lead=[f.LM(order=gb.order).exponents for f in gb.polys]
   for d in range(20):
    exps=[tuple(mon.count(i) for i in range(n)) for mon in combinations_with_replacement(range(n),d)];count=sum(not any(all(a<=b for a,b in zip(l,e)) for l in lead) for e in exps);counts.append(count)
    if not count:break
  info=dict(degree=degree,initial_rank=len(dr),transverse_counts=counts,length=sum(counts),homogenizer=list(map(str,W[degree][-1,:])),seconds=time.time()-start);stats.append(info);print(label,info,flush=True)
  if counts:break
 out[label]=dict(stats=stats,initial_generators=list(map(str,gens)));json.dump(out,open('work/r0-mixed-transverse-series.json','w'),indent=2)

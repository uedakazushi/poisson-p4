from pathlib import Path
import sympy as s,json,time
w=Path('work/nonsquare-v62/quad78-pencil-pseudo-v84');start=time.monotonic();t,H,v=s.symbols('t H v');load=lambda terms,vars:s.Poly(sum(s.Rational(c)*s.prod(z**k for z,k in zip(vars,ex))for ex,c in terms),*vars,domain=s.QQ);d=json.loads((w/'leading-coefficients.json').read_text());lead=[load(d[key],(H,v)).as_expr()for key in ['LC','MID','CONST']];profile=json.loads(Path('work/nonsquare-v62/quad78-small-gates-v83/pencil-profile.json').read_text());coeff=[load(q,(t,v,H)).as_expr()for q in profile['normalized_pencil_coefficients']];branches=[]
for vv in [s.Integer(-3),-s.Rational(4,3)]:
 polys=[s.Poly(q.subs(v,vv),H,domain=s.QQ)for q in lead];g=s.Poly(0,H,domain=s.QQ)
 for q in polys:g=s.gcd(g,q)
 print('LCMIDCONST branch',vv,'gcdH',s.factor(g.as_expr()),flush=True)
 if g.degree()<=0:branches.append(dict(v=str(vv),gcdH=str(g.as_expr()),no_points=True));continue
 tcoeff=[];records=[]
 for i in [1,2,3]:
  q=s.Poly(coeff[i].subs(v,vv),t);cs=[s.Poly(c,H,domain=s.QQ)for c in q.all_coeffs()]
  for j,c in enumerate(cs):tcoeff.append(c);records.append([i,q.degree()-j])
 totalg=g
 for q in tcoeff:totalg=s.gcd(totalg,q)
 print('all higher t-coefficients gcdH',s.factor(totalg.as_expr()),flush=True)
 branches.append(dict(v=str(vv),leading_polynomials=[str(q.as_expr())for q in polys],gcdH=str(g.as_expr()),higher_coefficients=[str(q.as_expr())for q in tcoeff],higher_coefficient_labels=records,all_identically_zero_gcdH=str(totalg.as_expr()),finite_t_fibers=totalg.degree()==0))
(w/'leading-special-branches.json').write_text(json.dumps(dict(branches=branches,seconds=time.monotonic()-start,finite_all_leading_zero_branch=all(x.get('no_points')or x.get('finite_t_fibers')for x in branches)),indent=2)+'\n')

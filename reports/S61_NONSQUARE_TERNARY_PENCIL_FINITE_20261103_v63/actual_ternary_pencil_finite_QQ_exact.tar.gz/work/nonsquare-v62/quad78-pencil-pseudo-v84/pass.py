from pathlib import Path
import sympy as s,json,time,resource,signal,itertools
resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024))
w=Path('work/nonsquare-v62/quad78-pencil-pseudo-v84');start=time.monotonic();t,H,v=s.symbols('t H v');source=json.loads(Path('work/nonsquare-v62/quad78-small-gates-v83/pencil-profile.json').read_text());load=lambda ts:s.Poly(sum(s.Rational(c)*t**ex[0]*v**ex[1]*H**ex[2]for ex,c in ts),t,H,v,domain=s.QQ);C=list(map(load,source['normalized_pencil_coefficients']));base=s.QQ.poly_ring(H,v);p0=s.Poly(C[0].as_expr(),t,domain=base);LC=s.Poly(p0.LC(),H,v,domain=s.QQ);MID=s.Poly(p0.coeff_monomial(t),H,v,domain=s.QQ);CONST=s.Poly(p0.coeff_monomial(1),H,v,domain=s.QQ);J=s.Poly(5*H-2*v-4,H,v,domain=s.QQ);records=[];bounds=[]
def timeout(signum,frame):raise TimeoutError('60 second authorized cap')
signal.signal(signal.SIGALRM,timeout);signal.setitimer(signal.ITIMER_REAL,60)
def encode(poly,vars):
 p=s.Poly(poly,*vars,domain=s.QQ);z=[[list(ex),str(c)]for ex,c in p.terms()];n=len(json.dumps(z,separators=(',',':')).encode());bounds.append(n)
 if n>1_000_000:raise RuntimeError('expanded polynomial exceeds1MB cap')
 return z
def save():
 (w/'progress.json').write_text(json.dumps(dict(records=records,seconds=time.monotonic()-start,largest_expanded_serialized_polynomial_bytes=max(bounds,default=0)),indent=2)+'\n')
def primitive_hv(q,units):
 content,q=s.Poly(q,H,v,domain=s.QQ).primitive();powers=[]
 for u in units:
  n=0
  while not q.is_zero:
   z,r=q.div(u)
   if r:break
   q=z;n+=1
  powers.append(n)
 return q,str(content),powers
try:
 encode(p0.as_expr(),(t,H,v));lead=dict(LC=encode(LC.as_expr(),(H,v)),MID=encode(MID.as_expr(),(H,v)),CONST=encode(CONST.as_expr(),(H,v)),LC_factored=str(s.factor(LC.as_expr())),LC_zero_case_retained=True);(w/'leading-coefficients.json').write_text(json.dumps(lead,indent=2)+'\n');print('C0_LEADING',lead['LC_factored'],flush=True)
 rems=[];ab=[]
 for i in [1,2,3]:
  ci=s.Poly(C[i].as_expr(),t,domain=base);qq,rr=ci.pdiv(p0);power=ci.degree()-p0.degree()+1;assert s.Poly(LC.as_expr()**power*ci.as_expr()-qq.as_expr()*p0.as_expr()-rr.as_expr(),t,H,v,domain=s.QQ).is_zero
  raw=encode(rr.as_expr(),(t,H,v));quot=encode(qq.as_expr(),(t,H,v));r=s.Poly(rr.as_expr(),t,H,v,domain=s.QQ);content,r=r.primitive();vals=[]
  for unit in [s.Poly(t,t,H,v),s.Poly(H-8*t,t,H,v),s.Poly(J.as_expr(),t,H,v),s.Poly(LC.as_expr(),t,H,v)]:
   n=0
   while not r.is_zero:
    z,tail=r.div(unit)
    if tail:break
    r=z;n+=1
   vals.append(n)
  pt=s.Poly(r.as_expr(),t);assert pt.degree()<=1;alpha=s.Poly(pt.coeff_monomial(t),H,v,domain=s.QQ);beta=s.Poly(pt.coeff_monomial(1),H,v,domain=s.QQ);ab.append((alpha,beta));rems.append(r)
  item=dict(source_index=i,pseudo_quotient=quot,pseudo_remainder=raw,LC_power=power,QQcontent=str(content),removed_units_t_P_J_LC=vals,normalized_remainder=encode(r.as_expr(),(t,H,v)),terms=len(r.terms()),degrees_t_H_v=[r.degree(x)for x in (t,H,v)]);(w/f'remainder-{i}.json').write_text(json.dumps(item,indent=2)+'\n');records.append({k:item[k]for k in ['source_index','terms','degrees_t_H_v','removed_units_t_P_J_LC']});save();print('REMAINDER',json.dumps(records[-1]),flush=True)
 candidates=[]
 for i,j in itertools.combinations(range(3),2):
  q=ab[i][0]*ab[j][1]-ab[j][0]*ab[i][1];q,content,powers=primitive_hv(q,[J,LC]);candidates.append(q);(w/f'eliminate-t-{i}-{j}.json').write_text(json.dumps(dict(polynomial=encode(q.as_expr(),(H,v)),QQcontent=content,removed_J_LC=powers),indent=2)+'\n');print('ELIM',i,j,'terms',len(q.terms()),'degrees',[q.degree(H),q.degree(v)],flush=True)
 for i,(alpha,beta)in enumerate(ab):
  q=LC*beta*beta-MID*alpha*beta+CONST*alpha*alpha;q,content,powers=primitive_hv(q,[J,LC]);candidates.append(q);(w/f'root-norm-{i}.json').write_text(json.dumps(dict(polynomial=encode(q.as_expr(),(H,v)),QQcontent=content,removed_J_LC=powers),indent=2)+'\n');print('NORM',i,'terms',len(q.terms()),'degrees',[q.degree(H),q.degree(v)],flush=True)
 g=s.Poly(0,H,v,domain=s.QQ)
 for i,q in enumerate(candidates):
  g=s.gcd(g,q);records.append(dict(generic_projection_gcd_through=i,terms=len(g.terms()),polynomial=encode(g.as_expr(),(H,v))));save();print('GENERIC_GCD',i,'degree',g.total_degree(),'factor',s.factor(g.as_expr())if g.total_degree()<8 else'(retained)',flush=True)
 generic_gcd=g
 # LC=0, MID!=0: the actual C0 becomes linear; a scalar pseudo-remainder is necessary.
 linear=s.Poly(MID.as_expr()*t+CONST.as_expr(),t,domain=base)
 q1,r1=s.Poly(C[1].as_expr(),t,domain=base).pdiv(linear);assert s.degree(r1.as_expr(),t)<=0;lin,scontent,spowers=primitive_hv(r1.as_expr(),[J,MID]);linear_gcd=s.gcd(LC,lin)
 (w/'LC-zero-MID-nonzero.json').write_text(json.dumps(dict(LC=encode(LC.as_expr(),(H,v)),linear_pseudo_remainder=encode(lin.as_expr(),(H,v)),quotient=encode(q1.as_expr(),(t,H,v)),gcd_LC_remainder=encode(linear_gcd.as_expr(),(H,v)),removed_J_MID=spowers,QQcontent=scontent),indent=2)+'\n');print('LC_ZERO_MID_NONZERO_GCD',s.factor(linear_gcd.as_expr()),flush=True)
 # LC=MID=0 requires CONST=0; exact unary resultant gcd is a necessary point cover.
 R1=s.Poly(s.resultant(LC.as_expr(),MID.as_expr(),H),v,domain=s.QQ);R2=s.Poly(s.resultant(LC.as_expr(),CONST.as_expr(),H),v,domain=s.QQ);Rg=s.gcd(R1,R2)
 (w/'LC-MID-zero.json').write_text(json.dumps(dict(resultant_LC_MID=encode(R1.as_expr(),(v,)),resultant_LC_CONST=encode(R2.as_expr(),(v,)),unary_gcd=encode(Rg.as_expr(),(v,)),LC_H_leading=str(s.Poly(LC.as_expr(),H).LC()),all_zero_polynomial_t_case_excluded=Rg.degree()==0),indent=2)+'\n');print('LC_MID_CONST_ZERO_RESULTANT_GCD',s.factor(Rg.as_expr()),flush=True)
 result=dict(completed=True,seconds=time.monotonic()-start,generic_LC_nonzero_projection_gcd=str(s.factor(generic_gcd.as_expr())),LC_zero_MID_nonzero_projection_gcd=str(s.factor(linear_gcd.as_expr())),LC_MID_CONST_zero_resultant_gcd=str(s.factor(Rg.as_expr())),finite_necessary_locus_proved=(generic_gcd.total_degree()==0 and linear_gcd.total_degree()==0 and Rg.degree()==0),QQ_finiteness_membership_certificates_not_yet_frozen=True,no_quad78_claim=True,largest_expanded_serialized_polynomial_bytes=max(bounds));(w/'result.json').write_text(json.dumps(result,indent=2)+'\n');save();print(json.dumps(result),flush=True)
except Exception as exc:
 result=dict(completed=False,seconds=time.monotonic()-start,exception=type(exc).__name__,reason=str(exc),largest_expanded_serialized_polynomial_bytes=max(bounds,default=0),no_negative_QQ_or_quad78_claim=True);(w/'result.json').write_text(json.dumps(result,indent=2)+'\n');save();print(json.dumps(result),flush=True)
finally:signal.setitimer(signal.ITIMER_REAL,0)

from pathlib import Path
import sympy as s,json,time,resource
resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024));w=Path('work/nonsquare-v62/quad78-pencil-pseudo-v84');start=time.monotonic();t,H,v=s.symbols('t H v');load=lambda ts,vs:s.Poly(sum(s.Rational(c)*s.prod(z**k for z,k in zip(vs,ex))for ex,c in ts),*vs,domain=s.QQ)
def enc(q,vs):
 out=[[list(ex),str(c)]for ex,c in s.Poly(q,*vs,domain=s.QQ).terms()];assert len(json.dumps(out).encode())<1_000_000;return out
def gcdcert(polys,var):
 g=s.Poly(0,var,domain=s.QQ);cofs=[]
 for q in polys:
  if q.is_zero:cofs.append(s.Poly(0,var,domain=s.QQ));continue
  if g.is_zero:
   cofs.append(s.Poly(1/q.LC(),var,domain=s.QQ));g=q.monic();continue
  a,b,h=s.gcdex(g,q);cofs=[s.Poly(c*a,var,domain=s.QQ)for c in cofs]+[s.Poly(b,var,domain=s.QQ)];g=s.Poly(h,var,domain=s.QQ)
 assert sum((c*q for c,q in zip(cofs,polys)),s.Poly(0,var,domain=s.QQ))==g
 return g,cofs
def coprime_certificate(F,G):
 F=s.Poly(F,H,v,domain=s.QQ);G=s.Poly(G,H,v,domain=s.QQ);coeff=[];labels=[]
 for i,poly in enumerate([F,G]):
  ph=s.Poly(poly.as_expr(),H)
  for j,c in enumerate(ph.all_coeffs()):coeff.append(s.Poly(c,v,domain=s.QQ));labels.append([i,ph.degree()-j])
  gg,cofs=gcdcert(coeff,v)
  if gg.degree()==0:break
 assert gg==s.Poly(1,v,domain=s.QQ)
 certificate=dict(F=enc(F.as_expr(),(H,v)),G=enc(G.as_expr(),(H,v)),coefficient_labels=labels,coefficient_content_Bezout=[enc(c.as_expr(),(v,))for c in cofs])
 for vv in [0,1,2,3]:
  f=s.Poly(F.as_expr().subs(v,vv),H,domain=s.QQ);g=s.Poly(G.as_expr().subs(v,vv),H,domain=s.QQ)
  if f.degree()!=F.degree(H)or g.degree()!=G.degree(H):continue
  a,b,h=s.gcdex(f,g)
  if h!=s.Poly(1,H,domain=s.QQ):continue
  certificate.update(special_v=vv,F_H_degree=F.degree(H),G_H_degree=G.degree(H),F_H_leading_at_v=str(f.LC()),G_H_leading_at_v=str(g.LC()),specialized_QQ_Bezout=[enc(a.as_expr(),(H,)),enc(b.as_expr(),(H,))]);return certificate
 raise RuntimeError('No chosen small good specialization; retain as unresolved')
N1=load(json.loads((w/'eliminate-t-0-1.json').read_text())['polynomial'],(H,v));N2=load(json.loads((w/'eliminate-t-0-2.json').read_text())['polynomial'],(H,v));generic=coprime_certificate(N1.as_expr(),N2.as_expr());print('GENERIC_PROJECTION_COPRIMALITY_CERTIFICATE_PASS',time.monotonic()-start,flush=True)
leading=json.loads((w/'leading-coefficients.json').read_text());A,B,C=[load(leading[key],(H,v))for key in ['LC','MID','CONST']];lcdata=json.loads((w/'LC-zero-MID-nonzero.json').read_text());linear=coprime_certificate(A.as_expr(),load(lcdata['linear_pseudo_remainder'],(H,v)).as_expr());print('LEADING_ZERO_MID_UNIT_COPRIMALITY_PASS',time.monotonic()-start,flush=True)
zero=json.loads((w/'LC-MID-zero.json').read_text());R1=load(zero['resultant_LC_MID'],(v,));R2=load(zero['resultant_LC_CONST'],(v,));u,z,g=s.gcdex(R1,R2);assert g==s.Poly((v+3)*(3*v+4)/3,v,domain=s.QQ)
profile=json.loads(Path('work/nonsquare-v62/quad78-small-gates-v83/pencil-profile.json').read_text());ci=[load(q,(t,v,H)).as_expr()for q in profile['normalized_pencil_coefficients']];branches=[]
for vv in [s.Integer(-3),-s.Rational(4,3)]:
 leadpolys=[s.Poly(p.as_expr().subs(v,vv),H,domain=s.QQ)for p in [A,B,C]];gh,wh=gcdcert(leadpolys,H);assert gh.degree()==1;hh=-gh.coeff_monomial(1)/gh.coeff_monomial(H);higher=[s.Poly(q.subs({v:vv,H:hh}),t,domain=s.QQ)for q in ci[1:]];gt,wt=gcdcert(higher,t);assert gt==s.Poly(1,t,domain=s.QQ)
 branches.append(dict(v=str(vv),forced_H=str(hh),leading_H_polynomial=enc(gh.as_expr(),(H,)),leading_Bezout=[enc(q.as_expr(),(H,))for q in wh],higher_t_polynomials=[enc(q.as_expr(),(t,))for q in higher],higher_t_Bezout=[enc(q.as_expr(),(t,))for q in wt]))
cert=dict(generic_LC_nonzero_projection=generic,LC_zero_MID_nonzero_projection=linear,LC_MID_zero_case=dict(resultant_R1=enc(R1.as_expr(),(v,)),resultant_R2=enc(R2.as_expr(),(v,)),resultant_gcd_Bezout=[enc(u.as_expr(),(v,)),enc(z.as_expr(),(v,))],resultant_gcd=enc(g.as_expr(),(v,)),special_branches=branches),all_coprimality_and_case_certificates_exact=True,seconds=time.monotonic()-start)
(w/'finite-certificate.json').write_text(json.dumps(cert,indent=2)+'\n');print('ALL_BRANCHES_FINITE_OR_EMPTY_QQ_PASS',time.monotonic()-start,flush=True)

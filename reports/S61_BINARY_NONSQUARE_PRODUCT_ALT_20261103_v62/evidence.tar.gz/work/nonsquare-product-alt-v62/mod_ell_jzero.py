from pathlib import Path
import sympy as s,itertools,time,subprocess,json
from sympy.polys.rings import ring
namespace={};z=Path('work/nonsquare-product-alt-v62/mod_ell_build.py').read_text().split('records=[]')[0];exec(z,namespace)
q4=namespace['q4'];bc=namespace['bc'];known=namespace['known'];base=namespace['base']
R2,aa,ee=ring('a,e',s.QQ);K2=R2.to_field();ak,ek=K2(aa),K2(ee);dk=(6*ek+4)/(5*ak)
T2,*y=ring('x0,x1,x2,x3,x4,x5,x6',K2)
def convert(c,corner):
 value=K2.zero
 for mon,co in c.items():
  if corner and mon[2]:continue
  term=K2(co)*ak**mon[0]
  term*= (K2(-s.Rational(2,3)) if corner else ek)**mon[1]
  if not corner and mon[2]:term*=dk**mon[2]
  value+=term
 return value
for corner in [False,True]:
 name='corner'if corner else'jzero';pivot=0 if corner else 2
 bs=[convert(c,corner)for c in bc];g=bs[pivot];tail=sum((T2(bs[j])*y[j]for j in range(7)if j!=pivot),T2.zero)
 kfactors=[]
 for q in known:
  value=convert(q,corner);assert value
  for poly in [value.numer,value.denom]:
   for f,power in s.factor_list(poly.as_expr(),*R2.symbols)[1]:
    r=R2.from_expr(f)
    if r not in kfactors:kfactors.append(r)
 if not corner:
  for f,power in s.factor_list(g.numer.as_expr(),*R2.symbols)[1]:
   r=R2.from_expr(f)
   if r not in kfactors:kfactors.append(r)
 unitpath=base/(name+'-units.txt');unitpath.write_text('\n'.join(str(f).replace('**','^')for f in kfactors)+'\n')
 quadrics=[]
 for q in q4:
  out=T2.zero
  for mon,c in q.items():
   rp=mon[pivot];rest=list(mon);rest[pivot]=0
   out+=T2.from_dict({tuple(rest):convert(c,corner)})*((-tail/g)**rp)
  assert out
  den=R2.one
  for c in out.values():den=den.lcm(c.denom)
  den_check=den
  for f in kfactors:
   while den_check.rem(f)==0:den_check=den_check.exquo(f)
  assert den_check.is_ground
  data={m:(c*den).numer.exquo((c*den).denom)for m,c in out.items()if c}
  for f in kfactors:
   while all(c.rem(f)==0 for c in data.values()):data={m:c.exquo(f)for m,c in data.items()}
  quadrics.append(data)
 positions=[j for j in range(7)if j!=pivot];mons=sorted(tuple(triple.count(j)for j in range(7))for triple in itertools.combinations_with_replacement(positions,3));rows=[]
 for q in quadrics:
  for j in positions:
   row={tuple(m[i]+int(i==j)for i in range(7)):c for m,c in q.items()};rows.append(row)
 inputfile=base/(name+'.txt')
 with inputfile.open('w')as f:
  f.write('24 56 0\n')
  for row in rows:
   for mon in mons:
    co=row.get(mon,R2.zero);f.write(str(len(co))+''.join(' '+str(c)+' '+' '.join(map(str,ex))+' 0'for ex,c in co.items())+'\n')
 print('CASE',name,'units',kfactors,'g',g,'terms',sum(len(c)for row in rows for c in row.values()),flush=True)
 out=base/(name+'-residual.txt')
 with (base/(name+'.log')).open('w')as log:cp=subprocess.run(['work/nonsquare-product-alt-v62/unit-span-general',str(inputfile),str(out),str(unitpath),'0'],stdout=log,stderr=subprocess.STDOUT,timeout=45)
 print('NATIVE',name,cp.returncode,out.read_text().split()[:3]if cp.returncode==0 else'',flush=True)

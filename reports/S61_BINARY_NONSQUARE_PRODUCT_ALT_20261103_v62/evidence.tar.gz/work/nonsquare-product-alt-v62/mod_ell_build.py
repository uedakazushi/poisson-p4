from pathlib import Path
import sympy as s,json,time,subprocess,itertools
from sympy.polys.rings import ring
base=Path('work/nonsquare-product-alt-v62/mod-ell');base.mkdir(exist_ok=True)
R,a,e,d=ring('a,e,d',s.QQ);P,*v=ring('v0,v1,v2,v3,v4,v5,v6,v7',R);T,*x=ring('x0,x1,x2,x3,x4,x5,x6',R)
source=json.load(open('reports/S61_BINARY_HYPERPLANE_QUADRATIC_CODIMENSION_20261102.json'))
qs=[P.from_dict({tuple(m):R.from_dict({tuple(ex):s.QQ(c)for ex,c in terms})for m,terms in row})for row in source['quadratic_rows_sparse']]
ell=(-(d*e+8)*qs[1]+8*qs[2]+d*qs[3]).exquo(v[3]);assert all(not mon[5]for mon in ell)
image=[x[0],3*x[0]+x[3]-x[5],x[1],x[6],x[2],T.zero,x[3],x[4]]
def move(q):
 out=T.zero
 for mon,c in q.items():
  term=T(c)
  for power,t in zip(mon,image):
   if power:term*=t**power
  out+=term
 return out
newell=move(ell);q4=[move(qs[i])for i in [0,1,3,5]];bc=[newell.get(tuple(int(i==j)for j in range(7)),R.zero)for i in range(7)]
known=[a,500*a+90*e**2+3*e-24,(50*a+18*e**2-9*e-2)*d+60*e-40,100*a+18*e**2-9*e-2]
records=[]
for pivot in range(5):
 g=bc[pivot];assert g
 units=list(known)
 for ff,mult in s.factor_list(g.as_expr(),*R.symbols)[1]:
  z=R.from_expr(ff)
  if all(not(z.rem(f)==0 or f.rem(z)==0)for f in known):units.append(z)
 unitsfile=base/f'chart-{pivot}-units.txt';unitsfile.write_text('\n'.join(str(f).replace('**','^')for f in units)+'\n')
 tail=sum((T(bc[j])*x[j]for j in range(7)if j!=pivot),T.zero);cquads=[]
 for q in q4:
  out=T.zero
  for mon,c in q.items():
   rp=mon[pivot];rest=list(mon);rest[pivot]=0
   out+=T.from_dict({tuple(rest):c})*((-tail)**rp)*(g**(2-rp))
  assert out
  for f in units:
   while all(co.rem(f)==0 for co in out.values()):out=T.from_dict({mon:co.exquo(f)for mon,co in out.items()})
  cquads.append(out)
 positions=[j for j in range(7)if j!=pivot];mons=[]
 for triple in itertools.combinations_with_replacement(positions,3):mons.append(tuple(triple.count(j)for j in range(7)))
 mons=sorted(mons);assert len(mons)==56
 rows=[q*x[j]for q in cquads for j in positions];assert len(rows)==24
 inputfile=base/f'chart-{pivot}.txt'
 with inputfile.open('w')as f:
  f.write('24 56 0\n')
  for row in rows:
   for mon in mons:
    co=row.get(mon,R.zero);f.write(str(len(co))+''.join(' '+str(c)+' '+' '.join(map(str,ex))for ex,c in co.items())+'\n')
 record=dict(pivot=pivot,g=str(g),units=list(map(str,units)),matrix_terms=sum(len(co)for row in rows for co in row.values()),bytes=inputfile.stat().st_size)
 print('CHART',record,flush=True);out=base/f'chart-{pivot}-residual.txt';st=time.monotonic()
 try:
  with (base/f'chart-{pivot}.log').open('w')as log:cp=subprocess.run(['work/nonsquare-product-alt-v62/unit-span-general',str(inputfile),str(out),str(unitsfile),'0'],stdout=log,stderr=subprocess.STDOUT,timeout=45)
  record['returncode']=cp.returncode
  if cp.returncode==0:record['remaining_shape']=list(map(int,out.read_text().split()[:2]))
 except subprocess.TimeoutExpired:record['timed_out']=True
 record['seconds']=time.monotonic()-st;records.append(record);(base/'status.json').write_text(json.dumps(records,indent=2)+'\n');print('RESULT',record,flush=True)

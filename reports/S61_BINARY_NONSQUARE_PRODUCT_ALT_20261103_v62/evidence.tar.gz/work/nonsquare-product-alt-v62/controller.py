from pathlib import Path
import subprocess,time,json
base=Path('work/nonsquare-product-alt-v62');current=base/'after-witness.txt';unitfile=base/'product-units.txt';binary=base/'unit-span';records=[]
def parse(path):
 t=iter(path.read_text().split());n,m,k=[int(next(t))for _ in range(3)]
 for _ in range(k+n):next(t)
 rows=[];cost=[]
 for i in range(n):
  row=[];ct=0
  for j in range(m):
   terms=[];ll=int(next(t));ct+=ll
   for _ in range(ll):
    c=next(t);es=[int(next(t))for _ in range(3)];terms.append('*'.join([c]+[f'{a}^{e}'for a,e in zip(['a','e','d'],es)if e]))
   row.append('('+('+'.join(terms)or'0')+')')
  rows.append(row);cost.append(ct)
 return n,m,rows,cost
for stage in range(2,8):
 n,m,rows,cost=parse(current)
 if n==0:break
 ix=min(range(n),key=cost.__getitem__);prefix=base/f'controller-{stage}';wit=Path(str(prefix)+'-witness.txt');script=Path(str(prefix)+'.m2');out=Path(str(prefix)+'-matrix.txt')
 head='R=QQ[a,e,d];F=500*a+90*e^2+3*e-24;B=(50*a+18*e^2-9*e-2)*d+60*e-40;C=100*a+18*e^2-9*e-2;U=a*F*B*C;\nM=matrix{{'+','.join(rows[ix])+'}};\n'
 body='''G=gb image M;stderr<<toString("SCALAR_R3_GB",numColumns gens G)<<endl;
unittargets={1_R,a,F,B,C};for degree from 2 to 3 do (for i from 0 to degree do for j from 0 to degree-i do for k from 0 to degree-i-j do (unittargets=append(unittargets,a^i*F^j*B^k*C^(degree-i-j-k))));unittargets=join(unittargets,{U,U^2,U^3,U^4});
chosen=position(unittargets,g->(matrix{{g}})%G==0);if chosen===null then(print "NO_UNIT_FOUND";exit 2);g=unittargets#chosen;stderr<<toString("UNIT_TARGET",chosen,factor g)<<endl;P=matrix{{g}};L=P//M;assert(M*L==P);stderr<<toString("LIFT_TERMS",sum(flatten entries L,p->#(terms p)))<<endl;
'''
 export='unitWitnessStream=openOut '+json.dumps(str(wit))+';unitWitnessStream<<numRows L<<endl;scan(flatten entries L,p->(unitWitnessTerms:=terms p;unitWitnessStream<<#unitWitnessTerms<<endl;scan(unitWitnessTerms,t->(unitWitnessExponents:=first exponents t;unitWitnessStream<<toString leadCoefficient t<<" "<<unitWitnessExponents#0<<" "<<unitWitnessExponents#1<<" "<<unitWitnessExponents#2<<endl;))));close unitWitnessStream;print "EXACT_R3_SCALAR_UNIT_LIFT_PASS";\n'
 script.write_text(head+body+export);start=time.monotonic();record=dict(stage=stage,n=n,m=m,row=ix,row_terms=cost[ix],matrix_terms=sum(cost));print('START',record,flush=True)
 try:
  cp=subprocess.run(['M2','--script',str(script)],capture_output=True,text=True,timeout=60);Path(str(prefix)+'.log').write_text(cp.stdout+cp.stderr);record['m2_returncode']=cp.returncode
  if cp.returncode:records.append(record);break
  with Path(str(prefix)+'-native.log').open('w')as log:np=subprocess.run([str(binary),str(current),str(out),str(unitfile),'1',str(wit),str(ix)],stdout=log,stderr=subprocess.STDOUT,timeout=90)
  record['native_returncode']=np.returncode
  if np.returncode:records.append(record);break
  record['seconds']=time.monotonic()-start;record['next_shape']=list(map(int,out.read_text().split()[:2]));current=out;records.append(record);print('DONE',record,flush=True)
 except subprocess.TimeoutExpired as err:
  record['timeout']=str(err);records.append(record);break
 (base/'controller-status.json').write_text(json.dumps(records,indent=2)+'\n')
(base/'controller-status.json').write_text(json.dumps(records,indent=2)+'\n');print('FINAL',current,flush=True)

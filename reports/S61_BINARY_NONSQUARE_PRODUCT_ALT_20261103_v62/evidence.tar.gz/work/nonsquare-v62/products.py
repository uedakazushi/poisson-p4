from pathlib import Path
import json,sympy as s,time
from sympy.polys.rings import ring
st=time.time();R,a,e,d=ring('a,e,d',s.QQ);P,*v=ring('v0,v1,v2,v3,v4,v5,v6,v7',R)
x=json.load(open('reports/S61_BINARY_HYPERPLANE_QUADRATIC_CODIMENSION_20261102.json'))
qs=[P.from_dict({tuple(m):R.from_dict({tuple(ex):s.QQ(c)for ex,c in cs})for m,cs in row})for row in x['quadratic_rows_sparse']]
Z=3*v[0]-v[1]+v[6];W=v[3];ell=(-(d*e+8)*qs[1]+8*qs[2]+d*qs[3]).exquo(W)
qs=[qs[i]for i in[0,1,3,5]]+[W*ell,Z*ell]
rows=[];labels=[]
for i,q in enumerate(qs):
 for j in[0,1,2,3,4,6,7]:
  if (i,j)==(5,3):continue
  rows.append(q*v[j]);labels.append([i,j])
assert len(rows)==41
mons=sorted(set().union(*rows));assert len(mons)==84
matrix=[[q.get(m,R.zero)for m in mons]for q in rows]
for field in['QQ','(ZZ/32003)']:
 name='qq'if field=='QQ'else'fp'
 lines=['R='+field+'[a,e,d,z];F=500*a+90*e^2+3*e-24;B=(50*a+18*e^2-9*e-2)*d+60*e-40;C=100*a+18*e^2-9*e-2;', 'M=matrix{'+','.join('{'+','.join(str(c).replace('**','^')for c in row)+'}'for row in matrix)+'};', 'E=M | ((z*a*F*B*C-1)*id_(R^41)); print "PRODUCT_INPUT_READY";<<flush; G=gb image E; print "PRODUCT_GB_DONE";<<flush; print(id_(R^41)%G==0);print(dim coker E);print(numColumns gens G);print "PRODUCT_DONE";<<flush;']
 Path('work/nonsquare-v62/products-'+name+'.m2').write_text('\n'.join(lines)+'\n')
print(len(rows),len(mons),sum(len(c)for row in matrix for c in row),time.time()-st,flush=True)
with Path('work/nonsquare-v62/products-full.txt').open('w')as f:
 f.write('41 84 41\n')
 for row in matrix:
  for poly in row:f.write(str(len(poly))+''.join(' '+str(c)+' '+' '.join(map(str,m))for m,c in poly.items())+'\n')
source=Path('code/s61_binary_hyperplane_cubic_unit_schur_20261102.cpp').read_text().replace('n==63&&m==91','n==41&&m==84').replace('k<42','k<41').replace('i<42','i<41')
Path('work/nonsquare-v62/products-schur.cpp').write_text(source)

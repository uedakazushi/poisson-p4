import sys,json,sympy as s,subprocess,os,time
from pathlib import Path
from itertools import combinations_with_replacement
sys.path.insert(0,'code')
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
m=S61();local=json.load(open('work/r0-flag-boundary-points.json'))['b1']['local']
r=json.load(open('work/flag-b1-jets-6.json'))
point=s.Matrix(local['point61']).applyfunc(s.Rational)
b={i:point[i] for i,w in enumerate(m.reduced['parameter_weights']) if w==1}
two,F=specialize(m,b,True);cols=local['chart_columns'];fixed=next(i for i in range(45) if i not in cols)
J=s.Matrix(local['jacobian']).applyfunc(s.Rational);T=s.Matrix(local['tangent_basis']).applyfunc(s.Rational)
terms=[]
for f in F:
 ht=[]
 for mon,c in f.items():
  if fixed not in mon:
   a,bb=[cols.index(i) for i in mon]+[44]*(2-len(mon));ht.append((a,bb,c))
 terms.append(ht)
C=r['pivot_columns'];rows=r['pivot_rows'];U=s.zeros(45,len(C));iv=J[rows,C].inv(method='DM')
for i,col in enumerate(C):U[col,:]=iv[i,:]
assert J*T==s.zeros(135,9) and J[rows,:]*U==s.eye(36)
factors=[s.ilcm(*[s.denom(v) for v in list(J[i,:])+[c for _,_,c in terms[i]]]) for i in range(135)]
Jn=s.diag(*factors)*J;Un=U*s.diag(*[1/s.Integer(factors[i]) for i in rows]);den=s.ilcm(*[s.denom(v) for v in Un]);Un=(den*Un).applyfunc(s.cancel);td=s.ilcm(*[s.denom(v) for v in T]);Tn=td*T
assert td%32003 and den%32003
fmt=lambda M:'matrix{'+','.join('{'+','.join(str(c) for c in row)+'}' for row in M.tolist())+'}'
text='R=ZZ[v_0..v_8];T='+fmt(Tn)+';J='+fmt(Jn)+';U='+fmt(Un)+';jetDen='+str(den)+';rows={'+','.join(map(str,rows))+'};\n'
expr=[];diag=[]
for row,ht in enumerate(terms):
 expr.append('{'+('+'.join('('+str(c*factors[row])+')*(V_('+str(i)+',0)*W_('+str(j)+',0)+V_('+str(j)+',0)*W_('+str(i)+',0))' for i,j,c in ht) or '0_R')+'}')
 diag.append('{'+('+'.join('('+str(c*factors[row])+')*V_('+str(i)+',0)*V_('+str(j)+',0)' for i,j,c in ht) or '0_R')+'}')
text+='jetB=(V,W)->matrix{'+','.join(expr)+'};jetQ=V->matrix{'+','.join(diag)+'};\nW1=T*transpose vars R;\n'
for d in range(2,7):
 pieces=[]
 for a in range(1,d//2+1):
  bb=d-a
  pieces.append('jetQ(W'+str(a)+')' if a==bb else 'jetB(W'+str(a)+',W'+str(bb)+')')
 text+='Q'+str(d)+'='+'+'.join(pieces)+';W'+str(d)+'=-U*Q'+str(d)+'^rows;A'+str(d)+'=jetDen*Q'+str(d)+'+J*W'+str(d)+';print("integer degree '+str(d)+' ready");stdio<<flush;\n'
text+='S=QQ[v_0..v_8];R=S;use R;\n'
for d in range(2,7):
 text+='A'+str(d)+'=sub(A'+str(d)+',S)/('+str(den**(d-1)*td**d)+');\n'
 mm=['*'.join('v_'+str(i) for i in mon) for mon in combinations_with_replacement(range(9),d)]
 text+='m'+str(d)+'=matrix{{'+','.join(mm)+'}};C'+str(d)+'=sub(transpose last coefficients(transpose A'+str(d)+',Monomials=>m'+str(d)+'),QQ);\n'
text+='C=C2|C3|C4|C5|C6;ff=openOut "work/flag-b1-exact-coefficients.txt";scan(entries C,rr->(scan(rr,a->(ff<<numerator a<<"/"<<denominator a<<" "));ff<<endl));close ff;print("exact export ready");\n'
Path('work/flag-b1-exact-jets.m2').write_text(text)
env=os.environ.copy();env['DYLD_LIBRARY_PATH']=str(Path.cwd()/'work/m2-runtime/lib')+':/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'
run=subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script','work/flag-b1-exact-jets.m2'],env=env,capture_output=True,text=True,timeout=150)
Path('work/flag-b1-exact-jets.log').write_text(run.stdout+run.stderr)
print(run.stdout+run.stderr);assert run.returncode==0 and 'exact export ready' in run.stdout

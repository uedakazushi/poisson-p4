from pathlib import Path
import sympy as s,json,time,resource
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));w=Path('work/nonsquare-v62/vertex-curve-E5-v85');start=time.monotonic();t,H,v=s.symbols('t H v');profile=json.loads((w/'profile.json').read_text());load=lambda ts,vs:s.Poly(sum(s.Rational(c)*s.prod(x**k for x,k in zip(vs,ex))for ex,c in ts),*vs,domain=s.QQ);E5=load(profile['E5_natural'],(t,H,v));D=55*H-66*v+18;N=2*(v+2)*(7*v-11)**2;assert E5==s.Poly(N-t*D**2,t,H,v,domain=s.QQ);eq=[load(q,(t,H,v))for q in profile['vertex_linear_equations']];ab=[]
for q in eq:
 p=s.Poly(q.as_expr(),t);ab.append((p.coeff_monomial(t),p.coeff_monomial(1)))
F=[];facts=[];units=[s.Poly(x,H,v,domain=s.QQ)for x in [D,5*H-2*v-4,N,(v+3)*(3*v+4)]]
for alpha,beta in ab:
 q=s.Poly(s.expand(D**2*beta+N*alpha),H,v,domain=s.QQ);content,q=q.primitive();powers=[]
 for u in units:
  k=0
  while not q.is_zero:
   z,r=q.div(u)
   if r:break
   q=z;k+=1
  powers.append(k)
 F.append(q);facts.append(dict(QQcontent=str(content),removed_D_J_N_f=powers));print('intersectionpoly',len(q.terms()),[q.degree(H),q.degree(v)],'factors',s.factor(q.as_expr()),flush=True)
g=s.gcd(*F);print('genericintersectiongcd',s.factor(g.as_expr()),flush=True)
branches=[]
for vv in [s.Integer(-2),s.Rational(11,7)]:
 hh=(66*vv-18)/55;polys=[s.Poly(q.as_expr().subs({v:vv,H:hh}),t,domain=s.QQ)for q in eq];gg=s.gcd(*polys);print('Dzero',vv,hh,'linear_t_gcd',s.factor(gg.as_expr()),flush=True);branches.append(dict(v=str(vv),H=str(hh),vertex_equations=list(map(lambda q:str(q.as_expr()),polys)),gcd_t=str(gg.as_expr())))
source=json.loads(Path('work/nonsquare-v62/pair-finite-proof-v76/certificate.json').read_text());loadr=lambda ts:load(ts,(t,v,H)).as_expr();rows=[[loadr(q)for q in row]for row in source['natural_rows']]
special=[]
for vv in [s.Integer(-3),-s.Rational(4,3)]:
 minor=s.factor((rows[0][5]*rows[1][4]-rows[1][5]*rows[0][4]).subs(v,vv));print('fzero minor',vv,minor,flush=True);special.append(dict(v=str(vv),minor=str(minor),N_nonzero=str(N.subs(v,vv))))
enc=lambda q,vs:[[list(ex),str(c)]for ex,c in s.Poly(q,*vs,domain=s.QQ).terms()]
(w/'intersection-profile.json').write_text(json.dumps(dict(E5=enc(E5.as_expr(),(t,H,v)),D=str(D),N=str(N),generic_projection_polynomials=[enc(q.as_expr(),(H,v))for q in F],normalizations=facts,generic_gcd=str(g.as_expr()),D_zero_branches=branches,f_zero_branches=special,seconds=time.monotonic()-start),indent=2)+'\n')

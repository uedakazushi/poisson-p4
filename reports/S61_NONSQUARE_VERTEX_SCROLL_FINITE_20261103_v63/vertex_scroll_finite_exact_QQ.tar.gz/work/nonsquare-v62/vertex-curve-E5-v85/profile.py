from pathlib import Path
import sympy as s,json,time
w=Path('work/nonsquare-v62/vertex-curve-E5-v85');start=time.monotonic();a,e,P,t,v,H=s.symbols('a e P t v H');J=5*P-6*e-4;old=json.loads(Path('work/nonsquare-v62/scroll-base-smooth-v81/resultant.json').read_text());res=s.sympify(old['resultant']);E=s.Poly(s.cancel(-res*s.Integer(4749088069944112812890625)*P**6/(s.Integer(67108864)*a**9*J**6)),a,e,P,domain=s.QQ);new=s.Poly(s.cancel(E.as_expr().subs(a,t*P).subs(e,(v-20*t)/3)/P**3).subs(P,H-8*t),t,H,v,domain=s.QQ);content,new=new.primitive();print('E5 natural',s.factor(new.as_expr()),'content',content,'tdeg',new.degree(t),'terms',len(new.terms()),flush=True)
source=json.loads(Path('work/nonsquare-v62/pair-finite-proof-v76/certificate.json').read_text());lc=lambda ts:s.Poly(sum(s.Rational(c)*t**ex[0]*v**ex[1]*H**ex[2]for ex,c in ts),t,H,v,domain=s.QQ);eq=[lc(q)for q in source['linear_t_equations']];ab=[]
for i in [0,2]:
 pp=s.Poly(eq[i].as_expr(),t);ab.append((s.Poly(pp.coeff_monomial(t),H,v,domain=s.QQ),s.Poly(pp.coeff_monomial(1),H,v,domain=s.QQ)))
N=s.Poly(s.expand(ab[0][0].as_expr()*ab[1][1].as_expr()-ab[1][0].as_expr()*ab[0][1].as_expr()),H,v,domain=s.QQ);_,N=N.primitive();print('vertexcurve projection H/v degrees',N.degree(H),N.degree(v),'terms',len(N.terms()),flush=True)
enc=lambda q,vs:[[list(ex),str(c)]for ex,c in s.Poly(q,*vs,domain=s.QQ).terms()]
(w/'profile.json').write_text(json.dumps(dict(E5_original=enc(E.as_expr(),(a,e,P)),E5_natural=enc(new.as_expr(),(t,H,v)),E5_natural_QQcontent=str(content),E5_removed_known_P_power=3,vertex_linear_equations=[enc(q.as_expr(),(t,H,v))for q in [eq[0],eq[2]]],vertex_projection_N=enc(N.as_expr(),(H,v)),core_units=['t','H-8*t','5H-2v-4'],seconds=time.monotonic()-start),indent=2)+'\n')

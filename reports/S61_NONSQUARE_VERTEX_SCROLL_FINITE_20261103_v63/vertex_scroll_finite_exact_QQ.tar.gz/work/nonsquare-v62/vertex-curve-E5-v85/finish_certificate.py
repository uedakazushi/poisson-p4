from pathlib import Path
import sympy as s,json,time
w=Path('work/nonsquare-v62/vertex-curve-E5-v85');start=time.monotonic();t,H,v=s.symbols('t H v');d=json.loads((w/'intersection-profile.json').read_text());load=lambda ts,vs:s.Poly(sum(s.Rational(c)*s.prod(z**k for z,k in zip(vs,ex))for ex,c in ts),*vs,domain=s.QQ);F,G=[load(q,(H,v))for q in d['generic_projection_polynomials']];enc=lambda q,vs:[[list(ex),str(c)]for ex,c in s.Poly(q,*vs,domain=s.QQ).terms()]
# A compact content certificate and a single exact good specialization suffice.
coeff=[];labels=[];weights=[];gg=s.Poly(0,v,domain=s.QQ)
for i,p in enumerate([F,G]):
 ph=s.Poly(p.as_expr(),H)
 for j,c in enumerate(ph.all_coeffs()):
  q=s.Poly(c,v,domain=s.QQ);coeff.append(q);labels.append([i,ph.degree()-j])
  if q.is_zero:weights.append(s.Poly(0,v,domain=s.QQ));continue
  if gg.is_zero:weights.append(s.Poly(1/q.LC(),v,domain=s.QQ));gg=q.monic();continue
  a,b,h=s.gcdex(gg,q);weights=[s.Poly(c*a,v,domain=s.QQ)for c in weights]+[s.Poly(b,v,domain=s.QQ)];gg=s.Poly(h,v,domain=s.QQ)
 if gg==s.Poly(1,v,domain=s.QQ):break
assert gg==s.Poly(1,v,domain=s.QQ);assert sum((a*b for a,b in zip(weights,coeff)),s.Poly(0,v,domain=s.QQ))==gg
f=s.Poly(F.as_expr().subs(v,0),H,domain=s.QQ);g=s.Poly(G.as_expr().subs(v,0),H,domain=s.QQ);assert f.degree()==F.degree(H)and g.degree()==G.degree(H);u,z,h=s.gcdex(f,g);assert h==s.Poly(1,H,domain=s.QQ)
branches=[]
for branch in d['D_zero_branches']:
 polys=[s.Poly(s.sympify(q),t,domain=s.QQ)for q in branch['vertex_equations']];a,b,c=s.gcdex(*polys);assert c==s.Poly(1,t,domain=s.QQ);branches.append(dict(v=branch['v'],H=branch['H'],polynomials=[enc(q.as_expr(),(t,))for q in polys],Bezout=[enc(a.as_expr(),(t,)),enc(b.as_expr(),(t,))]))
cert=dict(projection_polynomials=[enc(q.as_expr(),(H,v))for q in [F,G]],coefficient_labels=labels,coefficient_Bezout=[enc(q.as_expr(),(v,))for q in weights],good_special_v=0,special_H_degrees=[f.degree(),g.degree()],special_Bezout=[enc(u.as_expr(),(H,)),enc(z.as_expr(),(H,))],D_zero_branches=branches,all_exact_QQ_identities_passed=True,seconds=time.monotonic()-start);(w/'intersection-certificate.json').write_text(json.dumps(cert,indent=2)+'\n');print('EXACT_INTERSECTION_FINITE_CERTIFICATE_READY',time.monotonic()-start,flush=True)

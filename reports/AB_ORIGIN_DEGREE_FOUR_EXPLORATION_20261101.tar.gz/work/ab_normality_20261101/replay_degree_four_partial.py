from pathlib import Path
saved=json_saved=None
import json
saved=json.loads(Path('work/ab_normality_20261101/degree_four_lower.json').read_text())
source=Path('work/ab_normality_20261101/degree_four_lower.py').read_text().split('for num,inds in enumerate(combinations_with_replacement(range(45),4)):')[0]
exec(source)
assert seed==saved['seed']==37922
for i,j,k,l in saved['extra_quartics']:
 got=reduce(mul(products2[i,j],products2[k,l]),B4);assert got
 mm,c=got;det=det*c%prime
assert len(B4)==saved['rank']==38320 and det==saved['extra_pivot_product']
print('REPLAY PASS degree4 lower',len(B4),'extra',len(saved['extra_quartics']),'seconds',time.monotonic()-clockstart,flush=True)

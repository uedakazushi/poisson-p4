import sys,time,json
sys.path.insert(0,'code')
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.domains import QQ
from itertools import combinations,combinations_with_replacement
start=time.monotonic()
# Reuse the audited linear N-to-Q map; this scratch module strips its CLI tail.
source=open('work/ab_normality_20261101/zero_trace_transition.py').read().split('b0,b1=s.symbols')[0]
exec(source)
a,b,d,e,b0,b1,b2,g0,g1,g2=s.symbols('a b d e b0 b1 b2 g0 g1 g2')
N=s.Matrix([1,a,b])*s.Matrix([[-a*d-b*e,d,e]])
Q=push(upper(s.Matrix([[b0,b1],[b1,b2]])),Qof(N,g0*x*x+g1*x*z+g2*z*z))
vars=(a,b,d,e,b0,b1,b2,g0,g1,g2)
R,*_=ring(','.join(map(str,vars)),QQ)
mons=[Y[i]*Y[j] for i,j in combinations_with_replacement(range(4),2)]
polys=[R.from_expr(s.Poly(v,*Y).coeff_monomial(mon)) for i,j in combinations(range(4),2) for v in [Q[i,j]] for mon in mons]
p=32003
basis={};selected=[]
def red(poly,cache,save=False):
 row={mon:int(c.numerator)%p*pow(int(c.denominator),-1,p)%p for mon,c in poly.items() if c}
 while row:
  pivot=min(row)
  if pivot not in cache:
   c=row[pivot];inv=pow(c,-1,p);row={m:v*inv%p for m,v in row.items()}
   if save:cache[pivot]=row
   return pivot,c
  c=row[pivot]
  for m,v in cache[pivot].items():
   nv=(row.get(m,0)-c*v)%p
   if nv:row[m]=nv
   else:row.pop(m,None)
 return None
for i,f in enumerate(polys):
 if red(f,basis,True):selected.append(i)
print('degree1',len(basis),time.monotonic()-start,flush=True)
assert len(basis)==45
bb={};pivots=[];pairs=[];det=1
for i,j in combinations_with_replacement(range(45),2):
 result=red(polys[selected[i]]*polys[selected[j]],bb,True)
 if result:
  mon,c=result;pivots.append(mon);pairs.append((i,j));det=det*c%p
print('degree2',len(bb),time.monotonic()-start,flush=True)
json.dump(dict(rank_mod_p=len(bb),prime=p,coordinate_indices=selected,product_indices=pairs,pivot_monomials=pivots,triangular_pivot_product_mod_p=det),open('work/ab_normality_20261101/degree2_span.json','w'),indent=2)

source=open('work/ab_normality_20261101/degree2_span.py').read().split('bb={};pivots=[]')[0]
exec(source)
weights=[(1,-1),(2,-2),(-2,0),(-3,1),(2,0),(1,1),(0,2),(-3,-1),(-2,-2),(-1,-3)]
def weight(mon):return tuple(sum(e*w[k] for e,w in zip(mon,weights)) for k in range(2))
assert all(len({weight(m) for m in f})<=1 for f in polys)
from collections import Counter
bb={};pivots=[];pairs=[];det=1;character=Counter()
for num,(i,j,k) in enumerate(combinations_with_replacement(range(45),3)):
 result=red(polys[selected[i]]*polys[selected[j]]*polys[selected[k]],bb,True)
 if result:
  mon,c=result;pivots.append(mon);pairs.append((i,j,k));det=det*c%p;character[weight(mon)]+=1
 if num%2000==0:print('progress',num,len(bb),time.monotonic()-start,flush=True)
print('degree3',len(bb),time.monotonic()-start,flush=True)
json.dump(dict(rank_mod_p=len(bb),prime=p,coordinate_indices=selected,product_indices=pairs,pivot_monomials=pivots,triangular_pivot_product_mod_p=det,character={str(k):v for k,v in character.items()}),open('work/ab_normality_20261101/degree3_span.json','w'),indent=2)

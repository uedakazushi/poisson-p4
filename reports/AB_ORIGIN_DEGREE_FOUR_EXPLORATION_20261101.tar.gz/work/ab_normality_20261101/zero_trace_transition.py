import sys
sys.path.insert(0,'code')
import sympy as s
from itertools import combinations,combinations_with_replacement
from toric_zero_jet_dimension_20261101 import witness,encode
x,y,z,w,t=s.symbols('x y z w t');Y=s.Matrix([x,y,z,w]);q=s.Matrix([x,z]);J2=s.Matrix([[0,1],[-1,0]])
ss=s.symbols('s0:3');hh=s.symbols('h0:5');pars=[*ss,*hh]
S=ss[0]*x*x+ss[1]*x*z+ss[2]*z*z;H=sum(hh[i]*x**(4-i)*z**i for i in range(5))
def Nof(S,H):
 a=[s.Poly(s.expand(S),x,z).coeff_monomial(m) for m in (x*x,x*z,z*z)]
 h=[s.Poly(s.expand(H),x,z).coeff_monomial(x**(4-i)*z**i) for i in range(5)]
 return s.Matrix([[h[2]/6,-h[1]/4,h[0]],[h[3]/2,-h[2]/3,h[1]/2],[h[4],-h[3]/4,h[2]/6]])+s.Matrix([[2*a[1],-2*a[0],0],[4*a[2],0,-4*a[0]],[0,2*a[2],-2*a[1]]])/96
N=Nof(S,H);E=N.reshape(9,1).jacobian(pars);inverse=(E.T*E).inv()*E.T
F=q*S/4+J2*s.Matrix([s.diff(H,x),s.diff(H,z)]);mixed=F.jacobian(q)
def Qof(N,vertical=0):
 out=s.zeros(4);A=mixed.subs(dict(zip(pars,inverse*N.reshape(9,1))),simultaneous=True)
 for i,ii in enumerate((0,2)):
  for j,jj in enumerate((1,3)):out[ii,jj],out[jj,ii]=A[i,j],-A[i,j]
 out[1,3],out[3,1]=vertical,-vertical
 return out

def upper(B):
 A=s.eye(4)
 for i,ii in enumerate((0,2)):
  for j,jj in enumerate((1,3)):A[ii,jj]=B[i,j]
 return A

def push(A,Q):return (A*Q.subs(dict(zip(Y,A.inv()*Y)),simultaneous=True)*A.T).applyfunc(s.expand)
def extract(Q):
 A=Q[[0,2],[1,3]];F=A*q/3;S=s.diff(F[0],x)+s.diff(F[1],z);R=F-q*S/4
 H=-s.Poly(R[1],x,z).coeff_monomial(x**3)*x**4/4
 for i in range(1,5):H+=s.Poly(R[0],x,z).coeff_monomial(x**(4-i)*z**(i-1))*x**(4-i)*z**i/i
 return Nof(S,H),s.Matrix([s.Poly(Q[1,3],x,z).coeff_monomial(m) for m in (x*x,x*z,z*z)])
b0,b1=s.symbols('b0 b1');B=s.Matrix([[b0,b1],[b1,t]]);Bp=s.Matrix([[b0-b1*b1/t,b1/t],[b1/t,-1/t]])
rotation=s.Matrix([[1,0,0,0],[0,1,0,0],[0,0,0,1],[0,0,-1,0]])
h=((rotation*upper(Bp)).inv()*upper(B)).applyfunc(s.cancel);h0=h.subs({b0:0,b1:0});K=h.diff(b1).subs({b0:0,b1:0})*h0.inv()
baseQ=Qof(s.zeros(3),x*x);SB=upper(s.Matrix([[0,0],[0,t]]));base0=push(SB.inv(),baseQ);baseinf=push(h0,base0)
print('base0',extract(base0));print('baseinf',extract(baseinf))
# finite-chart normal free coordinates b0,b1,n00,n01,n02,n12,g0-1,g1,g2.
core=[]
for i,j in ((0,0),(0,1),(0,2),(1,2)):
 NN=s.zeros(3);NN[i,j]=1
 if (i,j)==(0,0):NN[2,2]=-1
 core.append(Qof(NN))
core +=[Qof(s.zeros(3),g) for g in (x*x,x*z,z*z)]
Ni,gi=extract(baseinf);nc=Ni[0,2]
# infinity smooth rankone chart: N=(1,p,q)^t(-p*r-q*s,r,s), coordinates p,q,r,s.
def ci(Q):
 NN,gg=extract(Q)
 return s.Matrix([NN[1,2]/nc,NN[2,2]/nc,NN[0,1],NN[0,2],*gg])
columns=[]
for k in range(9):
 out=s.zeros(9,1)
 if k==0:out[0]=1
 elif k==1:
  out[1]=1/t
  D=K*baseinf+baseinf*K.T-sum(((K*Y)[i]*baseinf.diff(Y[i]) for i in range(4)),s.zeros(4))
  out[2:,0]=ci(D)
 else:out[2:,0]=ci(push(h0,core[k-2]))
 columns.append(out)
T=s.Matrix.hstack(*columns).applyfunc(s.factor);print('transition',T);print('det',s.factor(T.det()))
# global coordinate derivatives including all13 normal coordinates at vertex.
allcore=[]
for i,j in ((0,0),(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1)):
 NN=s.zeros(3);NN[i,j]=1
 if i==j:NN[2,2]=-1
 allcore.append(Qof(NN))
allcore +=[Qof(s.zeros(3),g) for g in (x*x,x*z,z*z)]
pairs=list(combinations(range(4),2));mon=[Y[i]*Y[j] for i,j in combinations_with_replacement(range(4),2)]
def vec(Q):return s.Matrix([s.Poly(s.expand(Q[i,j]),*Y).coeff_monomial(m) for i,j in pairs for m in mon])
Ds=[]
for i,j in ((0,0),(0,1)):
 A=s.zeros(4);A[(0,2)[i],(1,3)[j]]=A[(0,2)[j],(1,3)[i]]=1
 Ds.append(vec(A*baseQ+baseQ*A.T-sum(((A*Y)[k]*baseQ.diff(Y[k]) for k in range(4)),s.zeros(4))))
Ds +=[vec(push(SB,C)) for C in allcore]
D=s.Matrix.hstack(*Ds)
# torsion relations finite: t*n10=t*n11=t*n20=t*n21=0.
torsion=[5,6,8,9]
for k in torsion:D[:,k]=D[:,k].subs(t,0)
cs=[];labels=[]
for j in range(D.cols):
 for n in range(5):
  col=D[:,j].applyfunc(lambda f:s.Poly(f,t).coeff_monomial(t**n))
  if any(col):cs.append(col);labels.append([j,n])
W=s.Matrix.hstack(*cs);print('coefficient span',W.shape,witness(W)['rank'])
import json
json.dump(dict(T=encode(T),D=encode(D),labels=labels,rank=witness(W)),open('work/ab_normality_20261101/zero_trace_transition.json','w'),indent=2)

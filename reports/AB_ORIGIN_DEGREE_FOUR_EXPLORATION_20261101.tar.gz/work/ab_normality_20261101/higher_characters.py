import sympy as s
from collections import Counter
from itertools import combinations,combinations_with_replacement
exec(open('work/ab_normality_20261101/zero_trace_transition.py').read().split('b0,b1=s.symbols')[0])
weights=[(2,0),(1,1),(0,2),(3,-1),(2,0),(1,1),(0,2),(-1,3)];vw=[(3,1),(2,2),(1,3)]
relations=[s.expand(N.extract(rr,cc).det()) for rr in combinations(range(3),2) for cc in combinations(range(3),2)]
gb=s.groebner(relations,*pars,domain=s.QQ,order='grevlex');leading=[p.LM(order='grevlex').exponents for p in gb.polys]
def char(n,weights,exclude=()):
 c=Counter()
 for tup in combinations_with_replacement(range(len(weights)),n):
  powers=tuple(tup.count(i) for i in range(len(weights)))
  if any(all(a>=b for a,b in zip(powers,m)) for m in exclude):continue
  c[tuple(sum(weights[i][r] for i in tup) for r in range(2))]+=1
 return c
def decompose(character):
 c=Counter({a:n for a,n in character.items() if n});out=[]
 while c:
  a,b=max(c);m=c[(a,b)];assert a>=b and m>0;out.append((a,b,m))
  for i in range(a-b+1):
   key=a-i,b+i;c[key]-=m;assert c[key]>=0
   if c[key]==0:del c[key]
 return out
def bott(a,b):
 u,v=a+2,b+1
 if 0 in(u,v) or abs(u)==abs(v):return None
 aa,bb=sorted([abs(u),abs(v)],reverse=True);aa-=2;bb-=1
 degree=(u<0)+(v<0)+(u+v<0)
 A,B=aa-bb,bb;dim=(A+1)*(B+1)*(A+B+2)*(A+2*B+3)//6
 return degree,(aa,bb),dim
ys=[char(n,weights,leading) for n in range(9)];vs=[char(n,vw) for n in range(9)]
records=[]
for n in range(9):
 h=[Counter(),Counter()];dims=[0,0]
 for j in range(n+1):
  prod=Counter()
  for a,ca in ys[n-j].items():
   for b,cb in vs[j].items():prod[(a[0]+b[0],a[1]+b[1])]+=ca*cb
  for a,b,m in decompose(prod):
   out=bott(a,b)
   if out:
    d,wt,dim=out;assert d in(0,1);h[d][wt]+=m;dims[d]+=m*dim
 print(n,dims,'chi',dims[0]-dims[1], 'H1',dict(h[1]),flush=True)
 records.append(dict(n=n,h0=dims[0],h1=dims[1],chi=dims[0]-dims[1],H1={str(k):v for k,v in h[1].items()}))
import json
json.dump(records,open('work/ab_normality_20261101/higher_characters.json','w'),indent=2)

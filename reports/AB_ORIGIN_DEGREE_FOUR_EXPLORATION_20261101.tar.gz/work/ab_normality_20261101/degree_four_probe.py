from pathlib import Path
src=Path('work/ab_normality_20261101/higher_characters.py').read_text().split('records=[]')[0]
exec(src)
# All cohomology multiplicities, including the candidate H0 slots.
n=4;h=[Counter(),Counter()]
for j in range(n+1):
 prod=Counter()
 for aa,ca in ys[n-j].items():
  for bb,cb in vs[j].items():prod[(aa[0]+bb[0],aa[1]+bb[1])]+=ca*cb
 for aa,bb,mm in decompose(prod):
  out=bott(aa,bb)
  if out:
   dd,wt,dim=out;h[dd][wt]+=mm
print('H1',dict(h[1]),'matching H0',{k:h[0][k] for k in h[1]},flush=True)
g0,g1,g2,u=s.symbols('g0 g1 g2 u');fiber=(*pars,g0,g1,g2);actual_weights=[tuple(-a for a in wt) for wt in weights+vw]
# Dense Y chart; all action identities are tested in its polynomial ring.
a,b,d,e=s.symbols('a b d e');chartN=s.Matrix([1,a,b])*s.Matrix([[-a*d-b*e,d,e]]);vals=inverse*chartN.reshape(9,1);sub=dict(zip(pars,vals));chartvars=(a,b,d,e,g0,g1,g2)
Q=Qof(N,g0*x*x+g1*x*z+g2*z*z)
radical=s.eye(4);radical[3,2]=u;rn,rg=extract(push(radical,Q));rsub=dict(zip(fiber,(*pars,*rg)))
T=s.Matrix([[1,u],[0,1]]);levi=s.eye(4)
for i,ii in enumerate((0,2)):
 for j,jj in enumerate((0,2)):levi[ii,jj]=T[i,j]
for i,ii in enumerate((1,3)):
 for j,jj in enumerate((1,3)):levi[ii,jj]=T.inv().T[i,j]
ln,lg=extract(push(levi,Q));lsub=dict(zip(fiber,(*(inverse*ln.reshape(9,1)),*lg)))
records=[]
for aa,bb in h[1]:
 forms=[s.prod(fiber[i] for i in inds) for inds in combinations_with_replacement(range(11),n) if tuple(sum(actual_weights[i][r] for i in inds) for r in range(2))==(-aa,-bb)]
 fp=[s.Poly(f.subs(sub,simultaneous=True),*chartvars) for f in forms];mons=sorted(set().union(*(set(p.monoms()) for p in fp)));M=s.Matrix([[p.coeff_monomial(mm) for p in fp] for mm in mons]);piv=list(M.to_DM().rref()[1]);forms=[forms[i] for i in piv]
 ops=[]
 for f in forms:
  op=[s.diff(f.subs(lsub,simultaneous=True),u).subs(u,0),s.diff(f.subs(rsub,simultaneous=True),u,bb+1).subs(u,0)]
  ops.append([s.Poly(ff.subs(sub,simultaneous=True),*chartvars) for ff in op])
 rows=[]
 for j in range(2):
  mon=sorted(set().union(*(set(p[j].monoms()) for p in ops)))
  rows +=[[p[j].coeff_monomial(mm) for p in ops] for mm in mon]
 C=s.Matrix(rows);rank=C.to_DM().rank();bound=len(forms)-rank;expected=h[0][aa,bb]-h[1][aa,bb]
 print('partition',(aa,bb),'weightdim',len(forms),'constraint rank',rank,'Hom upper',bound,'Euler',expected,flush=True)
 records.append(dict(partition=[aa,bb],weight_dimension=len(forms),constraint_rank=rank,Hom_upper=bound,Euler_multiplicity=expected,forms=list(map(str,forms)),kernel=[[str(x) for x in col] for col in C.nullspace()]))
import json
json.dump(records,open('work/ab_normality_20261101/degree_four_probe.json','w'),indent=2)

from pathlib import Path
src=Path('work/ab_normality_20261101/higher_characters.py').read_text().split('records=[]')[0]
exec(src)
n=4;h=[Counter(),Counter()]
for j in range(n+1):
 prod=Counter()
 for aa,ca in ys[n-j].items():
  for bb,cb in vs[j].items():prod[(aa[0]+bb[0],aa[1]+bb[1])]+=ca*cb
 for aa,bb,mm in decompose(prod):
  out=bott(aa,bb)
  if out:dd,wt,dim=out;h[dd][wt]+=mm
xx,yy=s.symbols('xx yy');den=s.expand(xx**2*yy**2*((xx**2-xx**-2)*(yy-yy**-1)-(yy**2-yy**-2)*(xx-xx**-1)));target=Counter()
for (aa,bb),mult in (h[0]-h[1]).items():
 num=s.expand(xx**(aa+2)*yy**(aa+2)*((xx**(aa+2)-xx**-(aa+2))*(yy**(bb+1)-yy**-(bb+1))-(yy**(aa+2)-yy**-(aa+2))*(xx**(bb+1)-xx**-(bb+1))))
 Q,rem=s.div(s.Poly(num,xx,yy),s.Poly(den,xx,yy));assert rem==0
 for mm,c in Q.terms():target[mm[0]-aa,mm[1]-aa]+=mult*int(c)
assert sum(target.values())==38570 and min(target.values())>0
import json
json.dump({str(k):v for k,v in target.items()},open('work/ab_normality_20261101/degree_four_character.json','w'),indent=2)
print('characters',len(target),'total',sum(target.values()))

source=open('work/ab_normality_20261101/degree2_span.py').read().split('p=32003')[0]
exec(source)
import time
clockstart=time.monotonic();prime=32003

def convert(f):return {m:int(c.numerator)%prime*pow(int(c.denominator),-1,prime)%prime for m,c in f.items() if c}
def mul(f,g):
 out={}
 for a,c in f.items():
  for b,d in g.items():
   mm=tuple(x+y for x,y in zip(a,b));out[mm]=(out.get(mm,0)+c*d)%prime
 return {mm:c for mm,c in out.items() if c}
def reduce(f,cache):
 f=f.copy()
 while f:
  mm=min(f)
  if mm not in cache:
   c=f[mm];iv=pow(c,-1,prime);cache[mm]={m:v*iv%prime for m,v in f.items()};return mm,c
  c=f[mm]
  for m,v in cache[mm].items():
   d=(f.get(m,0)-c*v)%prime
   if d:f[m]=d
   else:f.pop(m,None)
 return None
polys=list(map(convert,polys));B1={};selected=[]
for i,f in enumerate(polys):
 if reduce(f,B1):selected.append(i)
P=[polys[i] for i in selected];B2={};products2={}
for i,j in combinations_with_replacement(range(45),2):
 f=mul(P[i],P[j]);products2[i,j]=f;reduce(f,B2)
B3={}
for i,j,k in combinations_with_replacement(range(45),3):reduce(mul(products2[i,j],P[k]),B3)
assert len(B1)==45 and len(B2)==761 and len(B3)==6691
print('lower bases ready',time.monotonic()-clockstart,flush=True)
import ast
from collections import Counter
target={ast.literal_eval(k):v for k,v in json.load(open('work/ab_normality_20261101/degree_four_character.json')).items()}
weights=[(1,-1),(2,-2),(-2,0),(-3,1),(2,0),(1,1),(0,2),(-3,-1),(-2,-2),(-1,-3)]
def weight(mon):return tuple(sum(e*w[k] for e,w in zip(mon,weights)) for k in range(2))
Pweights=[weight(next(iter(f))) for f in P]
B4={};recipes=[];det=1
for left,bl,right,br in [(1,B1,3,B3),(2,B2,2,B2)]:
 for ia,(a,f) in enumerate(bl.items()):
  for ib,(b,g) in enumerate(br.items()):
   mm=tuple(x+y for x,y in zip(a,b))
   if mm in B4:continue
   product=mul(f,g);assert min(product)==mm and product[mm]==1;B4[mm]=product;recipes.append([left,ia,right,ib])
print('leading products',len(B4),time.monotonic()-clockstart,flush=True);seed=len(B4);extras=[];actual=Counter(weight(mm) for mm in B4)

extra_pairs=[];num=0
for left,bl,right,br in [(2,B2,2,B2),(1,B1,3,B3)]:
 for ia,(a,f) in enumerate(bl.items()):
  for ib,(b,g) in enumerate(br.items()):
   num+=1;wt=weight(tuple(x+y for x,y in zip(a,b)))
   if actual[wt]==target[wt]:continue
   got=reduce(mul(f,g),B4)
   if got:
    mm,c=got;extra_pairs.append([left,ia,right,ib]);det=det*c%prime;actual[wt]+=1;assert actual[wt]<=target[wt]
   if num%10000==0:print('progress',num,len(B4),time.monotonic()-clockstart,flush=True)
   if len(B4)==38570 or time.monotonic()-clockstart>180:break
  if len(B4)==38570 or time.monotonic()-clockstart>180:break
 if len(B4)==38570 or time.monotonic()-clockstart>180:break
print('result',len(B4),'extra',len(extra_pairs),'processed',num,'seconds',time.monotonic()-clockstart,flush=True)
json.dump(dict(rank=len(B4),seed=seed,prime=prime,coordinate_indices=selected,recipes=recipes,extra_pairs=extra_pairs,extra_pivot_product=det,processed=num,seconds=time.monotonic()-clockstart),open('work/ab_normality_20261101/degree_four_lower_pairs.json','w'),indent=2)
import pickle
with open('work/ab_normality_20261101/degree_four_caches.pickle','wb') as f:pickle.dump((B1,B2,B3,B4,actual),f)

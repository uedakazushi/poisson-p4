from pathlib import Path
import json,sympy as s,time,hashlib
w=Path('work/nonsquare-v62/rank2-finite-model-v59');start=time.monotonic();src=Path('work/nonsquare-v62/gcd-gate-exception-v54/certificate.json');data=json.loads(src.read_text());P,e=s.symbols('P e');enc=lambda terms:sum(s.Rational(c)*P**ex[0]*e**ex[1]for ex,c in terms);H=[[s.Poly(enc(q),P,e,domain=s.QQ)for q in row]for row in data['global_H3_entries']];Lp=20*P+3*e+20;J=5*P-6*e-4;vals=[]
for unit in [P,Lp,J]:
 up=s.Poly(unit,P,e);n=0
 while True:
  quot=[[p.div(up)for p in row]for row in H]
  if any(rem for row in quot for q,rem in row):break
  H=[[q for q,rem in row]for row in quot];n+=1
 vals.append(n)
M=s.Poly(s.expand(s.Matrix([[p.as_expr()for p in row[:3]]for row in H[:3]]).det(method='domain-ge')),P,e,domain=s.QQ);mvals=[]
for unit in [P,Lp,J]:
 up=s.Poly(unit,P,e);n=0
 while True:
  q,rem=M.div(up)
  if rem:break
  M=q;n+=1
 mvals.append(n)
N=s.Poly(enc(data['N']),P,e,domain=s.QQ);content,primitive=s.primitive(M.as_expr(),P,e);M=s.Poly(primitive,P,e,domain=s.QQ);out=dict(source_certificate_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),known_units_after_DB=['P','20P+3e+20','J'],stripped_H3_common_unit_powers=vals,stripped_minor_extra_unit_powers=mvals,minor_QQ_content=str(content),N=str(N.as_expr()),primitive_minor=str(s.factor(M.as_expr())),N_totaldegree=N.total_degree(),M_totaldegree=M.total_degree(),N_e_degree=N.degree(e),M_e_degree=M.degree(e),N_e_leading_coeff=str(s.Poly(N.as_expr(),e).LC()),M_e_leading_coeff=str(s.Poly(M.as_expr(),e).LC()),p=32003,N_e_lc_modp=int(s.Poly(N.as_expr(),e).LC())%32003,seconds=time.monotonic()-start,finite_model_not_yet_proved=True);(w/'primitive-input.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

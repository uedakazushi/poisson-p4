#!/usr/bin/env python3
"""A binary/mixed-tail junction: actual infinity line and transverse length upper bound67."""
import sys,json,time,hashlib,argparse
from pathlib import Path
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'code'))
import sympy as s,numpy as np
from itertools import combinations_with_replacement
from s61_model import S61,X,J as J0
from s61_flag_transverse_obstruction_20261101 import specialize
from primitive_jet_elliptic_curve_20261101 import primitive_beta


def verify_point():
    label=sys.argv[1]; start=time.time();p=32003;m=S61()
    local=json.loads((ROOT/'work/r0-flag-boundary-points.json').read_text())[label]['local']
    point=s.Matrix(local['point61']).applyfunc(s.Rational)
    b={i:point[i] for i,w in enumerate(m.reduced['parameter_weights']) if w==1}
    two,F=specialize(m,b,True);cols=local['chart_columns'];fixed=next(i for i in range(45) if i not in cols)
    J=s.Matrix(local['jacobian']).applyfunc(s.Rational);T=s.Matrix(local['tangent_basis']).applyfunc(s.Rational);n=T.cols
    _,piv=J.to_DM().rref();free=[i for i in range(45) if i not in piv]
    assert J*T==s.zeros(135,n) and T[free,:]==s.eye(n)
    def mod(v):v=s.Rational(v);return int(v.p)*pow(int(v.q),-1,p)%p
    def arr(M):return np.array([[mod(v) for v in row] for row in M.tolist()],dtype=np.int64)
    def rref(A):
     A=A.copy()%p;row=0;piv=[]
     for col in range(A.shape[1]):
      choices=np.flatnonzero(A[row:,col])
      if len(choices)==0:continue
      j=row+int(choices[0]);A[[row,j]]=A[[j,row]];A[row]=A[row]*pow(int(A[row,col]),-1,p)%p
      mask=np.flatnonzero(A[:,col]);mask=mask[mask!=row]
      if len(mask):A[mask]=(A[mask]-A[mask,col,None]*A[row,None,:])%p
      piv.append(col);row+=1
      if row==A.shape[0]:break
     return A,piv
    j=arr(J);t=arr(T);_,C=rref(j);_,R=rref(j[:,C].T);rank=len(C);rr,_=rref(np.concatenate([j[np.ix_(R,C)],np.eye(rank,dtype=np.int64)],axis=1));U=np.zeros((45,rank),dtype=np.int64);U[C,:]=rr[:,rank:];JU=j@U%p
    assert C==list(piv) and len(C)==len(R)==45-n and np.array_equal(j[R,:]@U%p,np.eye(45-n,dtype=np.int64))
    H=np.zeros((135,45,45),dtype=np.int64)
    for row,f in enumerate(F):
     for mon,c in f.items():
      if fixed in mon:continue
      i,l=[cols.index(v) for v in mon]+[44]*(2-len(mon));v=mod(c)
      if i==l:H[row,i,l]+=v
      else:H[row,i,l]+=v*pow(2,-1,p)%p;H[row,l,i]+=v*pow(2,-1,p)%p

    H%=p
    maximum=int(sys.argv[2]);ms={d:list(combinations_with_replacement(range(n),d)) for d in range(1,maximum+1)}
    ix={d:{mon:i for i,mon in enumerate(ms[d])} for d in ms};W={1:t};out={}
    for degree in range(2,maximum+1):
     raw=np.zeros((135,len(ms[degree])),dtype=np.int64)
     for aa in range(1,degree//2+1):
      bb=degree-aa;factor=1 if aa==bb else 2
      destinations=np.array([ix[degree][tuple(sorted(ma+mb))] for ma in ms[aa] for mb in ms[bb]],dtype=np.int64)
      for row in range(135):
       values=(factor*W[aa].T@(H[row]@W[bb]%p)%p).reshape(-1)
       raw[row]=(raw[row]+np.bincount(destinations,weights=values,minlength=len(ms[degree])).astype(np.int64))%p
     W[degree]=-U@raw[R,:]%p;A=(raw-JU@raw[R,:])%p
     out['A'+str(degree)]=A.tolist();out['t'+str(degree)]=W[degree][-1,:].tolist()
     print(label,'degree',degree,'seconds',time.time()-start,flush=True)
    out.update(n=n,T=T.tolist(),free=free,pivot_columns=C,pivot_rows=R)
    json.dump(out,open(ROOT/('work/flag-'+label+'-jets-'+str(maximum)+'.json'),'x'),default=str)
verify_point()

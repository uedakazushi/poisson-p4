import json,time,sys,numpy as np
from pathlib import Path
from itertools import combinations_with_replacement
p=32003;start=time.time();label=sys.argv[1]
r=json.load(open('work/flag-'+label+'-full-fourjet.json'));n=r['n']
ms={d:list(combinations_with_replacement(range(n),d)) for d in [2,3,4]}
ix={d:{m:i for i,m in enumerate(ms[d])} for d in [2,3,4]}
A2=np.array(r['A2'],dtype=np.int64);A3=np.array(r['A3'],dtype=np.int64);A4=np.array(r['A4'],dtype=np.int64)
n2,n3,n4=[len(ms[d]) for d in [2,3,4]];low=n2+n3;N=low+n4
def rref(M,limit=None):
 M=M.copy()%p;limit=M.shape[1] if limit is None else limit;row=0;piv=[];ids=list(range(len(M)))
 for col in range(limit):
  choices=np.flatnonzero(M[row:,col])
  if not len(choices):continue
  j=row+int(choices[0]);M[[row,j]]=M[[j,row]];ids[row],ids[j]=ids[j],ids[row]
  M[row]=M[row]*pow(int(M[row,col]),-1,p)%p
  ii=np.flatnonzero(M[:,col]);ii=ii[ii!=row]
  M[ii]=(M[ii]-M[ii,col,None]*M[row,None,:])%p
  piv.append(col);row+=1
  if row==len(M):break
 return M,piv,ids
MC,pc,ic=rref(np.concatenate([A2,A3],axis=1),n2);qrank=len(pc)
q=MC[:qrank,:n2];cubics,cc,_=rref(MC[qrank:,n2:]);c=cubics[:len(cc)]
rows=list(np.concatenate([A2,A3,A4],axis=1));product_labels=[('row',i) for i in range(135)]
for i,(q0,c0) in enumerate(zip(A2,A3)):
 for a in range(n):
  out=np.zeros(N,dtype=np.int64)
  for mon,v in zip(ms[2],q0):out[n2+ix[3][tuple(sorted((a,)+mon))]]+=v
  for mon,v in zip(ms[3],c0):out[low+ix[4][tuple(sorted((a,)+mon))]]+=v
  if np.any(out):rows.append(out%p);product_labels.append(('linear',i,a))
M,cols,ids=rref(np.array(rows),low);rank=len(cols)
raw=M[rank:,low:];rawids=ids[rank:]
B=[]
for deg,gens in [(2,q),(3,c)]:
 for gen in gens:
  for mon0 in (ms[2] if deg==2 else [(i,) for i in range(n)]):
   out=np.zeros(n4,dtype=np.int64)
   for mon,v in zip(ms[deg],gen):out[ix[4][tuple(sorted(mon+mon0))]]+=v
   B.append(out%p)
B,bp,_=rref(np.array(B));br=len(bp);B=B[:br]
reduced=(raw-(raw[:,bp]@B)%p)%p
_,sp,_=rref(reduced.T);quartic_ids=[rawids[i] for i in sp]
Q=raw[sp]
out=dict(n=n,quadratic_rank=qrank,cubic_span_rank=len(c),low_rank=rank,
 pivot_rows=ids[:rank],pivot_columns=cols,quartic_rows=quartic_ids,
 row_labels=product_labels,I3_degree4_rank=br,additional_quartics=len(sp),
 initial_quadrics=q.tolist(),initial_cubics=c.tolist(),initial_quartics=Q.tolist())
Path('work/flag-'+label+'-initial4.json').write_text(json.dumps(out,indent=2)+'\n')
def expr(row,degree):
 return '+'.join(str(int(v))+'*'+'*'.join('v_'+str(i) for i in mon) for mon,v in zip(ms[degree],row) if v) or '0'
forms=[expr(row,d) for d,mat in [(2,q),(3,c),(4,Q)] for row in mat]
text='R=ZZ/32003[v_0..v_'+str(n-1)+'];\nI=ideal('+','.join(forms)+');\nprint("dim",dim(R/I));print("degree",degree(R/I));print("HS",hilbertSeries(R/I));\n'
Path('work/flag-'+label+'-initial4.m2').write_text(text)
print(label,{k:v for k,v in out.items() if k in ['n','quadratic_rank','cubic_span_rank','low_rank','I3_degree4_rank','additional_quartics']},'seconds',time.time()-start,flush=True)

import sys,json,time,numpy as np
from pathlib import Path
from itertools import combinations_with_replacement
label=sys.argv[1];maximum=int(sys.argv[2]);start=time.time();p=32003
stem='generic-transverse' if label=='b0' else 'transverse'
r=json.load(open('work/flag-'+label+'-'+stem+'-jets-6.json'));n=r['n']
ms={d:list(combinations_with_replacement(range(n),d)) for d in range(2,maximum+1)}
ix={d:{m:i for i,m in enumerate(ms[d])} for d in ms};A={d:np.array(r['A'+str(d)],dtype=np.int64) for d in ms}
def rref(M):
 M=M.copy()%p;row=0;piv=[];ids=list(range(len(M)))
 for col in range(M.shape[1]):
  choices=np.flatnonzero(M[row:,col])
  if not len(choices):continue
  j=row+int(choices[0]);M[[row,j]]=M[[j,row]];ids[row],ids[j]=ids[j],ids[row]
  M[row]=M[row]*pow(int(M[row,col]),-1,p)%p
  ii=np.flatnonzero(M[:,col]);ii=ii[ii!=row]
  M[ii]=(M[ii]-M[ii,col,None]*M[row,None,:])%p;piv.append(col);row+=1
  if row==len(M):break
 return M,piv,ids
profiles={}
for bound in range(3,maximum+1):
 off={d:sum(len(ms[e]) for e in range(2,d)) for d in range(2,bound+1)};N=sum(len(ms[e]) for e in range(2,bound+1));rows=[];labels=[]
 for degree in range(bound-1):
  original=np.concatenate([A[d] for d in range(2,bound-degree+1)],axis=1)
  _,basis,_=rref(original.T)
  for mon0 in combinations_with_replacement(range(n),degree):
   maps={d:np.array([off[d+degree]+ix[d+degree][tuple(sorted(mon0+mon))] for mon in ms[d]],dtype=np.int64) for d in range(2,bound-degree+1)}
   for i in basis:
    out=np.zeros(N,dtype=np.int64)
    for d,loc in maps.items():out[loc]=A[d][i]
    if np.any(out):rows.append(out);labels.append((i,mon0))
 M,piv,ids=rref(np.array(rows));rank=len(piv);length=1+n+N-rank
 t=np.concatenate([np.array(r['t'+str(d)],dtype=np.int64) for d in range(2,bound+1)])
 reduced=(t-t[piv]@M[:rank]%p)%p
 profiles[str(bound)]=dict(n=n,rows=len(rows),columns=N,rank=rank,length=length,t_zero=not np.any(reduced),pivot_columns=piv,pivot_rows=[labels[i] for i in ids[:rank]])
 print(label,bound,'rank',rank,'length',length,'t_zero',not np.any(reduced),'seconds',time.time()-start,flush=True)
 Path('work/flag-'+label+'-truncated-ranks-'+str(maximum)+'.json').write_text(json.dumps(profiles)+'\n')

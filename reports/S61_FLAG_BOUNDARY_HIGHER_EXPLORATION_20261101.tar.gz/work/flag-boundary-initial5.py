import sys,json,time,numpy as np
from pathlib import Path
from itertools import combinations_with_replacement
label=sys.argv[1];start=time.time();p=32003
r=json.load(open('work/flag-'+label+'-jets-5.json'));old=json.load(open('work/flag-'+label+'-initial4.json'));n=r['n']
ms={d:list(combinations_with_replacement(range(n),d)) for d in range(2,6)}
ix={d:{m:i for i,m in enumerate(ms[d])} for d in ms}
off={d:sum(len(ms[e]) for e in range(2,d)) for d in ms};N=sum(map(len,ms.values()));low=off[5]
A={d:np.array(r['A'+str(d)],dtype=np.int64) for d in ms}
def rref(M,limit=None):
 M=M.copy()%p;limit=M.shape[1] if limit is None else limit;row=0;piv=[];ids=list(range(len(M)))
 for col in range(limit):
  choices=np.flatnonzero(M[row:,col])
  if not len(choices):continue
  j=row+int(choices[0]);M[[row,j]]=M[[j,row]];ids[row],ids[j]=ids[j],ids[row]
  M[row]=M[row]*pow(int(M[row,col]),-1,p)%p
  ii=np.flatnonzero(M[:,col]);ii=ii[ii!=row]
  M[ii]=(M[ii]-M[ii,col,None]*M[row,None,:])%p;piv.append(col);row+=1
  if row==len(M):break
 return M,piv,ids
_,qr,_=rref(A[2].T)
rows=list(np.concatenate([A[d] for d in ms],axis=1));labels=[('row',i) for i in range(135)]
for degree,rr in [(1,range(135)),(2,qr)]:
 for mon0 in combinations_with_replacement(range(n),degree):
  maps={d:np.array([off[d+degree]+ix[d+degree][tuple(sorted(mon0+mon))] for mon in ms[d]],dtype=np.int64) for d in range(2,6-degree)}
  for i in rr:
   out=np.zeros(N,dtype=np.int64)
   for d,loc in maps.items():out[loc]=A[d][i]
   if np.any(out):rows.append(out);labels.append(('product',i,mon0))
M,piv,ids=rref(np.array(rows),low);rk=len(piv)
print(label,'low rank',rk,'shape',M.shape,'seconds',time.time()-start,flush=True)
Q,qcols,qids=rref(M[rk:,low:]);Q=Q[:len(qcols)]
print(label,'pure quintic span',len(Q),'seconds',time.time()-start,flush=True)
out=dict(low_rank=rk,pivot_rows=ids[:rk],pivot_columns=piv,row_labels=labels,
 initial_quintics=Q.tolist(),quintic_span_rank=len(Q))
Path('work/flag-'+label+'-initial5.json').write_text(json.dumps(out)+'\n')
def expr(row,degree):
 return '+'.join(str(int(v))+'*'+'*'.join('v_'+str(i) for i in mon) for mon,v in zip(ms[degree],row) if v) or '0'
forms=[expr(row,d) for d,key in [(2,'initial_quadrics'),(3,'initial_cubics'),(4,'initial_quartics')] for row in old[key]]
forms += [expr(row,5) for row in Q]
text='R=ZZ/32003[v_0..v_'+str(n-1)+'];\nI=ideal('+','.join(forms)+');\nprint("dim",dim(R/I));print("degree",degree(R/I));print("HS",hilbertSeries(R/I));\n'
Path('work/flag-'+label+'-initial5.m2').write_text(text)

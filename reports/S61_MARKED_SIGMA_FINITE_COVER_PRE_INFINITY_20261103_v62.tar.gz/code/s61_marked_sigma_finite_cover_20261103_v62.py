#!/usr/bin/env python3
"""Audit the completed finite-pencil conditions; keep two missing bridges explicit."""
import argparse
import hashlib
import json
from pathlib import Path
import sympy as s

ROOT=Path(__file__).resolve().parents[1]
PRIME=32003


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    h=s.Symbol('h');dependencies={}
    def load(name):
        path=ROOT/'reports'/name;data=json.loads(path.read_text());assert data['all_passed']
        for filename,expected in data.get('input_sha256',{}).items():assert sha(ROOT/filename)==expected,filename
        for filename,expected in data.get('evidence_sha256',{}).items():assert sha(path.parent/filename)==expected,filename
        dependencies[str(path.relative_to(ROOT))]=sha(path);return data
    def determinant(record):
        line=next(line for line in record['output'].splitlines()if line.startswith('DETERMINANT_COEFFICIENTS '))
        numbers=list(map(int,line.split()[1:]));assert numbers[0]==len(numbers)-1
        return s.Poly.from_list(list(reversed(numbers[1:])),h,modulus=PRIME).monic()
    full=load('S61_MARKED_SIGMA_PENCIL_FULL5_20261103/report.json')
    full5=next(r for r in full['results']if r['task']=='full:5');zero5=next(r for r in full['results']if r['task']=='zero:5')
    assert full5['shape']==[2603,1432]and zero5['shape']==[2022,932]
    expected=(h*h+9314)*(h*h+2)**2*(h*h-16)**2*(h*h-15105)**2*(h*h-12033)**4
    assert determinant(full5)==s.Poly(expected,h,modulus=PRIME).monic()
    assert determinant(zero5)==s.Poly(h*h+2,h,modulus=PRIME)
    heavy=load('S61_MARKED_SIGMA_PENCIL_RANK_20261103/report.json');heavy6=next(r for r in heavy['results']if r['task']=='heavy:6')
    assert heavy6['shape']==[140,23]
    assert determinant(heavy6)==s.Poly((h*h+2)**2*(h*h+9314),h,modulus=PRIME).monic()
    new=load('S61_MARKED_SIGMA_NEW_QUADRATIC_20261103_v62/report.json')
    assert new['orbit']=='T6'and new['transverse_length_upper']==2 and new['ambient_homogenizer_zero']
    assert new['zero_rho_reduced_support_exhausted_by_new_axis']
    extras=load('S61_MARKED_SIGMA_FINITE_EXTRAS_20261103_v62/report.json')
    assert {r['orbit']for r in extras['cases']}=={'T4','T7'}
    for r in extras['cases']:
        assert r['ambient_t_zero']and r['transverse_length_upper']==r['known_generic_same_incidence_length']
        num=52 if r['orbit']=='T4'else 16
        assert all((125*root*root+num)%PRIME==0 for root in r['residue_h_roots'])
    standard=load('S61_MARKED_SIGMA_STANDARD_FLAG_SPREAD_20261103_v62.json')
    assert standard['ambient_t_zero']and standard['all_h_included']and standard['mixed_characteristic_relative_free_rank']==5
    quadratics=load('S61_MARKED_SIGMA_RHO_ONE_QUADRATICS_20261103_v62/report.json')
    assert len(quadratics['cases'])==3
    assert all(r['length']==4 and r['origin_away_saturation_ideal_one']for r in quadratics['cases'])
    pure=load('S61_MARKED_SIGMA_PURE_PRIME_20261103_v62.json')
    assert pure['h']==4 and pure['three_points_remain_distinct_mod_prime']
    assert all(r['ambient_t_zero_over_V']for r in pure['cases'])
    note=ROOT/'research/notes/S61_MARKED_SIGMA_PENCIL_FINITE_COVER_20261103_v62.md'
    return dict(id='S61_MARKED_SIGMA_FINITE_COVER_20261103_v62',all_passed=True,
                exceptional_radical_mod_prime=str(s.Poly((h*h+2)*(h*h+9314)*(h*h-16)*(h*h-15105)*(h*h-12033),h,modulus=PRIME).monic().as_expr()),
                all_unexceptional_finite_mod_prime_points_covered_by_standard_axis=True,
                new_quadratic_rho_zero_and_nonzero_covered=True,
                finite_T4_T7_extra_points_covered=True,h4_pure_extra_points_spread=True,
                old_quadratic_rho_nonzero_covered=True,
                next_lemma='Apply the actual t-saturated-support finite-weight origin lemma, not saturation-specialization commutation.',
                remaining_conditions_not_claimed_here=[
                    'All nonzero OLD h^2+2=0 plane points have mixed-characteristic ambient nilpotent neighborhoods (including the double junction).',
                    'The weighted projective endpoint [0:0:1] has a matching mixed-characteristic ambient nilpotent neighborhood.'],
                conditional_whole_pencil_implication_proved=True,whole_pencil_removal_claimed=False,
                input_sha256={**dependencies,str(Path(__file__).relative_to(ROOT)):sha(Path(__file__)),str(note.relative_to(ROOT)):sha(note)})


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();report=verify()
    with args.output.open('x')as stream:json.dump(report,stream,indent=2);stream.write('\n')
    print('PASS',report['id'],'conditional; remaining bridges explicit')

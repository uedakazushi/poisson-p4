from pathlib import Path
import json,sympy as s,time
x=json.loads(Path('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json').read_text());a,e,P=s.symbols('a e P');v=s.symbols('x0:6');qs=[]
for i,row in enumerate(x['cleared_qfour_sparse']):
 q=0
 for mon,terms in row:
  c=sum(s.Rational(co)*a**(ex[0]-ex[2]+[0,2,2,1][i])*e**ex[1]*P**ex[2]for ex,co in terms);q+=c*s.prod(z**k for z,k in zip(v,mon[:6]))
 qs.append(q)
J=5*P-6*e-4;new=s.cancel((qs[2]-e*qs[1])/(a**2*J));assert not s.denom(new).has(a,e,P);assert new.subs({v[0]:0,v[5]:0})==0
f=s.factor(qs[1].subs(v[5],0));sample={a:1,e:1,P:1};ranks=[]
for q in [qs[0],qs[1],new,qs[3]]:
 H=s.hessian(q,v)/2;ranks.append(int(H.subs(sample).rank()))
H=s.hessian(qs[1].subs(v[5],0),v[:5])/2
r=dict(Q2_unit_row_replacement='(Q2-eQ1)/(a^2 J)',Q2_replacement_in_ideal_x0_x5=True,Q2_replacement_total_coredegree=max(s.Poly(c,a,e,P).total_degree()for c in s.Poly(new,*v).coeffs()),q1_W0_factorization=str(f),q1_W0_factor_count=len(s.factor_list(f)[1]),sample_only_full_quadric_ranks=ranks,sample_only_q1_W0_rank=int(H.subs(sample).rank()));Path('work/nonsquare-v62/raw-fourquad-structure-v49/rank-probe.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='q1_W0_factorization'}));print('factor output chars',len(str(f)))

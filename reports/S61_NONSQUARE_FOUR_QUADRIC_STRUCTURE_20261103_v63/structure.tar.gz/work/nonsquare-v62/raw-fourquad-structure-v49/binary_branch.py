from pathlib import Path
import sympy as s,json,time,hashlib
start=time.monotonic();src=Path('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json');data=json.loads(src.read_text());a,e,P=s.symbols('a e P');x=s.symbols('x0:6');u,v=s.symbols('u v');qs=[]
for i,row in enumerate(data['cleared_qfour_sparse']):
 q=0
 for mon,terms in row:
  c=sum(s.Rational(co)*a**(ex[0]-ex[2]+[0,2,2,1][i])*e**ex[1]*P**ex[2]for ex,co in terms)
  q+=c*s.prod(z**k for z,k in zip(x,mon[:6]))
 qs.append(s.Poly(q,*x).as_expr())
J=5*P-6*e-4;T=-5*P+6*e-2;S=21*P*e+16*P+140*a;V=9*P*e+4*P+60*a;assert s.expand(3*S-7*V-20*P)==0
sub={x[0]:0,x[4]:0,x[5]:0,x[1]:3*a*T/(2*P)*v-3*V/(10*P)*u,x[2]:v,x[3]:-7*a*T/(4*P)*v+(7*V/(20*P)+1)*u}
assert s.cancel(qs[1].subs(sub,simultaneous=True))==0;assert s.cancel(qs[2].subs(sub,simultaneous=True))==0
f=s.Poly(s.cancel(P**2*qs[0].subs(sub,simultaneous=True)),u,v);g=s.Poly(s.cancel(P**2*qs[3].subs(sub,simultaneous=True)),u,v);cf=[s.factor(f.coeff_monomial(u**i*v**(2-i)))for i in [2,1,0]];cg=[s.factor(g.coeff_monomial(u**i*v**(2-i)))for i in [2,1,0]]
A,B,C=cf;D,E,F=cg;mat=s.Matrix([[A,B,C,0],[0,A,B,C],[D,E,F,0],[0,D,E,F]]);R=s.factor(mat.det(method='domain-ge'))
r=dict(source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),coefficient_variables=['a','e','P'],light_variables=list(map(str,x)),known_units_used=['P'],line_substitution={str(k):str(val)for k,val in sub.items()},q1_and_q2_vanish_identically=True,binary_Q0_coefficients=list(map(str,cf)),binary_Q3_coefficients=list(map(str,cg)),fixed_degree2_by2_homogeneous_resultant=str(R),resultant_identically_zero=R==0,seconds=time.monotonic()-start);Path('work/nonsquare-v62/raw-fourquad-structure-v49/binary-branch.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

from pathlib import Path
import json,sympy as s,time
from sympy.polys.matrices import DomainMatrix
start=time.monotonic();data=json.loads(Path('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json').read_text());a,e,P=s.symbols('a e P');x=s.symbols('x0:6');y=s.symbols('y0:4');qs=[]
for i,row in enumerate(data['cleared_qfour_sparse']):
 q=0
 for mon,terms in row:q+=sum(s.Rational(co)*a**(ex[0]-ex[2]+[0,2,2,1][i])*e**ex[1]*P**ex[2]for ex,co in terms)*s.prod(v**k for v,k in zip(x,mon[:6]))
 qs.append(q)
U=x[4]-5*x[0]+4*x[2];V=x[1];T=x[1]+2*x[3];R=a*(U+x[2])+(21*e+16)*x[1]/10+(9*e+4)*x[3]/5;assert s.expand(4*qs[0]-U*R+5*V*T)==0
J=5*P-6*e-4;new=s.cancel((qs[2]-e*qs[1])/(a**2*J));sample={a:1,e:1,P:1};qs=[q.subs(sample)for q in [qs[0],qs[1],new,qs[3]]];sub=dict(zip(x[:4],y));sub[x[4]]=y[0]+y[1]+2*y[2]+3*y[3];sub[x[5]]=2*y[0]+3*y[1]+5*y[2]+7*y[3];qs=[s.Poly(q.subs(sub,simultaneous=True),*y)for q in qs]
def mons(D):
 return[(i,j,k,D-i-j-k)for i in range(D+1)for j in range(D-i+1)for k in range(D-i-j+1)]
m3,m5=mons(3),mons(5);cols=[]
for q in qs:
 for mon in m3:cols.append(s.Poly(q.as_expr()*s.prod(v**k for v,k in zip(y,mon)),*y))
C=s.Matrix([[q.coeff_monomial(s.prod(v**k for v,k in zip(y,mon)))for q in cols]for mon in m5]);with_path=Path('work/nonsquare-v62/raw-fourquad-structure-v49/generic-CI-matrix.txt');with_path.write_text('56 80\n'+'\n'.join(str(v)for v in C)+'\n');D=DomainMatrix.from_Matrix(C).convert_to(s.QQ);_,piv=D.rref();rank=len(piv);det=None
if rank==56:det=str(DomainMatrix.from_Matrix(C[:,list(piv)]).convert_to(s.QQ).det())
r=dict(exact_Q0_normal_form='4Q0=U R-5 V T',U=str(U),V=str(V),T=str(T),R=str(R),known_inverse_denominators_only_a=True,sample=[1,1,1],sample_known_unit_values=dict(a=1,P=1,F=569,B0=77,C=107,J=-5),four_plane_cut={str(k):str(v)for k,v in sub.items()},degree5_Macaulay_matrix_shape=[56,80],exact_QQ_rank=rank,selected_columns=list(piv),selected_square_determinant=det,proves_generic_regular_sequence=rank==56,does_not_prove_all_U_regularity=True,seconds=time.monotonic()-start);Path('work/nonsquare-v62/raw-fourquad-structure-v49/generic-CI.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

from pathlib import Path
import json,sympy as s
x=s.symbols('x0:6');a,e=s.symbols('a e');r,z,U,V,T,R=s.symbols('r z U V T R');forward=[x[0],x[5],x[4]-5*x[0]+4*x[2],x[1],x[1]+2*x[3],a*(-5*x[0]+5*x[2]+x[4])+(21*e+16)*x[1]/10+(9*e+4)*x[3]/5];inverse=[r,V,R/a-U-6*(e+1)*V/(5*a)-(9*e+4)*T/(10*a),(T-V)/2,5*U+5*r-4*R/a+24*(e+1)*V/(5*a)+2*(9*e+4)*T/(5*a),z]
for got,want in zip(forward,[r,z,U,V,T,R]):assert s.cancel(got.subs(dict(zip(x,inverse)),simultaneous=True)-want)==0
for got,want in zip(inverse,x):assert s.cancel(got.subs(dict(zip([r,z,U,V,T,R],forward)),simultaneous=True)-want)==0
det=s.factor(s.Matrix(forward).jacobian(x).det());assert s.expand(det**2-4*a**2)==0
out=dict(forward_order=['r','z','U','V','T','R'],forward=list(map(str,forward)),inverse_original_order=list(map(str,inverse)),determinant=str(det),both_inverse_compositions_exact=True,denominators_only_a_and_QQ_constants=True);Path('work/nonsquare-v62/raw-fourquad-structure-v49/normal-frame.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

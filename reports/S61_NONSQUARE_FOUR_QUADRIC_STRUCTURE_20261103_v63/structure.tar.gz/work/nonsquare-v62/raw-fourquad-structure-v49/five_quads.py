from pathlib import Path
import json,sympy as s,time
w=Path('work/nonsquare-v62/raw-fourquad-structure-v49');start=time.monotonic();data=json.loads(Path('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json').read_text());a,e,P=s.symbols('a e P');x=s.symbols('x0:6');qs=[]
for i,row in enumerate(data['cleared_qfour_sparse']):
 q=0
 for mon,terms in row:q+=sum(s.Rational(co)*a**(ex[0]-ex[2]+[0,2,2,1][i])*e**ex[1]*P**ex[2]for ex,co in terms)*s.prod(v**k for v,k in zip(x,mon[:6]))
 qs.append(q)
J=5*P-6*e-4;Q2=s.cancel((qs[2]-e*qs[1])/(a**2*J));A=150*P**2*a*x[0]-150*P**2*a*x[2]-40*P**2*a*x[4]-63*P**2*e*x[1]-54*P**2*e*x[3]-48*P**2*x[1]-24*P**2*x[3]-60*P*a*e*x[0]+180*P*a*e*x[2]-12*P*a*e*x[4]+60*P*a*x[0]-420*P*a*x[1]-60*P*a*x[2]-360*P*a*x[3]-52*P*a*x[4]+800*a**2*x[0]-400*a**2*x[4]
D=s.cancel((40*x[0]*qs[1]-A*Q2)/x[5]);assert not s.denom(D).has(*x,a,e,P);five=[s.Poly(q,*x)for q in [qs[0],qs[1],Q2,qs[3],D]];mons=sorted(set().union(*(q.monoms()for q in five)));assert len(mons)==21
with(w/'five-native.txt').open('w')as f:
 f.write('5 21 0\n')
 for q in five:
  for mon in mons:
   c=s.Poly(q.coeff_monomial(s.prod(v**k for v,k in zip(x,mon))),a,e,P);f.write(str(len(c.terms())if not c.is_zero else 0)+(''.join(' '+str(co)+' '+' '.join(map(str,ex))for ex,co in c.terms())if not c.is_zero else '')+'\n')
(w/'aPJ-units.txt').write_text('a\nd\n5*d-6*e-4\n')
r=dict(five_quadric_order=['Q0','Q1','Q2prime','Q3','D'],Q2prime='(Q2-eQ1)/(a^2 J)',D='(40*x0*Q1-A*Q2prime)/x5',all_polynomial_identities_exact=True,quadric_monomials=mons,coefficient_coredegrees=[max(s.Poly(c,a,e,P).total_degree()for c in q.coeffs())for q in five],total_core_coefficient_terms=sum(len(s.Poly(c,a,e,P).terms())for q in five for c in q.coeffs()),seconds=time.monotonic()-start);(w/'five-input.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

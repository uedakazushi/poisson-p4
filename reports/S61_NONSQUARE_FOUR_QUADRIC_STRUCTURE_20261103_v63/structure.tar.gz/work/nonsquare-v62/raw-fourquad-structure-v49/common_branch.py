from pathlib import Path
import json,sympy as s,time
start=time.monotonic();data=json.loads(Path('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json').read_text());a,e,P=s.symbols('a e P');x=s.symbols('x0:6');z=s.symbols('z0:4');qs=[]
for i,row in enumerate(data['cleared_qfour_sparse']):
 q=0
 for mon,terms in row:q+=sum(s.Rational(co)*a**(ex[0]-ex[2]+[0,2,2,1][i])*e**ex[1]*P**ex[2]for ex,co in terms)*s.prod(v**k for v,k in zip(x,mon[:6]))
 qs.append(q)
R=15*P**2-6*P*e+6*P+80*a;T=-5*P+6*e-2;S=21*P*e+16*P+140*a;V=9*P*e+4*P+60*a;K=85*P**2-12*P*e+58*P+600*a;B=30*a*R*x[0]-9*P*S*x[1]+90*P*a*T*x[2]-18*P*V*x[3]-2*a*K*x[4];A=(B+10*a*P*(5*P-6*e-4)*x[4])/3
assert s.expand(qs[1].subs(x[5],0)-A*B/6075)==0
new=s.cancel((qs[2]-e*qs[1])/(a**2*(5*P-6*e-4)));assert s.expand(new.subs(x[5],0)-40*x[0]*B/6075)==0
t=(30*a*R*z[0]+90*P*a*T*z[1]-18*P*V*z[3]-2*a*K*z[2])/(180*P**2);sub={x[0]:z[0],x[1]:3*t,x[2]:z[1],x[3]:-s.Rational(7,2)*t+z[3],x[4]:z[2],x[5]:0};assert s.cancel(B.subs(sub,simultaneous=True))==0
f=s.Poly(s.cancel(P**4*qs[0].subs(sub,simultaneous=True)),*z);g=s.Poly(s.cancel(P**4*qs[3].subs(sub,simultaneous=True)),*z);F=s.factor(f.as_expr());G=s.factor(g.as_expr());sample={a:1,e:1,P:1};rank0=int(s.hessian(f.as_expr(),z).subs(sample).rank());rank3=int(s.hessian(g.as_expr(),z).subs(sample).rank());common=s.factor(s.gcd(f.as_expr(),g.as_expr()));out=dict(exact_q1_W0='A*B/6075',exact_Q2new_W0='40*x0*B/6075',A=str(s.expand(A)),B=str(s.expand(B)),B_minus_3A='-10*a*P*J*x4',known_units_for_B_chart=['P'],sample_only_Q0_restriction_rank=rank0,sample_only_Q3_restriction_rank=rank3,Q0_restricted_factorization=str(F),Q3_restricted_factorization=str(G),exact_QQ_polynomial_gcd=str(common),seconds=time.monotonic()-start);Path('work/nonsquare-v62/raw-fourquad-structure-v49/common-branch.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k not in ['Q0_restricted_factorization','Q3_restricted_factorization']}),flush=True)

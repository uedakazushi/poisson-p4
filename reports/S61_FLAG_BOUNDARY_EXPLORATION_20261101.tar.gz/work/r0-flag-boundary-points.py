import sys,json,time
sys.path.insert(0,'code')
import sympy as s
from s61_model import S61
from s61_minimal_infinity_local_data_20261101 import calculate
r=json.load(open('work/r0-flag-probe.json'))['FLAG'];m=S61();one=[i for i,w in enumerate(m.reduced['parameter_weights']) if w==1];H=s.Matrix(r['beta_kernel']).applyfunc(s.Rational);out={}
for label,zero in [('b0',[0]),('b1',[1]),('b0b1',[0,1])]:
 start=time.time();p=s.Matrix(r['point61']).applyfunc(s.Rational);b=s.Matrix(range(2,17))
 for i in zero:b[i]=0
 for i,v in zip(one,H*b):p[i]=v
 local=calculate(m,True,p);stats=[local['leading_jacobian_rank'],local['homogenized_jacobian_rank'],local['quadratic_span_rank'],len(local['tangent_basis'][0])-local['common_hessian_rank'],local['homogenizer_zero_on_tangent']];print(label,stats,time.time()-start,flush=True);out[label]=dict(stats=stats,local=local);json.dump(out,open('work/r0-flag-boundary-points.json','w'),indent=2)

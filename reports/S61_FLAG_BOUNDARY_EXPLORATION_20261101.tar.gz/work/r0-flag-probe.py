import sys
sys.path.insert(0,'code')
#!/usr/bin/env python3
"""Finite mixed-orbit cover of the remaining R0 normal-form faces."""
import argparse,json,time,hashlib
from pathlib import Path
import sympy as s
from s61_model import S61,X,J as J0
from s61_nil22_infinity_20261101 import beta_matrix
from s61_flag_transverse_obstruction_20261101 import specialize
from primitive_jet_elliptic_curve_20261101 import primitive_beta
from weight1_structure import COORDS,sp_basis,infinitesimal_action
ROOT=Path.cwd()
def rank(M):return len(M.to_DM().rref()[1])
def enc(M):return [[str(v) for v in row] for row in M.tolist()]
def flag_data():
 m=S61();x,y,z,w=X[1:];V=s.Matrix([x,y,z,w]);one=[i for i,v in enumerate(m.reduced['parameter_weights']) if v==1];two=[i for i,v in enumerate(m.reduced['parameter_weights']) if v==2];zz,bu,beta=primitive_beta(m);v=s.Matrix([beta[i,j].diff(zz[k]) for (i,j),k in COORDS]);bs=v.jacobian(bu);rows=list(bs.T.to_DM().rref()[1]);left=bs[rows,:].inv();acts=s.Matrix.hstack(*[(left*infinitesimal_action(v,A)[rows,:]).applyfunc(s.expand) for A in sp_basis()]);out={}
 def coords(Q):
  P=X[0]**2*J0;P[1:,1:]+=Q;return s.Matrix([m.normalize(P)['parameters'][i] for i in two])
 for label,G in [('FLAG',x*x*z),('SQUARE_BINARY',x*z*z),('SQUARE_BINARY_W',x*w*w)]:
  start=time.time();Q=s.zeros(4);Q[1,2]=s.diff(G,w);Q[1,3]=-s.diff(G,z);Q-=Q.T;M=beta_matrix(m,Q);H=s.Matrix.hstack(*M.nullspace());b=H*s.Matrix(range(2,H.cols+2));sub=dict(zip(bu,b));BD=H.row_join(acts.subs(sub));q0=coords(Q);fixed=next(i for i,v in enumerate(q0) if v);chart=[i for i in range(45) if i!=fixed];orbit=[]
  for A in sp_basis():
   dQ=sum(((A*V)[i]*Q.diff(V[i]) for i in range(4)),s.zeros(4))-A*Q-Q*A.T;dq=coords(dQ);dq-=q0*dq[fixed]/q0[fixed];orbit.append(dq[chart,:])
  QD=s.Matrix.hstack(*orbit);point=s.zeros(61,1)
  for i,v in zip(one,b):point[i]=v
  for i,v in zip(two,q0):point[i]=v
  joint=BD.col_join(s.zeros(44,H.cols).row_join(QD));stats=dict(Hdim=H.cols,orbitdim=rank(QD),beta_rank=rank(BD),joint_rank=rank(joint))
  print(label,str(G),stats,time.time()-start,flush=True);out[label]=dict(G=str(G),stats=stats,beta_kernel=enc(H),q_orbit_differential=enc(QD),source_beta_differential=enc(BD),point61=list(map(str,point)))
  bb=s.symbols('b:'+str(H.cols));beta_all=H*s.Matrix(bb);_,F=specialize(m,dict(zip(one,beta_all)),True);assert all(s.expand(sum(c*s.prod(q0[i] for i in mon) for mon,c in f.items() if len(mon)==2))==0 for f in F)
  if label=='T3':
   for constraint in [bu[0],bu[1],bu[2],bu[3],5*bu[4]-bu[13],5*bu[9]+bu[14],5*bu[6]-bu[15]]:assert s.expand(constraint.subs(dict(zip(bu,beta_all)),simultaneous=True))==0
   assert H.cols==9
 return out

from s61_minimal_infinity_local_data_20261101 import calculate
r=flag_data()
for label,c in r.items():
 loc=calculate(S61(),True,s.Matrix(c['point61']).applyfunc(s.Rational));c['local']=loc
 print(label,'LOCAL',loc['leading_jacobian_rank'],loc['homogenized_jacobian_rank'],loc['quadratic_span_rank'],len(loc['tangent_basis'][0])-loc['common_hessian_rank'],flush=True)
json.dump(r,open('work/r0-flag-probe.json','w'),indent=2)

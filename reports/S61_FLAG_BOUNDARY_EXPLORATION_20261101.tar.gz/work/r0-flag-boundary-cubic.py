import sys,json,time
sys.path.insert(0,'code')
import sympy as s
from s61_local_cubic_certificate_20261101 import profile
r=json.load(open('work/r0-flag-boundary-points.json'));out={}
for label in ['b1','b0','b0b1']:
 st=time.time();p=s.Matrix(r[label]['local']['point61']).applyfunc(s.Rational);q=profile(p);print(label,'quad',len(q['initial_quadrics']),'cubic',len(q['initial_cubics']),time.time()-st,flush=True);out[label]=q;json.dump(out,open('work/r0-flag-boundary-cubic.json','w'),indent=2)

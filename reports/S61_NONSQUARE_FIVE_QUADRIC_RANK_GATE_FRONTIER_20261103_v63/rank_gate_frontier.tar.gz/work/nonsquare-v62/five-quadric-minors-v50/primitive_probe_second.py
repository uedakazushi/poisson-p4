from pathlib import Path
import subprocess,resource,os,signal,time,json
w=Path('work/nonsquare-v62/five-quadric-minors-v50');base=Path('work/nonsquare-v62/raw-fourquad-structure-v49');exe=Path('work/nonsquare-v62/five-quadric-minors-v50/primitive-optimized-bin');results=[]
def cap():resource.setrlimit(resource.RLIMIT_AS,(512000*1024,512000*1024))
for row in [0,1]:
 t=time.monotonic()
 with(w/f'second-primitive-row{row}.log').open('w')as f:
  p=subprocess.Popen([str(exe),str(w/'after-primitive.txt'),str(base/'aPJ-units.txt'),'1',str(row),str(w/f'second-primitive-row{row}.witness'),'8'],stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True)
  try:p.wait(timeout=15);timeout=False
  except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 r=dict(row=row,elapsed=time.monotonic()-t,exit_code=p.returncode,timed_out=timeout,witness=(w/f'second-primitive-row{row}.witness').exists());results.append(r);print(json.dumps(r),flush=True)
(w/'second-primitive-probes.json').write_text(json.dumps(results,indent=2)+'\n')

from pathlib import Path
import sympy as s,json,hashlib,time
src=Path('work/nonsquare-v62/raw-fourquad-structure-v49/five-after.txt');w=Path('work/nonsquare-v62/five-quadric-minors-v50');a,e,P=s.symbols('a e P');ts=iter(src.read_text().split());n,m,k=[int(next(ts))for _ in range(3)];assert(n,m,k)==(3,19,2);used=[int(next(ts))for _ in range(k)];orig=[int(next(ts))for _ in range(n)];rows=[]
for i in range(n):
 row=[]
 for j in range(m):
  q=0
  for _ in range(int(next(ts))):
   c=s.Rational(next(ts));x,y,z=[int(next(ts))for _ in range(3)];q+=c*a**x*e**y*P**z
  row.append(q)
 rows.append(row)
M=s.Matrix(rows);sample=M.subs({a:1,e:1,P:1});_,piv=sample.rref();assert len(piv)==3;start=time.monotonic();piv=list(piv);det=s.factor(M[:,piv].det(method='domain-ge'));out=dict(source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),safe_prefix_unit_pivots=k,remaining_original_quadric_rows=orig,selected_columns=piv,exact_selected_minor=str(det),seconds=time.monotonic()-start);(w/'first-minor.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out),flush=True)

from pathlib import Path
from fractions import Fraction
import json,hashlib
w=Path('work/nonsquare-v62/five-quadric-localized-QQ-v51');src=Path('work/nonsquare-v62/raw-fourquad-structure-v49/five-after.txt');ts=iter(src.read_text().split());n,m,k=[int(next(ts))for _ in range(3)];assert(n,m,k)==(3,19,2);used=[int(next(ts))for _ in range(k)];rows=[int(next(ts))for _ in range(n)];A=[]
for i in range(n):
 row=[]
 for j in range(m):
  q=[]
  for _ in range(int(next(ts))):
   c=Fraction(next(ts));ex=tuple(int(next(ts))for _ in range(3));q.append((ex,c))
  row.append(q)
 A.append(row)
expr=lambda q:'('+(' + '.join('('+str(c)+')'+''.join('*'+v+('^'+str(k)if k!=1 else'')for v,k in zip(('a','e','d'),ex)if k)for ex,c in q)or'0')+')'
with(w/'source.sing').open('w')as f:
 f.write('ring r=0,(a,e,d,z),dp;option(redSB);matrix Q[3][19];\n')
 for i,row in enumerate(A):
  for j,q in enumerate(row):
   if q:f.write(f'Q[{i+1},{j+1}]='+expr(q)+';\n')
 f.write('poly taskRel=z*a*d*(5*d-6*e-4)-1;matrix taskId[3][3];taskId[1,1]=1;taskId[2,2]=1;taskId[3,3]=1;matrix taskE[3][22];int taskRow,taskCol;for(taskRow=1;taskRow<=3;taskRow++){for(taskCol=1;taskCol<=19;taskCol++){taskE[taskRow,taskCol]=Q[taskRow,taskCol];}taskE[taskRow,19+taskRow]=taskRel;}module taskM=taskE;print("FIVE_LOCALIZED_QQ_INPUT_READY");matrix taskT;module taskG=liftstd(taskM,taskT);print("FIVE_LOCALIZED_QQ_GB_DONE");print(ncols(matrix(taskG)));if(size(reduce(freemodule(3),taskG))!=0){print("FIVE_LOCALIZED_QQ_NONUNIT");quit;}print("FIVE_LOCALIZED_QQ_UNIT");matrix taskH=lift(taskG,freemodule(3));matrix taskL=taskT*taskH;if(size(module(taskE*taskL-taskId))!=0){print("ERROR_FIVE_LOCALIZED_QQ_IDENTITY");quit;}print("FIVE_LOCALIZED_QQ_EXACT_IDENTITY_PASS");int taskI,taskJ;poly taskP;intvec taskEx;int taskTerms=0;int taskDegree=0;link taskOut="ASCII:w '+str((w/'right-inverse-native4.txt').resolve())+'";open(taskOut);write(taskOut,string(nrows(taskL))+" "+string(ncols(taskL))+" 0");for(taskI=1;taskI<=nrows(taskL);taskI++){for(taskJ=1;taskJ<=ncols(taskL);taskJ++){taskP=taskL[taskI,taskJ];taskTerms=taskTerms+size(taskP);if(deg(taskP)>taskDegree){taskDegree=deg(taskP);}write(taskOut,string(size(taskP)));while(taskP!=0){taskEx=leadexp(taskP);write(taskOut,string(leadcoef(taskP))+" "+string(taskEx[1])+" "+string(taskEx[2])+" "+string(taskEx[3])+" "+string(taskEx[4]));taskP=taskP-lead(taskP);}}}close(taskOut);print("FIVE_LOCALIZED_QQ_COFACTOR_TERMS");print(taskTerms);print("FIVE_LOCALIZED_QQ_COFACTOR_DEGREE");print(taskDegree);print("FIVE_LOCALIZED_QQ_NATIVE_SAVED");quit;')
r=dict(source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),matrix_shape=[3,19],known_safe_prefix_pivots=2,localization_only='a*P*(5P-6e-4)',inverse_variable='z=1/(a*P*J)',extended_matrix_shape=[3,22],exact_target='[M|(z*a*P*J-1)*I3]*L=I3',scope='ONLY five-quadric rank5 gate',raw24_rank41_not_proved=True);(w/'source.json').write_text(json.dumps(r,indent=2)+'\n');s=Path('work/nonsquare-v62/raw-fourquad-GF-v36/run.py').read_text().replace('raw-fourquad-GF-v36','five-quadric-localized-QQ-v51');s=s.replace('p.wait(timeout=60)','p.wait(timeout=59.8)');(w/'run.py').write_text(s)

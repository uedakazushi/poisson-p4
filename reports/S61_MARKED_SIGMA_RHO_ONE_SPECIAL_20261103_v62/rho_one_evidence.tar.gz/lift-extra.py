from pathlib import Path
from collections import defaultdict
from fractions import Fraction
from math import gcd,lcm,isqrt
import json,sys,sympy as s
sys.path.insert(0,'code')
from s61_marked_sigma_point_lift_20261103_v62 import load_model,coerce
P=32003;raw=[]
with Path('work/cloud-marked-20261103/work/flag_boundary_geometry_20261101/marked-vertical-symbolic/global-rows').open()as f:
 n,N=map(int,f.readline().split())
 for i in range(N):
  w,k=map(int,f.readline().split());row=defaultdict(Fraction)
  for _ in range(k):
   q,*es=f.readline().split();e=tuple(map(int,es));row[e[:14]]+=Fraction(q)
  if i<135:
   den=lcm(*(c.denominator for c in row.values()));assert den%P
   raw.append({ex:int(c*den) for ex,c in row.items()if c})
print('parsed',len(raw),sum(map(len,raw)),flush=True)
MAX=[max(ex[i] for row in raw for ex in row)for i in range(14)]
def evaluate(row,vals,mod,derivative=True):
 powers=[[pow(v,k,mod)for k in range(m+1)]for v,m in zip(vals,MAX)];value=0;grad=[0]*14
 for ex,co in row.items():
  active=[i for i,e in enumerate(ex)if e];term=co%mod
  for i in active:term=term*powers[i][ex[i]]%mod
  value=(value+term)%mod
  if derivative:
   for j in active:
    term=co*ex[j]%mod
    for i in active:term=term*powers[i][ex[i]-(i==j)]%mod
    grad[j]=(grad[j]+term)%mod
 return value,grad
def invert(A,m):
 n=len(A);B=[list(row)+[int(i==j)for j in range(n)]for i,row in enumerate(A)]
 for j in range(n):
  pivot=next(i for i in range(j,n)if B[i][j]%P);B[j],B[pivot]=B[pivot],B[j];v=pow(B[j][j],-1,m);B[j]=[c*v%m for c in B[j]]
  for i in range(n):
   if i==j:continue
   v=B[i][j]
   if v:B[i]=[(a-v*b)%m for a,b in zip(B[i],B[j])]
 return [row[n:]for row in B]
def reconstruct(a,m):
 bound=isqrt(m//2);r0,r1=m,a%m;t0,t1=0,1
 while abs(r1)>bound:
  q=r0//r1;r0,r1=r1,r0-q*r1;t0,t1=t1,t0-q*t1
 if not t1:return None
 if t1<0:r1,t1=-r1,-t1
 if t1>bound or gcd(r1,t1)!=1 or (r1-a*t1)%m:return None
 return Fraction(r1,t1)
def point(a):
 text=Path(f'work/cloud-marked-finite-v62/h-{a}-extra.log').read_text();line=next(z for z in text.splitlines()if z.startswith('NORMALS='));v=json.loads(line[8:].replace('{','[').replace('}',']'));return[a,*[x%P for x in v]]
L=load_model('reports/S61_MARKED_SIGMA_POINT_LIFT_20261103_v62_FINAL/model')
outputs=[]
for a,other in[(4499,27504),(15938,16065)]:
 vals=point(a);op=point(other);sign=[]
 for x,y in zip(vals[1:],op[1:]):
  if x==y:sign.append(0)
  elif(x+y)%P==0:sign.append(1)
  else:raise Exception('mixedconjugacy',x,y)
 gradients=[evaluate(row,vals,P)[1]for row in raw];order=sorted(range(135),key=lambda i:len(raw[i]));G=s.Matrix([gradients[i]for i in order]);rref=G.T.to_DM().convert_to(s.GF(P)).rref();selected=[order[i]for i in rref[1]];rank=len(selected)
 print('case',a,'rank',rank,'selected',selected,flush=True);assert rank in[13,14]
 if rank==13:
  selected=[order[i]for i in G[:,1:].T.to_DM().convert_to(s.GF(P)).rref()[1]];assert len(selected)==13
 mod=P
 for step in range(3):
  newmod=mod*mod
  if rank==13:
   h2=Fraction(-52,125)if a==4499 else Fraction(-16,125);num,den=h2.numerator,h2.denominator;hv=vals[0];f=(den*hv*hv-num)%newmod;vals[0]=(hv-f*pow(2*den*hv,-1,newmod))%newmod
  ev=[evaluate(raw[i],vals,newmod)for i in selected];ff=[z[0]for z in ev];JJ=[z[1]if rank==14 else z[1][1:]for z in ev];inverse=invert(JJ,newmod);delta=[sum(v*c for v,c in zip(row,ff))%newmod for row in inverse]
  start=0 if rank==14 else 1
  for j,z in enumerate(delta):vals[start+j]=(vals[start+j]-z)%newmod
  assert not any(evaluate(raw[i],vals,newmod,False)[0]for i in selected)
  mod=newmod
  hsquare=reconstruct(vals[0]*vals[0]%mod,mod);cs=[reconstruct(v*pow(vals[0],-1,mod)%mod if odd else v,mod)for v,odd in zip(vals[1:],sign)]
  print('step',step,'h2',hsquare,'coeff',cs,flush=True)
  if hsquare is None or any(c is None for c in cs):continue
  K=s.QQ.algebraic_field(s.sqrt(s.Rational(hsquare.numerator,hsquare.denominator)),alias='h');h=K.unit;norm=[coerce(K,s.Rational(c.numerator,c.denominator))*(h if odd else K.one)for c,odd in zip(cs,sign)];Q=L.lift(h,norm,rho=1,domain=K)
  print('exactzero',Q['all135_zero'],'t',Q['t'],flush=True)
  if Q['all135_zero'] and not Q['t']:
   outputs.append({'h_mod_p':a,'h_square':str(hsquare),'normal_coefficients':[str(c)for c in cs],'normal_h_exponents':sign,'newton_rank':rank,'newton_rows':selected,'precision':mod,'q':[str(K.to_sympy(x))for x in Q['q']],'beta':[str(K.to_sympy(x))for x in Q['beta']]});break
 else:raise RuntimeError('liftfailed')
Path('work/cloud-marked-finite-v62/lift-extra.json').write_text(json.dumps(outputs,indent=2)+'\n')

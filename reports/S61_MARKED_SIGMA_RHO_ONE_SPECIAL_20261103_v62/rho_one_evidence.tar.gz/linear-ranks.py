from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import sympy as s
from sympy.polys.matrices.normalforms import smith_normal_decomp
p=32003;h=s.Symbol('h');values=[0,4499,27504,15938,16065,4];J=s.zeros(135,13)
with Path('work/cloud-marked-20261103/work/flag_boundary_geometry_20261101/marked-vertical-symbolic/global-rows').open()as f:
 assert tuple(map(int,f.readline().split()))==(14,136)
 for i in range(136):
  w,k=map(int,f.readline().split())
  for _ in range(k):
   q,*es=f.readline().split();e=list(map(int,es));ex=e[1:14]
   if i>=135 or sum(ex)!=1:continue
   j=ex.index(1);J[i,j]+=s.Rational(q)*h**e[0]
for value in values:
 rank=J.subs(h,value).applyfunc(lambda c:int(c.p)*pow(int(c.q),-1,p)%p).to_DM().convert_to(s.GF(p)).rank()
 print('h',value,'rank',rank,'embeddingdim',13-rank,flush=True)
dom=s.QQ.poly_ring(h);D=J.to_DM().convert_to(dom);dd,uu,vv=smith_normal_decomp(D)
assert uu*D*vv==dd
invariants=[dd[i,i].element for i in range(13) if dd[i,i].element]
print('invariants',invariants,flush=True)
Path('work/cloud-marked-finite-v62/linear-matrix.json').write_text(__import__('json').dumps({'matrix':[[str(c)for c in row] for row in J.tolist()],'invariants':[str(c) for c in invariants]},indent=2)+'\n')

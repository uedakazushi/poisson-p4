from pathlib import Path
import subprocess,resource,os,signal,time,json
w=Path('work/nonsquare-v62/five-rank-last-row-v61');src=w/'primitive-row.txt';units=Path('work/nonsquare-v62/raw-fourquad-structure-v49/aPJ-units.txt');start=time.monotonic();runs=[]
commands=[(0,['work/nonsquare-v62/five-quadric-minors-v50/primitive-optimized-bin']),(1,['work/nonsquare-v62/five-quadric-degree1-v53/degree1-bin']),(2,['work/nonsquare-v62/five-quadric-degree23-v60/degree23-bin'])]
def cap():resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024))
for deg,exe in commands:
 budget=60-(time.monotonic()-start)
 if budget<=0:break
 t=time.monotonic();wit=w/f'D{deg}.witness';cmd=exe+[str(src),str(units),'0','0',str(wit),'8']+([str(deg)]if deg==2 else[])
 with(w/f'D{deg}.log').open('w')as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True)
  try:p.wait(timeout=budget);timeout=False
  except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 r=dict(degree=deg,exit_code=p.returncode,timed_out=timeout,elapsed=time.monotonic()-t,witness=wit.exists());runs.append(r);(w/'searches.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(r),flush=True)
 if wit.exists()or timeout:break

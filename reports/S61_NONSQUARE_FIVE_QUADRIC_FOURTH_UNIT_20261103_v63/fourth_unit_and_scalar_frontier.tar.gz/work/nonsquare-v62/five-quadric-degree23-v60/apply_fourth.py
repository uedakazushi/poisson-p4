from pathlib import Path
import subprocess,resource,time,os,signal,json
w=Path('work/nonsquare-v62/five-quadric-degree23-v60');t=time.monotonic()
def cap():resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024))
with(w/'apply-fourth.log').open('w')as f:
 p=subprocess.Popen(['work/nonsquare-v62/raw-fourquad-structure-v49/unit-pivots-bin','work/nonsquare-v62/five-quadric-minors-v50/after-primitive.txt',str(w/'last-row.txt'),'work/nonsquare-v62/raw-fourquad-structure-v49/aPJ-units.txt','1',str(w/'D2-row0.witness'),'0'],stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True)
 try:p.wait(timeout=20);timeout=False
 except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
r=dict(exit_code=p.returncode,timed_out=timeout,elapsed=time.monotonic()-t,maxRSS_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss);(w/'apply-fourth.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

from pathlib import Path
import subprocess,time,resource,os,signal,json
w=Path('work/nonsquare-v62/five-quadric-degree23-v60');start=time.monotonic();runs=[]
def cap():resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024))
for deg,row in [(2,0),(2,1),(3,0),(3,1)]:
 remaining=60-(time.monotonic()-start)
 if remaining<=0:break
 t=time.monotonic();prefix=f'D{deg}-row{row}';witness=w/(prefix+'.witness')
 with(w/(prefix+'.log')).open('w')as f:
  p=subprocess.Popen([str(w/'degree23-bin'),'work/nonsquare-v62/five-quadric-minors-v50/after-primitive.txt','work/nonsquare-v62/raw-fourquad-structure-v49/aPJ-units.txt','1',str(row),str(witness),'8',str(deg)],stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True)
  try:p.wait(timeout=remaining);timeout=False
  except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 r=dict(degree=deg,row=row,exit_code=p.returncode,timed_out=timeout,elapsed=time.monotonic()-t,witness=witness.exists());runs.append(r);(w/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(r),flush=True)
 if witness.exists()or timeout:break

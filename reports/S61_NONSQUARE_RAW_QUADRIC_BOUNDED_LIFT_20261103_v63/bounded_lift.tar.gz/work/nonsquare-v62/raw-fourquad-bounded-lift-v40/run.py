from pathlib import Path
import subprocess,time,resource,os,signal,json
w=Path('work/nonsquare-v62/raw-fourquad-bounded-lift-v40');source=Path('work/nonsquare-v62/raw-fourquad-GF-v36/M-QQ-native.txt');out=[]
def cap():resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024))
for D in [1,2,3]:
 t=time.monotonic()
 with(w/f'D{D}.log').open('w')as f:
  p=subprocess.Popen([str(w/'modular-bin'),str(source),str(D)],stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True);timeout=False
  try:p.wait(timeout=60)
  except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 r=dict(D=D,exit_code=p.returncode,timed_out=timeout,elapsed_seconds=time.monotonic()-t,max_RSS_upper_bound_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,QQ_claim=False)
 if p.returncode==0:
  r.update(json.loads((w/f'D{D}.log').read_text().splitlines()[-1]));r['QQ_bounded_nonmembership_certified_by_full_column_rank']=r['rank_coefficient_matrix']==r['unknown_coefficients_per_target'] and r['rank_augmented_all24']>r['rank_coefficient_matrix']
 out.append(r);(w/'runs.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(r),flush=True)
 if timeout:break

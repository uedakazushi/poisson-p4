from pathlib import Path
import sympy as s,json,time,resource
from sympy.polys.matrices import DomainMatrix
resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));w=Path('work/nonsquare-v62/quad78-small-gates-v83');start=time.monotonic();t,v,H,z=s.symbols('t v H z');data=json.loads(Path('work/nonsquare-v62/pair-finite-proof-v76/certificate.json').read_text());load=lambda ts:sum(s.Rational(c)*t**ex[0]*v**ex[1]*H**ex[2]for ex,c in ts);rows=[[load(ts)for ts in row]for row in data['natural_rows']]
def symmetric(row):return s.Matrix([[row[0],row[1]/2,row[3]/2],[row[1]/2,row[2],row[4]/2],[row[3]/2,row[4]/2,row[5]]])
A,B=map(symmetric,rows);DM=DomainMatrix.from_Matrix(A+z*B);det=DM.domain.to_sympy(DM.det());cz=s.Poly(det,z);assert cz.degree()==3;coeff=[s.Poly(cz.coeff_monomial(z**i),t,v,H,domain=s.QQ)for i in range(4)];normalized=[];records=[]
for i,q in enumerate(coeff):
 vals=[]
 for unit in [t,H-8*t,5*H-2*v-4]:
  up=s.Poly(unit,t,v,H,domain=s.QQ);n=0
  while not q.is_zero:
   qq,r=q.div(up)
   if r:break
   q=qq;n+=1
  vals.append(n)
 content,q=q.primitive();normalized.append(q);record=dict(lambda_coefficient=i,terms=len(q.terms()),degrees_t_v_H=[q.degree(var)for var in (t,v,H)],total_degree=q.total_degree(),known_unit_powers_t_P_J=vals,QQcontent=str(content));records.append(record);print(json.dumps(record),flush=True)
print('firstnormalizedfactor',s.factor(normalized[0].as_expr()),flush=True)
enc=lambda q:[[list(ex),str(c)]for ex,c in s.Poly(q,t,v,H,domain=s.QQ).terms()]
(w/'pencil-profile.json').write_text(json.dumps(dict(pair_source='frozen actual natural pair coefficient list',monomial_order=['zlight^2','vlight*zlight','vlight^2','u*zlight','u*vlight','u^2'],raw_pencil_coefficients=[enc(q.as_expr())for q in coeff],normalized_pencil_coefficients=[enc(q.as_expr())for q in normalized],normalization_records=records,first_factored_coefficient=str(s.factor(normalized[0].as_expr())),commonfactor_implies_all4_zero=True,converse_not_assumed=True,seconds=time.monotonic()-start),indent=2)+'\n')

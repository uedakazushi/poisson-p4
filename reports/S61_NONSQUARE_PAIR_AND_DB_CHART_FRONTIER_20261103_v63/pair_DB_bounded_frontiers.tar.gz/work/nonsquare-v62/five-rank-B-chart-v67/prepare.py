from pathlib import Path
import sympy as s,json,time
w=Path('work/nonsquare-v62/five-rank-B-chart-v67');start=time.monotonic();a,e,P=s.symbols('a e P');ys=s.symbols('r U V T R');r,U,V,T,R=ys;J=5*P-6*e-4;DB=20*P**2+3*P*e+20*P+180*a
cert=json.loads(Path('work/nonsquare-v62/gcd-proportional-certificate-v58/certificate.json').read_text());load=lambda ts:sum(s.Rational(c)*a**ex[0]*e**ex[1]*P**ex[2]for ex,c in ts);bs=list(map(load,cert['global_B_normal_coefficients']));br=bs[0];assert s.expand(br+20*a*DB)==0
# Read literal native five quadrics, using the pinned six-light monomial order.
it=iter(Path('work/nonsquare-v62/raw-fourquad-structure-v49/five-native.txt').read_text().split());n,m,k=[int(next(it))for _ in range(3)];assert(n,m,k)==(5,21,0);coeff=[]
for i in range(n):
 row=[]
 for j in range(m):
  nt=int(next(it));q=0
  for z in range(nt):
   c=s.Rational(next(it));ex=[int(next(it))for _ in range(3)];q+=c*a**ex[0]*e**ex[1]*P**ex[2]
  row.append(q)
 coeff.append(row)
mons=json.loads(Path('work/nonsquare-v62/raw-fourquad-structure-v49/five-input.json').read_text())['quadric_monomials'];x=s.symbols('x0:6')
images=[r,V,R/a-U-6*(e+1)*V/(5*a)-(9*e+4)*T/(10*a),(T-V)/2,5*U+5*r-4*R/a+24*(e+1)*V/(5*a)+2*(9*e+4)*T/(5*a),s.Integer(0)]
D=sum(c*s.prod(xx**p for xx,p in zip(x,mon))for c,mon in zip(coeff[4],mons));Horig=s.hessian(D,x)/2;L=s.Matrix([[s.diff(image,y)for y in ys]for image in images]);HD=(a*a*(L.T*Horig*L)).applyfunc(s.cancel)
for val in HD:s.Poly(val,a,e,P,domain=s.QQ)
H0=s.zeros(5);H0[1,4]=H0[4,1]=a*a/s.Integer(8);H0[2,3]=H0[3,2]=-5*a*a/s.Integer(8)
H3=s.Matrix([[load(ts)for ts in row]for row in cert['global_H_a2Q3']]);by=s.Matrix(bs[1:]);restricted=[]
for H in [H0,H3,HD]:
 h=H[1:,0];K=(br*br*H[1:,1:]-br*(by*h.T+h*by.T)+H[0,0]*by*by.T).applyfunc(s.expand);restricted.append(K)
mons4=[(i,j)for i in range(4)for j in range(i,4)];native=w/'three-native.txt'
with native.open('w')as f:
 f.write('3 10 0\n')
 for H in restricted:
  for i,j in mons4:
   poly=s.Poly(H[i,j]*(1 if i==j else 2),a,e,P,domain=s.QQ);terms=[]if poly.is_zero else poly.terms();f.write(str(len(terms))+''.join(' '+str(c)+' '+' '.join(map(str,ex))for ex,c in terms)+'\n')
# Record full exact global coefficient identities before chart localization.
enc=lambda q:[[list(ex),str(c)]for ex,c in s.Poly(q,a,e,P,domain=s.QQ).terms()]
(w/'source-certificate.json').write_text(json.dumps(dict(HD=[[enc(q)for q in row]for row in HD.tolist()],Bcoefficients=[enc(q)for q in bs],restricted_matrices=[[[enc(q)for q in row]for row in H.tolist()]for H in restricted],coefficient_monomial_pairs=mons4),indent=2)+'\n')
units=Path('work/nonsquare-v62/four-quadric-FULLU-units-v65/units.txt').read_text();(w/'units.txt').write_text(units+'20*d^2+3*d*e+20*d+180*a\n')
print(json.dumps(dict(case='DB!=0',matrix=[3,10],global_polynomial_matrices_exact=True,QQsource='literal five-native Q0/Q3/D',additional_chart_unit=str(DB),bytes=native.stat().st_size,seconds=time.monotonic()-start)),flush=True)

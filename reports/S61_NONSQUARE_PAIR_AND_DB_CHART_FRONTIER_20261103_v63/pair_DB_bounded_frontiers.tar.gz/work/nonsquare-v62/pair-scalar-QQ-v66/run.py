from pathlib import Path
import subprocess,time,resource,os,signal,json
w=Path('work/nonsquare-v62/pair-scalar-QQ-v66');start=time.monotonic()
def cap():resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024))
cmd=['work/nonsquare-v62/singular-runtime/run-singular-optimized-v6.sh','--cpus=0','-q',str(w/'source.sing')]
with(w/'stdout.log').open('w')as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True)
 try:p.wait(timeout=60);timeout=False
 except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
r=dict(command=cmd,elapsed=time.monotonic()-start,exit_code=p.returncode,timed_out=timeout,maxRSS_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss);(w/'run.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

from pathlib import Path
import sympy as s
w=Path('work/nonsquare-v62/pair-scalar-QQ-v66');a,e,P,z=s.symbols('a e P z');it=iter(Path('work/nonsquare-v62/four-quadric-FULLU-units-v65/pair-primitive.txt').read_text().split());n,m,k=[int(next(it))for _ in range(3)];assert[n,m,k]==[1,6,0];qs=[]
for j in range(m):
 nt=int(next(it));q=0
 for t in range(nt):
  c=s.Rational(next(it));ex=[int(next(it))for _ in range(3)];q+=c*a**ex[0]*e**ex[1]*P**ex[2]
 qs.append(q)
F=500*a+90*e**2+3*e-24;B=(50*a+18*e**2-9*e-2)*P+(60*e-40)*a;C=100*a+18*e**2-9*e-2;J=5*P-6*e-4;U=a*P*J*F*B*C
expr=lambda q:str(q).replace('**','^')
text='ring r=0,(a,e,P,z),dp;\noption(redSB);\nideal I='+','.join(expr(q)for q in qs+[z*U-1])+';\nprint("PAIR_SCALAR_QQ_BEGIN");timer=1;\nmatrix T;ideal G=liftstd(I,T);\nprint("PAIR_SCALAR_GB_DONE");print(size(G));print(G);\nif(size(module(matrix(I)*T-matrix(G)))!=0){ERROR("Exact liftstd identity failed");}\nprint("EXACT_QQ_INPUT_TRANSFORMATION_PASS");\n'
text+='if(size(G)==1 && G[1]==1){\nwrite("'+str(w/'unit-witness-native.txt')+'",string(nrows(T))+" "+string(ncols(T))+" 4");\npoly f;int i,j,t;intvec ex;string line;\nfor(i=1;i<=nrows(T);i++){for(j=1;j<=ncols(T);j++){f=T[i,j];line=string(size(f));while(f!=0){ex=leadexp(f);line=line+" "+string(leadcoef(f))+" "+string(ex[1])+" "+string(ex[2])+" "+string(ex[3])+" "+string(ex[4]);f=f-lead(f);}write("'+str(w/'unit-witness-native.txt')+'",line);}}\nprint("PAIR_SCALAR_QQ_UNIT_EXACT_CERTIFICATE_SAVED");}\nquit;\n'
(w/'source.sing').write_text(text)

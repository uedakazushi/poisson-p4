from pathlib import Path
import subprocess,time,resource,os,signal,json
w=Path('work/nonsquare-v62/pair-gate-small-units-v64');t0=time.monotonic();runs=[]
def cap():resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024))
for degree,row in [(1,0),(1,1),(2,0),(2,1)]:
 name=f'D{degree}-row{row}';wit=w/(name+'.witness');exe='work/nonsquare-v62/five-quadric-degree1-v53/degree1-bin' if degree==1 else 'work/nonsquare-v62/five-quadric-degree23-v60/degree23-bin';cmd=[exe,'work/nonsquare-v62/four-quadric-pair-gate-v52/pair-after.txt','work/nonsquare-v62/raw-fourquad-structure-v49/aPJ-units.txt','1',str(row),str(wit),'8']+([str(degree)]if degree==2 else[])
 budget=60-(time.monotonic()-t0)
 if budget<=0:break
 t=time.monotonic()
 with(w/(name+'.log')).open('w')as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True)
  try:p.wait(timeout=budget);timeout=False
  except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 r=dict(degree=degree,row=row,exit_code=p.returncode,timed_out=timeout,elapsed=time.monotonic()-t,witness=wit.exists());runs.append(r);(w/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(r),flush=True)
 if wit.exists()or timeout:break

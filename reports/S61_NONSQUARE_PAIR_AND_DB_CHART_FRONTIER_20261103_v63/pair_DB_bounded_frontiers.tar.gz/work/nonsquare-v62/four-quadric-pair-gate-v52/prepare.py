from pathlib import Path
import sympy as s,json,time
w=Path('work/nonsquare-v62/four-quadric-pair-gate-v52');start=time.monotonic();data=json.loads(Path('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json').read_text());a,e,P=s.symbols('a e P');x=s.symbols('x0:6');u,v,z=s.symbols('u v z');qs=[]
for i,row in enumerate(data['cleared_qfour_sparse']):
 q=0
 for mon,terms in row:q+=sum(s.Rational(co)*a**(ex[0]-ex[2]+[0,2,2,1][i])*e**ex[1]*P**ex[2]for ex,co in terms)*s.prod(vv**k for vv,k in zip(x,mon[:6]))
 qs.append(q)
Tc=-5*P+6*e-2;Vc=9*P*e+4*P+60*a;Ka=10*P**2+3*P*e+13*P+100*a;t=(30*P*a*Tc*v-6*P*Vc*u-4*a*Ka*z)/(60*P**2);sub={x[0]:0,x[1]:3*t,x[2]:v,x[3]:-s.Rational(7,2)*t+u,x[4]:z,x[5]:0};rows=[s.Poly(s.cancel(P**4*qs[i].subs(sub,simultaneous=True)),u,v,z)for i in [0,3]];mons=[(i,j,2-i-j)for i in range(3)for j in range(3-i)]
with(w/'pair-native.txt').open('w')as f:
 f.write('2 6 0\n')
 for q in rows:
  for mon in mons:
   c=s.Poly(q.coeff_monomial(s.prod(var**k for var,k in zip((u,v,z),mon))),a,e,P);assert not s.denom(c.as_expr()).has(a,e,P);terms=[]if c.is_zero else c.terms();f.write(str(len(terms))+''.join(' '+str(co)+' '+' '.join(map(str,ex))for ex,co in terms)+'\n')
(w/'units.txt').write_text('a\nd\n5*d-6*e-4\n');r=dict(actual_gate='Q0,Q3 restrictions independent on x0=A=x5=0',known_units_used=['P'],row_unit_clear='P^4',restricted_variables=['u','v','z'],coefficient_monomials=mons,coefficient_coredegrees=[max(s.Poly(c,a,e,P).total_degree()for c in row.coeffs())for row in rows],total_core_terms=sum(len(s.Poly(c,a,e,P).terms())for row in rows for c in row.coeffs()),seconds=time.monotonic()-start);(w/'source.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

from pathlib import Path
import subprocess,resource,time,os,signal,json
w=Path('work/nonsquare-v62/rank-gate-GF-diagnostic-v70');runs=[]
def cap():resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024))
for case in ['pair','DBchart']:
 start=time.monotonic();cmd=['work/nonsquare-v62/singular-runtime/run-singular-optimized-v6.sh','--cpus=0','-q',str(w/(case+'.sing'))]
 with(w/(case+'.log')).open('w')as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True)
  try:p.wait(timeout=30);timeout=False
  except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 r=dict(case=case,command=cmd,elapsed=time.monotonic()-start,exit_code=p.returncode,timed_out=timeout,maxRSS_KiB=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss);runs.append(r);(w/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(r),flush=True)

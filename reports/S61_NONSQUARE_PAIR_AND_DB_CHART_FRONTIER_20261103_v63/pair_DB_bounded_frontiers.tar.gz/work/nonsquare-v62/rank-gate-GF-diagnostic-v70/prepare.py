from pathlib import Path
from fractions import Fraction
import json
w=Path('work/nonsquare-v62/rank-gate-GF-diagnostic-v70')
def read(path,meta):
 it=iter(Path(path).read_text().split());n,m,k=[int(next(it))for _ in range(3)];assert n==1
 if meta:labels=[next(it)for _ in range(n+k)]
 else:assert k==0
 rows=[]
 for _ in range(m):
  nt=int(next(it));terms=[]
  for t in range(nt):
   c=Fraction(next(it));ex=[int(next(it))for _ in range(3)];assert c.denominator%32003;terms.append((c,ex))
  rows.append(terms)
 return rows
def serialize(terms):
 return '+'.join('('+str(c)+')'+''.join('*'+v+('^'+str(k)if k!=1 else '')for v,k in zip(['a','e','P'],ex)if k)for c,ex in terms)or'0'
units=[('a','a'),('P','P'),('J','5*P-6*e-4'),('F','500*a+90*e^2+3*e-24'),('B','(50*a+18*e^2-9*e-2)*P+(60*e-40)*a'),('C','100*a+18*e^2-9*e-2')]
for name,path,meta in [('pair','work/nonsquare-v62/four-quadric-FULLU-units-v65/pair-primitive.txt',False),('DBchart','work/nonsquare-v62/five-rank-B-chart-v67/after.txt',True)]:
 rows=read(path,meta);prefix=w/name;ut=units+([('DB','20*P^2+3*P*e+20*P+180*a')]if name=='DBchart'else[])
 text='LIB "elim.lib";ring r=32003,(a,e,P),dp;option(redSB);\nideal I='+','.join(serialize(q)for q in rows)+';\nprint("GF_'+name+'_BEGIN");\n'
 for tag,u in ut:
  text+='print("SAT_START_'+tag+'");I=sat(I,ideal('+u+'));print("SAT_DONE_'+tag+'");print(size(I));\n'
 text+='print("GF_'+name+'_DONE");print("DIM");print(dim(I));print("VDIM");print(vdim(I));print("GENERATORS");print(I);write("'+str(prefix)+'-final-ideal.txt",I);\nquit;\n';prefix.with_suffix('.sing').write_text(text)

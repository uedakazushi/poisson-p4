from pathlib import Path
import sympy as s
w=Path('work/nonsquare-v62/five-DBchart-scalar-QQ-v69');a,e,P=s.symbols('a e P');it=iter(Path('work/nonsquare-v62/five-rank-B-chart-v67/after.txt').read_text().split());n,m,k=[int(next(it))for _ in range(3)];assert(n,m,k)==(1,8,2);meta=[next(it)for _ in range(n+k)];qs=[]
for j in range(m):
 nt=int(next(it));q=0
 for t in range(nt):
  c=s.Rational(next(it));ex=[int(next(it))for _ in range(3)];q+=c*a**ex[0]*e**ex[1]*P**ex[2]
 qs.append(q)
F=500*a+90*e**2+3*e-24;B=(50*a+18*e**2-9*e-2)*P+(60*e-40)*a;C=100*a+18*e**2-9*e-2;J=5*P-6*e-4;DB=20*P**2+3*P*e+20*P+180*a
expr=lambda q:str(q).replace('**','^')
text='LIB "elim.lib";\nring toy=0,(x,y),dp;ideal toyI=x*y;ideal toySat=sat(toyI,ideal(x));if(typeof(toySat)!="ideal" || size(toySat)!=1 || toySat[1]!=y){ERROR("Wrong sat API or toy result");}\nprint("SAT_IDEAL_DIRECT_API_TOY_PASS");\nring r=0,(a,e,P),dp;option(redSB);\nideal I='+','.join(expr(q)for q in qs)+';ideal Original=I;\nprint("DB_CHART_SCALAR_QQ_BEGIN");\n'
for name,unit in [('a',a),('P',P),('DB',DB),('J',J),('F',F),('B',B),('C',C)]:
 text+='print("SAT_START_'+name+'");\nI=sat(I,ideal('+expr(unit)+'));\nprint("SAT_DONE_'+name+'");print(size(I));\n'
 text+='write("'+str(w/('after-'+name+'.txt'))+'",I);\n'
 text+='if(size(I)==1 && I[1]==1){print("DB_CHART_QQ_LOCALIZED_UNIT_PROVED_AT_'+name+'");quit;}\n'
text+='print("DB_CHART_QQ_SATURATION_COMPLETE_NONUNIT");print(I);quit;\n';(w/'source.sing').write_text(text)

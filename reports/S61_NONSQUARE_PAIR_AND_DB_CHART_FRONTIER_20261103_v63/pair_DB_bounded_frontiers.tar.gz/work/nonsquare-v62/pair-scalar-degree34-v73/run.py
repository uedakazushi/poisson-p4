from pathlib import Path
import subprocess,time,resource,os,signal,json
w=Path('work/nonsquare-v62/pair-scalar-degree34-v73');t0=time.monotonic();runs=[]
def cap():resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
for degree in [3,4]:
 name=f'D{degree}';wit=w/(name+'.witness');cmd=[str(w/'degree34-bin'),'work/nonsquare-v62/four-quadric-FULLU-units-v65/pair-primitive.txt',str(w/'units-aP.txt'),'0','0',str(wit),'8',str(degree)];budget=60-(time.monotonic()-t0)
 if budget<=0:break
 t=time.monotonic()
 with(w/(name+'.log')).open('w')as f:
  p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True)
  try:p.wait(timeout=budget);timeout=False
  except subprocess.TimeoutExpired:timeout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
 r=dict(degree=degree,command=cmd,exit_code=p.returncode,timed_out=timeout,elapsed=time.monotonic()-t,witness=wit.exists());runs.append(r);(w/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');print(json.dumps(r),flush=True)
 if wit.exists()or timeout:break

from pathlib import Path
import sys,json
ker=Path(sys.argv[1]);inp=Path(sys.argv[2]);out=Path(sys.argv[3]);p=32003
lines=ker.read_text().splitlines();prime,D,n,num=map(int,lines[0].split());assert prime==p;basis={}
for line in lines[1:]:
 a=list(map(int,line.split()));r={}
 for j,c in zip(a[1::2],a[2::2]):r[j%n]=(r.get(j%n,0)+c*pow(2,j//n,p))%p
 r={j:c for j,c in r.items()if c}
 for j,b in sorted(basis.items()):
  c=r.get(j,0)
  if c:
   for k,v in b.items():
    w=(r.get(k,0)-c*v)%p
    if w:r[k]=w
    else:r.pop(k,None)
 assert r
 j=min(r);iv=pow(r[j],-1,p);basis[j]={k:v*iv%p for k,v in r.items()}
assert len(basis)==num;cols=[j for j in range(n)if j not in basis];index={j:k for k,j in enumerate(cols)}
it=iter(inp.read_text().split());nr=int(next(it));nc=int(next(it));assert nc==n
with out.open('x')as f:
 f.write(f'{nr} {len(cols)}\n')
 for i in range(nr):
  r={}
  for k in range(int(next(it))):
   j=int(next(it));a=[]
   for q in range(int(next(it))):a.append((next(it),next(it),next(it)))
   if j in index:r[index[j]]=a
  f.write(str(len(r))+'\n')
  for j,a in r.items():
   f.write(str(j)+'\n'+str(len(a))+'\n')
   for t in a:f.write(' '.join(t)+'\n')
Path(str(out)+'.columns.json').write_text(json.dumps(cols)+'\n');print('COMPLEMENT',len(cols))

from pathlib import Path
import sys,json,math
from functools import reduce
import sympy as s
from sympy.polys.rings import ring
R,e=ring('e',s.QQ);p=Path(sys.argv[1]);out=Path(sys.argv[2])
lines=p.read_text().splitlines();n,D,num=map(int,lines[0].split());assert len(lines)==num+1
rows=[];degs=[];newD=0
for line in lines[1:]:
 a=line.split();N=int(a[0]);v={}
 for k in range(N):
  j,c=int(a[1+2*k]),int(a[2+2*k]);v[j%n]=v.get(j%n,R.zero)+c*e**(j//n)
 g=R.zero
 for h in v.values():g=g.gcd(h)
 degs.append(g.degree());v={j:h.exquo(g)for j,h in v.items()}
 den=1
 for h in v.values():
  for c in h.values():den=s.ilcm(den,s.denom(c))
 vals={n*m[0]+j:int(c*den)for j,h in v.items()for m,c in h.items()if c}
 content=reduce(math.gcd,vals.values());vals={j:c//content for j,c in vals.items()};newD=max(newD,max(vals)//n);rows.append(vals)
with out.open('x')as f:
 f.write(f'{n} {newD} {num}\n')
 for r in rows:f.write(str(len(r))+' '+' '.join(f'{j} {c}'for j,c in sorted(r.items()))+'\n')
print(json.dumps({'input':str(p),'gcd_degrees':degs,'new_degree':newD,'coefficients':sum(map(len,rows))}))

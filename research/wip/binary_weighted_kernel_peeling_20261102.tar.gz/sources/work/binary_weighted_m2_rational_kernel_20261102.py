from pathlib import Path
from fractions import Fraction
import os,subprocess,sys,time
inp=Path(sys.argv[1]);prefix=Path(sys.argv[2]);prime=int(sys.argv[3])if len(sys.argv)>3 else 32003
it=iter(inp.read_text().split());n=int(next(it));m=int(next(it));rows=[]
for i in range(n):
 row=['0']*m
 for k in range(int(next(it))):
  j=int(next(it));terms=[]
  for a in range(int(next(it))):
   c=Fraction(next(it));ee=int(next(it));dd=int(next(it));assert dd==0;v=str(c)
   if v:terms.append(str(v)+(f'*e^{ee}'if ee else''))
  row[j]='+'.join(terms)or'0'
 rows.append('{'+','.join(row)+'}')
out=Path(str(prefix)+'.kernels');program=f'R=QQ[e]; A=matrix{{'+','.join(rows)+'};\n'
program+='print "LOADED";stdio<<flush;K=gens kernel A;assert(A*K==0);print("KERNEL",numColumns K);stdio<<flush;\n'
program+=f'out=openOut "{out}";out<<numRows K<<" "<<numColumns K<<endl;scan(numColumns K,j->{{nn=sum apply(numRows K,i->#listForm K_(i,j));out<<nn;scan(numRows K,i->scan(listForm K_(i,j),z->out<<" "<<(numRows K*(first z)#0+i)<<" "<<toString(last z)));out<<endl;}});close out;exit 0;\n'
p=Path(str(prefix)+'.m2');p.write_text(program)
env=dict(os.environ,DYLD_LIBRARY_PATH='work/m2-runtime/lib:/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib')
start=time.time()
with Path(str(prefix)+'.log').open('w')as f:
 try:q=subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',str(p)],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120);print('RETURN',q.returncode,'SECONDS',time.time()-start,flush=True)
 except subprocess.TimeoutExpired:print('TIMEOUT',time.time()-start,flush=True)

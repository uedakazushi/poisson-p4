from pathlib import Path
from itertools import combinations_with_replacement
import json,sympy as s,time,hashlib
from sympy.polys.rings import ring
start=time.time();D=json.load(open('reports/S61_BINARY_DEEPER_PRODUCT_PAIR_20261102.json'));K=s.QQ.frac_field('e','d');C=K.field.ring
R,*x=ring(','.join('x'+str(i)for i in range(7)),K)
new=[R.from_expr(s.sympify(q))for q in D['new_quadrics']]
images=[R.from_expr(s.sympify(q))for q in D['new_to_old_linear']]
def wp(stream,p):
 stream.write(str(len(p))+'\n')
 for m,c in p.items():stream.write(str(c)+' '+' '.join(map(str,m))+'\n')
mon2=[]
for pair in combinations_with_replacement(range(7),2):
 m=[0]*7
 for i in pair:m[i]+=1
 mon2.append(tuple(m))
index={m:i for i,m in enumerate(mon2)}
with open('/tmp/poisson_cubic_cover_new_quadrics_20261102.txt','w')as f:
 f.write('7 28\n')
 for q in new:
  f.write(str(len(q))+'\n')
  for m,c in sorted(q.items(),key=lambda t:index[t[0]]):f.write(str(index[m])+'\n');wp(f,c.numer);wp(f,c.denom)
DB=C.one
for q in images:
 for c in q.values():DB=DB.lcm(c.denom)
with open('/tmp/poisson_cubic_cover_coordinates_20261102.txt','w')as f:
 wp(f,DB)
 for q in images:
  out={}
  for m,c in q.items():
   cp=c.numer*DB.exquo(c.denom)
   for n,v in cp.items():out[n+m]=v
  wp(f,out)
for stem in ['new_quadrics','coordinates']:
 p=Path('/tmp/poisson_cubic_cover_'+stem+'_20261102.txt');print(stem,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())
print('time',time.time()-start)

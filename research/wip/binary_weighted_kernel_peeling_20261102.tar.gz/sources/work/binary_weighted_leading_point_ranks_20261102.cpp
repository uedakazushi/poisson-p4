#include "../code/s61_binary_deeper_quartic_field_20261101.hpp"
#include <flint/nmod_mat.h>
#include <flint/nmod.h>
#include <flint/ulong_extras.h>
int main(int argc,char**argv){assert(argc==2);fmpq_mpoly_ctx_init(ctx,2,ORD_LEX);{ifstream in(argv[1]);int n,m;in>>n>>m;vector<Row>A(n);for(auto&r:A){int nn;in>>nn;for(int k=0;k<nn;k++){int j;Rat c;in>>j;readpoly(in,c.n);r.emplace(j,std::move(c));}}for(ulong e:{0UL,1UL,2UL,3UL,5UL,7UL,11UL,17UL,313UL}){nmod_mat_t M;nmod_mat_init(M,n,m,32003);nmod_t mod;nmod_init(&mod,32003);ulong x[2]={e,0};for(int i=0;i<n;i++)for(auto&[j,f]:A[i]){ulong den=fmpz_fdiv_ui(fmpq_denref(f.n->content),mod.n);assert(den);ulong v=fmpz_mpoly_evaluate_all_nmod(f.n->zpoly,x,ctx->zctx,mod);v=nmod_mul(v,nmod_mul(fmpz_fdiv_ui(fmpq_numref(f.n->content),mod.n),n_invmod(den,mod.n),mod),mod);nmod_mat_entry(M,i,j)=v;}cout<<e<<' '<<nmod_mat_rank(M)<<'\n';nmod_mat_clear(M);}}fmpq_mpoly_ctx_clear(ctx);flint_cleanup();}

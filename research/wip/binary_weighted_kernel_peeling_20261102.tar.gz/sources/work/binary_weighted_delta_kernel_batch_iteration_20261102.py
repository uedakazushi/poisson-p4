#!/usr/bin/env python3
"""Bounded WIP: polynomial right-kernel peeling, exact QQ identities each step."""
import argparse,os,subprocess,json,time,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--valuation',type=int,required=True);p.add_argument('--prefix',required=True);p.add_argument('--stages',type=int,default=5);a=p.parse_args()
env=dict(os.environ,DYLD_LIBRARY_PATH='work/m2-runtime/lib:/opt/homebrew/lib')
cur=Path(a.input);value=a.valuation;records=[];start=time.time();prefix=Path(a.prefix)
def run(args,stem,timeout):
 with Path(str(stem)+'.log').open('w')as f:
  subprocess.run(list(map(str,args)),env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,check=True)
def read(path):
 lines=Path(path).read_text().splitlines();h=list(map(int,lines[0].split()));rows=[]
 for line in lines[1:]:
  v=list(map(int,line.split()));assert len(v)==1+2*v[0];rows.append(dict(zip(v[1::2],v[2::2])))
 assert len(rows)==h[-1];return h,rows
def save(status):
 Path(str(prefix)+'.json').write_text(json.dumps(dict(status=status,initial_valuation=a.valuation,proved_valuation_lower_bound=value,stages=records,seconds=time.time()-start,scope='Exact polynomial kernel and delta divisibility steps; not yet all-core rank coverage.'),indent=2)+'\n')
try:
 for stage in range(a.stages):
  base=Path(str(prefix)+f'_s{stage}');leading=Path(str(cur)+'.leading')
  for D in [2,4,6,8,10]:
   candidate=Path(str(base)+f'_d{D}.candidate')
   run(['/tmp/poisson_weighted_leading_bounded_kernel_20261102',leading,D,candidate],candidate,90)
   h,rr=read(candidate)
   print('CANDIDATE',stage,D,len(rr),flush=True)
   if len(rr)>=8 or(D==10 and rr):break
  else:raise RuntimeError('No bounded-degree kernel')
  second=Path(str(base)+'.second')
  run(['/tmp/poisson_weighted_leading_all_bounded_kernels_20261102',leading,D,second,32009],second,90)
  _,ss=read(second);smap={max(r):r for r in ss};union=Path(str(base)+'.union');extras=[]
  with union.open('w')as f:
   f.write(' '.join(map(str,h))+'\n')
   for r in rr:
    support=sorted(set(r)|set(smap[max(r)]));extras.append(len(support)-len(r));f.write(str(len(support))+' '+' '.join(f'{j} {r.get(j,0)}'for j in support)+'\n')
  exact=Path(str(base)+'.exact')
  run(['/tmp/poisson_weighted_leading_kernel_batch_exact_20261102',leading,union,exact],exact,240)
  eh,er=read(exact);assert eh[-1]==len(rr)==len(er)
  dest=Path(str(base)+'.matrix')
  run(['/tmp/poisson_weighted_delta_kernel_peel_20261102',cur,exact,dest],dest,150)
  value+=len(rr);assert value<=157
  ranks=Path(str(base)+'.ranks')
  run(['/tmp/poisson_weighted_leading_point_ranks_20261102',str(dest)+'.leading'],ranks,30)
  sampled=[list(map(int,line.split()))for line in Path(str(ranks)+'.log').read_text().splitlines()]
  rec=dict(stage=stage,degree=D,kernel_count=len(rr),new_support_entries=sum(extras),valuation=value,output=str(dest),sampled_leading_ranks=sampled,input_sha256=hashlib.sha256(cur.read_bytes()).hexdigest(),exact_kernel_sha256=hashlib.sha256(exact.read_bytes()).hexdigest())
  records.append(rec);cur=dest;save('running');print('EXACT_PEEL',stage,'ADDED',len(rr),'VALUATION',value,'RANKS',sampled,flush=True)
  if any(r==269 for _,r in sampled):
   assert value==157;save('complete_generic_infinity_valuation');break
 else:save('bounded_stage_limit')
except Exception as ex:
 save('stopped: '+repr(ex));raise

#include "binary_univariate_field_20261102.hpp"
#include <flint/fmpz_poly.h>
#include <flint/fmpz_mat.h>
#include <flint/fmpq_mat.h>
#include <flint/nmod_mat.h>
#include <flint/nmod.h>
#include <flint/ulong_extras.h>
#include <chrono>
#include <set>
struct IP{fmpz_poly_struct p[1];IP(){fmpz_poly_init(p);}IP(const IP&a):IP(){fmpz_poly_set(p,a.p);}IP(IP&&a):IP(){fmpz_poly_swap(p,a.p);}IP&operator=(IP a){fmpz_poly_swap(p,a.p);return *this;}~IP(){fmpz_poly_clear(p);}};
int main(int argc,char**argv){
 assert(argc==4);ifstream in(argv[1]),cand(argv[2]);ofstream out(argv[3]);
 int nr,n;in>>nr>>n;vector<map<int,IP>>A(nr);int md=0;
 fmpz_t den,scale,g;for(auto p:{den,scale,g})fmpz_init(p);
 for(int i=0;i<nr;i++){
  int nn;in>>nn;URow r;fmpz_one(den);
  for(int k=0;k<nn;k++){int j;URat q;in>>j;uread(in,q.n);fmpz_lcm(den,den,fmpq_poly_denref(q.n));r.emplace(j,std::move(q));}
  fmpz_zero(g);
  for(auto&[j,q]:r){IP p;fmpq_poly_get_numerator(p.p,q.n);fmpz_divexact(scale,den,fmpq_poly_denref(q.n));fmpz_poly_scalar_mul_fmpz(p.p,p.p,scale);for(int k=0;k<fmpz_poly_length(p.p);k++)fmpz_gcd(g,g,p.p->coeffs+k);A[i].emplace(j,std::move(p));}
  for(auto&[j,p]:A[i]){fmpz_poly_scalar_divexact_fmpz(p.p,p.p,g);md=max(md,int(fmpz_poly_degree(p.p)));}
 }
 for(auto p:{den,scale,g})fmpz_clear(p);
 ulong prime;int D,nc,number;cand>>prime>>D>>nc>>number;assert(nc==n);
 int constraints=nr*(md+D+1);nmod_t mod;nmod_init(&mod,prime);
 vector<map<int,ulong>>candidates(number);set<int>all,anchors;vector<int>anchor(number);
 for(int a=0;a<number;a++){int count;cand>>count;for(int k=0;k<count;k++){int j;ulong c;cand>>j>>c;candidates[a][j]=c;all.insert(j);}anchor[a]=candidates[a].rbegin()->first;anchors.insert(anchor[a]);}
 assert(int(anchors.size())==number);for(int a:anchors)all.erase(a);
 vector<int>support(all.begin(),all.end());int unknown=support.size();
 auto start=chrono::steady_clock::now();
 nmod_mat_t M;nmod_mat_init(M,unknown,constraints,prime);
 for(int s=0;s<unknown;s++){int pow=support[s]/n,col=support[s]%n;for(int i=0;i<nr;i++){auto it=A[i].find(col);if(it==A[i].end())continue;auto p=it->second.p;for(int k=0;k<fmpz_poly_length(p);k++)nmod_mat_entry(M,s,i*(md+D+1)+k+pow)=fmpz_fdiv_ui(p->coeffs+k,prime);}}
 assert(nmod_mat_rref(M)==unknown);vector<int>eq;
 for(int i=0;i<unknown;i++){int j=0;while(j<constraints&&!nmod_mat_entry(M,i,j))j++;assert(j<constraints);eq.push_back(j);}nmod_mat_clear(M);
 cerr<<"BATCH_PIVOT "<<unknown<<" RHS "<<number<<" SEC "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';
 fmpz_mat_t E,B;fmpq_mat_t X;fmpz_mat_init(E,unknown,unknown);fmpz_mat_init(B,unknown,number);fmpq_mat_init(X,unknown,number);
 for(int i=0;i<unknown;i++){
  int row=eq[i]/(md+D+1),degree=eq[i]%(md+D+1);
  for(int s=0;s<unknown;s++){int pwr=support[s]/n,col=support[s]%n;auto it=A[row].find(col);if(it!=A[row].end()&&degree>=pwr)fmpz_poly_get_coeff_fmpz(fmpz_mat_entry(E,i,s),it->second.p,degree-pwr);}
  for(int a=0;a<number;a++){int pwr=anchor[a]/n,col=anchor[a]%n;auto it=A[row].find(col);if(it!=A[row].end()&&degree>=pwr){fmpz_poly_get_coeff_fmpz(fmpz_mat_entry(B,i,a),it->second.p,degree-pwr);fmpz_neg(fmpz_mat_entry(B,i,a),fmpz_mat_entry(B,i,a));}}
 }
 assert(fmpq_mat_solve_fmpz_mat_dixon(X,E,B));
 cerr<<"BATCH_SOLVED SEC "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';out<<n<<' '<<D<<' '<<number<<'\n';
 for(int a=0;a<number;a++){
  fmpz_t common,integer;fmpz_init(common);fmpz_init(integer);fmpz_one(common);
  for(int s=0;s<unknown;s++)fmpz_lcm(common,common,fmpq_denref(fmpq_mat_entry(X,s,a)));
  map<int,IP>values;
  for(int s=0;s<unknown;s++){auto q=fmpq_mat_entry(X,s,a);if(fmpq_is_zero(q))continue;fmpz_divexact(integer,common,fmpq_denref(q));fmpz_mul(integer,integer,fmpq_numref(q));fmpz_poly_set_coeff_fmpz(values[support[s]].p,0,integer);}
  fmpz_poly_set_coeff_fmpz(values[anchor[a]].p,0,common);
  ulong anchor_res=fmpz_fdiv_ui(common,prime);assert(anchor_res);ulong ratio=nmod_mul(anchor_res,n_invmod(candidates[a][anchor[a]],prime),mod);
  for(auto&[j,p]:values)assert(fmpz_fdiv_ui(p.p->coeffs,prime)==nmod_mul(ratio,candidates[a][j],mod));
  IP sum,tmp,shift;
  for(int i=0;i<nr;i++){fmpz_poly_zero(sum.p);for(auto&[j,p]:values){auto it=A[i].find(j%n);if(it==A[i].end())continue;fmpz_poly_scalar_mul_fmpz(tmp.p,it->second.p,p.p->coeffs);fmpz_poly_shift_left(shift.p,tmp.p,j/n);fmpz_poly_add(sum.p,sum.p,shift.p);}assert(fmpz_poly_is_zero(sum.p));}
  int maxbits=0;out<<values.size();for(auto&[j,p]:values){char*str=fmpz_get_str(nullptr,10,p.p->coeffs);out<<' '<<j<<' '<<str;flint_free(str);maxbits=max(maxbits,int(fmpz_bits(p.p->coeffs)));}out<<'\n';out.flush();
  cerr<<"EXACT_KERNEL "<<a<<" SUPPORT "<<values.size()<<" BITS "<<maxbits<<" SEC "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';
  fmpz_clear(common);fmpz_clear(integer);
 }
 fmpz_mat_clear(E);fmpz_mat_clear(B);fmpq_mat_clear(X);flint_cleanup();
}

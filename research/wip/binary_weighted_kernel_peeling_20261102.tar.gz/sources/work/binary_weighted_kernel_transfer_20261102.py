from pathlib import Path
import json,sys,math
from functools import reduce
import sympy as s
from sympy.polys.rings import ring
R,e=ring('e',s.QQ)
g=[R.from_expr(s.sympify(x)) for x in json.load(open('work/binary-weighted-leading-column-factors-20261102.json'))['factors']]
p=Path(sys.argv[1]);lines=p.read_text().splitlines();n,D,num=map(int,lines[0].split());assert n==269 and len(lines)==num+1
out=[];newD=0
for line in lines[1:]:
 a=line.split();count=int(a[0]);v={}
 for k in range(count):
  i,c=int(a[1+2*k]),s.QQ(a[2+2*k]);v[i%n]=v.get(i%n,R.zero)+c*e**(i//n)
 common=R.one
 for j,h in v.items():common=common.lcm(g[j].exquo(g[j].gcd(h)))
 v={j:(h*common).exquo(g[j])for j,h in v.items()}
 den=1
 for h in v.values():
  for c in h.values():den=s.ilcm(den,s.denom(c))
 vals={n*m[0]+j:int(c*den)for j,h in v.items()for m,c in h.items()if c}
 content=reduce(math.gcd,vals.values());vals={j:c//content for j,c in vals.items()};newD=max(newD,max(vals)//n);out.append(vals)
with Path(sys.argv[2]).open('w')as f:
 f.write(f'{n} {newD} {num}\n')
 for v in out:f.write(str(len(v))+' '+' '.join(f'{j} {c}'for j,c in sorted(v.items()))+'\n')
print('TRANSFERRED',num,'MAX_DEGREE',newD,'COEFFICIENTS',sum(map(len,out)))

#pragma once
#include "../code/s61_binary_deeper_quartic_field_20261101.hpp"
#include <array>
#include <climits>
vector<Rat> local_factors;
vector<pair<long,long>> local_degrees;
map<pair<int,int>,Rat> powers_cache;
struct Loc{
    Rat p; vector<int> ex;
    Loc():ex(local_factors.size(),0){}
    bool zero()const{return p.zero();}
    bool unit()const{return !zero()&&fmpq_mpoly_is_fmpq(p.n,ctx);}
    void normalize(){
        if(zero()){fill(ex.begin(),ex.end(),0);return;}
        Rat q;long de=fmpq_mpoly_degree_si(p.n,0,ctx),dd=fmpq_mpoly_degree_si(p.n,1,ctx);
        for(int i=0;i<int(ex.size());i++){
            auto[a,b]=local_degrees[i];
            while(de>=a&&dd>=b&&fmpq_mpoly_divides(q.n,p.n,local_factors[i].n,ctx)){
                fmpq_mpoly_swap(q.n,p.n,ctx);ex[i]++;de-=a;dd-=b;
            }
        }
    }
    long cost()const{long c=1;for(int i=0;i<int(ex.size());i++)c+=abs(ex[i])*(local_degrees[i].first+local_degrees[i].second);return c;}
};
void load_factors(istream&in){int n;in>>n;local_factors.resize(n);fmpq_t lc;fmpq_init(lc);for(auto&f:local_factors){readpoly(in,f.n);fmpq_mpoly_get_term_coeff_fmpq(lc,f.n,0,ctx);fmpq_mpoly_scalar_div_fmpq(f.n,f.n,lc,ctx);local_degrees.emplace_back(fmpq_mpoly_degree_si(f.n,0,ctx),fmpq_mpoly_degree_si(f.n,1,ctx));}fmpq_clear(lc);}
Loc from_rat(const Rat&v){Loc a,b;fmpq_mpoly_set(a.p.n,v.n,ctx);fmpq_mpoly_set(b.p.n,v.d,ctx);a.normalize();b.normalize();assert(b.unit());fmpq_t c;fmpq_init(c);fmpq_mpoly_get_fmpq(c,b.p.n,ctx);fmpq_mpoly_scalar_div_fmpq(a.p.n,a.p.n,c,ctx);fmpq_clear(c);for(int i=0;i<int(a.ex.size());i++)a.ex[i]-=b.ex[i];return a;}
Loc times(const Loc&a,const Loc&b){Loc c;if(a.zero()||b.zero())return c;fmpq_mpoly_mul(c.p.n,a.p.n,b.p.n,ctx);for(int i=0;i<int(c.ex.size());i++)c.ex[i]=a.ex[i]+b.ex[i];return c;}
Loc inverse_unit(const Loc&a){assert(a.unit());Loc b;fmpq_t c;fmpq_init(c);fmpq_mpoly_get_fmpq(c,a.p.n,ctx);fmpq_inv(c,c);fmpq_mpoly_set_fmpq(b.p.n,c,ctx);fmpq_clear(c);for(int i=0;i<int(b.ex.size());i++)b.ex[i]=-a.ex[i];return b;}
Rat weighted_numerator(const Loc&a,const vector<int>&base){Rat p=a.p,t;for(int i=0;i<int(base.size());i++){int k=a.ex[i]-base[i];assert(k>=0);if(!k)continue;auto key=make_pair(i,k);auto it=powers_cache.find(key);if(it==powers_cache.end()){Rat pow;fmpq_mpoly_pow_ui(pow.n,local_factors[i].n,k,ctx);it=powers_cache.emplace(key,std::move(pow)).first;}fmpq_mpoly_mul(t.n,p.n,it->second.n,ctx);fmpq_mpoly_swap(t.n,p.n,ctx);}return p;}
Loc loc_sub(const Loc&a,const Loc&b){if(b.zero())return a;Loc c;if(a.zero()){c=b;fmpq_mpoly_neg(c.p.n,c.p.n,ctx);return c;}for(int i=0;i<int(c.ex.size());i++)c.ex[i]=min(a.ex[i],b.ex[i]);Rat an=weighted_numerator(a,c.ex),bn=weighted_numerator(b,c.ex);fmpq_mpoly_sub(c.p.n,an.n,bn.n,ctx);c.normalize();return c;}
using LRow=map<int,Loc>;

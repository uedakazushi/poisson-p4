#include <flint/nmod_poly.h>
#include <flint/nmod_mat.h>
#include <flint/ulong_extras.h>
#include <vector>
#include <fstream>
#include <iostream>
#include <cassert>
#include <algorithm>
using namespace std;
struct NP{nmod_poly_struct p[1];NP(){nmod_poly_init(p,32003);}NP(const NP&a):NP(){nmod_poly_set(p,a.p);}NP(NP&&a):NP(){nmod_poly_swap(p,a.p);}NP&operator=(NP a){nmod_poly_swap(p,a.p);return *this;}~NP(){nmod_poly_clear(p);}};
int main(int argc,char**argv){assert(argc==3);ifstream in(argv[1]);ofstream out(argv[2]);int n,r;in>>n>>r;vector<vector<NP>>A(r,vector<NP>(n));for(int i=0;i<r;i++){int cnt;in>>cnt;for(int k=0;k<cnt;k++){int j;long c;in>>j>>c;nmod_poly_set_coeff_ui(A[i][j%n].p,j/n,(c%32003+32003)%32003);}}
 vector<int>deg(r),pos(r);auto refresh=[&](int i){deg[i]=-1;pos[i]=-1;for(int j=0;j<n;j++){int d=nmod_poly_degree(A[i][j].p);if(d>=0&&(d>deg[i]||(d==deg[i]&&j>pos[i]))){deg[i]=d;pos[i]=j;}}assert(pos[i]>=0);};for(int i=0;i<r;i++)refresh(i);
 long count=0;NP tmp,shift;while(true){int a=-1,b=-1;for(int i=0;i<r&&a<0;i++)for(int j=i+1;j<r;j++)if(pos[i]==pos[j]){a=i;b=j;break;}if(a<0)break;if(deg[a]<deg[b])swap(a,b);int d=deg[a]-deg[b];ulong c=nmod_poly_get_coeff_ui(A[a][pos[a]].p,deg[a])*n_invmod(nmod_poly_get_coeff_ui(A[b][pos[b]].p,deg[b]),32003)%32003;for(int j=0;j<n;j++){nmod_poly_scalar_mul_nmod(tmp.p,A[b][j].p,c);nmod_poly_shift_left(shift.p,tmp.p,d);nmod_poly_sub(A[a][j].p,A[a][j].p,shift.p);}refresh(a);count++;if(count%1000==0)cerr<<"STEPS "<<count<<'\n';assert(count<100000);}
 int D=*max_element(deg.begin(),deg.end());out<<"32003 "<<D<<' '<<n<<' '<<r<<'\n';nmod_mat_t M;nmod_mat_init(M,r,n,32003);long terms=0;for(int i=0;i<r;i++){vector<pair<int,ulong>>row;for(int j=0;j<n;j++){nmod_mat_entry(M,i,j)=nmod_poly_evaluate_nmod(A[i][j].p,2);for(int k=0;k<nmod_poly_length(A[i][j].p);k++){ulong c=nmod_poly_get_coeff_ui(A[i][j].p,k);if(c)row.emplace_back(k*n+j,c);}}sort(row.begin(),row.end());terms+=row.size();out<<row.size();for(auto[j,c]:row)out<<' '<<j<<' '<<c;out<<'\n';cerr<<"VECTOR "<<i<<" DEGREE "<<deg[i]<<" SUPPORT "<<row.size()<<'\n';}assert(nmod_mat_rank(M)==r);nmod_mat_clear(M);cerr<<"POP0V "<<count<<" MAXDEG "<<D<<" TERMS "<<terms<<'\n';flint_cleanup();}

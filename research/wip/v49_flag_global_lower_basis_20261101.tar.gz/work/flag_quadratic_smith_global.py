import json,pickle,time
from pathlib import Path
from itertools import combinations_with_replacement as cwr
import sympy as s
from sympy.polys.matrices import DomainMatrix as DM
from sympy.polys.matrices.normalforms import smith_normal_decomp
st=time.time();c=pickle.load(open('work/flag-b1-universal-quadratic-cache.pkl','rb'));q=json.load(open('work/flag-b1-universal-quadratic.json'));r=s.Symbol('b2');P=s.QQ.poly_ring(r);ms=list(cwr(range(9),2));active=[j for j,m in enumerate(ms)if all(i in {4,5,7,8}for i in m)];rows=q['pivot_rows'];cover=json.load(open('reports/S61_FLAG_BOUNDARY_QUADRATIC_COVER_20261101.json'));contents=list(map(s.sympify,cover['row_contents']))
def dec(poly):
 assert all(not any(e[1:])for e,c in poly)
 return sum(s.Rational(c)*r**e[0]for e,c in poly)
A=s.Matrix([[s.cancel(dec(c['A2'][i][j])/contents[k])for j in active]for k,i in enumerate(rows)]);AD=A.to_DM().convert_to(P);print('A ready',time.time()-st,flush=True)
D,S,T=smith_normal_decomp(AD);assert D==S*AD*T;print('smith ready',time.time()-st,flush=True)
diag=[D.to_Matrix()[i,i]for i in range(9)];print('diagonal',[str(s.factor(x))for x in diag],flush=True)
Q=(s.diag(*[1/x for x in diag])*S.to_Matrix()*A).applyfunc(s.cancel);L=(s.diag(*[1/x for x in diag])*S.to_Matrix()*s.diag(*[1/x for x in contents])).applyfunc(s.cancel)
enc=lambda M:[[str(v)for v in row]for row in M.tolist()]
Path('work/flag-quadratic-smith-global.json').write_text(json.dumps(dict(basis=enc(Q),row_change=enc(L),right_change=enc(T.to_Matrix()),smith_diagonal=list(map(str,diag)),seconds=time.time()-st),indent=2)+'\n');print('GLOBAL QUAD BASIS',max(s.Poly(s.numer(v),r).degree()for v in Q),time.time()-st,flush=True)

import json,pickle,time
from pathlib import Path
from itertools import combinations_with_replacement as cwr
import sympy as s
from sympy.polys.matrices import DomainMatrix as DM
from sympy.polys.matrices.normalforms import smith_normal_decomp
st=time.time();c=pickle.load(open('work/flag-b1-universal-quadratic-cache.pkl','rb'));q=json.load(open('work/flag-b1-universal-quadratic.json'));r=s.Symbol('b2');P=s.QQ.poly_ring(r);ms=list(cwr(range(9),2));active=[j for j,m in enumerate(ms)if all(i in {4,5,7,8}for i in m)];rows=q['pivot_rows'];cover=json.load(open('reports/S61_FLAG_BOUNDARY_QUADRATIC_COVER_20261101.json'));contents=list(map(s.sympify,cover['row_contents']))
def dec(poly):return sum(s.Rational(c)*r**e[0]for e,c in poly)
A=s.Matrix([[s.cancel(dec(c['A2'][i][j])/contents[k])for j in active]for k,i in enumerate(rows)]);mons2=list(cwr(range(4),2));mons3=list(cwr(range(4),3));B=s.zeros(36,20)
for i in range(9):
 for j in range(4):
  for k,m in enumerate(mons2):B[4*i+j,mons3.index(tuple(sorted(m+(j,))))]+=A[i,k]
BD=B.to_DM().convert_to(P);print('B ready',time.time()-st,flush=True)
D,S,T=smith_normal_decomp(BD);assert D==S*BD*T;print('smith ready',time.time()-st,flush=True);diag=[D.to_Matrix()[i,i]for i in range(20)];print('diagonal',[str(s.factor(x))for x in diag],flush=True)
enc=lambda M:[[str(v)for v in row]for row in M.to_Matrix().tolist()]
Path('work/flag-active-cubic-smith-global.json').write_text(json.dumps(dict(left_change=enc(S),right_change=enc(T),smith_diagonal=list(map(str,diag)),seconds=time.time()-st),indent=2)+'\n');print('CUBIC SMITH GLOBAL DONE',time.time()-st,flush=True)

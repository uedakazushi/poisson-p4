import json,time
from pathlib import Path
from itertools import combinations,combinations_with_replacement as cwr
import sympy as s
from sympy.polys.rings import ring
st=time.time();d=json.load(open('work/flag-quadratic-smith-global.json'));T=s.Matrix(d['right_change']).applyfunc(s.sympify);iv=T.inv(method='DM');r=s.Symbol('b2');P,x=ring('b2',s.QQ);mu=T[:,9];z=iv[9,:];assert s.expand((z*mu)[0])==1
G=s.zeros(4);pairs=list(cwr(range(4),2))
for value,(i,j)in zip(mu,pairs):G[i,j]=G[j,i]=value
minors=[]
for a,b in combinations(range(4),2):
 for c,e in combinations(range(4),2):
  p=P.from_expr(s.expand(G[a,c]*G[b,e]-G[a,e]*G[b,c]))
  if p:minors.append((a,b,c,e,p))
g=P.zero;coef=[];used=[]
for a,b,c,e,p in minors:
 if not g:g=p;coef=[P.one];used=[(a,b,c,e,p)];continue
 u,v,new=g.gcdex(p);coef=[u*k for k in coef]+[v];used.append((a,b,c,e,p));g=new
 if g.degree()==1:break
assert s.cancel(g.as_expr()/(400*r+91)).is_Rational
assert sum((k*v[4]for k,v in zip(coef,used)),P.zero)==g
print('Bezout used',len(used),'gcd',g.as_expr(),'degrees',[p.degree()for p in coef],time.time()-st,flush=True)
# R(i;j,m) z = -q_ij*v_m+q_im*v_j; all q_ij are actual quadratic relations.
# Delta*z*v_m equals mu_kl R(i;j,m)+mu_im R(k;l,j)-mu_kj R(i;l,m).
reps=[]
for m in range(4):
 row=s.zeros(1,40)
 def addR(i,j,k,c):
  row[0,4*pairs.index(tuple(sorted((i,j))))+k]-=c
  row[0,4*pairs.index(tuple(sorted((i,k))))+j]+=c
 for co,(i,k,j,l,p)in zip(coef,used):
  co=co.as_expr();addR(i,j,m,co*G[k,l]);addR(k,l,j,co*G[i,m]);addR(i,l,m,-co*G[k,j])
 reps.append(row.applyfunc(s.expand))
v=s.symbols('v:4');mon2=s.Matrix([v[i]*v[j]for i,j in pairs]);zz=(z*mon2)[0];qq=mon2-mu*zz;mult=s.Matrix([qq[i]*v[j]for i in range(10)for j in range(4)])
for m,row in enumerate(reps):assert s.expand((row*mult)[0]-g.as_expr()*zz*v[m])==0
enc=lambda M:[[str(x)for x in row]for row in M.tolist()]
Path('work/flag-active-cubic-bezout.json').write_text(json.dumps(dict(socle_coefficients=enc(z),multiplication=enc(G),bezout_gcd=str(g.as_expr()),used_minors=[[a,b,c,e,str(p.as_expr())]for a,b,c,e,p in used],bezout_coefficients=[str(p.as_expr())for p in coef],socle_active_lifts=[enc(row)[0]for row in reps],seconds=time.time()-st),indent=2)+'\n');print('ALL ACTIVE CUBIC GLOBAL LIFTS PASS',time.time()-st,flush=True)

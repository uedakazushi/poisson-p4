v47 WIP, 2026-11-01. These are exploratory calculations, not saturation theorems.
The r=-91/400 normal-chart sample is the v46 archived six-jet sample. The M2 source
contains its full60 initial generators. B=J:v1^infinity has degree5 but parameter
length49; it must not be called free5. D=J:v5^infinity has degree4 and parameter
length4. Further v6 saturation still has parameter length49; primary/torsion-free structure remains unproved.
The fixed H11 beta T7 probe demonstrates a flat4 coordinate algebra after DVR
regularization; its universal replacement is the formal S61_FLAG_T7_FLAT4 certificate.
Do not use finite-field computations alone to claim QQ gr equality or t-nilpotence.
Next: match the actual flat4 initial algebra to D, then control residual E using
the same actual flag C3 and relative geometry.

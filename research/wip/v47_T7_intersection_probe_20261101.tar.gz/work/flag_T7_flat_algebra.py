import json,time,sys
from pathlib import Path
import sympy as s
st=time.time();d=json.load(open('work/flag-T7-flat-probe.json'));M=lambda x:s.Matrix(x).applyfunc(s.sympify);e=s.Symbol('e');q=M(d['q']);T=M(d['T']);W2=M(d['W2']);W3=M(d['W3']);Z=T[:,2].row_join(W2[:,5]).row_join(W3[:,9]);chart=d['chart']
def val(x):
 if x==0:return 10000
 p,dd=map(lambda y:s.Poly(y,e),s.fraction(s.cancel(x)));return min(i[0] for i in p.monoms())-min(i[0] for i in dd.monoms())
def regular(x):return val(x)>=0
def simp(A):return A.applyfunc(s.cancel)
def basis(rows):
 rows=[list(row) for row in rows if any(row)];B=[]
 for col in range(3):
  k=min(range(len(rows)),key=lambda i:val(rows[i][col]));p=rows.pop(k);v=val(p[col]);assert v<10000
  unit=s.cancel(p[col]/e**v);p=[s.cancel(c/unit) for c in p]
  new=[]
  for r in rows:
   c=s.cancel(r[col]/p[col]);assert regular(c)
   a=[s.cancel(x-c*y) for x,y in zip(r,p)]
   if any(a):new.append(a)
  rows=new;B.append(p)
 return s.Matrix(B)
def product(a,b):return [0,a[0]*b[0],a[0]*b[1]+a[1]*b[0]]
B=basis(Z.tolist())
for it in range(8):
 iv=B.inv().applyfunc(s.cancel);P=s.Matrix([product(list(B[i,:]),list(B[j,:])) for i in range(3) for j in range(i,3)]);C=simp(P*iv)
 if all(regular(v) for v in C):break
 B=basis(B.tolist()+P.tolist())
else:raise Exception('closure failed')
CQ=simp(Z*iv);assert all(regular(v) for v in CQ);C0=C.subs(e,0);CQ0=CQ.subs(e,0)
print('basis',B.tolist(),'iterations',it,flush=True);print('multiplication',C.tolist(),'special',C0.tolist(),flush=True)
# tangent space basis of nilradical / products at e=0
rr,piv=C0.rref();nonp=[i for i in range(3) if i not in piv];tangent=CQ0[:,nonp]-CQ0[:,list(piv)]*rr[:len(piv),nonp]
dq=q.diff(e)[chart,:].col_join(s.zeros(1,1));map4=dq.subs(e,0).row_join(tangent);p4=list(map4.T.rref()[1]);assert len(p4)==map4.cols
print('closed formal immersion tangent dim',map4.cols,'minorrows',p4,'minor',map4[p4,:].det(),flush=True)
# Include coefficients of all135 equations in this finite rank4 algebra.
sys.path.insert(0,'code');from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
m=S61();one=[i for i,wt in enumerate(m.reduced['parameter_weights'])if wt==1];_,F=specialize(m,dict(zip(one,map(s.Rational,d['beta']))),True)
Q=[[q[i],0,0,0] for i in range(45)]
for j,i in enumerate(chart):Q[i]=[q[i]]+list(CQ[j,:])
pairs=[(i,j) for i in range(3) for j in range(i,3)]
def mul(a,b):
 out=[a[0]*b[0]]+[a[0]*b[j]+a[j]*b[0] for j in range(1,4)]
 for k,(i,j) in enumerate(pairs):
  c=a[i+1]*b[j+1]+(a[j+1]*b[i+1] if i!=j else 0)
  for l in range(3):out[l+1]+=c*C[k,l]
 return out
for f in F:
 r=[0]*4
 for mon,c in f.items():
  fs=[Q[i] for i in mon]+[[0]*4]*(2-len(mon));v=mul(*fs);r=[a+c*b for a,b in zip(r,v)]
 assert all(s.cancel(v)==0 for v in r)
enc=lambda A:[[str(v) for v in row] for row in A.tolist()]
Path('work/flag-T7-flat-algebra.json').write_text(json.dumps(dict(beta=d['beta'],fixed=d['fixed'],q=d['q'],chart=chart,basis=enc(B),coordinate_coefficients=enc(CQ),multiplication=enc(C),multiplication_special=enc(C0),special_tangent_dimension=map4.cols,immersion_minor=str(map4[p4,:].det()),immersion_rows=p4,all135=True,t_zero=True,seconds=time.time()-st),indent=2)+'\n')
print('CLOSED FLAT4 ALGEBRA PASS',time.time()-st,flush=True)

import sys,json,time
from pathlib import Path
import sympy as s
sys.path.insert(0,'code')
from s61_model import S61,X,J
from s61_flag_transverse_obstruction_20261101 import specialize
st=time.time();m=S61();data=json.load(open('reports/S61_FLAG_T7_BOUNDARY_20261101.json'));H=s.Matrix(data['fixed_beta_kernel']).applyfunc(s.Rational);a=s.Matrix(range(2,13));beta=H*a;e=s.Symbol('e');q=s.Matrix(data['projective_q']).applyfunc(s.sympify);one=[i for i,w in enumerate(m.reduced['parameter_weights'])if w==1];_,F=specialize(m,dict(zip(one,beta)),True)
fixed=next(i for i,v in enumerate(q) if v and not v.has(e));chart=[i for i in range(45) if i!=fixed];J=s.zeros(135,45);terms=[]
for row,f in enumerate(F):
 ts=[]
 for mon,c in f.items():
  if len(mon)==2:
   i,j=mon
   if i!=fixed:J[row,chart.index(i)]+=c*q[j]
   if j!=fixed:J[row,chart.index(j)]+=c*q[i]
  elif len(mon)==1:J[row,44]+=c*q[mon[0]]
  if fixed not in mon:
   i,j=[chart.index(k) for k in mon]+[44]*(2-len(mon));ts.append((i,j,c))
 terms.append(ts)
K=s.QQ.frac_field(e);JD=J.to_DM().convert_to(K);rr,piv=JD.rref();rr=rr.to_Matrix();free=[i for i in range(45) if i not in piv];T=s.zeros(45,len(free))
for j,f in enumerate(free):
 T[f,j]=1
 for k,p in enumerate(piv):T[p,j]=-rr[k,f]
print('generic rank',len(piv),'free',free,'seconds',time.time()-st,flush=True)
def val(x):
 if x==0:return 10000
 p,d=map(lambda y:s.Poly(y,e),s.fraction(s.cancel(x)));return min(i[0] for i in p.monoms())-min(i[0] for i in d.monoms())
# Saturate the tangent lattice over the epsilon DVR.
for j in range(T.cols):T[:,j]=T[:,j]*e**(-min(val(v) for v in T[:,j]))
for it in range(20):
 T=T.applyfunc(s.cancel);T0=T.subs(e,0);r=T0.rank()
 if r==T.cols:break
 ns=T0.nullspace()[0];j=next(i for i,v in enumerate(ns) if v);T[:,j]=T*ns/e
assert T0.rank()==3
print('regular tangent',T0.tolist(),'seconds',time.time()-st,flush=True)
rows=list(JD.transpose().rref()[1]);iv=JD.extract(rows,list(piv)).inv();U=s.zeros(45,len(rows));im=iv.to_Matrix()
for k,p in enumerate(piv):U[p,:]=im[k,:]
from itertools import combinations_with_replacement as cwr
ms={d:list(cwr(range(3),d)) for d in [1,2,3]};Ws={1:T};As={}
for d in [2,3]:
 ix={mon:i for i,mon in enumerate(ms[d])};Q=s.zeros(135,len(ms[d]))
 for row,ts in enumerate(terms):
  for i,j,c in ts:
   for da in range(1,d):
    for ia,ma in enumerate(ms[da]):
     if not Ws[da][i,ia]:continue
     for ib,mb in enumerate(ms[d-da]):
      if Ws[d-da][j,ib]:Q[row,ix[tuple(sorted(ma+mb))]]+=c*Ws[da][i,ia]*Ws[d-da][j,ib]
 Q=Q.applyfunc(s.cancel);W=(-U*Q[rows,:]).applyfunc(s.cancel);A=(Q+J*W).applyfunc(s.cancel);assert A==s.zeros(*A.shape);Ws[d]=W
 print('degree',d,'min valuation',min(val(v) for v in W),'tzero',all(v==0 for v in W[-1,:]),'seconds',time.time()-st,flush=True)
enc=lambda M:[[str(v) for v in row] for row in M.tolist()]
Path('work/flag-T7-flat-probe.json').write_text(json.dumps(dict(beta=list(map(str,beta)),fixed=fixed,chart=chart,q=list(map(str,q)),T=enc(T),W2=enc(Ws[2]),W3=enc(Ws[3]),J=enc(J),rows=rows,pivots=list(piv)),indent=2)+'\n')
print('PASS',time.time()-st,flush=True)

import json,time,subprocess,numpy as np
from pathlib import Path
from itertools import combinations_with_replacement as cwr
st=time.time();p=32003;n=11;D=9
mons=[m for d in range(D+1)for m in cwr(range(n),d)];ix={m:i for i,m in enumerate(mons)}
B=[tuple(m)for m in json.load(open('work/minimal-free-flag-module-query-basis.json'))['base_monomials']]
assert len(B)==141
log=json.load(open('work/minimal-free-flag-base-quadratic-module.json'))['log'];tokens=log.split('\nt ')[1].strip().split();T={int(a):int(b)for a,b in (v.split(':')for v in tokens)};assert len(T)==1053
queries=[{ix[tuple(sorted(b+(j,)))]:1}for j in range(8)for b in B]
for b in B:
 row={}
 for k,c in T.items():
  if len(mons[k])+len(b)<=D:row[ix[tuple(sorted(mons[k]+b))]]=c
 queries.append(row)
query=Path('/tmp/free-m0-r-adic-action-queries.txt');answer=Path('/tmp/free-m0-r-adic-action-answers.txt')
query.write_text(str(len(queries))+'\n'+'\n'.join(str(len(r))+' '+' '.join(str(i)+' '+str(c)for i,c in sorted(r.items()))for r in queries)+'\n')
exe='/tmp/free-m0-r-adic-action-nf';subprocess.run(['clang++','-O3','-std=c++17','code/truncated_local_module_normal_form_20261102.cpp','-o',exe],check=True)
done=subprocess.run([exe,'11','9','/tmp/minimal-free-flag-base-quadratic-fullbasis.txt',str(query),str(answer),'/tmp/free-m0-r-adic-action-metadata.txt'],capture_output=True,text=True,check=True,timeout=60)
print('QUERY PASS',time.time()-st,done.stderr,flush=True)

def parse(path):
 lines=Path(path).read_text().splitlines();assert int(lines[0])==len(lines)-1;out=[]
 for line in lines[1:]:
  v=list(map(int,line.split()));assert len(v)==2*v[0]+1;out.append(dict(zip(v[1::2],v[2::2])))
 return out
C=parse('/tmp/minimal-free-flag-module-quadratic-answers.txt');actual=parse(answer)

def axpy(v,w,a):
 for k,c in w.items():
  z=(v.get(k,0)+a*c)%p
  if z:v[k]=z
  else:v.pop(k,None)
 return v

def encode(v):
 out={}
 for k,c in v.items():axpy(out,C[k],c)
 return out

def rref(A):
 A=A.copy()%p;h=0;piv=[]
 for j in range(A.shape[1]):
  found=np.flatnonzero(A[h:,j])
  if not len(found):continue
  k=h+int(found[0]);A[[h,k]]=A[[k,h]];A[h]=A[h]*pow(int(A[h,j]),-1,p)%p
  ids=np.flatnonzero(A[:,j]);ids=ids[ids!=h]
  if len(ids):A[ids]=(A[ids]-A[ids,j,None]*A[h])%p
  piv.append(j);h+=1
  if h==A.shape[0]:break
 return A,piv

def decoder(indices):
 unit={next(iter(C[j])):j for j in indices if len(C[j])==1 and next(iter(C[j].values()))==1}
 support=set().union(*(C[j].keys()for j in indices));missing=sorted(support-set(unit));nonunit=[j for j in indices if not (len(C[j])==1 and next(iter(C[j].values()))==1)]
 M=np.array([[C[j].get(i,0)for j in nonunit]for i in missing],dtype=np.int64)
 _,pc=rref(M);_,pr=rref(M[:,pc].T);M0=M[np.ix_(pr,pc)];N=len(pc);rr,_=rref(np.hstack([M0,np.eye(N,dtype=np.int64)]));inv=rr[:,N:];selected=[nonunit[i]for i in pc]
 def decode(row):
  assert not set(row)-support
  vv=inv@np.array([row.get(missing[i],0)for i in pr],dtype=np.int64)%p;result={j:int(v)for j,v in zip(selected,vv)if v};rest=row.copy()
  for j,v in result.items():axpy(rest,C[j],-v)
  assert not set(rest)-set(unit),(len(rest),set(rest)-set(unit))
  for k,v in rest.items():result[unit[k]]=v
  assert encode(result)==row
  return result
 print('DECODER',len(indices),len(unit),len(missing),N,time.time()-st,flush=True)
 return decode,dict(unit_columns=len(unit),missing_rows=len(missing),residual_rank=N,minor_rows=[missing[i]for i in pr],minor_columns=selected,inverse=inv.tolist())
decode,info=decoder(list(range(1410)));decode2,info2=decoder(list(range(564,1410)))
old1=json.load(open('work/minimal-free-flag-first-base-relations.json'))['linear_relations'];old2=json.load(open('work/minimal-free-flag-second-base-relations.json'))['quadratic_relations']
powers=[()]+list(cwr(range(3),1))+list(cwr(range(3),2));powers2=list(cwr(range(3),2));pi={v:i for i,v in enumerate(powers)}
def shift(v,u):
 out={}
 for k,c in v.items():
  pw=powers[k//141]+u
  if len(pw)<=2:axpy(out,{pi[tuple(sorted(pw))]*141+k%141:c},1)
 return out
lifted=[]
for r in old1:
 v={i+141:c for i,c in r};correction=decode2({k:(-a)%p for k,a in encode(v).items()});axpy(v,correction,1);assert not encode(v);lifted.append(v)
mult=[shift(r,(i,))for r in lifted for i in range(3)];N2=[{i+564:c for i,c in r}for r in old2]
M=np.zeros((846,len(mult)+len(N2)),dtype=np.int64)
for j,r in enumerate(mult+N2):
 for k,c in r.items():M[k-564,j]=c
_,pc=rref(M);assert len(pc)==85 and sum(j<len(mult)for j in pc)==60
new=[N2[j-len(mult)]for j in pc if j>=len(mult)];assert len(new)==25
relations=lifted+new;closure=lifted+mult+new
M=np.zeros((1410,len(closure)),dtype=np.int64)
for j,r in enumerate(closure):
 assert not encode(r)
 for k,c in r.items():M[k,j]=c
assert len(rref(M)[1])==107
print('RELATIONS PASS',len(relations),time.time()-st,flush=True)
actions=[[decode(r)for r in actual[141*i:141*(i+1)]]for i in range(9)]
def act(M,v):
 out={}
 for k,c in v.items():axpy(out,shift(M[k%141],powers[k//141]),c)
 return out
for i,M in enumerate(actions):
 for r in relations:assert not encode(act(M,r)),(i,'relation')
 print('ACTION',i,'nnz',sum(map(len,M)),time.time()-st,flush=True)
for j in range(141):assert not encode(act(actions[8],actions[8][j]))
print('T SQUARED PASS',time.time()-st,flush=True)
for i in range(9):
 for j in range(i):
  for k in range(141):
   z=act(actions[i],actions[j][k]);axpy(z,act(actions[j],actions[i][k]),-1);assert not encode(z),(i,j,k)
 print('COMMUTATORS',i,time.time()-st,flush=True)
def sparse(rows):return [[[int(i),int(c)]for i,c in sorted(r.items())]for r in rows]
result=dict(prime=p,coefficient_ring='Fp[u0,u1,u2]/(u)^3',generators=141,coefficient_powers=powers,decoder=info,quadratic_decoder=info2,lifted_linear_relations=sparse(lifted),new_quadratic_relations=sparse(new),relations_total=47,vector_space_kernel=107,dimension=1303,actions=[dict(variable='x'+str(i)if i<8 else't',columns=sparse(M))for i,M in enumerate(actions)],relations_stable=True,commutators_zero=True,t_squared_zero=True,seconds=time.time()-st)
json.dump(result,open('work/free-m0-r-adic-module-action.json','w'),indent=2)
print('ALL PASS',time.time()-st,flush=True)

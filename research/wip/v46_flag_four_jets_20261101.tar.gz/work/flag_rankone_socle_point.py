import json,sys,time,subprocess
from pathlib import Path
from itertools import combinations_with_replacement as cwr
import sympy as s
sys.path.insert(0,'code')
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
from truncated_local_ideal_io_20261101 import write_input
start=time.time();D=int(sys.argv[1]) if len(sys.argv)>1 else 6
prefix=str(Path(f'work/flag-rankone-socle-point-d{D}').resolve())
frame=json.load(open('work/flag-b1-normalized-frame.json'));m=S61();case=json.load(open('reports/S61_FLAG_UNIFORM_OPEN_20261101.json'))['flag']
b=s.zeros(15,1);b[0]=b[12]=1;b[2]=-s.Rational(91,400)
for i,v in zip([4,7,8,9,10,11,13],[1,2,3,5,7,11,13]):b[i]=v
sub={s.Symbol(f'b{i}'):b[i] for i in range(15)};H=s.Matrix(case['beta_kernel']).applyfunc(s.Rational);one=[i for i,w in enumerate(m.reduced['parameter_weights']) if w==1]
two,F=specialize(m,dict(zip(one,H*b)),True);q=s.Matrix([s.Rational(case['point61'][i]) for i in two]);fixed=next(i for i,v in enumerate(q) if v);cols=[i for i in range(45) if i!=fixed]
J=s.Matrix(frame['jacobian']).applyfunc(s.sympify).subs(sub);T=s.Matrix(frame['tangent']).applyfunc(s.sympify).subs(sub);rows=frame['pivot_rows'];C=frame['pivot_columns'];U=s.zeros(45,36);iv=J[rows,C].inv()
for i,col in enumerate(C):U[col,:]=iv[i,:]
assert J*T==s.zeros(135,9) and J[rows,:]*U==s.eye(36)
terms=[]
for f in F:
    ht=[]
    for mon,c in f.items():
        if fixed not in mon:
            a,bb=[cols.index(i) for i in mon]+[44]*(2-len(mon));ht.append((a,bb,c))
    terms.append(ht)
factors=[s.ilcm(*[s.denom(v) for v in list(J[i,:])+[c for _,_,c in terms[i]]]) for i in range(135)]
Jn=s.diag(*factors)*J;Un=U*s.diag(*[1/s.Integer(factors[i]) for i in rows]);den=s.ilcm(*[s.denom(v) for v in Un]);Un=den*Un;td=s.ilcm(*[s.denom(v) for v in T]);Tn=td*T
assert den%32003 and td%32003
ms={d:list(cwr(range(9),d)) for d in range(D+1)};ix={d:{m:i for i,m in enumerate(mm)} for d,mm in ms.items()}
with open(prefix+'-input.txt','w') as out:
    out.write(f'135 9 {D} 36\n{den} {td}\n');out.write(' '.join(str(len(ms[d])) for d in range(D+1))+'\n');out.write(' '.join(map(str,rows))+'\n')
    for M in [Jn,Tn,Un]:
        for row in M.tolist():out.write(' '.join(map(str,row))+'\n')
    for i,ht in enumerate(terms):out.write(str(len(ht))+' '+' '.join(f'{a} {b} {c*factors[i]}' for a,b,c in ht)+'\n')
    for a in range(1,D):
        for d in range(1,D+1-a):out.write(' '.join(str(ix[a+d][tuple(sorted(x+y))]) for x in ms[a] for y in ms[d])+'\n')
binary='/tmp/poisson_root_flag_socle_mod_20261101'
if not Path(binary).exists():subprocess.run(['c++','-O3','-std=c++17','-I/opt/homebrew/include','work/integer_implicit_jets_mod8.cpp','-L/opt/homebrew/lib','-lgmpxx','-lgmp','-o',binary],check=True)
import tempfile,shutil
with tempfile.TemporaryDirectory(prefix='root-socle-native-') as directory:
    q=Path(directory);coef=q/'coefficients.txt';tc=q/'tcoefficients.txt'
    subprocess.run([binary,prefix+'-input.txt',str(coef),str(tc)],check=True)
    assert coef.exists() and tc.exists()
    shutil.copyfile(coef,prefix+'-coefficients.txt');shutil.copyfile(tc,prefix+'-tcoefficients.txt')
Path(prefix+'-metadata.json').write_text(json.dumps(dict(b=list(map(str,b)),den=str(den),td=str(td),row_factors=list(map(str,factors)),seconds=time.time()-start),indent=2)+'\n')
subprocess.run([sys.executable,'work/flag_rankone_socle_point_finish.py',str(D)],check=True)

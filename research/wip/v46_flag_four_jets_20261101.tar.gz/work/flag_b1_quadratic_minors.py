import json,pickle,time
from pathlib import Path
import sympy as s
start=time.time();c=pickle.load(open('work/flag-b1-universal-quadratic-cache.pkl','rb'));q=json.load(open('work/flag-b1-universal-quadratic.json'))
b=s.symbols('b2 b4 b7 b8 b9 b10 b11 b13');x=b[0]
def dec(p):return sum(s.Rational(v)*s.prod(z**e for z,e in zip(b,ex)) for ex,v in p)
active=[j for j,m in enumerate(q['monomials']) if all(i in {4,5,7,8} for i in m)]
A=s.Matrix([[dec(c['A2'][i][j]) for j in active] for i in q['pivot_rows']])
assert set().union(*(v.free_symbols for v in A))=={x}
contents=[]
for i in range(9):
    g=s.factor(s.polys.polytools.terms_gcd(s.gcd_list(list(A[i,:]))));contents.append(str(g))
    for j in range(10):A[i,j]=s.cancel(A[i,j]/g)
minors=[]
for j in range(10):
    dm=A[:,[k for k in range(10) if k!=j]].to_DM();d=s.factor(dm.domain.to_sympy(dm.det()));minors.append(d)
    print('minor',j,'degree',s.degree(d,x),'sec',time.time()-start,flush=True)
g=s.factor(s.gcd_list(minors));print('GCD',g,flush=True)
Path('work/flag-b1-quadratic-minors.json').write_text(json.dumps(dict(contents=contents,minors=list(map(str,minors)),gcd=str(g),seconds=time.time()-start),indent=2)+'\n')

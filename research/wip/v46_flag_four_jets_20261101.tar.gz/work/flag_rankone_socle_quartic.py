from pathlib import Path
src=Path('work/flag_rankone_socle_cubic.py').read_text()
exec(src[:src.index("qq=json.load")])
mons4=list(cwr(range(9),4));ix4={m:i for i,m in enumerate(mons4)}
Q4=[[zero for _ in mons4] for _ in range(135)]
for row,f in enumerate(cache['F']):
    for mon,c in f:
        if fixed in mon:continue
        i,j=[chart.index(k) for k in mon]+[44]*(2-len(mon));co=poly(c)
        for a in range(9):
            for k,mm in enumerate(mons3):
                val=T[i][a]*W3[j][k]+T[j][a]*W3[i][k]
                if val:Q4[row][ix4[tuple(sorted((a,)+mm))]]+=co*val
        for a,m1 in enumerate(mons2):
            if not W2[i][a]:continue
            for k,m2 in enumerate(mons2):
                if W2[j][k]:Q4[row][ix4[tuple(sorted(m1+m2))]]+=co*W2[i][a]*W2[j][k]
print('raw4',time.time()-start,flush=True)
W4=[[zero for _ in mons4] for _ in range(45)]
for i,row in enumerate(U):
    for j,co in enumerate(row):
        if co:
            for k,v in enumerate(Q4[rows[j]]):
                if v:W4[i][k]-=co*v
A4=[[ud*v for v in row] for row in Q4]
for i,row in enumerate(J):
    for j,co in enumerate(row):
        if co:
            for k,v in enumerate(W4[j]):
                if v:A4[i][k]+=co*v
print('implicit4',time.time()-start,flush=True)
assert all(not v for i in rows for v in A4[i])
enc=lambda M:[[[[list(e),str(c)] for e,c in v.items()] for v in row] for row in M]
pickle.dump(dict(A2=enc(A2),A3=enc(A3),A4=enc(A4),W3=enc(W3),W4=enc(W4),variables=list(map(str,variables)),ud=str(ud.as_expr()),td=str(poly(cache['td']).as_expr())),open('work/flag-rankone-socle-quartic-cache.pkl','wb'))
print('RAW FOUR-JET SAVED',time.time()-start,flush=True)

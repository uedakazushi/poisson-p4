import json,sys,time,subprocess
from pathlib import Path
from itertools import combinations_with_replacement as cwr
import sympy as s
sys.path.insert(0,'code')
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
from truncated_local_ideal_io_20261101 import write_input
start=time.time();D=int(sys.argv[1]) if len(sys.argv)>1 else 6
prefix=str(Path(f'work/flag-rankone-socle-point-d{D}').resolve())
A=[list(map(int,line.split())) for line in Path(prefix+'-coefficients.txt').read_text().splitlines()];tt=[list(map(int,line.split())) for line in Path(prefix+'-tcoefficients.txt').read_text().splitlines()]
ms={d:list(cwr(range(9),d)) for d in range(D+1)};offset=0;jets={}
for d in range(2,D+1):
    count=len(ms[d]);jets[d]=[row[offset:offset+count] for row in A];offset+=count
write_input(prefix+'-modinput.txt',32003,9,jets,{d:tt[d-2] for d in range(2,D+1)},D)
print('POINT INPUT READY',time.time()-start,flush=True)
import tempfile,shutil
with tempfile.TemporaryDirectory(prefix='root-flag-socle-') as td:
    temp=Path(td); trace=temp/'trace.txt';order=temp/'order.txt';initial=temp/'initial.txt';minimal=temp/'minimal.txt'
    subprocess.run(['/tmp/poisson_root_flag_socle_trace_guard',prefix+'-modinput.txt',str(trace),str(order),str(initial)],check=True,timeout=240)
    assert trace.exists() and initial.exists()
    subprocess.run(['/tmp/poisson_root_flag_socle_minimal_20261101',prefix+'-modinput.txt',str(initial),str(minimal)],check=True,timeout=120)
    assert minimal.exists()
    for f in [trace,order,initial,minimal]:shutil.copyfile(f,prefix+'-'+f.name)
print('POINT INITIAL READY',time.time()-start,flush=True)

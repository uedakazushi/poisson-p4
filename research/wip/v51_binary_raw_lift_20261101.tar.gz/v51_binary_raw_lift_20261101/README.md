# v51 deeper-binary continuation, WIP

This is a reconstruction checkpoint, not a new removal theorem. The older
research/archive/binary_deeper_pid_20261101 directory remains frozen.
No independent review or aggregate replay of this new pipeline is claimed.

Copy the included work files to the repository work directory, retaining names.
The native includes intentionally refer to the existing frozen code header.
Run from the repository root with .venv/bin/python. First reconstruct inverse.txt
and relations.txt using the v50 archive run_probe.py (or its documented stages).
The large caches are omitted; their hashes are in manifest.json.

Run work/binary_deeper_raw_lift_prepare_20261101.py. It rebuilds the raw quadratic
lift from frozen repository certificates and writes the 2.3 MB operator input
under /tmp. Compile work/binary_deeper_raw_lift_quartics_20261101.cpp using the
same local FLINT include/library flags as the v50 driver. Pass, in order:

1. /tmp/poisson_deeper_raw_lift_operators_20261101.txt
2. the reconstructed inverse.txt
3. the reconstructed relations.txt
4. a fresh output filename

Replacing argument 3 with inputs/poisson_deeper_canonical_unit_rows_20261101.txt
reconstructs v0 times all24 canonical cubic tails. Ten rows are exactly zero;
the fourteen nonzero rows are the two seven-component vectors described in the
note. The scratch producer accepts an optional case limit; complete recorded
runs did not use one. The cubic extraction removes the extra v0 factor exactly.

The degree_rref producer takes the v50 seven_quadrics.txt, a fresh output, and
3 for cubic multiples. This elimination was still running at packaging time.
Its later result and the subsequent reduce_canonical_cubic producer are not
claimed complete here. The latter takes the completed cubic basis, canonical
cubic tails, and a fresh output file.

Finite-field annihilator and coefficient-Ansatz probes are preserved separately:
they do not imply a QQ(e)[d] inverse. The e=2 contents and known-factor pivot
probes likewise record unsuccessful simplifications. No large matrix, native
binary, or 481/909 MB quartic cache is included.

import sys,json,time
from pathlib import Path
sys.path.insert(0,'code')
import sympy as s
from sympy.polys.rings import ring
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
from s61_binary_deeper_uniform_quadratic_20261101 import build_quadratics,PIVOT_ROWS
from s61_binary_deeper_cubic_nuisance_20261101 import normal_exponent
D=json.load(open('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json'))['linear'];R,Q=build_quadratics(D)
S,e,d=ring('e,d',s.QQ);zero=S.zero
core=lambda p:S.from_dict({m[:2]:c for m,c in p.items()if not any(m[2:])})
pol=lambda x:core(R.from_expr(s.sympify(x)))
T=[[core(x)for x in row]for row in Q['Tn']];U=[[core(x)for x in row]for row in Q['Un']];W=[[core(x)for x in row]for row in Q['W']];Du=core(Q['Uden']);J=[[pol(x)for x in row]for row in D['J']]
SUPPORT=[i for i,row in enumerate(W)if any(row)];ns=len(SUPPORT);si={j:i for i,j in enumerate(SUPPORT)};print('raw support',SUPPORT,flush=True)
beta={int(k[1:])-1:s.sympify(v)for k,v in D['beta'].items()};_,F=specialize(S61(),beta,True)
ops=[]
for eq in F:
 mat=[[zero]*ns for _ in range(9)]
 for mon,c in eq.items():
  if D['fixed'] in mon:continue
  i,j=[D['cols'].index(v)for v in mon]+[44]*(2-len(mon));c=pol(c)
  for a in range(9):
   if i in si and T[j][a]:mat[a][si[i]]+=c*T[j][a]
   if j in si and T[i][a]:mat[a][si[j]]+=c*T[i][a]
 ops.append(mat)
proj=[[sum((c*U[j][k]for j,c in enumerate(row)if c),zero)for k in range(33)]for row in J]
sel=D['pivot_rows']
# Original row contents determine the saved canonical B inverse.
contents=[core(Q['contents'][i])for i in PIVOT_ROWS]
assert all(contents)
def corewrite(f,p):f.write(str(len(p))+' '+' '.join(str(c)+' '+' '.join(map(str,m))for m,c in p.items())+'\n')
def write16(f,terms):f.write(str(len(terms))+'\n'+'\n'.join(str(c)+' '+' '.join(map(str,m))for m,c in terms)+'\n')
from itertools import combinations_with_replacement
ms2=list(combinations_with_replacement(range(9),2));out=Path('/tmp/poisson_deeper_raw_lift_operators_20261101.txt')
with out.open('w')as f:
 f.write(f'24 {ns}\n')
 for c in contents:corewrite(f,c)
 for i in PIVOT_ROWS:
  for b in range(ns):
   terms=[]
   for a in range(9):
    v=Du*ops[i][a][b]-sum((c*ops[sel[k]][a][b]for k,c in enumerate(proj[i])if c),zero)
    terms.extend((list(m)+[0]*5+normal_exponent((a,)),c)for m,c in v.items())
   write16(f,terms)
 for i in SUPPORT:
  terms=[]
  for mon,p in zip(ms2,W[i]):terms.extend((list(m)+[0]*5+normal_exponent(mon),c)for m,c in p.items())
  write16(f,terms)
 corewrite(f,Du**2)
print('written',out.stat().st_size,flush=True)
json.dump({'support':SUPPORT,'denominator':str(Du.as_expr()),'raw_W_terms':sum(len(v)for row in W for v in row)},open('work/binary-deeper-raw-lift-20261101.json','w'),indent=2)

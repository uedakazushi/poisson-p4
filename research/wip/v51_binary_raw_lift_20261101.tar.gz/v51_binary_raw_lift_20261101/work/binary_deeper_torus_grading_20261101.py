import json,sys
from pathlib import Path
import sympy as s
sys.path.insert(0,'code')
from s61_model import S61,BASIS,X
m=S61();two=[i for i,w in enumerate(m.reduced['parameter_weights']) if w==2]
a=[0,1,-1,-1,1];raw=[]
for r in m.certificate['raw_free_indices']:
 pair,mon=BASIS[r];raw.append(sum(a[i] for i in pair)-sum(i*j for i,j in zip(a,s.Poly(mon,*X).monoms()[0])))
d=json.load(open('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json'))['linear']
localw=[raw[two[i]]+4 for i in d['cols']]+[6]
T=s.Matrix(d['T']).applyfunc(s.sympify);W=s.Matrix(d['chart_basis']).applyfunc(s.sympify)
print('localw',localw)
for j,col in enumerate(d['free']):
 ids=[i for i in range(45) if W[i,col]];print('free',j,col,'ids',ids,'weights',[localw[i] for i in ids])
print('normal',d['normal'])
nuis=s.symbols('p q r h k');subs=dict.fromkeys(nuis,0)
result=[]
for j in d['normal']:
 weights=sorted(set(localw[i] for i in range(45) if T[i,j].subs(subs)!=0))
 print('normal weights',j,weights)
 result.append(weights)
json.dump({'local_weights':localw,'normal_weights':result},open('work/binary-deeper-torus-grading-20261101.json','w'),indent=2)

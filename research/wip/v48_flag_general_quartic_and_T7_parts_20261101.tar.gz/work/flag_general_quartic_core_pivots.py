import ast,json,time,pickle
from pathlib import Path
import sympy as s
st=time.time();data=json.load(open('work/flag-general-initial4-projected.json'));variables=list(map(s.Symbol,data['variables']));K=s.QQ.frac_field(*variables);env={str(x):g for x,g in zip(variables,K.field.gens)};env['Q']=s.QQ
class Exact(ast.NodeTransformer):
 def visit_Constant(self,node):
  assert isinstance(node.value,int)
  return ast.copy_location(ast.Call(func=ast.Name(id='Q',ctx=ast.Load()),args=[node],keywords=[]),node)
 def visit_BinOp(self,node):
  if isinstance(node.op,ast.Pow):
   assert isinstance(node.right,ast.Constant)and isinstance(node.right.value,int);node.left=self.visit(node.left);return node
  return self.generic_visit(node)
rows={}
for (key,expr) in data['entries'].items():
 tree=ast.parse(expr,mode='eval')
 assert all(isinstance(n,(ast.Expression,ast.BinOp,ast.UnaryOp,ast.Add,ast.Sub,ast.Mult,ast.Div,ast.Pow,ast.USub,ast.UAdd,ast.Constant,ast.Name,ast.Load))for n in ast.walk(tree))
 tree=ast.fix_missing_locations(Exact().visit(tree));v=eval(compile(tree,'<exact-quartic>','eval'),{'__builtins__':{}},env);i,j=map(int,key.split(','));rows.setdefault(i,{})[j]=K.convert(v)
print('parsed',len(rows),sum(map(len,rows.values())),time.time()-st,flush=True)
# Preserve a portable sparse polynomial-pair cache for future checks.
enc=lambda p:[[list(m),str(c)]for m,c in p.items()]
encoded={i:{j:[enc(c.numer),enc(c.denom)]for j,c in row.items()}for i,row in rows.items()};pickle.dump(dict(variables=data['variables'],rows=encoded),open('work/flag-general-initial4-field-cache.pkl','wb'))
noncore=[i for i,x in enumerate(variables)if str(x)not in ['b2','b8']]
def iscore(c):return all(all(m[i]==0 for i in noncore)for p in [c.numer,c.denom]for m in p)
pivots=[]
while rows:
 candidates=[(len(c.numer)+len(c.denom),i,j)for i,row in rows.items()for j,c in row.items()if c and iscore(c)]
 if not candidates:print('NO CORE PIVOT REMAINS',len(rows),flush=True);break
 _,i,j=min(candidates);row=rows.pop(i);p=row[j];pivots.append((i,j,str(K.to_sympy(p))));row={k:c/p for k,c in row.items()}
 for k in list(rows):
  c=rows[k].get(j)
  if c:
   for col,v in row.items():
    new=rows[k].get(col,K.zero)-c*v
    if new:rows[k][col]=new
    else:rows[k].pop(col,None)
  if not rows[k]:del rows[k]
 print('pivot',len(pivots),i,j,'rows left',len(rows),'seconds',time.time()-st,flush=True)
out=dict(rank=len(pivots)if not rows else None,core_pivots=pivots,remaining_rows=len(rows),HF4=213-len(pivots)if not rows else None,seconds=time.time()-st)
Path('work/flag-general-quartic-core-pivots.json').write_text(json.dumps(out,indent=2)+'\n');print('QUARTIC CORE PIVOTS RESULT',out['rank'],out['HF4'],time.time()-st,flush=True)

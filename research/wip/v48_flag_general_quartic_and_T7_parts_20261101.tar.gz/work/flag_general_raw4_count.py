import pickle,time,json
from pathlib import Path
from itertools import combinations_with_replacement as cwr
st=time.time();c=pickle.load(open('work/flag-eight-flint-raw4-cache.pkl','rb'));print('loaded',time.time()-st,flush=True);active={4,5,7,8};out={}
for degree in [2,3,4]:
 ms=list(cwr(range(9),degree));counts={i:0 for i in range(degree+1)}
 for row in c['A'+str(degree)]:
  for mon,p in zip(ms,row):counts[sum(i in active for i in mon)]+=len(p)
 out[degree]=counts
print(out,time.time()-st,flush=True);Path('work/flag-general-raw4-count.json').write_text(json.dumps(out,indent=2)+'\n')
# Save a much smaller payload, retaining only degree4 monomials surviving the
# generic quadratic-product quotient. No projected polynomial is yet changed.
ms=list(cwr(range(9),4));columns=[j for j,m in enumerate(ms)if sum(i in active for i in m)<=2]
c['A4_surviving']=[[row[j]for j in columns]for row in c['A4']];c['A4_columns']=columns
for k in ['A4','W3','W4']:del c[k]
pickle.dump(c,open('work/flag-eight-flint-projection-input.pkl','wb'));print('saved',Path('work/flag-eight-flint-projection-input.pkl').stat().st_size,time.time()-st,flush=True)

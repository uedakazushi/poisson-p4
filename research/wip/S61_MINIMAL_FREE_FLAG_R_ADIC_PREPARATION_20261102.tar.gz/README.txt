WIP only: free-M0 finite-field parameter-adic module preparation, 2026-11-02.
This archive preserves exploratory sources and results, not a new full-S61 theorem.
No DLL, binary, 320MB raw input, or 74MB filtered full basis is included.

The fast tracked validator checks archive hashes, finite initial-monomial counts,
normal-form matrix ranks and saved relation kernels. It does not rebuild raw135
jets or repeat the native standard-basis calculation. The t-square result and
function-field module ranks are preserved computation records.

To rebuild the original experiments (minutes, not performed by the validator):
restore work/* below the repository work/ directory; restore tmp/* below /tmp/.
Run from repository root with .venv/bin/python, in the following order:
  work/minimal_free_flag_transverse_raw_probe_20261101.py
  work/minimal_free_flag_base_linear_module_probe_20261101.py
  work/minimal_free_flag_module_queries_20261101.py
  work/minimal_free_flag_first_base_relations_20261101.py
  work/minimal_free_flag_base_quadratic_module_probe_20261101.py
  work/minimal_free_flag_module_quadratic_queries_20261101.py
  work/minimal_free_flag_second_base_relations_20261101.py
The scripts deliberately preserve the original /tmp paths and local M2 command.
Adapt the latter to an available standard M2 installation if necessary.
For the t-action script, first compile
  code/truncated_local_module_normal_form_20261102.cpp
as /tmp/minimal-free-flag-cached-module-nf using clang++ -O3 -std=c++17.
Then run work/minimal_free_flag_parameter_t_action_20261102.py.
The module-query script creates its own native helper from the tracked standard
basis source; the quadratic query script adds full-basis export.

Do not repeat the stored third-layer 240s/180s or Mora 90s failures unchanged.
Raw data are rebuilt from tracked source models and the frozen endpoint report.
The characteristic-zero, relative, full-ring torsion and saturation steps are open.

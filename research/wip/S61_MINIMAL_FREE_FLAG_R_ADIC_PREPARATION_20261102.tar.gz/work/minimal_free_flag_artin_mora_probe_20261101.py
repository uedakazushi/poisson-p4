import json,sys,time,numpy as np,sympy as s,subprocess,os
from itertools import combinations_with_replacement as cwr
sys.path.insert(0,'code');from s61_model import S61;from s61_flag_transverse_obstruction_20261101 import specialize
st=time.time();p=32003;r=json.load(open('reports/S61_MINIMAL_FLAG_ENDPOINT_TABLE_20261101.json'))['strata']['free_M0']['local_data'];m=S61();pt=s.Matrix(r['point61']).applyfunc(s.Rational);one=[i for i,w in enumerate(m.reduced['parameter_weights'])if w==1];two,F=specialize(m,dict(zip(one,pt[one,:])),True);fixed=two.index(r['chart_fixed_u']-1);cols=r['chart_columns'];J=s.Matrix(r['jacobian']);T=s.Matrix(r['tangent_basis']);T=s.Matrix.hstack(T[:,3],T[:,4],T[:,5]-T[:,1],T[:,6:11],T[:,0],T[:,2],T[:,1]);C=list(J.to_DM().rref()[1]);R=list(J[:,C].T.to_DM().rref()[1]);U=s.zeros(45,34);Ui=J[R,C].inv()
for ri,ci in enumerate(C):U[ci,:]=Ui[ri,:]
V=T.row_join(U)
def mod(v):v=s.Rational(v);return int(v.p)*pow(int(v.q),-1,p)%p
arr=lambda M:np.array([[mod(v)for v in row]for row in M.tolist()],dtype=np.int64);v=arr(V);j=arr(J);H=np.zeros((135,45,45),dtype=np.int64)
for row,f in enumerate(F):
 for mon,c in f.items():
  if fixed in mon:continue
  i,k=[cols.index(x)for x in mon]+[44]*(2-len(mon));a=mod(c)
  if i==k:H[row,i,k]+=a
  else:H[row,i,k]+=a*pow(2,-1,p)%p;H[row,k,i]+=a*pow(2,-1,p)%p
H%=p;lin=j@v%p;polys=[]
for row in range(135):
 B=v.T@(H[row]@v%p)%p;terms=[str(int(lin[row,i]))+'*x_'+str(i)for i in range(45)if lin[row,i]]
 for i in range(45):
  for k in range(i,45):
   c=int(B[i,k])*(1 if i==k else 2)%p
   if c:terms.append(str(c)+'*x_'+str(i)+'*x_'+str(k))
 polys.append('+'.join(terms)or'0')
polys+=['*'.join('x_'+str(i)for i in mon)for mon in cwr([8,9,10],2)]
prog='R=ZZ/32003[x_0..x_44,MonomialOrder=>{Weights=>toList(45:-1),GRevLex},Global=>false];I=ideal('+','.join(polys)+');print "INPUT READY";stdio<<flush;G=gb I;print("GB",numgens source gens G);B=leadTerm gens G;A=ZZ/32003[x_0..x_44];L=ideal sub(B,A);print("ARTIN",dim(A/L),degree(A/L));stdio<<flush;\n';src='/tmp/minimal-free-flag-artin-mora.m2';open(src,'w').write(prog);e=os.environ.copy();e['DYLD_LIBRARY_PATH']=os.getcwd()+'/work/m2-runtime/lib:/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'
try:
 z=subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',src],env=e,capture_output=True,text=True,timeout=90);out={'returncode':z.returncode,'log':z.stdout,'error':z.stderr}
except subprocess.TimeoutExpired as ex:out={'timeout':90,'log':str(ex.stdout),'error':str(ex.stderr)}
out['seconds']=time.time()-st;print(json.dumps(out),flush=True);json.dump(out,open('work/minimal-free-flag-artin-mora-probe.json','w'),indent=2)

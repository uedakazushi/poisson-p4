import sys,json,time,subprocess
from pathlib import Path
sys.path.insert(0,'code');from truncated_local_ideal_io_20261101 import monomials
st=time.time();p=32003;D=9;Nmons=monomials(11,D);ix={m:i for i,m in enumerate(Nmons)}
with open('/tmp/minimal-free-flag-base-quadratic-input.txt')as f:
 header=f.readline();pp,n,N,F=map(int,header.split())
 for _ in range(n+1+F):f.readline()
 tv=list(map(int,f.readline().split()));assert len(tv)==N
fpath='/tmp/minimal-free-flag-t-module-query.txt';out='/tmp/minimal-free-flag-t-module-answer.txt';meta='/tmp/minimal-free-flag-t-module-meta.txt'
def nf(rows):
 with open(fpath,'w')as f:
  f.write(str(len(rows))+'\n')
  for row in rows:f.write(str(len(row))+' '+' '.join(str(i)+' '+str(c)for i,c in sorted(row.items()))+'\n')
 subprocess.run(['/tmp/minimal-free-flag-cached-module-nf','11',str(D),'/tmp/minimal-free-flag-base-quadratic-fullbasis.txt',fpath,out,meta],check=True,capture_output=True,text=True,timeout=30)
 result=[]
 for line in Path(out).read_text().splitlines()[1:]:
  z=list(map(int,line.split()));result.append(dict(zip(z[1::2],z[2::2])))
 return result
T=nf([{i:c for i,c in enumerate(tv)if c}])[0]
def product(A,B):
 C={}
 for i,a in A.items():
  for j,b in B.items():
   if len(Nmons[i])+len(Nmons[j])>D:continue
   m=tuple(sorted(Nmons[i]+Nmons[j]));k=ix[m];C[k]=(C.get(k,0)+a*b)%p
 return {k:c for k,c in C.items()if c}
T2,T3=nf([product(T,T),product(product(T,T),T)])
print('T ACTION',len(T),len(T2),len(T3),'seconds',time.time()-st,flush=True)
json.dump({'prime':p,'quotient':'S/(v8,v9,v10)^3','t_terms':len(T),'t2_terms':len(T2),'t3_terms':len(T3),'t2_sparse':list(T2.items()),'t3_sparse':list(T3.items()),'seconds':time.time()-st},open('work/minimal-free-flag-parameter-t-action.json','w'),indent=2)

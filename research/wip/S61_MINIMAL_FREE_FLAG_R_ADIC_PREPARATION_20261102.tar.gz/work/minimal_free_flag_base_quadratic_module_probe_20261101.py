import sys,time,json,subprocess,inspect,numpy as np
from itertools import combinations_with_replacement as cwr
sys.path.insert(0,'code');import s61_minimal_free_flag_initial_probe_20261101 as base
from truncated_local_ideal_io_20261101 import write_input
st=time.time();source=inspect.getsource(base.build_jets).replace('def build_jets(', 'def build_weighted_jets(')
source=source.replace('list(combinations_with_replacement(range(n),d))','[m for m in combinations_with_replacement(range(n),d) if sum(j>=8 for j in m)<3]')
old='indices=np.array([idx[degree][tuple(sorted(ma+mb))]for ma in ms[da]for mb in ms[db]])'
new='indices=np.array([idx[degree].get(tuple(sorted(ma+mb)),-1)for ma in ms[da]for mb in ms[db]]);mask=indices>=0'
assert old in source;source=source.replace(old,new).replace('np.bincount(indices,weights=cross.ravel(),','np.bincount(indices[mask],weights=cross.ravel()[mask],')
source=source.replace('return n,jet,ts','return n,jet,ts,ms')
ns=vars(base).copy();exec(source,ns);n,A,t,mm=ns['build_weighted_jets'](9);assert n==11;powers=list(cwr([8,9,10],3))
for d in range(2,10):
 full=list(cwr(range(11),d));ix={m:i for i,m in enumerate(full)};sel=[ix[m]for m in mm[d]];M=np.zeros((145,len(full)),dtype=np.int64);M[:135,sel]=A[d];ts=np.zeros(len(full),dtype=np.int64);ts[sel]=t[d];t[d]=ts
 if d==3:
  for j,mon in enumerate(powers):M[135+j,ix[mon]]=1
 A[d]=M
src='/tmp/minimal-free-flag-base-quadratic-input.txt';write_input(src,32003,n,A,t,maximum_degree=9);print('INPUT READY',time.time()-st,flush=True)
exe='/tmp/minimal-free-flag-module-query';p=subprocess.run([exe,src,'/tmp/minimal-free-flag-base-quadratic-initial.txt'],text=True,capture_output=True,timeout=180);print(p.returncode,p.stdout,p.stderr,time.time()-st,flush=True);json.dump({'prime':32003,'base_columns':[8,9,10],'degree':9,'returncode':p.returncode,'log':p.stdout,'seconds':time.time()-st},open('work/minimal-free-flag-base-quadratic-module.json','w'),indent=2)

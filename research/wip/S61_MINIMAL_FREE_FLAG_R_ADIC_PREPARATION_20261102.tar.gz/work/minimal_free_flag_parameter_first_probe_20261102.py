from pathlib import Path
import subprocess,time,json
st=time.time();src=Path('/tmp/minimal-free-flag-base-linear-input.txt');dst=Path('/tmp/minimal-free-flag-base-linear-parameters-first.txt')
with src.open()as f:
 header=f.readline();p,n,N,F=map(int,header.split());prefix=[f.readline()for _ in range(n+1)];offset=[]
 for _ in range(F):offset.append(f.tell());f.readline()
 tail=f.tell()
 with dst.open('w')as g:
  g.write(header);g.writelines(prefix)
  for j in list(range(135,F))+list(range(135)):
   f.seek(offset[j]);g.write(f.readline())
  f.seek(tail);g.write(f.read())
p=subprocess.run(['/tmp/minimal-free-flag-module-query',str(dst),'/tmp/minimal-free-flag-base-linear-parameters-first-initial.txt'],capture_output=True,text=True,timeout=60);print(p.returncode,p.stdout.split('t ')[0],p.stderr,time.time()-st,flush=True);json.dump({'returncode':p.returncode,'log':p.stdout.split('t ')[0],'seconds':time.time()-st},open('work/minimal-free-flag-parameter-first-probe.json','w'),indent=2)

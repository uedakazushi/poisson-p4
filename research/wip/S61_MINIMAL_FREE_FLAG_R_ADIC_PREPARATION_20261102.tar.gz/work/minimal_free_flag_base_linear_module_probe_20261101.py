import sys,time,json,subprocess,numpy as np
from itertools import combinations_with_replacement as cwr
sys.path.insert(0,'code')
from s61_minimal_free_flag_initial_probe_20261101 import build_jets
from truncated_local_ideal_io_20261101 import write_input
st=time.time();n,A,t=build_jets(8);assert n==11
pairs=list(cwr([8,9,10],2));mm={d:list(cwr(range(11),d))for d in range(2,9)}
for d in range(2,9):
 M=np.array(A[d],dtype=np.int64);add=np.zeros((6,M.shape[1]),dtype=np.int64)
 if d==2:
  for row,mon in enumerate(pairs):add[row,mm[d].index(mon)]=1
 A[d]=np.vstack([M,add])
src='/tmp/minimal-free-flag-base-linear-input.txt';write_input(src,32003,n,A,t,maximum_degree=8)
exe='/tmp/minimal-free-flag-base-linear-standard';subprocess.run(['clang++','-O3','-std=c++17','code/truncated_local_standard_basis_20261101.cpp','-o',exe],check=True)
p=subprocess.run([exe,src,'/tmp/minimal-free-flag-base-linear-initial.txt'],text=True,capture_output=True,timeout=120);print(p.returncode,p.stdout,p.stderr,time.time()-st,flush=True)
json.dump({'prime':32003,'base_columns':[8,9,10],'degree':8,'returncode':p.returncode,'log':p.stdout,'seconds':time.time()-st},open('work/minimal-free-flag-base-linear-module.json','w'),indent=2)

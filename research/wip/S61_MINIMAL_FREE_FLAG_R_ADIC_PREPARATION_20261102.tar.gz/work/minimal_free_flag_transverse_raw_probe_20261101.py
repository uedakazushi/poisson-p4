import inspect,sys,time,json,subprocess
from pathlib import Path
sys.path.insert(0,'code')
import s61_minimal_free_flag_initial_probe_20261101 as base
from truncated_local_ideal_io_20261101 import write_input
st=time.time();source=inspect.getsource(base.build_jets).replace('n=T.cols','T=T[:,:8];n=T.cols').replace('def build_jets(', 'def build_transverse_jets(');ns=vars(base).copy();exec(source,ns);n,A,t=ns['build_transverse_jets'](10);assert n==8
src='/tmp/minimal-free-flag-transverse10-input.txt';write_input(src,32003,n,A,t,maximum_degree=10)
exe='/tmp/minimal-free-flag-transverse-standard';subprocess.run(['clang++','-O3','-std=c++17','code/truncated_local_standard_basis_20261101.cpp','-o',exe],check=True)
p=subprocess.run([exe,src,'/tmp/minimal-free-flag-transverse10-initial.txt'],text=True,capture_output=True,timeout=90);print(p.returncode,p.stdout,p.stderr,time.time()-st,flush=True)
json.dump({'prime':32003,'normal_columns':list(range(8)),'base_columns':[8,9,10],'degree':10,'returncode':p.returncode,'log':p.stdout,'seconds':time.time()-st},open('work/minimal-free-flag-transverse10.json','w'),indent=2)

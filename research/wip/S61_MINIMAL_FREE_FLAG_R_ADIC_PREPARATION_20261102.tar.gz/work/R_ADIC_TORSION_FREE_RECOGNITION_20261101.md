# R-adic graded-module recognition: proposed finite bridge

Let R=k[[u1,...,ud]], P=gr_m(R)=k[u1,...,ud]. Let S be a finite R-algebra,
and let S -> D be a surjective R-algebra map. Fix an element t in S.
Assume D has R-rank zero and t^h=0 in D. Let r=rank_R(S).

Suppose a finite graded P-module M, given by explicit leading relations of an
R-module generating set of S, has a surjection

    M -> gr_mR S -> gr_mR D.

Here the filtration is m_R^n S, not the maximal-ideal filtration of S.
Let H=ker(M -> gr_mR D). Assume:

1. rank_P(M)=r;
2. H is P-torsion-free;
3. t^h=0 in S tensor_R Frac(R).

Then t^h=0 in S.

Indeed rank_P(gr_mR S)=rank_R(S): both are the Hilbert-Samuel multiplicity
of S over the regular local ring R, since all lower-dimensional R-torsion
has smaller-dimensional Hilbert growth. Thus K=ker(M -> gr_mR S) has rank
zero. It is a submodule of H, so torsion-freeness gives K=0. The map S -> D
is strict for the m_R-adic filtrations, since m_R^n S maps onto m_R^n D.
For N=ker(S -> D), the induced filtration N intersect m_R^n S therefore
has associated graded H. If a nonzero a in R killed a nonzero n in N,
its initial form would kill the nonzero initial form of n in H. Separatedness
and compatibility of the filtrations give a contradiction. Hence N is
R-torsion-free. Since t^h belongs to N and becomes zero after tensoring
with Frac(R), it vanishes in N and in S.

For the free-M0 candidate:

- R has three common-projection parameters.
- The chosen transverse finite-field quotient has length141, so141 monomials
  generate S as an R-module by complete Nakayama.
- The known flag and binary branches suggest r=5+65=70 after all good-prime
  lower-bound hypotheses are checked.
- The actual flat4 baseline quotient is a candidate D, with t^2=0.
- The first two parameter-adic layers yield141 generators,22 linear leading
  relations, and85 quadratic leading relations (25 beyond linear multiples).
  Their candidate module has rank108, so condition1 is NOT yet satisfied.
- No torsion-free H has been constructed or proved.
- The calculations are at one finite-field point. Relative beta and
  characteristic-zero descent are separate required steps.

This is a proposed recognition lemma and strategy, not a proof of saturation
removal for the free-M0 stratum. In particular the earlier m-adic embedded
module E of dimension2/degree31 is not being identified with actual R-torsion.

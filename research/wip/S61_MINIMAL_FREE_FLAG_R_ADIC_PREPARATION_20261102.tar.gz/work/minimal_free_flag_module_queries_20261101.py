from pathlib import Path
import sys,json,subprocess,time
sys.path.insert(0,'code');from truncated_local_ideal_io_20261101 import monomials,read_initial
st=time.time();n=8;rows=read_initial('/tmp/minimal-free-flag-transverse10-initial.txt',8,10);leads=[min(r)for r in rows]
def divides(m,x):return all(x.count(i)>=m.count(i)for i in set(m))
B=[m for m in monomials(8,7)if not any(divides(l,m)for l in leads)];assert len(B)==141
mons=monomials(11,8);ix={m:i for i,m in enumerate(mons)};qs=B+[tuple(sorted(m+(j,)))for j in[8,9,10]for m in B]
qpath=Path('/tmp/minimal-free-flag-module-queries.txt');qpath.write_text(str(len(qs))+'\n'+'\n'.join('1 '+str(ix[m])+' 1' for m in qs)+'\n');src=Path('code/truncated_local_standard_basis_20261101.cpp').read_text();needle=' int len=count(reducer.begin(),reducer.end(),-1);';addition='''
 if(argc>=5){ifstream queries(argv[3]);ofstream answers(argv[4]);if(!queries||!answers)return 11;int count;queries>>count;answers<<count<<"\\n";
 for(int qi=0;qi<count;qi++){int length;queries>>length;vector<int>v(N);for(int k=0;k<length;k++){int column,c;queries>>column>>c;v[column]=c;}reduce(v);int total=0;for(int x:v)if(x)total++;answers<<total;for(int k=0;k<N;k++)if(v[k])answers<<" "<<k<<" "<<v[k];answers<<"\\n";}answers.flush();if(!queries||!answers)return 12;}
''';assert needle in src;src=src.replace(needle,addition+needle);cpp=Path('/tmp/minimal-free-flag-module-query.cpp');cpp.write_text(src);exe='/tmp/minimal-free-flag-module-query';subprocess.run(['clang++','-O3','-std=c++17',str(cpp),'-o',exe],check=True);p=subprocess.run([exe,'/tmp/minimal-free-flag-base-linear-input.txt','/tmp/minimal-free-flag-base-linear-initial2.txt',str(qpath),'/tmp/minimal-free-flag-module-answers.txt'],capture_output=True,text=True,timeout=120);print(p.returncode,p.stdout,p.stderr,time.time()-st,flush=True);json.dump({'base_monomials':B,'seconds':time.time()-st},open('work/minimal-free-flag-module-query-basis.json','w'),indent=2)

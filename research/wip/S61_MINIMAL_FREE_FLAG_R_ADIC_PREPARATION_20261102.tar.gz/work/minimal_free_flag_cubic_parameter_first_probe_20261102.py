from pathlib import Path
import subprocess,time,json
st=time.time();src=Path('/tmp/minimal-free-flag-base-cubic-input.txt');dst=Path('/tmp/minimal-free-flag-base-cubic-parameters-first.txt')
with src.open()as f:
 header=f.readline();p,n,N,F=map(int,header.split());prefix=[f.readline()for _ in range(n+1)];offset=[]
 for _ in range(F):offset.append(f.tell());f.readline()
 tail=f.tell()
 with dst.open('w')as g:
  g.write(header);g.writelines(prefix)
  for j in list(range(135,F))+list(range(135)):
   f.seek(offset[j]);g.write(f.readline())
  f.seek(tail);g.write(f.read())
p=subprocess.run(['/tmp/minimal-free-flag-module-query',str(dst),'/tmp/minimal-free-flag-base-cubic-parameters-first-initial.txt'],capture_output=True,text=True,timeout=180);print(p.returncode,p.stdout.split('t ')[0],p.stderr,time.time()-st,flush=True);json.dump({'returncode':p.returncode,'log':p.stdout.split('t ')[0],'seconds':time.time()-st},open('work/minimal-free-flag-cubic-parameter-first-probe.json','w'),indent=2)

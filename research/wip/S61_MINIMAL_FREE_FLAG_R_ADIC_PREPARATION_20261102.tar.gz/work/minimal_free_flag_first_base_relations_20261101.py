import json,time,numpy as np,os,subprocess
st=time.time();p=32003;lines=open('/tmp/minimal-free-flag-module-answers.txt').read().splitlines();assert int(lines[0])==564;R=[]
for l in lines[1:]:
 v=list(map(int,l.split()));assert len(v)==2*v[0]+1;R.append(dict(zip(v[1::2],v[2::2])))
cols=sorted({i for r in R for i in r});ix={v:i for i,v in enumerate(cols)};A=np.zeros((len(cols),423),dtype=np.int64)
for j,r in enumerate(R[141:]):
 for k,c in r.items():A[ix[k],j]=c
A=A%p;h=0;piv=[]
for j in range(423):
 ii=np.flatnonzero(A[h:,j])
 if not len(ii):continue
 k=h+ii[0];A[[h,k]]=A[[k,h]];A[h]=A[h]*pow(int(A[h,j]),-1,p)%p;ii=np.flatnonzero(A[:,j]);ii=ii[ii!=h]
 if len(ii):A[ii]=(A[ii]-A[ii,j,None]*A[h])%p
 piv.append(j);h+=1
 if h==A.shape[0]:break
free=[j for j in range(423)if j not in piv];N=np.zeros((423,len(free)),dtype=np.int64)
for j,k in enumerate(free):N[k,j]=1;N[piv,j]=-A[:h,k]%p
print('first module',len(cols),'u-rank',h,'linear relations',len(free),flush=True)
rows=[]
for i in range(141):rows.append('{'+','.join('+'.join(str(int(N[i+141*k,j]))+'*u_'+str(k)for k in range(3)if N[i+141*k,j])or'0'for j in range(len(free)))+'}')
program='R=ZZ/32003[u_0..u_2];P=matrix{'+','.join(rows)+'};M=coker P;print("MODULE",numgens M,numgens source P,rank M,dim M,degree M);stdio<<flush;\n';src='/tmp/minimal-free-flag-first-base-relations.m2';open(src,'w').write(program);env=os.environ.copy();env['DYLD_LIBRARY_PATH']=os.getcwd()+'/work/m2-runtime/lib:/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib';done=subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',src],env=env,capture_output=True,text=True,timeout=30);print(done.returncode,done.stdout,done.stderr,time.time()-st,flush=True);json.dump({'prime':p,'linear_relations':[[[int(i),int(x)]for i,x in enumerate(N[:,j])if x]for j in range(len(free))],'first_u_rank':h,'m2':done.stdout,'seconds':time.time()-st},open('work/minimal-free-flag-first-base-relations.json','w'),indent=2)

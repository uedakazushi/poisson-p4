# Free-M0 fifth-tail / sixth preparation (WIP)

Run from the repository root after extracting this archive to `work/free-flag-sixth-preparation`.
The exact full fifth tail is preparation for six, not a proved sixth-order result.

```
.venv/bin/python work/free-flag-sixth-preparation/minimal_free_flag_full_fifth_input_20261101.py
clang++ -O3 -std=c++17 -Iwork/flint-headers/flint/3.5.0/include -Iwork/flint-headers/mpfr/4.2.2/include -I/opt/homebrew/include work/free-flag-sixth-preparation/minimal_free_flag_full_fifth_20261101.cpp work/m2-runtime/lib/libflint.24.0.dylib -L/opt/homebrew/lib -lgmp -o /tmp/minimal-free-flag-full-fifth-native
DYLD_LIBRARY_PATH="$PWD/work/m2-runtime/lib:/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib" /tmp/minimal-free-flag-full-fifth-native /tmp/minimal-free-flag-full-fifth-native-input.txt /tmp/minimal-free-flag-full-fifth-native-output.txt
.venv/bin/python work/free-flag-sixth-preparation/minimal_free_flag_native_fifth_mod_check_20261101.py
```

The compiler paths describe the existing local FLINT3.5 runtime; a standard FLINT install can replace them. No binary or dependency library is included and no OS files were changed. The source checks failed output opens/writes. Files are written under /tmp to avoid native subprocess sandbox problems. The 17MB input and107MB output are reproducible, not archived.

The native full A5 numerator has2805179 parameter monomials. The independently reconstructed raw135 finite-field recurrence agrees in all405405 coefficients at a=(1,2,3,4,5),p=32003. This modular crosscheck does not by itself prove a characteristic-zero theorem; the native algorithm uses exact rational polynomial arithmetic.

`minimal_free_flag_known_sixth_space_20261101.py` reconstructs the known sixth homogeneous rowspace, rank6757+14, quotient1237. Its exploratory output path is under work; it is not a proof of new sixth relations.

`minimal_free_flag_projected_sixth_raw_20261101.py` depends on the earlier ignored sparse work JSONs and is archived ONLY as an incomplete attempt, not as a standalone producer. Its180-second Python run completed pair contractions but not the final135 aggregation. Do not rerun it unchanged. Next: native aggregation, then preserve all full lower tails during genuine sixth syzygy extraction.

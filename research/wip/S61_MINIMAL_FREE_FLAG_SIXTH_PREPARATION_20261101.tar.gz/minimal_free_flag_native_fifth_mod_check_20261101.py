import json,sys,time,sympy as s,numpy as np
from itertools import combinations_with_replacement
sys.path.insert(0,'code');from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
st=time.time();p=32003;values=[1,2,3,4,5];powers=[[pow(v,e,p)for e in range(20)]for v in values];native=np.zeros((135,3003),dtype=np.int64)
with open('/tmp/minimal-free-flag-full-fifth-native-output.txt')as f:
 assert list(map(int,f.readline().split()))==[135,3003,5]
 for row in range(135):
  for _ in range(int(f.readline())):
   col=int(f.readline());value=0
   for _ in range(int(f.readline())):
    z=f.readline().split();c=z[0].split('/');v=int(c[0])%p
    if len(c)>1:v=v*pow(int(c[1]),-1,p)%p
    for j,e in enumerate(z[1:]):v=v*powers[j][int(e)]%p
    value=(value+v)%p
   native[row,col]=value
 assert not f.read().strip()
print('native read',time.time()-st,flush=True);r=json.load(open('reports/S61_MINIMAL_FREE_FLAG_UNIVERSAL_QUADRATIC_20261101.json'));a=s.symbols('a0:5');sub=dict(zip(a,values));mat=lambda key:s.Matrix(r[key]).applyfunc(s.sympify).subs(sub);J=mat('jacobian');T=mat('tangent_basis_after_shift');T[:,1]-=s.Rational(values[1],6)*T[:,0];U=mat('right_inverse');rows=r['pivot_rows'];mod=lambda x:int(s.Rational(x).p)*pow(int(s.Rational(x).q),-1,p)%p;arr=lambda M:np.array([[mod(x)for x in row]for row in M.tolist()],dtype=np.int64);j=arr(J);u=arr(U);t=arr(T);JU=j@u%p;m=S61();one=[i for i,w in enumerate(m.reduced['parameter_weights'])if w==1];beta=s.Matrix(json.load(open('reports/S61_MINIMAL_FREE_FLAG_NORMAL_FORM_20261101.json'))['normalized_beta16']).applyfunc(s.sympify).subs(sub);two,F=specialize(m,dict(zip(one,beta)),True);point=json.load(open('reports/S61_MINIMAL_FLAG_ENDPOINT_TABLE_20261101.json'))['strata']['free_M0']['local_data'];fixed=two.index(point['chart_fixed_u']-1);chart=point['chart_columns'];H=np.zeros((135,45,45),dtype=np.int64)
for row,f in enumerate(F):
 for mon,c in f.items():
  if fixed in mon:continue
  i,k=[chart.index(v)for v in mon]+[44]*(2-len(mon));v=mod(c)
  if i==k:H[row,i,k]+=v
  else:H[row,i,k]+=v*pow(2,-1,p)%p;H[row,k,i]+=v*pow(2,-1,p)%p
H%=p;mm={d:list(combinations_with_replacement(range(11),d))for d in range(1,6)};ix={d:{mon:i for i,mon in enumerate(mm[d])}for d in mm};W={1:t}
for degree in range(2,6):
 Q=np.zeros((135,len(mm[degree])),dtype=np.int64)
 for da in range(1,degree//2+1):
  db=degree-da;fac=1 if da==db else 2;indices=np.array([ix[degree][tuple(sorted(x+y))]for x in mm[da]for y in mm[db]])
  for row in range(135):
   cross=(W[da].T@(H[row]@W[db]%p))%p;acc=np.bincount(indices,weights=cross.ravel(),minlength=len(mm[degree])).astype(np.int64);Q[row]=(Q[row]+fac*acc)%p
 W[degree]=-u@Q[rows,:]%p;A=(Q-JU@Q[rows,:])%p;print('degree',degree,time.time()-st,flush=True)
assert np.array_equal(native,A*pow(values[1],4,p)%p);np.save('work/minimal-free-flag-native-full-fifth-mod.npy',native);json.dump(dict(all_passed=True,prime=p,point=values,coefficients=135*3003,seconds=time.time()-st),open('work/minimal-free-flag-native-full-fifth-mod-check.json','w'),indent=2);print('PASS',time.time()-st,flush=True)

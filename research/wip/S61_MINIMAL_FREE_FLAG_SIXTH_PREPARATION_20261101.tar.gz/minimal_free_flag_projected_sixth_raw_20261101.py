import json,time,sympy as s
from itertools import combinations_with_replacement
from sympy.polys.rings import ring
st=time.time();R,*ar=ring('a0,a1,a2,a3,a4',s.QQ);d=ar[1];unpack=lambda A:[[R.from_dict({tuple(ex):s.QQ.from_sympy(s.Rational(co))for ex,co in poly})for poly in row]for row in A];rp=lambda M:[[R.from_expr(x)for x in row]for row in M.tolist()];z=json.load(open('work/minimal-free-flag-reduced-five-jets.json'));raw5=json.load(open('work/minimal-free-flag-universal-fifth-raw.json'));r5=json.load(open('reports/S61_MINIMAL_FREE_FLAG_UNIVERSAL_QUINTIC_20261101.json'));q6=json.load(open('work/minimal-free-flag-known-sixth-space.json'));TT=unpack(z['T']);W2=unpack(z['W2']);W3=unpack(z['W3']);W4=unpack(z['W4']);H5=unpack(raw5['H5']);Q5=rp(s.Matrix(r5['constant_fifth_rref']).applyfunc(s.Rational));p5=r5['pivots'];f5=[j for j in range(763)if j not in p5]
for row in H5:
 for pi,rr in zip(p5,Q5):
  c=row[pi]
  if c:
   for j,v in enumerate(rr):
    if v:row[j]-=c*v
H5=[[row[j]for j in f5]for row in H5];f5=[raw5['free5'][j]for j in f5];UP=rp(s.Matrix(z['UP']).applyfunc(s.sympify));W5=[[R.zero]*740 for _ in range(45)]
for i,row in enumerate(UP):
 for k,c in enumerate(row):
  if c:
   for j,v in enumerate(H5[z['pivot_rows'][k]]):
    if v:W5[i][j]-=c*v
print('W5',time.time()-st,'terms',sum(len(x)for row in W5 for x in row),flush=True)
mm={k:list(combinations_with_replacement(range(11),k))for k in range(1,7)};ix6={mon:j for j,mon in enumerate(mm[6])};fm={k:[mm[k][j]for j in z['free'+str(k)]]for k in [2,3,4]};fm[5]=[mm[5][j]for j in f5];fm[1]=mm[1];cp=q6['pivots'];cf=q6['free'];cfindex={j:i for i,j in enumerate(cf)};vp=q6['variable_pivots'];vf=[j for j in range(len(cf))if j not in vp];vfindex={j:i for i,j in enumerate(vf)};vq=rp(s.Matrix(q6['variable_rref']).applyfunc(s.sympify));cpindex={j:i for i,j in enumerate(cp)};nf=[]
for j in range(8008):
 if j in cfindex:row={cfindex[j]:R.one}
 else:row={cfindex[k]:-R.from_expr(s.Rational(c))for k,c in q6['rref_sparse'][cpindex[j]]if k!=j}
 for pi,rr in zip(vp,vq):
  c=row.get(pi,R.zero)
  if c:
   for k,v in enumerate(rr):
    if v:row[k]=row.get(k,R.zero)-c*v
 nf.append([(vfindex[k],v)for k,v in row.items()if v])
print('normalforms',sum(bool(row)for row in nf),sum(len(row)for row in nf),time.time()-st,flush=True)
terms=[[(i,j,R.from_dict({tuple(ex):s.QQ.from_sympy(s.Rational(co))for ex,co in c}))for i,j,c in row]for row in z['terms']];pairs=sorted({(min(i,j),max(i,j))for row in terms for i,j,c in row});cache={}
def product(out,left,right,lm,rm):
 for i,x in enumerate(left):
  if x:
   for j,y in enumerate(right):
    if y:
     normal=nf[ix6[tuple(sorted(lm[i]+rm[j]))]]
     if normal:
      value=x*y
      for k,c in normal:out[k]+=c*value
for count,(i,j)in enumerate(pairs):
 out=[R.zero]*len(vf)
 for left,right,da,db in [(TT[i],W5[j],1,5),(TT[j],W5[i],1,5),(W2[i],W4[j],2,4),(W2[j],W4[i],2,4),(W3[i],W3[j],3,3)]:product(out,left,right,fm[da],fm[db])
 cache[i,j]=out
 if count%100==0:print('pair',count,time.time()-st,flush=True)
H6=[[R.zero]*len(vf)for _ in range(135)]
for row,tr in enumerate(terms):
 for i,j,c in tr:
  for k,v in enumerate(cache[min(i,j),max(i,j)]):
   if v:H6[row][k]+=c*v
J=s.Matrix(z['jacobian']).applyfunc(s.sympify);up=s.Matrix(z['UP']).applyfunc(s.sympify);JUP=rp((J.to_DM()*up.to_DM()).to_Matrix());A6=[]
for i,row in enumerate(JUP):
 out=[d*x for x in H6[i]]
 for k,c in enumerate(row):
  if c:
   for j,v in enumerate(H6[z['pivot_rows'][k]]):
    if v:out[j]-=c*v
 A6.append(out)
print('A6',time.time()-st,'terms',sum(len(x)for row in A6 for x in row),flush=True);pack=lambda A:[[[[list(ex),str(co)]for ex,co in value.items()]for value in row]for row in A];json.dump(dict(A6=pack(A6),H6=pack(H6),free6=[cf[j]for j in vf],seconds=time.time()-st),open('work/minimal-free-flag-projected-sixth-raw.json','w'));print('saved',time.time()-st,flush=True)

import json,time,sympy as s
from itertools import combinations_with_replacement
st=time.time();v=s.symbols('v0:11');a1=s.Symbol('a1');mm={k:list(combinations_with_replacement(range(11),k))for k in range(1,7)};ix={k:{m:j for j,m in enumerate(mm[k])}for k in mm};r2=json.load(open('reports/S61_MINIMAL_FREE_FLAG_UNIVERSAL_QUADRATIC_20261101.json'));r3=json.load(open('reports/S61_MINIMAL_FREE_FLAG_UNIVERSAL_CUBIC_20261101.json'));r4=json.load(open('reports/S61_MINIMAL_FREE_FLAG_UNIVERSAL_QUARTIC_20261101.json'));r5=json.load(open('reports/S61_MINIMAL_FREE_FLAG_UNIVERSAL_QUINTIC_20261101.json'));gens=[]
for row in r2['constant_quadratic_rref']:gens.append((2,{m:s.Rational(c)for c,m in zip(row,mm[2])if c!='0'}))
for expression in r3['constant_cubic_polynomials']:
 poly=s.Poly(s.sympify(expression),*v);gens.append((3,{tuple(j for j,n in enumerate(ex)for _ in range(n)):c for ex,c in poly.terms()}))
q4=[{mm[4][j]:s.sympify(c)for c,j in zip(row,r4['quotient_free_columns'])if c!='0'}for row in r4['new_quartic_rref']];gens.extend((4,row)for row in q4[1:]);gens.extend((5,{mm[5][j]:s.Rational(c)for c,j in zip(row,r5['quotient_free_columns'])if c!='0'})for row in r5['constant_fifth_rref']);entries={};count=0
for degree,poly in gens:
 for mon in mm[6-degree]:
  for exp,c in poly.items():
   key=(count,ix[6][tuple(sorted(mon+exp))]);entries[key]=entries.get(key,0)+c
  count+=1
A=s.SparseMatrix(count,len(mm[6]),entries);print('matrix',A.shape,'terms',len(entries),time.time()-st,flush=True);rr,p= A.to_DM().rref();free=[j for j in range(len(mm[6]))if j not in p];rows=rr.to_sdm();print('constant',len(p),'terms',sum(len(row)for row in rows.values()),time.time()-st,flush=True)
B=[]
for mon in mm[2]:
 row={ix[6][tuple(sorted(mon+exp))]:c for exp,c in q4[0].items()}
 for i,pi in enumerate(p):
  c=row.get(pi,0)
  if c:
   for j,x in rows[i].items():row[j]=row.get(j,0)-c*rr.domain.to_sympy(x)
 B.append([row.get(j,0)for j in free])
vr,vp=s.Matrix(B).to_DM().rref();vr=vr.to_Matrix()[:len(vp),:].applyfunc(s.factor);print('variable',len(vp),'totalfree',len(free)-len(vp),time.time()-st,flush=True);json.dump(dict(constant_rank=len(p),variable_rank=len(vp),pivots=list(p),free=free,rref_sparse=[[[j,str(rr.domain.to_sympy(c))]for j,c in rows[i].items()]for i in range(len(p))],variable_pivots=list(vp),variable_rref=[[str(c)for c in row]for row in vr.tolist()],seconds=time.time()-st),open('work/minimal-free-flag-known-sixth-space.json','w'),indent=2)

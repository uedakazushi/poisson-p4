import sys,time,sympy as s
from itertools import combinations_with_replacement
from pathlib import Path
sys.path.insert(0,'code');from s61_minimal_free_flag_filtered_data_20261101 import build_four
st=time.time();b=build_four();data=b['data'];R=b['R'];rp=b['rp'];mul=b['multiply'];H4=b['H4'];W4=mul(rp(-data['UP']),[H4[i]for i in data['rows']]);print('W4',time.time()-st,'terms',sum(len(x)for rr in W4 for x in rr),flush=True)
pairs=sorted({(min(i,j),max(i,j))for rr in data['terms']for i,j,c in rr});ip={p:j for j,p in enumerate(pairs)};F=[[R.zero]*len(pairs)for _ in range(135)]
for row,tr in enumerate(data['terms']):
 for i,j,c in tr:F[row][ip[min(i,j),max(i,j)]]+=c
cor=mul(b['JUP'],[F[i]for i in data['rows']]);C=[[b['d']*x-y for x,y in zip(rr,cc)]for rr,cc in zip(F,cor)];active=[j for j in range(len(pairs))if any(rr[j]for rr in C)];print('effective pairs',len(active),time.time()-st,flush=True)
mm={d:list(combinations_with_replacement(range(11),d))for d in range(1,6)};ix5={m:j for j,m in enumerate(mm[5])}
def poly(f,x):
 f.write(str(len(x))+'\n')
 for ex,c in x.items():f.write(str(c)+' '+' '.join(map(str,ex))+'\n')
p=Path('/tmp/minimal-free-flag-full-fifth-native-input.txt')
with p.open('w')as f:
 f.write('5 45 135 3003\n')
 for d,M in [(1,b['TT']),(2,b['W2']),(3,b['W3']),(4,W4)]:
  f.write(str(len(M[0]))+'\n')
  for rr in M:
   for x in rr:poly(f,x)
 for da,db in [(1,4),(2,3)]:
  for ma in mm[da]:f.write(' '.join(str(ix5[tuple(sorted(ma+mb))])for mb in mm[db])+'\n')
 f.write(str(len(active))+'\n')
 for j in active:
  i,k=pairs[j];rows=[r for r in range(135)if C[r][j]];f.write(f'{i} {k} {len(rows)}\n')
  for r in rows:f.write(str(r)+'\n');poly(f,C[r][j])
print('saved',p.stat().st_size,time.time()-st,flush=True)

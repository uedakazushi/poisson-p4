import json,re
from pathlib import Path
import sympy as s
for k,d in re.findall(r'CORE (\d) DIR (.+)',Path('work/flag-linear-core-fourth.log').read_text()):
 x=json.load(open(Path(d)/'flag-eight-initial4-field.json'));n=s.zeros(217,213);ss=s.symbols(','.join(x['variables']));h=ss.index(s.Symbol('b8'));values=[0,1,2,0,3,5,7,11]
 for label,off in [('rows',0),('corrected_t4',216)]:
  for key,(num,den)in x[label].items():
   i,j=map(int,key.split(','))
   def ev(p):return sum(s.Rational(c)*s.prod(s.Integer(a)**e for a,e in zip(values,m))for m,c in p)
   n[i+off,j]=ev(num)/ev(den)
 print('core',k,'h0 sample rank',len(n[:216,:].to_DM().rref()[1]),'witht',len(n.to_DM().rref()[1]),'nonzero rows',sum(any(n[i,:])for i in range(216)),flush=True)

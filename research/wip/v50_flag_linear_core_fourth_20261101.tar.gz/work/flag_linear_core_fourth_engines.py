from pathlib import Path
p=Path('code/s61_flag_boundary_global_project4_engine_20261101.py').read_text().replace('ROOT=Path(__file__).resolve().parents[1]','ROOT=Path.cwd()')
p=p.replace('G=b8**2','G=s.S.One')
a=p.index('quot=[m for');b=p.index('proj=[]',a)
p=p[:a]+"fr=q['free_radical'];quot=[m for m in ms[4]if sum(i in active for i in m)<=1]+[tuple(sorted((a,b,8,8)))for a,b in cwr(fr,2)];assert len(quot)==213;ix={m:i for i,m in enumerate(quot)};sub={int(k):(v[0],s.sympify(v[1]))for k,v in q['radical_substitutions'].items()}\n"+p[b:]
Path('work/flag_linear_core_project4.py').write_text(p)
p=Path('code/s61_flag_boundary_global_initial4_engine_20261101.py').read_text().replace('ROOT=Path(__file__).resolve().parents[1]','ROOT=Path.cwd()').replace('[1,2,3]',"q['cubic_pivot_radical']").replace('ell=[vn[1]+(r-2)/h*vn[6],vn[2]+4*vn[6],vn[3]+2*vn[6]]',"ell=list(map(s.sympify,q['canonical_cubic_linear']))").replace("projection_multiplier='b8**2'","projection_multiplier='1'")
Path('work/flag_linear_core_initial4.py').write_text(p)
p=Path('code/s61_flag_boundary_global_cover4_engine_20261101.py').read_text().replace('ROOT=Path(__file__).resolve().parents[1]','ROOT=Path.cwd()').replace("P,r=ring('r',s.QQ)","P,r=ring('r',s.QQ)").replace('if k in','if k in')
p=p.replace('for k in [1,2,4,5,6,7]','for k in [0,1,2,4,5,6,7]').replace('a={m[3]for m,c in nn};b={m[3]for m,c in dd}','a={m[0]for m,c in nn};b={m[0]for m,c in dd}').replace('(m[0],):s.QQ(c)','(m[3],):s.QQ(c)').replace('assert len(rows)==21','assert len(rows)>=13').replace(".subs(s.Symbol('b8'),1).subs(s.Symbol('b2'),s.Symbol('r'))", ".subs(s.Symbol('b8'),s.Symbol('r')).subs(s.Symbol('b2'),0)").replace("nonzero_factors=['h']+sorted(factor_set)","nonzero_factors=sorted(factor_set)").replace('pure_core_columns=80','pure_core_columns=len(cw)').replace("factor_variables=['r=b2','h=b8']","factor_variables=['r=b8']")
p='\n'.join(line for line in p.splitlines()if not line.startswith("assert result['nonzero_factors']"))+'\n'
Path('work/flag_linear_core_cover4.py').write_text(p)

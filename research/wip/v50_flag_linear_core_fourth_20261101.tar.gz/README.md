# Three linear frame artifacts: fourth-order exploration (WIP)
The four constant-core polynomial frames were independently reconstructed from
the universal Jacobian and the frozen NORMAL_FORMS pivot lists. Every JT=0 and
block inverse identity passed; tangent coefficients have nuisance degree1.
Core -6,-12/5,-119/20: constant quadratic rank9, cubic new rank3, t in m4.
Their raw four-jets were rebuilt by the native raw135 engine with exact W2/A2
cross-checks. Regular constant quadratic and all-h cubic splittings were found.
All three full fourth candidate ranks are12, with corrected t4 augmented13.
Eight minors at each rank give only h=b8 as a remaining core factor.
At h=0, nuisance values (b4,b7,b9,b10,b11,b13)=(1,2,3,5,7,11) give exact QQ
rank12/13 for all three. A6 x Sp4 has dimension16, so a proper closed failure
set would have beta image at most15; this step needs a formal fresh producer
and written proof before claiming the all-general-beta cover.
The true linear rank-drop core -4/25 has tangent dimension10 and generic
quadratic rank15; its canonical quadratic rows depend on five nuisance values.
No ambient t-nilpotence, saturation removal, or new exhaustion claim is made.

Scripts are scratch research, not a standalone final producer. To reconstruct
the seed in a fresh checkout, run the frozen eight frame/inverse/quadratic
engines into a scratch directory and place its universal-quadratic-cache.pkl
at work/flag-b1-universal-quadratic-cache.pkl. Then run frames.py and the four
quadratic jobs. Raw4 uses the frozen parametric_implicit_jets native source
and eight_raw4 engine; three raw caches are intentionally omitted. The logged
temporary directory paths are historical execution locations, not inputs to a
fresh proof. The next step is a formal shared producer for the first three
cores, including the h=0 finite-minor/general-beta argument.

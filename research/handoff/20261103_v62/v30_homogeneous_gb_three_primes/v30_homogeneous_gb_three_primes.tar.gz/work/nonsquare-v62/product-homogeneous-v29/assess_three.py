from pathlib import Path
import json,gzip,hashlib
w=Path('work/nonsquare-v62/product-homogeneous-v29');primes=[32003,2147483647,2147483629];bases=[];meta=[]
def keyterm(term):
 i,ex,c=term;return(sum(ex),*[-v for v in reversed(ex)],i)
for p in primes:
 d=w/str(p);log=(d/'run.log').read_text();assert'HOMOGENEOUS_GB_NATIVE_SAVED'in log and'ERROR'not in log and'?'not in log;run=json.loads((d/'run.json').read_text());assert run['exit_code']==0
 with(d/'G-native4.txt').open()as f:
  n,m,k=map(int,f.readline().split());assert(n,m,k)==(10,739,0);cols=[[]for _ in range(m)]
  for i in range(n):
   for j in range(m):
    for z in range(int(f.readline())):
     t=f.readline().split();c=int(t[0])%p;ex=tuple(int(v)for v in t[1:]);cols[j].append((i,ex,c))
 B={};tot=0
 for col in cols:
  i,ex,c=max(col,key=keyterm);assert c==1;lm=(*ex,i+1);assert lm not in B
  assert len({sum(e)for ii,e,cc in col})==1
  B[lm]={(ii,*e):cc for ii,e,cc in col};tot+=len(col)
 assert len(B)==739
 sig=hashlib.sha256(repr(sorted(B)).encode()).hexdigest();meta.append(dict(prime=p,runtime=run,terms=tot,nonleading_terms=tot-739,leading_signature=sig))
 bases.append(B)
assert all(set(B)==set(bases[0])for B in bases),'different leading module; no blind CRT'
sets=[{(lm,k)for lm,C in B.items()for k in C if not(k[0]+1==lm[4]and k[1:]==lm[:4])}for B in bases];keys=sorted(set.union(*sets));p0,p1,p2=primes;M2=p0*p1;M3=M2*p2;inv01=pow(p0,-1,p1);inv12=pow(M2,-1,p2);vals=[]
for lm,k in keys:
 c0,c1,c2=[B[lm].get(k,0)for B in bases];r2=c0+p0*((c1-c0)*inv01%p1);r3=r2+M2*((c2-r2)*inv12%p2);vals.append(((lm,k),r2,r3))
with(w/'nonleading-assess3.txt').open('w')as f:
 f.write(f'{len(vals)} {M2} {M3}\n')
 for k,r2,r3 in vals:f.write(f'{r2} {r3}\n')
(w/'canonical-GB-state3.json.gz').write_bytes(gzip.compress(json.dumps(dict(primes=primes,modulus=str(M3),GB_leading_monomials=sorted(bases[0]),nonleading_terms=[[list(lm),list(k),str(r3)]for(lm,k),r2,r3 in vals]),separators=(',',':')).encode(),mtime=0))
report=dict(primes=primes,all_GB_shapes=[10,739],all_monic=True,all_column_homogeneous=True,all_leading_modules_equal=True,states=meta,union_nonleading_coefficient_positions=len(keys),support_missing_by_prime=[len(set(keys)-S)for S in sets],support_extra_relative_small_prime=[len(S-sets[0])for S in sets],CRT_modulus_bits=M3.bit_length(),no_QQ_GB_or_module_equality_claim=True)
(w/'three-prime-assessment.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)

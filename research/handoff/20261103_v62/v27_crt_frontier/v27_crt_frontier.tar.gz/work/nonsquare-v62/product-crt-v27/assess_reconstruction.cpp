#include <flint/fmpq.h>
#include <flint/fmpz.h>
#include <fstream>
#include <iostream>
#include <string>
#include <cassert>
using namespace std;int main(int argc,char**argv){assert(argc==2);ifstream f(argv[1]);long n;string a,b;f>>n>>a>>b;fmpz_t M2,M3,r2,r3;fmpz_init(M2);fmpz_init(M3);fmpz_init(r2);fmpz_init(r3);assert(!fmpz_set_str(M2,a.c_str(),10)&&!fmpz_set_str(M3,b.c_str(),10));fmpq_t q2,q3;fmpq_init(q2);fmpq_init(q3);long ok2=0,ok3=0,stable=0;for(long i=0;i<n;i++){f>>a>>b;assert(!fmpz_set_str(r2,a.c_str(),10)&&!fmpz_set_str(r3,b.c_str(),10));bool s2=fmpq_reconstruct_fmpz(q2,r2,M2),s3=fmpq_reconstruct_fmpz(q3,r3,M3);ok2+=s2;ok3+=s3;stable+=s2&&s3&&fmpq_equal(q2,q3);}cout<<"{\"coefficients\":"<<n<<",\"reconstruct2\":"<<ok2<<",\"reconstruct3\":"<<ok3<<",\"same2and3\":"<<stable<<"}\n";fmpq_clear(q2);fmpq_clear(q3);fmpz_clear(M2);fmpz_clear(M3);fmpz_clear(r2);fmpz_clear(r3);flint_cleanup();}

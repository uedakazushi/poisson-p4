from pathlib import Path
from fractions import Fraction
import json,hashlib,gzip,math
w=Path('work/nonsquare-v62/product-crt-v27');primes=[2147483647,2147483629,2147483587];keys0=None;matrices=[];states=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for p in primes:
 d=w/str(p);run=json.loads((d/'run.json').read_text());assert run['exit_code']==0 and not run['timed_out'];log=(d/'lift.log').read_text();assert 'CRT_EXACT_FRAME_AND_RIGHT_INVERSE_PASS'in log and 'CRT_NATIVE_SAVED'in log
 it=iter((d/'right-inverse-native.txt').read_text().split());n,m,k=[int(next(it))for _ in range(3)];assert(n,m,k)==(53,10,0);co={};maxdeg=0
 for i in range(n):
  for j in range(m):
   for _ in range(int(next(it))):
    c=int(next(it))%p;ex=tuple(int(next(it))for _ in range(3));assert c;co[(i,j,*ex)]=c;maxdeg=max(maxdeg,sum(ex))
 assert next(it,None)is None;keys=sorted(co)
 if keys0 is None:keys0=keys
 trace=''.join(log.split('CRT_TRACE_START',1)[1].split('CRT_TRACE_END',1)[0].split())
 states.append(dict(prime=p,run=run,terms=len(co),degree=maxdeg,support_hash=sha(repr(keys).encode()),trace_hash=sha(trace.encode()),leading_transform_hash=sha((d/'leading-and-transform.txt').read_bytes())))
 matrices.append(co)
assert all(set(M)==set(keys0)for M in matrices),'support differs; do not blindly CRT'
assert len({s['trace_hash']for s in states})==1,'pivot protocol differs'
assert len({s['leading_transform_hash']for s in states})==1,'leading/transform signature differs'
keep=json.loads(Path('work/nonsquare-v62/product-module-v25/source.json').read_text())['retained_columns'];lc=[None]*53;numg=[0]*53;denl=[1]*53
with Path('work/nonsquare-v62/primitive-unit-span-v9/full26.txt').open()as f:
 f.readline();f.readline();f.readline()
 for i in range(10):
  for j in range(60):
   t=f.readline().split();nt=int(t[0])
   if j not in keep:continue
   z=keep.index(j)
   if nt and lc[z]is None:lc[z]=Fraction(t[1])
   for q in range(nt):
    c=Fraction(t[1+4*q]);numg[z]=math.gcd(numg[z],abs(c.numerator));denl[z]=math.lcm(denl[z],c.denominator)
content=[Fraction(a,b)for a,b in zip(numg,denl)]
for basis,scales in [('raw',[Fraction(1)]*53),('column_lc',lc),('column_content',content)]:
 vals=[];mod1,mod2,mod3=primes;M2=mod1*mod2;M3=M2*mod3;inv12=pow(mod1,-1,mod2);inv23=pow(M2,-1,mod3)
 for key in keys0:
  i=key[0];cs=[]
  for p,C in zip(primes,matrices):
   c=scales[i];assert c.denominator%p;cs.append(C[key]*c.numerator*pow(c.denominator,-1,p)%p)
  r2=cs[0]+mod1*((cs[1]-cs[0])*inv12%mod2);r3=r2+M2*((cs[2]-r2)*inv23%mod3);vals.append((key,r2,r3))
 with(w/(basis+'-assess.txt')).open('w')as f:
  f.write(f'{len(vals)} {M2} {M3}\n')
  for key,r2,r3 in vals:f.write(str(r2)+' '+str(r3)+'\n')
 (w/(basis+'-state3.json.gz')).write_bytes(gzip.compress(json.dumps(dict(primes=primes,modulus=str(M3),scales=[str(c)for c in scales],terms=[[list(k),str(r3)]for k,r2,r3 in vals]),separators=(',',':')).encode(),mtime=0))
report=dict(three_primes=primes,all_target_g_exactly='a*P^3*C*J^2*identity10',all_full_frames_and_field_right_inverse_identities=True,same_complete_support=True,same_coefficient_free_GB_protocol=True,same_all_GB_leading_monomials_and_T_leading_degree_size_signatures=True,states=states,QQ_identity_verified=False)
(w/'three-prime-assessment.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

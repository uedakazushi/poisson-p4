import subprocess,resource,time,json,sys,os,signal
from pathlib import Path
p=int(sys.argv[1]);w=Path('work/nonsquare-v62/product-crt-v27')/str(p);t=time.monotonic();cmd=['work/nonsquare-v62/singular-runtime/run-singular-optimized-v6.sh','--cpus=0','-q',str(w/'lift.sing')]
def cap():resource.setrlimit(resource.RLIMIT_AS,(2400000*1024,2400000*1024))
with(w/'lift.log').open('w')as f:
 q=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True);(w/'pid').write_text(str(q.pid)+'\n');timedout=False
 try:q.wait(timeout=120)
 except subprocess.TimeoutExpired:timedout=True;os.killpg(q.pid,signal.SIGKILL);q.wait()
info=dict(prime=p,command=cmd,elapsed_seconds=time.monotonic()-t,exit_code=q.returncode,timed_out=timedout,max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
(w/'run.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True)

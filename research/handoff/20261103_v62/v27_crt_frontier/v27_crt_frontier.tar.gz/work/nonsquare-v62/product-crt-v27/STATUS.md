# CRT frontier (mutable; not a QQ theorem)

The immutable characteristic32003 reduced-residual certificate is now public at
reports/S61_BINARY_NONSQUARE_MODP_PRODUCT_MODULE_20261103_v62. It does NOT assert
originalGF product41 without earlier31-pivot p-unit audit, or QQ product41.

The QQ goal is a complete53×10 polynomial matrix L with
M L=aP³CJ² I10 for the pinned actual QQ31-prefix product residual M10×53.
All100 exact QQ polynomial identities are required before promotion. Combined
with the accepted QQ31 pivots, that identity would prove product41 on adFBCJ.
Full cubic57/quartic/ambient exhaustion remain additional tasks.

Use `prepare_prime.py PRIME`, then `run_prime.py PRIME` under existing activation.
The explicit FIXED constructor is redSB; B=liftstd(M,T), H=lift(B,gI10), L=T*H.
Every prime checks M*T=B and M*L=gI10 exactly, and serializes ALLentries through
ASCII link (do not use write(file,matrix), which writes only the first row).
The old invalidpartial export and metadata-name collision are preserved in the
publicGF packet. FullL32003 is183182terms/degree18 from a different old constructor;
DO NOT CRT it with the new redSB constructor.

Completed3-prime redSB batch:2147483647,2147483629,2147483587. Every L has124942terms,
degree17. Their complete GBprotocols, ALL GBleading mons, and Tleading/degree/size
signatures are byte-identical; all coefficient supports are identical. Each took
28–33seconds and159MBRSS. `three-prime-assessment.json` stores exact hashes.

Three-prime modulus93bits, balancedFarey reconstruction is at random~60.8%coverage
and ZEROcoefficients stable from2→3primes, also after QQcolumnLC or content scaling.
No QQcandidate is available. Existing simpler QQscalar lifts had200–256bit numerators
but small denominators, so balanced reconstruction can need many more bits.
Asymmetric fmpq_reconstruct_fmpz_2 with fixed denominator bounds is worth comparing
on adjacent modulus prefixes; only stable whole candidates plus final QQidentity
checks count. Never CRT arbitrary unrelated right inverses; compare the recorded
whole protocol/leading/transform signatures first. Final QQ identities are decisive.

The bounded extension to8total primes COMPLETED via run_batch8.py, at most
two single-process Singular jobs,120sec/2.4GB cap each (actual~159MB). It stops on
changed protocol/transform signature. `batch8-primes.json` and per-prime run.json
persist state. The measured8-prime assessment again has ZERO stable coefficients7→8 for balanced or asymmetric denominator bounds8…96bits, in all three scalings. Automatic prime extension has STOPPED. Further primes require a new justified method/height assessment, not an
unbounded hundred-prime run. All prime computations are a search/reconstruction
method, not a QQ rank argument.

Other completed mutable frontier: after33-scalar-v26/short-row.m2 (old actual
productrow7,50256terms) has a QQscalar entryideal saturatingunit; first GBgenerator
is aP(125a+3e+2). It is a candidate route to the guaranteed34th unit row (rank37
existence theorem), but no explicit new knownunit cofactor/native34th step is saved.

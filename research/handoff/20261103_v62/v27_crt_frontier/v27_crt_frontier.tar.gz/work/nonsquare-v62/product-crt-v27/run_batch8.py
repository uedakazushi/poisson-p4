import concurrent.futures,subprocess,sys,json,hashlib,threading
from pathlib import Path
from sympy import prevprime
w=Path('work/nonsquare-v62/product-crt-v27');first=json.loads((w/'three-prime-assessment.json').read_text())['states'][0];p=2147483587;primes=[]
for _ in range(5):p=int(prevprime(p));primes.append(p)
(w/'batch8-primes.json').write_text(json.dumps(primes)+'\n');stop=threading.Event()
def run(p):
 if stop.is_set():return None
 subprocess.run([sys.executable,str(w/'prepare_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL)
 subprocess.run([sys.executable,str(w/'run_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL)
 d=w/str(p);r=json.loads((d/'run.json').read_text());assert r['exit_code']==0 and not r['timed_out'];log=(d/'lift.log').read_text();assert'CRT_NATIVE_SAVED'in log and'CRT_EXACT_FRAME_AND_RIGHT_INVERSE_PASS'in log
 trace=''.join(log.split('CRT_TRACE_START',1)[1].split('CRT_TRACE_END',1)[0].split());h=hashlib.sha256(trace.encode()).hexdigest();t=hashlib.sha256((d/'leading-and-transform.txt').read_bytes()).hexdigest()
 if h!=first['trace_hash']or t!=first['leading_transform_hash']:stop.set();raise RuntimeError('pivot/transform strategy changed at '+str(p))
 print(json.dumps(dict(prime=p,elapsed=r['elapsed_seconds'],max_rss_kib=r['max_rss_kib'],same_protocol_and_transform=True)),flush=True);return p
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 result=list(pool.map(run,primes))
(w/'batch8-result.json').write_text(json.dumps(dict(primes=primes,completed=result,QQ_identity_verified=False),indent=2)+'\n')

from pathlib import Path
from fractions import Fraction
import sys,json,hashlib
p=int(sys.argv[1]);w=Path('work/nonsquare-v62/product-crt-v27')/str(p);w.mkdir(exist_ok=True);source=Path('work/nonsquare-v62/primitive-unit-span-v9/full26.txt')
A=[]
with source.open()as f:
 n,m,k=map(int,f.readline().split());assert(n,m,k)==(26,60,1);f.readline();f.readline()
 for i in range(10):
  row=[]
  for j in range(m):
   t=f.readline().split();nt=int(t[0]);assert len(t)==1+4*nt;q={}
   for z in range(nt):
    c=Fraction(t[1+4*z]);ex=tuple(int(v)for v in t[2+4*z:5+4*z]);assert c.denominator%p
    val=c.numerator*pow(c.denominator,-1,p)%p
    if val:q[ex]=val if val<=p//2 else val-p
   row.append(q)
  A.append(row)
keep=json.loads(Path('work/nonsquare-v62/product-module-v25/source.json').read_text())['retained_columns'];assert len(keep)==53
expr=lambda q:'('+(' + '.join(str(c)+''.join('*'+v+('^'+str(k)if k!=1 else '')for v,k in zip(('a','e','d'),ex)if k)for ex,c in q.items())or '0')+')'
with(w/'lift.sing').open('w')as f:
 f.write('ring r='+str(p)+',(a,e,d),dp;matrix Q[10][53];\n')
 for i,row in enumerate(A):
  for z,j in enumerate(keep):
   if row[j]:f.write(f'Q[{i+1},{z+1}]='+expr(row[j])+';\n')
 f.write('module M=Q;poly taskG=a*d^3*(100*a+18*e^2-9*e-2)*(5*d-6*e-4)^2;module N=taskG*freemodule(10);matrix taskT;option(redSB);print("CRT_TRACE_START");option(prot);module taskB=liftstd(M,taskT);option(noprot);print("CRT_TRACE_END");module taskCheck=M*taskT-taskB;if(size(taskCheck)!=0){print("CRT_FRAME_IDENTITY_FAIL");quit;}matrix taskH=lift(taskB,N);matrix taskL=taskT*taskH;taskCheck=M*taskL-N;if(size(taskCheck)!=0){print("CRT_RIGHT_INVERSE_IDENTITY_FAIL");quit;}print("CRT_EXACT_FRAME_AND_RIGHT_INVERSE_PASS");\n')
 f.write('link taskLM="ASCII:w '+str((w/'leading-and-transform.txt').resolve())+'";open(taskLM);int taskI,taskJ;intvec taskEx;for(taskI=1;taskI<=ncols(matrix(taskB));taskI++){write(taskLM,"G "+string(taskI)+" "+string(leadexp(taskB[taskI])));}for(taskI=1;taskI<=nrows(taskT);taskI++){for(taskJ=1;taskJ<=ncols(taskT);taskJ++){if(taskT[taskI,taskJ]!=0){write(taskLM,"T "+string(taskI)+" "+string(taskJ)+" "+string(leadexp(taskT[taskI,taskJ]))+" "+string(deg(taskT[taskI,taskJ]))+" "+string(size(taskT[taskI,taskJ])));}}}close(taskLM);\n')
 f.write('int taskDegree=0;int taskTerms=0;poly taskP;link taskOut="ASCII:w '+str((w/'right-inverse-native.txt').resolve())+'";open(taskOut);write(taskOut,string(nrows(taskL))+" "+string(ncols(taskL))+" 0");for(taskI=1;taskI<=nrows(taskL);taskI++){for(taskJ=1;taskJ<=ncols(taskL);taskJ++){taskP=taskL[taskI,taskJ];taskTerms=taskTerms+size(taskP);if(deg(taskP)>taskDegree){taskDegree=deg(taskP);}write(taskOut,string(size(taskP)));while(taskP!=0){taskEx=leadexp(taskP);write(taskOut,string(leadcoef(taskP))+" "+string(taskEx[1])+" "+string(taskEx[2])+" "+string(taskEx[3]));taskP=taskP-lead(taskP);}}}close(taskOut);print("CRT_RIGHT_INVERSE_TERMS");print(taskTerms);print("CRT_RIGHT_INVERSE_DEGREE");print(taskDegree);print("CRT_NATIVE_SAVED");quit;')
(w/'source.json').write_text(json.dumps(dict(prime=p,source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),retained_columns=keep,target='a*P^3*C*J^2*identity10',constructor='option(redSB); B=liftstd(M,T); H=lift(B,N); L=T*H',QQ_claim=False),indent=2)+'\n');print('PREPARED',p,flush=True)

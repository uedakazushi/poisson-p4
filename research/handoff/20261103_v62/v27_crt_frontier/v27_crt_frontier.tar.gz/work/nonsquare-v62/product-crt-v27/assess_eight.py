from pathlib import Path
import json,gzip,hashlib
w=Path('work/nonsquare-v62/product-crt-v27');primes=[2147483647,2147483629,2147483587]+json.loads((w/'batch8-primes.json').read_text());base=json.loads((w/'three-prime-assessment.json').read_text())['states'][0]
for basis in ['raw','column_lc','column_content']:
 old=json.loads(gzip.decompress((w/(basis+'-state3.json.gz')).read_bytes()));keys=[tuple(k)for k,v in old['terms']];R=[int(v)for k,v in old['terms']];mod=int(old['modulus']);scales=old['scales'];states=[];R7=None;mod7=None
 from fractions import Fraction
 scales=list(map(Fraction,scales))
 for p in primes[3:]:
  d=w/str(p);log=(d/'lift.log').read_text();trace=''.join(log.split('CRT_TRACE_START',1)[1].split('CRT_TRACE_END',1)[0].split());assert hashlib.sha256(trace.encode()).hexdigest()==base['trace_hash'];assert hashlib.sha256((d/'leading-and-transform.txt').read_bytes()).hexdigest()==base['leading_transform_hash']
  it=iter((d/'right-inverse-native.txt').read_text().split());n,m,k=[int(next(it))for _ in range(3)];assert(n,m,k)==(53,10,0);C={}
  for i in range(n):
   c=scales[i];assert c.denominator%p;s=c.numerator*pow(c.denominator,-1,p)%p
   for j in range(m):
    for _ in range(int(next(it))):
     v=int(next(it))%p;ex=tuple(int(next(it))for _ in range(3));C[(i,j,*ex)]=v*s%p
  assert set(C)==set(keys);inv=pow(mod,-1,p);R=[v+mod*((C[key]-v)*inv%p)for key,v in zip(keys,R)];mod*=p
  if p==primes[-2]:R7=R.copy();mod7=mod
 assert R7 is not None
 with(w/(basis+'-assess8.txt')).open('w')as f:
  f.write(f'{len(keys)} {mod7} {mod}\n')
  for a,b in zip(R7,R):f.write(f'{a} {b}\n')
 (w/(basis+'-state8.json.gz')).write_bytes(gzip.compress(json.dumps(dict(primes=primes,modulus=str(mod),scales=[str(c)for c in scales],terms=[[list(k),str(v)]for k,v in zip(keys,R)]),separators=(',',':')).encode(),mtime=0))
 print('CRT8_STATE',basis,mod.bit_length(),len(keys),flush=True)

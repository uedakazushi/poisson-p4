// Exact polynomial unit pivots, including constant column/row span search.
// Args: input output unit-polynomial-file has-metadata(0/1) [transpose] [colclean] [witness-file target-row].
// Witness: column-count, then one sparse polynomial per column in the same 3-variable format.
// target-row is zero-based AFTER the optional transpose. The exact resulting entry must be a unit.
// Three variables are a,e,d. Input: n m metadata_count, optional metadata_count+n
// integer labels, then n*m sparse polynomials: term_count,(coefficient,aexp,eexp,dexp)*.
// Units are one or more nonconstant polynomials inverted on the intended open set.
// Only nonzero QQ constants and these units are inverted. Added span pivots use
// invertible constant row/column operations, verified by exact target equality.
// Output preserves the sparse format with metadata (pivot columns, remaining rows).
// A partial pivot count is NOT a full-rank certificate. Call under a time limit.
#include <flint/fmpq.h>
#include <flint/fmpq_mat.h>
#include <map>
#include <functional>
#include <array>
#include <flint/fmpq_mpoly.h>
#include <flint/fmpq_mpoly_factor.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <cassert>
#include <chrono>
#include <algorithm>
using namespace std;fmpq_mpoly_ctx_t ctx;
struct Poly{fmpq_mpoly_t p;Poly(){fmpq_mpoly_init(p,ctx);}Poly(const Poly&a):Poly(){fmpq_mpoly_set(p,a.p,ctx);}Poly(Poly&&a):Poly(){fmpq_mpoly_swap(p,a.p,ctx);}Poly&operator=(Poly a){fmpq_mpoly_swap(p,a.p,ctx);return *this;}~Poly(){fmpq_mpoly_clear(p,ctx);}};
void write(ostream&o,const Poly&a){fmpq_t q;fmpq_init(q);ulong ex[3];int n=fmpq_mpoly_length(a.p,ctx);o<<n;for(int i=0;i<n;i++){fmpq_mpoly_get_term_coeff_fmpq(q,a.p,i,ctx);fmpq_mpoly_get_term_exp_ui(ex,a.p,i,ctx);char*s=fmpq_get_str(nullptr,10,q);o<<' '<<s;for(ulong x:ex)o<<' '<<x;flint_free(s);}o<<'\n';fmpq_clear(q);}


vector<Poly> known;vector<Poly>primitiveWitness,primitiveTarget;
bool unit(Poly p){if(fmpq_mpoly_is_zero(p.p,ctx))return false;Poly q;for(auto&f:known)while(fmpq_mpoly_divides(q.p,p.p,f.p,ctx))p=q;return fmpq_mpoly_is_fmpq(p.p,ctx);}
void clean(vector<Poly>&row){int first=-1;for(int j=0;j<(int)row.size();j++)if(!fmpq_mpoly_is_zero(row[j].p,ctx)){first=j;break;}if(first<0)return;fmpq_t c;fmpq_init(c);fmpq_mpoly_get_term_coeff_fmpq(c,row[first].p,0,ctx);for(auto&p:row)fmpq_mpoly_scalar_div_fmpq(p.p,p.p,c,ctx);fmpq_clear(c);vector<Poly> quot(row.size());for(auto&f:known)while(true){bool yes=true;for(int j=first;j<(int)row.size();j++)if(!fmpq_mpoly_divides(quot[j].p,row[j].p,f.p,ctx)){yes=false;break;}if(!yes)break;row=quot;}}

bool combo(vector<vector<Poly>>&A,int k,const vector<int>&used,int &bi,int &bj){
 int n=A.size(),m=A[0].size();vector<int> cols;for(int j=0;j<m;j++)if(find(used.begin(),used.end(),j)==used.end())cols.push_back(j);
 vector<Poly>targets;Poly one;fmpq_mpoly_one(one.p,ctx);targets.push_back(one);

 function<void(int,int,const Poly&)>extend=[&](int pos,int left,const Poly&prod){
  if(pos==(int)known.size()-1){Poly v=prod,tmp;for(int e=0;e<left;e++){fmpq_mpoly_mul(tmp.p,v.p,known[pos].p,ctx);v=tmp;}targets.push_back(v);return;}
  Poly v=prod,tmp;for(int e=0;e<=left;e++){extend(pos+1,left-e,v);fmpq_mpoly_mul(tmp.p,v.p,known[pos].p,ctx);v=tmp;}
 };
 for(int deg=1;deg<=3;deg++)extend(0,deg,one);

 for(int i=k;i<n;i++){
  map<array<ulong,3>,int>mons;ulong ex[3];
  auto collect=[&](const Poly&p){for(int t=0;t<fmpq_mpoly_length(p.p,ctx);t++){fmpq_mpoly_get_term_exp_ui(ex,p.p,t,ctx);array<ulong,3>key={ex[0],ex[1],ex[2]};if(!mons.count(key))mons[key]=mons.size();}};
  for(int j:cols)collect(A[i][j]);for(auto&t:targets)collect(t);
  int nc=cols.size(),nt=targets.size(),nr=mons.size();fmpq_mat_t M,E;fmpq_mat_init(M,nr,nc+nt);fmpq_mat_init(E,nr,nc+nt);fmpq_t q;fmpq_init(q);
  auto put=[&](const Poly&p,int c){for(int t=0;t<fmpq_mpoly_length(p.p,ctx);t++){fmpq_mpoly_get_term_exp_ui(ex,p.p,t,ctx);fmpq_mpoly_get_term_coeff_fmpq(q,p.p,t,ctx);array<ulong,3>key={ex[0],ex[1],ex[2]};fmpq_set(fmpq_mat_entry(M,mons.at(key),c),q);}};
  for(int j=0;j<nc;j++)put(A[i][cols[j]],j);for(int j=0;j<nt;j++)put(targets[j],nc+j);
  fmpq_mat_rref(E,M);vector<int> pivots;
  for(int r=0;r<nr;r++){int c=0;for(;c<nc;c++)if(!fmpq_is_zero(fmpq_mat_entry(E,r,c)))break;if(c==nc)break;pivots.push_back(c);}
  int rr=pivots.size();int found=-1;
  for(int j=0;j<nt;j++){bool yes=true;for(int r=rr;r<nr;r++)if(!fmpq_is_zero(fmpq_mat_entry(E,r,nc+j))){yes=false;break;}if(yes){found=j;break;}}
  if(found>=0){primitiveWitness=vector<Poly>(m);primitiveTarget.clear();primitiveTarget.push_back(targets[found]);for(int r=0;r<rr;r++){auto c=fmpq_mat_entry(E,r,nc+found);fmpq_mpoly_set_fmpq(primitiveWitness[cols[pivots[r]]].p,c,ctx);}int pivot=-1;for(int r=0;r<rr;r++)if(!fmpq_is_zero(fmpq_mat_entry(E,r,nc+found))){pivot=r;break;}assert(pivot>=0);bj=cols[pivots[pivot]];bi=i;
   vector<Poly>newcol(n);Poly tmp;for(int r=0;r<rr;r++){auto c=fmpq_mat_entry(E,r,nc+found);if(fmpq_is_zero(c))continue;for(int l=0;l<n;l++){fmpq_mpoly_scalar_mul_fmpq(tmp.p,A[l][cols[pivots[r]]].p,c,ctx);fmpq_mpoly_add(newcol[l].p,newcol[l].p,tmp.p,ctx);}}
   assert(fmpq_mpoly_equal(newcol[i].p,targets[found].p,ctx));for(int l=0;l<n;l++)A[l][bj]=newcol[l];cerr<<"COMBO row "<<i<<" rank "<<rr<<" target "<<found<<" col "<<bj<<"\n";
   fmpq_clear(q);fmpq_mat_clear(M);fmpq_mat_clear(E);return true;
  }
  cerr<<"NO_COMBO row "<<i<<" rank "<<rr<<" mons "<<nr<<"\n";fmpq_clear(q);fmpq_mat_clear(M);fmpq_mat_clear(E);
 }
 return false;
}


void rd(istream&in,Poly&p){int nt;in>>nt;assert(in&&nt>=0);fmpq_t q;fmpq_init(q);ulong ex[3];for(int t=0;t<nt;t++){string c;in>>c>>ex[0]>>ex[1]>>ex[2];assert(in&&!fmpq_set_str(q,c.c_str(),10));fmpq_canonicalise(q);fmpq_mpoly_push_term_fmpq_ui(p.p,q,ex,ctx);}fmpq_mpoly_sort_terms(p.p,ctx);fmpq_mpoly_combine_like_terms(p.p,ctx);fmpq_clear(q);}
int main(int argc,char**argv){assert(argc==6);fmpq_mpoly_ctx_init(ctx,3,ORD_LEX);{ifstream in(argv[1]),uf(argv[2]);int n,m,k;in>>n>>m>>k;int metadata=stoi(argv[3]),target=stoi(argv[4]);assert(target>=0&&target<n);if(metadata){int discard;for(int z=0;z<k+n;z++)in>>discard;}else assert(metadata==0);const char*names[]={"a","e","d"};string text;while(getline(uf,text)){if(text.empty())continue;Poly q;assert(!fmpq_mpoly_set_str_pretty(q.p,text.c_str(),names,ctx));assert(!fmpq_mpoly_is_fmpq(q.p,ctx));known.push_back(q);}assert(!known.empty());vector<Poly>original(m);for(int i=0;i<n;i++)for(int j=0;j<m;j++){Poly q;rd(in,q);if(i==target)original[j]=q;}
vector<vector<int>>val(m,vector<int>(known.size()));vector<vector<Poly>>primitive(1,original);Poly quotient;for(int j=0;j<m;j++){if(fmpq_mpoly_is_zero(primitive[0][j].p,ctx))continue;for(int t=0;t<(int)known.size();t++)while(fmpq_mpoly_divides(quotient.p,primitive[0][j].p,known[t].p,ctx)){primitive[0][j]=quotient;val[j][t]++;}}
vector<int>empty;int bi,bj;if(!combo(primitive,0,empty,bi,bj)){cerr<<"NO_LOCALIZED_CONSTANT_SPAN_WITNESS\n";return 2;}assert(primitiveWitness.size()==(size_t)m&&primitiveTarget.size()==1);vector<int>maxval(known.size());for(int j=0;j<m;j++)if(!fmpq_mpoly_is_zero(primitiveWitness[j].p,ctx))for(int t=0;t<(int)known.size();t++)maxval[t]=max(maxval[t],val[j][t]);
Poly common,tmp,sum,expected;fmpq_mpoly_one(common.p,ctx);for(int t=0;t<(int)known.size();t++)for(int h=0;h<maxval[t];h++){fmpq_mpoly_mul(tmp.p,common.p,known[t].p,ctx);common=tmp;}vector<Poly>lift(m);long terms=0,degree=0;int active=0;for(int j=0;j<m;j++){if(fmpq_mpoly_is_zero(primitiveWitness[j].p,ctx))continue;lift[j]=primitiveWitness[j];for(int t=0;t<(int)known.size();t++)for(int h=val[j][t];h<maxval[t];h++){fmpq_mpoly_mul(tmp.p,lift[j].p,known[t].p,ctx);lift[j]=tmp;}fmpq_mpoly_mul(tmp.p,original[j].p,lift[j].p,ctx);fmpq_mpoly_add(sum.p,sum.p,tmp.p,ctx);terms+=fmpq_mpoly_length(lift[j].p,ctx);degree=max(degree,fmpq_mpoly_total_degree_si(lift[j].p,ctx));active++;}
fmpq_mpoly_mul(expected.p,common.p,primitiveTarget[0].p,ctx);assert(fmpq_mpoly_equal(sum.p,expected.p,ctx)&&unit(expected));ofstream out(argv[5]);out<<m<<'\n';for(auto&p:lift)write(out,p);cerr<<"EXACT_KNOWN_UNIT_DENOMINATOR_LIFT_PASS ROW "<<target<<" ACTIVE "<<active<<" TERMS "<<terms<<" DEGREE "<<degree<<" COMMON_DEGREE "<<fmpq_mpoly_total_degree_si(common.p,ctx)<<"\n";primitiveWitness.clear();primitiveTarget.clear();known.clear();}fmpq_mpoly_ctx_clear(ctx);flint_cleanup();}

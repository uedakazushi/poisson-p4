from pathlib import Path
from fractions import Fraction
import json,hashlib,tarfile,time
w=Path('work/nonsquare-v62/primitive-unit-span-v9');b=Path('research/handoff/20261103_v62/v9_short_unit_pivots');assert not(b/'manifest.json').exists()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  while s:=f.read(1048576):h.update(s)
 return h.hexdigest()
def poly(s):
 z=s.split();nt=int(z[0]);assert len(z)==1+4*nt;return{tuple(map(int,z[2+4*k:5+4*k])):Fraction(z[1+4*k])for k in range(nt)}
def enc(p):return str(len(p))+''.join(' '+str(c)+' '+' '.join(map(str,m))for m,c in sorted(p.items(),reverse=True))+'\n'
def add(a,b):
 a=a.copy()
 for m,c in b.items():
  a[m]=a.get(m,0)+c
  if not a[m]:del a[m]
 return a
def scale(a,c):return{m:v*c for m,v in a.items()if v*c}
def mul(a,b):
 r={}
 for m,c in a.items():
  for n,d in b.items():
   k=tuple(x+y for x,y in zip(m,n));r[k]=r.get(k,0)+c*d
 return{k:v for k,v in r.items()if v}
def divide(a,b):
 a=a.copy();q={};lm=max(b);lc=b[lm]
 while a:
  m=max(a)
  if any(x<y for x,y in zip(m,lm)):return None
  ex=tuple(x-y for x,y in zip(m,lm));c=a[m]/lc;q[ex]=q.get(ex,0)+c;a=add(a,scale({tuple(x+y for x,y in zip(ex,n)):v for n,v in b.items()},-c))
 return q
def projection(src,dst,row,metadata):
 f=Path(src).open();n,m,k=map(int,f.readline().split())
 if metadata:f.readline();f.readline()
 target=None
 for i in range(n):
  lines=[f.readline()for j in range(m)]
  if i==row:target=lines
 assert target is not None;Path(dst).write_text('1 '+str(m)+' 1\n'+''.join(target));return[poly(s)for s in target]
def witness(p):
 f=Path(p).open();n=int(f.readline());return[poly(f.readline())for j in range(n)]
a={(1,0,0):Fraction(1)};e={(0,1,0):Fraction(1)};d={(0,0,1):Fraction(1)};one={(0,0,0):Fraction(1)}
F=add(add(scale(a,500),scale(mul(e,e),90)),add(scale(e,3),scale(one,-24)));C=add(add(scale(a,100),scale(mul(e,e),18)),add(scale(e,-9),scale(one,-2)));Jold=add(scale(mul(a,d),5),add(scale(e,-6),scale(one,-4)));Jnew=add(scale(d,5),add(scale(e,-6),scale(one,-4)));B=add(mul(add(add(scale(a,50),scale(mul(e,e),18)),add(scale(e,-9),scale(one,-2))),d),add(scale(e,60),scale(one,-40)));Bnew=add(mul(add(add(scale(a,50),scale(mul(e,e),18)),add(scale(e,-9),scale(one,-2))),d),mul(add(scale(e,60),scale(one,-40)),a))
main=Path('work/nonsquare-v62/cubic27-v6/P-clean27');v6=Path('research/handoff/20261103_v62/v6_cubic27_coker/manifest.json');v6r=json.loads(v6.read_text());expected=next(x['sha256']for x in v6r['omitted_large_generated_files']if x['path']==str(main));assert sha(main)==expected
cases=[]
for tag,src,row,meta,wp,unitlist,expected_shape,terms,outpath in [('product',Path('work/nonsquare-product-alt-v62/mod-ell/chart-3-ad-residual.txt'),10,True,w/'product-row10.witness',[a,F,B,C,Jold,d],[13,45],44143,w/'product-after-row10.txt'),('main',main,4,False,w/'full27-row4.witness',[a,F,Bnew,C,Jnew,d],[26,60],1290701,w/'full26.txt')]:
 ps=projection(src,w/(tag+'-target-row.txt'),row,meta);cs=witness(wp);assert len(ps)==len(cs);s={}
 for p,c in zip(ps,cs):s=add(s,mul(p,c))
 exponents=[];rest=s
 for u in unitlist:
  count=0
  while (q:=divide(rest,u))is not None:rest=q;count+=1
  exponents.append(count)
 assert len(rest)==1 and (0,0,0)in rest and rest[(0,0,0)]!=0
 if tag=='main':assert s==mul(C,Jnew)
 with outpath.open()as f:header=list(map(int,f.readline().split()))
 assert header[:2]==expected_shape
 cases.append(dict(case=tag,source=str(src),source_sha256=sha(src),target_row=row,witness_sha256=sha(wp),witness_nonzero_components=[(j,enc(c).strip())for j,c in enumerate(cs)if c],target_unit_scalar=str(rest[(0,0,0)]),target_unit_exponents=exponents,target_unit_sparse=enc(s).strip(),known_unit_order=['a','F','B_or_B0','C','J','d_or_P'],independent_Fraction_identity_passed=True,residual_shape=expected_shape,residual_terms=terms,residual_sha256=sha(outpath),residual_bytes=outpath.stat().st_size,operation='invertible column replacement followed by one known-unit pivot'))
status=dict(frozen=True,all_passed=True,mathematical_scope='Two exact constant unit witnesses and rank-preserving one-pivot reductions only',localization='a*d*F*B*C*J!=0; main chart uses P=ad and B0=aB',cases=cases,main_total_constructive_unit_pivots=31,product_mod_ell_total_unit_pivots=11,all_point_rank57=False,all_point_product_rank41=False,quartic_or_ambient_exhaustion=False,live_solver_owned_by_this_agent=False,dependencies={str(v6):sha(v6),'reports/S61_BINARY_NONSQUARE_PRODUCT_ALT_20261103_v62/report.json':sha('reports/S61_BINARY_NONSQUARE_PRODUCT_ALT_20261103_v62/report.json')})
(b/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
files=[w/x for x in ['primitive-unit-span.cpp','primitive-unit-span-optimized.cpp','optimized-span-fragment.cpp','fixture.txt','fixture-units.txt','fixture.witness','fixture.log','product-row10.witness','product-row10.log','product-after-row10.log','full27-row4.witness','full27-row4.log','full26.log','product-target-row.txt','main-target-row.txt','freeze-v9.py']];files += [Path('work/nonsquare-product-alt-v62/mod-ell/chart-3-ad-residual.txt'),Path('work/nonsquare-product-alt-v62/mod-ell/chart-3-ad-units.txt'),Path('work/nonsquare-v62/cubic27-v6/P-units'),Path('work/nonsquare-v62/product-field-v7/witness-image-stats.cpp')];files=sorted(set(files));archive=b/'v9_short_unit_pivots.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for p in files:t.add(p,arcname=str(p),recursive=False)
manifest=dict(frozen=True,created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),members=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in files],archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),omitted_large_generated_files=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in [main,w/'product-after-row10.txt',w/'full26.txt']],status_sha256=sha(b/'STATUS.json'))
(b/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(status['cases'],indent=2));print(json.dumps(manifest['archive']))

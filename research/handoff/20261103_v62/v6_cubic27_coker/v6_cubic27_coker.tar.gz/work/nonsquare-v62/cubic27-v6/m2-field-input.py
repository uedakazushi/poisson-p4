from pathlib import Path
import sys,json,hashlib
wd=Path('work/nonsquare-v62/cubic27-v6');src=wd/'P-clean27';field=sys.argv[1];char=sys.argv[2];field_index={'a':0,'e':1,'P':2}[field];names=['a','e','P'];active=[x for x in range(3)if x!=field_index];tag=f'generic-{field}-{char}';datafile=wd/(tag+'.data.m2');runfile=wd/(tag+'.run.m2');invfile=(wd/(tag+'.right-inverse.m2')).resolve();gbfile=(wd/(tag+'.gb.txt')).resolve();annfile=(wd/(tag+'.ann.txt')).resolve();prime=None if char=='QQ'else int(char)
with src.open()as inp,datafile.open('w')as out:
 n,m,target=map(int,inp.readline().split());assert n==27 and m==61 and target==27
 out.write(f'C027={"QQ"if prime is None else"GF("+str(prime)+")"}[{field}];K27=frac C027;R=K27[{",".join(names[i]for i in active)},z];{field}=promote(C027_0,K27);\nMM27=mutableMatrix(R,{n},{m+n});\n')
 for i in range(n):
  for j in range(m):
   z=inp.readline().split();nt=int(z[0]);groups={}
   for k in range(nt):
    c=z[1+4*k];assert '/'not in c;ex=list(map(int,z[2+4*k:5+4*k]))
    if prime:
     v=int(c)%prime
     if not v:continue
     if v>prime//2:v-=prime
     c=str(v)
    key=tuple(ex[h]for h in active);groups.setdefault(key,[]).append((ex[field_index],c))
   terms=[]
   for key,coeff in sorted(groups.items(),reverse=True):
    inner='+'.join('('+c+')'+(''if exp==0 else'*'+field+(''if exp==1 else'^'+str(exp)))for exp,c in coeff)
    outer=''.join('*'+names[h]+(''if ex==1 else'^'+str(ex))for h,ex in zip(active,key)if ex)
    terms.append('('+inner+')'+outer)
   if terms:out.write(f'MM27_({i},{j})='+ '+'.join(terms)+';\n')
  print('GENERATED_ROW',field,char,i,flush=True)
 out.write('U27=a*(500*a+90*e^2+3*e-24)*((50*a+18*e^2-9*e-2)*P+(60*e-40)*a)*(100*a+18*e^2-9*e-2)*(5*P-6*e-4)*P;\n')
 for i in range(n):out.write(f'MM27_({i},{m+i})=z*U27-1;\n')
 out.write(f'M27=matrix MM27;MM27=null;print "FUNCTION_FIELD_INPUT_READY_{field}_{char}";<<flush;\n')
script=f'''load "{datafile.resolve()}";
G27=gb(M27,ChangeMatrix=>true);N27=gens G27;E27=id_(target M27);
unit27=all(flatten entries(E27%G27),x->x==0_R);
print("FUNCTION_FIELD_GB_DONE_{field}_{char}",numColumns N27,unit27);<<flush;
outGB27=openOut "{gbfile}";outGB27<<toExternalString N27<<endl;close outGB27;
if unit27 then (
    X27=(getChangeMatrix G27)*(E27//N27);
    out27=openOut "{invfile}";
    out27<<"Xproof27=mutableMatrix(R,"<<numRows X27<<","<<numColumns X27<<");"<<endl;
    scan(numRows X27,i->scan(numColumns X27,j->if X27_(i,j)!=0_R then(out27<<"Xproof27_("<<i<<","<<j<<")="<<toExternalString X27_(i,j)<<";"<<endl)));
    out27<<"Xproof27=matrix Xproof27;assert(M27*Xproof27==id_(target M27));print \\\"RIGHT_INVERSE_REPLAY_PASS\\\";"<<endl;
    close out27;
    print "FUNCTION_FIELD_INVERSE_CANDIDATE_SAVED_{field}_{char}";<<flush;
    assert(M27*X27==E27);
    print "EXACT_FUNCTION_FIELD_COKER_ZERO_{field}_{char}";<<flush;
) else (
    A27=ann coker M27;
    print("FUNCTION_FIELD_ANN_DIM_{field}_{char}",dim(R/A27));<<flush;
    if dim(R/A27)==0 then(print("FUNCTION_FIELD_ANN_LENGTH",numColumns basis(R/A27));<<flush;);
    outAnn27=openOut "{annfile}";outAnn27<<toExternalString gens gb A27<<endl;close outAnn27;
);
'''
# M2's output string needs actual escaped quotes, not literal backslashes in the generated proof.
script=script.replace('\\\\\\"','\\"')
runfile.write_text(script)
(wd/(tag+'.verify.m2')).write_text(f'load "{datafile.resolve()}";load "{invfile}";\n')
(wd/(tag+'.input.json')).write_text(json.dumps(dict(coefficient_field='QQ('+field+')'if prime is None else'GF('+char+')('+field+')',active_core_variables=[names[i]for i in active],localization_variable='z',matrix_shape=[n,m],augmented_shape=[n,m+n],source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),data_sha256=hashlib.sha256(datafile.read_bytes()).hexdigest(),script_sha256=hashlib.sha256(runfile.read_bytes()).hexdigest(),data_bytes=datafile.stat().st_size,change_matrix=True),indent=2)+'\n');print('FIELD_INPUT_DONE',tag,datafile.stat().st_size,flush=True)

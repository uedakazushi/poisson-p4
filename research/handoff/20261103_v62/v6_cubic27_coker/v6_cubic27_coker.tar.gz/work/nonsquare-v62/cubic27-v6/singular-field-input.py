from pathlib import Path
import re,json,hashlib
w=Path('work/nonsquare-v62/cubic27-v6');src=w/'generic-e-QQ.data.m2';dst=w/'generic-e-QQ-liftstd.sing'
with src.open()as inp,dst.open('w')as out:
 out.write('ring R=(0,e),(a,P,z),dp;\nmatrix M[27][88];\n')
 for line in inp:
  if line.startswith('MM27_('):
   z=re.fullmatch(r'MM27_\((\d+),(\d+)\)=(.*);\n',line);assert z
   out.write(f'M[{int(z[1])+1},{int(z[2])+1}]={z[3]};\n')
  elif line.startswith('U27='):out.write('poly '+line)
 out.write('''module I=M;
print("FUNCTION_FIELD_INPUT_READY_e_QQ_SINGULAR");
matrix T;
module G=liftstd(I,T);
print("FUNCTION_FIELD_GB_DONE_e_QQ_SINGULAR");
matrix E[27][27];
for(int i=1;i<=27;i++){E[i,i]=1;}
module EE=E;
module red=reduce(EE,G);
if(size(red)==0){
 matrix Q=lift(G,EE);
 matrix X=T*Q;
 if(M*X!=E){ERROR("exact right inverse failed");}
 write("'''+str((w/'generic-e-QQ-liftstd.right-inverse.sing').resolve())+'''",X);
 print("EXACT_FUNCTION_FIELD_COKER_ZERO_e_QQ_SINGULAR");
}else{
 print("FUNCTION_FIELD_COKER_NONZERO_e_QQ_SINGULAR");
 print(size(red));
}
quit;
''')
(w/'generic-e-QQ-liftstd.input.json').write_text(json.dumps(dict(source_m2_input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),singular_input_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),bytes=dst.stat().st_size,coefficient_field='QQ(e)',ring_variables=['a','P','z'],algorithm='liftstd with exact right-inverse identity required'),indent=2)+'\n')

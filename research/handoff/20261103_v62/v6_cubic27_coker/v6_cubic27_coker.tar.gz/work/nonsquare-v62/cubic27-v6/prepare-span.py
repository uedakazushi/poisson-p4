from pathlib import Path
import json
wd=Path('work/nonsquare-v62/cubic27-v6')
def read(p):
 f=Path(p).open();n,m,k=map(int,f.readline().split());cols=list(map(int,f.readline().split()));ids=list(map(int,f.readline().split()));assert len(cols)==k and len(ids)==n;rows={i:[f.readline()for _ in range(m)]for i in ids};return n,m,k,cols,ids,rows
n,m,k,cols,ids,rows=read(wd/'after21');on,om,ok,oc,oi,orr=read('work/nonsquare-v62/fresh-cubic/schur');assert(n,m,k)==(36,70,21)and cols==oc
for i in ids:assert rows[i]==orr[i],i
order=[i for i in oi if i in rows]
with (wd/'after21-ordered').open('w')as f:
 f.write(f'{n} {m} {k}\n'+' '.join(map(str,cols))+'\n'+' '.join(map(str,order))+'\n')
 for i in order:f.writelines(rows[i])
(wd/'phase21-check.json').write_text(json.dumps(dict(all_passed=True,shape=[n,m],known_unit_pivots=k,all_36_retained_rows_byte_identical_to_current_pinned_Schur=True,remaining_original_rows=order,used_original_columns=cols),indent=2)+'\n')
s=Path('code/polynomial_unit_span_pivots_20261103_v62.cpp').read_text().replace('vector<Poly> known;','vector<Poly> known;int forcedRowIndex=-1;')
a=s.index('bool combo(');b=s.index('bool combo_rows(');s=s[:a]+s[a:b].replace('for(int i=k;i<n;i++){','for(int i=forcedRowIndex;i<forcedRowIndex+1;i++){')+s[b:]
s=s.replace('if(string(argv[4])=="1"){int discard;for(int l=0;l<r+n;l++)in>>discard;}else assert(string(argv[4])=="0");','vector<int>inputOrigin(n);if(string(argv[4])=="1"){int discard;for(int l=0;l<r;l++)in>>discard;for(int&i:inputOrigin)in>>i;}else{assert(string(argv[4])=="0");for(int i=0;i<n;i++)inputOrigin[i]=i;}')
a=s.index('bool do_column_clean=false;');b=s.index('auto start=chrono',a)
s=s[:a]+'bool do_column_clean=false;for(auto&row:A)clean(row);vector<int>used;vector<int>origin=inputOrigin;assert(argc==6);ifstream forced(argv[5]);int steps;forced>>steps;assert(steps==8);vector<int>forceRow(steps),forceCol(steps);for(int i=0;i<steps;i++)forced>>forceRow[i]>>forceCol[i];'+s[b:]
a=s.index('for(;k<n;k++){int bi=');b=s.index('swap(A[k],A[bi]);',a)
s=s[:a]+'for(;k<steps;k++){int bi=find(origin.begin()+k,origin.end(),forceRow[k])-origin.begin();assert(bi<n);forcedRowIndex=bi;int bj=-1;assert(combo(A,k,used,bi,bj));assert(bj==forceCol[k]);'+s[b:]
(wd/'forced-span.cpp').write_text(s)
print('PHASE21_BYTE_EQUALITY_PASS',n,m)

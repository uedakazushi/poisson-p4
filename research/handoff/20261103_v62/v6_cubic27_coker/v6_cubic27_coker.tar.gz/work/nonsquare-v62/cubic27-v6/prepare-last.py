from pathlib import Path
import json,hashlib
wd=Path('work/nonsquare-v62/cubic27-v6')
def matrix(p):
 f=Path(p).open();n,m,k=map(int,f.readline().split());cols=list(map(int,f.readline().split()));ids=list(map(int,f.readline().split()));assert len(cols)==k and len(ids)==n;rows={i:[f.readline()for _ in range(m)]for i in ids};return n,m,k,cols,ids,rows
n,m,k,cols,ids,rows=matrix(wd/'after29');on,om,ok,oc,oi,old=matrix('work/nonsquare-v62/fresh-cubic/unit-span-schur');oldSchur=matrix('work/nonsquare-v62/fresh-cubic/schur')[4];oldGlobal=[oldSchur[i]for i in oi];oldRows={g:old[i]for g,i in zip(oldGlobal,oi)};assert(n,m,k)==(28,62,8)and cols==oc
for i in ids:assert rows[i]==oldRows[i],i
order=[i for i in oldGlobal if i in rows]
with (wd/'after29-ordered').open('w')as f:
 f.write(f'{n} {m} {k}\n'+' '.join(map(str,cols))+'\n'+' '.join(map(str,order))+'\n')
 for i in order:f.writelines(rows[i])
z=Path('work/nonsquare-v62/fresh-cubic/short-row-degree1.witness').read_text().split();at=1;count=int(z[0]);assert count==m;w=[]
for j in range(m):
 nt=int(z[at]);at+=1;w.append([z[at+4*t:at+4*t+4]for t in range(nt)]);at+=4*nt
candidate=[]
for j in range(m):
 if w[j]or int(rows[23][j].split()[0])!=0:continue
 cost=sum(int(rows[i][j].split()[0])for i in ids);nz=sum(int(rows[i][j].split()[0])>0 for i in ids);candidate.append((cost,nz,j))
assert candidate;cost,nz,j=min(candidate);w[j]=[['1','0','0','0']]
with (wd/'replacement-witness').open('w')as f:
 f.write(str(m)+'\n')
 for terms in w:
  f.write(str(len(terms))+'\n')
  for t in terms:f.write(' '.join(t)+'\n')
meta=dict(all_passed=True,after29_shape=[n,m],all28retained_rows_byte_equal_to_pinned_34rowmatrix=True,target_original_row=23,target_current_row=order.index(23),replace_column=j,replaced_column_total_terms=cost,replaced_column_nonzero_rows=nz,original_witness_coefficient_at_replacement_zero=True,target_matrix_entry_at_replacement_zero=True,new_witness_coefficient_at_replacement='1',reason='Add the existing zero-target column to the old span witness, giving a unimodular column replacement instead of appending a column.',old_witness_sha256=hashlib.sha256(Path('work/nonsquare-v62/fresh-cubic/short-row-degree1.witness').read_bytes()).hexdigest())
(wd/'last-preparation.json').write_text(json.dumps(meta,indent=2)+'\n')
s=Path('code/polynomial_unit_span_pivots_20261103_v62.cpp').read_text().replace('vector<Poly> known;','vector<Poly> known;int witnessReplacement=-1;')
s=s.replace('if(replace>=0){for(int i=0;i<n;i++)A[i][replace]=v[i];','if(replace>=0){witnessReplacement=replace;for(int i=0;i<n;i++)A[i][replace]=v[i];')
s=s.replace('if(string(argv[4])=="1"){int discard;for(int l=0;l<r+n;l++)in>>discard;}else assert(string(argv[4])=="0");','vector<int>inputOrigin(n);if(string(argv[4])=="1"){int discard;for(int l=0;l<r;l++)in>>discard;for(int&i:inputOrigin)in>>i;}else{assert(string(argv[4])=="0");for(int i=0;i<n;i++)inputOrigin[i]=i;}')
s=s.replace('for(int i=0;i<n;i++)origin[i]=i;','for(int i=0;i<n;i++)origin[i]=inputOrigin[i];')
a=s.index('for(;k<n;k++){int bi=');b=s.index('swap(A[k],A[bi]);',a)
s=s[:a]+'assert(argc==7&&witnessReplacement>=0);for(;k<1;k++){int bi=stoi(argv[6]),bj=witnessReplacement;assert(bi>=0&&bi<n&&unit(A[bi][bj]));'+s[b:]
(wd/'last-pivot.cpp').write_text(s)
print('PHASE29_BYTE_EQUALITY_PASS',n,m,'REPLACEMENT_COLUMN',j,'cost',cost,'targetrow',order.index(23))

C0=QQ[e];K=frac C0;R=K[a,P,z];e=promote(C0_0,K);
M=matrix{{a,1-a}};
G=gb(M,ChangeMatrix=>true);N=gens G;E=id_(target M);
X=(getChangeMatrix G)*(E//N);
assert(M*X==E);
print "EXACT_FUNCTION_FIELD_UNIT_LIFT_SMOKE_PASS";
print toExternalString X_(0,0);<<flush;

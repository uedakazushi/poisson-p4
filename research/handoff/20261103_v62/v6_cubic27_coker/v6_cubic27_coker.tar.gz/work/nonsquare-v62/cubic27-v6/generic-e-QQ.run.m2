load "/workspace/poisson-p4/work/nonsquare-v62/cubic27-v6/generic-e-QQ.data.m2";
G27=gb(M27,ChangeMatrix=>true);N27=gens G27;E27=id_(target M27);
unit27=all(flatten entries(E27%G27),x->x==0_R);
print("FUNCTION_FIELD_GB_DONE_e_QQ",numColumns N27,unit27);<<flush;
outGB27=openOut "/workspace/poisson-p4/work/nonsquare-v62/cubic27-v6/generic-e-QQ.gb.txt";outGB27<<toExternalString N27<<endl;close outGB27;
if unit27 then (
    X27=(getChangeMatrix G27)*(E27//N27);
    out27=openOut "/workspace/poisson-p4/work/nonsquare-v62/cubic27-v6/generic-e-QQ.right-inverse.m2";
    out27<<"Xproof27=mutableMatrix(R,"<<numRows X27<<","<<numColumns X27<<");"<<endl;
    scan(numRows X27,i->scan(numColumns X27,j->if X27_(i,j)!=0_R then(out27<<"Xproof27_("<<i<<","<<j<<")="<<toExternalString X27_(i,j)<<";"<<endl)));
    out27<<"Xproof27=matrix Xproof27;assert(M27*Xproof27==id_(target M27));print \"RIGHT_INVERSE_REPLAY_PASS\";"<<endl;
    close out27;
    print "FUNCTION_FIELD_INVERSE_CANDIDATE_SAVED_e_QQ";<<flush;
    assert(M27*X27==E27);
    print "EXACT_FUNCTION_FIELD_COKER_ZERO_e_QQ";<<flush;
) else (
    A27=ann coker M27;
    print("FUNCTION_FIELD_ANN_DIM_e_QQ",dim(R/A27));<<flush;
    if dim(R/A27)==0 then(print("FUNCTION_FIELD_ANN_LENGTH",numColumns basis(R/A27));<<flush;);
    outAnn27=openOut "/workspace/poisson-p4/work/nonsquare-v62/cubic27-v6/generic-e-QQ.ann.txt";outAnn27<<toExternalString gens gb A27<<endl;close outAnn27;
);

load "/workspace/poisson-p4/work/nonsquare-v62/cubic27-v6/generic-e-QQ.data.m2";load "/workspace/poisson-p4/work/nonsquare-v62/cubic27-v6/generic-e-QQ.right-inverse.m2";

from pathlib import Path
import json,re,hashlib,tarfile
wd=Path('work/nonsquare-v62/cubic27-v6');rep=json.loads(Path('reports/S61_BINARY_NONSQUARE_CUBIC_ROW_BASIS_20261103_v62/report.json').read_text());ids=rep['alternative_ad_remaining_original_row_indices'];assert len(ids)==57
with tarfile.open('reports/S61_BINARY_NONSQUARE_CUBIC_REPLAY_20261103_v62/matrices.tar.gz')as t:full=t.extractfile('full').read()
assert hashlib.sha256(full).hexdigest()==rep['original_full_matrix_sha256'];lines=full.decode().splitlines();assert lines[0]=='63 91 57'
with (wd/'raw-alternative').open('w')as f:
 f.write('57 91 57\n')
 for i in ids:f.write('\n'.join(lines[1+i*91:1+(i+1)*91])+'\n')
(wd/'original-row-ids').write_text('57\n'+' '.join(map(str,ids))+'\n')
r=json.loads(Path('work/nonsquare-v62/fresh-cubic/report.json').read_text());log=r['native_logs']['unit_schur'];pairs=[]
for k,c,i in re.findall(r'PIVOT (\d+) COL (\d+) ROW (\d+)',log):pairs.append((int(i),int(c)))
assert len(pairs)==21 and all(i in ids for i,c in pairs)
(wd/'forced21').write_text('21\n'+''.join(f'{i} {c}\n'for i,c in pairs))
(wd/'forced8').write_text('8\n'+''.join(f'{i} {c}\n'for i,c in zip([27,28,30,31,7,21,20,9],[10,12,20,13,51,52,48,15])))
s=Path('code/s61_binary_hyperplane_cubic_unit_schur_20261102.cpp').read_text().replace('assert(argc==3);','assert(argc==5);').replace('assert(n==63&&m==91);','assert(n==57&&m==91&&r==57);')
s=s.replace('for(int i=0;i<n;i++)origin[i]=i;','ifstream idfile(argv[3]),forced(argv[4]);int idn,steps;idfile>>idn;assert(idn==n);for(int&i:origin)idfile>>i;forced>>steps;assert(steps==21);vector<int>forceRow(steps),forceCol(steps);for(int i=0;i<steps;i++)forced>>forceRow[i]>>forceCol[i];')
a=s.index('for(;k<42;k++){int bi=');b=s.index('if(bi<0)break;',a)
s=s[:a]+'for(;k<steps;k++){int bi=find(origin.begin()+k,origin.end(),forceRow[k])-origin.begin();int bj=forceCol[k];assert(bi<n&&bj>=0&&bj<m&&find(used.begin(),used.end(),bj)==used.end()&&unit(A[bi][bj]));int cost=fmpq_mpoly_length(A[bi][bj].p,ctx);'+s[b:]
(wd/'forced21.cpp').write_text(s)

#include <flint/fmpq.h>
#include <flint/fmpq_mpoly.h>
#include <flint/nmod_mat.h>
#include <flint/ulong_extras.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <cassert>
#include <algorithm>
using namespace std;fmpq_mpoly_ctx_t ctx;
struct P{fmpq_mpoly_t p;P(){fmpq_mpoly_init(p,ctx);}P(const P&x):P(){fmpq_mpoly_set(p,x.p,ctx);}P(P&&x):P(){fmpq_mpoly_swap(p,x.p,ctx);}P&operator=(P x){fmpq_mpoly_swap(p,x.p,ctx);return *this;}~P(){fmpq_mpoly_clear(p,ctx);}};
struct Q{fmpq_t q;Q(){fmpq_init(q);fmpq_one(q);}Q(const Q&x):Q(){fmpq_set(q,x.q);}Q(Q&&x):Q(){fmpq_swap(q,x.q);}Q&operator=(Q x){fmpq_swap(q,x.q);return *this;}~Q(){fmpq_clear(q);}};
void rd(istream&in,P&p){int nt;in>>nt;assert(in&&nt>=0);fmpq_t q;fmpq_init(q);ulong ex[3];for(int i=0;i<nt;i++){string c;in>>c>>ex[0]>>ex[1]>>ex[2];assert(in&&!fmpq_set_str(q,c.c_str(),10));fmpq_canonicalise(q);fmpq_mpoly_push_term_fmpq_ui(p.p,q,ex,ctx);}fmpq_mpoly_sort_terms(p.p,ctx);fmpq_mpoly_combine_like_terms(p.p,ctx);fmpq_mpoly_reduce(p.p,ctx);assert(fmpq_mpoly_is_canonical(p.p,ctx));fmpq_clear(q);}
void wr(ostream&o,const P&p){int nt=fmpq_mpoly_length(p.p,ctx);o<<nt;fmpq_t q;fmpq_init(q);ulong ex[3];for(int i=0;i<nt;i++){fmpq_mpoly_get_term_coeff_fmpq(q,p.p,i,ctx);fmpq_mpoly_get_term_exp_ui(ex,p.p,i,ctx);char*c=fmpq_get_str(nullptr,10,q);o<<' '<<c;flint_free(c);for(ulong e:ex)o<<' '<<e;}o<<'\n';fmpq_clear(q);}
void qwr(ostream&o,const Q&q){char*s=fmpq_get_str(nullptr,10,q.q);o<<s<<'\n';flint_free(s);}

int main(int argc,char**argv){assert(argc==6);fmpq_mpoly_ctx_init(ctx,3,ORD_LEX);{ifstream in(argv[1]),uf(argv[2]);ofstream out(argv[3]),proof(argv[4]),stats(argv[5]);int n,m,target;in>>n>>m>>target;assert(n==27&&m==61&&target==27);vector<vector<P>>A(n,vector<P>(m));for(auto&row:A)for(auto&p:row)rd(in,p);auto original=A;vector<P>known;string line;const char*names[]={"a","e","d"};while(getline(uf,line)){if(line.empty())continue;P f;assert(!fmpq_mpoly_set_str_pretty(f.p,line.c_str(),names,ctx));known.push_back(f);}assert(known.size()==6);vector<P>multipliers(m);P temp;long total=0;for(int j=0;j<m;j++){fmpq_mpoly_one(multipliers[j].p,ctx);int anchor=-1,best=100000000;for(int i=0;i<n;i++){int nt=fmpq_mpoly_length(A[i][j].p,ctx);if(nt&&nt<best){anchor=i;best=nt;}}assert(anchor>=0);vector<int>val(known.size());for(int k=0;k<(int)known.size();k++)while(true){vector<P>quot(n);bool yes=true;long before=0,after=0;for(int i=0;i<n;i++)before+=fmpq_mpoly_length(A[i][j].p,ctx);if(!fmpq_mpoly_divides(quot[anchor].p,A[anchor][j].p,known[k].p,ctx))break;for(int i=0;i<n;i++)if(i!=anchor&&!fmpq_mpoly_divides(quot[i].p,A[i][j].p,known[k].p,ctx)){yes=false;break;}if(!yes)break;for(auto&p:quot)after+=fmpq_mpoly_length(p.p,ctx);if(after>before)break;for(int i=0;i<n;i++)A[i][j]=quot[i];fmpq_mpoly_mul(temp.p,multipliers[j].p,known[k].p,ctx);multipliers[j]=temp;val[k]++;}long colterms=0,olddeg=0,newdeg=0;for(int i=0;i<n;i++){fmpq_mpoly_mul(temp.p,A[i][j].p,multipliers[j].p,ctx);assert(fmpq_mpoly_equal(temp.p,original[i][j].p,ctx));assert(fmpz_is_one(fmpq_denref(fmpq_mpoly_content_ref(A[i][j].p,ctx))));colterms+=fmpq_mpoly_length(A[i][j].p,ctx);olddeg=max(olddeg,fmpq_mpoly_total_degree_si(original[i][j].p,ctx));newdeg=max(newdeg,fmpq_mpoly_total_degree_si(A[i][j].p,ctx));}total+=colterms;proof<<j<<' ';wr(proof,multipliers[j]);stats<<j<<' '<<olddeg<<' '<<newdeg<<' '<<colterms;for(int v:val)stats<<' '<<v;stats<<'\n';cerr<<"KNOWN_UNIT_COLUMN "<<j<<" DEGREE "<<olddeg<<" -> "<<newdeg<<" TERMS "<<colterms<<'\n';}out<<n<<' '<<m<<' '<<target<<'\n';for(auto&row:A)for(auto&p:row)wr(out,p);cerr<<"EXACT_KNOWN_UNIT_COLUMN_EQUIVALENCE_PASS TERMS "<<total<<'\n';}
fmpq_mpoly_ctx_clear(ctx);flint_cleanup();}

from pathlib import Path
from fractions import Fraction
import json
from sympy.polys.rings import ring
from sympy import QQ
w=Path('work/nonsquare-v62/main-scalar-unit-v21');it=iter(Path('work/nonsquare-v62/primitive-unit-span-v9/full26.txt').read_text().split());n,m,k=[int(next(it))for _ in range(3)]
for _ in range(n+k):next(it)
R,a,e,d=ring('a,e,d',QQ);known=[a,500*a+90*e**2+3*e-24,(50*a+18*e**2-9*e-2)*d+(60*e-40)*a,100*a+18*e**2-9*e-2,5*d-6*e-4,d]
A=[]
for i in range(n):
 row=[]
 for j in range(m):
  p={}
  for _ in range(int(next(it))):
   c=Fraction(next(it));ex=tuple(int(next(it))for _ in range(3));p[ex]=QQ(c.numerator,c.denominator)
  row.append(R.from_dict(p))
 A.append(row)
def expr(p):return '('+(' + '.join('('+str(c)+')'+''.join('*'+x+('^'+str(k)if k!=1 else '')for x,k in zip(('a','e','d'),ex)if k)for ex,c in p.items())or '0')+')'
def save(tag,row):
 vals=[];base=[]
 for b in row:
  v=[0]*len(known)
  if b:
   for k,f in enumerate(known):
    while True:
     q,r=divmod(b,f)
     if r:break
     b=q;v[k]+=1
  vals.append(v);base.append(b)
 (w/(tag+'-vals.json')).write_text(json.dumps(vals))
 mat='matrix{{'+','.join(map(expr,base))+'}}'
 text='R=QQ[a,e,d];M='+mat+';print "SCALAR_INPUT_READY";<<flush;G=gb M;N=gens G;print("SCALAR_GB_DONE",numColumns N,dim(R/ideal flatten entries N));<<flush;outG=openOut "'+str((w/(tag+'-gb.txt')).resolve())+'";outG<<toExternalString N<<endl;close outG;print "SCALAR_GB_SAVED";<<flush;'
 (w/(tag+'.m2')).write_text(text)
 print(tag,'primitive terms',sum(len(p)for p in base),'raw terms',sum(len(p)for p in row),'valuations',sum(sum(v)for v in vals),flush=True)
save('row0',A[0]);save('row7',A[7])

R=QQ[a,e,d];T=mutableMatrix(R,2,3);T_(0,1)=a+e;T=matrix T;assert(T_(0,1)==a+e);print "MUTABLE_STREAM_INPUT_PASS";

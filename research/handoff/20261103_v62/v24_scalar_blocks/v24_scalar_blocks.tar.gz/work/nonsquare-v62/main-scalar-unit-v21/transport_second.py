from pathlib import Path
from fractions import Fraction
from sympy.polys.rings import ring
from sympy import QQ
R,*v=ring('a,e,d',QQ);w=Path('work/nonsquare-v62/main-scalar-unit-v21')
def readpoly(it):
 p={}
 for _ in range(int(next(it))):
  c=Fraction(next(it));ex=tuple(int(next(it))for _ in range(3));p[ex]=QQ(c.numerator,c.denominator)
 return R.from_dict(p)
it=iter((w/'rows0_7-right-inverse.txt').read_text().split());n,m,k=[int(next(it))for _ in range(3)];assert(n,m,k)==(60,2,0);A=[[readpoly(it)for _ in range(m)]for _ in range(n)]
it=iter((w/'row7.witness').read_text().split());assert int(next(it))==60;c=[readpoly(it)for _ in range(60)];pivot=43;assert c[pivot].is_ground and c[pivot]
# T is identity with column43 replaced by c; invert T on the second witness.
coef=A[pivot][0]/c[pivot];out=[A[j][0]-coef*c[j]for j in range(60)if j!=pivot]
assert len(out)==59
with(w/'after-row7-second.witness').open('w')as f:
 f.write('59\n')
 for p in out:
  f.write(str(len(p))+'\n')
  for ex,c in p.items():f.write(str(c)+' '+' '.join(map(str,ex))+'\n')
print('EXACT_CONSTANT_COLUMN_INVERSE_TRANSPORT',sum(len(p)for p in out),flush=True)

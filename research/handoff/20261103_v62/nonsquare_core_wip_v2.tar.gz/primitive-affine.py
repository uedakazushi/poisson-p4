from pathlib import Path
import json,sys,time
from fractions import Fraction
import sympy as s
from sympy.polys.rings import ring
st=time.time();p=32003
kind=sys.argv[1]if len(sys.argv)>1 else'a1'
if kind=='a1':R,e,d=ring('e,d',s.GF(p));a=R.one
else:R,a,d=ring('a,d',s.GF(p));e=R(2)
fs=[a,d,500*a+90*e**2+3*e-24,(50*a+18*e**2-9*e-2)*d+60*e-40,100*a+18*e**2-9*e-2]
def coef(c):
 q=Fraction(c);return q.numerator*pow(q.denominator,-1,p)%p
def row(raw):
 out={}
 for mon,terms in raw:
  z=R.zero
  for ex,c in terms:z+=coef(c)*a**ex[0]*e**ex[1]*d**ex[2]
  if z:out[tuple(mon)]=z
 return out
old=json.load(open('work/nonsquare-v62/old/work/generic_hyperplane_polynomial_a_elimination_20261102.json'));new=json.load(open('reports/S61_BINARY_NONSQUARE_PARTIAL135_20261103_v62/additional-G6.json'))
rs=[row(q['polynomial'])for q in old['equations_sparse']]+[row(new['G6'])];history=[]
for i,q in enumerate(rs):
 g=R.zero
 for c in q.values():g=g.gcd(c)
 rem=g;orders=[]
 for f in fs:
  n=0
  if not f or all(not any(mon)for mon in f):orders.append(0);continue
  while rem.rem(f)==0:rem=rem.exquo(f);n+=1
  orders.append(n)
 div=g.exquo(rem)*rem.LC
 rs[i]={m:c.exquo(div)for m,c in q.items()};history.append(orders)
print('primitive',kind,'rows',len(rs),'oldterms',sum(len(c)for q in rs for c in q.values()),'degrees',max(sum(m)for q in rs for c in q.values()for m in c),'seconds',time.time()-st,flush=True)
target=row(new['t_numerator']);target[()]=target.get((),R.zero)-a**9;rs.append(target)
def pol(q):
 return '+'.join('('+str(c).replace(' mod 32003','').replace('**','^')+')'+''.join('*q'+str(j)for j in mon)for mon,c in q.items())or'0'
vs=old['remaining_variables'];pars=['e','d']if kind=='a1'else['a','d'];vars=['q'+str(i)for i in vs]+pars+['z'];aa='1_R'if kind=='a1'else'a';ee='e'if kind=='a1'else'2_R'
lines=['R=(ZZ/32003)['+','.join(vars)+'];a='+aa+';e='+ee+';','F=500*a+90*e^2+3*e-24;B=(50*a+18*e^2-9*e-2)*d+60*e-40;C=100*a+18*e^2-9*e-2;','I=ideal('+','.join(pol(q)for q in rs)+',z*a*d*F*B*C-1);','G=groebnerBasis(I,Strategy=>"F4");H=monomialIdeal leadTerm G;print(dim(R/H),numColumns G);print "PRIMITIVE_PARTIAL135_F4_DONE";']
out=Path('work/nonsquare-v62');(out/('primitive-'+kind+'.m2')).write_text('\n'.join(lines)+'\n');(out/('primitive-'+kind+'-history.json')).write_text(json.dumps(history));print('inputbytes',(out/('primitive-'+kind+'.m2')).stat().st_size,flush=True)

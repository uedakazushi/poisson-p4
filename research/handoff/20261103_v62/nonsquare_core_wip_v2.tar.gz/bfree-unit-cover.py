from pathlib import Path
import sympy as s,json,time
from sympy.polys.rings import ring
st=time.time();wd=Path('work/nonsquare-v62/fresh-bfree');R,a,e,d=ring('a,e,d',s.QQ);nw=[1,1,1,1,1,2,1,1]
def mons(w,i=0,m=()):
 if i==8:
  if w==0:yield m
  return
 for k in range(w//nw[i]+1):yield from mons(w-k*nw[i],i+1,m+(k,))
rows=[];labels=[]
with(wd/'rows').open()as f:
 for _ in range(int(f.readline())):
  idx,w,ct=map(int,f.readline().split());q={}
  for _ in range(ct):
   mon=tuple(map(int,f.readline().split()));z=f.readline().split();q[mon]=R.from_dict({tuple(map(int,z[2+4*k:5+4*k])):s.QQ(z[1+4*k])for k in range(int(z[0]))})
  for sh in mons(4-w):rows.append({tuple(x+y for x,y in zip(mon,sh)):c for mon,c in q.items()if c});labels.append([idx,sh])
columns=[m for m in mons(4)if m[5]!=2];assert(len(rows),len(columns))==(321,238)
with(wd/'matrix').open('w')as f:
 f.write('321 238 238\n')
 for row in rows:
  for m in columns:
   q=row.get(m,R.zero);f.write(str(len(q))+''.join(' '+str(c)+' '+' '.join(map(str,ex))for ex,c in q.items())+'\n')
(wd/'matrix-meta.json').write_text(json.dumps(dict(labels=labels,columns=columns)))
src=Path('code/s61_binary_hyperplane_cubic_unit_schur_20261102.cpp').read_text().replace('n==63&&m==91','n==321&&m==238').replace('k<42','k<238').replace('i<42','i<n').replace('50*a*d+18*d*e^2-9*d*e-2*d+60*e-40','50*a+9*e^2+3*e-6').replace('count()<60','count()<120')
(wd/'unit-schur.cpp').write_text(src);print('READY',sum(len(p)for row in rows for p in row.values()),'seconds',time.time()-st,flush=True)

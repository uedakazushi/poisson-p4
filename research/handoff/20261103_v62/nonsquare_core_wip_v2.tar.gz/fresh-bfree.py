from pathlib import Path
import sys,subprocess,json,time,os
sys.path.insert(0,'code')
import s61_binary_hyperplane_Bfree_horizontal_20261102 as mod
wd=Path('work/nonsquare-v62/fresh-bfree').resolve();wd.mkdir(exist_ok=True)
def compile(src,target):
 flags=subprocess.check_output(['pkg-config','--cflags','--libs','flint'],text=True).split()
 cp=subprocess.run(['c++','-w','-O3','-std=c++17','-I'+str(Path('code').resolve()),str(src),*flags,'-lgmp','-o',str(target)],capture_output=True,text=True);assert cp.returncode==0,cp.stderr
mod.compile_native=compile
logs={}
def run(label,args):
 st=time.time();cp=subprocess.run(list(map(str,args)),capture_output=True,text=True,check=True);logs[label]=dict(seconds=time.time()-st,log=cp.stderr);print(label,cp.stderr[-400:],flush=True)
r=mod.build_source(wd,os.environ,run);r['logs']=logs;(wd/'report.json').write_text(json.dumps(r,indent=2)+'\n');print('DONE',r['source_rows_sha256'],flush=True)

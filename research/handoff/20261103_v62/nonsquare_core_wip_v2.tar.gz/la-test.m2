R=QQ[x,y];E=matrix{{x,y^2+1},{x+y,1_R}};G=gb(image E,Algorithm=>LinearAlgebra);print toString gens G;print "LA_QQ_MODULE_WORKS";

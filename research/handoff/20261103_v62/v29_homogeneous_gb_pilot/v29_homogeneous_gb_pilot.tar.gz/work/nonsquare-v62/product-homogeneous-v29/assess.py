from pathlib import Path
import json,hashlib
w=Path('work/nonsquare-v62/product-homogeneous-v29/32003');p=32003
with(w/'G-native4.txt').open()as f:
 n,m,k=map(int,f.readline().split());assert(n,m,k)==(10,739,0);columns=[[]for _ in range(m)];hist={};terms=0
 for i in range(n):
  for j in range(m):
   nt=int(f.readline());terms+=nt
   for z in range(nt):
    t=f.readline().split();c=int(t[0])%p;ex=tuple(int(v)for v in t[1:]);assert len(ex)==4 and c;columns[j].append((i,ex,c));hist[min(c,p-c)]=hist.get(min(c,p-c),0)+1
 assert not f.read().strip()
degrees=[];leading=[];leading_coeffs=[]
for col in columns:
 ds={sum(ex)for i,ex,c in col};assert len(ds)==1;degrees.append(ds.pop())
 # Native(dp,C) smoke gives higher component index as the leading tie.
 i,ex,c=max(col,key=lambda t:(sum(t[1]),*[-v for v in reversed(t[1])],t[0]));leading.append((*ex,i+1));leading_coeffs.append(c)
report=dict(prime=p,source_input=json.loads((w/'source.json').read_text()),runtime=json.loads((w/'run.json').read_text()),GB_shape=[n,m],GB_terms=terms,GB_max_degree=max(degrees),all_GB_columns_homogeneous=True,all_GB_leading_coefficients_one=all(c==1 for c in leading_coeffs),leading_coefficient_values=sorted(set(leading_coeffs)),field_coefficient_representative_bits=max(c.bit_length()for c in hist),QQ_coefficient_height_unknown=True,coefficient_plus_minus_one_count=hist.get(1,0),coefficient_representative_abs_at_most_100_count=sum(v for c,v in hist.items()if c<=100),leading_signature_sha256=hashlib.sha256(repr(leading).encode()).hexdigest(),QQ_claim=False,next_reconstruction_requires=['Fixed same source Mh and rowshifts0/order acrossprimes','Monic canonical GF GB coefficient reconstruction','ExactQQ complete GB S-pair check','ExactQQ containment Ih subsetG','p-integrality and exact same good-prime original homogeneous module equality','Hilbert-function sandwich proving Ih=G','Only then dehomogeneous localizedrank criterion'])
(w/'assessment.json').write_text(json.dumps(report,indent=2)+'\n');(w/'leading-signature.json').write_text(json.dumps(leading)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ['source_input','leading_coefficient_values']},indent=2))

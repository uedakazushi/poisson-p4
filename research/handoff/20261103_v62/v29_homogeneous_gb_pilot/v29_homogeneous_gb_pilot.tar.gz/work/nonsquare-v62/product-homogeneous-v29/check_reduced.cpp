#include <array>
#include <vector>
#include <fstream>
#include <iostream>
#include <cassert>
using namespace std;struct T{int row;array<int,4>e;long c;};int degree(const T&t){int d=0;for(int e:t.e)d+=e;return d;}bool lead_is_greater(const T&a,const T&b){if(degree(a)!=degree(b))return degree(a)>degree(b);for(int i=3;i>=0;i--)if(a.e[i]!=b.e[i])return a.e[i]<b.e[i];return a.row>b.row;}int main(int argc,char**argv){assert(argc==2);ifstream f(argv[1]);int n,m,k;f>>n>>m>>k;assert(n==10&&m==739&&k==0);vector<vector<T>>G(m);for(int i=0;i<n;i++)for(int j=0;j<m;j++){int count;f>>count;for(int z=0;z<count;z++){T t;t.row=i;f>>t.c;for(int&v:t.e)f>>v;assert(f);G[j].push_back(t);}}vector<T>L;for(auto&col:G){assert(!col.empty());T lead=col[0];for(auto&t:col)if(lead_is_greater(t,lead))lead=t;assert((lead.c%32003+32003)%32003==1);for(auto&t:col)assert(degree(t)==degree(lead));L.push_back(lead);}long checks=0;for(int j=0;j<m;j++)for(auto&t:G[j])for(int h=0;h<m;h++)if(h!=j&&L[h].row==t.row){bool divides=true;for(int z=0;z<4;z++)if(L[h].e[z]>t.e[z]){divides=false;break;}assert(!divides);checks++;}cout<<"MONIC_HOMOGENEOUS_FULLY_REDUCED_GF_GB_DATA_PASS "<<m<<" CANDIDATE_CHECKS "<<checks<<'\n';}

from pathlib import Path
from fractions import Fraction
import json,hashlib
w=Path('work/nonsquare-v62/raw-fourquad-homogeneous-v38');old=Path('work/nonsquare-v62/raw-fourquad-GF-v36');src=old/'M-QQ-native.txt';p=32003;A=[]
with src.open()as f:
 assert list(map(int,f.readline().split()))==[24,56,0]
 for i in range(24):
  row=[]
  for j in range(56):
   ts=f.readline().split();n=int(ts[0]);assert len(ts)==1+4*n;q={}
   for z in range(n):q[tuple(map(int,ts[2+4*z:5+4*z]))]=Fraction(ts[1+4*z])
   row.append(q)
  A.append(row)
 assert not f.read().strip()
deg=[max(sum(ex)for row in A for ex in row[j])for j in range(56)];B=[];terms=0
for row in A:
 out=[]
 for j,q in enumerate(row):
  rr={}
  for ex,c in q.items():
   assert c.denominator%p;v=c.numerator*pow(c.denominator,-1,p)%p;hom=(*ex,deg[j]-sum(ex));assert min(hom)>=0
   if v:rr[hom]=v if v<=p//2 else v-p
  terms+=len(rr);out.append(rr)
 B.append(out)
expr=lambda q:'('+(' + '.join(str(c)+''.join('*'+v+('^'+str(k)if k!=1 else'')for v,k in zip(('a','e','d','w'),ex)if k)for ex,c in q.items())or'0')+')'
export_template='module taskM=Q;option(redSB);print("RAW_FOURQUAD_HOMOGENEOUS_INPUT_READY");module taskG=slimgb(taskM);print("RAW_FOURQUAD_HOMOGENEOUS_GB_DONE");print(ncols(matrix(taskG)));if(size(reduce(taskM,taskG))!=0){print("ERROR_SOURCE_INCLUSION");quit;}matrix taskGM=matrix(taskG);int taskRows=nrows(taskGM);int taskCols=ncols(taskGM);link taskOut="ASCII:w __OUTPUT_PATH__";open(taskOut);write(taskOut,string(taskRows)+" "+string(taskCols)+" 0");int taskI,taskJ;int taskD;int taskMaxD=0;int taskTerms=0;poly taskP;intvec taskEx;for(taskJ=1;taskJ<=taskCols;taskJ++){taskD=-1;for(taskI=1;taskI<=taskRows;taskI++){taskP=taskGM[taskI,taskJ];while(taskP!=0){taskEx=leadexp(taskP);if(taskD<0){taskD=taskEx[1]+taskEx[2]+taskEx[3]+taskEx[4];}if(taskD!=taskEx[1]+taskEx[2]+taskEx[3]+taskEx[4]){print("ERROR_GB_COLUMN_NOT_RAW_FOURQUAD_HOMOGENEOUS");quit;}taskP=taskP-lead(taskP);}}if(taskD>taskMaxD){taskMaxD=taskD;}}for(taskI=1;taskI<=taskRows;taskI++){for(taskJ=1;taskJ<=taskCols;taskJ++){taskP=taskGM[taskI,taskJ];taskTerms=taskTerms+size(taskP);write(taskOut,string(size(taskP)));while(taskP!=0){taskEx=leadexp(taskP);write(taskOut,string(leadcoef(taskP))+" "+string(taskEx[1])+" "+string(taskEx[2])+" "+string(taskEx[3])+" "+string(taskEx[4]));taskP=taskP-lead(taskP);}}}close(taskOut);print("RAW_FOURQUAD_HOMOGENEOUS_GB_TERMS");print(taskTerms);print("RAW_FOURQUAD_HOMOGENEOUS_GB_MAX_DEGREE");print(taskMaxD);print("RAW_FOURQUAD_HOMOGENEOUS_GB_NATIVE_SAVED");quit;'
with(w/'source.sing').open('w')as f:
 f.write('ring r=32003,(a,e,d,w),(dp,C);matrix Q[24][56];\n')
 for i,row in enumerate(B):
  for j,q in enumerate(row):
   if q:f.write(f'Q[{i+1},{j+1}]='+expr(q)+';\n')
 f.write(export_template.replace('__OUTPUT_PATH__',str((w/'G-native4.txt').resolve())))
q=json.loads((old/'source.json').read_text());q.update(fixed_QQ_column_degrees=deg,row_degrees=[0]*24,Singular_order='(dp,C)',homogenization='Each entire QQ source column to its fixed QQ degree BEFORE modp reduction',prime=p,input_terms=terms,QQ_claim=False,all_columns_homogeneous=True);(w/'source.json').write_text(json.dumps(q,indent=2)+'\n');print('RAW_HOM_SOURCE',terms,'degrees',min(deg),max(deg),flush=True)
s=(old/'run.py').read_text().replace('raw-fourquad-GF-v36','raw-fourquad-homogeneous-v38');(w/'run.py').write_text(s)

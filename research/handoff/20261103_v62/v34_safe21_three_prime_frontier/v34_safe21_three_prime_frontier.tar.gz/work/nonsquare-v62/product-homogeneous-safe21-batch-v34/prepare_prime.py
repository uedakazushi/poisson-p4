from pathlib import Path
from fractions import Fraction
import json,hashlib,sys
p=int(sys.argv[1]);w=Path('work/nonsquare-v62/product-homogeneous-safe21-batch-v34')/str(p);w.mkdir(exist_ok=True)
source=Path('work/nonsquare-v62/adaptive-product-v12/P-after21.txt');assert hashlib.sha256(source.read_bytes()).hexdigest()=='ef6e066015ebbe0e8791bf4b264069d0559b7c9154765a9d1b7cb1675a0bc515'
provenance=json.loads(Path('work/nonsquare-v62/adaptive-product-v12/source.json').read_text());A=[]
with source.open() as f:
 assert list(map(int,f.readline().split()))==[36,70,36]
 # This source has NO metadata lines. Third header integer is not a flag.
 for i in range(20):
  row=[]
  for j in range(70):
   t=f.readline().split();n=int(t[0]);assert len(t)==1+4*n;q={}
   for z in range(n):
    c=Fraction(t[1+4*z]);ex=tuple(int(v)for v in t[2+4*z:5+4*z]);assert min(ex)>=0;q[ex]=c
   row.append(q)
  A.append(row)
keep=[j for j in range(70)if any(row[j]for row in A)];assert len(keep)==63
A=[[row[j]for j in keep]for row in A]
deg=[max(sum(ex)for row in A for ex in row[j])for j in range(63)];B=[];terms=0;source_terms=0
for row in A:
 out=[]
 for j,q in enumerate(row):
  r={}
  for ex,c in q.items():
   source_terms+=1;assert c.denominator%p;hom=(*ex,deg[j]-sum(ex));assert min(hom)>=0 and sum(hom)==deg[j];v=c.numerator*pow(c.denominator,-1,p)%p
   if v:r[hom]=v if v<=p//2 else v-p
  terms+=len(r);out.append(r)
 B.append(out)
assert source_terms==30731
expr=lambda q:'('+(' + '.join(str(c)+''.join('*'+v+('^'+str(k)if k!=1 else '')for v,k in zip(('a','e','d','w'),ex)if k)for ex,c in q.items())or'0')+')'
with(w/'source.sing').open('w') as f:
 f.write('ring r='+str(p)+',(a,e,d,w),(dp,C);matrix Q[20][63];\n')
 for i,row in enumerate(B):
  for j,q in enumerate(row):
   if q:f.write(f'Q[{i+1},{j+1}]='+expr(q)+';\n')
 f.write('module taskM=Q;option(redSB);print("SAFE21_HOMOGENEOUS_INPUT_READY");module taskG=slimgb(taskM);print("SAFE21_HOMOGENEOUS_GB_DONE");print(ncols(matrix(taskG)));if(size(reduce(taskM,taskG))!=0){print("ERROR_SOURCE_INCLUSION");quit;}matrix taskGM=matrix(taskG);int taskRows=nrows(taskGM);int taskCols=ncols(taskGM);link taskOut="ASCII:w '+str((w/'G-native4.txt').resolve())+'";open(taskOut);write(taskOut,string(taskRows)+" "+string(taskCols)+" 0");int taskI,taskJ;int taskD;int taskMaxD=0;int taskTerms=0;poly taskP;intvec taskEx;for(taskJ=1;taskJ<=taskCols;taskJ++){taskD=-1;for(taskI=1;taskI<=taskRows;taskI++){taskP=taskGM[taskI,taskJ];while(taskP!=0){taskEx=leadexp(taskP);if(taskD<0){taskD=taskEx[1]+taskEx[2]+taskEx[3]+taskEx[4];}if(taskD!=taskEx[1]+taskEx[2]+taskEx[3]+taskEx[4]){print("ERROR_GB_COLUMN_NOT_HOMOGENEOUS");quit;}taskP=taskP-lead(taskP);}}if(taskD>taskMaxD){taskMaxD=taskD;}}for(taskI=1;taskI<=taskRows;taskI++){for(taskJ=1;taskJ<=taskCols;taskJ++){taskP=taskGM[taskI,taskJ];taskTerms=taskTerms+size(taskP);write(taskOut,string(size(taskP)));while(taskP!=0){taskEx=leadexp(taskP);write(taskOut,string(leadcoef(taskP))+" "+string(taskEx[1])+" "+string(taskEx[2])+" "+string(taskEx[3])+" "+string(taskEx[4]));taskP=taskP-lead(taskP);}}}close(taskOut);print("HOMOGENEOUS_GB_TERMS");print(taskTerms);print("HOMOGENEOUS_GB_MAX_DEGREE");print(taskMaxD);print("SAFE21_HOMOGENEOUS_GB_NATIVE_SAVED");quit;')
(w/'source.json').write_text(json.dumps(dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_has_metadata=False,source_header=[36,70,36],exact_source_rows=list(range(20)),global_original_row_indices=provenance['row_global_indices'][:20],row_a_clear_shifts=provenance['row_a_clear_shifts'][:20],retained_columns=keep,QQ_column_degrees=deg,row_degrees=[0]*20,polynomial_variables=['a','e','P','w'],Singular_order='(dp,C)',homogenization='Each full source column to its fixed QQ maximum degree, before reduction modp',prime=p,source_terms=source_terms,input_terms=terms,all_columns_homogeneous=True,all_source_denominators_prime_units=True,QQ_claim=False,criterion='Full20 residual product rows after21 safe QQ unit pivots suffice for original product rank41; no converse claimed in positive characteristic'),indent=2)+'\n');print('SAFE21_HOMOGENEOUS_SOURCE_PREPARED',terms,'degrees',min(deg),max(deg),flush=True)

from pathlib import Path
import subprocess,sys,concurrent.futures,json,hashlib
w=Path('work/nonsquare-v62/product-homogeneous-safe21-batch-v34');old=Path('work/nonsquare-v62/product-homogeneous-safe21-v33');source0=json.loads((old/'source.json').read_text());base=json.loads((old/'report.json').read_text());expected=base['GF_GB_leading_module_sha256'];primes=[2147483629,2147483587]
def one(p):
 subprocess.run([sys.executable,str(w/'prepare_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL);subprocess.run([sys.executable,str(w/'run_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL);d=w/str(p);r=json.loads((d/'run.json').read_text());assert r['exit_code']==0 and not r['timed_out'];log=(d/'run.log').read_text();assert'SAFE21_HOMOGENEOUS_GB_NATIVE_SAVED'in log and'?'not in log and'ERROR'not in log
 q=json.loads((d/'source.json').read_text())
 for key in ['source_sha256','QQ_column_degrees','row_degrees','Singular_order','retained_columns','homogenization','global_original_row_indices','row_a_clear_shifts']:assert q[key]==source0[key],key
 subprocess.run([str(old/'check-reduced-bin'),str(d/'G-native4.txt'),str(p)],check=True,stdout=(d/'check-reduced.log').open('w'))
 with(d/'G-native4.txt').open()as f:
  n,m,k=map(int,f.readline().split());assert(n,m,k)==(20,1050,0);L=[None]*m;terms=0
  for i in range(n):
   for j in range(m):
    count=int(f.readline());terms+=count
    for _ in range(count):
     t=f.readline().split();ex=tuple(map(int,t[1:]));key=(sum(ex),*[-v for v in reversed(ex)],i)
     if L[j]is None or key>L[j][0]:L[j]=(key,(*ex,i+1))
 sig=hashlib.sha256(repr(sorted(v[1]for v in L)).encode()).hexdigest();assert sig==expected,'leading module changed; stop and inspect'
 info=dict(prime=p,elapsed=r['elapsed_seconds'],max_rss_kib=r['max_rss_kib'],GB_terms=terms,same_leading_module=True,all_monic_homogeneous_and_fully_reduced=True);(d/'assessed.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True);return p
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:done=list(pool.map(one,primes))
(w/'batch-result.json').write_text(json.dumps(dict(primes=[2147483647]+primes,completed=done,QQ_claim=False),indent=2)+'\n')

from pathlib import Path
import sys,subprocess,json
w=Path('work/nonsquare-v62/raw-e0-lift-three-fields-v48');done=[]
for p in [2147483647,2147483629]:
 subprocess.run([sys.executable,str(w/'prepare_prime.py'),str(p)],check=True);subprocess.run([sys.executable,str(w/'run_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL);d=w/str(p);r=json.loads((d/'run.json').read_text());log=(d/'run.log').read_text();assert r['exit_code']==0 and not r['timed_out'] and'RAW_E0_NATIVE_SAVED'in log and'RAW_E0_EXACT_FIELD_IDENTITY_PASS'in log and'?'not in log and'ERROR'not in log;r['prime']=p;print(json.dumps(r),flush=True);done.append(r)
(w/'batch-result.json').write_text(json.dumps(done,indent=2)+'\n')

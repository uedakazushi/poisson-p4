from pathlib import Path
from fractions import Fraction
import json,math,hashlib,gzip
w=Path('work/nonsquare-v62/raw-e0-lift-three-fields-v48');primes=[32003,2147483647,2147483629];orig=Path('work/nonsquare-v62/raw-fourquad-e0-lift-v47');paths=[orig/'primitive-native.txt']+[w/str(p)/'primitive-native.txt'for p in primes[1:]]
def read(path,p):
 ts=iter(path.read_text().split());n,m,k=[int(next(ts))for _ in range(3)];assert(n,m,k)==(56,1,0);data={}
 for i in range(n):
  for j in range(int(next(ts))):
   c=int(next(ts))%p;ex=tuple(int(next(ts))for _ in range(3));assert c;data[(i,*ex)]=c
 return data
allC=[read(path,p)for path,p in zip(paths,primes)];keys=sorted(set().union(*allC));assert set(allC[1])==set(allC[2]);assert not(set(allC[0])-set(allC[1]));assert len(keys)==8919;R=[0]*len(keys);mod=1
for i,(p,C)in enumerate(zip(primes,allC)):
 inv=pow(mod,-1,p);R=[v+mod*((C.get(key,0)-v)*inv%p)for key,v in zip(keys,R)];mod*=p
 if i==1:prev=R.copy();mprev=mod
def rr(x,M):
 B=math.isqrt(M//2);r0,r1,t0,t1=M,x,0,1
 while abs(r1)>B:q=r0//r1;r0,r1=r1,r0-q*r1;t0,t1=t1,t0-q*t1
 if t1 and abs(t1)<=B and math.gcd(r1,t1)==1 and math.gcd(t1,M)==1:return Fraction(r1,t1)
 return None
qs=[rr(x,mod)for x in R];qsp=[rr(x,mprev)for x in prev];stable=[x for x,y in zip(qs,qsp)if x is not None and x==y];r=dict(GF_only=True,QQ_identity_not_verified=True,prime_count=3,primes=primes,modulus_bits=mod.bit_length(),fixed_target='a e0',primitive_cofactor_shape=[56,1],primitive_degree=11,support_union=len(keys),same_full_support_large_fields=True,zero_padded_missing_at32003=len(keys)-len(allC[0]),reconstruct_previous=sum(x is not None for x in qsp),reconstruct_current=sum(x is not None for x in qs),stable_previous_current=len(stable),stable_fraction=len(stable)/len(keys),max_stable_num_bits=max((abs(x.numerator).bit_length()for x in stable),default=0),max_stable_den_bits=max((x.denominator.bit_length()for x in stable),default=0),complete_QQ_candidate=len(stable)==len(keys),no_further_fields_authorized=True,inputs_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths});(w/'three-field-assessment.json').write_text(json.dumps(r,indent=2)+'\n');(w/'CRT-state3.json.gz').write_bytes(gzip.compress(json.dumps(dict(keys=keys,residues=list(map(str,R)),modulus=str(mod),primes=primes),separators=(',',':')).encode(),mtime=0));print(json.dumps(r),flush=True)

from pathlib import Path
import json,hashlib
w=Path('work/nonsquare-v62/raw-e0-lift-three-fields-v48')
def cols(path,p):
 ts=iter(path.read_text().split());n,m,k=[int(next(ts))for _ in range(3)];assert(n,m,k)==(24,160,0);cs=[{}for _ in range(m)]
 for i in range(n):
  for j in range(m):
   for _ in range(int(next(ts))):
    c=int(next(ts))%p;ex=tuple(int(next(ts))for _ in range(3));assert c;cs[j][(i,*ex)]=c
 out=[]
 for c in cs:
  lead=max(c);unit=pow(c[lead],-1,p);out.append(tuple(sorted((k,v*unit%p)for k,v in c.items())))
 return sorted(out)
reports=[]
for p in [2147483647,2147483629]:
 a=w/str(p)/'GB-native.txt';b=Path('work/nonsquare-v62/raw-fourquad-ann-comparison-v45')/str(p)/'G-native.txt';assert cols(a,p)==cols(b,p);reports.append(dict(prime=p,same_complete_polynomial_GB_columns_up_to_scalars=True,new_liftstd_GB_sha256=hashlib.sha256(a.read_bytes()).hexdigest(),earlier_slimgb_GB_sha256=hashlib.sha256(b.read_bytes()).hexdigest()))
r=dict(all_passed=True,canonical_basis_protocol_comparison=reports,cofactor_QQ_reconstruction_not_proved=True);(w/'basis-protocol-check.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

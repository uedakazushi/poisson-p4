from pathlib import Path
import subprocess,resource,time,os,signal,json,sys
w=Path('work/nonsquare-v62/raw-fourquad-QQ-v37');cmd=['work/nonsquare-v62/singular-runtime/run-singular-optimized-v6.sh','--cpus=0','-q',str(w/'source.sing')]
def cap():resource.setrlimit(resource.RLIMIT_AS,(2200000*1024,2200000*1024))
t=time.monotonic()
with(w/'run.log').open('w')as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,preexec_fn=cap,start_new_session=True);(w/'pid').write_text(str(p.pid)+'\n');timedout=False
 try:p.wait(timeout=60)
 except subprocess.TimeoutExpired:timedout=True;os.killpg(p.pid,signal.SIGKILL);p.wait()
r=dict(command=cmd,elapsed_seconds=time.monotonic()-t,exit_code=p.returncode,timed_out=timedout,max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,QQ_claim=False);(w/'run.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

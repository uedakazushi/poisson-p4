from pathlib import Path
from fractions import Fraction
import json,hashlib
w=Path('work/nonsquare-v62/raw-fourquad-QQ-v37');old=Path('work/nonsquare-v62/raw-fourquad-GF-v36');src=old/'M-QQ-native.txt';A=[]
with src.open()as f:
 assert list(map(int,f.readline().split()))==[24,56,0]
 for i in range(24):
  row=[]
  for j in range(56):
   ts=f.readline().split();n=int(ts[0]);assert len(ts)==1+4*n;q={}
   for z in range(n):q[tuple(map(int,ts[2+4*z:5+4*z]))]=Fraction(ts[1+4*z])
   row.append(q)
  A.append(row)
 assert not f.read().strip()
expr=lambda q:'('+(' + '.join('('+str(c)+')'+''.join('*'+v+('^'+str(k)if k!=1 else'')for v,k in zip(('a','e','d'),ex)if k)for ex,c in q.items())or'0')+')'
body=(old/'source.sing').read_text().split('module taskM=Q;',1)[1];body=body.replace(str(old.resolve()),str(w.resolve())).replace('RAW_FOURQUAD','RAW_FOURQUAD_QQ')
with(w/'source.sing').open('w')as f:
 f.write('LIB "elim.lib";ring r=0,(a,e,d),dp;option(redSB);matrix Q[24][56];\n')
 for i,row in enumerate(A):
  for j,q in enumerate(row):
   if q:f.write(f'Q[{i+1},{j+1}]='+expr(q)+';\n')
 f.write('module taskM=Q;'+body)
q=json.loads((old/'source.json').read_text());q.update(field='QQ',prime=None,GF_source_pin=str(src),GF_source_pin_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),QQ_claim=False,known_open='a*P*F*B0*C*J != 0');(w/'source.json').write_text(json.dumps(q,indent=2)+'\n')
s=(old/'run.py').read_text().replace('raw-fourquad-GF-v36','raw-fourquad-QQ-v37');(w/'run.py').write_text(s)

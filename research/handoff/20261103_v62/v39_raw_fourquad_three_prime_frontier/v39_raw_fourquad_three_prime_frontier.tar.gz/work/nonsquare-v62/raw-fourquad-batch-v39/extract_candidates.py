from pathlib import Path
import gzip,json,math,hashlib
from fractions import Fraction
w=Path('work/nonsquare-v62/raw-fourquad-batch-v39');state=json.loads(gzip.decompress((w/'canonical-GB-state3.json.gz').read_bytes()));lms=sorted(map(tuple,state['GB_leading_monomials']));ids={lm:i for i,lm in enumerate(lms)};N=len(state['nonleading_terms']);ds=[1]*len(lms);counts=[0]*len(lms);data=[]
def rr(x,M):
 B=math.isqrt(M//2);r0,r1,t0,t1=M,x,0,1
 while abs(r1)>B:
  q=r0//r1;r0,r1=r1,r0-q*r1;t0,t1=t1,t0-q*t1
 if t1 and abs(t1)<=B and math.gcd(r1,t1)==1 and math.gcd(t1,M)==1:return Fraction(r1,t1)
 return None
stable=0
with(w/'nonleading-assess3.txt').open()as f:
 n,m1,m2=map(int,f.readline().split());assert n==N
 for(lm,key,cur),line in zip(state['nonleading_terms'],f):
  x,y=map(int,line.split());assert y==int(cur);cid=ids[tuple(lm)];counts[cid]+=1;data.append((cid,key,x,y));q1,q2=rr(x,m1),rr(y,m2)
  if q1 is not None and q1==q2:ds[cid]=math.lcm(ds[cid],q1.denominator);stable+=1
assert stable==18438
complete=[True]*len(lms);nums=[]
for cid,key,x,y in data:
 a=x*ds[cid]%m1;b=y*ds[cid]%m2
 if 2*a>m1:a-=m1
 if 2*b>m2:b-=m2
 complete[cid]&=a==b;nums.append(b)
selected=[i for i,v in enumerate(complete)if v];assert len(selected)==112;dest={c:i for i,c in enumerate(selected)};polys=[[{}for _ in selected]for _ in range(24)]
for cid in selected:lm=lms[cid];polys[lm[4]-1][dest[cid]][lm[:4]]=Fraction(1)
for(cid,key,x,y),b in zip(data,nums):
 if complete[cid]:polys[key[0]][dest[cid]][tuple(key[1:])]=Fraction(b,ds[cid])
with(w/'candidate112-native4.txt').open('w')as f:
 f.write('24 112 0\n')
 for row in polys:
  for q in row:f.write(str(len(q))+''.join(' '+str(c)+' '+' '.join(map(str,ex))for ex,c in sorted(q.items()))+'\n')
r=dict(candidate_only=True,QQ_GB_or_membership_not_verified=True,candidate_shape=[24,112],candidate_terms=sum(len(q)for row in polys for q in row),selected_canonical_GB_columns=selected,pooled_denominator_bits_max=max(d.bit_length()for d in ds),balanced_stable_by_own_Python_Euclid=stable,candidate_native_sha256=hashlib.sha256((w/'candidate112-native4.txt').read_bytes()).hexdigest());(w/'candidate112.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k!='selected_canonical_GB_columns'}),flush=True)

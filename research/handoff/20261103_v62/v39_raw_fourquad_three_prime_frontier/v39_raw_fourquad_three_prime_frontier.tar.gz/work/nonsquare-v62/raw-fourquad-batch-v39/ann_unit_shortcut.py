from pathlib import Path
import sympy as s,json,hashlib
p=32003;w=Path('work/nonsquare-v62/raw-fourquad-batch-v39');src=Path('work/nonsquare-v62/raw-fourquad-GF-v36/ann-native.txt');a,e,P=s.symbols('a e P');polys=[]
with src.open()as f:
 n,m,k=map(int,f.readline().split());assert(n,m,k)==(1,7,0)
 for j in range(m):
  terms={}
  for z in range(int(f.readline())):
   c,x,y,z=map(int,f.readline().split());terms[(x,y,z)]=c
  polys.append(s.Poly.from_dict(terms,(a,e,P),modulus=p))
c3=-6*pow(889,-1,p)%p;c2=(5+c3*9186)*pow(889,-1,p)%p;g=s.Poly(a**5*(5*P-6*e-4)**3,a,e,P,modulus=p);assert polys[2]*c2+polys[3]*c3==g
r=dict(GF_only=True,prime=p,ann_native_source=str(src),ann_native_source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),zero_based_generator_indices=[2,3],constant_coefficients=[c2,c3],exact_identity='c2*A[2]+c3*A[3]=a^5*(5P-6e-4)^3',target_totaldegree=8,QQ_claim=False,original_GF_rank41_not_claimed=True)
(w/'ann-unit-shortcut.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))

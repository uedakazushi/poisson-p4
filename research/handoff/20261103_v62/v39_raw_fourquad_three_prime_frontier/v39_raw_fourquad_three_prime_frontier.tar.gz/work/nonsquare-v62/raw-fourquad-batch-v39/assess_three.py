from pathlib import Path
import json,gzip
w=Path('work/nonsquare-v62/raw-fourquad-batch-v39');old=Path('work/nonsquare-v62/raw-fourquad-homogeneous-v38');primes=[32003,2147483647,2147483629];dirs=[old]+[w/str(p)for p in primes[1:]];termkey=lambda t:(sum(t[1]),*[-v for v in reversed(t[1])],t[0])
def read(p,d):
 with(d/'G-native4.txt').open()as f:
  n,m,k=map(int,f.readline().split());assert(n,m,k)==(24,925,0);cols=[[]for _ in range(m)]
  for i in range(n):
   for j in range(m):
    for _ in range(int(f.readline())):
     t=f.readline().split();cols[j].append((i,tuple(map(int,t[1:])),int(t[0])%p))
 C={};leading=set();terms=0
 for col in cols:
  i,ex,c=max(col,key=termkey);assert c==1;lm=(*ex,i+1);leading.add(lm)
  for ii,e,cc in col:
   terms+=1
   if ii+1==lm[4]and e==lm[:4]:continue
   C[(lm,(ii,*e))]=cc
 return C,leading,terms
allC=[];leading=None;states=[]
for p,d in zip(primes,dirs):
 C,L,terms=read(p,d)
 if leading is None:leading=L
 else:assert leading==L
 allC.append(C);states.append(dict(prime=p,terms=terms))
keys=sorted(set().union(*allC));R=[0]*len(keys);mod=1
for index,(p,C)in enumerate(zip(primes,allC)):
 inv=pow(mod,-1,p);R=[v+mod*((C.get(k,0)-v)*inv%p)for k,v in zip(keys,R)];mod*=p;states[index]['support_missing_zero_padded']=len(keys)-len(C)
 if index==1:Rprev=R.copy();modprev=mod
with(w/'nonleading-assess3.txt').open('w')as f:
 f.write(f'{len(keys)} {modprev} {mod}\n')
 for a,b in zip(Rprev,R):f.write(f'{a} {b}\n')
cache=gzip.compress(json.dumps(dict(primes=primes,modulus=str(mod),GB_leading_monomials=sorted(leading),nonleading_terms=[[list(lm),list(k),str(v)]for(lm,k),v in zip(keys,R)]),separators=(',',':')).encode(),mtime=0);assert len(cache)<32*1024**2;(w/'canonical-GB-state3.json.gz').write_bytes(cache)
r=dict(prime_count=3,primes=primes,modulus_bits=mod.bit_length(),nonleading_positions=len(keys),states=states,all_leading_monic_homogeneous_reduced=True,QQ_GB_or_module_equality_verified=False,derived_CRT_cache_bytes=len(cache));(w/'three-prime-assessment.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

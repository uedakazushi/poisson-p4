from pathlib import Path
import subprocess,json,hashlib,sys
w=Path('work/nonsquare-v62/raw-fourquad-batch-v39');old=Path('work/nonsquare-v62/raw-fourquad-homogeneous-v38');base=json.loads((old/'report.json').read_text());q0=json.loads((old/'source.json').read_text());done=[]
for p in [2147483647,2147483629]:
 subprocess.run([sys.executable,str(w/'prepare_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL);subprocess.run([sys.executable,str(w/'run_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL);d=w/str(p);r=json.loads((d/'run.json').read_text());assert r['exit_code']==0 and not r['timed_out'];log=(d/'run.log').read_text();assert'RAW_FOURQUAD_HOMOGENEOUS_GB_NATIVE_SAVED'in log and'?'not in log and'ERROR'not in log
 q=json.loads((d/'source.json').read_text())
 for key in ['matrix_QQ_sha256','fixed_QQ_column_degrees','row_degrees','Singular_order','homogenization','row_a_clear_shifts_by_quadric','cubic_monomials']:assert q[key]==q0[key],key
 subprocess.run([str(old/'check-reduced-bin'),str(d/'G-native4.txt'),str(p)],check=True,stdout=(d/'check-reduced.log').open('w'))
 with(d/'G-native4.txt').open()as f:
  n,m,k=map(int,f.readline().split());assert(n,m,k)==(24,925,0);L=[None]*m;terms=0
  for i in range(n):
   for j in range(m):
    for _ in range(int(f.readline())):
     terms+=1;t=f.readline().split();ex=tuple(map(int,t[1:]));key=(sum(ex),*[-v for v in reversed(ex)],i)
     if L[j]is None or key>L[j][0]:L[j]=(key,(*ex,i+1))
 sig=hashlib.sha256(repr(sorted(v[1]for v in L)).encode()).hexdigest();assert sig==base['GB_leading_module_sha256'],'leading module changed; inspect before more work'
 info=dict(prime=p,elapsed=r['elapsed_seconds'],max_rss_kib=r['max_rss_kib'],GB_terms=terms,same_leading_module=True,all_monic_homogeneous_fully_reduced=True);(d/'assessed.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True);done.append(p)
(w/'batch-result.json').write_text(json.dumps(dict(primes=[32003]+done,completed=done,QQ_claim=False),indent=2)+'\n')

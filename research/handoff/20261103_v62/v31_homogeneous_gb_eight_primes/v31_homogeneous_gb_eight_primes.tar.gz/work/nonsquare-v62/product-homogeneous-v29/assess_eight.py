from pathlib import Path
import json,gzip,hashlib
w=Path('work/nonsquare-v62/product-homogeneous-v29');primes=[32003,2147483647,2147483629]+json.loads((w/'batch8-primes.json').read_text());old=json.loads(gzip.decompress((w/'canonical-GB-state3.json.gz').read_bytes()));keys=[(tuple(lm),tuple(k))for lm,k,v in old['nonleading_terms']];R=[int(v)for lm,k,v in old['nonleading_terms']];mod=int(old['modulus']);leading=set(tuple(v)for v in old['GB_leading_monomials']);R7=None;mod7=None;states=[]
def termkey(t):i,ex,c=t;return(sum(ex),*[-v for v in reversed(ex)],i)
for p in primes[3:]:
 d=w/str(p);assert'HOMOGENEOUS_GB_NATIVE_SAVED'in(d/'run.log').read_text();assert json.loads((d/'run.json').read_text())['exit_code']==0
 with(d/'G-native4.txt').open()as f:
  n,m,k=map(int,f.readline().split());assert(n,m,k)==(10,739,0);cols=[[]for _ in range(m)]
  for i in range(n):
   for j in range(m):
    for z in range(int(f.readline())):
     t=f.readline().split();c=int(t[0])%p;ex=tuple(int(v)for v in t[1:]);cols[j].append((i,ex,c))
 C={};LM=set();terms=0
 for col in cols:
  i,ex,c=max(col,key=termkey);assert c==1;lm=(*ex,i+1);LM.add(lm)
  for ii,e,cc in col:
   terms+=1
   if ii+1==lm[4]and e==lm[:4]:continue
   C[(lm,(ii,*e))]=cc
 assert LM==leading and set(C)==set(keys),'support/leading changed; stopblindCRT'
 inv=pow(mod,-1,p);R=[v+mod*((C[key]-v)*inv%p)for key,v in zip(keys,R)];mod*=p
 if p==primes[-2]:R7=R.copy();mod7=mod
 states.append(dict(prime=p,terms=terms,monic_homogeneous_reduced_checked=True,same_leading_and_support=True))
with(w/'nonleading-assess8.txt').open('w')as f:
 f.write(f'{len(keys)} {mod7} {mod}\n')
 for a,b in zip(R7,R):f.write(f'{a} {b}\n')
(w/'canonical-GB-state8.json.gz').write_bytes(gzip.compress(json.dumps(dict(primes=primes,modulus=str(mod),GB_leading_monomials=sorted(leading),nonleading_terms=[[list(lm),list(k),str(r)]for(lm,k),r in zip(keys,R)]),separators=(',',':')).encode(),mtime=0))
report=dict(primes=primes,all_leading_modules_equal=True,all_monic_homogeneous_reduced=True,union_nonleading_coefficients=len(keys),small_prime_zero_padding=14,CRT_modulus_bits=mod.bit_length(),states=states,QQ_GB_or_module_equality_verified=False)
(w/'eight-prime-assessment.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2),flush=True)

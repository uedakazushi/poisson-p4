#!/usr/bin/env bash
set -e
source /workspace/cloud-setup/activate.sh
task_singular_prefix=/workspace/poisson-p4/work/nonsquare-v62/singular-runtime/prefix
export PATH="$task_singular_prefix/usr/bin:$PATH"
export SINGULARPATH="$task_singular_prefix/usr/lib/x86_64-linux-gnu/singular/MOD:/workspace/cloud-setup/prefix/usr/share/singular/LIB"
export SINGULAR_ROOT_DIR=/workspace/cloud-setup/prefix/usr
export SINGULAR_DATA_DIR=/workspace/cloud-setup/prefix/usr/share
export SINGULAR_PROCS_DIR="$task_singular_prefix/usr/lib/x86_64-linux-gnu/singular/MOD"
export SINGULAR_EXECUTABLE="$task_singular_prefix/usr/bin/Singular"
exec "$SINGULAR_EXECUTABLE" "$@"

from pathlib import Path
import re,sys,hashlib,json
w=Path('work/nonsquare-v62/product-field-v7');field=sys.argv[1];src=w/f'generic-{field}-QQ.sing';dst=w/f'generic-{field}-QQ-no-z.sing';text=src.read_text();text=text[:text.index('module I=M;')];text=text.replace(',z),dp;', '),dp;').replace('matrix M[14][60];','matrix M[14][46];');text=re.sub(r'M\[\d+,(?:4[7-9]|5\d|60)\]=z\*U-1;\n','',text);assert'z'not in text
text+='''module I=M;
print("PRODUCT_FIELD_NO_Z_INPUT_READY_'''+field+'''");
matrix T;
module G=liftstd(I,T);
print("PRODUCT_FIELD_NO_Z_GB_DONE_'''+field+'''");
write("'''+str((w/f'generic-{field}-QQ-no-z.gb.sing').resolve())+'''",G);
matrix E[14][14];for(int i=1;i<=14;i++){E[i,i]=1;}
module EE=E;
int found=0;
for(int n=1;n<=64;n=n*2){
 module target=U^n*EE;
 module red=reduce(target,G);
 print("SATURATION_POWER");print(n);print(size(red));
 if(size(red)==0){
  matrix Q=lift(G,target);
  matrix X=T*Q;
  matrix Y=U^n*E;
  if(M*X!=Y){ERROR("exact saturation inverse failed");}
  write("'''+str((w/f'generic-{field}-QQ-no-z.inverse.sing').resolve())+'''",X);
  print("EXACT_PRODUCT_FIELD_COKER_ZERO_NO_Z_'''+field+'''");print(n);found=1;break;
 }
}
if(found==0){print("NO_UNIT_CERTIFICATE_IN_BOUNDED_POWERS");}
quit;
''';dst.write_text(text);(w/f'generic-{field}-QQ-no-z.input.json').write_text(json.dumps(dict(input_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),localization='a F B C J d != 0',algorithm='exact 2-variable liftstd then bounded U^n inverse identity',coefficient_field=f'QQ({field})'),indent=2)+'\n')

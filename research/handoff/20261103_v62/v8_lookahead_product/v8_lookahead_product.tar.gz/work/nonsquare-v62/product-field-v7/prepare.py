from pathlib import Path
import sys,json,hashlib
w=Path('work/nonsquare-v62/product-field-v7');src=Path('work/nonsquare-product-alt-v62/mod-ell/chart-3-ad-residual.txt');field=sys.argv[1];names=['a','e','d'];assert field in names;dst=w/f'generic-{field}-QQ.sing';out=dst.open('w');out.write(f'ring R=(0,{field}),({",".join(x for x in names if x!=field)},z),dp;\nmatrix M[14][60];\n')
f=src.open();n,m,k=map(int,f.readline().split());assert(n,m,k)==(14,46,10);cols=list(map(int,f.readline().split()));rows=list(map(int,f.readline().split()));assert len(cols)==k and len(rows)==n
for i in range(n):
 for j in range(m):
  q=f.readline().split();nt=int(q[0]);assert len(q)==1+4*nt;terms=[]
  for k in range(nt):
   c=q[1+4*k];ex=map(int,q[2+4*k:5+4*k]);terms.append('('+c+')'+''.join('*'+v+(''if k==1 else'^'+str(k))for v,k in zip(names,ex)if k))
  if terms:out.write(f'M[{i+1},{j+1}]='+ '+'.join(terms)+';\n')
out.write('poly U=a*(500*a+90*e^2+3*e-24)*((50*a+18*e^2-9*e-2)*d+60*e-40)*(100*a+18*e^2-9*e-2)*(5*a*d-6*e-4)*d;\n')
for i in range(n):out.write(f'M[{i+1},{m+i+1}]=z*U-1;\n')
out.write('''module I=M;
print("PRODUCT_FIELD_INPUT_READY_'''+field+'''");
matrix T;
module G=liftstd(I,T);
print("PRODUCT_FIELD_GB_DONE_'''+field+'''");
matrix E[14][14];
for(int i=1;i<=14;i++){E[i,i]=1;}
module EE=E;
module red=reduce(EE,G);
write("'''+str((w/f'generic-{field}-QQ.gb.sing').resolve())+'''",G);
if(size(red)==0){
 matrix Q=lift(G,EE);
 matrix X=T*Q;
 if(M*X!=E){ERROR("exact product right inverse failed");}
 write("'''+str((w/f'generic-{field}-QQ.right-inverse.sing').resolve())+'''",X);
 print("EXACT_PRODUCT_FIELD_COKER_ZERO_'''+field+'''");
}else{
 print("EXACT_PRODUCT_FIELD_COKER_NONZERO_'''+field+'''");print(size(red));
}
quit;
''');out.close()
(w/f'generic-{field}-QQ.input.json').write_text(json.dumps(dict(source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),input_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),coefficient_field='QQ('+field+')',localization='a F B C J d != 0',source_shape=[14,46],exact_inverse_required=True),indent=2)+'\n')

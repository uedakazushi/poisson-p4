from pathlib import Path
from fractions import Fraction
w=Path('work/nonsquare-v62/product-field-v7');f=Path('work/nonsquare-product-alt-v62/mod-ell/chart-3-ad-residual.txt').open();n,m,k=map(int,f.readline().split());f.readline();f.readline();dst=w/'global-modp-slimgb.sing';p=32003
with dst.open('w')as out:
 out.write('ring R=32003,(a,e,d,z),dp;\nmatrix M[14][60];\n')
 for i in range(n):
  for j in range(m):
   q=f.readline().split();terms=[]
   for t in range(int(q[0])):
    c=Fraction(q[1+4*t]);assert c.denominator%p;v=c.numerator*pow(c.denominator,-1,p)%p
    if not v:continue
    if v>p//2:v-=p
    ex=map(int,q[2+4*t:5+4*t]);terms.append('('+str(v)+')'+''.join('*'+x+(''if k==1 else'^'+str(k))for x,k in zip(['a','e','d'],ex)if k))
   if terms:out.write(f'M[{i+1},{j+1}]='+ '+'.join(terms)+';\n')
 out.write('poly U=a*(500*a+90*e^2+3*e-24)*((50*a+18*e^2-9*e-2)*d+60*e-40)*(100*a+18*e^2-9*e-2)*(5*a*d-6*e-4)*d;\n')
 for i in range(n):out.write(f'M[{i+1},{m+i+1}]=z*U-1;\n')
 out.write('''module I=M;
print("GLOBAL_MODP_PRODUCT_INPUT_READY");
option(prot);
module G=slimgb(I);
print("GLOBAL_MODP_PRODUCT_GB_DONE");
write("'''+str((w/'global-modp-slimgb.gb.sing').resolve())+'''",G);
matrix E[14][14];for(int i=1;i<=14;i++){E[i,i]=1;}module EE=E;
module red=reduce(EE,G);
if(size(red)==0){print("DIAGNOSTIC_GLOBAL_MODP_COKER_ZERO");}
else{print("DIAGNOSTIC_GLOBAL_MODP_COKER_NONZERO");print(size(red));}
quit;
''')

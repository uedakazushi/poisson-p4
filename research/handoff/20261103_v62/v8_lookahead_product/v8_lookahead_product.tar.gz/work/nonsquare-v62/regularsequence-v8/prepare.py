from pathlib import Path
import json,itertools,hashlib
from fractions import Fraction
w=Path('work/nonsquare-v62/regularsequence-v8');src=Path('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json');data=json.loads(src.read_text());qfour=[{tuple(mon):{tuple(ex):Fraction(c)for ex,c in terms}for mon,terms in q}for q in data['cleared_qfour_sparse']];assert all(sum(mon)==2 and mon[6]==0 for q in qfour for mon in q)
def mons(n,d):
 if n==1:return[(d,)]
 return[(i,)+m for i in range(d+1)for m in mons(n-1,d-i)]
def rank(A,p):
 r=0
 for j in range(len(A[0])):
  i=next((i for i in range(r,len(A))if A[i][j]%p),None)
  if i is None:continue
  A[r],A[i]=A[i],A[r];z=pow(A[r][j]%p,-1,p);A[r]=[v*z%p for v in A[r]]
  for i in range(r+1,len(A)):
   z=A[i][j]%p
   if z:A[i]=[(a-z*b)%p for a,b in zip(A[i],A[r])]
  r+=1
  if r==len(A):return r
 return r
p=32003;scores=[];samples=(1,2,3)
for subset in itertools.combinations(range(6),4):
 qs=[]
 for q in qfour:
  out={}
  for mon,poly in q.items():
   if any(mon[i]for i in range(6)if i not in subset):continue
   out[tuple(mon[i]for i in subset)]=poly
  qs.append(out)
 rows=[{tuple(a+b for a,b in zip(mon,mu)):poly for mon,poly in q.items()}for q in qs for mu in mons(4,3)];columns=mons(4,5);assert(len(rows),len(columns))==(80,56)
 A=[[sum(int(c.numerator)%p*pow(int(c.denominator)%p,-1,p)*pow(samples[0],ex[0],p)*pow(samples[1],ex[1],p)*pow(samples[2],ex[2],p)for ex,c in row.get(mon,{}).items())%p for mon in columns]for row in rows];r=rank(A,p);cost=sum(len(v)for row in rows for v in row.values());scores.append((r,cost,subset))
 if r==56:
  dst=w/('section-'+''.join(map(str,subset))+'.txt')
  with dst.open('w')as f:
   f.write('80 56 56\n')
   for row in rows:
    for mon in columns:
     poly=row.get(mon,{});f.write(str(len(poly)))
     for ex,c in sorted(poly.items(),reverse=True):f.write(' '+str(c)+' '+' '.join(map(str,ex)))
     f.write('\n')
(w/'scores.json').write_text(json.dumps(dict(source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),sample=list(samples),prime=p,scores=scores),indent=2)+'\n');print(sorted(scores,reverse=True))

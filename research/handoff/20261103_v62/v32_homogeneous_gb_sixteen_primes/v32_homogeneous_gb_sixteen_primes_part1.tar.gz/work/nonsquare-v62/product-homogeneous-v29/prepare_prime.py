from pathlib import Path
from fractions import Fraction
import json,hashlib,sys
p=int(sys.argv[1]);w=Path('work/nonsquare-v62/product-homogeneous-v29')/str(p);w.mkdir(exist_ok=True);source=Path('work/nonsquare-v62/primitive-unit-span-v9/full26.txt');keep=json.loads(Path('work/nonsquare-v62/product-module-v25/source.json').read_text())['retained_columns'];A=[]
with source.open()as f:
 assert list(map(int,f.readline().split()))==[26,60,1];f.readline();f.readline()
 for i in range(10):
  row=[]
  for j in range(60):
   t=f.readline().split();n=int(t[0]);q={}
   for z in range(n):
    c=Fraction(t[1+4*z]);ex=tuple(int(v)for v in t[2+4*z:5+4*z]);q[ex]=c
   if j in keep:row.append(q)
   else:assert not q
  assert len(row)==53;A.append(row)
deg=[max(sum(ex)for row in A for ex in row[j])for j in range(53)];B=[];terms=0
for row in A:
 out=[]
 for j,q in enumerate(row):
  r={}
  for ex,c in q.items():
   assert c.denominator%p;hom=(*ex,deg[j]-sum(ex));assert min(hom)>=0 and sum(hom)==deg[j];v=c.numerator*pow(c.denominator,-1,p)%p
   if v:r[hom]=v if v<=p//2 else v-p
  terms+=len(r);out.append(r)
 B.append(out)
expr=lambda q:'('+(' + '.join(str(c)+''.join('*'+v+('^'+str(k)if k!=1 else '')for v,k in zip(('a','e','d','w'),ex)if k)for ex,c in q.items())or'0')+')'
with(w/'source.sing').open('w')as f:
 f.write('ring r='+str(p)+',(a,e,d,w),(dp,C);matrix Q[10][53];\n')
 for i,row in enumerate(B):
  for j,q in enumerate(row):
   if q:f.write(f'Q[{i+1},{j+1}]='+expr(q)+';\n')
 f.write('module taskM=Q;option(redSB);print("HOMOGENEOUS_INPUT_READY");module taskG=slimgb(taskM);print("HOMOGENEOUS_GB_DONE");print(ncols(matrix(taskG)));if(size(reduce(taskM,taskG))!=0){print("ERROR_SOURCE_INCLUSION");quit;}matrix taskGM=matrix(taskG);int taskRows=nrows(taskGM);int taskCols=ncols(taskGM);link taskOut="ASCII:w '+str((w/'G-native4.txt').resolve())+'";open(taskOut);write(taskOut,string(taskRows)+" "+string(taskCols)+" 0");int taskI,taskJ;int taskD;int taskMaxD=0;int taskTerms=0;poly taskP;intvec taskEx;for(taskJ=1;taskJ<=taskCols;taskJ++){taskD=-1;for(taskI=1;taskI<=taskRows;taskI++){taskP=taskGM[taskI,taskJ];while(taskP!=0){taskEx=leadexp(taskP);if(taskD<0){taskD=taskEx[1]+taskEx[2]+taskEx[3]+taskEx[4];}if(taskD!=taskEx[1]+taskEx[2]+taskEx[3]+taskEx[4]){print("ERROR_GB_COLUMN_NOT_HOMOGENEOUS");quit;}taskP=taskP-lead(taskP);}}if(taskD>taskMaxD){taskMaxD=taskD;}}for(taskI=1;taskI<=taskRows;taskI++){for(taskJ=1;taskJ<=taskCols;taskJ++){taskP=taskGM[taskI,taskJ];taskTerms=taskTerms+size(taskP);write(taskOut,string(size(taskP)));while(taskP!=0){taskEx=leadexp(taskP);write(taskOut,string(leadcoef(taskP))+" "+string(taskEx[1])+" "+string(taskEx[2])+" "+string(taskEx[3])+" "+string(taskEx[4]));taskP=taskP-lead(taskP);}}}close(taskOut);print("HOMOGENEOUS_GB_TERMS");print(taskTerms);print("HOMOGENEOUS_GB_MAX_DEGREE");print(taskMaxD);print("HOMOGENEOUS_GB_NATIVE_SAVED");quit;')
(w/'source.json').write_text(json.dumps(dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),exact_source_rows=list(range(10)),retained_columns=keep,QQ_column_degrees=deg,row_degrees=[0]*10,polynomial_variables=['a','e','P','w'],Singular_order='(dp,C)',homogenization='Each full source column to its fixed QQ maximum degree, before reduction modp',prime=p,input_terms=terms,all_columns_homogeneous=True,all_source_denominators_prime_units=True,QQ_claim=False),indent=2)+'\n');print('HOMOGENEOUS_SOURCE_PREPARED',terms,'degrees',min(deg),max(deg),flush=True)

from pathlib import Path
import subprocess,sys,concurrent.futures,threading,json,hashlib
from sympy import prevprime
w=Path('work/nonsquare-v62/product-homogeneous-v29');baseline=json.loads((w/'three-prime-assessment.json').read_text());expected=baseline['states'][0]['leading_signature'];source0=json.loads((w/'32003/source.json').read_text());p=2147483543;primes=[]
for _ in range(8):p=int(prevprime(p));primes.append(p)
(w/'batch16-primes.json').write_text(json.dumps(primes)+'\n');stop=threading.Event()
def one(p):
 if stop.is_set():return None
 subprocess.run([sys.executable,str(w/'prepare_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL);subprocess.run([sys.executable,str(w/'run_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL);d=w/str(p);r=json.loads((d/'run.json').read_text());assert r['exit_code']==0 and not r['timed_out'];log=(d/'run.log').read_text();assert'HOMOGENEOUS_GB_NATIVE_SAVED'in log and'?'not in log and'ERROR'not in log
 q=json.loads((d/'source.json').read_text())
 for key in ['source_sha256','QQ_column_degrees','row_degrees','Singular_order','retained_columns','homogenization']:assert q[key]==source0[key],key
 subprocess.run([str(w/'check-reduced-prime-bin'),str(d/'G-native4.txt'),str(p)],check=True,stdout=(d/'check-reduced.log').open('w'))
 with(d/'G-native4.txt').open()as f:
  n,m,k=map(int,f.readline().split());assert(n,m,k)==(10,739,0);L=[None]*m;terms=0
  for i in range(n):
   for j in range(m):
    count=int(f.readline());terms+=count
    for z in range(count):
     t=f.readline().split();ex=tuple(int(v)for v in t[1:]);key=(sum(ex),*[-v for v in reversed(ex)],i)
     if L[j]is None or key>L[j][0]:L[j]=(key,(*ex,i+1))
 sig=hashlib.sha256(repr(sorted(v[1]for v in L)).encode()).hexdigest()
 if sig!=expected:stop.set();raise RuntimeError('leading module changed '+str(p))
 info=dict(prime=p,elapsed=r['elapsed_seconds'],max_rss_kib=r['max_rss_kib'],GB_terms=terms,same_leading_module=True,all_monic_homogeneous_and_fully_reduced=True);(d/'assessed.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps(info),flush=True);return p
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:done=list(pool.map(one,primes))
(w/'batch16-result.json').write_text(json.dumps(dict(primes=primes,completed=done,QQ_claim=False),indent=2)+'\n')

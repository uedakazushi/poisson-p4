from pathlib import Path
import json,hashlib,tarfile,gzip
root=Path('.');w=Path('work/nonsquare-v62/product-homogeneous-v29');out=Path('research/handoff/20261103_v62/v32_homogeneous_gb_sixteen_primes');out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
primes=json.loads((w/'batch16-primes.json').read_text());states=[]
for p in primes:
 d=w/str(p);a=json.loads((d/'assessed.json').read_text());assert a['all_monic_homogeneous_and_fully_reduced'] and a['same_leading_module'];states.append(a)
rec=[json.loads(x)for x in(w/'nonleading-reconstruction16.jsonl').read_text().splitlines()];balanced=next(x for x in rec if x['denominator_bound_bits']==0)
common=['freeze16.py','prepare_prime.py','run_prime.py','run_batch16.py','assess_extra.py','assess_asymmetric_extended.cpp','check_reduced_prime.cpp','batch16-primes.json','batch16-result.json','12-prime-assessment.json','16-prime-assessment.json','nonleading-reconstruction12.jsonl','nonleading-reconstruction16.jsonl','source-height.json','safe21-product-height.json','degree30-target.json','degree44-target.json']
archives=[]
for part,ps in enumerate((primes[:4],primes[4:]),1):
 files=[]
 for p in ps:
  files += [w/str(p)/name for name in ['G-native4.txt','assessed.json','check-reduced.log','run.json','run.log','source.json']]
 if part==1:files += [w/name for name in common]
 files=sorted(set(files));target=out/f'v32_homogeneous_gb_sixteen_primes_part{part}.tar.gz'
 with tarfile.open(target,'w:gz',compresslevel=9)as t:
  for f in files:t.add(f,arcname=str(f),recursive=False)
 assert target.stat().st_size<32*1024**2
 archives.append(dict(path=str(target),bytes=target.stat().st_size,sha256=sha(target),members=[dict(path=str(f),bytes=f.stat().st_size,sha256=sha(f))for f in files]))
cache=w/'canonical-GB-state16.json.gz'
status=dict(frozen=True,QQ_claim=False,prime_count=16,CRT_modulus_bits=480,GB_shape=[10,739],GB_degree_max=29,all_same_fixed_QQ_column_degrees=True,row_degrees=[0]*10,order='(dp,C)',all_monic_homogeneous_fully_reduced=True,all_same_leading_module=True,nonleading_union_coefficients=506068,small_prime_missing_coefficients_zero_padded=14,stable_NONLEADING_previous_current_balanced=balanced['same_previous_current'],stable_fraction=balanced['same_previous_current']/506068,stable_balanced_height_bits=224,observed_stable_asymmetric_den128_numerator_bits_up_to=320,QQ_GB_coefficient_height_bound_not_proved=True,QQ_GB_and_Ih_equality_not_verified=True,prime_route_stopped_at16=True,source_QQ_heights=dict(numerator_bits_max=217,denominator_bits_max=222),next_single_lower_height_safe21_pilot_authorized=True)
(out/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
deps=[]
for d in ['v29_homogeneous_gb_pilot','v30_homogeneous_gb_three_primes','v31_homogeneous_gb_eight_primes']:
 f=out.parent/d/'manifest.json';deps.append(dict(path=str(f),sha256=sha(f)))
manifest=dict(frozen=True,archives=archives,dependencies=deps,derived_cache_omitted_reproducible=dict(path=str(cache),bytes=cache.stat().st_size,sha256=sha(cache),replay='python work/nonsquare-v62/product-homogeneous-v29/assess_extra.py 16'),QQ_claim=False)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(archives=[{k:v for k,v in a.items()if k!='members'}for a in archives],status=status)))

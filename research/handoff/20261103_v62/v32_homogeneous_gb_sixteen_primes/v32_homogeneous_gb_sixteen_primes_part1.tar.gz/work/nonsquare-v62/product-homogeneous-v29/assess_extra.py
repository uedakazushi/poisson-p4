from pathlib import Path
import json,gzip,sys,time
w=Path('work/nonsquare-v62/product-homogeneous-v29');count=int(sys.argv[1]);assert count in [12,16];base=json.loads(gzip.decompress((w/'canonical-GB-state8.json.gz').read_bytes()));primes=base['primes']+json.loads((w/'batch16-primes.json').read_text());primes=primes[:count];keys=[(tuple(lm),tuple(k))for lm,k,v in base['nonleading_terms']];R=[int(v)for lm,k,v in base['nonleading_terms']];mod=int(base['modulus']);leading=set(map(tuple,base['GB_leading_monomials']));del base;Rprev=None;modprev=None;states=[]
termkey=lambda t:(sum(t[1]),*[-v for v in reversed(t[1])],t[0])
for p in primes[8:]:
 d=w/str(p);assert(d/'assessed.json').exists(),'Wait for completedreducedaudit at '+str(p)
 with(d/'G-native4.txt').open()as f:
  n,m,k=map(int,f.readline().split());assert(n,m,k)==(10,739,0);cols=[[]for _ in range(m)]
  for i in range(n):
   for j in range(m):
    for z in range(int(f.readline())):
     t=f.readline().split();cols[j].append((i,tuple(map(int,t[1:])),int(t[0])%p))
 C={};LM=set();terms=0
 for col in cols:
  i,ex,c=max(col,key=termkey);assert c==1;lm=(*ex,i+1);LM.add(lm)
  for ii,e,cc in col:
   terms+=1
   if ii+1==lm[4]and e==lm[:4]:continue
   C[(lm,(ii,*e))]=cc
 assert LM==leading and not(set(C)-set(keys)),'leading/newsupport changed; inspect beforecontinuing'
 missing=len(set(keys)-set(C));inv=pow(mod,-1,p);R=[v+mod*((C.get(key,0)-v)*inv%p)for key,v in zip(keys,R)];mod*=p
 if p==primes[-2]:Rprev=R.copy();modprev=mod
 states.append(dict(prime=p,terms=terms,support_missing_zero_padded=missing,all_leading_monic_homogeneous_reduced=True))
assert Rprev is not None
with(w/f'nonleading-assess{count}.txt').open('w')as f:
 f.write(f'{len(keys)} {modprev} {mod}\n')
 for a,b in zip(Rprev,R):f.write(f'{a} {b}\n')
(w/f'canonical-GB-state{count}.json.gz').write_bytes(gzip.compress(json.dumps(dict(primes=primes,modulus=str(mod),GB_leading_monomials=sorted(leading),nonleading_terms=[[list(lm),list(k),str(v)]for(lm,k),v in zip(keys,R)]),separators=(',',':')).encode(),mtime=0))
r=dict(prime_count=count,primes=primes,modulus_bits=mod.bit_length(),nonleading_positions=len(keys),states=states,QQ_GB_or_module_equality_verified=False);(w/f'{count}-prime-assessment.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

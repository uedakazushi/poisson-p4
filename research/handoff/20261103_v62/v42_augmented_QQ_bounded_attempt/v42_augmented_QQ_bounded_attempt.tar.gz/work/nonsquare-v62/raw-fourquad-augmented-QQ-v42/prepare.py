from pathlib import Path
from fractions import Fraction
import json,hashlib
w=Path('work/nonsquare-v62/raw-fourquad-augmented-QQ-v42');src=Path('work/nonsquare-v62/raw-fourquad-GF-v36/M-QQ-native.txt');seed=Path('work/nonsquare-v62/raw-fourquad-batch-v39/candidate112-native4.txt');A=[];S=[]
for path,target,dims,hom in [(src,A,(24,56,0),True),(seed,S,(24,112,0),False)]:
 with path.open()as f:
  n,m,k=map(int,f.readline().split());assert(n,m,k)==dims
  for i in range(n):
   row=[]
   for j in range(m):
    ts=f.readline().split();z=int(ts[0]);q={};sz=4 if hom else 5;assert len(ts)==1+sz*z
    for t in range(z):
     c=Fraction(ts[1+sz*t]);ex=tuple(map(int,ts[2+sz*t:1+sz*(t+1)]));
     if hom:ex=(*ex,7-sum(ex))
     assert min(ex)>=0;q[ex]=c
    row.append(q)
   target.append(row)
  assert not f.read().strip()
Q=[a+s for a,s in zip(A,S)];expr=lambda q:'('+(' + '.join('('+str(c)+')'+''.join('*'+v+('^'+str(k)if k!=1 else'')for v,k in zip(('a','e','d','w'),ex)if k)for ex,c in q.items())or'0')+')'
old=Path('work/nonsquare-v62/raw-fourquad-homogeneous-v38/source.sing').read_text();tail='module taskM=Q;'+old.split('module taskM=Q;',1)[1];tail=tail.replace('RAW_FOURQUAD_HOMOGENEOUS','AUGMENTED_QQ_HOMOGENEOUS').replace(str(Path('work/nonsquare-v62/raw-fourquad-homogeneous-v38/G-native4.txt').resolve()),str((w/'G-native4.txt').resolve()));tail=tail.rsplit('quit;',1)[0]+'module taskCheck;int taskK;for(taskK=1;taskK<=ncols(matrix(taskG));taskK++){taskCheck[taskK]=taskG[taskK];}attrib(taskCheck,"isSB",0);module taskChecked=std(taskCheck);if(size(reduce(taskG,taskChecked))!=0||size(reduce(taskChecked,taskG))!=0){print("ERROR_QQ_FRESH_STD_EQUALITY");quit;}print("AUGMENTED_QQ_FRESH_STD_VERIFIED");quit;'
with(w/'source.sing').open('w')as f:
 f.write('ring r=0,(a,e,d,w),(dp,C);matrix Q[24][168];\n')
 for i,row in enumerate(Q):
  for j,q in enumerate(row):
   if q:f.write(f'Q[{i+1},{j+1}]='+expr(q)+';\n')
 f.write(tail)
r=dict(original_source=str(src),original_source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),original_source_homogenization='All56 whole columns to fixed QQ degree7, target shifts0',candidate_seed_source=str(seed),candidate_seed_source_sha256=hashlib.sha256(seed.read_bytes()).hexdigest(),total_columns=168,original_columns=56,candidate_columns=112,only44_degree7_seeds_exact_QQ_member_certified=True,remaining68_seeds_are_guesses=True,QQ_claim=False,eventual_acceptance='Complete QQ GB + exact original homogeneous containment + p-integral monic + same-good-prime homogeneous equality + graded HF bridge; localized QQ membership further required');(w/'source.json').write_text(json.dumps(r,indent=2)+'\n')
s=Path('work/nonsquare-v62/raw-fourquad-QQ-v37/run.py').read_text().replace('raw-fourquad-QQ-v37','raw-fourquad-augmented-QQ-v42');(w/'run.py').write_text(s)

from pathlib import Path
from fractions import Fraction
import hashlib,json
w=Path('work/nonsquare-v62/raw-fourquad-GF-v36');src=Path('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json');data=json.loads(src.read_text());assert data['all_passed'];p=32003
for name,sha in data['input_sha256'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha,name
qs=[];shifts=[];input_core_terms=0
for row in data['cleared_qfour_sparse']:
 shift=max(0,max(ex[2]-ex[0]for mon,terms in row for ex,co in terms));shifts.append(shift);q={}
 for mon,terms in row:
  assert len(mon)==7 and mon[6]==0 and sum(mon)==2;v={}
  for ex,co in terms:
   c=Fraction(co);assert c.denominator%p;ee=(ex[0]-ex[2]+shift,ex[1],ex[2]);assert min(ee)>=0;v[ee]=c;input_core_terms+=1
  q[tuple(mon[:6])]=v
 qs.append(q)
assert shifts==[0,2,2,1] and input_core_terms==804
products=[]
for q in qs:
 for k in range(6):products.append({tuple(a+int(k==i)for i,a in enumerate(mon)):co for mon,co in q.items()})
mons=sorted(set().union(*products));assert len(mons)==56;A=[[row.get(m,{})for m in mons]for row in products];assert sum(len(q)for row in A for q in row)==4824
with(w/'M-QQ-native.txt').open('w')as f:
 f.write('24 56 0\n')
 for row in A:
  for q in row:f.write(str(len(q))+''.join(' '+str(c)+' '+' '.join(map(str,e))for e,c in sorted(q.items()))+'\n')
expr=lambda q:'('+(' + '.join(str(c.numerator*pow(c.denominator,-1,p)%p)+''.join('*'+v+('^'+str(k)if k!=1 else'')for v,k in zip(('a','e','d'),ex)if k)for ex,c in q.items())or'0')+')'
with(w/'source.sing').open('w')as f:
 f.write('LIB "elim.lib";ring r=32003,(a,e,d),dp;option(redSB);matrix Q[24][56];\n')
 for i,row in enumerate(A):
  for j,q in enumerate(row):
   if q:f.write(f'Q[{i+1},{j+1}]='+expr(q)+';\n')
 f.write('module taskM=Q;print("RAW_FOURQUAD_INPUT_READY");module taskG=slimgb(taskM);print("RAW_FOURQUAD_GB_DONE");print(ncols(matrix(taskG)));if(size(reduce(taskM,taskG))!=0){print("ERROR_SOURCE_INCLUSION");quit;}ideal taskA=quotient(taskG,freemodule(24));print("RAW_FOURQUAD_ANN_DONE");print(size(taskA));print(dim(std(taskA)));poly taskU=a*d*(500*a+90*e^2+3*e-24)*((50*a+18*e^2-9*e-2)*d+(60*e-40)*a)*(100*a+18*e^2-9*e-2)*(5*d-6*e-4);ideal taskS=std(sat(taskA,ideal(taskU))[1]);print("RAW_FOURQUAD_SAT_DONE");print(size(taskS));print(dim(taskS));if(reduce(1,taskS)==0){print("RAW_FOURQUAD_SAT_UNIT");}else{print("RAW_FOURQUAD_SAT_NONUNIT");}matrix taskN;int taskI,taskJ;poly taskP;intvec taskEx;link taskOut;\n')
 for name,var in [('G', 'taskG'),('ann','taskA'),('sat','taskS')]:
  f.write('taskN=matrix('+var+');taskOut="ASCII:w '+str((w/(name+'-native.txt')).resolve())+'";open(taskOut);write(taskOut,string(nrows(taskN))+" "+string(ncols(taskN))+" 0");for(taskI=1;taskI<=nrows(taskN);taskI++){for(taskJ=1;taskJ<=ncols(taskN);taskJ++){taskP=taskN[taskI,taskJ];write(taskOut,string(size(taskP)));while(taskP!=0){taskEx=leadexp(taskP);write(taskOut,string(leadcoef(taskP))+" "+string(taskEx[1])+" "+string(taskEx[2])+" "+string(taskEx[3]));taskP=taskP-lead(taskP);}}}close(taskOut);\n')
 f.write('print("RAW_FOURQUAD_SAVED");quit;\n')
info=dict(source_report=str(src),source_report_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),source_actual_quadric_indices=[0,1,3,5],light_coordinates=data['light_coordinate_order'],substitution='d_old=P/a, third native coordinate d denotes P',row_a_clear_shifts_by_quadric=shifts,source_quad_core_terms=804,matrix_shape=[24,56],matrix_terms=4824,source_all_denominators_prime_units=True,prime=p,known_units=['a','P','500a+90e^2+3e-24','(50a+18e^2-9e-2)P+(60e-40)a','100a+18e^2-9e-2','5P-6e-4'],QQ_claim=False,criterion='STRONGER raw24 product row surjectivity; sufficient with prior17 kernel directions for QQ original41 ONLY after separate QQ proof',matrix_QQ_sha256=hashlib.sha256((w/'M-QQ-native.txt').read_bytes()).hexdigest(),cubic_monomials=mons)
(w/'source.json').write_text(json.dumps(info,indent=2)+'\n');print('RAW_FOURQUAD_SOURCE_PREPARED',flush=True)

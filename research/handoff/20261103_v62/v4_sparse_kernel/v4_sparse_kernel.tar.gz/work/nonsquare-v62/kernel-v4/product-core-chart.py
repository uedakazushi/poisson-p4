from pathlib import Path
import json,hashlib
wd=Path('work/nonsquare-v62/kernel-v4');src=wd/'full-minus-14-48-55';dst=wd/'P-chart-full';mult=[]
with src.open()as f,dst.open('w')as out:
 n,m,target=map(int,f.readline().split());out.write(f'{n} {m} {target}\n')
 for i in range(n):
  row=[];low=0
  for j in range(m):
   z=f.readline().split();nt=int(z[0]);ts=[]
   for t in range(nt):
    c=z[1+4*t];a,e,d=map(int,z[2+4*t:5+4*t]);ts.append((c,a-d,e,d));low=min(low,a-d)
   row.append(ts)
  shift=-low;mult.append(shift)
  for ts in row:out.write(str(len(ts))+''.join(f' {c} {a+shift} {e} {P}'for c,a,e,P in ts)+'\n')
# Native third serialized coefficient slot is named d; it represents P=a*d.
(wd/'P-chart-units').write_text('a\n500*a+90*e^2+3*e-24\n(50*a+18*e^2-9*e-2)*d+(60*e-40)*a\n100*a+18*e^2-9*e-2\n5*d-6*e-4\nd\n')
report=dict(source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),output=str(dst),output_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),coefficient_coordinates=['a','e','P'],native_third_slot_name='d',coordinate_identity='P=a*old_d; old_d=P/a',row_multiplier_powers_of_a=mult,known_units=['a','500a+90e²+3e−24','(50a+18e²−9e−2)P+(60e−40)a=a*old_B','100a+18e²−9e−2','5P−6e−4','P'],scope='Explicit invertible coefficient chart and known-unit row scalings on a*old_d*F*old_B*C*old_J nonzero. No rank assertion.')
(wd/'P-chart.json').write_text(json.dumps(report,indent=2)+'\n');print('P_CHART_READY',n,m,'a shifts',mult)

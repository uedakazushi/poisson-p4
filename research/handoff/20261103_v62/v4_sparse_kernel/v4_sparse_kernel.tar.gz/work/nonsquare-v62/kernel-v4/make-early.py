from pathlib import Path
s=Path('work/nonsquare-v62/kernel-v4/sparse-certified-kernel.cpp').read_text();a=s.index('vector<int>free;for(int i=0;i<nu0;i++)');b=s.index('ofstream out(argv[3]);out<<S.size()',a);body=s[a:b]
body=body.replace('assert((int)free.size()==dim);','assert((int)free.size()==nu0-(int)chosen.size());')
body=body.replace('cerr<<"RATIONAL_RECONSTRUCTION_NEEDS_MORE_PRIMES "<<f<<\' \'<<i<<\'\\n\';return 4;','fmpz_clear(modulus);fmpz_clear(residue);return false;')
body=body.replace('cerr<<"EXACT_FULL_IDENTITY_FAILED "<<f<<\' \'<<j<<\'\\n\';return 3;','fmpz_clear(modulus);fmpz_clear(residue);return false;')
body+='fmpz_clear(modulus);fmpz_clear(residue);certifiedS=move(S);return true;'
s=s[:a]+'if(!earlyCertified&&!tryCertificate()){cerr<<"FINAL_QQ_KERNEL_RECONSTRUCTION_NOT_CERTIFIED\\n";return 4;}auto&S=certifiedS;\n'+s[b:]
s=s.replace('fmpq_clear(q);fmpz_clear(modulus);fmpz_clear(residue);','fmpq_clear(q);')
needle='for(int e:eqorder){Row row=equations[e];'
insert='vector<vector<P>>certifiedS;bool earlyCertified=false;int lastTriedRank=-1;auto tryCertificate=[&]()->bool{'+body+'};\n'+needle
assert needle in s;s=s.replace(needle,insert)
s=s.replace('processed++;if((int)chosen.size()==nu0)break;if(processed%10000==0)', 'processed++;if((int)chosen.size()==nu0)break;if((int)chosen.size()>=nu0-8&&lastTriedRank!=(int)chosen.size()){lastTriedRank=chosen.size();if(tryCertificate()){earlyCertified=true;cerr<<"EARLY_EXACT_QQ_KERNEL_CERTIFICATE RANK "<<chosen.size()<<" PROCESSED "<<processed<<\'\\n\';break;}}if(processed%10000==0)')
Path('work/nonsquare-v62/kernel-v4/sparse-early-certified-kernel.cpp').write_text(s)
# Immutable full63 source remains unchanged.
f=Path('work/nonsquare-v62/fresh-cubic/syzygies-normalized-degree1.normalized-input').open();n,m,target=map(int,f.readline().split())
with Path('work/nonsquare-v62/kernel-v4/full-minus-14-48-55').open('w')as out:
 out.write(f'{n-3} {m} {target}\n')
 for i in range(n):
  for j in range(m):
   line=f.readline()
   if i not in [14,48,55]:out.write(line)

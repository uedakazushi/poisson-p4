from pathlib import Path
import json,time,sys
import sympy as s
from sympy.polys.rings import ring
wd=Path('work/nonsquare-v62/kernel-v4');start=time.time();data=json.loads(Path('work/nonsquare-v62/fresh-cubic/report.json').read_text());mons=[tuple(x)for x in data['normal_monomials']];R,a,e,d=ring('a,e,d',s.QQ);K=R.to_field();P,*v=ring('v0,v1,v2,v3,v4,v5,v6,v7',K)
qdata=json.loads(Path('reports/S61_BINARY_HYPERPLANE_QUADRATIC_CODIMENSION_20261102.json').read_text());qs=[P.from_dict({tuple(mon):K(R.from_dict({tuple(mm):s.QQ(c)for mm,c in terms}))for mon,terms in row})for row in qdata['quadratic_rows_sparse']]
known=[a,500*a+90*e**2+3*e-24,(50*a+18*e**2-9*e-2)*d+60*e-40,100*a+18*e**2-9*e-2,d,5*a*d-6*e-4]
def unit(p):
 if not p:return False
 for f in known:
  while p.rem(f)==0:p=p.exquo(f)
 return p.is_ground
with Path('work/nonsquare-v62/fresh-cubic/full').open()as f:
 n,m,_=map(int,f.readline().split());records=[]
 for i in range(n):
  row={};heavy=False
  for j in range(m):
   z=f.readline().split();nt=int(z[0]);
   if i<42 or not nt:continue
   p=R.from_dict({tuple(map(int,z[2+4*t:5+4*t])):s.QQ(z[1+4*t])for t in range(nt)});row[mons[j]]=K(p);heavy|=bool(mons[j][5])
  if i<42:continue
  if heavy:print('SKIP_HEAVY',i,flush=True);continue
  poly=P.from_dict(row);print('PURE_LIGHT',i,len(poly),flush=True)
  for qi,q in enumerate(qs):
   quot,rem=divmod(poly,q)
   if rem:continue
   assert q*quot==poly;assert all(sum(mon)==1 for mon in quot);assert all(unit(c.denom)for c in quot.values())
   rec=dict(row=i,quadric=qi,quotient=str(quot));records.append(rec);print('EXACT_SINGLE_QUAD_MULTIPLE',rec,flush=True);break
(wd/'single-quad-divisibility-report.json').write_text(json.dumps(dict(records=records,seconds=time.time()-start,scope='Exact identities for listed rows only; not a full cubic-rank proof.'),indent=2)+'\n')

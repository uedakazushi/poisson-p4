from pathlib import Path
from fractions import Fraction
import math,json,sympy as s,hashlib
w=Path('work/nonsquare-v62/raw-fourquad-ann-comparison-v45');primes=[32003,2147483647,2147483629];paths=[Path('work/nonsquare-v62/raw-fourquad-GF-v36/ann-native.txt')]+[w/str(p)/'ann-native.txt'for p in primes[1:]]
key=lambda ex:(sum(ex),*[-v for v in reversed(ex)])
def read(path,p):
 ts=iter(path.read_text().split());n,m,flag=[int(next(ts))for _ in range(3)];assert(n,m,flag)==(1,7,0);out={};order=[]
 for j in range(m):
  q={}
  for _ in range(int(next(ts))):
   c=int(next(ts))%p;ex=tuple(int(next(ts))for _ in range(3));q[ex]=c
  lm=max(q,key=key);c=q[lm];q={ex:v*pow(c,-1,p)%p for ex,v in q.items()};out[lm]=q;order.append(lm)
 return out,order
allP=[];order0=None
for p,path in zip(primes,paths):
 P,order=read(path,p);allP.append(P)
 if order0 is None:order0=order
 else:assert set(P)==set(allP[0])
def rr(x,M):
 B=math.isqrt(M//2);r0,r1,t0,t1=M,x,0,1
 while abs(r1)>B:q=r0//r1;r0,r1=r1,r0-q*r1;t0,t1=t1,t0-q*t1
 if t1 and abs(t1)<=B and math.gcd(r1,t1)==1 and math.gcd(t1,M)==1:return Fraction(r1,t1)
 return None
cands=[];stats=[];a,e,P=s.symbols('a e P')
for j,lm in enumerate(order0):
 exs=sorted(set().union(*(Q[lm]for Q in allP)));R=[0]*len(exs);mod=1
 for i,(p,Q)in enumerate(zip(primes,allP)):
  inv=pow(mod,-1,p);R=[v+mod*((Q[lm].get(ex,0)-v)*inv%p)for ex,v in zip(exs,R)];mod*=p
  if i==1:prev=R.copy();prevmod=mod
 qs=[rr(x,mod)for x in R];qsp=[rr(x,prevmod)for x in prev];stable=sum(x is not None and x==y for x,y in zip(qs,qsp));poly=sum(s.Rational(x.numerator,x.denominator)*a**ex[0]*e**ex[1]*P**ex[2]for ex,x in zip(exs,qs)if x is not None);stats.append(dict(old_zero_based_generator=j,leading_monomial=lm,terms=len(exs),stable=stable,reconstructed=sum(x is not None for x in qs),all_coefficients_stable=stable==len(exs),factored_QQ_candidate=str(s.factor(poly))if stable==len(exs)else None));cands.append((exs,qs))
with(w/'ann7-candidate-native.txt').open('w')as f:
 f.write('1 7 0\n')
 for exs,qs in cands:
  assert all(x is not None for x in qs),'no complete reconstructed candidate'
  f.write(str(len(exs))+''.join(' '+str(x)+' '+' '.join(map(str,ex))for ex,x in zip(exs,qs))+'\n')
r=dict(candidate_only=True,QQ_ann_membership_not_verified=True,primes=primes,modulus_bits=mod.bit_length(),generators=stats,all_input_files_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths});(w/'assessment.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

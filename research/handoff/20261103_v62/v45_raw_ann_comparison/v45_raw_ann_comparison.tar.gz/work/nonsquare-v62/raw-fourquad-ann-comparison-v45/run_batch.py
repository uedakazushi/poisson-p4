from pathlib import Path
import subprocess,sys,json
w=Path('work/nonsquare-v62/raw-fourquad-ann-comparison-v45');runs=[]
for p in [2147483647,2147483629]:
 subprocess.run([sys.executable,str(w/'prepare_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL);subprocess.run([sys.executable,str(w/'run_prime.py'),str(p)],check=True,stdout=subprocess.DEVNULL);d=w/str(p);r=json.loads((d/'run.json').read_text());log=(d/'run.log').read_text();assert not r['timed_out'] and r['exit_code']==0 and'RAW_FOURQUAD_SAVED'in log and'?'not in log and'ERROR'not in log;r['prime']=p;runs.append(r);print(json.dumps(r),flush=True)
(w/'batch-result.json').write_text(json.dumps(runs,indent=2)+'\n')

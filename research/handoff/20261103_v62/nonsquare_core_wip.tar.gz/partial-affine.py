import json,sys,time
from fractions import Fraction
from pathlib import Path
p=32003;a0=1
x=json.load(open('work/nonsquare-v62/old/work/generic_hyperplane_polynomial_a_elimination_20261102.json'));vs=x['remaining_variables'];vnames=['q'+str(i)for i in vs]
def red(c):f=Fraction(c);return f.numerator*pow(f.denominator,-1,p)%p
def poly(q):
 terms=[]
 for mon,coeffs in q:
  coeff={}
  for ex,c in coeffs:
   ee,dd=ex[1:];v=red(c)*pow(a0,ex[0],p)%p;coeff[ee,dd]=(coeff.get((ee,dd),0)+v)%p
  qq='+'.join(str(v)+('*e^'+str(ee)if ee else'')+('*d^'+str(dd)if dd else'')for(ee,dd),v in coeff.items()if v)
  if not qq:continue
  terms.append('('+qq+')'+''.join('*q'+str(j)for j in mon))
 return '+'.join(terms)or'0'
ps=[poly(q['polynomial'])for q in x['equations_sparse']];t=poly(x['targets_sparse'][-1]);ak=x['target_a_denominators'][-1];assert ak==9
lines=['R=(ZZ/32003)['+','.join(vnames+['e','d','z'])+'];a='+str(a0)+'_R;','F=500*a+90*e^2+3*e-24;B=(50*a+18*e^2-9*e-2)*d+60*e-40;C=100*a+18*e^2-9*e-2;','I=ideal('+','.join(ps)+',('+t+')-a^'+str(ak)+',z*d*F*B*C-1);g=gb I;print(dim(R/I),degree(R/I));print toString gens g;']
Path('work/nonsquare-v62/partial-affine-a1.m2').write_text('\n'.join(lines)+'\n');print('ready',len(ps),flush=True)

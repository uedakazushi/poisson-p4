import sys,random,json
from pathlib import Path
import numpy as np
sys.path.insert(0,'code');sys.path.insert(0,'work/nonsquare-v62')
import heavy as H
from s61_binary_deeper_uniform_quadratic_20261101 import determinant_mod
p=32003
M=np.array([[int((v:=H.s.Rational(q.evaluate(0,1).evaluate(0,2).evaluate(0,3))).p)*pow(int(v.q),-1,p)%p for q in row]for row in H.N],dtype=np.int64)
rng=random.Random(20261103);rows=[]
while len(rows)<32:
 v=sorted(rng.sample(range(15),7))
 if v in rows:continue
 try: vv=determinant_mod(M[v,:],p)
 except AssertionError: continue
 if vv:rows.append(v)
out=Path('work/nonsquare-v62');json.dump(rows,open(out/'heavy32-selections.json','w'))
with open(out/'heavy32.in','w')as f:
 f.write('15 7\n')
 for row in H.N:
  for q in row:
   f.write(str(len(q))+'\n')
   for m,c in q.items():f.write(str(c)+' '+' '.join(map(str,m))+'\n')
 f.write(str(len(rows))+'\n')
 for row in rows:f.write(' '.join(map(str,row))+'\n')

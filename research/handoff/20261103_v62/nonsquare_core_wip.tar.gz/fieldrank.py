import json,sys,functools,time
from fractions import Fraction
import numpy as np
from pathlib import Path
p=32003
@functools.lru_cache(None)
def coef(s):
 q=Fraction(s);return q.numerator*pow(q.denominator,-1,p)%p
class Field:
 def __init__(self,b,c):self.b=b%p;self.c=c%p
 def add(self,x,y):return((x[0]+y[0])%p,(x[1]+y[1])%p)
 def mul(self,x,y):
  a,b=x;c,d=y
  return((a*c-self.c*b*d)%p,(a*d+b*c-self.b*b*d)%p)
 def pow(self,x,n):
  r=(1,0)
  for _ in range(n):r=self.mul(r,x)
  return r
 def inv(self,x):
  a,b=x;n=(a*a-self.b*a*b+self.c*b*b)%p;assert n
  inv=pow(n,-1,p);return((a-self.b*b)*inv%p,-b*inv%p)
 def poly(self,terms,E,D):
  out=(0,0)
  ep=[self.pow(E,i)for i in range(30)];dp=[self.pow(D,i)for i in range(30)]
  for m,c in terms:
   v=self.mul(ep[m[1]],dp[m[2]]);cc=coef(c);out=self.add(out,(v[0]*cc%p,v[1]*cc%p))
  return out
 def rank(self,vals):
  A=np.array(vals,dtype=np.int64);nr,nc,dim=A.shape;assert dim==2;r=0;pivs=[]
  for j in range(nc):
   ids=np.flatnonzero(np.any(A[r:,j,:],axis=1))
   if not len(ids):continue
   i=int(ids[0])+r;A[[i,r]]=A[[r,i]];v=self.inv(tuple(map(int,A[r,j])))
   x=A[r,:,0].copy();y=A[r,:,1].copy();A[r,:,0]=(x*v[0]-self.c*y*v[1])%p;A[r,:,1]=(x*v[1]+y*v[0]-self.b*y*v[1])%p
   for i in range(r+1,nr):
    a,b=map(int,A[i,j]);
    if not a and not b:continue
    x=A[r,:,0];y=A[r,:,1]
    A[i,:,0]=(A[i,:,0]-a*x+self.c*b*y)%p;A[i,:,1]=(A[i,:,1]-a*y-b*x+self.b*b*y)%p
   pivs.append(j);r+=1
   if r==nr:break
  return r,pivs
records=[];src=Path('work/nonsquare-v62/old/native_data/hyperplane-full-cubic-schur36-input.txt')
pols=[]
with src.open()as f:
 nr,nc,rank=map(int,f.readline().split());assert(nr,nc,rank)==(42,70,36)
 for ii in range(nr*nc):
  z=f.readline().split();n=int(z[0]);assert len(z)==1+4*n
  pols.append([(tuple(map(int,z[2+4*k:5+4*k])),z[1+4*k])for k in range(n)])
assert len(pols)==nr*nc
for b,c in[(235,1065),(-2903,-7388)]:
 st=time.time();F=Field(b,c);Z=(0,1)
 D=(0,0);E=(0,0)
 for deg,v in[(3,15317),(2,13909),(1,-10374),(0,13099)]:
  q=F.pow(Z,deg);D=F.add(D,(q[0]*v%p,q[1]*v%p))
 for deg,v in[(3,-14211),(2,-3391),(1,-8724),(0,-15779)]:
  q=F.pow(Z,deg);E=F.add(E,(q[0]*v%p,q[1]*v%p))
 vals=[F.poly(poly,E,D)for poly in pols];matrix=np.array(vals).reshape(42,70,2)
 rk,piv=F.rank(matrix);print('quadraticfield',b,c,'E',E,'D',D,'fullcubicrank',rk,'time',time.time()-st,flush=True)
 records.append(dict(quadratic=[b,c],e=E,d=D,full_cubic_rank=rk))
Path('work/nonsquare-v62/fieldrank.json').write_text(json.dumps(records,indent=2)+'\n')

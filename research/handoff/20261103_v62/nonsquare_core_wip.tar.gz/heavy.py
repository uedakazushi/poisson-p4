from pathlib import Path
import json,sympy as s,time
from sympy.polys.rings import ring
start=time.time();data=json.load(open('code/data/s61_binary_hyperplane_heavy_template_20261102.json'))
R,a,e,d=ring('a,e,d',s.QQ);K=R.to_field();known=[a,500*a+90*e**2+3*e-24,(50*a+18*e**2-9*e-2)*d+60*e-40,100*a+18*e**2-9*e-2]
def unit(p):
 if not p:return False
 for f in known:
  while p.rem(f)==0:p=p.exquo(f)
 return all(not any(m)for m in p)
M=[[R.from_dict({tuple(m):s.QQ(c)for m,c in p})for p in row]for row in data['matrix']]
change=[[s.QQ(c)for c in row]for row in data['constant_row_change']]
N=[[sum((q*M[k][j]for k,q in enumerate(row)if q),R.zero)for j in range(7)]for row in change]
for row in N:
 g=R.zero
 for p in row:g=g.gcd(p)
 gp=g
 for f in known:
  while gp.rem(f)==0:gp=gp.exquo(f)
 div=g.exquo(gp)*gp.LC
 row[:]=[p.exquo(div)for p in row]
print('entries terms',sum(len(p)for row in N for p in row),flush=True)
Q=[[K(p)for p in row]for row in N];piv=[];r=0
while r<7:
 cand=sorted((len(v.numer)+len(v.denom),i,j)for i in range(r,len(Q))for j,v in enumerate(Q[i])if j not in piv and v)
 pos=next(((i,j)for n,i,j in cand if unit(Q[i][j].numer)and unit(Q[i][j].denom)),None)
 if pos is None:break
 i,j=pos;Q[r],Q[i]=Q[i],Q[r];v=Q[r][j];piv.append(j);Q[r]=[z/v for z in Q[r]]
 for i in range(r+1,len(Q)):
  v=Q[i][j]
  if v:Q[i]=[x-v*y for x,y in zip(Q[i],Q[r])]
 print('pivot',r,i,j,'seconds',time.time()-start,flush=True);r+=1
keep=[j for j in range(7)if j not in piv];res=[]
for row in Q[r:]:
 den=R.one
 for j in keep:den=den.lcm(row[j].denom)
 assert unit(den)
 vec=[row[j].numer*den.exquo(row[j].denom)for j in keep];g=R.zero
 for z in vec:g=g.gcd(z)
 if not g:continue
 gp=g
 for f in known:
  while gp.rem(f)==0:gp=gp.exquo(f)
 gknown=g.exquo(gp);assert unit(gknown)
 res.append([p.exquo(gknown)for p in vec])
print('residual',len(res),len(keep),'terms',sum(len(p)for row in res for p in row),flush=True)
lines=['R=QQ[a,e,d,z];','F=500*a+90*e^2+3*e-24;B=(50*a+18*e^2-9*e-2)*d+60*e-40;C=100*a+18*e^2-9*e-2;','M=matrix{'+','.join('{'+','.join(str(p).replace('**','^')for p in row)+'}'for row in res)+'};','I=minors('+str(len(keep))+',M)+ideal(z*a*F*B*C-1);','g=gb I;print(dim(R/I),degree(R/I));print toString gens g;']
Path('work/nonsquare-v62/heavy.m2').write_text('\n'.join(lines)+'\n');json.dump({'rows':[[str(p)for p in row]for row in res],'pivots':r},open('work/nonsquare-v62/heavy.json','w'));print('ready',time.time()-start)

from pathlib import Path
import sympy as s,json
from sympy.polys.rings import ring
R,a,e,d=ring('a,e,d',s.QQ);fs=[a,500*a+90*e**2+3*e-24,(50*a+18*e**2-9*e-2)*d+60*e-40,100*a+18*e**2-9*e-2]
lines=Path('work/nonsquare-v62/heavy32.out').read_text().splitlines();ps=[]
for i in range(32):
 z=lines[4*i+1].split();nt=int(z[0]);assert len(z)==1+nt*4
 q=R.from_dict({tuple(map(int,z[2+4*k:5+4*k])):s.QQ(z[1+4*k])for k in range(nt)})
 for f in fs:
  while q.rem(f)==0:q=q.exquo(f)
 ps.append(q.monic())
lines=['R=(ZZ/32003)[a,e,d,z];F=500*a+90*e^2+3*e-24;B=(50*a+18*e^2-9*e-2)*d+60*e-40;C=100*a+18*e^2-9*e-2;','I=ideal('+','.join(str(q).replace('**','^')for q in ps)+',z*a*F*B*C-1);g=gb I;print(dim(R/I),degree(R/I));print toString gens g;']
Path('work/nonsquare-v62/heavy32-fp.m2').write_text('\n'.join(lines)+'\n');Path('work/nonsquare-v62/heavy32-qq.m2').write_text('\n'.join(lines).replace('(ZZ/32003)','QQ')+'\n')
json.dump({'polynomials':[str(q)for q in ps]},open('work/nonsquare-v62/heavy32stripped.json','w'))
print('ready32',sum(len(q)for q in ps),flush=True)

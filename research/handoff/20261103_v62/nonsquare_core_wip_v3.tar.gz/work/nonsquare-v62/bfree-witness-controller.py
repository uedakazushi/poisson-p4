from pathlib import Path
import json,time,itertools,subprocess,hashlib,sys
wd=Path('work/nonsquare-v62/fresh-bfree');base=Path('work/nonsquare-v62');start=time.time();current=wd/'witness-short-1';history=[];exe=wd/'unit-witness-short';units=wd/'units'
cands=sorted(itertools.product(range(5),repeat=4),key=lambda x:(x[0]+2*sum(x[1:]),sum(x),x));cstr='{'+','.join('{'+','.join(map(str,x))+'}'for x in cands)+'}'
for step in range(2,8):
 stage=time.time();stem=base/('bfree-r3-stage-'+str(step));counts=[]
 with current.open()as f:
  n,m,k=map(int,f.readline().split());f.readline();f.readline()
  for i in range(n):
   counts.append(sum(int(f.readline().partition(' ')[0])for _ in range(m)))
 row=min((v,i)for i,v in enumerate(counts)if v)[1];assert counts[row]>0
 expr=[]
 with current.open()as f:
  f.readline();f.readline();f.readline()
  for i in range(n*m):
   line=f.readline()
   if i//m!=row:continue
   z=line.split();nt=int(z[0]);terms=[]
   for t in range(nt):
    c=z[1+4*t];ex=list(map(int,z[2+4*t:5+4*t]));terms.append('('+c+')'+''.join('*'+v+('^'+str(x)if x>1 else'')for v,x in zip(['a','e','d'],ex)if x))
   expr.append('+'.join(terms)or'0')
 source='R=QQ[a,e,d];F=500*a+90*e^2+3*e-24;D0=50*a+9*e^2+3*e-6;C=100*a+18*e^2-9*e-2;M=matrix{{'+','.join(expr)+'}};I=ideal M;print "INPUT_READY";<<flush;G=gb I;print "GB_DONE";print(dim(R/I),degree(R/I));<<flush;\n'
 source+='units62={a,F,D0,C};choices62='+cstr+';found62=null;target62=0_R;scan(choices62,pows62->if found62===null then(g62:=product(toList(0..3),j->(units62#j)^(pows62#j));if g62%G==0 then(found62=pows62;target62=g62)));assert(found62=!=null);print("UNIT_TARGET_POWERS="|toString found62);<<flush;L=matrix{{target62}}//M;assert(M*L==matrix{{target62}});print "BEZOUT_PASS";<<flush;\n'
 witness=str(stem)+'.witness';source+='out62=openOut "'+witness+'";out62<<numRows L<<endl;scan(flatten entries L,f->(cc:=coefficients f;mm:=flatten entries cc#0;vv:=flatten entries cc#1;out62<<#mm<<endl;scan(#mm,j->(out62<<toString leadCoefficient(vv#j);scan(first exponents(mm#j),x->out62<<" "<<x);out62<<endl))));close out62;print "BEZOUT_SAVED";<<flush;\n'
 Path(str(stem)+'.m2').write_text(source);record=dict(step=step,input=str(current),input_shape=[n,m],selected_row=row,row_terms=counts[row],input_sha256=hashlib.sha256(current.read_bytes()).hexdigest());print('START',record,flush=True)
 try:cp=subprocess.run(['M2','--script',str(stem)+'.m2'],capture_output=True,text=True,timeout=90)
 except subprocess.TimeoutExpired as e:record['status']='scalar_timeout';Path(str(stem)+'.log').write_text(str(e));history.append(record);break
 Path(str(stem)+'.log').write_text(cp.stdout+cp.stderr)
 if cp.returncode or 'BEZOUT_SAVED'not in cp.stdout:record['status']='scalar_blocked';history.append(record);print(cp.stdout[-500:],cp.stderr[-1000:],flush=True);break
 record['target_powers']=cp.stdout.split('UNIT_TARGET_POWERS=')[1].splitlines()[0];out=wd/('witness-short-'+str(step))
 try:cp=subprocess.run([str(exe),str(current),str(out),str(units),'1',witness,str(row)],capture_output=True,text=True,timeout=60)
 except subprocess.TimeoutExpired as e:record['status']='native_timeout';history.append(record);break
 Path(str(stem)+'.native.log').write_text(cp.stderr)
 if cp.returncode:record['status']='native_blocked';history.append(record);print(cp.stderr[-1000:],flush=True);break
 with out.open()as f:n2,m2,k2=map(int,f.readline().split())
 record.update(status='pivot_pass',output=str(out),output_shape=[n2,m2],removed=k2,output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),seconds=time.time()-stage);history.append(record);print('PASS',record,flush=True);current=out
 if n2==0:break
(base/'bfree-witness-controller-report.json').write_text(json.dumps(dict(history=history,total_seconds=time.time()-start,current=str(current),all_eliminated=history[-1].get('output_shape',[1])[0]==0),indent=2)+'\n')

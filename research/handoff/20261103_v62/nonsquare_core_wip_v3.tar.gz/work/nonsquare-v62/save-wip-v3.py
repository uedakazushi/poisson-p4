from pathlib import Path
import hashlib,json,tarfile
base=Path('.');wd=Path('work/nonsquare-v62');out=Path('research/handoff/20261103_v62');selected=set()
for directory in ['singular-runtime','thin-r3','chart3-minors','jzero-minors','ell-native','fresh-cubic']:
 for p in (wd/directory).glob('*'):
  if not p.is_file()or p.suffix in ['.deb']or p.name in ['minors','unit-span','bounded-lift','short-pivots','all-witness-pivots','clean','factor-first','primitive','low-syzygies']:continue
  if p.suffix in ['.py','.cpp','.m2','.sing','.log','.json','.witness','.txt','.gb']or p.name in ['run-singular.sh','input','output','bags','units','all-witness-list','witness','full','schur','after-short-row','unit-span-schur','full-minus-row48','full-minus-14-48','syzygy-fixture','syzygy-fixture-output','syzygy-unit-removal','syzygy-degree3-unit-removal']or p.name.startswith('syzygies-'):selected.add(p)
for p in wd.glob('*'):
 if p.is_file()and any(t in p.name for t in ['r3','ell-','zw-','witness']):selected.add(p)
for p in (wd/'fresh-bfree').glob('*'):
 if p.is_file()and (p.suffix in ['.py','.cpp','.log','.witness']or p.name=='units'):selected.add(p)
for p in [Path('work/nonsquare-product-alt-v62/mod-ell/chart-3-residual.txt'),Path('work/nonsquare-product-alt-v62/mod-ell/chart-3-ad-units.txt')]:selected.add(p)
# Nested second scalar GB source/log is deliberately included.
selected.update((wd/'thin-r3/second').glob('*'))
selected.add(wd/'wip-v3-status.json');selected.add(wd/'save-wip-v3.py')
files={};omitted={};bundle=[]
for p in sorted(selected):
 if not p.is_file():continue
 h=hashlib.sha256()
 with p.open('rb')as stream:
  for chunk in iter(lambda:stream.read(1<<20),b''):h.update(chunk)
 rec=dict(bytes=p.stat().st_size,sha256=h.hexdigest())
 if rec['bytes']>8_000_000:omitted[str(p)]=rec
 else:files[str(p)]=rec;bundle.append(p)
manifest=dict(date='2026-11-03',scope='WIP and partial exact identities. Not an all-core or ambient-removal theorem.',archive='nonsquare_core_wip_v3.tar.gz',files=files,omitted_regenerable_large_files=omitted)
with tarfile.open(out/manifest['archive'],'w:gz',compresslevel=9)as tar:
 for p in bundle:tar.add(p,arcname=str(p))
manifest['archive_bytes']=(out/manifest['archive']).stat().st_size
manifest['archive_sha256']=hashlib.sha256((out/manifest['archive']).read_bytes()).hexdigest()
(out/'nonsquare_core_wip_v3_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(len(files),'files',len(omitted),'omitted',manifest['archive_bytes'],'archivebytes')

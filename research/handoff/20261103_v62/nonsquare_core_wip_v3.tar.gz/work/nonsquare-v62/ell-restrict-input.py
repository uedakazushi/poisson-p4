from pathlib import Path
import sys,json
sys.path.insert(0,'code')
from s61_binary_nonsquare_mod_ell_coordinates_20261103_v62 import load_chart
c=load_chart();R=c['R'];den=R.one
for image in c['images']:
 for co in image.values():den=den.lcm(co.denom)
mons=json.load(open('work/nonsquare-v62/fresh-cubic/report.json'))['normal_monomials'];wd=Path('work/nonsquare-v62/ell-native');wd.mkdir(exist_ok=True)
def put(f,p):f.write(str(len(p))+''.join(' '+str(co)+' '+' '.join(map(str,ex))for ex,co in p.items())+'\n')
with(wd/'images').open('w')as f:
 f.write('91 8 7\n')
 for m in mons:f.write(' '.join(map(str,m))+'\n')
 put(f,den)
 for image in c['images']:
  f.write(str(len(image))+'\n')
  for m,co in image.items():f.write(' '.join(map(str,m))+'\n');put(f,co.numer*den.exquo(co.denom))
(wd/'units').write_text('\n'.join(str(p).replace('**','^')for p in[R.gens[0],c['F'],c['B'],c['C'],c['J']])+'\n');(wd/'quads.json').write_text(json.dumps([[[list(m),[[list(ex),str(co)]for ex,co in coefficient.items()]]for m,coefficient in q.items()]for q in c['cleared_qfour']]))

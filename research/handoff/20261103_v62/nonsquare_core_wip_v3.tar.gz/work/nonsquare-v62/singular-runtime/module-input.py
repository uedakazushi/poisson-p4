from pathlib import Path
import sys
src=Path(sys.argv[1]);units=Path(sys.argv[2]);out=Path(sys.argv[3]);tag=sys.argv[4]
with src.open()as f:
 n,m,k=map(int,f.readline().split());f.readline();f.readline();A=[]
 for i in range(n):
  row=[]
  for j in range(m):
   z=f.readline().split();nt=int(z[0]);terms=[]
   for t in range(nt):
    c=z[1+4*t];ex=list(map(int,z[2+4*t:5+4*t]));terms.append('('+c+')'+''.join('*'+v+('^'+str(x)if x>1 else'')for v,x in zip(['a','e','d'],ex)if x))
   row.append('+'.join(terms)or'0')
  A.append(row)
fs=[s.strip()for s in units.read_text().splitlines()if s.strip()];rel='z*'+''.join('('+s+')*'for s in fs)+'1-1';vectors=['['+','.join(A[i][j]for i in range(n))+']'for j in range(m)]
for j in range(n):vectors.append('['+','.join(rel if i==j else'0'for i in range(n))+']')
identity=','.join('['+','.join('1'if i==j else'0'for i in range(n))+']'for j in range(n))
s='LIB "modstd.lib";ring R=0,(a,e,d,z),dp;module M='+','.join(vectors)+';module E='+identity+';print("INPUT_READY_'+tag+'");module G=modStd(M,1);print("GB_READY_'+tag+'");if(size(reduce(E,G))==0){print("EXACT_QQ_UNIT_MODULE_'+tag+'");}else{print("NOT_UNIT_'+tag+'");}write("'+str(out)+'.gb",G);quit;\n';out.write_text(s);print(n,m,out.stat().st_size)

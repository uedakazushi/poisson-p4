from pathlib import Path
import sys,json,sympy as sy
src=Path(sys.argv[1]);unitfile=Path(sys.argv[2]);out=Path(sys.argv[3]);tag=sys.argv[4]
with src.open()as f:
 n,m,k=map(int,f.readline().split());f.readline();f.readline();A=[]
 for i in range(n):
  row=[]
  for j in range(m):
   z=f.readline().split();nt=int(z[0]);row.append([(z[1+4*t],tuple(map(int,z[2+4*t:5+4*t])))for t in range(nt)])
  A.append(row)
coldegrees=[max([sum(ex)for i in range(n)for co,ex in A[i][j]]or[0])for j in range(m)]
def pol(terms,degree):
 return '+'.join('('+co+')'+''.join('*'+v+('^'+str(x)if x>1 else'')for v,x in zip(['a','e','d'],ex)if x)+('*w^'+str(degree-sum(ex))if degree>sum(ex)else'')for co,ex in terms)or'0'
vectors=['['+','.join(pol(A[i][j],coldegrees[j])for i in range(n))+']'for j in range(m)]
a,e,d=sy.symbols('a e d');fs=[]
for text in unitfile.read_text().splitlines():
 if not text.strip():continue
 q=sy.Poly(sy.sympify(text.replace('^','**')),a,e,d,domain=sy.QQ);degree=q.total_degree();terms=[(str(co),mon)for mon,co in q.terms()];fs.append((pol(terms,degree),degree))
D=1+sum(degree for _,degree in fs);rel='z*'+'*'.join('('+text+')'for text,_ in fs)+'-w^'+str(D)
for j in range(n):vectors.append('['+','.join(rel if i==j else'0'for i in range(n))+']')
identity=','.join('['+','.join('1'if i==j else'0'for i in range(n))+']'for j in range(n))
script='''LIB "modstd.lib";
ring R=0,(a,e,d,z,w),dp;
module M='''+','.join(vectors)+''';
module E='''+identity+''';
matrix HM62=homog(M,w);matrix MM62=M;
if(HM62!=MM62){ERROR("INPUT_NOT_HOMOGENEOUS");quit;}
print("HOMOGENEOUS_INPUT_READY_'''+tag+'''");
module G=modStd(M,1);
matrix HG62=homog(G,w);matrix MG62=G;
if(HG62!=MG62){ERROR("CANDIDATE_NOT_HOMOGENEOUS");quit;}
int i;
for(i=1;i<=ncols(G);i++){G[i]=G[i]/leadcoef(G[i]);}
if(system("verifyGB",G)!=1){ERROR("QQ_GB_CHECK_FAILED");quit;}
if(size(reduce(M,G))!=0){ERROR("QQ_INPUT_INCLUSION_FAILED");quit;}
module LQ=lead(G);
write("'''+str(out)+'''.gb",G);
print("EXACT_QQ_HOMOGENEOUS_GB_AND_INCLUSION_PASS_'''+tag+'''");
ring Rp=2147483647,(a,e,d,z,w),dp;
module MP=imap(R,M);module GP=imap(R,G);module LQP=imap(R,LQ);
matrix LP62=lead(GP);matrix LQ62=LQP;
if(LP62!=LQ62){ERROR("LEADING_MODULE_CHANGED");quit;}
module GBP=std(MP);
if(system("verifyGB",GBP)!=1){ERROR("MODP_GB_FAILED");quit;}
if(size(reduce(GP,GBP))!=0 || size(reduce(GBP,GP))!=0){ERROR("MODP_EQUALITY_FAILED");quit;}
print("EXACT_HOMOGENEOUS_HILBERT_CERTIFICATE_'''+tag+'''");
setring R;
module GD=subst(G,w,1);module GDS=std(GD);
if(size(reduce(E,GDS))!=0){ERROR("DEHOMOGENIZED_NOT_UNIT");quit;}
print("CERTIFIED_QQ_UNIT_MODULE_VIA_HOMOGENIZATION_'''+tag+'''");
quit;
'''
out.write_text(script);(Path(str(out)+'.meta.json')).write_text(json.dumps(dict(rows=n,source_columns=m,homogeneous_input_column_degrees=coldegrees+[D]*n,module_order='dp with defaultcomponentorder, sameoverQQ/Fp',prime=2147483647),indent=2)+'\n');print(n,m,'bytes',out.stat().st_size)

#include <flint/fmpq_mpoly.h>
#include <cassert>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;fmpq_mpoly_ctx_t ctx;
struct P{fmpq_mpoly_t p;P(){fmpq_mpoly_init(p,ctx);}P(const P&x):P(){fmpq_mpoly_set(p,x.p,ctx);}P(P&&x):P(){fmpq_mpoly_swap(p,x.p,ctx);}P&operator=(P x){fmpq_mpoly_swap(p,x.p,ctx);return *this;}~P(){fmpq_mpoly_clear(p,ctx);}};
void read(istream&in,P&p){fmpq_mpoly_zero(p.p,ctx);int n;in>>n;fmpq_t q;fmpq_init(q);ulong ex[3];for(int i=0;i<n;i++){string s;in>>s>>ex[0]>>ex[1]>>ex[2];assert(!fmpq_set_str(q,s.c_str(),10));fmpq_canonicalise(q);fmpq_mpoly_push_term_fmpq_ui(p.p,q,ex,ctx);}fmpq_mpoly_sort_terms(p.p,ctx);fmpq_mpoly_combine_like_terms(p.p,ctx);fmpq_clear(q);}
int main(int argc,char**argv){assert(argc==4);fmpq_mpoly_ctx_init(ctx,3,ORD_LEX);{ifstream in(argv[1]),units(argv[2]);ofstream out(argv[3]);string line;const char*vars[]={"a","e","d"};vector<P>known;while(getline(units,line)){if(line.empty())continue;P p;assert(!fmpq_mpoly_set_str_pretty(p.p,line.c_str(),vars,ctx));known.push_back(p);}out<<"R=QQ[a,e];I=ideal(";for(int k=0;k<4;k++){getline(in,line);assert(line.rfind("MINOR ",0)==0);P p,q;read(in,p);getline(in,line);vector<int>vals;for(auto&u:known){int n=0;while(fmpq_mpoly_divides(q.p,p.p,u.p,ctx)){p=q;n++;}vals.push_back(n);}fmpq_t lc;fmpq_init(lc);fmpq_mpoly_get_term_coeff_fmpq(lc,p.p,0,ctx);fmpq_mpoly_scalar_div_fmpq(p.p,p.p,lc,ctx);fmpq_clear(lc);cerr<<"MINOR "<<k<<" TERMS "<<fmpq_mpoly_length(p.p,ctx)<<" TOTALDEG "<<fmpq_mpoly_total_degree_si(p.p,ctx)<<" VALUATIONS ";for(int n:vals)cerr<<n<<' ';cerr<<'\n';char*s=fmpq_mpoly_get_str_pretty(p.p,vars,ctx);if(k)out<<",";out<<s;flint_free(s);getline(in,line);assert(line.rfind("GCD ",0)==0);read(in,q);getline(in,line);}out<<");print \"JZERO_MINOR_SCALAR_READY\";<<flush;G=gb I;print(\"JZERO_MINOR_SCALAR_GB_DONE\",dim(R/I),degree(R/I));<<flush;print gens G;<<flush;\n";}
fmpq_mpoly_ctx_clear(ctx);flint_cleanup();}

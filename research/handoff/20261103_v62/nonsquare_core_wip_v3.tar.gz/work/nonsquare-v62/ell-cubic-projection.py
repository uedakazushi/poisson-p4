from pathlib import Path
import sys,json,time
sys.path.insert(0,'code')
from s61_binary_nonsquare_mod_ell_coordinates_20261103_v62 import load_chart
from sympy.polys.rings import ring
import sympy as s
st=time.time();c=load_chart();R,K=c['R'],c['K'];P,*w=ring('w0,w1,w2,w3,w4,w5,H',R);den=R.one
for image in c['images']:
 for co in image.values():den=den.lcm(co.denom)
print('den',str(den),'setup',time.time()-st,flush=True)
images=[P.from_dict({m:co.numer*den.exquo(co.denom)for m,co in image.items()})for image in c['images']];rep=json.load(open('work/nonsquare-v62/fresh-cubic/report.json'));mons=[tuple(m)for m in rep['normal_monomials']];cache=[]
for mon in mons:
 out=P(den**(3-sum(mon)))
 for n,img in zip(mon,images):
  if n:out*=img**n
 cache.append(out)
print('cache',sum(len(co)for poly in cache for co in poly.values()),time.time()-st,flush=True)
known=[R.gens[0],c['F'],c['B'],c['C'],c['J']];outrows=[]
with Path('work/nonsquare-v62/fresh-cubic/full').open()as f:
 nr,nc,k=map(int,f.readline().split())
 for i in range(nr):
  row=[]
  for j in range(nc):
   z=f.readline().split();nt=int(z[0]);co=R.from_dict({tuple(map(int,z[2+4*t:5+4*t])):s.QQ(z[1+4*t])for t in range(nt)});row.append(co)
  if i<42:continue
  poly=P.zero
  for co,img in zip(row,cache):
   if co:poly+=img*co
  out=dict(poly.items());orders=[]
  for factor in known:
   nn=0
   while out and all(not co.rem(factor)for co in out.values()):out={m:co.exquo(factor)for m,co in out.items()};nn+=1
   orders.append(nn)
  first=next(iter(out.values()),R.one).LC;out={m:co/first for m,co in out.items()};outrows.append(out);print('CUBIC',i,'outer',len(out),'terms',sum(len(co)for co in out.values()),'orders',orders,'seconds',time.time()-st,flush=True)
wd=Path('work/nonsquare-v62/ell-cubic-projection');wd.mkdir(exist_ok=True);enc=lambda q:[[m,[[ex,str(co)]for ex,co in coefficient.items()]]for m,coefficient in q.items()];(wd/'cubics.json').write_text(json.dumps([enc(q)for q in outrows]));(wd/'quads.json').write_text(json.dumps([enc(q)for q in c['cleared_qfour']]));print('DONE',time.time()-st,flush=True)

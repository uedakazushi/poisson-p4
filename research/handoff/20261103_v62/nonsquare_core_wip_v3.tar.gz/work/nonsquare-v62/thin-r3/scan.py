from pathlib import Path
import subprocess,time,json
wd=Path('work/nonsquare-v62/thin-r3');base=Path('work/nonsquare-product-alt-v62/mod-ell');out=[];start=time.time()
for row in range(14):
 stem=wd/('scan-row-'+str(row));cmd=[str(wd/'bounded-lift'),str(base/'chart-3-residual.txt'),str(base/'chart-3-ad-units.txt'),str(row),'2','4',str(stem)+'.witness'];t=time.time()
 try:r=subprocess.run(cmd,capture_output=True,text=True,timeout=12)
 except subprocess.TimeoutExpired as e:out.append(dict(row=row,status='timeout',seconds=time.time()-t));print(out[-1],flush=True);continue
 Path(str(stem)+'.log').write_text(r.stderr+r.stdout);rec=dict(row=row,exit_code=r.returncode,seconds=time.time()-t)
 if r.returncode==0:
  ls=Path(str(stem)+'.witness').read_text().splitlines();i=1;ct=0;chars=[];degs=[]
  for _ in range(int(ls[0])):
   nt=int(ls[i]);i+=1;ts=ls[i:i+nt];i+=nt;ct+=nt;chars.extend(len(x.split()[0])for x in ts);degs.extend(sum(map(int,x.split()[1:]))for x in ts)
  rec.update(terms=ct,max_coefficient_chars=max(chars),max_degree=max(degs),target=r.stderr.split('TARGET ')[-1].splitlines()[0])
 out.append(rec);print(rec,flush=True)
(wd/'scan-report.json').write_text(json.dumps(dict(records=out,seconds=time.time()-start),indent=2)+'\n')

from pathlib import Path
from fractions import Fraction
import json,time,functools,sympy as s
st=time.time();old=json.load(open('work/nonsquare-v62/old/work/generic_hyperplane_polynomial_a_elimination_20261102.json'));add=json.load(open('reports/S61_BINARY_NONSQUARE_PARTIAL135_20261103_v62/additional-G6.json'));raw=[q['polynomial']for q in old['equations_sparse']]+[add['G6']]
@functools.lru_cache(None)
def frac(c):return Fraction(c)
rows=[]
for q in raw:
 terms=[]
 for mon,cs in q:
  z=sum((frac(c)*2**ex[1]*3**ex[2]for ex,c in cs),Fraction(0))
  if z:terms.append('('+str(z)+')'+''.join('*q'+str(j)for j in mon))
 rows.append('+'.join(terms)or'0')
c=json.load(open('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json'));v=s.symbols('v0:8');a,e,d=s.symbols('a e d');core={a:1,e:2,d:3};idx=[0,1,2,3,4,6,7];rawlight=[3,8,20,22,24,37,43];qq=s.Matrix([s.Symbol('q'+str(j))for j in rawlight]);T=s.Matrix([[s.sympify(row[c['normal34'][j]]).subs(core)for j in idx]for row in c['T34']]);M=T[rawlight,:];assert M.det();sol=M.inv()*qq;replace={v[j]:sol[k]for k,j in enumerate(idx)};pair=json.load(open('reports/S61_BINARY_HYPERPLANE_QUADRATIC_PAIR_20261102.json'));ell=s.expand(s.sympify(pair['linear_form']).subs(core).subs(replace));Z=s.expand((3*v[0]-v[1]+v[6]).subs(replace));W=s.expand(v[3].subs(replace));print('forms',ell,Z,W,flush=True)
vs=old['remaining_variables'];ws=add['remaining_weights'];source='R=QQ['+','.join('q'+str(j)for j in vs)+',Degrees=>{'+','.join(map(str,ws))+'}];I=ideal('+','.join(rows)+');G=gb I;ell='+str(ell).replace('**','^')+';Z='+str(Z).replace('**','^')+';W='+str(W).replace('**','^')+';assert(ell*Z%G==0 and ell*W%G==0);\n'
source+='Jell=I+ideal(ell);Jzw=I+ideal(Z,W);Jcol=I:ideal(ell);scan({I,Jell,Jzw,Jcol},J->(print(numColumns basis(R/J),apply(0..4,n->hilbertFunction(n,R/J)))));print(isSubset(Jzw,Jcol),isSubset(Jcol,Jzw));print "ELL_BRANCH_POINT_DONE";<<flush;\n';Path('work/nonsquare-v62/ell-branch-point.m2').write_text(source);print('generate',time.time()-st,flush=True)

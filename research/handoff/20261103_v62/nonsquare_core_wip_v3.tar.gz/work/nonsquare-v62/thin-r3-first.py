from pathlib import Path
import itertools,json,sympy as s
src=Path('work/nonsquare-product-alt-v62/mod-ell/chart-3-residual.txt');unitsfile=Path('work/nonsquare-product-alt-v62/mod-ell/chart-3-ad-units.txt');wd=Path('work/nonsquare-v62/thin-r3');wd.mkdir(exist_ok=True)
with src.open()as f:
 n,m,k=map(int,f.readline().split());f.readline();f.readline();data=[f.readline()for _ in range(n*m)]
counts=[sum(int(data[i*m+j].partition(' ')[0])for j in range(m))for i in range(n)];i=min((ct,i)for i,ct in enumerate(counts)if ct)[1];polys=[]
for line in data[i*m:(i+1)*m]:
 z=line.split();nt=int(z[0]);polys.append('+'.join('('+z[1+4*t]+')'+''.join('*'+v+('^'+str(x)if x>1 else'')for v,x in zip(['a','e','d'],map(int,z[2+4*t:5+4*t]))if x)for t in range(nt))or'0')
fs=[x for x in unitsfile.read_text().splitlines()if x.strip()];a,e,d=s.symbols('a e d');degrees=[s.Poly(s.sympify(x.replace('^','**')),a,e,d).total_degree()for x in fs];candidates=[]
for powers in itertools.product(range(5),repeat=len(fs)):
 if sum(powers)<=4 or len(set(powers))==1:candidates.append(powers)
candidates.sort(key=lambda x:(sum(c*di for c,di in zip(x,degrees)),sum(x),x));cs='{'+','.join('{'+','.join(map(str,x))+'}'for x in candidates)+'}'
source='R=QQ[a,e,d];M=matrix{{'+','.join(polys)+'}};I=ideal M;print "THIN_R3_INPUT_READY";<<flush;G=gb I;print "THIN_R3_GB_DONE";print(dim(R/I),degree(R/I));<<flush;\n'
source+='units62={'+','.join(fs)+'};choices62='+cs+';found62=null;target62=0_R;scan(choices62,pows62->if found62===null then(g62:=product(toList(0..'+str(len(fs)-1)+'),j->(units62#j)^(pows62#j));if g62%G==0 then(found62=pows62;target62=g62)));assert(found62=!=null);print("UNIT_TARGET_POWERS="|toString found62);<<flush;L=matrix{{target62}}//M;assert(M*L==matrix{{target62}});print "THIN_R3_BEZOUT_PASS";<<flush;\n'
source+='out62=openOut "'+str(wd/'witness')+'";out62<<numRows L<<endl;scan(flatten entries L,f->(cc:=coefficients f;mm:=flatten entries cc#0;vv:=flatten entries cc#1;out62<<#mm<<endl;scan(#mm,j->(out62<<toString leadCoefficient(vv#j);scan(first exponents(mm#j),x->out62<<" "<<x);out62<<endl))));close out62;print "THIN_R3_SAVED";<<flush;\n';(wd/'first.m2').write_text(source);(wd/'meta.json').write_text(json.dumps(dict(target_row=i,row_terms=counts[i],matrix_shape=[n,m],source=str(src),units=str(unitsfile))));print(i,counts[i],len(candidates))

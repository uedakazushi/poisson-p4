from pathlib import Path
import json,sympy as s,time
from sympy.polys.rings import ring
st=time.time();R,a,e,d=ring('a,e,d',s.QQ);wd=Path('work/nonsquare-v62/ell-native')
qs=[{tuple(m):R.from_dict({tuple(ex):s.QQ(co)for ex,co in cs})for m,cs in q}for q in json.load(open(wd/'quads.json'))];cubics=[];cubeids=[]
with(wd/'cubics').open()as f:
 nr=int(f.readline())
 for _ in range(nr):
  idx,n=map(int,f.readline().split());row={}
  for _ in range(n):
   m=tuple(map(int,f.readline().split()));z=f.readline().split();row[m]=R.from_dict({tuple(map(int,z[2+4*k:5+4*k])):s.QQ(z[1+4*k])for k in range(int(z[0]))})
  cubics.append(row);cubeids.append(idx)
nw=[1]*6+[2]
def mons(w,i=0,m=()):
 if i==7:
  if w==0:yield m
  return
 for k in range(w//nw[i]+1):yield from mons(w-k*nw[i],i+1,m+(k,))
rows=[];labels=[]
for i,q in enumerate(qs):
 for shift in mons(2):rows.append({tuple(x+y for x,y in zip(mon,shift)):co for mon,co in q.items()});labels.append(['quad',i,list(shift)])
for i,q in enumerate(cubics):
 for shift in mons(1):rows.append({tuple(x+y for x,y in zip(mon,shift)):co for mon,co in q.items()});labels.append(['cubic',cubeids[i],list(shift)])
columns=[m for m in mons(4)if m[6]!=2];assert(len(rows),len(columns))==(214,147)
with(wd/'quartic-matrix').open('w')as f:
 f.write('214 147 147\n')
 for row in rows:
  for mon in columns:
   p=row.get(mon,R.zero);f.write(str(len(p))+''.join(' '+str(co)+' '+' '.join(map(str,ex))for ex,co in p.items())+'\n')
(wd/'quartic-meta.json').write_text(json.dumps(dict(rows=labels,columns=columns)))
src=Path('work/nonsquare-v62/fresh-bfree/unit-schur-markowitz.cpp').read_text().replace('n==321&&m==238','n==214&&m==147').replace('k<238','k<147').replace('"50*a+9*e^2+3*e-6"','"50*a*d+18*d*e^2-9*d*e-2*d+60*e-40"').replace('"100*a+18*e^2-9*e-2"}','"100*a+18*e^2-9*e-2","5*a*d-6*e-4","d"}');(wd/'quartic-schur.cpp').write_text(src);print('READY',sum(len(co)for row in rows for co in row.values()),'sec',time.time()-st,flush=True)

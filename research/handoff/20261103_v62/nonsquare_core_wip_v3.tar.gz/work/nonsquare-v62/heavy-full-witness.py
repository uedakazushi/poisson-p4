from pathlib import Path
import json,time,sys,sympy as s
from sympy.polys.rings import ring
sys.path.insert(0,'work/nonsquare-v62')
# Import just the exact finite-field arithmetic definitions (no old probe I/O).
ns={};src=Path('work/nonsquare-v62/fieldrank.py').read_text();exec(src[:src.index('records=[]')],ns)
Field=ns['Field'];coef=ns['coef'];p=32003
annraw=Path('work/nonsquare-v62/heavy-ann-QQ.log').read_text();ss=annraw[annraw.index('matrix {{')+9:annraw.index('}}\nHEAVY_QQ_ANN_DONE')];R,*vs=ring('a,e,d,z',s.QQ);ann=[R.from_expr(s.sympify(q.replace('^','**')))for q in ss.split(', ')]
pols=[]
with Path('work/nonsquare-v62/fresh-cubic/schur').open()as f:
 nr,nc,k=map(int,f.readline().split());f.readline();f.readline()
 for ii in range(nr*nc):
  zz=f.readline().split();n=int(zz[0]);pols.append([(tuple(map(int,zz[2+4*j:5+4*j])),zz[1+4*j])for j in range(n)])

def det(F,A):
 A=[[tuple(map(int,v))for v in row]for row in A];v=(1,0)
 for j in range(len(A)):
  i=next(i for i in range(j,len(A))if A[i][j]!=(0,0))
  if i!=j:A[i],A[j]=A[j],A[i];v=((-v[0])%p,(-v[1])%p)
  t=A[j][j];v=F.mul(v,t);iv=F.inv(t)
  for i in range(j+1,len(A)):
   t=F.mul(A[i][j],iv)
   if t==(0,0):continue
   for h in range(j,len(A)):q=F.mul(t,A[j][h]);A[i][h]=((A[i][h][0]-q[0])%p,(A[i][h][1]-q[1])%p)
 return v
records=[];choice=None
for bi,ci,E,D in[(235,1065,(6680,24479),(223,4274)),(-2903,-7388,(7302,20430),(26690,6349))]:
 st=time.time();F=Field(bi,ci);assert pow((bi*bi-4*ci)%p,(p-1)//2,p)==p-1
 Fval=F.add((500-24,0),F.add(F.mul((90,0),F.pow(E,2)),F.mul((3,0),E)))
 Cval=F.add((100-2,0),F.add(F.mul((18,0),F.pow(E,2)),F.mul((-9,0),E)))
 Bval=F.add(F.mul(F.add((50-2,0),F.add(F.mul((18,0),F.pow(E,2)),F.mul((-9,0),E))),D),F.add(F.mul((60,0),E),(-40,0)))
 Z=F.inv(F.mul(F.mul(Fval,Bval),Cval));bases=[(1,0),E,D,Z];powers=[[F.pow(v,k)for k in range(15)]for v in bases]
 for q in ann:
  value=(0,0)
  for mon,c in q.items():
   cc=coef(str(c));term=(cc,0)
   for j,k in enumerate(mon):term=F.mul(term,powers[j][k])
   value=F.add(value,term)
  assert value==(0,0),value
 vals=[F.poly(q,E,D)for q in pols];import numpy as np
 A=np.array(vals,dtype=np.int64).reshape(nr,nc,2)
 rank,cols=F.rank(A);assert rank==36
 _,rows=F.rank(A[:,cols].transpose(1,0,2));assert len(rows)==36
 if choice is None:choice={'rows':rows,'columns':cols}
 value=det(F,A[np.ix_(choice['rows'],choice['columns'])]);assert value!=(0,0)
 print('PASS',bi,ci,'rank',rank,'commonminor',value,'seconds',time.time()-st,flush=True)
 records.append(dict(quadratic=[bi,ci],e=E,d=D,z=Z,ann_generators_zero=25,full_cubic_rank=rank,common_minor_determinant=value))
Path('work/nonsquare-v62/heavy-full-witness.json').write_text(json.dumps({'prime':p,'common_minor':choice,'records':records},indent=2)+'\n')

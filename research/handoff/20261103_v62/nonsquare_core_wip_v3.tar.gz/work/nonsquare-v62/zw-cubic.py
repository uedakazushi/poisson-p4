from pathlib import Path
import json,sympy as s,math,time
from sympy.polys.rings import ring
st=time.time();R,a,e,d=ring('a,e,d',s.QQ);rep=json.load(open('work/nonsquare-v62/fresh-cubic/report.json'));old=json.load(open('reports/S61_BINARY_HYPERPLANE_QUADRATIC_CODIMENSION_20261102.json'))
qs=[{tuple(mon):R.from_dict({tuple(ex):s.QQ(c)for ex,c in cs})for mon,cs in row}for row in old['quadratic_rows_sparse']]
rows=[]
with Path('work/nonsquare-v62/fresh-cubic/full').open()as f:
 nr,nc,k=map(int,f.readline().split());assert(nr,nc)==(63,91)
 for i in range(nr):
  row={}
  for j in range(nc):
   z=f.readline().split();nn=int(z[0]);p=R.from_dict({tuple(map(int,z[2+4*t:5+4*t])):s.QQ(z[1+4*t])for t in range(nn)})
   if p:row[tuple(rep['normal_monomials'][j])]=p
  if i>=42:rows.append(row)
positions=[0,1,2,4,5,7]
def restrict(row):
 out={}
 for mon,c in row.items():
  if mon[3]:continue
  k=mon[6]
  for j in range(k+1):
   ex=[mon[i]for i in positions];ex[0]+=j;ex[1]+=k-j;ex=tuple(ex);out[ex]=out.get(ex,R.zero)+c*math.comb(k,j)*(-3)**j
 return {m:c for m,c in out.items()if c}
qq=[restrict(qs[i])for i in[0,1,3,5]];cc=[restrict(row)for row in rows];out=[];labels=[]
for i,q in enumerate(qq):
 for j in[0,1,2,3,5]:
  out.append({tuple(x+(l==j)for l,x in enumerate(m)):c for m,c in q.items()});labels.append(['quadproduct',i,j])
out+=cc;labels+=[['cubic',i[1]]for i in rep['labels'][42:]];mons=sorted(set().union(*out));assert(len(out),len(mons))==(41,40)
wd=Path('work/nonsquare-v62/zw-cubic');wd.mkdir(exist_ok=True)
with(wd/'matrix').open('w')as f:
 f.write('41 40 34\n')
 for row in out:
  for m in mons:
   p=row.get(m,R.zero);f.write(str(len(p))+''.join(' '+str(c)+' '+' '.join(map(str,ex))for ex,c in p.items())+'\n')
(wd/'meta.json').write_text(json.dumps(dict(labels=labels,columns=mons)))
src=Path('code/s61_binary_hyperplane_cubic_unit_schur_20261102.cpp').read_text().replace('n==63&&m==91','n==41&&m==40').replace('k<42','k<40').replace('i<42','i<n');(wd/'unit-schur.cpp').write_text(src)
print('READY',sum(len(p)for row in out for p in row.values()),'sec',time.time()-st,flush=True)

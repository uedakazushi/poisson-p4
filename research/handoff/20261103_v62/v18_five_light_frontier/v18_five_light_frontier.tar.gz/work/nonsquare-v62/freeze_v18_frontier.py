from pathlib import Path
import json,tarfile,hashlib,time
b=Path('research/handoff/20261103_v62/v18_five_light_frontier');assert not(b/'manifest.json').exists();a=Path('work/nonsquare-v62/five-light-product-v14');c=Path('work/nonsquare-v62/five-light-adaptive-v15');d=Path('work/nonsquare-v62/degree1-span-v16')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=[p for p in a.iterdir()if p.is_file()and not p.name.endswith('-bin')and p.stat().st_size<2000000];files += [c/x for x in ['source.json','continue.py','state.json','continue.log']]
s=json.loads((c/'state.json').read_text());assert s['stage']==4 and s['total_pivots']==9 and s['products']==11
for rec in s['history']:
 sd=Path(rec['result']).parent;files += [sd/'receipt.json',sd/'candidates.json',sd/'pivot.log',Path(rec['witness']),Path(rec['result'])]
files += [d/'source.json',d/'degree1-unit-span.cpp',d/'row6.log',d/'row6.receipt.json',d/'rows/row6.txt',Path('work/nonsquare-v62/cubic27-v6/P-units'),Path('work/nonsquare-v62/product-field-v7/witness-image-stats.cpp'),Path('work/nonsquare-v62/freeze_v18_frontier.py')];files=sorted(set(files));assert all(p.is_file()for p in files)
archive=b/'v18_five_light_frontier.tar.gz'
with tarfile.open(archive,'w:gz')as t:
 for p in files:t.add(p,arcname=str(p),recursive=False)
status=dict(frozen=True,proved_lemma='rank20 after one extra light hyperplane implies rank24 before it, hence accepted original product rank41 bridge',sufficient_not_necessary=True,sample=[1,2,3],sample_prime=32003,sample_ranks=[20,20,20,20,20,19],z_case_native_unit_pivots=9,z_case_residual_shape=[11,26],z_case_residual_terms=20453,all_core_rank_bound=False,quartic_or_ambient_result=False,all_jobs_of_this_agent_closed=True,next='Bound actual defect of the five-light rank tests; main cubic/quartic exhaustion remains open',source_report_sha256=sha('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json'))
(b/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n');note=Path('research/notes/S61_BINARY_NONSQUARE_FIVE_LIGHT_CRITERION_20261103_v62.md')
r=dict(frozen=True,created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),members=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in files],archive=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive)),note_sha256=sha(note),readme_sha256=sha(b/'README.md'),status_sha256=sha(b/'STATUS.json'));(b/'manifest.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r['archive']),len(files))

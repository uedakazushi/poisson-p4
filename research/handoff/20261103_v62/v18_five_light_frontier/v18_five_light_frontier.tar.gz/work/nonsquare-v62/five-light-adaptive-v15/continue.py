from pathlib import Path
import json,subprocess,re,resource,time,hashlib
w=Path('work/nonsquare-v62/five-light-adaptive-v15');units='work/nonsquare-v62/cubic27-v6/P-units';span='work/nonsquare-v62/primitive-unit-span-v9/primitive-unit-span-optimized-bin';pair='work/nonsquare-v62/full-cubic-unit-v10/short-unit-pair-bin';scorer='work/nonsquare-v62/adaptive-product-v12/witness-score-bin';pivot='work/nonsquare-v62/v8-restore-audit/witness-stats-bin'
def cap():resource.setrlimit(resource.RLIMIT_AS,(1500000*1024,1500000*1024))
def run(args,log,seconds):
 try:p=subprocess.run([str(x)for x in args],capture_output=True,text=True,timeout=seconds,preexec_fn=cap);s=p.stdout+p.stderr;code=p.returncode
 except subprocess.TimeoutExpired as e:s=(e.stdout or b'').decode()+(e.stderr or b'').decode();code=124
 log.write_text(s);return code,s
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def mat(p,meta):
 f=Path(p).open();n,m,k=map(int,f.readline().split());ids=list(range(n))
 if meta:f.readline();ids=list(map(int,f.readline().split()))
 A=[[f.readline()for j in range(m)]for i in range(n)];assert not f.read().strip();return n,m,ids,A
state=dict(stage=0,matrix='work/nonsquare-v62/five-light-product-v14/omit4-residual.txt',metadata=1,global_rows=json.loads((w/'source.json').read_text())['row_global_indices'],products=15,total_pivots=5,history=[])
for step in range(1,16):
 sd=w/f'stage{step}';sd.mkdir(exist_ok=False);n,m,_,A=mat(state['matrix'],state['metadata']);cost=[sum(int(z.split(maxsplit=1)[0])for z in row)for row in A];total=sum(cost);c=[]
 if False:c=[]
 else:
  for i in sorted(range(state['products']),key=cost.__getitem__):
   rp=sd/f'row{i}.txt';rp.write_text(f'1 {m} 1\n'+''.join(A[i]))
   for kind,binary,extras,seconds in [('pair',pair,[],3),('span',span,['8'],4)]:
    wp=sd/f'{kind}-row{i}.witness';code,s=run([binary,rp,units,'0','0',wp,*extras],sd/f'{kind}-row{i}.log',seconds)
    if code==0:
     z=wp.read_text().split();at=1;nt=0;degree=0
     for j in range(int(z[0])):
      zt=int(z[at]);at+=1;nt+=zt
      for t in range(zt):degree=max(degree,sum(map(int,z[at+1:at+4])));at+=4
     c.append(dict(row=i,global_row=state['global_rows'][i],kind=kind,witness=str(wp),rowcost=cost[i],witness_terms=nt,witness_degree=degree,heuristic=cost[i]*nt*(degree+1)))
  c.sort(key=lambda z:z['heuristic']);c=c[:30]
 if not c:
  state['halt']='No short declared-unit candidate found within per-row bounds';(sd/'candidates.json').write_text('[]\n');break
 scored=[]
 for j,z in enumerate(c):
  code,s=run([scorer,state['matrix'],str(sd/'unused-score-output'),units,state['metadata'],z['witness'],z['row'],'score'],sd/f'score{j}.log',20)
  if code:continue
  qs=[tuple(map(int,g))for g in re.findall(r'IMAGE_ROW (\d+) DEGREE (-?\d+) TERMS (\d+)',s)];assert len(qs)==n and'IMAGE_SCORE_ONLY_PASS'in s;tp=qs[z['row']];off=sum(q[2]for q in qs if q[0]!=z['row']);z.update(target_degree=tp[1],target_terms=tp[2],offdiag_terms=off,score=tp[2]*(total-cost[z['row']])+off*cost[z['row']]);scored.append(z)
 if not scored:state['halt']='Candidate scoring reached bounds';break
 scored.sort(key=lambda z:(z['score'],z['target_degree']));chosen=scored[0];(sd/'candidates.json').write_text(json.dumps(scored,indent=2)+'\n');out=sd/'matrix.txt';code,s=run([pivot,state['matrix'],out,units,state['metadata'],chosen['witness'],chosen['row']],sd/'pivot.log',45)
 if code:state['halt']='Exact native pivot did not complete within bounds';break
 nn,mm,localids,AA=mat(out,True);assert nn==n-1 and mm==m-1 and'EXACT_WITNESS_REPLACE'in s and'PASS 1'in s;globalids=[state['global_rows'][i]for i in localids];products=state['products']-1;assert all(i<=41 for i in globalids[:products])and all(i>=42 for i in globalids[products:]);terms=sum(int(q.split(maxsplit=1)[0])for row in AA for q in row);record=dict(step=step,global_pivot_row=chosen['global_row'],local_pivot_row=chosen['row'],witness=chosen['witness'],source=state['matrix'],source_sha256=sha(state['matrix']),result=str(out),result_sha256=sha(out),shape=[nn,mm],products_remaining=products,total_terms=terms,known_unit_pivots=state['total_pivots']+1,target_terms=chosen['target_terms'],target_degree=chosen['target_degree']);state.update(stage=step,matrix=str(out),metadata=1,global_rows=globalids,products=products,total_pivots=state['total_pivots']+1);state['history'].append(record);(sd/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');(w/'state.json').write_text(json.dumps(state,indent=2)+'\n');print('EXACT_ADAPTIVE_PIVOT',record,flush=True)
 if terms>1500000:state['halt']='Conditioning term budget reached';break
(w/'state.json').write_text(json.dumps(state,indent=2)+'\n');print('ADAPTIVE_PHASE_DONE',state['stage'],state.get('halt','eight saved pivots'),flush=True)

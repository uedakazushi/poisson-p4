from pathlib import Path
from fractions import Fraction
import json,itertools,hashlib
w=Path('work/nonsquare-v62/five-light-product-v14');src=Path('reports/S61_BINARY_NONSQUARE_MOD_ELL_COORDINATES_20261103_v62.json');data=json.loads(src.read_text());qfour=[{tuple(mon):{tuple(ex):Fraction(c)for ex,c in terms}for mon,terms in q}for q in data['cleared_qfour_sparse']]
def mons(n,d):return [(d,)]if n==1 else[(i,)+a for i in range(d+1)for a in mons(n-1,d-i)]
def enc(p):return str(len(p))+''.join(' '+str(c)+' '+' '.join(map(str,m))for m,c in sorted(p.items(),reverse=True))+'\n'
def rank(A,p):
 r=0
 for j in range(len(A[0])):
  i=next((i for i in range(r,len(A))if A[i][j]%p),None)
  if i is None:continue
  A[r],A[i]=A[i],A[r];z=pow(A[r][j]%p,-1,p);A[r]=[v*z%p for v in A[r]]
  for i in range(r+1,len(A)):
   z=A[i][j]%p
   if z:A[i]=[(a-z*b)%p for a,b in zip(A[i],A[r])]
  r+=1
  if r==len(A):return r
 return r
cases=[]
for omit in range(6):
 keep=[i for i in range(6)if i!=omit];qs=[];shifts=[]
 for q in qfour:
  allowed={tuple(mon[i]for i in keep):c for mon,c in q.items()if not mon[omit]};shift=max([0]+[ex[2]-ex[0]for c in allowed.values()for ex in c]);shifts.append(shift);out={}
  for mon,c in allowed.items():
   cp={}
   for(a,e,d),v in c.items():
    ex=(a-d+shift,e,d);assert min(ex)>=0 and ex[0]+ex[2]-shift==a;cp[ex]=cp.get(ex,0)+v
   out[mon]={ex:v for ex,v in cp.items()if v}
  qs.append(out)
 rows=[{tuple(a+b for a,b in zip(mon,mu)):c for mon,c in q.items()}for q in qs for mu in mons(5,1)];columns=mons(5,3);assert(len(rows),len(columns))==(20,35);dest=w/f'omit{omit}.txt'
 with dest.open('w')as f:
  f.write('20 35 20\n')
  for row in rows:
   for mon in columns:f.write(enc(row.get(mon,{})))
 p=32003;sample=(1,2,3);A=[[sum(c.numerator*pow(c.denominator,-1,p)*pow(sample[0],ex[0],p)*pow(sample[1],ex[1],p)*pow(sample[2],ex[2],p)for ex,c in row.get(mon,{}).items())%p for mon in columns]for row in rows];cases.append(dict(omitted_light_coordinate=omit,retained_light_coordinates=keep,core_coordinates=['a','e','P=ad'],a_clear_shifts_per_quad=shifts,matrix=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),shape=[20,35],sample_rank=rank(A,p),sample=[1,2,3],prime=p))
(w/'source.json').write_text(json.dumps(dict(source_report=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),known_units_file='work/nonsquare-v62/cubic27-v6/P-units',four_quad_indices=[0,1,3,5],cases=cases),indent=2)+'\n');print([(z['omitted_light_coordinate'],z['sample_rank'])for z in cases])

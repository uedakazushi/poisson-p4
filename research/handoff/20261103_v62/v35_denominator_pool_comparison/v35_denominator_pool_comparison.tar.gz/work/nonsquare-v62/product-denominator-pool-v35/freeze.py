from pathlib import Path
import json,tarfile,hashlib
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
w=Path('work/nonsquare-v62/product-homogeneous-safe21-batch-v34');out=Path('research/handoff/20261103_v62/v34_safe21_three_prime_frontier');files=[]
for p in [2147483629,2147483587]:files +=[w/str(p)/x for x in ['G-native4.txt','assessed.json','source.json','run.json','run.log','check-reduced.log']]
files +=[w/x for x in ['prepare_prime.py','run_prime.py','run_batch.py','assess_three.py','batch-result.json','three-prime-assessment.json','nonleading-reconstruction3.jsonl']]
def freeze(out,name,files,dependencies,caches,status):
 archive=out/name
 with tarfile.open(archive,'w:gz',compresslevel=9)as t:
  for f in sorted(set(files)):t.add(f,arcname=str(f),recursive=False)
 assert archive.stat().st_size<32*1024**2
 m=dict(frozen=True,archive=str(archive),archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),members=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))for p in sorted(set(files))],dependencies=[dict(path=str(p),sha256=sha(p))for p in dependencies],derived_caches_omitted=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p),replay=cmd)for p,cmd in caches],QQ_claim=False)
 (out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(out/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps({k:v for k,v in m.items()if k not in ['members','dependencies','derived_caches_omitted']}),flush=True)
freeze(out,'v34_safe21_three_prime_frontier.tar.gz',files,[out.parent/'v33_safe21_homogeneous_gb_pilot/manifest.json'],[(w/'canonical-GB-state3.json.gz',f'python {w}/assess_three.py')],dict(frozen=True,QQ_claim=False,prime_count=3,modulus_bits=93,source='actual SAFE21 first20 product rows, SAME QQ rank41 criterion',all_same_QQ_column_homogenization=True,all_same_order_and_row_shifts=True,all_monic_homogeneous_fully_reduced=True,all_same_leading_module_and_support=True,GB_shape=[20,1050],GB_terms=532491,GB_degree_max=21,nonleading_coefficients=531441,stable_balanced_NONLEADING=16692,stable_fraction=16692/531441,QQ_GB_height_bound_not_proved=True,QQ_GB_and_Ih_equality_not_verified=True,prime_extension_stopped_at3=True))
w=Path('work/nonsquare-v62/product-denominator-pool-v35');out=Path('research/handoff/20261103_v62/v35_denominator_pool_comparison');files=[w/x for x in ['assess.cpp','prepare.py','assess_late_three_large.py','freeze.py','early3-assessment.jsonl','late3large-assessment.jsonl','late16-assessment.jsonl']]+[w/'late-three-large'/x for x in ['three-prime-assessment.json','nonleading-reconstruction3.jsonl']]
status=dict(frozen=True,QQ_claim=False,new_GB_or_primes_launched=0,early3=json.loads((w/'early3-assessment.jsonl').read_text().splitlines()[0]),late3large=json.loads((w/'late3large-assessment.jsonl').read_text().splitlines()[0]),late16=json.loads((w/'late16-assessment.jsonl').read_text().splitlines()[0]))
caches=[(w/'late-three-large/canonical-GB-state3.json.gz',f'python {w}/assess_late_three_large.py')]
for source in ['early3','late3large','late16']:caches.append((w/(source+'-input.txt'),'Regenerate CRT state / pairs with the saved assessment script; pass those to prepare.py STATE PAIRS OUTPUT, then assess-bin OUTPUT'))
freeze(out,'v35_denominator_pool_comparison.tar.gz',files,[out.parent/'v32_homogeneous_gb_sixteen_primes/manifest.json',out.parent/'v34_safe21_three_prime_frontier/manifest.json'],caches,status)

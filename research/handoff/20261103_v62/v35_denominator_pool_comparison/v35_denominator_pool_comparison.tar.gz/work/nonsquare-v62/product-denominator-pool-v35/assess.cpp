#include <flint/fmpq.h>
#include <flint/fmpz.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cassert>
using namespace std;
int main(int argc,char**argv){assert(argc==2);ifstream f(argv[1]);long n,m;string s1,s2;f>>n>>m>>s1>>s2;fmpz_t M1,M2,r1,r2,tmp,D1,D2,N1,N2;for(auto p:{M1,M2,r1,r2,tmp,D1,D2,N1,N2})fmpz_init(p);fmpz_set_str(M1,s1.c_str(),10);fmpz_set_str(M2,s2.c_str(),10);
vector<long>col(n),total(m),stable(m);vector<string>v1(n),v2(n);vector<fmpz*>Ds(m);for(auto&v:Ds){v=new fmpz;fmpz_init(v);fmpz_one(v);}fmpq_t q1,q2;fmpq_init(q1);fmpq_init(q2);
long independent=0;
for(long i=0;i<n;i++){f>>col[i]>>v1[i]>>v2[i];assert(f&&col[i]>=0&&col[i]<m);total[col[i]]++;fmpz_set_str(r1,v1[i].c_str(),10);fmpz_set_str(r2,v2[i].c_str(),10);bool a=fmpq_reconstruct_fmpz(q1,r1,M1),b=fmpq_reconstruct_fmpz(q2,r2,M2);if(a&&b&&fmpq_equal(q1,q2)){stable[col[i]]++;independent++;fmpz_lcm(Ds[col[i]],Ds[col[i]],fmpq_denref(q1));}}
vector<long>poolstable(m),dbits;long pooled=0,complete=0,maxbits=0,oversized=0;
for(auto D:Ds){long z=fmpz_bits(D);dbits.push_back(z);maxbits=max(maxbits,z);if(z>4096)oversized++;}
for(long i=0;i<n;i++){auto D=Ds[col[i]];if(fmpz_bits(D)>4096)continue;fmpz_set_str(r1,v1[i].c_str(),10);fmpz_set_str(r2,v2[i].c_str(),10);fmpz_mul(N1,r1,D);fmpz_mod(N1,N1,M1);fmpz_mul_2exp(tmp,N1,1);if(fmpz_cmp(tmp,M1)>0)fmpz_sub(N1,N1,M1);fmpz_mul(N2,r2,D);fmpz_mod(N2,N2,M2);fmpz_mul_2exp(tmp,N2,1);if(fmpz_cmp(tmp,M2)>0)fmpz_sub(N2,N2,M2);if(fmpz_equal(N1,N2)){pooled++;poolstable[col[i]]++;}}
for(long j=0;j<m;j++)if(total[j]==poolstable[j])complete++;
sort(dbits.begin(),dbits.end());cout<<"{\"nonleading_positions\":"<<n<<",\"GB_columns\":"<<m<<",\"independent_stable_fractions\":"<<independent<<",\"denominator_pool_stable_signed_numerators\":"<<pooled<<",\"complete_observed_columns\":"<<complete<<",\"pooled_denominator_bits_median\":"<<dbits[m/2]<<",\"pooled_denominator_bits_max\":"<<maxbits<<",\"columns_above4096_bits_skipped\":"<<oversized<<",\"QQ_claim\":false}"<<endl;
for(long j=0;j<m;j++)cout<<"{\"column\":"<<j<<",\"nonleading_terms\":"<<total[j]<<",\"independent_stable\":"<<stable[j]<<",\"pooled_stable\":"<<poolstable[j]<<",\"pooled_denominator_bits\":"<<fmpz_bits(Ds[j])<<"}\n";
}

from pathlib import Path
import json,gzip,sys
state=Path(sys.argv[1]);pairs=Path(sys.argv[2]);out=Path(sys.argv[3]);s=json.loads(gzip.decompress(state.read_bytes()));lms=sorted(map(tuple,s['GB_leading_monomials']));c={lm:i for i,lm in enumerate(lms)}
with pairs.open()as f,out.open('w')as g:
 n,m1,m2=f.readline().split();assert int(n)==len(s['nonleading_terms']);g.write(f'{n} {len(lms)} {m1} {m2}\n')
 for (lm,k,v),line in zip(s['nonleading_terms'],f):g.write(f'{c[tuple(lm)]} {line}')
print(out,flush=True)

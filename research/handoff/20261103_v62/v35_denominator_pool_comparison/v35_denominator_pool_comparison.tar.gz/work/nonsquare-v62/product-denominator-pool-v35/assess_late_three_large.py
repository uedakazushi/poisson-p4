from pathlib import Path
import json,gzip
w=Path('work/nonsquare-v62/product-denominator-pool-v35/late-three-large');w.mkdir(exist_ok=True);primes=[2147483647,2147483629,2147483587];dirs=[Path('work/nonsquare-v62/product-homogeneous-v29')/str(p)for p in primes]
termkey=lambda t:(sum(t[1]),*[-v for v in reversed(t[1])],t[0])
def read(p,d):
 with(d/'G-native4.txt').open()as f:
  n,m,k=map(int,f.readline().split());assert(n,m,k)==(10,739,0);cols=[[]for _ in range(m)]
  for i in range(n):
   for j in range(m):
    for _ in range(int(f.readline())):
     t=f.readline().split();cols[j].append((i,tuple(map(int,t[1:])),int(t[0])%p))
 C={};leading=set();terms=0
 for col in cols:
  i,ex,c=max(col,key=termkey);assert c==1;lm=(*ex,i+1);leading.add(lm)
  for ii,e,cc in col:
   terms+=1
   if ii+1==lm[4] and e==lm[:4]:continue
   C[(lm,(ii,*e))]=cc
 return C,leading,terms
base,leading,terms=read(primes[0],dirs[0]);keys=sorted(base);R=[base[k]for k in keys];mod=primes[0];del base;states=[dict(prime=primes[0],terms=terms,support_missing_zero_padded=0)]
for index,(p,d)in enumerate(zip(primes[1:],dirs[1:]),1):
 C,L,terms=read(p,d);assert L==leading and not(set(C)-set(keys)),'leading or support changed; inspect before further reconstruction';missing=len(set(keys)-set(C));inv=pow(mod,-1,p);R=[v+mod*((C.get(k,0)-v)*inv%p)for k,v in zip(keys,R)];mod*=p
 if index==1:Rprev=R.copy();modprev=mod
 states.append(dict(prime=p,terms=terms,support_missing_zero_padded=missing))
with(w/'nonleading-assess3.txt').open('w')as f:
 f.write(f'{len(keys)} {modprev} {mod}\n')
 for a,b in zip(Rprev,R):f.write(f'{a} {b}\n')
(w/'canonical-GB-state3.json.gz').write_bytes(gzip.compress(json.dumps(dict(primes=primes,modulus=str(mod),GB_leading_monomials=sorted(leading),nonleading_terms=[[list(lm),list(k),str(v)]for(lm,k),v in zip(keys,R)]),separators=(',',':')).encode(),mtime=0))
r=dict(prime_count=3,primes=primes,modulus_bits=mod.bit_length(),nonleading_positions=len(keys),states=states,all_leading_monic_homogeneous_reduced=True,QQ_GB_or_module_equality_verified=False);(w/'three-prime-assessment.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)

from pathlib import Path
s=Path('work/nonsquare-v62/kernel-v4/sparse-early-certified-kernel.cpp').read_text()
s=s.replace('assert(argc==4||argc==5);','assert(argc>=4&&argc<=6);').replace('if(argc==5){ifstream uf(argv[4]);','if(argc>=5&&string(argv[4])!="-"){ifstream uf(argv[4]);')
s=s.replace('int nm=mus.size(),nu0=n*nm;',r'''int nm=mus.size();vector<int>rowCount(n,nm),bounds(n,deg),offset(n+1);if(argc==6){ifstream bf(argv[5]);for(int i=0;i<n;i++){bf>>bounds[i];assert(bf&&bounds[i]>=0&&bounds[i]<=deg);rowCount[i]=0;for(auto mu:mus)if((int)(mu[0]+mu[1]+mu[2])<=bounds[i])rowCount[i]++;}}for(int i=0;i<n;i++)offset[i+1]=offset[i]+rowCount[i];int nu0=offset[n];vector<int>unknownRow(nu0),unknownMu(nu0);for(int i=0;i<n;i++)for(int u=0;u<rowCount[i];u++){unknownRow[offset[i]+u]=i;unknownMu[offset[i]+u]=u;}cerr<<"ROW_COEFFICIENT_DEGREE_BOUNDS ";for(int b:bounds)cerr<<b<<' ';cerr<<'\n';''')
s=s.replace('for(auto mu:mus){array<ulong,4>key=', 'for(int u=0;u<rowCount[i];u++){auto mu=mus[u];array<ulong,4>key=')
s=s.replace('for(int u=0;u<nm;u++)','for(int u=0;u<rowCount[i];u++)')
s=s.replace('int v=i*nm+u;','int v=offset[i]+u;')
s=s.replace('auto mu=mus[orig%nm];','auto mu=mus[unknownMu[orig]];').replace('relation[orig/nm].p','relation[unknownRow[orig]].p')
s=s.replace('EXACT_FULL_BOUNDED_DEGREE_KERNEL_PASS','EXACT_FULL_ROW_BOUNDED_KERNEL_PASS')
Path('work/nonsquare-v62/kernel-v5/row-bounded-sparse-kernel.cpp').write_text(s)
rows=[i for i in range(63)if i not in [14,48,55]]
Path('work/nonsquare-v62/kernel-v5/product7-genuine3.bounds').write_text(' '.join('7'if i<42 else'3'for i in rows)+'\n')
Path('work/nonsquare-v62/kernel-v5/row-bound-fixture').write_text('2 1 1\n1 1 1 0 0\n1 1 1 0 1\n')
Path('work/nonsquare-v62/kernel-v5/row-bound-fixture.bounds').write_text('1 0\n')

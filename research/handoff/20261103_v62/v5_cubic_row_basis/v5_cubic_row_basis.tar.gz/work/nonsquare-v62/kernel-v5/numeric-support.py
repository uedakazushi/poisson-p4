from pathlib import Path
import json,hashlib
wd=Path('work/nonsquare-v62/kernel-v5');src=wd/'P-global-minus57-59';p=32003
with src.open()as f:
 n,m,_=map(int,f.readline().split());data=[]
 for i in range(n):
  row=[]
  for j in range(m):
   z=f.readline().split();nt=int(z[0]);ts=[]
   for k in range(nt):
    q=z[1+4*k].split('/');c=int(q[0])%p
    if len(q)>1:c=c*pow(int(q[1])%p,-1,p)%p
    ts.append((c,*map(int,z[2+4*k:5+4*k])))
   row.append(ts)
  data.append(row)
ids=[i for i in range(63)if i not in [14,48,55,57,59]];union=set();rec=[]
for a,e,P in [(1,2,3),(2,3,5),(3,1,7)]:
 M=[[sum(c*pow(a,x,p)*pow(e,y,p)*pow(P,z,p)for c,x,y,z in ts)%p for ts in row]for row in data];A=[list(x)for x in zip(*M)];pivot=[];r=0
 for col in range(n):
  q=next((j for j in range(r,m)if A[j][col]),None)
  if q is None:continue
  A[r],A[q]=A[q],A[r];iv=pow(A[r][col],-1,p);A[r]=[v*iv%p for v in A[r]]
  for j in range(m):
   if j!=r and A[j][col]:
    mult=A[j][col];A[j]=[(v-mult*w)%p for v,w in zip(A[j],A[r])]
  pivot.append(col);r+=1
 assert r==57
 free=next(i for i in range(n)if i not in pivot);v=[0]*n;v[free]=1
 for j,c in enumerate(pivot):v[c]=-A[j][free]%p
 support=[ids[i]for i,x in enumerate(v)if x];union.update(support);rec.append(dict(point=[a,e,P],rank=r,support_original_rows=support))
obj=dict(scope='Heuristic search-support proposal only. Every discovered polynomial relation must still pass full exact QQ identity; zero samples are not a proof of identicallyzero coordinates.',input_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),prime=p,points=rec,union_original_row_support=sorted(union),numeric_zero_original_rows=[i for i in ids if i not in union]);(wd/'numeric-support.json').write_text(json.dumps(obj,indent=2)+'\n');print('union',sorted(union),'zeros',obj['numeric_zero_original_rows'],'product/gen',sum(i<42 for i in union),sum(i>=42 for i in union))
(wd/'support-product9-genuine6.bounds').write_text(' '.join('-1'if i not in union else('9'if i<42 else'6')for i in ids)+'\n')

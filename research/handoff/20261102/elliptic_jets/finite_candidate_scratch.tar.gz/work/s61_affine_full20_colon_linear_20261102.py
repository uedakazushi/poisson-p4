import sys,itertools,numpy as np,sympy as sp,time,os,subprocess,re,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from s61_affine_residual_annihilator_20261102 import *
wd=Path('/tmp/s61-affine-fixed-two-border-20261102');wd.mkdir(exist_ok=True)
v,Q,complement,paths=slice_model();W=np.array(v['fixed_normal_plane_integer_basis'],dtype=np.int64);basis=np.column_stack((W,np.eye(42,dtype=np.int64)[:,complement]))

# Original universal G6, evaluated at the same affine beta; translate to
# the toric point and its known three-plane, matching all 134 older rows.
from s61_flag_transverse_obstruction_20261101 import specialize
from s61_model import S61
model=S61()
point=json.loads((ROOT/'reports/S61_KNOWN_FIBER_AUDIT_20261031.json').read_text())
record=next(p for p in point['points'] if p['component_id']=='T01')
vals=list(map(sp.Rational,record['S61_coordinates_u1_through_u61']))
one=[i for i,w in enumerate(model.reduced['parameter_weights'])if w==1]
two,poly=specialize(model,{i:vals[i] for i in one},True)
kn=json.loads((ROOT/'reports/S61_KNOWN_FIVE_POINT_SECTION_20261101.json').read_text())
var=sp.symbols('v0:3')
sl=np.array([[residue(sp.sympify(expr).coeff(l))for l in var]for expr in kn['affine_plane_substitution']],dtype=np.int64)
C=np.zeros((46,46),dtype=np.int64);C[0,0]=1;C[1:,0]=[residue(vals[i])for i in two];C[1:,1:4]=sl;C[4:,4:]=basis
M=np.zeros((135,46,46),dtype=np.int64)
for i,row in enumerate(poly):
 for mon,value in row.items():
  if len(mon)==2:M[i,mon[0]+1,mon[1]+1]=residue(value)
  elif len(mon)==1:M[i,0,mon[0]+1]=residue(value)
  else:M[i,0,0]=residue(value)
QQ=C.T@M@C%P
assert not np.any((QQ[:134]+QQ[:134].transpose(0,2,1)-Q-Q.transpose(0,2,1))%P)
Q=QQ
j=json.load(open(ROOT/'reports/S61_KNOWN_FIVE_POINT_SECTION_20261101.json'));_,ids,base,*_=load_fiber();x=sp.symbols('v0:3')
indices=[ids.index(i) for i in [5,41]]
T=np.array([[residue(base[i])]+[residue(sp.sympify(j['affine_plane_substitution'][i]).coeff(z)) for z in x]+list(basis[i-3]) for i in indices],dtype=np.int64)%P
free=[0]+list(range(3,46));inv=np.array(sp.Matrix(T[:,1:3].tolist()).inv_mod(P)).astype(np.int64)
sub=np.zeros((46,44),dtype=np.int64);sub[free]=np.eye(44,dtype=np.int64);sub[1:3]=-inv@T[:,free]%P
assert not np.any(T@sub%P)
trans=sub.T@Q@sub%P
mon=list(itertools.combinations_with_replacement(range(1,24),2));H=np.column_stack([trans[:,a,b]+(trans[:,b,a] if a!=b else 0) for a,b in mon])%P
wd=Path('/tmp/s61-affine-full20-colon-linear-20261102');wd.mkdir(exist_ok=True)
with (wd/'input').open('w')as f:
 f.write('0\n'+' '.join(map(str,H.ravel()))+'\n')
 for i in [0]+list(range(24,44)):
  R=(trans[:,1:24,i]+trans[:,i,1:24])%P
  f.write(' '.join(map(str,R.ravel()))+'\n')
 par=[0]+list(range(24,44))
 for i in par:
  f.write(' '.join(map(str,((trans[:,1:24,i]+trans[:,i,1:24])%P).ravel()))+'\n')
 for i,j in itertools.combinations_with_replacement(par,2):
  R=(trans[:,i,j]+(trans[:,j,i] if i!=j else 0))%P
  f.write(' '.join(map(str,R))+'\n')
compile_native(ROOT/'work/s61_affine_full20_colon_linear_20261102.cpp',wd/'native')
t=time.monotonic();subprocess.run([wd/'native',wd/'input',wd/'output'],check=True,capture_output=True,text=True,env=os.environ|{'DYLD_LIBRARY_PATH':str(ROOT/'work/m2-runtime/lib')+':/opt/homebrew/lib'},timeout=90)
print((wd/'output').read_text().splitlines()[-3:],time.monotonic()-t)

import sys,itertools,numpy as np,sympy as sp,time,os,subprocess,re,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from s61_affine_residual_annihilator_20261102 import *
wd=Path('/tmp/s61-affine-fixed-two-border-20261102');wd.mkdir(exist_ok=True)
v,Q,complement,paths=slice_model();W=np.array(v['fixed_normal_plane_integer_basis'],dtype=np.int64);basis=np.column_stack((W,np.eye(42,dtype=np.int64)[:,complement]))
j=json.load(open(ROOT/'reports/S61_KNOWN_FIVE_POINT_SECTION_20261101.json'));_,ids,base,*_=load_fiber();x=sp.symbols('v0:3')
indices=[ids.index(i) for i in [5,41]]
T=np.array([[residue(base[i])]+[residue(sp.sympify(j['affine_plane_substitution'][i]).coeff(z)) for z in x]+list(basis[i-3]) for i in indices],dtype=np.int64)%P
free=[0]+list(range(3,46));inv=np.array(sp.Matrix(T[:,1:3].tolist()).inv_mod(P)).astype(np.int64)
sub=np.zeros((46,44),dtype=np.int64);sub[free]=np.eye(44,dtype=np.int64);sub[1:3]=-inv@T[:,free]%P
assert not np.any(T@sub%P)
trans=sub.T@Q@sub%P
mon=list(itertools.combinations_with_replacement(range(1,24),2));H=np.column_stack([trans[:,a,b]+(trans[:,b,a] if a!=b else 0) for a,b in mon])%P

wd=Path('/tmp/s61-affine-fixed-pair-krylov-20261102');wd.mkdir(exist_ok=True)
rng=np.random.default_rng(63971831)
ell=rng.integers(1,600,size=23)
baseabs=[residue(base[i]) for i in indices]
samples=[(1,[0,0],[0]*20),(1,baseabs,[0]*20),(1,baseabs,list(rng.integers(-10,11,size=20))),(0,[0,0],[0]*20)]
with (wd/'input').open('w')as f:
 f.write(str(len(samples))+'\n'+' '.join(map(str,H.ravel()))+'\n'+' '.join(map(str,ell))+'\n')
 for s,(t,pair,yy) in enumerate(samples):
  S=T.copy();S[:,0]=(S[:,0]-pair)%P
  sub[1:3]=-inv@S[:,free]%P;raw=sub.T@Q@sub%P
  V=np.array([t]+[0]*23+yy,dtype=np.int64)
  L=(raw+raw.transpose(0,2,1))@V
  c=np.einsum('i,rij,j->r',V,raw,V,optimize=True)%P
  R=np.column_stack([L[:,1:24],c])%P
  f.write(str(s)+'\n'+' '.join(map(str,R.ravel()))+'\n')
compile_native(ROOT/'work/s61_affine_fixed_pair_krylov_probe_20261102.cpp',wd/'exe')
subprocess.run([wd/'exe',wd/'input',wd/'out'],check=True,env=os.environ|{'DYLD_LIBRARY_PATH':str(ROOT/'work/m2-runtime/lib')+':/opt/homebrew/lib'},timeout=150)
print((wd/'out').read_text(),flush=True)

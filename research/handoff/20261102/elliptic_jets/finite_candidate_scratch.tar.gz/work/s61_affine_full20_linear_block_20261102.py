import sys,itertools,numpy as np,sympy as sp,time,os,subprocess,re,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from s61_affine_residual_annihilator_20261102 import *
wd=Path('/tmp/s61-affine-fixed-two-border-20261102');wd.mkdir(exist_ok=True)
v,Q,complement,paths=slice_model();W=np.array(v['fixed_normal_plane_integer_basis'],dtype=np.int64);basis=np.column_stack((W,np.eye(42,dtype=np.int64)[:,complement]))
j=json.load(open(ROOT/'reports/S61_KNOWN_FIVE_POINT_SECTION_20261101.json'));_,ids,base,*_=load_fiber();x=sp.symbols('v0:3')
indices=[ids.index(i) for i in [5,41]]
T=np.array([[residue(base[i])]+[residue(sp.sympify(j['affine_plane_substitution'][i]).coeff(z)) for z in x]+list(basis[i-3]) for i in indices],dtype=np.int64)%P
free=[0]+list(range(3,46));inv=np.array(sp.Matrix(T[:,1:3].tolist()).inv_mod(P)).astype(np.int64)
sub=np.zeros((46,44),dtype=np.int64);sub[free]=np.eye(44,dtype=np.int64);sub[1:3]=-inv@T[:,free]%P
assert not np.any(T@sub%P)
trans=sub.T@Q@sub%P
mon=list(itertools.combinations_with_replacement(range(1,24),2));H=np.column_stack([trans[:,a,b]+(trans[:,b,a] if a!=b else 0) for a,b in mon])%P
wd=Path('/tmp/s61-affine-full20-linear-block-20261102');wd.mkdir(exist_ok=True)
with (wd/'input').open('w')as f:
 f.write('0\n'+' '.join(map(str,H.ravel()))+'\n')
 for i in [0]+list(range(24,44)):
  R=(trans[:,1:24,i]+trans[:,i,1:24])%P
  f.write(' '.join(map(str,R.ravel()))+'\n')
compile_native(ROOT/'work/s61_affine_full20_linear_block_20261102.cpp',wd/'native')
t=time.monotonic();subprocess.run([wd/'native',wd/'input',wd/'output'],check=True,capture_output=True,text=True,env=os.environ|{'DYLD_LIBRARY_PATH':str(ROOT/'work/m2-runtime/lib')+':/opt/homebrew/lib'},timeout=90)
print((wd/'output').read_text().splitlines()[-1],time.monotonic()-t)

import sympy as s,time
from sympy.polys.rings import ring
from sympy import QQ
R,*vs=ring('a,b,c,d,s0,s1,s2,t0,t1,t2',QQ);a,b,c,d,s0,s1,s2,t0,t1,t2=vs
# Positions x,z first, momenta y,w last. Use polynomial g and inverse both
# multiplied by det(A), derived from lower T * Levi A * upper S.
one=R.one;zero=R.zero;det=a*d-b*c
def mm(A,B):return [[sum((v*B[k][j] for k,v in enumerate(row)),zero) for j in range(len(B[0]))] for row in A]
def add(A,B):return [[u+v for u,v in zip(x,y)]for x,y in zip(A,B)]
def minus(A):return [[-v for v in row]for row in A]
def times(A,n):return [[v*n for v in row]for row in A]
def tr(A):return list(map(list,zip(*A)))
def blocks(A,B,C,D):return [x+y for x,y in zip(A,B)]+[x+y for x,y in zip(C,D)]
A=[[a,b],[c,d]];adj=[[d,-b],[-c,a]];S=[[s0,s1],[s1,s2]];T=[[t0,t1],[t1,t2]]
upper=times(A,det);upperright=mm(upper,S);lower=mm(T,upper);dblock=add(mm(lower,S),tr(adj))
g=blocks(upper,upperright,lower,dblock);gi=blocks(tr(dblock),minus(tr(upperright)),minus(tr(lower)),tr(upper))
prod=mm(g,gi);assert all(x==(det**2 if i==j else 0) for i,row in enumerate(prod) for j,x in enumerate(row))
for lab in ['T5','T7']:
 out=[]
 for i,k,v in [(0,1,0),(2,3,2)]:
  x,w=gi[0][v],gi[3][v]
  # Q=e_y^(2xw e_z-x^2 e_w), or e_y^(3w² e_z-x² e_w).
  zcoef=2*x*w if lab=='T5' else 3*w*w;wcoef=-x*x
  q=(g[i][2]*(zcoef*g[k][1]+wcoef*g[k][3])-g[k][2]*(zcoef*g[i][1]+wcoef*g[i][3]))
  out.append(q)
 start=time.monotonic();gg=out[0].gcd(out[1]);h=gg;v=0
 while True:
  q,r=h.div(det)
  if r:break
  h=q;v+=1
 print(lab,[len(p) for p in out],v,len(h),str(h)[:80],time.monotonic()-start,flush=True)

#include <flint/nmod_mat.h>
#include <flint/nmod.h>
#include <array>
#include <vector>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <fstream>
#include <cassert>
using namespace std;
constexpr int eqs=134,n=23,n2=276,n3=2300,m3=3082,sy=782,p=32003,low=300,target=166;
struct Z {nmod_mat_t m; Z(int r,int c){nmod_mat_init(m,r,c,p);} ~Z(){nmod_mat_clear(m);} ulong& at(int i,int j){return nmod_mat_entry(m,i,j);}};
static vector<int> selectrows(Z &a,int rank){
    nmod_mat_t E;nmod_mat_init_set(E,a.m);vector<slong> perm(a.m->r);iota(perm.begin(),perm.end(),0);
    auto r=nmod_mat_lu(perm.data(),E,0);assert(r==rank);nmod_mat_clear(E);return {perm.begin(),perm.begin()+rank};
}
int main(int argc,char**argv){
 assert(argc==3);ifstream f(argv[1]);ofstream o(argv[2]);int np;f>>np;
 int pair[n][n],tri[n][n][n],ct=0;
 for(int i=0;i<n;i++)for(int j=i;j<n;j++)pair[i][j]=pair[j][i]=ct++;assert(ct==n2);ct=0;
 for(int i=0;i<n;i++)for(int j=i;j<n;j++)for(int k=j;k<n;k++){array<int,3> a{i,j,k};do{tri[a[0]][a[1]][a[2]]=ct;}while(next_permutation(a.begin(),a.end()));ct++;}assert(ct==n3);
 Z H(eqs,n2),H3(m3,n3);
 for(int r=0;r<eqs;r++)for(int i=0;i<n;i++)for(int j=i;j<n;j++){
  ulong v;f>>v;assert(f&&v<p);H.at(r,pair[i][j])=v;for(int k=0;k<n;k++)H3.at(r*n+k,tri[i][j][k])=v;
 }
 Z HT(n2,eqs);nmod_mat_transpose(HT.m,H.m);auto p2=selectrows(HT,eqs),p3=selectrows(H3,n3);
 vector<int>cf,rr;vector<bool>used2(n2),used3(m3);for(int j:p2)used2[j]=true;for(int j:p3)used3[j]=true;
 for(int j=0;j<n2;j++)if(!used2[j])cf.push_back(j);for(int j=0;j<m3;j++)if(!used3[j])rr.push_back(j);
 // C3 * H3[p3] = H3[rr]. Thus row-reduction multipliers are independent of all y's.
 Z c3(sy,n3),A3(n3,n3),B3(n3,sy),X3(n3,sy);
 for(int i=0;i<n3;i++){for(int j=0;j<n3;j++)A3.at(i,j)=H3.at(p3[j],i);for(int j=0;j<sy;j++)B3.at(i,j)=H3.at(rr[j],i);}
 ulong determinant3=nmod_mat_det(A3.m);assert(determinant3);
 assert(nmod_mat_solve(X3.m,A3.m,B3.m));nmod_mat_transpose(c3.m,X3.m);
 Z A2(eqs,eqs),A2inv(eqs,eqs);for(int i=0;i<eqs;i++)for(int j=0;j<eqs;j++)A2.at(i,j)=H.at(i,p2[j]);
 assert(nmod_mat_inv(A2inv.m,A2.m));o<<"fixed "<<eqs<<" "<<n3<<" "<<nmod_mat_det(A2.m)<<" "<<determinant3<<"\n";
 for(int col:p2)o<<col<<" ";o<<"\n";for(int row:p3)o<<row<<" ";o<<"\n";o.flush();
 // All 21 coefficients t,y1,...,y20 of the pure-X^2 column block, at once.
 Z all_linear(sy,21*cf.size());std::vector<Z*> alpha;
 for(int h=0;h<21;h++){
   Z raw(eqs,n);for(int i=0;i<eqs;i++)for(int j=0;j<n;j++){f>>raw.at(i,j);assert(f&&raw.at(i,j)<p);}
   Z lowrows(m3,n2);
   for(int i=0;i<eqs;i++)for(int j=0;j<n;j++)for(int k=0;k<n;k++)lowrows.at(i*n+j,pair[j][k])=raw.at(i,k);
   Z hi(n3,n2),extra(sy,n2),product(sy,n2);
   for(int i=0;i<n3;i++)for(int j=0;j<n2;j++)hi.at(i,j)=lowrows.at(p3[i],j);
   for(int i=0;i<sy;i++)for(int j=0;j<n2;j++)extra.at(i,j)=lowrows.at(rr[i],j);
   nmod_mat_mul(product.m,c3.m,hi.m);nmod_mat_sub(product.m,extra.m,product.m);
   Z ph(sy,eqs),hf(eqs,cf.size()),af(sy,cf.size()),reduced(sy,cf.size());
   for(int i=0;i<sy;i++)for(int k=0;k<eqs;k++)ph.at(i,k)=product.at(i,p2[k]);
   Z* mult = new Z(sy,eqs);nmod_mat_mul(mult->m,ph.m,A2inv.m);alpha.push_back(mult);
   for(int i=0;i<eqs;i++)for(int k=0;k<int(cf.size());k++)hf.at(i,k)=H.at(i,cf[k]);
   nmod_mat_mul(af.m,mult->m,hf.m);
   for(int i=0;i<sy;i++)for(int k=0;k<int(cf.size());k++)all_linear.at(i,h*cf.size()+k)=(product.at(i,cf[k])+p-af.at(i,k))%p;
 }
 Z AT(21*cf.size(),sy),Et(21*cf.size(),sy);nmod_mat_transpose(AT.m,all_linear.m);nmod_mat_set(Et.m,AT.m);
 std::vector<slong> perm(Et.m->r);iota(perm.begin(),perm.end(),0);
 auto rank=nmod_mat_lu(perm.data(),Et.m,0);o<<"all-linear-rank "<<rank<<" kernel "<<sy-rank<<"\n";o.flush();
 // D contains the 91 independent constant cancellations of the X^2 block.
 int rker=sy-rank;
 Z ker(sy,sy),D(rker,sy);
 assert(nmod_mat_nullspace(ker.m,AT.m)==rker);
 for(int i=0;i<rker;i++) for(int j=0;j<sy;j++) D.at(i,j)=ker.at(j,i);
 Z check(rker,21*cf.size());nmod_mat_mul(check.m,D.m,all_linear.m);assert(nmod_mat_is_zero(check.m));
 // A_h is the reduced quadratic elimination multiplier, after taking those combinations.
 std::vector<Z*> A;
 for(auto* a:alpha){Z* c=new Z(rker,eqs); nmod_mat_mul(c->m,D.m,a->m);A.push_back(c);}
 Z DP(rker,n3),left(rker,m3);nmod_mat_mul(DP.m,D.m,c3.m);
 for(int i=0;i<rker;i++){for(int j=0;j<n3;j++)left.at(i,p3[j])=(p-DP.at(i,j))%p;for(int j=0;j<sy;j++)left.at(i,rr[j])=D.at(i,j);}
 Z Htest(rker,n3);nmod_mat_mul(Htest.m,left.m,H3.m);assert(nmod_mat_is_zero(Htest.m));
 int nh=21;
 vector<Z*> raw;
 for(int h=0;h<nh;h++){auto* v=new Z(eqs,n);for(int i=0;i<eqs;i++)for(int j=0;j<n;j++){f>>v->at(i,j);assert(f&&v->at(i,j)<p);}raw.push_back(v);}
 int num2=nh*(nh+1)/2;
 Z C(eqs,num2);
 for(int j=0;j<num2;j++)for(int i=0;i<eqs;i++){f>>C.at(i,j);assert(f&&C.at(i,j)<p);}
 Z Xlinear(rker,num2*n);int a2[21][21];ct=0;
 for(int h=0;h<nh;h++)for(int k=h;k<nh;k++) {
  int ix=ct++; a2[h][k]=a2[k][h]=ix;
  Z cc(m3,n),raw_product(rker,n),v(rker,n),w(rker,n);
  for(int i=0;i<eqs;i++)for(int j=0;j<n;j++)cc.at(i*n+j,j)=C.at(i,ix);
  nmod_mat_mul(raw_product.m,left.m,cc.m);nmod_mat_mul(v.m,A[h]->m,raw[k]->m);
  if(h!=k)nmod_mat_mul(w.m,A[k]->m,raw[h]->m);
  for(int i=0;i<rker;i++)for(int j=0;j<n;j++)Xlinear.at(i,ix*n+j)=(raw_product.at(i,j)+2*p-v.at(i,j)-w.at(i,j))%p;
 }
 int rk=nmod_mat_rank(Xlinear.m);o<<"linear-X rank "<<rk<<" constant syzygies "<<rker-rk<<"\n";
 Z XT(num2*n,rker),K(rker,rker),E(rker-rk,rker);nmod_mat_transpose(XT.m,Xlinear.m);assert(nmod_mat_nullspace(K.m,XT.m)==rker-rk);
 for(int i=0;i<rker-rk;i++)for(int j=0;j<rker;j++)E.at(i,j)=K.at(j,i);
 Z Yonly(rker-rk,nh*(nh+1)*(nh+2)/6);
 vector<Z*> Y;for(int h=0;h<nh;h++){Z Ealpha(rker-rk,eqs);nmod_mat_mul(Ealpha.m,E.m,A[h]->m);Z* tmp=new Z(rker-rk,num2);nmod_mat_mul(tmp->m,Ealpha.m,C.m);Y.push_back(tmp);}
 ct=0;for(int i=0;i<nh;i++)for(int j=i;j<nh;j++)for(int k=j;k<nh;k++){
  for(int row=0;row<rker-rk;row++)Yonly.at(row,ct)=(Y[i]->at(row,a2[j][k])+(j!=i?Y[j]->at(row,a2[i][k]):0)+(k!=j?Y[k]->at(row,a2[i][j]):0))%p;
  ct++;
 }
 int ry=nmod_mat_rank(Yonly.m);o<<"pure-Y rank "<<ry<<" complete dependencies "<<rker-rk-ry<<"\n";o.flush();
}

import sys,itertools,numpy as np,sympy as sp,time,os,subprocess,re,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
from s61_affine_residual_annihilator_20261102 import *
from s61_model import S61,X,J
wd=Path('/tmp/s61-affine-homogeneous-t-matrix-20261102');wd.mkdir(exist_ok=True)
v,Q,complement,paths=slice_model();W=np.array(v['fixed_normal_plane_integer_basis'],dtype=np.int64);basis=np.column_stack((W,np.eye(42,dtype=np.int64)[:,complement]))
j=json.load(open(ROOT/'reports/S61_KNOWN_FIVE_POINT_SECTION_20261101.json'));_,ids,base,*_=load_fiber();x=sp.symbols('v0:3')
slopes=np.array([[residue(sp.sympify(expr).coeff(z)) for z in x]for expr in j['affine_plane_substitution']],dtype=np.int64)
indices=[ids.index(i) for i in [5,41]]
T=np.array([[residue(base[i])]+list(slopes[i])+list(basis[i-3]) for i in indices],dtype=np.int64)%P
free=[0]+list(range(3,46));inv=np.array(sp.Matrix(T[:,1:3].tolist()).inv_mod(P)).astype(np.int64)
shift=np.random.default_rng(1625433).integers(-4,5,size=20)
pairs=[[0,0],[residue(base[i]) for i in indices]]
env=os.environ|{'DYLD_LIBRARY_PATH':str(ROOT/'work/m2-runtime/lib')+':/opt/homebrew/lib'}
# Find a genuine flag at infinity, supported on span(e_x,e_z). At this
# support both prescribed coordinates vanish automatically.
model=S61(); flag_basis=[]
for F in [X[2]**2,2*X[2]*X[4],X[4]**2]:
 m=X[0]**2*J;m[1,3]+=F;m[3,1]-=F
 raw=model.normalize(m)['parameters'];qv=np.array([residue(raw[i]) for i in ids],dtype=np.int64)
 plane=qv[:3];res=qv-slopes@plane
 assert not np.any(res[:3])
 bn=np.array(sp.Matrix(basis.tolist()).inv_mod(P),dtype=np.int64)@res[3:]%P
 flag_basis.append(np.array([0]+list(plane)+list(bn),dtype=np.int64))
flag_basis=np.array(flag_basis)
tor=np.einsum('ir,qrs,js->qij',flag_basis,Q,flag_basis,optimize=True)%P
qfull=flag_basis[2];assert not np.any(T@qfull%P) and not np.any(np.einsum('i,rij,j->r',qfull,Q,qfull,optimize=True)%P)
flag_y=qfull[26:]
print('flag coord',qfull[:4].tolist(),flag_y.tolist(),flush=True)
native=ROOT/'work/s61_affine_homogeneous_t_matrix_20261102.cpp'
compile_native(native,wd/'exe')
for pi,pair in enumerate(pairs):
 # Embed old coordinates in (t,X23,y'20) with y'=y+shift*t.
 S=T.copy();S[:,0]=(S[:,0]-pair)%P
 transform=np.eye(44,dtype=np.int64);transform[24:,0]=-shift
 sub=np.zeros((46,44),dtype=np.int64);sub[free]=np.eye(44,dtype=np.int64);sub[1:3]=-inv@S[:,free]%P;sub=sub@transform%P
 assert not np.any(S@sub%P);raw=sub.T@Q@sub%P
 mon=list(itertools.combinations_with_replacement(range(24),2))
 H=np.column_stack([raw[:,a,b]+(raw[:,b,a] if a!=b else 0) for a,b in mon])%P
 samples=[np.zeros(20,dtype=np.int64),shift,flag_y]
 with (wd/f'input{pi}').open('w')as f:
  f.write(str(len(samples))+'\n'+' '.join(map(str,H.ravel()))+'\n'+' '.join(['0']*24)+'\n')
  for i,y in enumerate(samples):
   z=np.array([0]*24+list(y),dtype=np.int64)
   L=((raw+raw.transpose(0,2,1))@z)[:,:24]%P
   c=np.einsum('i,rij,j->r',z,raw,z,optimize=True)%P
   if (pi,i)==(1,1) or i==2:
    xx=(np.array([1]+[0]*23) if i==1 else qfull[free][:24])%P
    combined=np.array(list(xx)+list(y),dtype=np.int64)
    val=np.einsum('i,rij,j->r',combined,raw,combined,optimize=True)%P
    val2=(H@np.array([int(xx[a])*int(xx[b])%P for a,b in mon])+L@xx+c)%P
    print('point',pi,i,'encoded',np.count_nonzero(val2),'actual',np.count_nonzero(val),'lift',np.count_nonzero((sub@combined-(np.array([1]+[0]*45)if i==1 else qfull))%P),'raw',val[:8].tolist(),'enc',val2[:8].tolist(),flush=True)
    assert not np.any(val) and not np.any(val2)
   f.write(str(i)+'\n'+' '.join(map(str,np.column_stack([L,c]).ravel()))+'\n')
 subprocess.run([wd/'exe',wd/f'input{pi}',wd/f'out{pi}'],check=True,env=env,timeout=120)
 print(pi,(wd/f'out{pi}').read_text(),flush=True)

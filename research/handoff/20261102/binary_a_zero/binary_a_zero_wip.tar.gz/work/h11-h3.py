import sys,itertools
sys.path.insert(0,'code')
from s61_binary_a_zero_atlas_20261102 import *
r,w,g=transversal(B,1,1,8*B/3+7)
F,W,ds=reduce_line(r,w,g)
heavy=[i for i,n in enumerate(W) if n==3]
def polynomial(f,i):
 exp=tuple(int(j==i) for j in range(len(W)))
 return sp.Poly.from_dict({(m[0],):int(c) for m,c in f.items() if m[1:]==exp},B,modulus=PRIME).as_expr()
M=sp.Matrix([[polynomial(f,i) for i in heavy] for f,k in zip(F,g) if k==3 and f])
print('M',M,flush=True)
q=sp.Poly(0,B,modulus=PRIME)
for inds in itertools.combinations(range(M.rows),3):
 d=sp.Poly(M[list(inds),:].det(),B,modulus=PRIME)
 q=sp.gcd(q,d)
 if q.degree()==0:break
print('gcd',q.monic().factor_list(),flush=True)

from pathlib import Path
import sys,pickle,json,subprocess,tempfile,os,time
sys.path.insert(0,'code')
import sympy as sp
import s61_binary_endpoint_full_transverse_20261102 as T
from fractions import Fraction
raw=pickle.load(open('work/h11-orbit-raw.pkl','rb'));w,g=json.loads(Path('work/h11-orbit-weights.json').read_text());vs=[i for i in range(47) if i not in T.CUTS]
env=os.environ|{'DYLD_LIBRARY_PATH':str(T.ROOT/'work/m2-runtime/lib')+':/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'}
cp={f:sp.Poly(f,T.A,T.B,T.D,T.E).terms() for row in raw for f in row.values()}
def at(slope,p=0):
 b=Fraction(7)/(slope-Fraction(8,3));e=b*slope;pt=(0,b,1,e)
 def val(f):
  f=sum(Fraction(c)*__import__('math').prod(v**power for v,power in zip(pt,m)) for m,c in cp[f])
  return f.numerator*pow(f.denominator,-1,p)%p if p else f
 cv={x:val(x) for x in cp}
 def pol(row):
  return '+'.join('('+str(cv[f])+')'+''.join('*q'+str(i) for i in mon) for mon,f in row.items() if cv[f]) or '0'
 for h in [1,2,3,4]:
  rng='QQ' if not p else f'(ZZ/{p})';weights=','.join(str(w[i]) for i in vs)
  r='R='+rng+'['+','.join('q'+str(i) for i in vs)+',Degrees=>{'+weights+'}]; I=ideal('+','.join(map(pol,raw))+');\n'
  y='+'.join(str((i*17+6)%23+1)+'*q'+str(i) for i in vs if w[i]==h)
  r+='H=ideal('+y+');S=saturate(I,H);print toString hilbertSeries(R/S,Reduce=>true);\n'
  r+='A='+rng+'[zz_0..zz_'+str(len(vs)-1)+',MonomialOrder=>{Weights=>{'+weights+'},GRevLex}];transfer=map(A,R,gens A);D=(transfer S)+ideal(transfer('+y+')-1);G=gb D;print (dim(A/D),degree D);print toString apply(numgens A,i->toString(A_i%G));print toString gens G;\n'
  out=Path('work/h11-a0-ex-'+str(slope).replace('/','_')+'-'+str(h)+'.out')
  with tempfile.TemporaryDirectory() as wd:
   src=Path(wd)/'s.m2';src.write_text(r)
   with out.open('w') as f:proc=subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',str(src)],cwd=wd,env=env,stdout=f,stderr=f,timeout=30)
  print(slope,h,out.read_text()[:100].replace('\n',' '),flush=True)
  if '(0, ' in out.read_text():break
if __name__=='__main__':
 for slope in map(Fraction,['2','5/3','5/4','-10','5/2','25/14']):
  try:at(slope)
  except Exception as e:print(slope,str(e),flush=True)

from pathlib import Path
import sys,json,inspect,pickle,os,subprocess
sys.path.insert(0,'code')
import sympy as s
import s61_binary_endpoint_full_transverse_20261102 as T
import s61_binary_zero_pair_stratum_removal_20261102 as Z
rows=pickle.load(open('work/h11-orbit-raw.pkl','rb'));weights,grades=json.load(open('work/h11-orbit-weights.json'));a,b,d,e=T.A,T.B,T.D,T.E
env0=os.environ|{'DYLD_LIBRARY_PATH':str(T.ROOT/'work/m2-runtime/lib')+':/opt/homebrew/lib'}
def run(kappa,mu,tag):
 const={a:0,d:1,e:kappa*b+mu}
 steps=[]
 for W in range(1,5):
  r=[i for i,g in enumerate(grades) if g==W];v=[i for i in range(47) if i not in T.CUTS and weights[i]==W]
  J=s.Matrix([[rows[i].get((j,),s.S.Zero).subs(const) for j in v] for i in r])
  while True:
   k=next(((i,j) for i in range(J.rows) for j in range(J.cols) if J[i,j].is_Rational and J[i,j]),None)
   if k is None:break
   i,j=k;steps.append((r[i],v[j]));p=J[i,j];J=(J-J[:,j]*J[i,:]/p).applyfunc(s.cancel);J.row_del(i);J.col_del(j);r.pop(i);v.pop(j)
 text=inspect.getsource(T.reduce_test_line).replace('PIVOT_STEPS','OUR_PIVOTS').replace('assert sorted(weights[i] for i in free) == [1]*7+[2]','assert len(free)>=8').replace('range(8)','range(len(free))').replace('constants = {B:6,D:12,E:16}','constants = C_N').replace('f.subs(constants),A','f.subs(constants),B')
 env=vars(T).copy()|{'OUR_PIVOTS':steps,'C_N':const};exec(text,env);F,fw,ds=env['reduce_test_line'](rows,weights,grades)
 inp=Path('/tmp/h11-a0-'+tag+'.in');out=Path('/tmp/h11-a0-'+tag+'.out');n=Z.write_quartics(inp,F,fw,grades);subprocess.run(['/tmp/binary-atlas-popov',str(inp),str(out)],env=env0,check=True,timeout=92,capture_output=True);print(tag,[(i,j) for i,j in steps][:2],out.read_text(),flush=True)
if __name__=='__main__':
 for k,mu,tag in [(s.Rational(8,3),11,'p2'),(s.Rational(9,4),13,'p3'),(s.Rational(7,4),2,'p4')]:run(k,mu,tag)

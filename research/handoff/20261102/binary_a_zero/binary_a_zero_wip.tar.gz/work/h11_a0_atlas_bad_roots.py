from binary_linear_atlas_direct import *
import s61_binary_endpoint_full_transverse_20261102 as T
import inspect
env=vars(T).copy();exec(inspect.getsource(T.original_transversal).replace('35:D,48:E','34:sp.Symbol("c"),35:D,48:E,49:-5*sp.Symbol("c")'),env)
raw,weights,gr,_,_=env['original_transversal'](); c=s.Symbol('c');params=[a,b,c,d,e];cache={f:s.Poly(f,*params).terms() for row in raw for f in row.values()}
def trial(pt):
 values={f:sum(Fraction(cf)*__import__('math').prod(v**i for v,i in zip(pt,ex)) for ex,cf in terms) for f,terms in cache.items()}
 pol='R=(ZZ/32003)['+','.join('q'+str(v) for v in vs)+',Degrees=>{'+','.join(str(weights[v]) for v in vs)+'}];I=ideal('+','.join(mkrow(row,values.get) for row in raw)+');print toString hilbertSeries(R/I,Reduce=>true);print(q44%gb I==0,q44^2%gb I==0);'
 print(pt,run(pol,timeout=25),flush=True)
for t in [857,15991,31996,28233,2526,3,31961]:
 trial((0,t,1,1,(8*t*pow(3,-1,32003)+7)%32003))

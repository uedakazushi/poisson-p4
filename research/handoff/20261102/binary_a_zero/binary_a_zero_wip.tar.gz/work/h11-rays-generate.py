from pathlib import Path
src=Path('work/h11_extra_orbit_geometry.py').read_text()
start=src.index('for r in map');head=src[:start]
runner=src[start:]+'''
  rounded=[str(s.factor(Q[i,j])) for i,j in pairs];print('tensor',rounded,flush=True)
  qcuts=list(O.T.to_DM().rref()[1]);bcuts=list(H.T.to_DM().rref()[1]);spt=[int(x) for x in range(45) if q[x]];tag=tag+'-'+str(spt[-1])+('-b' if 35 in spt else '')
  obj=dict(q=list(map(str,q)),beta=[str(beta.get(j,0)) for j in one],fixed=fixed,bcuts=bcuts,qcuts=qcuts,H=list(map(lambda row:list(map(str,row)),H.tolist())),tensor=rounded)
  Path('work/h11-ray-'+tag+'.json').write_text(json.dumps(obj))
'''
Path('work/h11-ray-data.py').write_text(head+runner)
src=Path('code/s61_t5_critical_ambient_length_20261102.py').read_text()
beg=src.index('    model=S61()');end=src.index('    loc=',beg)
src=src[:beg]+'''    import sys,itertools
    m=S61()
    obj=json.loads(Path(sys.argv[1]).read_text());generic=len(sys.argv)>2 and sys.argv[2]=='generic'
    one=[i for i,w in enumerate(m.reduced['parameter_weights']) if w==1]
    two=[i for i,w in enumerate(m.reduced['parameter_weights']) if w==2]
    q=sym.Matrix(obj['q']).applyfunc(sym.Rational);beta=sym.Matrix(obj['beta']).applyfunc(sym.Rational)
    if generic:
        H=sym.Matrix(obj['H']).applyfunc(sym.Rational);beta=H*sym.Matrix([i**2+2*i+3 for i in range(H.cols)])
    cuts={two[obj['fixed']],*[one[i] for i in obj['bcuts']],*[two[i] for i in obj['qcuts']]}
    variables=[i for i in range(62) if i not in cuts];model=m
'''+src[end:];src=src.replace('    assert len(variables)==43','    N=len(variables)');src=src.replace('sym.zeros(135,43)','sym.zeros(135,N)').replace('    assert len(piv)==40 and kernel.cols==3','    n=kernel.cols; print("normal",n, "t tangent",kernel[-1,:],flush=True)\n    if n==0:return [1]').replace('sym.zeros(43,40)','sym.zeros(N,len(piv))').replace('sym.eye(40)','sym.eye(len(piv))').replace('ring("v0,v1,v2",QQ)','ring(",".join(f"v{i}" for i in range(n)),QQ)').replace('for j in range(3)','for j in range(n)').replace('for i in range(43)','for i in range(N)')
src=src.replace('[(i,j,d-i-j) for d in range(7) for i in range(d+1) for j in range(d-i+1)]','[a for d in range(7) for a in itertools.product(range(d+1),repeat=n) if sum(a)==d]')
src=src[:src.index('    assert hilbert==')]+'''    return hilbert
print(ambient_certificate(),flush=True)
'''
Path('work/h11-ray-trans.py').write_text('import sys;sys.path.insert(0,"code")\n'+src.replace('ROOT=Path(__file__).resolve().parents[1]','ROOT=Path.cwd()'))

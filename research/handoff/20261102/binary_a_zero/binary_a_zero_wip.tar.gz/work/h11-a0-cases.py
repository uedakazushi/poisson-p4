from pathlib import Path
import json,pickle,os,sys,subprocess,tempfile
import sympy as s
from fractions import Fraction
sys.path.insert(0,'code')
import s61_binary_endpoint_full_transverse_20261102 as T
raw=pickle.load(open('work/h11-orbit-raw.pkl','rb'));weights,grades=json.load(open('work/h11-orbit-weights.json'))
chart=T.load_report('S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101')['linear']
F=[i for i in range(47) if i not in T.CUTS];p=32003
def red(f):
 f=s.Rational(f);return int(f.p)*pow(int(f.q),-1,p)%p
def ring():
 return 'R=(ZZ/32003)['+','.join('q'+str(i) for i in F)+',Degrees=>{'+','.join(str(weights[i]) for i in F)+'}];'
def run(cmd):
 env=os.environ|{'DYLD_LIBRARY_PATH':str(Path.cwd()/'work/m2-runtime/lib')+':/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'}
 with tempfile.TemporaryDirectory() as wd:
  src=Path(wd)/'case.m2';src.write_text(cmd)
  return subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',str(src)],cwd=wd,env=env,capture_output=True,text=True,check=True,timeout=35).stdout
records=[]
for slope in ['2','5/3','5/4','-10','5/2','25/14','5','d0']:
 name=slope.replace('/','_')
 if slope=='d0':d=0;b=6;e=16
 else:
  d=1;r=s.Rational(slope);b=7/(r-s.Rational(8,3));e=b*r
 point={T.A:0,T.B:b,T.D:d,T.E:e};coeff={}
 def pol(row):
  terms=[]
  for mon,f in row.items():
   if f not in coeff:coeff[f]=red(f.subs(point))
   if coeff[f]:terms.append(str(coeff[f])+''.join('*q'+str(i) for i in mon))
  return '+'.join(terms) or '0'
 cmd=ring()+'I=ideal('+','.join(pol(row) for row in raw)+');S=(ZZ/32003)[v];\n'
 ideals=[]
 for i,f in enumerate(sorted(Path('work').glob('h11-ray-'+name+'-*.json'))):
  ob=json.loads(f.read_text());q=list(map(s.Rational,ob['q']));be=list(map(s.Rational,ob['beta']));q0=chart['fixed'];pnt=[q[j]for j in chart['cols']]+[0,be[2],be[3]]
  assert q[q0]==1 and not any(pnt[j] for j in T.CUTS)
  vals=','.join(str(red(pnt[j]))+'*v^'+str(weights[j]) for j in F)
  j0=min((j for j in F if pnt[j]),key=lambda j:weights[j])
  eq=[]
  for j in F:
   c=red(pnt[j])
   if j==j0:continue
   if not c:eq.append('q'+str(j));continue
   u,v=divmod(weights[j],weights[j0]);assert not v
   eq.append(f'q{j}-{red(pnt[j]/pnt[j0]**u)}*q{j0}^{u}')
  cmd+=f'K{i}=ideal('+','.join(eq)+');\n';ideals.append('K'+str(i))
  records.append(dict(slope=slope,q={str(j):str(k) for j,k in enumerate(q) if k},beta={str(j):str(k) for j,k in enumerate(be) if k},type={'2':'xzw','5/3':'T2','5/4':'double root','-10':'smooth','5/2':'T5','25/14':'T6'}[slope]))
 cmd+='K='+('intersect('+','.join(ideals)+')' if len(ideals)>1 else ideals[0] if ideals else 'ideal vars R')+';g=gb I;assert all(flatten entries gens K,f->any(1..8,n->((f^n)%g)==0));print toString hilbertSeries(R/I,Reduce=>true);\n'
 try: print(slope,run(cmd),flush=True)
 except Exception as er:print(slope,str(er),getattr(er,'stderr',''),flush=True)
Path('work/h11-ray-model-points.json').write_text(json.dumps(records,indent=2)+'\n')

from pathlib import Path
import sys,inspect,json,pickle,os,tempfile,subprocess
sys.path.insert(0,'code')
import sympy as s
import s61_binary_endpoint_full_transverse_20261102 as T
import s61_binary_zero_pair_stratum_removal_20261102 as Z
a,b,d,e=T.A,T.B,T.D,T.E
rows=pickle.load(open('work/h11-orbit-raw.pkl','rb'));weights,grades=json.load(open('work/h11-orbit-weights.json'));steps=json.load(open('work/h11-a0-atlas-pivots.json'))
text=inspect.getsource(T.reduce_test_line).replace('PIVOT_STEPS','OUR_PIVOTS').replace('assert sorted(weights[i] for i in free) == [1]*7+[2]','print("vars",free,[weights[i] for i in free],flush=True)').replace('range(8)','range(len(free))').replace('constants = {B:6,D:12,E:16}','constants = {A:0,D:1,E:sp.Rational(8,3)*B+7}').replace('f.subs(constants),A','f.subs(constants),B')
env=vars(T).copy();env['OUR_PIVOTS']=steps;exec(text,env);F,fweights,ds=env['reduce_test_line'](rows,weights,grades)
def write(k):
 text=inspect.getsource(Z.write_quartics).replace('monomials(weights,4)','monomials(weights,k)').replace('grade > 4','grade > k').replace('4-grade','k-grade')
 env=vars(Z).copy();env['k']=k;exec(text,env);p=Path('/tmp/h11-a0-full-weight'+str(k)+'.in');nr=env['write_quartics'](p,F,fweights,grades);return p,nr
print('compiled residuals',sum(map(len,F)),[len(x) for x in ds],flush=True)
inp,nr=write(4);print('matrix',nr,flush=True)
root=Path.cwd();env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'}
out=Path('/tmp/h11-a0-full-weight4.out');subprocess.run(['/tmp/binary-atlas-popov',str(inp),str(out)],check=True,capture_output=True,timeout=100,env=env);print(out.read_text(),flush=True)

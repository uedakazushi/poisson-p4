from pathlib import Path
from textwrap import dedent
p=Path('code/s61_binary_endpoint_full_transverse_20261102.py').read_text()
head='''"""Full positive-weight central slices at a=0, K=0 in the nonsquare chart."""
import sympy as sp
from sympy.polys.rings import ring
from s61_binary_endpoint_full_transverse_20261102 import (
    PRIME, CUTS, B, S61, specialize, load_report)
'''
s=p[p.index('def original_transversal'):p.index('def reduce_test_line')]
i=s.index('    pi =');j=s.index('    normal =');s=s[:i]+s[j:]
s=s.replace('def original_transversal():','def transversal(b,c,d,e):').replace('3:A,13:B,35:D,48:E','13:b,34:c,35:d,48:e,49:-5*c').replace('rows,weights,grades,selected,determinant','rows,weights,grades')
red=p[p.index('def reduce_test_line'):p.index('def monomials')]
piv=Path('work/h11-a0-atlas-pivots.json').read_text()
red=red.replace('def reduce_test_line(', 'def reduce_line(').replace('Keep b=6,d=12,e=16 and a indeterminate. Invert only constants on this line.', 'Eliminate 27 coordinates using minors invertible on the entire test line.').replace('== [1]*7+[2]','== [1]*7+[2]*5+[3]*3').replace('range(8)','range(len(free))').replace("ring('a,'","ring('b,'").replace('    constants = {B:6,D:12,E:16}\n','').replace('f.subs(constants),A','f,B').replace('.subs(constants) for j',' for j')
Path('code/s61_binary_a_zero_atlas_20261102.py').write_text(head+'\nPIVOT_STEPS = '+piv+'\n\n'+s+red)

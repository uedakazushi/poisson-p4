import sys,json
sys.path.insert(0,'code')
from s61_binary_a_zero_ray_transverse_20261102 import *
points=json.loads((ROOT/'code/certificates/s61_binary_a_zero_points_20261102.json').read_text())
print([(x['type'],x['transverse_hilbert_mod_32003']) for x in all_rays(points)])

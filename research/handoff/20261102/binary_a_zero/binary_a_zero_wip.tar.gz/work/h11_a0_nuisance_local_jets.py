import json,sympy as s,inspect,sys,numpy as np
sys.path.insert(0,'code')
import s61_binary_endpoint_engine_20261101 as E
src=inspect.getsource(E.verify_endpoint);src=src[:src.index('    trow=')]+'''    return n,length,len(rref(A2)[1]),rk\n'''
src=src.replace('def verify_endpoint(extra_zero):','def verify_at(SAMPLE):');i=src.index('r[\'sample\'][extra_zero]');j=src.index('\n',i);src=src[:i]+"r['sample']=SAMPLE"+src[j:];src=src.replace("n==11 and J*T==s.zeros(135,11) and T[-1,:]==s.zeros(1,11)","J*T==s.zeros(135,n) and T[-1,:]==s.zeros(1,n)")
src=src.replace('params==[0,1,3] and len(normal)==8','len(normal)==n-3').replace('len(C)==len(R)==34','len(C)==len(R)==45-n').replace('np.eye(34,dtype=np.int64)','np.eye(45-n,dtype=np.int64)')
i=src.index('    Tn=T');j=src.index('    H%=p',i);src=src[:i]+src[j:];env=vars(E).copy();exec(src,env);calc=env['verify_at']
nu=[4,24,25,26,33,36,47,50];one=[4,5,12,13,14,25,26,27,34,35,36,37,48,49,50,51]
for slope in [2,s.Rational(5,4),-10,s.Rational(5,2),s.Rational(5,3),s.Rational(25,14)]:
 b=7/(s.Rational(slope)-s.Rational(8,3));e=b*slope;beta=dict.fromkeys([i-1 for i in one],s.S.Zero);beta.update(dict(zip(nu,[3,7,8,9,10,13,14,17])));beta.update({13:b,34:1,35:1,48:e,49:-5});sample={f'u{i+1}':str(k) for i,k in beta.items()};print('start',slope,flush=True)
 try:print('done',slope,calc(sample),flush=True)
 except Exception as ex:
  import traceback;traceback.print_exc()

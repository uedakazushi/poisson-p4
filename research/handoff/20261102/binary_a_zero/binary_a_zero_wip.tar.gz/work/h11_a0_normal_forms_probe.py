from pathlib import Path
import sys,json,sympy as s,pickle
sys.path.insert(0,'code')
from s61_model import S61
from primitive_jet_elliptic_curve_20261101 import primitive_beta
one=[4,5,12,13,14,25,26,27,34,35,36,37,48,49,50,51];v=s.Matrix([s.Symbol('u'+str(i)) for i in one]);act=s.Matrix(json.load(open('reports/S61_BINARY_RANK_DROP_FAMILY_20261101.json'))['primitive_action']).applyfunc(s.sympify);u4,u5,u12,u13,u14,u25,u26,u27,u34,u35,u36,u37,u48,u49,u50,u51=v
for ex in [u36,u35,u14-s.Rational(1,5)*u49]:
 eq=s.Matrix([u12,u13,u50+5*u35,u4,ex]);piv=[u12,u13,u50,u4,(u14 if ex.free_symbols=={u14,u49} else ex)];subs=s.solve(list(eq),piv)
 xs=eq.jacobian(v)*act;print(str(ex),'normalrank',xs.subs(subs).to_DM().rank(),flush=True)

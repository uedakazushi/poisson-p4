import sys;sys.path.insert(0,"code")
"""Full 18-parameter incidence transverse and actual sixth Macaulay space."""
import itertools
import json
from functools import lru_cache
from pathlib import Path

import sympy as sym
from sympy import QQ
from sympy.polys.rings import ring

from s61_flag_t5_core_geometry_20261102 import fixed_representative
from s61_model import S61,X,J
from weight1_structure import sp_basis

ROOT=Path.cwd()
EXTRA="reports/S61_UNIVERSAL_WEIGHT6_20261031.json"


def ambient_certificate():
    import sys,itertools
    m=S61()
    obj=json.loads(Path(sys.argv[1]).read_text());generic=len(sys.argv)>2 and sys.argv[2]=='generic'
    one=[i for i,w in enumerate(m.reduced['parameter_weights']) if w==1]
    two=[i for i,w in enumerate(m.reduced['parameter_weights']) if w==2]
    q=sym.Matrix(obj['q']).applyfunc(sym.Rational);beta=sym.Matrix(obj['beta']).applyfunc(sym.Rational)
    if generic:
        H=sym.Matrix(obj['H']).applyfunc(sym.Rational);beta=H*sym.Matrix([i**2+2*i+3 for i in range(H.cols)])
    cuts={two[obj['fixed']],*[one[i] for i in obj['bcuts']],*[two[i] for i in obj['qcuts']]}
    variables=[i for i in range(62) if i not in cuts];model=m
    loc={j:i for i,j in enumerate(variables)}
    point=dict(zip(one,beta))|dict(zip(two,q))|{61:sym.S.Zero}
    N=len(variables)
    source=model.reduced["equations"]+[json.loads((ROOT/EXTRA).read_text())["universal_new_equation"]]
    linear=sym.zeros(135,N)
    higher=[]
    for row,polynomial in enumerate(source):
        expanded={}
        for mon,numerator,denominator in polynomial:
            qdegree=sum(i in two for i in mon)
            terms={():sym.Rational(numerator,denominator)}
            for j in [*mon,*([61]*(2-qdegree))]:
                next_terms={}
                for ids,c in terms.items():
                    if point[j]:
                        next_terms[ids]=next_terms.get(ids,0)+point[j]*c
                    if j in loc:
                        key=tuple(sorted((*ids,loc[j])))
                        next_terms[key]=next_terms.get(key,0)+c
                terms=next_terms
            for key,c in terms.items():
                expanded[key]=expanded.get(key,0)+c
        expanded={key:c for key,c in expanded.items() if c}
        assert () not in expanded
        for key,c in expanded.items():
            if len(key)==1:
                linear[row,key[0]]=c
        higher.append({key:c for key,c in expanded.items() if len(key)>=2})
    kernel=sym.Matrix.hstack(*linear.nullspace())
    piv=list(linear.to_DM().rref()[1])
    rows=list(linear[:,piv].T.to_DM().rref()[1])
    n=kernel.cols; print("normal",n, "t tangent",kernel[-1,:],flush=True)
    if n==0:return [1]
    block=linear[rows,piv]
    inverse=block.inv()
    right=sym.zeros(N,len(piv))
    for i,k in enumerate(piv):
        right[k,:]=inverse[i,:]
    assert linear[rows,:]*right==sym.eye(len(piv))
    algebra,*v=ring(",".join(f"v{i}" for i in range(n)),QQ)
    scalar=lambda z:QQ.from_sympy(sym.Rational(z))
    def apply(mat,vec):
        return [sum((scalar(mat[i,j])*vec[j] for j in range(mat.cols) if mat[i,j] and vec[j]),algebra.zero) for i in range(mat.rows)]
    lifts={1:[sum((scalar(kernel[i,j])*v[j] for j in range(n)),algebra.zero) for i in range(N)]}
    residuals=[algebra.zero for _ in range(135)]
    for degree in range(2,7):
        @lru_cache(None)
        def product(ids,n):
            if not ids:
                return algebra.one if n==0 else algebra.zero
            return sum((lifts[k][ids[0]]*product(ids[1:],n-k) for k in range(1,min(n,degree-1)+1) if lifts[k][ids[0]]),algebra.zero)
        raw=[sum((scalar(c)*product(ids,degree) for ids,c in row.items() if len(ids)<=degree),algebra.zero) for row in higher]
        lifts[degree]=[-z for z in apply(right,[raw[i] for i in rows])]
        terms=[z+y for z,y in zip(raw,apply(linear,lifts[degree]))]
        assert not any(terms[i] for i in rows)
        residuals=[z+y for z,y in zip(residuals,terms)]
    # Start at lowest total degree and retain every later coefficient of each row.
    monomials=[a for d in range(7) for a in itertools.product(range(d+1),repeat=n) if sum(a)==d]
    index={exp:i for i,exp in enumerate(monomials)}
    basis={}
    selected=[]
    for row_index,polynomial in enumerate(residuals):
        if not polynomial:
            continue
        for shift in monomials:
            vec={index[tuple(x+y for x,y in zip(exp,shift))]:c for exp,c in polynomial.items() if sum(exp)+sum(shift)<=6}
            while vec:
                j=min(vec)
                pivot=vec[j]
                if j not in basis:
                    basis[j]={k:c/pivot for k,c in vec.items()}
                    selected.append([row_index,list(shift)])
                    break
                for k,c in basis[j].items():
                    val=vec.get(k,QQ.zero)-pivot*c
                    if val:
                        vec[k]=val
                    else:
                        vec.pop(k,None)
    hilbert=[sum(1 for j,a in enumerate(monomials) if sum(a)==d and j not in basis) for d in range(7)]
    return hilbert
print(ambient_certificate(),flush=True)

from pathlib import Path
import sys,inspect,json,pickle
sys.path.insert(0,'code')
import s61_binary_endpoint_full_transverse_20261102 as T
import sympy as s
w=Path('work/h11-orbit-weights.json')
if not w.exists():
 text=inspect.getsource(T.original_transversal).replace('35:D,48:E','34:1,35:D,48:E,49:-5')
 env=vars(T).copy();exec(text,env);r,wt,rw,sel,det=env['original_transversal']()
 w.write_text(json.dumps([wt,rw]));pickle.dump(r,open('work/h11-orbit-raw.pkl','wb'))
wt,rw=json.loads(w.read_text());r=pickle.load(open('work/h11-orbit-raw.pkl','rb'))
a,b,d,e=s.symbols('a b d e');v=[j for j in range(47) if j not in T.CUTS]
assert (a,b,d,e)==(T.A,T.B,T.D,T.E)
subs={b:6,e:16};PIV=[]
for W in range(1,5):
 inds=[i for i in range(135) if rw[i]==W];cols=[i for i in v if wt[i]==W];J=s.Matrix([[r[i].get((j,),s.S.Zero).subs(subs) for j in cols] for i in inds])
 while True:
  pos=[(len(str(J[i,j])),i,j) for i in range(J.rows) for j in range(J.cols) if J[i,j].is_Rational and J[i,j]]
  if not pos:break
  _,i,j=min(pos);PIV.append((inds[i],cols[j]));pivot=J[i,j];J=(J-J[:,j]*J[i,:]/pivot).applyfunc(s.cancel);J.row_del(i);J.col_del(j);inds.pop(i);cols.pop(j)
 print(W,'residual block',J.shape,'generic rank',J.to_DM().rank(),flush=True)
 if J.cols<8:
  print(str(J)[:1300],flush=True)
print('total const pivs',len(PIV));json.dump(PIV,open('work/h11-orbit-surface-pivots.json','w'))

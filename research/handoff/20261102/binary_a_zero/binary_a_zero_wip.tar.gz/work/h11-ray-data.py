from pathlib import Path
import sys,pickle,json,sympy as s,re
sys.path.insert(0,'code')
from s61_model import S61,X
from weight1_structure import sp_basis
from toric_closed_jet_coordinates_20261102 import pairs,m2
m=S61();one=[i for i,x in enumerate(m.reduced['parameter_weights']) if x==1];two=[i for i,x in enumerate(m.reduced['parameter_weights']) if x==2]
model=json.load(open('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json'))['linear']; fixed=model['fixed'];cols=model['cols'];fv=[i for i in range(47) if i not in [5,19,20,23,27]]
dat=pickle.load(open('work/toric-closed-coordinates.pkl','rb'));Pi=dat['Pi'];y=s.Matrix(X[1:]);rows=m.reduced['equations']+[json.load(open('reports/S61_UNIVERSAL_WEIGHT6_20261031.json'))['universal_new_equation']]
for r in map(s.Rational,['2','5/3','5/4','-10','5/2','25/14']):
 b=7/(r-s.Rational(8,3));e=b*r;tag=str(r).replace('/','_')
 for h in range(1,5):
  f=Path('work/h11-a0-ex-'+tag+'-'+str(h)+'.out')
  if f.exists() and '(0, ' in f.read_text():break
 txt=f.read_text().splitlines();vals=s.sympify('['+txt[2][1:-1].replace('^','**')+']');gb=s.sympify('['+txt[3].removeprefix('matrix {{').removesuffix('}}').replace('^','**')+']');vars=set().union(*(x.free_symbols for x in vals));univ=[g for g in gb if g.free_symbols<=vars and g]
 sol=s.solve(univ,list(vars),dict=True) if vars else [{}];print('case',r,'vars',vars,'points',len(sol),flush=True)
 for sub in sol:
  pnt=[x.subs(sub) for x in vals];xx=dict(zip(fv,pnt));q=s.zeros(45,1);q[fixed]=1
  for k,z in enumerate(cols):q[z]=xx.get(k,0)
  beta=dict.fromkeys(one,0);beta.update({13:b,34:1,35:1,48:e,49:-5,11:xx.get(45,0),12:xx.get(46,0)});v=[0]*62
  for i,j in zip(two,q):v[i]=j
  for i,j in beta.items():v[i]=j
  variables=one+[two[k] for k in cols]+[61];J=s.zeros(135,61);betaform=s.zeros(16)
  for i,row in enumerate(rows):
   value=0
   for mon,n,d in row:
    ii=mon+[61]*(2-sum(k in two for k in mon));co=s.Rational(n,d);value+=co*s.prod(v[k] for k in ii)
    if i==134 and 61 not in ii:
     bb=[one.index(j) for j in ii if j in one];betaform[bb[0],bb[1]]+=co*s.prod(v[k] for k in ii if k in two)
    for h,k in enumerate(ii):
     if k in variables:J[i,variables.index(k)]+=co*s.prod(v[j] for h1,j in enumerate(ii) if h1!=h)
   assert s.expand(value)==0
  lead=J[:134,:16];H=s.Matrix.hstack(*lead.nullspace());form=H.T*(betaform+betaform.T)*H
  E=dat['E']*q;Q=s.zeros(4)
  for z,(i,j) in enumerate(pairs):Q[i,j]=sum(E[z*10+h]*y[k]*y[l] for h,(k,l) in enumerate(m2))
  Q-=Q.T;O=[]
  for g in sp_basis():
   V=g*Q+Q*g.T-sum(((g*y)[i]*Q.diff(y[i]) for i in range(4)),s.zeros(4));P=s.Matrix([s.Poly(V[i,j],*y).coeff_monomial(y[k]*y[l]) for i,j in pairs for k,l in m2]);c=Pi*P;O.append(c-q*c[fixed])
  O=s.Matrix.hstack(*O);print('q',[(i,str(k))for i,k in enumerate(q) if k], 'beta+',xx.get(45),xx.get(46),'orbit',O.to_DM().rank(),'H',H.cols,'extra',form.to_DM().rank(),'fullJac',J.to_DM().rank(),'tangent',61-J.to_DM().rank(),flush=True)

  rounded=[str(s.factor(Q[i,j])) for i,j in pairs];print('tensor',rounded,flush=True)
  qcuts=list(O.T.to_DM().rref()[1]);bcuts=list(H.T.to_DM().rref()[1]);spt=[int(x) for x in range(45) if q[x]];tag=tag+'-'+str(spt[-1])+('-b' if 35 in spt else '')
  obj=dict(q=list(map(str,q)),beta=[str(beta.get(j,0)) for j in one],fixed=fixed,bcuts=bcuts,qcuts=qcuts,H=list(map(lambda row:list(map(str,row)),H.tolist())),tensor=rounded)
  Path('work/h11-ray-'+tag+'.json').write_text(json.dumps(obj))

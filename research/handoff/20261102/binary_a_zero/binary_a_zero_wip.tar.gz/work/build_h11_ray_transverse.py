from pathlib import Path
s=Path('work/h11-ray-trans.py').read_text();l=s.index('    loc=');s=s[l:s.index('print(ambient_certificate()')]
s=s.replace('point=dict(zip(one,beta))|dict(zip(two,q))|{61:sym.S.Zero}','point=dict(zip(one,beta))|dict(zip(two,q))|{61:sym.S.Zero}').replace('    source=model.reduced["equations"]+[json.loads((ROOT/EXTRA).read_text())["universal_new_equation"]]','')
s=s.replace('n=kernel.cols; print("normal",n, "t tangent",kernel[-1,:],flush=True)\n    if n==0:return [1]','n = len(variables)-len(piv)').replace('    inverse=block.inv()','    jdet=block.det(method="domain-ge")\n    assert unit(jdet)\n    if not n:return [1], str(jdet), rows, piv\n    assert kernel.cols==n\n    inverse=block.inv()').replace('algebra,*v=ring(",".join(f"v{i}" for i in range(n)),QQ)','algebra,*v=ring(",".join(f"v{i}" for i in range(n)),field)').replace('scalar=lambda z:QQ.from_sympy(sym.Rational(z))','scalar=lambda z:field(red(z))').replace('QQ.zero','field.zero').replace('    return hilbert','    return hilbert,str(jdet),rows,piv')
pre='''"""Mixed-characteristic transverse bounds at all nonzero rays on the marked a=0 test."""
import itertools
from functools import lru_cache
import sympy as sym
from sympy.polys.rings import ring
from s61_binary_endpoint_full_transverse_20261102 import PRIME, ROOT, load_report
from s61_model import S61, X
from toric_closed_jet_coordinates_20261102 import coords, pairs, m2
from weight1_structure import sp_basis

def unit(z):
    z=sym.Rational(z)
    return int(z.p)%PRIME != 0 and int(z.q)%PRIME != 0

def red(z):
    z=sym.Rational(z)
    return int(z.p)*pow(int(z.q),-1,PRIME)%PRIME

def transverse(one,two,beta,q,variables,source):
    field=sym.GF(PRIME)
'''
p=Path('code/s61_binary_a_zero_ray_transverse_20261102.py');p.write_text(pre+s)

import sys,json,sympy as s,itertools
sys.path.insert(0,'code')
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
from s61_binary_hyperplane_root_model_20261102 import actual_binary_tangent
m=S61();one=[i for i,w in enumerate(m.reduced['parameter_weights']) if w==1];old=json.load(open('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json'))['linear']
nu=[4,24,25,26,33,36,47,50]
for slope in [s.Rational(25,14),2,s.Rational(5,3),s.Rational(5,4),-10,5,s.Rational(5,2)]:
 b=7/(s.Rational(slope)-s.Rational(8,3));e=b*slope
 beta=dict.fromkeys(one,s.S.Zero);beta.update(dict(zip(nu,[3,7,8,9,10,13,14,17])));beta.update({13:b,34:1,35:1,48:e,49:-5});two,f=specialize(m,beta,True);fx=old['fixed'];cols=old['cols'];J=s.Matrix([[q.get(tuple(sorted((fx,j))),0) for j in cols]+[q.get((fx,),0)] for q in f]);rk=J.to_DM().rank();jr=J[:,:44].to_DM().rank()
 print(slope,'b',b,'ranks',jr,rk,flush=True)

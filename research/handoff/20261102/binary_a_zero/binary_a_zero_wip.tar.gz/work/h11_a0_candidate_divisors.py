from pathlib import Path
from fractions import Fraction
import math
p=32003
def red(x):f=Fraction(x);return f.numerator*pow(f.denominator,-1,p)%p
def rr(x):
 vals=[]
 for j in range(1,250):
  c=x*j%p;c=c if c<=p//2 else c-p
  if math.gcd(c,j)==1:vals.append((max(abs(c),j),Fraction(c,j)))
 return min(vals)[1]
lines=[(Fraction(8,3),7,'h11-a0-full-weight4'),(Fraction(8,3),11,'h11-a0-p2'),(Fraction(9,4),13,'h11-a0-p3'),(Fraction(7,4),2,'h11-a0-p4')];pts=[]
for k,v,s in lines:
 core=Path('/tmp/'+s+'.out').read_text().split('FACTORS 7\n')[1].split('FINAL')[0];r=[]
 for row in core.splitlines():
  o,_,a,b=map(int,row.split());x=-a%p;r.append((o,x,(red(k)*x+v)%p))
 pts.append(r)
for o,x,y in pts[0]:
 for b,X,Y in pts[1]:
  if b!=o:continue
  dx=(X-x)%p;dy=(Y-y)%p;lo=pow(dx,-1,p) if dx else pow(dy,-1,p)
  coeff=[dy*lo%p,-dx*lo%p,(dx*y-dy*x)*lo%p]
  if all(any(i==o and (coeff[0]*xx+coeff[1]*yy+coeff[2])%p==0 for i,xx,yy in k) for k in pts[2:]):
   print(o,x,[str(rr(c)) for c in coeff])

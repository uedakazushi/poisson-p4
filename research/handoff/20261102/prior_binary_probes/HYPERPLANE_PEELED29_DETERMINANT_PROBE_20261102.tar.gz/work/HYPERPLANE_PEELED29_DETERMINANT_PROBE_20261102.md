# One bounded determinant attempt after exact a/C peeling

Input: the selected 29 x29 pure-cubic minor after the independently checked
constant-kernel extraction of a^11 C^3. The scalar-normalized primitive Schur
and factor-bag method was copied to a new exploratory native source, with no
changes to frozen files. Row/column scalar normalization, polynomial contents,
and the signed-exponent gcd factor bag are retained.

This single attempt was bounded at180 seconds. It reached an8 x8 matrix with
2,438,693 terms at125.077seconds, then timed out during the next primitive/gcd
stage. No determinant factorization or completed factor list was obtained.
There is no new rank-coverage conclusion.

The native code would save a restartable matrix and factor bag at a completed
stage exceeding165 seconds or5,000,000 terms. The process timed out inside a
stage before either checkpoint boundary was reached. Therefore the8 x8 matrix
itself is NOT saved. The original peeled input, exact source, all completed
stage dimensions/timings, timeout record, and hashes ARE saved and suffice to
reproduce the attempt. No identical retry or wall-time extension is made.

The independent a^11 C^3 extraction remains valid; this failure does not alter
it. Earlier unpeeled29 attempts and this peeled-input attempt have different
inputs and are recorded separately.

Files:
- `work/generic_hyperplane_peeled29_determinant_20261102.cpp`
- `work/generic_hyperplane_peeled29_determinant_probe_20261102.py`
- matching `.json` report and native `.log`
- input `/tmp/generic-hyperplane-peeled29-determinant-20261102.in`

The candidate archive includes the input under a relative work/ path. It does
not include the native runtime or any claimed completed determinant result.

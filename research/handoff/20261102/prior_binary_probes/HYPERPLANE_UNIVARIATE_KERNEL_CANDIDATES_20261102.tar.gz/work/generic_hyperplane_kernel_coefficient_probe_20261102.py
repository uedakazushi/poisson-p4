from pathlib import Path
import json,time
import numpy as np
import sympy as s
P=32003;start=time.time()
base=Path('work/generic_hyperplane_univariate_kernel_probe_20261102.py').read_text().split('results=[]')[0]
exec(base)
D=4;maxd=3
terms=[(i,j,tuple(m),mod(c)) for i,row in enumerate(data['matrix']) for j,poly in enumerate(row) for m,c in poly]
def coefficient_matrix(aa,ee):
 A=np.zeros((16,7,4),dtype=np.int64)
 pa=[pow(aa,k,P) for k in range(5)];pe=[pow(ee,k,P) for k in range(7)]
 for i,j,m,c in terms:A[i,j,m[2]]=(A[i,j,m[2]]+c*pa[m[0]]*pe[m[1]])%P
 M=np.zeros((56,80),dtype=np.int64)
 for i in range(16):
  for t in range(5):
   for j in range(7):M[j*8+t:j*8+t+4,i*5+t]=A[i,j]
 return M
R,piv=rref(coefficient_matrix(1,2));free=[i for i in range(80) if i not in piv];chosen=free[-2:]
print('PIVOT',piv,'FREE',free,'CHOSEN',chosen,flush=True)
rng=np.random.default_rng(6102026);weights=rng.integers(1,P,size=(3,160),dtype=np.int64)
def sample(aa,ee):
 M=coefficient_matrix(aa,ee);R,p=rref(M)
 if p!=piv:return None
 K=np.zeros((80,2),dtype=np.int64)
 for k,f in enumerate(chosen):
  K[f,k]=1
  for j,p in enumerate(piv):K[p,k]=-R[j,f]%P
 assert not np.any(M@K%P)
 return (weights@K.T.reshape(-1)%P).tolist(),K.T.tolist()
def trim(a):
 while a and a[-1]%P==0:a.pop()
 return a
def add(a,b,sgn=1):
 r=a.copy()+[0]*max(0,len(b)-len(a))
 for i,v in enumerate(b):r[i]=(r[i]+sgn*v)%P
 return trim(r)
def mul(a,b):
 if not a or not b:return []
 r=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):r[i+j]=(r[i+j]+x*y)%P
 return trim(r)
def divmodp(a,b):
 r=trim(a.copy());q=[0]*max(0,len(a)-len(b)+1);ib=pow(b[-1],-1,P)
 while len(r)>=len(b):
  j=len(r)-len(b);z=r[-1]*ib%P;q[j]=z
  for i,v in enumerate(b):r[j+i]=(r[j+i]-z*v)%P
  trim(r)
 return trim(q),r
def evalp(f,x):
 z=0
 for c in reversed(f):z=(z*x+c)%P
 return z
def interp(xs,ys):
 f=[];m=[1]
 for x,y in zip(xs,ys):
  z=(y-evalp(f,x))*pow(evalp(m,x),-1,P)%P
  f=add(f,[(z*c)%P for c in m]);m=mul(m,[-x%P,1])
 return f,m
def recon(xs,ys,testx,testy):
 f,m=interp(xs,ys);r0,r1=m,f;t0,t1=[],[1]
 while r1:
  if len(r1)+len(t1)<=len(xs)+1 and all(evalp(t1,x) and evalp(r1,x)==y*evalp(t1,x)%P for x,y in zip(testx,testy)):
   ic=pow(t1[-1],-1,P);return {'numerator_degree':len(r1)-1,'denominator_degree':len(t1)-1,'numerator':[c*ic%P for c in r1],'denominator':[c*ic%P for c in t1]}
  q,r=divmodp(r0,r1);r0,r1=r1,r;t0,t1=t1,add(t0,mul(q,t1),-1)
 return None
out={'prime':P,'D':4,'pivots':piv,'free_columns':free,'chosen_free_columns':chosen,'weights_seed':6102026,'random_weights':weights.tolist(),'axis_probes':[]}
for axis,fixed in [('e',1),('e',2),('a',2),('a',3)]:
 xs=[];ys=[]
 for x in range(2,172):
  aa,ee=(fixed,x) if axis=='e' else (x,fixed)
  z=sample(aa,ee)
  if z:xs.append(x);ys.append(z[0])
  if len(xs)==160:break
 result=[]
 for i in range(3):result.append(recon(xs[:140],[y[i] for y in ys[:140]],xs[140:],[y[i] for y in ys[140:]]))
 rec={'axis':axis,'fixed_other':fixed,'sample_count':len(xs),'reconstructions':result};out['axis_probes'].append(rec)
 print(axis,fixed,[(z['numerator_degree'],z['denominator_degree']) if z else None for z in result],'seconds',time.time()-start,flush=True)
_, selected_rows = rref(coefficient_matrix(1,2)[:,piv].T)
assert len(selected_rows)==50
out['selected_equation_rows']=selected_rows
out['coefficient_index_convention']='column=5*heavy_template_row+d_exponent; equation=8*heavy_column+output_d_exponent'
out['selected_minor_shape']=[50,50]
out['seconds']=time.time()-start
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')

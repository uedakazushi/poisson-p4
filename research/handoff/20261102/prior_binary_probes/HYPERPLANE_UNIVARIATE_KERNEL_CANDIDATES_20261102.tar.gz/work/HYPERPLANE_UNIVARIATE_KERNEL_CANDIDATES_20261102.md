# Hyperplane heavy kernel: bounded finite-field candidates

This is exploratory work over F_32003, not a QQ theorem or a new rank-drop
coverage theorem. The input is the frozen 16 x 7 heavy template, independently
reconstructed from the original 135 equations in the formal heavy-block note.

## A genuinely smaller degree in d

At each (a,e)=(1,2),(2,3),(3,5), the coefficient-kernel dimensions for d-degree
bounds 0,1,2,3,4 are 3,7,14,21,30. Their spans after evaluation d=3 have dimensions
3,4,7,7,9. Thus the minimal-index pattern suggested by these samples is
(0,0,0,1,2,2,2,4,4). The two degree-4 vectors complement the seven-dimensional
span of the eight existing small polynomial syzygies.

All polynomial-in-d kernel identities are checked coefficient by coefficient.
Using the original weighted cubic rows, at all three samples the pure cubic rank
is 41 after quadratic products, 44 after the five pure raw rows, 48 after the
small syzygies, and 50 after these two new vectors.

The first producer and its JSON contain the three pairs of polynomial-in-d
vectors. These are pointwise finite-field vectors, not rational functions of a,e.

## Coefficient complexity

For d-degree 4 the matrix has 56 rows and 80 columns. Column 5*i+j means the
coefficient of d^j in heavy-template row i; equation 8*k+l means the coefficient
of d^l in heavy column k. The JSON coefficient probe saves a fixed rank-50 minor,
the 30 free columns, and the two normalized free coefficients 77,78. Every other
free coefficient is zero. Its selected 50 equation rows are also saved.

Three random linear combinations of all 160 coefficients, with fixed seed
6102026, admit verified rational interpolants of degrees:

- e, at a=1 or 2: numerator 25, denominator 14;
- a, at e=2 or 3: numerator 14, denominator 11.

Each reconstruction uses 140 training points and 20 held-out points. These are
only degree candidates for possible exact reconstruction. Eleven alternative
column orders did not improve the e-degree pair; the best stayed the original
25/14. Therefore an exact QQ(a,e) lift is possible in principle but not yet
shown computationally preferable to the existing two cofactor relations.

## Bounded polynomial alternative

With d-degree at most 4 and total polynomial degrees 9,10,11, exact modular
constant RREF gives:

| total bound | coefficient matrix | rank | kernel dimension | image with old span at (1,2,3) |
|---|---|---:|---:|---:|
| 9 | 5470 x 2960 | 2256 | 704 | 7 |
| 10 | 6283 x 3680 | 2767 | 913 | 7 |
| 11 | 7151 x 4480 | 3330 | 1150 | 7 |

The three RREF stages took approximately 4.55, 7.21, 12.11 seconds. No missing
pure direction was produced at the test point. This does not assert a generic
negative result or rule out a different normalization.

## Files and reproduction

Run from the repository root with `.venv/bin/python`:

1. `work/generic_hyperplane_univariate_kernel_probe_20261102.py`
2. `work/generic_hyperplane_kernel_coefficient_probe_20261102.py`
3. `work/generic_hyperplane_kernel_pivot_search_20261102.py`
4. `work/generic_hyperplane_univariate_pure_image_probe_20261102.py`

The fourth reads the existing exploratory weighted-row cache in
`/tmp/poisson-binary-hyperplane-weighted-20261102/rows`; it is not a standalone
formal certificate. The first three use only the frozen template and the eight
small-generator JSON input.

The bounded polynomial probe uses the matching `.cpp` native helper, compiled
against the local FLINT runtime, and has a 45-second timeout per degree. It writes
all native input/output to `/tmp`. All scripts and outcomes are in the matching
candidate archive; hashes cover its small inputs. No frozen source was modified.

Next executable choice: use the saved 50 x 50 rational system for exact
QQ(a,e) reconstruction, checking all 56 equations after solving. Its denominator
support must be tracked if used in a global core-cover argument. Alternatively,
retain the existing exact cofactor pair: the present experiments do not yet
justify replacing it as a whole-core certificate.

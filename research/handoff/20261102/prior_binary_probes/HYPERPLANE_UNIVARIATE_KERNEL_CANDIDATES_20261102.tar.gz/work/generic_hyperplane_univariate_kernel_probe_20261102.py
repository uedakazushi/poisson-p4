from pathlib import Path
import json,time
import numpy as np
import sympy as s
P=32003;start=time.time();data=json.loads(Path('code/data/s61_binary_hyperplane_heavy_template_20261102.json').read_text());gens=json.loads(Path('work/binary_hyperplane_heavy_small_generators_20261102.json').read_text())['generators']
def mod(c):
 q=s.Rational(c);return int(q.p)%P*pow(int(q.q),-1,P)%P
def rref(M):
 M=np.array(M,dtype=np.int64);row=0;piv=[]
 for j in range(M.shape[1]):
  nz=np.flatnonzero(M[row:,j])
  if not len(nz):continue
  k=row+int(nz[0]);M[[row,k]]=M[[k,row]];M[row]=M[row]*pow(int(M[row,j]),-1,P)%P
  for i in range(M.shape[0]):
   if i!=row and M[i,j]:M[i]=(M[i]-M[i,j]*M[row])%P
  piv.append(j);row+=1
  if row==M.shape[0]:break
 return M,piv
results=[]
for aa,ee in [(1,2),(2,3),(3,5)]:
 maxd=max(m[2] for row in data['matrix'] for poly in row for m,c in poly)
 A=np.zeros((16,7,maxd+1),dtype=np.int64)
 for i,row in enumerate(data['matrix']):
  for j,poly in enumerate(row):
   for m,c in poly:A[i,j,m[2]]=(A[i,j,m[2]]+mod(c)*pow(aa,m[0],P)*pow(ee,m[1],P))%P
 short=np.array([[sum(mod(c)*pow(aa,m[0],P)*pow(ee,m[1],P)*pow(3,m[2],P) for m,c in poly)%P for poly in gen] for gen in gens],dtype=np.int64)
 _,piv0=rref(short);base=short.tolist();record=[]
 for D in range(6):
  M=np.zeros((7*(maxd+D+1),16*(D+1)),dtype=np.int64)
  for i in range(16):
   for t in range(D+1):
    for j in range(7):
     M[j*(maxd+D+1)+t:j*(maxd+D+1)+t+maxd+1,i*(D+1)+t]=A[i,j]
  R,piv=rref(M);free=[j for j in range(M.shape[1]) if j not in piv];K=[]
  for f in free:
   row=np.zeros(M.shape[1],dtype=np.int64);row[f]=1
   for i,j in enumerate(piv):row[j]=-R[i,f]%P
   assert not np.any(M.dot(row)%P);K.append(row)
  values=np.array([[sum(int(row[i*(D+1)+t])*pow(3,t,P) for t in range(D+1))%P for i in range(16)] for row in K],dtype=np.int64)
  _,kp=rref(values);_,bp=rref(np.vstack([short,values]));extras=[];current=short.copy();rank=len(piv0)
  for k,row in enumerate(values):
   _,v=rref(np.vstack([current,row]))
   if len(v)>rank:extras.append(k);current=np.vstack([current,row]);rank=len(v)
  record.append({'D':D,'coefficient_matrix_shape':list(M.shape),'kernel_dimension':len(K),'kernel_field_rank_at_d3':len(kp),'joined_rank':len(bp),'extra_indices_over_small8':extras})
  print('POINT',aa,ee,'D',D,'K',len(K),'FIELD',len(kp),'SHORT',len(piv0),'PLUS',len(bp),'EXTRA',extras,flush=True)
  if len(bp)==9:
   record[-1]['extra_vectors_coeff_low_d_first']=[K[k].reshape(16,D+1).tolist() for k in extras]
   break
 results.append({'a':aa,'e':ee,'max_d':maxd,'short8_rank':len(piv0),'degrees':record})
Path(__file__).with_suffix('.json').write_text(json.dumps({'prime':P,'results':results,'seconds':time.time()-start},indent=2)+'\n')

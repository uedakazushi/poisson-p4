from pathlib import Path
import json,time,itertools,subprocess,os
import sympy as s
P=32003;start=time.time();data=json.loads(Path('code/data/s61_binary_hyperplane_heavy_template_20261102.json').read_text());gens=json.loads(Path('work/binary_hyperplane_heavy_small_generators_20261102.json').read_text())['generators']
def mod(c):
 q=s.Rational(c);return int(q.p)%P*pow(int(q.q),-1,P)%P
cols=[[(j,tuple(m),mod(c)) for j,poly in enumerate(row) for m,c in poly] for row in data['matrix']]
short=[[sum(mod(c)*pow(2,m[1],P)*pow(3,m[2],P) for m,c in poly)%P for poly in gen] for gen in gens]
env=os.environ.copy();env['DYLD_LIBRARY_PATH']=str(Path('work/m2-runtime/lib').resolve())+':/opt/homebrew/lib';results=[]
for D in [9,10,11]:
 mons=sorted((a,e,d) for a in range(D+1) for e in range(D+1-a) for d in range(min(4,D-a-e)+1));labels=[(i,m) for i in range(16) for m in mons];rows={}
 for ci,(i,m) in enumerate(labels):
  for eq,mm,c in cols[i]:
   key=(eq,tuple(x+y for x,y in zip(m,mm)));rows.setdefault(key,{})[ci]=c
 keys=sorted(rows);inp=Path(f'/tmp/generic-hyperplane-poly-kernel-D{D}-20261102.in');out=inp.with_suffix('.out')
 with inp.open('w') as f:
  f.write(f'{len(keys)} {len(labels)} {P}\n')
  for key in keys:f.write(str(len(rows[key]))+''.join(f' {j} {c}' for j,c in rows[key].items())+'\n')
  for i,m in labels:f.write(f'{i} {pow(2,m[1],P)*pow(3,m[2],P)%P}\n')
  f.write('8\n')
  for row in short:f.write(' '.join(map(str,row))+'\n')
 print('RUN',D,len(keys),len(labels),'seconds',time.time()-start,flush=True)
 try:r=subprocess.run(['/tmp/generic-hyperplane-bounded-poly-kernel-20261102',str(inp),str(out)],env=env,capture_output=True,text=True,timeout=45)
 except subprocess.TimeoutExpired:results.append(dict(D=D,timeout_seconds=45));print('TIMEOUT',D,flush=True);break
 print(r.stderr,flush=True);r.check_returncode();lines=iter(out.read_text().splitlines());nr,nc,rank=map(int,next(lines).split());kernels=[]
 for line in lines:
  z=line.split()
  if z[0]=='FIELD_RANK':fieldrank=int(z[1]);break
  assert z[0]=='KERNEL';k={int(j):int(c) for j,c in (next(lines).split() for _ in range(int(z[1])))}
  assert all(sum(c*k.get(j,0) for j,c in row.items())%P==0 for row in rows.values())
  kernels.append({'terms':[[labels[j][0],list(labels[j][1]),c] for j,c in k.items()]})
 results.append(dict(D=D,shape=[nr,nc],rank=rank,kernel_dimension=nc-rank,joined_field_rank=fieldrank,new_kernels=kernels))
 if fieldrank==9:break
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(prime=P,results=results,seconds=time.time()-start),indent=2)+'\n')

from pathlib import Path
import json,time
import numpy as np
exec(Path('work/generic_hyperplane_kernel_coefficient_probe_20261102.py').read_text().split("out={'prime'")[0])
start=time.time();rng=np.random.default_rng(6102027)
rowdeg=[max(sum(m[:2]) for poly in row for m,c in poly) for row in data['matrix']]
short=np.array([[sum(mod(c)*pow(1,m[0],P)*pow(2,m[1],P)*pow(3,m[2],P) for m,c in poly)%P for poly in gen] for gen in gens],dtype=np.int64)
_,sp=rref(short)
orders={
 'rowdegree_ascending':[i*5+j for i in sorted(range(16),key=lambda i:(rowdeg[i],i)) for j in range(5)],
 'rowdegree_descending':[i*5+j for i in sorted(range(16),key=lambda i:(-rowdeg[i],i)) for j in range(5)],
 'd_ascending':[i*5+j for j in range(5) for i in range(16)],
 'd_descending':[i*5+j for j in reversed(range(5)) for i in range(16)],
 'row_reverse':[i*5+j for i in reversed(range(16)) for j in range(5)],
}
for i in range(6):orders[f'random_rows_{i}']=[int(k)*5+j for k in rng.permutation(16) for j in range(5)]
records=[]
for name,order in orders.items():
 R,piv=rref(coefficient_matrix(1,2)[:,order]);free=[i for i in range(80) if i not in piv];chosen=[];current=short.copy();rank=len(sp)
 for f in free:
  v=np.zeros(80,dtype=np.int64);v[f]=1
  for i,j in enumerate(piv):v[j]=-R[i,f]%P
  vp=np.zeros(80,dtype=np.int64);vp[order]=v
  value=np.array([sum(int(vp[5*i+t])*pow(3,t,P) for t in range(5))%P for i in range(16)],dtype=np.int64)
  _,pv=rref(np.vstack([current,value]))
  if len(pv)>rank:chosen.append(f);current=np.vstack([current,value]);rank=len(pv)
 assert rank==9 and len(chosen)==2
 def onesample(aa,ee):
  M=coefficient_matrix(aa,ee);R,p=rref(M[:,order])
  if p!=piv:return None
  K=np.zeros((80,2),dtype=np.int64)
  for k,f in enumerate(chosen):
   K[order[f],k]=1
   for j,p in enumerate(piv):K[order[p],k]=-R[j,f]%P
  assert not np.any(M@K%P)
  return (weights@K.T.reshape(-1)%P).tolist()
 xs=[];ys=[]
 for x in range(2,142):
  z=onesample(1,x)
  if z:xs.append(x);ys.append(z)
  if len(xs)==125:break
 recs=[recon(xs[:105],[y[i] for y in ys[:105]],xs[105:],[y[i] for y in ys[105:]]) for i in range(3)]
 record={'name':name,'order':order,'pivots_in_order':piv,'chosen_free_in_order':chosen,'e_at_a1':recs};records.append(record)
 print(name,[(z['numerator_degree'],z['denominator_degree']) if z else None for z in recs], 'seconds',time.time()-start,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(prime=P,records=records,seconds=time.time()-start),indent=2)+'\n')

from fractions import Fraction
from pathlib import Path
import hashlib
import json
import sys
import time

import numpy as np
import sympy as sp

root = Path.cwd()
sys.path.insert(0, str(root/'code'))
from s61_model import S61, X, J as symplectic_bivector
from primitive_jet_elliptic_curve_20261101 import primitive_beta
from s61_flag_transverse_obstruction_20261101 import specialize
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank, determinant_mod

started = time.time()
prime = 32003
chart_path = Path('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json')
old_path = Path('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json')
chart = json.loads(chart_path.read_text())
old = json.loads(old_path.read_text())['linear']
core = dict(zip(sp.symbols('a e d'), [sp.Rational(-13,25),sp.Integer(2),sp.Integer(3)]))
beta = {int(k[1:])-1: sp.sympify(v).subs(core) for k,v in chart['beta'].items()}
weights = chart['local_coordinate_weights']
equation_weights = chart['equation_weights']
fixed, columns = old['fixed'], old['cols']
model = S61()
quadratic_indices, equations = specialize(model,beta,True)
assert len(equations)==135

def residue(value):
    q = Fraction(str(value))
    assert q.denominator % prime
    return q.numerator*pow(q.denominator,-1,prime)%prime

def add(polynomial, monomial, coefficient):
    coefficient %= prime
    if not coefficient: return
    value = (polynomial.get(monomial,0)+coefficient)%prime
    if value: polynomial[monomial]=value
    else: polynomial.pop(monomial,None)

def multiply(left,right):
    result={}
    for m,c in left.items():
        for n,v in right.items(): add(result,tuple(sorted(m+n)),c*v)
    return result

def substitute(polynomial, variable, replacement):
    degree=max((m.count(variable) for m in polynomial),default=0)
    if degree==0: return polynomial.copy()
    powers=[{():1},replacement]
    for _ in range(2,degree+1): powers.append(multiply(powers[-1],replacement))
    result={}
    for m,c in polynomial.items():
        tail=tuple(j for j in m if j!=variable)
        for n,v in powers[m.count(variable)].items(): add(result,tuple(sorted(tail+n)),c*v)
    return result

def binary_tangent():
    variables,_,form=primitive_beta(model)
    form=form.subs({sp.Symbol(f'u{i+1}'):v for i,v in beta.items()})
    A,C,D,h,k=sp.symbols('planeA planeC planeD conicH conicK')
    origin=dict.fromkeys([A,C,D,h,k],0)
    v1=sp.Matrix([A,1,0,C]);v2=sp.Matrix([-C,0,1,D])
    section=sp.Matrix([(v1.T*form.subs(dict(zip(variables,v)))*v2)[0] for v in [v1,v2]])
    curve_jacobian=section.jacobian([A,C,D]).subs(origin)
    assert curve_jacobian.rank()==2
    direction=curve_jacobian.row(0).cross(curve_jacobian.row(1)).reshape(3,1)
    x,y,z,w=X[1:];l1=x-A*y+C*z;l2=w-C*y-D*z
    family=(l1*l2+h*l1**2+k*l2**2)*(v1*v2.T-v2*v1.T)
    derivatives=[];center=sp.zeros(45,1);center[fixed]=1
    for variable in [A,C,D,h,k]:
        bivector=X[0]**2*symplectic_bivector
        bivector[1:,1:]+=family.diff(variable).subs(origin)
        point=sp.Matrix([model.normalize(bivector)['parameters'][i] for i in quadratic_indices])
        point-=center*point[fixed]
        derivatives.append(point[columns,:].col_join(sp.zeros(1,1)))
    tangent=sp.Matrix.hstack(sp.Matrix.hstack(*derivatives[:3])*direction,*derivatives[3:])
    return tangent,curve_jacobian,direction

tangent,curve_jacobian,plane_direction=binary_tangent()
linear=sp.zeros(135,45);full=[{} for _ in equations]
for i,polynomial in enumerate(equations):
    assert not polynomial.get((fixed,fixed),0)
    for monomial,coefficient in polynomial.items():
        if len(monomial)==2:
            x,y=monomial
            if x!=fixed and y==fixed: linear[i,columns.index(x)]+=coefficient
            if y!=fixed and x==fixed: linear[i,columns.index(y)]+=coefficient
        elif len(monomial)==1 and monomial[0]==fixed: linear[i,44]+=coefficient
        if fixed not in monomial:
            m=tuple(sorted([columns.index(j) for j in monomial]+[44]*(2-len(monomial))))
            add(full[i],m,residue(coefficient))
    for j,c in enumerate(linear.row(i)):
        if c: add(full[i],(j,),residue(c))
    assert all(sum(weights[j] for j in m)==equation_weights[i] for m in full[i])
assert linear*tangent==sp.zeros(135,3)
assert tangent[[5,19,23],:].det()==0
choices={j:tangent[[j,19,23],:].det() for j,w in enumerate(weights) if w==1}
choices={j:v for j,v in choices.items() if v and residue(v)}
assert choices
# The first raw light coordinate with nonzero transverse determinant.
chosen=min(choices)
cuts=[chosen,19,23]
variables=[j for j in range(45) if j not in cuts]
polynomials=[{m:c for m,c in q.items() if not set(m).intersection(cuts)}
             if equation_weights[i]<=4 else {} for i,q in enumerate(full)]
steps=[]
while True:
    options=[]
    for i,q in enumerate(polynomials):
        for m,c in q.items():
            if len(m)!=1: continue
            variable=m[0]
            assert all(variable not in n for n in q if n!=m)
            occurrences=sum(sum(variable in n for n in f) for f in polynomials)
            options.append(((len(q)-1)*occurrences,len(q),i,variable,c))
    if not options: break
    _,_,i,j,pivot=min(options)
    replacement={m:-c*pow(pivot,-1,prime)%prime for m,c in polynomials[i].items() if m!=(j,)}
    polynomials=[{} if row==i else substitute(q,j,replacement) for row,q in enumerate(polynomials)]
    variables.remove(j)
    steps.append({'equation':i,'variable':j,'pivot_modp':pivot,
                  'replacement':[[list(m),c] for m,c in sorted(replacement.items())]})
    assert all(sum(weights[j] for j in m)==equation_weights[i]
               for i,q in enumerate(polynomials) for m in q)
assert len(steps)==34 and sorted(weights[j] for j in variables)==[1]*7+[2]

def monomials(weight,first=0):
    if weight==0: yield ();return
    for k in range(first,len(variables)):
        j=variables[k]
        if weights[j]<=weight:
            for rest in monomials(weight-weights[j],k): yield (j,)+rest

mons={w:list(monomials(w)) for w in range(5)}
ranks={}
for w in range(5):
    index={m:i for i,m in enumerate(mons[w])};rows=[];labels=[]
    for i,q in enumerate(polynomials):
        if not q or equation_weights[i]>w: continue
        for shift in mons[w-equation_weights[i]]:
            row=np.zeros(len(index),dtype=np.int64)
            for m,c in q.items(): row[index[tuple(sorted(m+shift))]]=c
            rows.append(row);labels.append([i,list(shift)])
    rank=0;cc=[];rr=[];minor=1
    if rows:
        matrix=np.array(rows,dtype=np.int64)
        rank,cc=elimination_rank(matrix,prime)
        _,rr=elimination_rank(matrix[:,cc].T,prime)
        minor=int(determinant_mod(matrix[np.ix_(rr,cc)],prime));assert minor
    ranks[str(w)]={'monomials':len(index),'rows':len(rows),'rank':rank,'quotient_dimension':len(index)-rank,
                   'minor_rows':rr,'minor_columns':cc,'minor_modp':minor,'minor_source_labels':[labels[i] for i in rr]}
hf=[ranks[str(w)]['quotient_dimension'] for w in range(5)]
paths=[Path(__file__),chart_path,old_path,*[Path('code')/s for s in ['s61_model.py','s61_flag_transverse_obstruction_20261101.py','primitive_jet_elliptic_curve_20261101.py','s61_binary_deeper_uniform_quadratic_20261101.py']],Path('reports/S61_UNIVERSAL_WEIGHT6_20261031.json')]
for f in ['symplectic_slice_certificate.json','symplectic_slice_equations.json','symplectic_slice_reduced_equations.json']: paths.append(Path('legacy/v02/data')/f)
result={'scope':'Actual binary tangent over QQ and fixed finite-field transverse algebra at the designated C=0 sample.',
        'prime':prime,'a':'-13/25','e':2,'d':3,'beta':{f'u{k+1}':str(v) for k,v in beta.items()},
        'plane_curve_jacobian_QQ':[[str(v) for v in row] for row in curve_jacobian.tolist()],
        'plane_tangent_direction_QQ':list(map(str,plane_direction)),
        'actual_binary_tangent_45x3_QQ':[[str(v) for v in row] for row in tangent.tolist()],
        'all135_Jacobian_rows_annihilate_actual_tangent_over_QQ':True,'old_cut_determinant':'0',
        'nonzero_weight1_cut_choices_QQ':{str(j):str(v) for j,v in choices.items()},
        'new_cut_raw_coordinates':cuts,'new_transverse_determinant_QQ':str(choices[chosen]),
        'new_transverse_determinant_modp':residue(choices[chosen]),'remaining_variables':variables,
        'remaining_weights':[weights[j] for j in variables],'linear_elimination_steps':steps,
        'remaining_equations_through_weight4':{str(i):[[list(m),c] for m,c in sorted(q.items())] for i,q in enumerate(polynomials) if q},
        'weighted_pieces':ranks,'weighted_Hilbert_function_through_four':hf,
        'remaining_positive_weights_are_ones_and_two':True,'sample_length':sum(hf) if hf[4]==0 else None,
        'input_sha256':{str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in paths},'seconds':time.time()-started}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print('CUT',cuts,'QQ DET',choices[chosen],'HF',hf,'LENGTH',result['sample_length'],'SECONDS',result['seconds'])

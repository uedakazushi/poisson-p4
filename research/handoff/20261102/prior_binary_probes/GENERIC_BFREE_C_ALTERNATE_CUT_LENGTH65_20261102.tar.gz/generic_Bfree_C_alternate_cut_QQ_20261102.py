from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math
import os
import subprocess
import sys
import time

import sympy as sp

root=Path.cwd()
sys.path.insert(0,str(root/'code'))
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize

started=time.time()
sample_path=Path('work/generic_Bfree_C_alternate_cut_20261102.json')
chart_path=Path('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json')
old_path=Path('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json')
sample=json.loads(sample_path.read_text())
chart=json.loads(chart_path.read_text())
old=json.loads(old_path.read_text())['linear']
beta={int(k[1:])-1:sp.Rational(v) for k,v in sample['beta'].items()}
_,source=specialize(S61(),beta,True)
assert len(source)==135
fixed,cols=old['fixed'],old['cols']
cuts=set(sample['new_cut_raw_coordinates'])
weights=chart['local_coordinate_weights']
row_weights=chart['equation_weights']
prime=32003

def modulo(q):
    assert q.denominator%prime
    return q.numerator*pow(q.denominator,-1,prime)%prime

def add(poly,mon,value):
    if value:
        result=poly.get(mon,0)+value
        if result: poly[mon]=result
        else: poly.pop(mon,None)

def multiply(left,right):
    out={}
    for m,c in left.items():
        for n,v in right.items(): add(out,tuple(sorted(m+n)),c*v)
    return out

def substitute(poly,variable,replacement):
    degree=max((m.count(variable) for m in poly),default=0)
    if not degree: return poly.copy()
    powers=[{():Fraction(1)},replacement]
    for _ in range(2,degree+1): powers.append(multiply(powers[-1],replacement))
    out={}
    for m,c in poly.items():
        tail=tuple(j for j in m if j!=variable)
        for n,v in powers[m.count(variable)].items(): add(out,tuple(sorted(tail+n)),c*v)
    return out

equations=[{} for _ in source]
for i,encoded in enumerate(source):
    if row_weights[i]>4: continue
    for mon,c in encoded.items():
        c=Fraction(str(c))
        if len(mon)==2 and mon.count(fixed)==1:
            local=(cols.index(next(j for j in mon if j!=fixed)),)
        elif len(mon)==1 and mon[0]==fixed:
            local=(44,)
        elif fixed not in mon:
            local=tuple(sorted([cols.index(j) for j in mon]+[44]*(2-len(mon))))
        else:
            assert not c
            continue
        if not cuts.intersection(local): add(equations[i],local,c)
    assert all(sum(weights[j] for j in m)==row_weights[i] for m in equations[i])

pivots=[]
for step in sample['linear_elimination_steps']:
    i,j=step['equation'],step['variable'];q=equations[i];pivot=q[(j,)]
    assert modulo(pivot)==step['pivot_modp'] and all(j not in m for m in q if m!=(j,))
    replace={m:-c/pivot for m,c in q.items() if m!=(j,)}
    residues={m:modulo(c) for m,c in replace.items() if modulo(c)}
    assert residues=={tuple(m):c for m,c in step['replacement']}
    equations=[{} if k==i else substitute(f,j,replace) for k,f in enumerate(equations)]
    pivots.append(str(pivot))
variables=sample['remaining_variables']
for i,q in enumerate(equations):
    assert all(len(m)>=2 and set(m).issubset(variables) and sum(weights[j] for j in m)==row_weights[i] for m in q)
    assert {m:modulo(c) for m,c in q.items() if modulo(c)}=={
        tuple(m):c for m,c in sample['remaining_equations_through_weight4'].get(str(i),[])}

def monomials(weight,first=0):
    if not weight: yield ();return
    for k in range(first,len(variables)):
        j=variables[k]
        if weights[j]<=weight:
            for tail in monomials(weight-weights[j],k): yield (j,)+tail

mons={w:list(monomials(w)) for w in range(5)}
wd=Path('/tmp/generic-Bfree-C-alternate-cut-QQ-20261102');wd.mkdir(exist_ok=True)
matrix_path=wd/'integer_matrices';output=wd/'ranks';labels={};denominators={}
with matrix_path.open('w') as stream:
    for w in [2,3,4]:
        index={m:i for i,m in enumerate(mons[w])};rows=[];row_labels=[];scalars=[]
        for i,q in enumerate(equations):
            if not q or row_weights[i]>w: continue
            for shift in mons[w-row_weights[i]]:
                row={index[tuple(sorted(m+shift))]:c for m,c in q.items()}
                common=math.lcm(*(c.denominator for c in row.values()))
                assert common%prime
                rows.append({j:int(c*common) for j,c in row.items()});row_labels.append([i,list(shift)]);scalars.append(str(common))
        stream.write(f'{w} {len(rows)} {len(index)}\n')
        for row in rows: stream.write(str(len(row))+''.join(f' {j} {v}' for j,v in sorted(row.items()))+'\n')
        labels[str(w)]=row_labels;denominators[str(w)]=scalars
cpp=Path('work/generic_Bfree_C_exact_matrix_rank_20261102.cpp');exe=wd/'rank'
subprocess.run(['clang++','-O3','-std=c++17','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(cpp),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=20)
subprocess.run([str(exe),str(matrix_path),str(output)],env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'},check=True,timeout=35)
pieces={str(w):{'columns':len(mons[w]),'rank':0,'dimension':len(mons[w])} for w in [0,1]}
for line in output.read_text().splitlines():
    w,rows,cols,rank=map(int,line.split());assert rows==len(labels[str(w)]);pieces[str(w)]={'rows':rows,'columns':cols,'rank':rank,'dimension':cols-rank}
hf=[pieces[str(w)]['dimension'] for w in range(5)]
assert hf==[1,7,23,34,0] and sample['remaining_weights'].count(2)==1 and sample['remaining_weights'].count(1)==7
paths=[Path(__file__),cpp,sample_path,chart_path,old_path,matrix_path,output]
result={'scope':'Exact QQ transverse Hilbert function at e=2,d=3,a=-13/25 for the alternate cut, using all135 original equations.',
        'cut':list(sample['new_cut_raw_coordinates']),'transverse_QQ_determinant':sample['new_transverse_determinant_QQ'],
        'all34_QQ_pivots_nonzero_and_p_units':True,'pivot_values_QQ':pivots,'all_remaining_QQ_coefficients_reduce_to_sample':True,
        'remaining_variables':variables,'remaining_weights':sample['remaining_weights'],'weight_pieces':pieces,'Hilbert_function':hf,
        'length':sum(hf),'weight4_zero_and_all_higher_zero':True,'row_labels':labels,'cleared_row_denominators':denominators,
        'remaining_QQ_equations':{str(i):[[list(m),str(c)] for m,c in sorted(q.items())] for i,q in enumerate(equations) if q},
        'input_sha256':{str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in paths},'seconds':time.time()-started}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print('EXACT QQ',hf,'LENGTH',sum(hf),'SECONDS',result['seconds'])

Candidate computation and bounded failure, not a vertical-support theorem.
The original269minor has valid rational specialized e-degree upper1607, GF32003 determinantdegree1241. All61 original QQ[e]row contents are constant afterd3, so known13factor removal leaves the same selected rows and determinant.
An integerization of the chosen269minor (constant row denominators cleared, maximumcoefficient55bits) was submitted once to exact FLINT fmpz_poly_mat_det_interpolate and terminated after180seconds withouta completed determinant.
Use input from BINARY_VERTICAL_ROWMODULE_CANDIDATE_20261102.tar.gz. Source helper and known13factors are bundled here.
Potential different route, not performed: prove366 leading-degree cancellations over constantQQ via reversed-polynomial matrix kernel chains.

from fractions import Fraction
from functools import lru_cache
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

started = time.time()
root = Path.cwd()
work = Path('/tmp/generic-Bfree-original-C-d40-20261102')
work.mkdir(exist_ok=True)
prime = 32003
prior_path = Path('work/generic_Bfree_original_roots_20261102.json')
prior = json.loads(prior_path.read_text())
core = Path('/tmp/generic-Bfree-original-root-weight4-20261102/raw_matrix')
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert prior['raw_matrix_fresh_regeneration_matched'] and digest(core)==prior['input_sha256'][str(core)]
labels = [q[0] for q in prior['row_labels']]
alpha = Fraction(-13,25)
point_a = alpha.numerator * pow(alpha.denominator,-1,prime) % prime
assert (100*point_a + 52) % prime == 0
@lru_cache(None)
def scalar(c):
    q = Fraction(c)
    assert q.denominator % prime
    return q.numerator*pow(q.denominator,-1,prime)%prime
points = [4,0]
paths = {d:work/f'd{d}.in' for d in points}
streams = {d:path.open('w') for d,path in paths.items()}
for f in streams.values(): f.write('5089 2814 32003\n')
with core.open() as source:
    assert source.readline().split()==['5089','2814']
    for label in labels:
        rows={d:[] for d in points}
        for _ in range(int(source.readline())):
            z=source.readline().split()
            column,terms=map(int,z[:2])
            assert len(z)==2+4*terms
            values={d:0 for d in points}
            for k in range(terms):
                aa,ee,dd=map(int,z[3+4*k:6+4*k])
                c=scalar(z[2+4*k])*pow(point_a,aa,prime)*pow(2,ee,prime)%prime
                for d in points: values[d]=(values[d]+c*pow(d,dd,prime))%prime
            for d,v in values.items():
                if v: rows[d].append((column,v))
        for d,row in rows.items():
            streams[d].write(f'{label} {len(row)}'+''.join(f' {j} {v}' for j,v in row)+'\n')
    assert not source.read().strip()
for f in streams.values(): f.close()
cpp=Path('work/generic_Bfree_original_root_rank_20261102.cpp')
exe=work/'rank'
subprocess.run(['clang++','-O3','-std=c++17','-Iwork/flint-headers/flint/3.5.0/include',
                '-I/opt/homebrew/include',str(cpp),'work/m2-runtime/lib/libflint.24.0.dylib',
                '-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=25)
env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'}
deps=[Path(__file__),prior_path,core,cpp]
report={'scope':'Two additional original-matrix F32003 samples on C=0 only.',
        'prime':prime,'a':str(alpha),'a_modp':point_a,'e':2,'cuts':prior['cuts'],'points':{}}
for d in points:
    out=work/f'd{d}.out'
    subprocess.run([str(exe),str(paths[d]),str(out)],check=True,env=env,timeout=70)
    entry={'ranks':{},'full_minors':{}}
    for line in out.read_text().splitlines():
        z=line.split()
        if z[0]=='RANK': entry['ranks'][z[1]]={'rows':int(z[2]),'rank':int(z[3]),'quotient_dimension':int(z[4])}
        elif z[0]=='MINOR_ROWS': entry['full_minors'][z[1]]={'rows':list(map(int,z[3:])),'all_columns':True}
        elif z[0]=='MINOR_DET': entry['full_minors'][z[1]]['determinant_modp']=int(z[2])
        elif z[0]=='SECONDS': entry['native_seconds']=float(z[1])
        else: raise ValueError(line)
    assert set(entry['ranks'])=={'134','135'}
    report['points'][str(d)]=entry;deps.extend([paths[d],out]);report['input_sha256']={str(q):digest(q) for q in deps}
    report['seconds']=time.time()-started
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
    print('d',d,entry['ranks'],{k:v['determinant_modp'] for k,v in entry['full_minors'].items()},flush=True)

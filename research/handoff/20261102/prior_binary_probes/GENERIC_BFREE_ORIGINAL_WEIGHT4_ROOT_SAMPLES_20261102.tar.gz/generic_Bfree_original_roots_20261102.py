from fractions import Fraction
from functools import lru_cache
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

started = time.time()
root = Path.cwd()
work = Path('/tmp/generic-Bfree-original-root-weight4-20261102')
work.mkdir(exist_ok=True)
prime = 32003
source = Path('work/generic_hyperplane_raw_weight4_macaulay_20261102.py')
previous = Path('/tmp/generic-hyperplane-raw-weight4-macaulay-20261102.in')
core = work/'raw_matrix'
producer = work/'original_generator.py'
script = source.read_text().replace(str(previous), str(core)).replace(
    '/tmp/generic-hyperplane-raw-weight4-point-20261102.in', str(work/'unused_generic_point'))
producer.write_text(script)
subprocess.run([sys.executable, str(producer)], check=True, capture_output=True, timeout=40)
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert digest(core) == digest(previous)
data = json.loads(producer.with_suffix('.json').read_text())
assert data['shape'] == [5089,2814]
labels = [row[0] for row in data['row_sources']]
assert labels.count(134) == 12 and labels.count(135) == 557
named_points = {'D0': Fraction(-36,50), 'C': Fraction(-52,100),
                'F': Fraction(-342,500), 'a': Fraction(0)}
def residue(q):
    assert q.denominator % prime
    return q.numerator * pow(q.denominator,-1,prime) % prime
@lru_cache(None)
def scalar(c): return residue(Fraction(c))
points = {name:residue(q) for name,q in named_points.items()}
paths = {name:work/(name+'.in') for name in points}
streams = {name:path.open('w') for name,path in paths.items()}
for stream in streams.values(): stream.write('5089 2814 32003\n')
with core.open() as source_matrix:
    assert source_matrix.readline().split() == ['5089','2814']
    for label in labels:
        rows = {name:[] for name in points}
        for _ in range(int(source_matrix.readline())):
            words = source_matrix.readline().split()
            column,terms = map(int,words[:2])
            assert len(words) == 2+4*terms
            values = {name:0 for name in points}
            for k in range(terms):
                a_degree,e_degree,d_degree = map(int,words[3+4*k:6+4*k])
                coefficient = scalar(words[2+4*k])*pow(2,e_degree,prime)*pow(3,d_degree,prime)%prime
                for name,point in points.items():
                    values[name] = (values[name]+coefficient*pow(point,a_degree,prime))%prime
            for name,value in values.items():
                if value: rows[name].append((column,value))
        for name,row in rows.items():
            streams[name].write(f'{label} {len(row)}'+''.join(f' {j} {c}' for j,c in row)+'\n')
    assert not source_matrix.read().strip()
for stream in streams.values(): stream.close()
cpp = Path('work/generic_Bfree_original_root_rank_20261102.cpp')
exe = work/'rank'
subprocess.run(['clang++','-O3','-std=c++17','-Iwork/flint-headers/flint/3.5.0/include',
                '-I/opt/homebrew/include',str(cpp),'work/m2-runtime/lib/libflint.24.0.dylib',
                '-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=25)
environment = os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'}
dependencies = [Path(__file__),cpp,source,core,Path('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json'),
                Path('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json'),Path('code/s61_model.py'),
                Path('code/s61_flag_transverse_obstruction_20261101.py')]
report = {'scope':'Original 134/135 polynomial fibers over F32003 at the four specified points only.',
          'prime':prime,'fixed_e':2,'fixed_d':3,'cuts':['z19=0','z23=0','z5=0'],
          'raw_shape':[5089,2814],'raw_matrix_fresh_regeneration_matched':True,
          'weight6_source_row':134,'weight6_macaulay_rows':12,'cut_source_row':135,
          'row_labels':data['row_sources'],'points':{}}
for name,point in points.items():
    output = work/(name+'.out')
    subprocess.run([str(exe),str(paths[name]),str(output)],env=environment,check=True,timeout=70)
    result = {'rational_a':str(named_points[name]),'a_modp':point,'ranks':{},'full_minors':{}}
    for line in output.read_text().splitlines():
        w = line.split()
        if w[0]=='RANK':
            result['ranks'][w[1]]={'rows':int(w[2]),'rank':int(w[3]),'quotient_dimension':int(w[4])}
        elif w[0]=='MINOR_ROWS':
            assert len(w[3:])==int(w[2])==2814
            result['full_minors'][w[1]]={'row_indices':list(map(int,w[3:])), 'all_columns':True}
        elif w[0]=='MINOR_DET':
            assert int(w[2])%prime
            result['full_minors'][w[1]]['determinant_modp']=int(w[2])
        elif w[0]=='SECONDS': result['native_seconds']=float(w[1])
        else: raise ValueError(line)
    assert set(result['ranks'])=={'134','135'}
    report['points'][name]=result
    dependencies.extend([paths[name],output]);report['input_sha256']={str(q):digest(q) for q in dependencies}
    report['seconds']=time.time()-started
    Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,result['ranks'],{k:v['determinant_modp']for k,v in result['full_minors'].items()},flush=True)

#include <flint/nmod_mat.h>
#include <cassert>
#include <chrono>
#include <fstream>
#include <iostream>
#include <numeric>
#include <vector>

int main(int argc, char **argv) {
    assert(argc == 3);
    std::ifstream input(argv[1]);
    std::ofstream output(argv[2]);
    assert(input && output);
    int row_count, column_count;
    ulong prime;
    input >> row_count >> column_count >> prime;
    assert(row_count == 5089 && column_count == 2814 && prime == 32003);
    nmod_mat_t original;
    nmod_mat_init(original, row_count, column_count, prime);
    std::vector<int> source_rows(row_count);
    for (int row = 0; row < row_count; ++row) {
        int nonzero;
        input >> source_rows[row] >> nonzero;
        for (int term = 0; term < nonzero; ++term) {
            int column;
            ulong value;
            input >> column >> value;
            assert(column >= 0 && column < column_count && value && value < prime);
            nmod_mat_entry(original, row, column) = value;
        }
    }
    std::string extra;
    assert(input && !(input >> extra));
    const auto start = std::chrono::steady_clock::now();
    for (bool include_weight6 : {false, true}) {
        std::vector<int> rows;
        for (int i = 0; i < row_count; ++i)
            if (include_weight6 || source_rows[i] != 134) rows.push_back(i);
        nmod_mat_t matrix;
        nmod_mat_init(matrix, rows.size(), column_count, prime);
        for (size_t i = 0; i < rows.size(); ++i)
            for (int j = 0; j < column_count; ++j)
                nmod_mat_entry(matrix, i, j) = nmod_mat_entry(original, rows[i], j);
        std::vector<slong> permutation(rows.size());
        std::iota(permutation.begin(), permutation.end(), 0);
        slong rank = nmod_mat_lu(permutation.data(), matrix, 0);
        nmod_mat_clear(matrix);
        output << "RANK " << (include_weight6 ? 135 : 134) << ' ' << rows.size()
               << ' ' << rank << ' ' << column_count-rank << '\n';
        output.flush();
        if (rank != column_count) continue;
        nmod_mat_t minor;
        nmod_mat_init(minor, column_count, column_count, prime);
        output << "MINOR_ROWS " << (include_weight6 ? 135 : 134) << ' ' << column_count;
        for (int i = 0; i < column_count; ++i) {
            int original_row = rows[permutation[i]];
            output << ' ' << original_row;
            for (int j = 0; j < column_count; ++j)
                nmod_mat_entry(minor, i, j) = nmod_mat_entry(original, original_row, j);
        }
        ulong determinant = nmod_mat_det(minor);
        nmod_mat_clear(minor);
        assert(determinant);
        output << "\nMINOR_DET " << (include_weight6 ? 135 : 134) << ' ' << determinant << '\n';
        if (!include_weight6) output << "RANK 135 " << row_count << ' ' << rank << " 0\n";
        break;
    }
    nmod_mat_clear(original);
    output << "SECONDS " << std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count() << '\n';
    output.flush();
    assert(output.good());
    flint_cleanup();
}

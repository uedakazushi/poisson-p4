from pathlib import Path
from fractions import Fraction
import json,hashlib,time,functools,os,subprocess
import sympy as s
st=time.time();root=Path.cwd();core=Path('/tmp/hyperplane-Bfree-t-targets-exact-core-20261102.in');p=32003;points=[3,4];M={dd:[{}for _ in range(321)]for dd in points}
@functools.lru_cache(None)
def coefficient(z):
 c=Fraction(z);assert c.denominator%p;return c.numerator*pow(c.denominator,-1,p)%p
with core.open()as f:
 assert list(map(int,f.readline().split()))==[328,238,321]
 count=0
 for i in range(328):
  for j in range(238):
   z=f.readline().split()
   if i>=321:continue
   n=int(z[0]);assert len(z)==1+4*n;values={dd:{}for dd in points}
   for k in range(n):
    c=coefficient(z[1+4*k]);aa,ee,di=map(int,z[2+4*k:5+4*k]);count+=1;v=c*pow(2,ee,p)%p
    for dd in points:values[dd][aa]=(values[dd].get(aa,0)+v*pow(dd,di,p))%p
   for dd in points:
    v={k:c for k,c in values[dd].items()if c}
    if v:M[dd][i][j]=[v.get(k,0)for k in range(max(v)+1)]
 assert not f.read().strip()
inputs={}
for dd in points:
 path=Path(f'/tmp/generic-Bfree-vertical-a-d{dd}-20261102.in');inputs[dd]=path
 with path.open('w')as f:
  f.write('32003 321 238 0\n0 1\n')
  for row in M[dd]:
   f.write(str(len(row))+'\n')
   for j,co in row.items():f.write(f'{j} {len(co)} '+' '.join(map(str,co))+'\n')
cpp=Path('work/generic_Bfree_vertical_a_rowmodule_20261102.cpp');exe=Path('/tmp/generic-Bfree-vertical-a-rowmodule-20261102');subprocess.run(['clang++','-O3','-std=c++17','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(cpp),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=30);env=dict(os.environ);env['DYLD_LIBRARY_PATH']=str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'
a=s.Symbol('a');known={'a':s.Poly(a,a,modulus=p).monic(),'F':s.Poly(500*a+342,a,modulus=p).monic(),'D0':s.Poly(50*a+36,a,modulus=p).monic(),'C':s.Poly(100*a+52,a,modulus=p).monic()};results={};outs=[]
for dd in points:
 out=Path(f'/tmp/generic-Bfree-vertical-a-d{dd}-20261102.out');log=Path(f'/tmp/generic-Bfree-vertical-a-d{dd}-20261102.log');t=time.time()
 try:
  run=subprocess.run([str(exe),str(inputs[dd]),str(out)],env=env,capture_output=True,text=True,timeout=30);log.write_text(run.stdout+run.stderr);run.check_returncode()
 except subprocess.TimeoutExpired as ex:
  text=(ex.stdout or b'')+(ex.stderr or b'');log.write_bytes(text if isinstance(text,bytes)else text.encode());results[str(dd)]={'status':'timeout30s','seconds':time.time()-t};continue
 except subprocess.CalledProcessError:
  results[str(dd)]={'status':'native_guard_or_error','log':str(log),'seconds':time.time()-t};continue
 res={'status':'completed','factors':[],'seconds':time.time()-t};det=None
 for line in out.read_text().splitlines():
  z=line.split()
  if z[0]=='ROWMODULE':res.update(rank=int(z[1]),determinant_degree=int(z[3]),steps=int(z[5]))
  elif z[0]=='DETERMINANT_COEFFICIENTS':
   assert int(z[1])==len(z)-2;co=list(map(int,z[2:]));det=s.Poly.from_list(list(reversed(co)),a,modulus=p).monic();res['monic_determinant_coefficients_ascending']=[int(det.nth(i))%p for i in range(det.degree()+1)]
  elif z[0]=='RESIDUAL_SIZE':res['residual_size']=int(z[1]);res['factor_count']=int(z[3])
  elif z[0]=='FACTOR':
   mult,n=int(z[1]),int(z[2]);co=list(map(int,z[3:]));assert n==len(co);f=s.Poly.from_list(list(reversed(co)),a,modulus=p).monic();labels=[name for name,q in known.items()if f==q];res['factors'].append({'multiplicity':mult,'coefficients_ascending':[int(f.nth(i))%p for i in range(f.degree()+1)],'known_label':labels[0]if labels else None})
  else:raise AssertionError(line)
 assert det is not None and det.degree()==res['determinant_degree'];prod=s.Poly(1,a,modulus=p)
 for f in res['factors']:prod*=s.Poly.from_list(list(reversed(f['coefficients_ascending'])),a,modulus=p)**f['multiplicity']
 assert prod.monic()==det;res['known_only']=all(f['known_label']is not None for f in res['factors']);results[str(dd)]=res;outs.extend([out,log]);print('d',dd,'degree',res['determinant_degree'],'factors',res['factors'],'seconds',res['seconds'],flush=True)
comparison=None
if all(results[str(dd)]['status']=='completed'for dd in points):
 pp=[s.Poly.from_list(list(reversed(results[str(dd)]['monic_determinant_coefficients_ascending'])),a,modulus=p)for dd in points];g=s.gcd(*pp).monic();remaining=g;known_mult={}
 for name,f in known.items():
  k=0
  while remaining and remaining.degree()>=1 and not remaining.rem(f):remaining=remaining.exquo(f);k+=1
  known_mult[name]=k
 comparison={'gcd_degree':g.degree(),'known_multiplicities':known_mult,'remaining_unknown_degree':remaining.degree(),'remaining_unknown_coefficients_ascending':[int(remaining.nth(i))%p for i in range(remaining.degree()+1)],'gcd_support_known_only':remaining.degree()==0}
report={'scope':'Bounded finite-field candidates only: F32003[a] full321-row polynomial modules at e=2,d=3 and4. No QQ vertical support or all-core conclusion.','prime':p,'variable':'a','fixed_e':2,'d_values':points,'coefficient_terms_read':count,'results':results,'comparison':comparison,'per_point_seconds_bound':30,'no_nonconstant_row_division':True,'input_sha256':{str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in [Path(__file__),cpp,core]+list(inputs.values())+outs},'seconds':time.time()-st};Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('COMPARISON',comparison,'TOTAL',report['seconds'])

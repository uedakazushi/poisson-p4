Finite-field candidate bundle. No QQ conclusion.
The10 complement columns have all other free coordinates zero.
Together with the known33 they are independent at e=2.
Programs need FLINT3.5.0 headers/library; no dependency binaries bundled.
Sampling invocation: complement_sampling leading_matrix.txt known_degree4_kernel33.txt result.txt samples.txt
Identity invocation: complement_identity leading_matrix.txt samples.txt complement_denominator.txt numerators.txt
Bounded invocation: bounded leading_matrix.txt 6 output.txt (or8).

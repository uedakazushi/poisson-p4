#include <flint/nmod_mat.h>
#include <flint/nmod_poly.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <random>
#include <chrono>
#include <cassert>
#include <cstdint>
using namespace std;
const ulong P=32003;
ulong power(ulong a,ulong b){ulong r=1;for(;b;b>>=1,a=a*a%P)if(b&1)r=r*a%P;return r;}
ulong integer(const string&s){bool neg=s[0]=='-';ulong r=0;for(size_t i=(s[0]=='-'||s[0]=='+');i<s.size();i++)r=(r*10+s[i]-'0')%P;return neg&&r?P-r:r;}
ulong rational(const string&s){size_t slash=s.find('/');if(slash==string::npos)return integer(s);ulong d=integer(s.substr(slash+1));assert(d);return integer(s.substr(0,slash))*power(d,P-2)%P;}
void show(ostream&o,nmod_poly_t p){o<<nmod_poly_length(p);for(long i=0;i<nmod_poly_length(p);i++)o<<' '<<nmod_poly_get_coeff_ui(p,i);o<<'\n';}
int main(int argc,char**argv){
 assert(argc==5);auto start=chrono::steady_clock::now();auto sec=[&](){return chrono::duration<double>(chrono::steady_clock::now()-start).count();};
 ifstream in(argv[1]),selection(argv[2]);ofstream out(argv[3]),full(argv[4]);assert(in&&selection&&out&&full);int nr,n;in>>nr>>n;assert(nr==238&&n==135);int rank;selection>>rank;assert(rank==132);vector<int>rows(rank);for(int&i:rows)selection>>i;assert(selection);
 vector<vector<pair<int,ulong>>>A(nr*n);int maxdegree=0;long terms=0;
 for(auto&q:A){int nt;in>>nt;for(int z=0;z<nt;z++){string c;int x,e;in>>c>>x>>e;assert(x==0&&e>=0);ulong v=rational(c);if(v)q.emplace_back(e,v);maxdegree=max(maxdegree,e);}terms+=q.size();}
 string extra;assert(in&&!(in>>extra));out<<"INPUT "<<nr<<' '<<n<<" RANK "<<rank<<" MAXDEG "<<maxdegree<<" TERMS "<<terms<<'\n';
 nmod_mat_t M,B,F,X,K,C;nmod_mat_init(M,nr,n,P);nmod_mat_init(B,rank,rank,P);nmod_mat_init(F,rank,3,P);nmod_mat_init(X,rank,3,P);nmod_mat_init(K,n,3,P);nmod_mat_init(C,nr,3,P);
 mt19937 rng(20261102);vector<vector<ulong>>weights(3,vector<ulong>(n*3));for(auto&w:weights)for(auto&x:w)x=rng()%P;
 out<<"WEIGHTS_SEED 20261102\n";for(int i=0;i<3;i++){out<<"WEIGHTS "<<i;for(ulong x:weights[i])out<<' '<<x;out<<'\n';}
 vector<ulong>xs;vector<vector<ulong>>ys(3);ulong ev=2;int attempts=0;bool accepted=false;
 for(int goal:{64,128,224}){
  while((int)xs.size()<goal+32){
   assert(xs.size()<256&&sec()<27);vector<ulong>powers(maxdegree+1,1);for(int i=1;i<=maxdegree;i++)powers[i]=powers[i-1]*ev%P;
   for(int i=0;i<nr;i++)for(int j=0;j<n;j++){uint64_t sum=0;for(auto[e,c]:A[i*n+j])sum+=uint64_t(c)*powers[e];nmod_mat_entry(M,i,j)=sum%P;}
   for(int i=0;i<rank;i++){for(int j=0;j<rank;j++)nmod_mat_entry(B,i,j)=nmod_mat_entry(M,rows[i],j);for(int j=0;j<3;j++){ulong c=nmod_mat_entry(M,rows[i],rank+j);nmod_mat_entry(F,i,j)=c?P-c:0;}}
   attempts++;if(!nmod_mat_solve(X,B,F)){ev++;continue;}nmod_mat_zero(K);for(int j=0;j<3;j++)nmod_mat_entry(K,rank+j,j)=1;
   for(int i=0;i<rank;i++)for(int j=0;j<3;j++)nmod_mat_entry(K,i,j)=nmod_mat_entry(X,i,j);
   nmod_mat_mul(C,M,K);assert(nmod_mat_is_zero(C));xs.push_back(ev);full<<ev;
   for(int i=0;i<n;i++)for(int j=0;j<3;j++)full<<' '<<nmod_mat_entry(K,i,j);full<<'\n';
   for(int h=0;h<3;h++){uint64_t sum=0;for(int i=0;i<n;i++)for(int j=0;j<3;j++)sum+=uint64_t(weights[h][i*3+j])*nmod_mat_entry(K,i,j);ys[h].push_back(sum%P);}ev++;
  }
  accepted=true;out<<"TRIAL "<<goal<<" SAMPLES "<<xs.size()<<" HOLDOUT "<<xs.size()-goal<<'\n';
  for(int h=0;h<3;h++){
   nmod_poly_t mod,f,r0,r1,s0,s1,q,r,s,tmp,g,num,den;
   for(auto z:{mod,f,r0,r1,s0,s1,q,r,s,tmp,g,num,den})nmod_poly_init(z,P);
   nmod_poly_product_roots_nmod_vec(mod,xs.data(),goal);nmod_poly_interpolate_nmod_vec_fast(f,xs.data(),ys[h].data(),goal);nmod_poly_set(r0,mod);nmod_poly_set(r1,f);nmod_poly_one(s1);bool good=false;
   while(!nmod_poly_is_zero(r1)){
    if(nmod_poly_degree(r1)+nmod_poly_degree(s1)<goal){
     nmod_poly_gcd(g,r1,s1);nmod_poly_div(num,r1,g);nmod_poly_div(den,s1,g);ulong lc=nmod_poly_get_coeff_ui(den,nmod_poly_degree(den));assert(lc);nmod_poly_scalar_mul_nmod(num,num,power(lc,P-2));nmod_poly_scalar_mul_nmod(den,den,power(lc,P-2));good=true;
     for(int i=0;i<(int)xs.size();i++){ulong d=nmod_poly_evaluate_nmod(den,xs[i]),v=nmod_poly_evaluate_nmod(num,xs[i]);if(!d||v!=ys[h][i]*d%P){good=false;break;}}
     if(good)break;
    }
    nmod_poly_divrem(q,r,r0,r1);nmod_poly_mul(tmp,q,s1);nmod_poly_sub(s,s0,tmp);nmod_poly_swap(r0,r1);nmod_poly_swap(r1,r);nmod_poly_swap(s0,s1);nmod_poly_swap(s1,s);
   }
   accepted&=good;out<<"CANDIDATE "<<h<<' '<<good<<' '<<nmod_poly_degree(num)<<' '<<nmod_poly_degree(den)<<'\n';show(out,num);show(out,den);cerr<<"TRIAL "<<goal<<" CANDIDATE "<<h<<" GOOD "<<good<<" NUM "<<nmod_poly_degree(num)<<" DEN "<<nmod_poly_degree(den)<<" SEC "<<sec()<<'\n';
   for(auto z:{mod,f,r0,r1,s0,s1,q,r,s,tmp,g,num,den})nmod_poly_clear(z);
  }
  out.flush();full.flush();assert(out.good()&&full.good());if(accepted)break;
 }
 out<<"FINAL "<<accepted<<" SAMPLES "<<xs.size()<<" ATTEMPTS "<<attempts<<" SECONDS "<<sec()<<'\n';out.flush();full.flush();assert(out.good()&&full.good());
 nmod_mat_clear(M);nmod_mat_clear(B);nmod_mat_clear(F);nmod_mat_clear(X);nmod_mat_clear(K);nmod_mat_clear(C);
}

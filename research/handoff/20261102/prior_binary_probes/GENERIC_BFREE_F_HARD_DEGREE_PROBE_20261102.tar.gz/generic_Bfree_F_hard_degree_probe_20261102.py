from pathlib import Path
import json,time,hashlib,os,subprocess

start=time.time();root=Path.cwd();priorpath=Path('work/generic_Bfree_root_F_hard_union_rank_20261102.json');prior=json.loads(priorpath.read_text());inp=Path('/tmp/generic-Bfree-root-F-hard-union-rank-20261102/input');assert hashlib.sha256(inp.read_bytes()).hexdigest()==prior['input_sha256'][str(inp)]
wd=Path('/tmp/generic-Bfree-F-hard-degree-probe-20261102');wd.mkdir(exist_ok=True);selection=wd/'selection';rows=prior['common132_minor_modp']['equation_rows'];assert len(rows)==132;selection.write_text('132\n'+' '.join(map(str,rows))+'\n')
cpp=Path('work/generic_Bfree_F_hard_degree_probe_20261102.cpp');exe=wd/'native';out=wd/'output';full=wd/'samples';log=wd/'log'
subprocess.run(['clang++','-O3','-std=c++17','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(cpp),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=10)
env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'};report={'scope':'Bounded F32003 evaluation/interpolation degree candidates only for the three hard F-root left kernels. No QQ replay, QQ rational solution, or full polynomial identity claimed.','prime':32003,'fixed_pivot_rows':rows,'common_columns':prior['common_columns'],'anchor_columns':prior['anchor_columns'],'sample_limit':256,'whole_seconds_limit':30,'holdouts_per_trial_at_least':32,'random_rule':'std::mt19937 seed20261102, rng()%32003, three arrays in component-row-major135x3 order','all_valid_samples_full238x3_kernel_checked':False}
try:
    cp=subprocess.run([str(exe),str(inp),str(selection),str(out),str(full)],env=env,capture_output=True,text=True,timeout=max(1,30-(time.time()-start)));log.write_text(cp.stdout+cp.stderr);cp.check_returncode();report['status']='completed'
except subprocess.TimeoutExpired as ex:
    z=(ex.stdout or b'')+(ex.stderr or b'');log.write_bytes(z if isinstance(z,bytes)else z.encode());report['status']='whole30s_timeout'
except subprocess.CalledProcessError:report['status']='native_guard_or_error'
if report['status']=='completed':
    lines=iter(out.read_text().splitlines());trials=[];weights=[];trial=None
    for line in lines:
        z=line.split()
        if z[0]=='INPUT':report['input_summary']=line
        elif z[0]=='WEIGHTS_SEED':assert z[1]=='20261102'
        elif z[0]=='WEIGHTS':assert int(z[1])==len(weights);weights.append(list(map(int,z[2:])))
        elif z[0]=='TRIAL':trial={'training_samples':int(z[1]),'total_samples':int(z[3]),'holdout_samples':int(z[5]),'candidates':[]};trials.append(trial)
        elif z[0]=='CANDIDATE':
            num=list(map(int,next(lines).split()));den=list(map(int,next(lines).split()));assert num[0]==len(num)-1 and den[0]==len(den)-1;trial['candidates'].append({'random_index':int(z[1]),'fits_training_and_holdouts':z[2]=='1','numerator_degree':int(z[3]),'denominator_degree':int(z[4]),'numerator_coefficients_ascending':num[1:],'denominator_coefficients_ascending':den[1:]})
        elif z[0]=='FINAL':report.update(accepted=z[1]=='1',valid_sample_count=int(z[3]),attempted_sample_count=int(z[5]),native_seconds=float(z[7]))
        else:raise AssertionError(line)
    report['trials']=trials;report['weights']=weights;report['all_valid_samples_full238x3_kernel_checked']=True
    samples=[list(map(int,z.split()))for z in full.read_text().splitlines()];assert len(samples)==report['valid_sample_count']<=256 and all(len(z)==406 for z in samples)
    if report['accepted']:
        def ev(co,x):
            v=0
            for c in reversed(co):v=(v*x+c)%32003
            return v
        accepted=trials[-1]['candidates'];assert len(accepted)==3
        for c in accepted:
            assert c['fits_training_and_holdouts'];w=weights[c['random_index']]
            for point,*v in samples:
                den=ev(c['denominator_coefficients_ascending'],point);assert den and ev(c['numerator_coefficients_ascending'],point)==sum(x*y for x,y in zip(w,v))*den%32003
        report['independent_python_all_sample_fit_checked']=True
        report['three_candidate_denominators_equal']=all(c['denominator_coefficients_ascending']==accepted[0]['denominator_coefficients_ascending']for c in accepted)
paths=[Path(__file__),cpp,priorpath,inp,selection,log]+[q for q in [out,full]if q.exists()];report['input_sha256']={str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in paths};report['seconds']=time.time()-start
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('RESULT',report['status'],'ACCEPTED',report.get('accepted'),'SAMPLES',report.get('valid_sample_count'),'SECONDS',report['seconds'])
if report.get('accepted'):print('DEGREES',[(c['numerator_degree'],c['denominator_degree'])for c in report['trials'][-1]['candidates']])

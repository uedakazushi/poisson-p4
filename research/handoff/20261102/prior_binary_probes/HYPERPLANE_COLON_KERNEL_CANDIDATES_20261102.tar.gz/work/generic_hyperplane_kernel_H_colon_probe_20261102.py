from pathlib import Path
import json,subprocess,os,time,sympy as s
start=time.time();x=json.loads(Path('work/generic_hyperplane_D_colon_kernels_20261102.json').read_text());y=json.loads(Path('work/generic_hyperplane_kernel_schur_20261102.json').read_text())
a,e=s.symbols('a e');D=sum(s.Rational(c)*a**m[0]*e**m[1] for m,c in y['kernels'][0]['denominator_sparse']);H=s.Poly(D,a,e).exquo(s.Poly(a**2*(50*a+9*e**2+3*e-6),a,e));hs=str(H.as_expr()).replace('**','^')
def poly(p):return '+'.join('('+c+')'+''.join('*'+v+(f'^{n}' if n>1 else '') for v,n in zip(('a','e','d'),m) if n) for m,c in p) or '0'
mat='transpose matrix {'+','.join('{'+','.join(poly(p) for p in g)+'}' for g in x['generators'])+'}'
source='R=QQ[a,e,d,MonomialOrder=>GRevLex]; M=image map(R^16,,'+mat+'); H='+hs+'; <<"H_COLON_START"<<endl; N=quotient(M,H); E=mingens N; <<"H_COLON_DONE GENS "<<numColumns E<<" TERMS "<<sum flatten apply(entries E,r->apply(r,p->#terms p))<<endl;\n'
source+='out="/tmp/generic-hyperplane-H-colon-20261102.txt"<<numRows E<<" "<<numColumns E<<endl; scan(numRows E,i->scan(numColumns E,j->(out<<i<<" "<<j<<" "<<toString E_(i,j)<<endl))); close out;\n'
p=Path('/tmp/generic-hyperplane-kernel-H-colon-20261102.m2');p.write_text(source)
env=os.environ.copy();env['DYLD_LIBRARY_PATH']=str(Path('work/m2-runtime/lib').resolve())+':/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'
try:
 proc=subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',str(p)],env=env,capture_output=True,text=True,timeout=60)
 result=dict(returncode=proc.returncode,stdout=proc.stdout,stderr=proc.stderr,seconds=time.time()-start)
except subprocess.TimeoutExpired as exc:result=dict(timeout_seconds=60,stdout=str(exc.stdout),stderr=str(exc.stderr),seconds=time.time()-start)
print(result,flush=True);Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')

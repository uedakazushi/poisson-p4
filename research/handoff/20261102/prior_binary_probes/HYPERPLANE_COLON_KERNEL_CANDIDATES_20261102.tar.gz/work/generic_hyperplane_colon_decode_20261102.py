from pathlib import Path
import json,re,sympy as s
src=Path('/tmp/generic-hyperplane-a-colon-20261102-3.txt');lines=src.read_text().splitlines();nr,nc=map(int,lines[0].split());assert nr==16
cols=[[[] for _ in range(16)] for j in range(nc)]
for line in lines[1:]:
 ii,jj,expr=line.split(' ',2);terms=[]
 if expr!='0':
  for term in re.findall(r'[+-]?[^+-]+',expr):
   c=s.S.One;m=[0,0,0]
   if term[0]=='-':c=-c;term=term[1:]
   elif term[0]=='+':term=term[1:]
   for fac in term.split('*'):
    if fac[0] in 'aed':
     z=fac.split('^');m['aed'.index(z[0])]=int(z[1]) if len(z)==2 else 1
    else:c*=s.Rational(fac)
   terms.append([m,str(c)])
 cols[int(jj)][int(ii)]=terms
stats=[dict(terms=sum(len(p) for p in col),total_degree=max([sum(m) for p in col for m,c in p],default=-1),individual_degrees=[max([m[k] for p in col for m,c in p],default=-1) for k in range(3)]) for col in cols]
print(stats)
Path('work/generic_hyperplane_a_saturated_kernels_20261102.json').write_text(json.dumps(dict(variables=['a','e','d'],generators=cols,statistics=stats),indent=2)+'\n')
data=json.loads(Path('code/data/s61_binary_hyperplane_heavy_template_20261102.json').read_text())
with Path('/tmp/generic-hyperplane-a-saturated-check-20261102.in').open('w') as f:
 f.write(f'16 7 {nc}\n')
 for row in data['matrix']:
  for p in row:f.write(str(len(p))+''.join(f' {c} '+ ' '.join(map(str,m)) for m,c in p)+'\n')
 for col in cols:
  for p in col:f.write(str(len(p))+''.join(f' {c} '+ ' '.join(map(str,m)) for m,c in p)+'\n')

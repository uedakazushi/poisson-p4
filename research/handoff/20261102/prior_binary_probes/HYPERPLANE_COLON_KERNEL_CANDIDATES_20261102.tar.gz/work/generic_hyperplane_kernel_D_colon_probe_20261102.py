from pathlib import Path
import json,subprocess,os,time
start=time.time();x=json.loads(Path('work/generic_hyperplane_kernel_schur_20261102.json').read_text())
p=x['kernels'][0]['denominator_sparse'];den='+'.join('('+c+')'+''.join('*'+v+(f'^{n}' if n>1 else '') for v,n in zip(('a','e'),m) if n) for m,c in p)
source=Path('/tmp/generic-hyperplane-d4-kernel-module-reduce-20261102.m2').read_text().split('G=gb B;')[0]
source+='B=map(R^16,,B); V=map(R^16,,V); M=saturate(image(B|V),a); <<"A_SAT_READY"<<endl; D='+den+';\n'
source+='for k from 1 to 3 do (N:=quotient(M,D); E:=mingens N; <<"D_STEP "<<k<<" GENS "<<numColumns E<<" TERMS "<<sum flatten apply(entries E,r->apply(r,p->#terms p))<<endl; out:=("/tmp/generic-hyperplane-D-colon-20261102-"|toString k|".txt")<<numRows E<<" "<<numColumns E<<endl; scan(numRows E,i->scan(numColumns E,j->(out<<i<<" "<<j<<" "<<toString E_(i,j)<<endl))); close out; if N==M then (<<"D_SATURATION_STABLE "<<k<<endl; break); M=N);\n'
p=Path('/tmp/generic-hyperplane-kernel-D-colon-20261102.m2');p.write_text(source)
env=os.environ.copy();env['DYLD_LIBRARY_PATH']=str(Path('work/m2-runtime/lib').resolve())+':/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'
try:
 proc=subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',str(p)],env=env,capture_output=True,text=True,timeout=60)
 result=dict(returncode=proc.returncode,stdout=proc.stdout,stderr=proc.stderr,seconds=time.time()-start)
except subprocess.TimeoutExpired as exc:result=dict(timeout_seconds=60,stdout=str(exc.stdout),stderr=str(exc.stderr),seconds=time.time()-start)
print(result,flush=True);Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')

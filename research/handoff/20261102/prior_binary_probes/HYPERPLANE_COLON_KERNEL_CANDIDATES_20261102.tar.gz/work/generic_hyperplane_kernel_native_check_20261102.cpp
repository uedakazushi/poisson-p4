#include <flint/fmpq.h>
#include <flint/fmpq_mpoly.h>
#include <flint/fmpq_mpoly_factor.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <cassert>
#include <chrono>
using namespace std;fmpq_mpoly_ctx_t ctx;
struct Poly{fmpq_mpoly_t p;Poly(){fmpq_mpoly_init(p,ctx);}Poly(const Poly&a):Poly(){fmpq_mpoly_set(p,a.p,ctx);}Poly(Poly&&a):Poly(){fmpq_mpoly_swap(p,a.p,ctx);}Poly&operator=(Poly a){fmpq_mpoly_swap(p,a.p,ctx);return *this;}~Poly(){fmpq_mpoly_clear(p,ctx);}};
void write(ostream&o,const Poly&a){fmpq_t q;fmpq_init(q);ulong ex[3];int n=fmpq_mpoly_length(a.p,ctx);o<<n;for(int i=0;i<n;i++){fmpq_mpoly_get_term_coeff_fmpq(q,a.p,i,ctx);fmpq_mpoly_get_term_exp_ui(ex,a.p,i,ctx);char*s=fmpq_get_str(nullptr,10,q);o<<' '<<s;for(ulong x:ex)o<<' '<<x;flint_free(s);}o<<'\n';fmpq_clear(q);}
Poly determinant(vector<vector<Poly>> A){Poly prev,x,y,z;fmpq_mpoly_one(prev.p,ctx);int n=A.size(),sign=1;for(int k=0;k<n-1;k++){int bi=-1,bj=-1;long cost=10000000;for(int i=k;i<n;i++)for(int j=k;j<n;j++){int l=fmpq_mpoly_length(A[i][j].p,ctx);if(l&&l<cost){cost=l;bi=i;bj=j;}}assert(bi>=0);if(k!=bi)sign=-sign;if(k!=bj)sign=-sign;swap(A[k],A[bi]);for(auto&r:A)swap(r[k],r[bj]);for(int i=k+1;i<n;i++)for(int j=k+1;j<n;j++){fmpq_mpoly_mul(x.p,A[k][k].p,A[i][j].p,ctx);fmpq_mpoly_mul(y.p,A[i][k].p,A[k][j].p,ctx);fmpq_mpoly_sub(z.p,x.p,y.p,ctx);assert(fmpq_mpoly_divides(A[i][j].p,z.p,prev.p,ctx));}prev=A[k][k];}Poly answer=A[n-1][n-1];if(sign<0)fmpq_mpoly_neg(answer.p,answer.p,ctx);return answer;}

void read(istream&in,Poly&a){int n;in>>n;fmpq_t q;fmpq_init(q);ulong ex[3];for(int i=0;i<n;i++){string z;in>>z>>ex[0]>>ex[1]>>ex[2];assert(!fmpq_set_str(q,z.c_str(),10));fmpq_canonicalise(q);fmpq_mpoly_push_term_fmpq_ui(a.p,q,ex,ctx);}fmpq_mpoly_sort_terms(a.p,ctx);fmpq_mpoly_combine_like_terms(a.p,ctx);fmpq_clear(q);}
int main(int argc,char**argv){assert(argc==2);fmpq_mpoly_ctx_init(ctx,3,ORD_LEX);{ifstream in(argv[1]);assert(in);int n,m,k;in>>n>>m>>k;vector<vector<Poly>>A(n,vector<Poly>(m)),K(k,vector<Poly>(n));for(auto&r:A)for(auto&p:r)read(in,p);for(auto&r:K)for(auto&p:r)read(in,p);auto start=chrono::steady_clock::now();Poly tmp,z;for(int i=0;i<k;i++){for(int j=0;j<m;j++){fmpq_mpoly_zero(z.p,ctx);for(int l=0;l<n;l++){fmpq_mpoly_mul(tmp.p,K[i][l].p,A[l][j].p,ctx);fmpq_mpoly_add(z.p,z.p,tmp.p,ctx);}assert(fmpq_mpoly_is_zero(z.p,ctx));}cerr<<"KERNEL "<<i<<" PASS SEC "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';}}fmpq_mpoly_ctx_clear(ctx);flint_cleanup();}

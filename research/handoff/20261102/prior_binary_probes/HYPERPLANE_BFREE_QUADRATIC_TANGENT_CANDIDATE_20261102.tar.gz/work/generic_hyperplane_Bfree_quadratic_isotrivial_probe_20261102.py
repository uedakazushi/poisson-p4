from pathlib import Path
from fractions import Fraction
import itertools,json,hashlib,time,sys
import numpy as np
start=time.time();p=32003;point=(1,2,3);path=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/poisson-hyperplane-Bfree-cubic-20261102/rows');light=[0,1,2,3,4,6,7]
mons=[]
for pair in itertools.combinations_with_replacement(range(7),2):
 m=[0]*7
 for i in pair:m[i]+=1
 mons.append(tuple(m))
index={m:i for i,m in enumerate(mons)};qs=[];dq=[];labels=[];read_terms=0
with path.open() as f:
 for _ in range(int(f.readline())):
  source,weight,count=map(int,f.readline().split());q=np.zeros(28,dtype=np.int64);der=np.zeros((28,3),dtype=np.int64)
  for j in range(count):
   mon=tuple(map(int,f.readline().split()));line=f.readline()
   if weight!=2:continue
   assert mon[5]==0 and sum(mon)==2
   col=index[tuple(mon[i] for i in light)];words=line.split();n=int(words[0]);assert len(words)==1+4*n
   for k in range(n):
    c=Fraction(words[1+4*k]);ex=tuple(map(int,words[2+4*k:5+4*k]));assert c.denominator%p
    base=c.numerator*pow(c.denominator,-1,p)%p
    value=base
    for t,z in zip(point,ex):value=value*pow(t,z,p)%p
    q[col]=(q[col]+value)%p
    for h in range(3):
     if ex[h]:der[col,h]=(der[col,h]+value*ex[h]*pow(point[h],-1,p))%p
    read_terms+=1
  if weight==2:qs.append(q);dq.append(der);labels.append(source)
assert len(qs)==6
Q=np.array(qs,dtype=np.int64);rhs=np.vstack(dq);A=np.zeros((168,85),dtype=np.int64)
for i,q in enumerate(Q):
 for mm,c in zip(mons,q):
  if not c:continue
  for r in range(7):
   if not mm[r]:continue
   for ss in range(7):
    nn=list(mm);nn[r]-=1;nn[ss]+=1;A[i*28+index[tuple(nn)],r*7+ss]=(A[i*28+index[tuple(nn)],r*7+ss]+int(c)*mm[r])%p
for i in range(6):
 for j in range(6):A[i*28:(i+1)*28,49+i*6+j]=Q[j]
def rref(M,transform=False):
 M=M.copy();E=np.eye(M.shape[0],dtype=np.int64) if transform else None;rank=0;pc=[]
 for j in range(M.shape[1]):
  hit=next((i for i in range(rank,M.shape[0]) if M[i,j]),None)
  if hit is None:continue
  if hit!=rank:
   M[[rank,hit]]=M[[hit,rank]]
   if E is not None:E[[rank,hit]]=E[[hit,rank]]
  inv=pow(int(M[rank,j]),-1,p);M[rank]=M[rank]*inv%p
  if E is not None:E[rank]=E[rank]*inv%p
  for i in range(M.shape[0]):
   if i!=rank and M[i,j]:
    val=int(M[i,j]);M[i]=(M[i]-val*M[rank])%p
    if E is not None:E[i]=(E[i]-val*E[rank])%p
  pc.append(j);rank+=1
  if rank==M.shape[0]:break
 return rank,pc,M,E
rank,piv,red,trans=rref(A,True);assert np.array_equal(trans@A%p,red)
rr=trans@rhs%p;results={}
for j,name in enumerate(['a','e','d']):
 compatible=not np.any(rr[rank:,j]);res=dict(orbit_rank=rank,augmented_rank=rank+int(not compatible),member=compatible)
 if compatible:
  sol=np.zeros(85,dtype=np.int64)
  for i,k in enumerate(piv):sol[k]=rr[i,j]
  assert np.array_equal(A@sol%p,rhs[:,j]);res['solution']=sol.tolist();res['solution_GL7']=sol[:49].reshape(7,7).tolist();res['solution_GL6']=sol[49:].reshape(6,6).tolist()
 else:
  n=rank+int(np.flatnonzero(rr[rank:,j])[0]);w=trans[n];assert not np.any(w@A%p);v=int(w@rhs[:,j]%p);assert v
  res['left_annihilator_sparse']=[[i,int(x)] for i,x in enumerate(w) if x];res['annihilator_target_value']=v
 results[name]=res
aug=rref(np.column_stack([A,rhs]))[0];assert aug==rank+rref(rr[rank:])[0]
report=dict(scope='Fixed-point finite-field tangent-orbit membership only; no QQ or local/global isotriviality theorem. Uses supplied B-free low-row cache, not an independent raw135 reconstruction.',prime=p,point=dict(zip(['a','e','d'],point)),input=str(path),input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),producer_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),quadric_source_rows=labels,light_positions=light,monomials=mons,quadric_values=Q.tolist(),parameter_derivative_values=rhs.tolist(),orbit_matrix_shape=list(A.shape),unknown_order='GL7: x_s*d/dx_r row-major(r,s), followed by GL6: output_i += Y_ij*q_j row-major(i,j)',orbit_rank=rank,GL7_rank=rref(A[:,:49])[0],GL6_rank=rref(A[:,49:])[0],orbit_plus_all_derivatives_rank=aug,orbit_pivot_columns=piv,results=results,read_core_terms=read_terms,all_witnesses_checked=True,seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['quadric_source_rows','orbit_matrix_shape','orbit_rank','GL7_rank','GL6_rank','orbit_plus_all_derivatives_rank','read_core_terms','seconds']},indent=2));print({n:{k:r[k] for k in ['augmented_rank','member']} for n,r in results.items()})

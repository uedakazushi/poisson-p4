from pathlib import Path
import json,hashlib,time,os,subprocess,math

start=time.time();root=Path.cwd();p=32003;n=238;limit=32
profile_path=Path('work/generic_Bfree_vertical_a_infinity_20261102.json');prof=json.loads(profile_path.read_text());rows=prof['selected_original_rows'];assert len(rows)==len(set(rows))==n
orders_path=Path('work/generic_Bfree_vertical_a_minor_known_orders_20261102.json');orders=json.loads(orders_path.read_text())
uni=Path('/tmp/generic-Bfree-vertical-a-d3-20261102.in');assert hashlib.sha256(uni.read_bytes()).hexdigest()==prof['input_sha256'][str(uni)]
it=iter(map(int,uni.read_text().split()));assert [next(it)for _ in range(4)]==[p,321,n,0];next(it);next(it);M=[]
for i in range(321):
    row={}
    for _ in range(next(it)):
        j,l=next(it),next(it);row[j]=[next(it)for _ in range(l)]
    M.append(row)
assert next(it,None)is None
source=Path('work/generic_Bfree_vertical_a_infinity_profile_20261102.cpp')
cpp=Path('work/generic_Bfree_vertical_knownroot_profile_20261102.cpp');cpp.write_text(source.read_text().replace('if(sec()>25)','if(sec()>18)'))
exe=Path('/tmp/generic-Bfree-vertical-knownroot-profile-20261102');subprocess.run(['clang++','-O3','-std=c++17','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(cpp),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=20)
env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'}
cases=[('a',1,0,'a=delta'),('F',500,342,'a=(delta-90*e^2-3*e+24)/500'),('D0',50,36,'a=(delta-9*e^2-3*e+6)/50'),('C',100,52,'a=(delta-18*e^2+9*e+2)/100')]
report={'scope':'Bounded finite-field delta profiles at e=2,d=3 for the fixed selected original238-row minor. Every named factor itself equals delta. No QQ kernel or QQ root-order theorem.','prime':p,'fixed_e':2,'fixed_d':3,'selected_original_rows':rows,'original_columns':list(range(n)),'jet_limit':limit,'per_native_wall_limit_seconds':20,'whole_wall_limit_seconds':60,'cases':{}}
paths=[Path(__file__),source,cpp,profile_path,orders_path,uni]
def evaluate(co,x):
    ans=0
    for c in reversed(co):ans=(ans*x+c)%p
    return ans
for name,alpha,b,formula in cases:
    if time.time()-start>38:
        report['cases'][name]={'status':'not_started_whole_budget'};continue
    t=time.time();ia=pow(alpha,-1,p);a0=-b*ia%p;maxdeg=max(len(co)-1 for row in M for co in row.values());pwroot=[pow(a0,k,p)for k in range(maxdeg+1)];pwscale=[pow(ia,k,p)for k in range(maxdeg+1)]
    base=Path('/tmp')/f'generic-Bfree-vertical-root-{name}-20261102';inp=base.with_suffix('.in');out=base.with_suffix('.out');log=base.with_suffix('.log');nonzero=0
    with inp.open('w')as f:
        f.write(f'{p} {n} {n} {limit}\n')
        for i in rows:
            for j in range(n):
                co=M[i].get(j,[]);trans=[sum(co[k]*math.comb(k,l)*pwroot[k-l]for k in range(l,len(co)))*pwscale[l]%p for l in range(len(co))]
                while trans and not trans[-1]:trans.pop()
                # Check the substitution at two independent delta values.
                for x in [1,7]:assert evaluate(trans,x)==evaluate(co,(x-b)*ia%p)
                nonzero+=bool(trans);f.write(str(len(trans))+(' '+' '.join(map(str,trans))if trans else '')+'\n')
    paths.append(inp);case={'factor_alpha':alpha,'factor_beta_at_e2':b,'root_a_modp':a0,'QQ_e_substitution_convention':formula,'factor_equals_delta':True,'alpha_p_unit':True,'entry_substitutions_at_delta1_and7_checked':True,'nonzero_entries':nonzero,'expected_order_from_direct_determinant':orders['known_orders'][name]['order']}
    try:
        run=subprocess.run([str(exe),str(inp),str(out)],env=env,capture_output=True,text=True,timeout=min(20,60-(time.time()-start)))
        log.write_text(run.stdout+run.stderr);run.check_returncode();case['status']='completed';stages=[];last=None;res={}
        for ln in out.read_text().splitlines():
            z=ln.split()
            if z[0]=='STAGE':
                vals={z[k]:z[k+1]for k in range(0,len(z),2)};last={k.lower():float(v)if k=='SECONDS'else int(v)for k,v in vals.items()};last['pivots']=[];stages.append(last)
            elif z[0]=='PIVOT':
                v=list(map(int,z[1:]));assert v[0]==last['stage'];last['pivots'].append(v[1:])
            elif z[0]=='RESULT':res={z[k]:z[k+1]for k in range(1,len(z),2)}
            elif z[0].startswith('STOP'):case['status']='native_guard_or_precision'
            else:raise AssertionError(ln)
        if res.get('COMPLETE')=='1':
            assert sum(q['rank']for q in stages)==n;order=int(res['VALUATION']);assert order==case['expected_order_from_direct_determinant']
            case.update(complete=True,order=order,first_corank=n-stages[0]['rank'],maximum_chain_depth=max(q['stage']for q in stages if q['rank']),elementary_divisor_multiplicities=[[q['stage'],q['rank']]for q in stages if q['rank']],native_seconds=float(res['SECONDS']))
        case['stages']=stages
    except subprocess.TimeoutExpired as ex:
        txt=(ex.stdout or b'')+(ex.stderr or b'');log.write_bytes(txt if isinstance(txt,bytes)else txt.encode());case['status']='timeout20s'
    except subprocess.CalledProcessError:case['status']='native_error_or_guard'
    paths.append(log)
    if out.exists():paths.append(out)
    case['seconds']=time.time()-t;report['cases'][name]=case;print(name,case['status'],'PROFILE',case.get('elementary_divisor_multiplicities'),'ORDER',case.get('order'),'SECONDS',case['seconds'],flush=True)
report['input_sha256']={str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in paths};report['seconds']=time.time()-start
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('TOTAL',report['seconds'],flush=True)

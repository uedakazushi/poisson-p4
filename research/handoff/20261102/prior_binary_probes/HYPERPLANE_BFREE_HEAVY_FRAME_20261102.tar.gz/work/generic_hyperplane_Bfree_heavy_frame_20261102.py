from pathlib import Path
import json,time,hashlib,sys
import sympy as s
from sympy.polys.rings import ring
start=time.time();root=Path.cwd();sys.path.insert(0,str(root/'code'))
R,a,e,d=ring('a,e,d',s.QQ);K=R.to_field();kk=lambda x:K(x);A,E,D=s.symbols('a e d')
F=500*a+90*e**2+3*e-24;B=50*a*d+18*d*e**2-9*d*e-2*d+60*e-40;C=100*a+18*e**2-9*e-2;S=3*e-2;D0=50*a+9*e**2+3*e-6
P=125*a*a*d-450*a*e-200*a-54*e**3-27*e**2+33*e+6;RR=15*a*d*e-10*a*d+200*a+18*e**2+6*e-12
assert 25*a*RR-S*P==D0*C
mpath=Path('work/generic_hyperplane_polynomial_a_elimination_20261102.json');model=json.loads(mpath.read_text());heavy=[4,12,35]
def parse(poly):return {tuple(m):K(R.from_dict({tuple(ex):s.QQ(c) for ex,c in coeff})) for m,coeff in poly}
eqs={q['original_row']:parse(q['polynomial']) for q in model['equations_sparse'] if q['weight']==2}
def add(out,m,c):
 if c:
  v=out.get(m,K.zero)+c
  if v:out[m]=v
  elif m in out:del out[m]
Q72={m:c for m,c in eqs[72].items() if len(m)==2};Q87={m:c for m,c in eqs[87].items() if len(m)==2}
y12={m:-c/eqs[72][(12,)] for m,c in Q72.items()};rhs={m:-c for m,c in Q87.items()}
for m,c in y12.items():add(rhs,m,-eqs[87][(12,)]*c)
y4={m:K(-625)*c/(K(a*D0*C)) for m,c in rhs.items()};y35={m:K(-125*S)*c/K(a*a*D0*C) for m,c in rhs.items()}
y4[(45,)]=K(P)/250;y35[(45,)]=K(RR)/50
subs={4:y4,12:y12,35:y35}
mat=s.Matrix([[eqs[72].get((j,),K.zero).as_expr() for j in heavy],[eqs[87].get((j,),K.zero).as_expr() for j in heavy],[250*S.as_expr(),0,-1250*A]])
det=s.factor(mat.det());assert R.from_expr(det)==4*a**4*F*D0*C/125
for row,q in [(72,eqs[72]),(87,eqs[87])]:
 out={}
 for m,c in q.items():
  if len(m)==1:
   for n,v in subs[m[0]].items():add(out,n,c*v)
  else:add(out,m,c)
 assert not out
lambda_check={}
for n,v in y4.items():add(lambda_check,n,250*K(S)*v)
for n,v in y35.items():add(lambda_check,n,-1250*K(a)*v)
add(lambda_check,(45,),K(D0*C));assert not lambda_check
remaining={}
for row,q in eqs.items():
 out={}
 for m,c in q.items():
  if len(m)==1:
   for n,v in subs[m[0]].items():add(out,n,c*v)
  else:add(out,m,c)
 assert all(45 not in m for m in out);remaining[row]=out
assert not remaining[72] and not remaining[87]
told=parse(model['targets_sparse'][-1]);tnew={}
for m,c in told.items():
 hs=[j for j in m if j in heavy]
 if hs:
  assert len(hs)==1;j=hs[0];rest=tuple(i for i in m if i!=j)
  for n,v in subs[j].items():add(tnew,tuple(sorted(rest+n)),c*v/K(a**model['target_a_denominators'][-1]))
 else:add(tnew,m,c/K(a**model['target_a_denominators'][-1]))
assert all(45 not in m and len(m)==3 for m in tnew)

def deninfo(polys):
 den=R.one
 for q in polys:
  for c in q.values():den=den.lcm(c.denom)
 return s.factor(den.as_expr())
print('HEAVY',det,'subsden',deninfo(subs.values()),'tden',deninfo([tnew]),flush=True)
# Independent direct modification of the frozen right inverse; no raw quartic expansion.
cpath=Path('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json');chart=json.loads(cpath.read_text());U=[[K.from_expr(s.sympify(v)) for v in row] for row in chart['U34']]
k=[K.from_expr(s.sympify(row[chart['normal34'][5]]))*K(B)/50 for row in chart['T34']]
assert [k[i] for i in heavy]==[K(P)/250,K.zero,K(RR)/50]
lamk=250*K(S)*k[4]-1250*K(a)*k[35];assert lamk==-K(D0*C)
lamU=[250*K(S)*U[4][j]-1250*K(a)*U[35][j] for j in range(34)]
Un=[[U[i][j]-k[i]*lamU[j]/lamk for j in range(34)] for i in range(45)]
assert all(250*K(S)*Un[4][j]-1250*K(a)*Un[35][j]==0 for j in range(34))
assert all(c.denom.degree(d)==0 for row in Un for c in row)
uden=deninfo([{(j,):v for j,v in enumerate(row) if v} for row in Un])
print('UNEW_DEN',uden,flush=True)
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
old=json.loads(Path('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json').read_text())['linear'];fixed=old['fixed'];cols=old['cols'];m=S61();beta={int(key[1:])-1:s.sympify(v) for key,v in chart['beta'].items()};two,eqall=specialize(m,beta,True)
J=[{} for _ in range(135)]
for i,eq in enumerate(eqall):
 for mon,c in eq.items():
  c=K.from_expr(s.sympify(c))
  if len(mon)==2:
   x,y=mon
   if x!=fixed and y==fixed:j=cols.index(x);J[i][j]=J[i].get(j,K.zero)+c
   if y!=fixed and x==fixed:j=cols.index(y);J[i][j]=J[i].get(j,K.zero)+c
  elif len(mon)==1 and mon[0]==fixed:J[i][44]=J[i].get(44,K.zero)+c
assert all(sum((c*k[j] for j,c in row.items()),K.zero)==0 for row in J)
for ii,i in enumerate(chart['selected34_rows']):
 for j in range(34):assert sum((c*Un[z][j] for z,c in J[i].items()),K.zero)==int(ii==j)
# The old light coordinate projectors continue to annihilate the correction k.
W=s.Matrix(old['chart_basis']);Wi=W.inv();light=[0,1,2,3,4,6,7]
for j in light:
 row=Wi[chart['free34'][chart['normal34'][j]],:]
 assert sum((K.from_expr(row[i])*k[i] for i in range(45) if row[i]),K.zero)==0
serialize=lambda q:[[list(m),str(c.as_expr())] for m,c in sorted(q.items())]
paths=[Path(__file__),mpath,cpath,Path('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json'),Path('code/s61_model.py'),Path('code/s61_flag_transverse_obstruction_20261101.py'),Path('reports/S61_UNIVERSAL_WEIGHT6_20261031.json')]
report=dict(scope='Exact candidate B-free frame on a*F*D0*C nonzero. New D0 localization is explicit. No all-core rank or ambient nilpotence assertion.',all_checks_passed=True,heavy_variables=heavy,new_heavy_index=45,lambda_row=[str((250*S).as_expr()),'0',str((-1250*a).as_expr())],kernel_heavy_entries=[str(k[i].as_expr()) for i in heavy],lambda_kernel=str(lamk.as_expr()),matrix=[[str(v) for v in mat.row(i)] for i in range(3)],determinant=str(det),substitution_common_denominator=str(deninfo(subs.values())),substitution={str(j):serialize(q) for j,q in subs.items()},quadratic_residuals={str(i):serialize(q) for i,q in remaining.items()},all_eight_no_heavy=True,t_is_pure_cubic=True,t_common_denominator=str(deninfo([tnew])),t_terms=serialize(tnew),right_inverse_common_denominator=str(uden),right_inverse=[[str(c.as_expr()) for c in row] for row in Un],right_inverse_B_cancellation=True,raw135_Jkernel_checked=True,selected_J_right_inverse_checked=True,old_light_projectors_killed=True,source_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,separators=(',',':'))+'\n');print('PASS',report['seconds'],flush=True)

from pathlib import Path
import json,functools,time,sys
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();p=32003
@functools.lru_cache(maxsize=None)
def mod(c):
 if '/' in c:
  n,d=map(int,c.split('/'));assert d%p;return n%p*pow(d%p,-1,p)%p
 return int(c)%p
src=Path('/tmp/hyperplane-full-cubic-schur36-input.txt');A=[]
with src.open() as f:
 nr,nc,k=map(int,f.readline().split());assert (nr,nc,k)==(42,70,36)
 for i in range(nr):
  row=[]
  for j in range(nc):
   z=f.readline().split();n=int(z[0]);poly=[(tuple(map(int,z[2+4*t:5+4*t])),mod(z[1+4*t])) for t in range(n)];row.append([(m,c) for m,c in poly if c])
  A.append(row)

lines=iter(Path('/tmp/generic-hyperplane-full36-small-factors-20261102.out').read_text().splitlines());factors=[]
for head in lines:
 h=head.split();assert h[0]=='HIT' and h[-1]=='1'
 z=next(lines).split();assert z[:2]==['EXP','1'];nt=int(z[2]);assert len(z)==3+nt*4
 poly=[(tuple(map(int,z[4+4*i:7+4*i])),int(z[3+4*i])) for i in range(nt)]
 factors.append(poly)
maxex=[max(m[j] for row in A for poly in row for m,c in poly) for j in range(3)]
flat=[];dest=[]
for i,row in enumerate(A):
 for j,poly in enumerate(row):
  for m,c in poly:flat.append([*m,c]);dest.append(i*nc+j)
flat=np.array(flat,dtype=np.int64);dest=np.array(dest,dtype=np.int64)
def value_matrix(vals):
 powers=[[pow(x,i,p) for i in range(maxex[j]+1)] for j,x in enumerate(vals)]
 z=flat[:,3].copy()
 for j in range(3):z=z*np.array(powers[j],dtype=np.int64)[flat[:,j]]%p
 ans=np.zeros(nr*nc,dtype=np.int64);np.add.at(ans,dest,z);return (ans%p).reshape(nr,nc)
avec=np.arange(p,dtype=np.int64);rng=np.random.default_rng(10720261102);res=[]
for fi,poly in enumerate(factors):
 attempts=[];witness=None
 for t in range(20):
  e,d=([2,3] if t==0 else rng.integers(1,p,size=2).tolist());degree=max(m[0] for m,c in poly);co=[0]*(degree+1)
  for m,c in poly:co[m[0]]=(co[m[0]]+c*pow(e,m[1],p)*pow(d,m[2],p))%p
  z=np.zeros(p,dtype=np.int64)
  for c in reversed(co):z=(z*avec+c)%p
  roots=np.flatnonzero(z==0)
  for a in roots:
   a=int(a);F=(500*a+90*e*e+3*e-24)%p;B=(50*a*d+18*d*e*e-9*d*e-2*d+60*e-40)%p;C=(100*a+18*e*e-9*e-2)%p
   if not a*F*B*C%p:continue
   assert sum(c*pow(a,m[0],p)*pow(e,m[1],p)*pow(d,m[2],p) for m,c in poly)%p==0
   M=value_matrix([a,e,d]);rank,cols=elimination_rank(M,p);attempts.append(dict(point=[a,e,d],rank=rank));print('TRY',fi,[a,e,d],rank,flush=True)
   if rank==36:
    _,rows=elimination_rank(M[:,cols].T,p);det=determinant_mod(M[np.ix_(rows,cols)],p);assert det
    witness=dict(point=[a,e,d],rows=rows,columns=cols,determinant=det,known_unit_values=[a,F,B,C]);break
  if witness:break
 res.append(dict(factor_index=fi,terms=len(poly),witness=witness,attempts=attempts))
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(prime=p,shape=[nr,nc],factors=res,seconds=time.time()-start),indent=2)+'\n')
print('SUMMARY',[(r['factor_index'],r['witness'] is not None,len(r['attempts'])) for r in res],time.time()-start,flush=True)

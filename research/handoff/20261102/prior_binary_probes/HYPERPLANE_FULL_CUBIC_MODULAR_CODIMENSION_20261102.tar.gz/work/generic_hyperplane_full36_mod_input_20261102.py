from pathlib import Path
import json,functools,time,sys
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();p=32003
@functools.lru_cache(maxsize=None)
def mod(c):
 if '/' in c:
  n,d=map(int,c.split('/'));assert d%p;return n%p*pow(d%p,-1,p)%p
 return int(c)%p
src=Path('/tmp/hyperplane-full-cubic-schur36-input.txt');A=[]
with src.open() as f:
 nr,nc,k=map(int,f.readline().split());assert (nr,nc,k)==(42,70,36)
 for i in range(nr):
  row=[]
  for j in range(nc):
   z=f.readline().split();n=int(z[0]);poly=[(tuple(map(int,z[2+4*t:5+4*t])),mod(z[1+4*t])) for t in range(n)];row.append([(m,c) for m,c in poly if c])
  A.append(row)
M=np.array([[sum(c*pow(2,m[1],p)*pow(3,m[2],p) for m,c in poly)%p for poly in row] for row in A],dtype=np.int64)
rank,_=elimination_rank(M,p);assert rank==36
rng=np.random.default_rng(20261102);choices=[]
for t in range(2):
 ro=list(range(nr)) if t==0 else rng.permutation(nr).tolist();co=list(range(nc)) if t==0 else rng.permutation(nc).tolist()
 rank,rows=elimination_rank(M[np.ix_(ro,co)].T,p);rr=[ro[i] for i in rows]
 rank,cols=elimination_rank(M[np.ix_(rr,co)],p);cc=[co[j] for j in cols]
 det=determinant_mod(M[np.ix_(rr,cc)],p);assert rank==36 and det
 choices.append(dict(rows=rr,columns=cc,determinant_at_1_2_3=det))
assert choices[0]['rows']!=choices[1]['rows'] or choices[0]['columns']!=choices[1]['columns']
with Path('/tmp/generic-hyperplane-full36-mod-20261102.in').open('w') as f:
 f.write(f'{nr} {nc} {k} {p}\n')
 for row in A:
  for poly in row:f.write(str(len(poly))+''.join(' '+str(c)+' '+' '.join(map(str,m)) for m,c in poly)+'\n')
 f.write('2\n')
 for c in choices:f.write(' '.join(map(str,c['rows']+c['columns']))+'\n')
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(prime=p,point=[1,2,3],shape=[nr,nc],rank=rank,choices=choices,nonzero_entries=sum(bool(poly) for row in A for poly in row),terms=sum(len(poly) for row in A for poly in row),seconds=time.time()-start),indent=2)+'\n')
print('READY',time.time()-start,'dets',[c['determinant_at_1_2_3'] for c in choices],flush=True)

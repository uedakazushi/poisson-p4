from pathlib import Path
import json,math,hashlib
p=32003;src=Path('/tmp/generic-hyperplane-full36-adjacent-det-20261102.out');lines=iter(src.read_text().splitlines());h=next(lines).split();assert h[:2]==['MINOR','0'];nf=int(h[3]);factors=[]
for k in range(nf):
 z=next(lines).split();assert z[0]=='EXP';n=int(z[1]);assert n>0
 z=next(lines).split();nt=int(z[0]);assert len(z)==1+4*nt
 poly=[(tuple(map(int,z[2+4*i:5+4*i])),int(z[1+4*i])) for i in range(nt)]
 lead=max(poly,key=lambda z:(z[0][2],z[0][1],z[0][0]));val=sum(c*pow(2,m[1],p)*pow(3,m[2],p) for m,c in poly)%p
 assert val
 factors.append(dict(exponent=n,terms=nt,total_degree=max(sum(m) for m,c in poly),individual_degrees=[max(m[j] for m,c in poly) for j in range(3)],leading_d_e_a=[list(lead[0]),lead[1]],value_1_2_3=val,polynomial=[[list(m),c] for m,c in poly]))
meta=json.loads(Path('work/generic_hyperplane_full36_adjacent_input_20261102.json').read_text());value=1
for f in factors:value=value*pow(f['value_1_2_3'],f['exponent'],p)%p
scalar=meta['choice']['determinant_at_1_2_3']*pow(value,-1,p)%p
lc=scalar;mon=[0,0,0]
for f in factors:
 lc=lc*pow(f['leading_d_e_a'][1],f['exponent'],p)%p
 mon=[a+f['exponent']*b for a,b in zip(mon,f['leading_d_e_a'][0])]
out=dict(prime=p,minor=meta['choice'],factor_count=nf,factors=factors,constant_scalar_modp=scalar,leading_monomial_order='lex d,e,a',leading_exponents_a_e_d=mon,leading_coefficient_modp=lc,degree_a_e_d=[sum(f['exponent']*f['individual_degrees'][j] for f in factors) for j in range(3)],total_degree=sum(f['exponent']*f['total_degree'] for f in factors),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest())
Path(__file__).with_suffix('.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
print({k:out[k] for k in out if k not in ['factors','minor']})
print('factors',[(f['exponent'],f['terms'],f['individual_degrees']) for f in factors])

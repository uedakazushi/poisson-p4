from pathlib import Path
import json,functools,time,sys
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();p=32003
@functools.lru_cache(maxsize=None)
def mod(c):
 if '/' in c:
  n,d=map(int,c.split('/'));assert d%p;return n%p*pow(d%p,-1,p)%p
 return int(c)%p
src=Path('/tmp/hyperplane-full-cubic-schur36-input.txt');A=[]
with src.open() as f:
 nr,nc,k=map(int,f.readline().split());assert (nr,nc,k)==(42,70,36)
 for i in range(nr):
  row=[]
  for j in range(nc):
   z=f.readline().split();n=int(z[0]);poly=[(tuple(map(int,z[2+4*t:5+4*t])),mod(z[1+4*t])) for t in range(n)];row.append([(m,c) for m,c in poly if c])
  A.append(row)
M=np.array([[sum(c*pow(2,m[1],p)*pow(3,m[2],p) for m,c in poly)%p for poly in row] for row in A],dtype=np.int64)
rank,_=elimination_rank(M,p);assert rank==36

old=json.loads(Path('work/generic_hyperplane_full36_mod_input_20261102.json').read_text())['choices'][0];rr=old['rows'];cc=old['columns']
counts=np.array([[len(q) for q in row] for row in A]); candidates=[]
for ir in range(36):
 for r in set(range(nr))-set(rr):
  rs=rr.copy();rs[ir]=r
  for ic in range(36):
   for c in set(range(nc))-set(cc):
    cost=int(counts[np.ix_(rs,cc)].sum()-counts[rs,cc[ic]].sum()+counts[rs,c].sum())
    candidates.append((cost,ir,r,ic,c))
candidates.sort();choice=None
for cost,ir,r,ic,c in candidates:
 rs=rr.copy();cs=cc.copy();rs[ir]=r;cs[ic]=c
 try:det=determinant_mod(M[np.ix_(rs,cs)],p)
 except AssertionError:continue
 if det:
  choice=dict(rows=rs,columns=cs,determinant_at_1_2_3=det,terms=cost,change=[ir,r,ic,c]);break
assert choice
out=Path('/tmp/generic-hyperplane-full36-adjacent-20261102.in')
with out.open('w') as f:
 f.write(f'{nr} {nc} {k} {p}\n')
 for row in A:
  for poly in row:f.write(str(len(poly))+''.join(' '+str(c)+' '+' '.join(map(str,m)) for m,c in poly)+'\n')
 f.write('1\n'+' '.join(map(str,choice['rows']+choice['columns']))+'\n')
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(prime=p,choice=choice,seconds=time.time()-start),indent=2)+'\n')
print(choice,flush=True)

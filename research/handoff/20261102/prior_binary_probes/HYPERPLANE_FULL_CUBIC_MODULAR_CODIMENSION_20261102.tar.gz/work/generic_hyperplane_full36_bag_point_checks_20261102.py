from pathlib import Path
import json,functools,time,sys
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();p=32003
@functools.lru_cache(maxsize=None)
def mod(c):
 if '/' in c:
  n,d=map(int,c.split('/'));assert d%p;return n%p*pow(d%p,-1,p)%p
 return int(c)%p
src=Path('/tmp/hyperplane-full-cubic-schur36-input.txt');A=[]
with src.open() as f:
 nr,nc,k=map(int,f.readline().split());assert (nr,nc,k)==(42,70,36)
 for i in range(nr):
  row=[]
  for j in range(nc):
   z=f.readline().split();n=int(z[0]);poly=[(tuple(map(int,z[2+4*t:5+4*t])),mod(z[1+4*t])) for t in range(n)];row.append([(m,c) for m,c in poly if c])
  A.append(row)

lines=iter(Path('/tmp/generic-hyperplane-full36-small-factors-20261102.out').read_text().splitlines());factors=[]
for head in lines:
 h=head.split();assert h[0]=='HIT' and h[-1]=='1'
 z=next(lines).split();assert z[:2]==['EXP','1'];nt=int(z[2]);assert len(z)==3+nt*4
 poly=[(tuple(map(int,z[4+4*i:7+4*i])),int(z[3+4*i])) for i in range(nt)]
 factors.append(poly)
maxex=[max(m[j] for row in A for poly in row for m,c in poly) for j in range(3)]
flat=[];dest=[]
for i,row in enumerate(A):
 for j,poly in enumerate(row):
  for m,c in poly:flat.append([*m,c]);dest.append(i*nc+j)
flat=np.array(flat,dtype=np.int64);dest=np.array(dest,dtype=np.int64)
def value_matrix(vals):
 powers=[[pow(x,i,p) for i in range(maxex[j]+1)] for j,x in enumerate(vals)]
 z=flat[:,3].copy()
 for j in range(3):z=z*np.array(powers[j],dtype=np.int64)[flat[:,j]]%p
 ans=np.zeros(nr*nc,dtype=np.int64);np.add.at(ans,dest,z);return (ans%p).reshape(nr,nc)

checks=[]
for stem in ['first','adjacent']:
 b=json.loads(Path('work/generic_hyperplane_full36_'+stem+'_bag_20261102.json').read_text()); rows=b['minor']['rows'];cols=b['minor']['columns']
 for vals in [[2,3,4],[3,5,7],[11,13,17]]:
  M=value_matrix(vals)
  try:det=determinant_mod(M[np.ix_(rows,cols)],p)
  except AssertionError:det=0
  pred=b['constant_scalar_modp']
  for f in b['factors']:
   val=sum(c*pow(vals[0],m[0],p)*pow(vals[1],m[1],p)*pow(vals[2],m[2],p) for m,c in f['polynomial'])%p
   pred=pred*pow(val,f['exponent'],p)%p
  assert pred==det;checks.append(dict(minor=stem,point=vals,determinant=det));print(stem,vals,det,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(prime=p,checks=checks,seconds=time.time()-start),indent=2)+'\n')

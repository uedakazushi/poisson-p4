from pathlib import Path
import json,time,subprocess,os,hashlib
start=time.time();root=Path.cwd();env=os.environ.copy();env['DYLD_LIBRARY_PATH']=str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'
cmd=['/tmp/generic-hyperplane-full36-mod-determinants-20261102','/tmp/generic-hyperplane-full36-mod-20261102.in','/tmp/generic-hyperplane-full36-mod-determinants-20261102.out']
with Path('work/generic_hyperplane_full36_mod_determinants_20261102.log').open('w') as f:
 try:r=subprocess.run(cmd,env=env,stdout=f,stderr=f,timeout=180);result=dict(returncode=r.returncode)
 except subprocess.TimeoutExpired:result=dict(timeout_seconds=180)
paths=[Path('work/generic_hyperplane_full36_mod_determinants_20261102.cpp'),Path('work/generic_hyperplane_full36_mod_input_20261102.json'),Path('/tmp/generic-hyperplane-full36-mod-20261102.in')]
result.update(seconds=time.time()-start,command=cmd,input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},log=Path('work/generic_hyperplane_full36_mod_determinants_20261102.log').read_text());Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='log'},flush=True)

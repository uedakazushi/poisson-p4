from pathlib import Path
import json,hashlib,time
start=time.time();selpath=Path('/tmp/hyperplane-Bfree-t-targets-minor-20261102.out');lines=selpath.read_text().splitlines();n=int(lines[0].split()[1]);selected=list(map(int,lines[1].split()));assert n==len(selected)==238 and lines[2].startswith('DET_DEG 225 ')
exact=Path('/tmp/hyperplane-Bfree-t-targets-exact-core-20261102.in');degree=[None]*n;where={r:i for i,r in enumerate(selected)}
with exact.open() as f:
 nr,nc,ns=map(int,f.readline().split());assert (nr,nc,ns)==(328,238,321)
 for i in range(nr):
  row=[]
  for j in range(nc):
   line=f.readline()
   if i not in where:continue
   z=line.split();ct=int(z[0]);assert len(z)==1+4*ct;row.append(max((int(z[4+4*k]) for k in range(ct)),default=-100000))
  if i in where:degree[where[i]]=row
 assert not f.read().strip()
uni=Path('/tmp/hyperplane-Bfree-t-targets-univariate-20261102.in');it=iter(map(int,uni.read_text().split()));p,nr,nc,nt=[next(it) for _ in range(4)];B=[next(it),next(it)];rows=[]
for i in range(nr+nt):
 row=[[] for _ in range(nc)]
 for _ in range(next(it)):
  j,l=next(it),next(it);row[j]=[next(it) for _ in range(l)]
 if i<nr:rows.append(row)
assert next(it,None) is None
out=Path('/tmp/generic-Bfree-minor-infinity-20261102.in')
with out.open('w') as f:
 f.write(f'{p} {n} 32 225\n')
 for r,i in enumerate(selected):
  f.write(' '.join(map(str,degree[r]))+'\n')
  for j,poly in enumerate(rows[i]):
   while poly and not poly[-1]:poly.pop()
   assert len(poly)-1<=degree[r][j] or not poly
   f.write(str(len(poly))+(' '+' '.join(map(str,poly)) if poly else '')+'\n')
rep=dict(scope='Bounded finite-field infinity profile input; generic entry degrees from the supplied QQ coefficient matrix only, no QQ determinant or kernel theorem.',selected_rows=selected,prime=p,n=n,precision=32,known_modular_degree=225,input=str(out),input_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),input_sources_sha256={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),selpath,exact,uni]},seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(rep,indent=2)+'\n');print(json.dumps({k:rep[k] for k in ['n','precision','known_modular_degree','seconds']},indent=2))

#include <flint/nmod_poly.h>
#include <flint/nmod_mat.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <cassert>
#include <chrono>
#include <climits>
#include <algorithm>
using namespace std;
ulong prime;
struct Poly {
 nmod_poly_struct p[1];
 Poly(){nmod_poly_init(p,prime);} Poly(const Poly&a):Poly(){nmod_poly_set(p,a.p);}
 Poly(Poly&&a):Poly(){nmod_poly_swap(p,a.p);} Poly&operator=(Poly a){nmod_poly_swap(p,a.p);return *this;}
 ~Poly(){nmod_poly_clear(p);}
};
int main(int argc,char**argv){
 assert(argc==3);ifstream in(argv[1]);ofstream out(argv[2]);assert(in&&out);
 int nr,nc,limit;in>>prime>>nr>>nc>>limit;assert(nr>=nc&&limit>0);
 vector<vector<Poly>>M(nr,vector<Poly>(nc));
 for(auto&row:M)for(auto&z:row){int n;in>>n;assert(n<=limit+1);for(int k=0;k<n;k++){ulong c;in>>c;assert(c<prime);nmod_poly_set_coeff_ui(z.p,k,c);}}
 assert(in);string extra;assert(!(in>>extra));
 auto start=chrono::steady_clock::now();auto sec=[&](){return chrono::duration<double>(chrono::steady_clock::now()-start).count();};
 int prec=limit+1,stage=0;long valuation=0;bool complete=false,timed=false;Poly inv,tmp;
 vector<int>rl(nr),cl(nc);for(int i=0;i<nr;i++)rl[i]=i;for(int j=0;j<nc;j++)cl[j]=j;
 while(nc){
  nmod_mat_t lead;nmod_mat_init(lead,nr,nc,prime);
  for(int i=0;i<nr;i++)for(int j=0;j<nc;j++)nmod_mat_entry(lead,i,j)=nmod_poly_get_coeff_ui(M[i][j].p,0);
  int rank=nmod_mat_rank(lead);nmod_mat_clear(lead);
  out<<"STAGE "<<stage<<" ROWS "<<nr<<" COLS "<<nc<<" RANK "<<rank<<" PRECISION "<<prec<<" VALUATION "<<valuation<<" SECONDS "<<sec()<<'\n';out.flush();assert(out.good());
  cerr<<"STAGE "<<stage<<" SHAPE "<<nr<<'x'<<nc<<" RANK "<<rank<<" SEC "<<sec()<<'\n';
  // Also perform the last full-rank stage, recording all unit pivots.
  for(int r=0;r<rank;r++){
   vector<int>rc(nr),cc(nc);
   for(int i=r;i<nr;i++)for(int j=r;j<nc;j++)if(!nmod_poly_is_zero(M[i][j].p)){rc[i]++;cc[j]++;}
   int bi=-1,bj=-1,score=INT_MAX;
   for(int i=r;i<nr;i++)for(int j=r;j<nc;j++)if(nmod_poly_get_coeff_ui(M[i][j].p,0)){
    int z=(rc[i]-1)*(cc[j]-1);if(z<score){score=z;bi=i;bj=j;}
   }
   assert(bi>=0);ulong unit=nmod_poly_get_coeff_ui(M[bi][bj].p,0);
   out<<"PIVOT "<<stage<<' '<<r<<' '<<bi<<' '<<bj<<' '<<rl[bi]<<' '<<cl[bj]<<' '<<unit<<'\n';
   swap(M[r],M[bi]);swap(rl[r],rl[bi]);
   for(auto&row:M)nmod_poly_swap(row[r].p,row[bj].p);swap(cl[r],cl[bj]);
   nmod_poly_inv_series(inv.p,M[r][r].p,prec);
   for(int j=r;j<nc;j++){nmod_poly_mullow(tmp.p,M[r][j].p,inv.p,prec);nmod_poly_swap(tmp.p,M[r][j].p);}
   for(int i=r+1;i<nr;i++)if(!nmod_poly_is_zero(M[i][r].p)){
    Poly f=M[i][r];for(int j=r+1;j<nc;j++)if(!nmod_poly_is_zero(M[r][j].p)){
     nmod_poly_mullow(tmp.p,f.p,M[r][j].p,prec);nmod_poly_sub(M[i][j].p,M[i][j].p,tmp.p);
    }nmod_poly_zero(M[i][r].p);
   }
   if(sec()>18){timed=true;out<<"STOP_TIME "<<stage<<' '<<r+1<<'\n';break;}
  }
  if(timed)break;
  if(rank==nc){complete=true;break;}
  int nextrows=nr-rank,nextcols=nc-rank;vector<vector<Poly>>next(nextrows,vector<Poly>(nextcols));
  for(int i=0;i<nextrows;i++)for(int j=0;j<nextcols;j++){
   assert(!nmod_poly_get_coeff_ui(M[rank+i][rank+j].p,0));
   nmod_poly_shift_right(next[i][j].p,M[rank+i][rank+j].p,1);
  }
  valuation+=nextcols;prec--;stage++;M=move(next);rl.erase(rl.begin(),rl.begin()+rank);cl.erase(cl.begin(),cl.begin()+rank);nr=nextrows;nc=nextcols;
  if(prec<=0){out<<"STOP_PRECISION\n";break;}
 }
 out<<"RESULT COMPLETE "<<complete<<" TIMEOUT "<<timed<<" VALUATION "<<valuation<<" SECONDS "<<sec()<<'\n';out.flush();assert(out.good());
}

from pathlib import Path
from fractions import Fraction
import functools,json,hashlib,time,os,subprocess,math

start=time.time();p=32003;n=238;root=Path.cwd();profile_path=Path('work/generic_Bfree_vertical_a_infinity_20261102.json');profile=json.loads(profile_path.read_text());rows=profile['selected_original_rows'];rowset=set(rows)
prior_path=Path('work/generic_Bfree_vertical_knownroot_profiles_20261102.json');prior=json.loads(prior_path.read_text());core=Path('/tmp/hyperplane-Bfree-t-targets-exact-core-20261102.in');points=[3,5];mat={e:{}for e in points};count=0
@functools.lru_cache(None)
def residue(s):
    q=Fraction(s);assert q.denominator%p;return q.numerator*pow(q.denominator,-1,p)%p
with core.open()as f:
    assert list(map(int,f.readline().split()))==[328,238,321]
    for i in range(328):
        if i in rowset:
            for e in points:mat[e][i]={}
        for j in range(n):
            z=f.readline().split()
            if i not in rowset:continue
            nt=int(z[0]);assert len(z)==1+4*nt;vals={e:{}for e in points}
            for k in range(nt):
                c=residue(z[1+4*k]);aa,ee,dd=map(int,z[2+4*k:5+4*k]);c=c*pow(3,dd,p)%p;count+=1
                for e in points:vals[e][aa]=(vals[e].get(aa,0)+c*pow(e,ee,p))%p
            for e in points:
                v={k:c for k,c in vals[e].items()if c}
                if v:mat[e][i][j]=[v.get(k,0)for k in range(max(v)+1)]
    assert not f.read().strip()
cpp=Path('work/generic_Bfree_vertical_knownroot_profile_20261102.cpp');exe=Path('/tmp/generic-Bfree-e35-knownroot-profile-20261102')
subprocess.run(['clang++','-O3','-std=c++17','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(cpp),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=20)
env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'};paths=[Path(__file__),cpp,profile_path,prior_path,core];report={'scope':'Finite-field comparison only, same original238 rows at d=3 and e=3,5. No QQ root-order theorem.','prime':p,'d':3,'selected_original_rows':rows,'selected_core_terms_checked':count,'cases':{}}
def ev(co,x):
    y=0
    for c in reversed(co):y=(y*x+c)%p
    return y
for e in points:
    cases=[('a',1,0),('F',500,90*e*e+3*e-24),('D0',50,9*e*e+3*e-6),('C',100,18*e*e-9*e-2)]
    for name,alpha,b in cases:
        if time.time()-start>40:raise RuntimeError('whole60s preparation guard')
        t=time.time();ia=pow(alpha,-1,p);a0=-b*ia%p;base=Path(f'/tmp/generic-Bfree-e{e}-root-{name}-20261102');inp=base.with_suffix('.in');out=base.with_suffix('.out');log=base.with_suffix('.log')
        with inp.open('w')as f:
            f.write(f'{p} {n} {n} 32\n')
            for i in rows:
                for j in range(n):
                    co=mat[e][i].get(j,[]);z=[sum(co[k]*math.comb(k,l)*pow(a0,k-l,p)for k in range(l,len(co)))*pow(ia,l,p)%p for l in range(len(co))]
                    while z and not z[-1]:z.pop()
                    for x in [1,7]:assert ev(z,x)==ev(co,(x-b)*ia%p)
                    f.write(str(len(z))+(' '+' '.join(map(str,z))if z else '')+'\n')
        cp=subprocess.run([str(exe),str(inp),str(out)],env=env,capture_output=True,text=True,timeout=min(20,60-(time.time()-start)));log.write_text(cp.stdout+cp.stderr);cp.check_returncode();stages=[];last=None;res={}
        for ln in out.read_text().splitlines():
            z=ln.split()
            if z[0]=='STAGE':
                v={z[k]:z[k+1]for k in range(0,len(z),2)};last={k.lower():float(t)if k=='SECONDS'else int(t)for k,t in v.items()};last['pivots']=[];stages.append(last)
            elif z[0]=='PIVOT':v=list(map(int,z[1:]));assert v[0]==last['stage'];last['pivots'].append(v[1:])
            elif z[0]=='RESULT':res={z[k]:z[k+1]for k in range(1,len(z),2)}
            else:raise AssertionError(ln)
        assert res['COMPLETE']=='1';order=int(res['VALUATION']);ranks=[q['rank']for q in stages];old=prior['cases'][name]
        c={'e':e,'factor':name,'alpha':alpha,'beta':b,'root_modp':a0,'factor_equals_delta':True,'order':order,'first_corank':n-ranks[0],'maximum_chain_depth':max(q['stage']for q in stages if q['rank']),'ranks':ranks,'matches_e2_order':order==old['order'],'matches_e2_full_profile':ranks==[q['rank']for q in old['stages']],'stages':stages,'seconds':time.time()-t};report['cases'][f'{e}:{name}']=c;paths.extend([inp,out,log]);print(e,name,'ORDER',order,'RANKS',ranks,'MATCH_E2',c['matches_e2_full_profile'],flush=True)
report['all_orders_and_profiles_equal_e2']=all(q['matches_e2_full_profile']for q in report['cases'].values());report['input_sha256']={str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in paths};report['seconds']=time.time()-start
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('TOTAL',report['seconds'],flush=True)

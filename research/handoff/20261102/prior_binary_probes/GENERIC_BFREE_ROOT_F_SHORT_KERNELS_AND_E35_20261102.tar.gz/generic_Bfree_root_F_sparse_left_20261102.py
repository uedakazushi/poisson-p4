from pathlib import Path
from fractions import Fraction
from collections import Counter
import json,hashlib,os,subprocess,sys,time
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod

start=time.time();p=32003;n=238;wd=Path('/tmp/generic-Bfree-root-F-sparse-left-20261102');wd.mkdir(exist_ok=True)
lead=Path('/tmp/binary-Bfree-root-20261102-F.leading');ls=lead.read_text().splitlines();assert ls[0]=='238 238';lines=ls[1:];assert len(lines)==n*n
def readpoly(line):
    z=line.split();nn=int(z[0]);assert len(z)==1+3*nn;q={}
    for k in range(nn):
        c=Fraction(z[1+3*k]);xx,e=map(int,z[2+3*k:4+3*k]);assert xx==0 and c.denominator%p;q[e]=c
    return q
def ev(q):return sum(c.numerator*pow(c.denominator,-1,p)*pow(2,e,p)for e,c in q.items())%p
A=np.array([ev(readpoly(z))for z in lines],dtype=np.int64).reshape(n,n).T
R=A.copy();piv=[]
for col in range(n):
    r=len(piv);found=np.flatnonzero(R[r:,col])
    if not len(found):continue
    i=r+int(found[0]);R[[r,i]]=R[[i,r]];R[r]=R[r]*pow(int(R[r,col]),-1,p)%p
    ids=np.flatnonzero(R[:,col]);ids=ids[ids!=r]
    R[ids]=(R[ids]-R[ids,col,None]*R[r,None,:])%p;piv.append(col)
assert len(piv)==169 and not np.any(R[169:]);anchors=[j for j in range(n)if j not in piv];assert len(anchors)==69
_,pivotrows=elimination_rank(A[:,piv].T,p);fullminor=int(determinant_mod(A[np.ix_(pivotrows,piv)],p));assert fullminor
candidates=[]
for anchor in anchors:
    v=np.zeros(n,dtype=np.int64);v[anchor]=1;v[piv]=-R[:169,anchor]%p;assert not np.any(A@v%p)
    candidates.append((anchor,v.tolist()))
modpath=wd/'modular_candidates';modpath.write_text(f'{n} {n} 169 69\n'+''.join(str(a)+' '+' '.join(map(str,v))+'\n'for a,v in candidates))
candidates.sort(key=lambda z:(sum(c!=0 for c in z[1]),z[0]));hist=Counter(sum(c!=0 for c in v)for a,v in candidates)
print('SUPPORTS',dict(sorted(hist.items())),'PREP',time.time()-start,flush=True)
native=Path('code/s61_binary_hyperplane_leading_kernel_20261102.cpp');header=Path('code/s61_binary_deeper_cubic_field_20261101.hpp');exe=wd/'native'
subprocess.run(['clang++','-O3','-std=c++17','-Icode','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(native),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=20)
env=os.environ|{'DYLD_LIBRARY_PATH':str(Path.cwd()/'work/m2-runtime/lib')+':/opt/homebrew/lib'};paths=[Path(__file__),lead,modpath,native,header];cert=[];allgood=True
for idx,(anchor,v)in enumerate(candidates):
    if time.time()-start>=58:
        allgood=False;cert.append({'index':idx,'status':'not_started_total60s'});break
    support=[j for j,c in enumerate(v)if c];assert v[anchor]==1 and all(not v[j]for j in anchors if j!=anchor)
    unknown=[j for j in support if j!=anchor];order=unknown+[anchor];B=A[:,order];r=len(unknown)
    if r:
        rank,cols=elimination_rank(B[:,:-1],p);assert rank==r;_,rows=elimination_rank(B[:,:-1].T,p);minor=int(determinant_mod(B[np.ix_(rows,range(r))],p));assert minor
    else:rows=[];minor=1
    inp=wd/f'input{idx}';out=wd/f'kernel{idx}';log=wd/f'log{idx}';inp.write_text(f'{n} {len(order)} {r} 1\n'+' '.join(map(str,rows))+'\n'+' '.join(map(str,range(r)))+f'\n{r}\n'+''.join(lines[j*n+i]+'\n'for i in range(n)for j in order));paths.append(inp);t=time.time()
    try:
        cp=subprocess.run([str(exe),str(inp),str(out)],env=env,capture_output=True,text=True,timeout=min(15,60-(time.time()-start)));log.write_text(cp.stdout+cp.stderr);cp.check_returncode()
    except subprocess.TimeoutExpired as ex:
        z=(ex.stdout or b'')+(ex.stderr or b'');log.write_bytes(z if isinstance(z,bytes)else z.encode());paths.append(log);allgood=False;cert.append({'index':idx,'anchor':anchor,'support':support,'status':'bounded_timeout','seconds':time.time()-t});break
    except subprocess.CalledProcessError:
        paths.append(log);allgood=False;cert.append({'index':idx,'anchor':anchor,'support':support,'status':'native_guard'});break
    paths.extend([out,log]);o=out.read_text().splitlines();assert o[0]=='KERNEL 0';den=readpoly(o[1]);nums=[readpoly(q)for q in o[2:]];assert len(nums)==len(order)and nums[-1]==den and ev(den)
    E=np.array([ev(q)for q in nums],dtype=np.int64);assert not np.any(B@E%p);assert all(int(E[j])*pow(ev(den),-1,p)%p==v[k]for j,k in enumerate(order))
    cert.append({'index':idx,'anchor':anchor,'support':support,'output_component_order':order,'status':'exact_all238_identities_pass','seconds':time.time()-t,'pivot_minor_modp':minor,'anchor_modp':ev(den),'terms':sum(map(len,nums)),'max_e_degree':max(e for q in nums for e in q)})
    print(idx,anchor,len(support),round(time.time()-t,3),flush=True)
report={'scope':'First left kernels only of the supplied selected238-row leading matrix at F=0,d=3 overQQ(e). Supports are finite-field candidates, but every lifted kernel is verified against all238 equations overQQ. No F^70 or full vertical theorem.','all_passed':allgood and len(cert)==69,'rank':169 if allgood and len(cert)==69 else None,'kernel_support_distribution':dict(sorted(hist.items())),'full_rank_lower_minor':{'rows_in_transpose':pivotrows,'columns_in_transpose':piv,'value_modp':fullminor},'kernels':cert,'distinct_free_anchors':anchors,'independence_via_distinct_free_diagonal':allgood and len(cert)==69,'all_anchor_units_and_coefficients_p_integral':allgood and len(cert)==69,'seconds':time.time()-start,'input_sha256':{str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in paths}}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('RESULT',report['all_passed'],'SECONDS',report['seconds'],flush=True)

Bounded candidate computation; no QQ vertical exclusion is asserted.
Source is copied from original weak-Popov rowmodule helper with variable specialization swapped: exp[1] is fixed d, exp[0] is polynomial e.
The include ../code/s61_binary_deeper_quartic_field_20261101.hpp resolves when source is copied to repo/work; bundled header is unchanged.
Compile using existing FLINT headers/library and invoke INPUT d OUTPUT. d=3,4 completed in about7.43seconds each.
Full390row module, not merely a chosen269minor, is preserved by polynomial row operations and unit constant divisions.
Each resulting basis has269distinct leading positions. Its determinant gives the Fitting support of this finite-field specialized cokernel.
Both factorizations and their common monic gcd were independently checked by pure Python polynomial arithmetic.

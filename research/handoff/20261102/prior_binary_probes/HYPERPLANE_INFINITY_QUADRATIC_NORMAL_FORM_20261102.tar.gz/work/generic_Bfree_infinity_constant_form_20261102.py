import sympy as s,json,itertools,hashlib,time
from pathlib import Path
st=time.time();a,e=s.symbols('a e');x=s.symbols('x0:8');li=[0,1,2,3,4,6,7];xx=[x[i] for i in li]
source=Path('work/binary_hyperplane_Bfree_infinity_initial_forms_20261102.json');j=json.loads(source.read_text())
ids=[19,60,84,114,117,133];q={r['source']:s.Poly(sum(s.sympify(c)*s.prod(x[i]**b for i,b in enumerate(m)) for m,c in r['terms']),*xx).as_expr() for r in j['rows'] if r['weight']==2}
L=10*a*x[2]-15*a*x[3]+(12*e+2)*x[1]+90*x[4]-90*x[6]+30*x[7]
U=a*x[0]+28*a*x[4]+28*a*x[6]-28*a*x[7]-6*e*x[6]+6*e*x[7]+3*x[4]-4*x[6]+2*x[7]
W=-15*e*x[2]-12*e*x[3]+5*x[0]-15*x[1]+3*x[3]-5*x[4]-5*x[6]+75*x[7]
p=2*x[2]+x[3]
Q=-40*a*x[2]+60*a*x[3]-48*e*x[1]+45*x[0]-8*x[1]-270*x[2]-135*x[3]+720*x[6]+420*x[7]
Z=Q/27+5*e*p+2*W/3
V=15*U+2*a*W-8*a*Z-(s.Rational(32,27)*a+3*e)*L
C=s.expand((-4*L+18*W-27*Z)/18);P=s.Rational(15,2)*p;E=s.expand(3*V/(16*a))
f=[L,W,C,P,E];ys=s.symbols('L W C P E r s');can=[ys[0]**2,ys[0]*ys[1],ys[0]*(ys[4]-ys[2]),ys[1]**2-ys[1]*ys[2]-ys[0]*ys[3],ys[3]*ys[4],ys[4]*ys[2]]
g=[s.expand(t.subs(dict(zip(ys[:5],f)),simultaneous=True)) for t in can]
R=s.Matrix([[ -10,0,0,0,0,1],[0,0,1,0,0,0],[(90*e-45)/(16*a),0,-s.Rational(5,8),0,0,-9*e/(16*a)],[0,s.Rational(3,2),0,0,0,0],[0,-45*e/(32*a),45/(32*a),45/(32*a),0,0],[0,-s.Rational(75,16),45*(1-e)/(32*a),0,15/(32*a),0]])
for gg,rr in zip(g,R*s.Matrix([q[i] for i in ids])):
 assert all(s.cancel(t)==0 for t in s.Poly(s.expand(gg-rr),*xx).coeffs())
print('generator determinant',s.factor(R.det()),flush=True)
A=s.Matrix([[s.diff(t,z) for z in xx] for t in f]);mins=[]
for cc in itertools.combinations(range(7),5):
 de=s.factor(A[:,cc].det())
 if de!=0:mins.append((s.count_ops(de),cc,de))
print('all coordinate minors',sorted(mins,key=lambda z:z[0]),flush=True)
_,cc,de=min(mins);com=[i for i in range(7) if i not in cc];T=A.col_join(s.eye(7)[com,:]);Ti=T.inv().applyfunc(s.factor); assert (T*Ti-s.eye(7)).applyfunc(s.cancel)==s.zeros(7)
for i,gg in enumerate(g):
 assert all(s.cancel(t)==0 for t in s.Poly(s.expand(gg-can[i].subs(dict(zip(ys,T*s.Matrix(xx))),simultaneous=True)),*xx).coeffs())
ans={'scope':'Exact generic QQ(a,e) normal form of six supplied infinity quadrics; no cubic or ambient conclusion.','source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'variables_old':[str(z) for z in xx],'variables_new':[str(z) for z in ys],'quadric_source_ids':ids,'active_linear_forms':[str(s.factor(t)) for t in f],'complement_old_indices':[li[i] for i in com],'coordinate_matrix':[[str(v) for v in T.row(i)] for i in range(7)],'coordinate_inverse':[[str(v) for v in Ti.row(i)] for i in range(7)],'coordinate_determinant':str(s.factor(T.det())),'all_active_minors':[[[li[i] for i in cc],str(de)] for _,cc,de in mins],'normal_generators':[str(g) for g in can],'generator_matrix':[[str(v) for v in R.row(i)] for i in range(6)],'generator_inverse':[[str(s.factor(v)) for v in R.inv().row(i)] for i in range(6)],'generator_determinant':str(s.factor(R.det())),'checks':{'all_six_polynomial_identities':True,'coordinate_inverse':True,'generator_inverse':True},'seconds':time.time()-st}
T8=s.zeros(8);
for ii,rr in enumerate([0,1,2,3,4,6,7]):
 for jj,cc8 in enumerate(li):T8[rr,cc8]=T[ii,jj]
T8[5,5]=1
T8i=T8.inv().applyfunc(s.factor)
new8=s.symbols('L W C P E H r s')
ans.update({'new8_order':[str(v) for v in new8],'new_linear_forms_in_old8':[str(s.factor(v)) for v in T8*s.Matrix(x)],'old_variables_in_new8':[str(s.factor(v)) for v in T8i*s.Matrix(new8)],'coordinate_matrix8':[[str(v) for v in T8.row(i)] for i in range(8)],'coordinate_inverse8':[[str(v) for v in T8i.row(i)] for i in range(8)]})
assert (T8*T8i-s.eye(8)).applyfunc(s.cancel)==s.zeros(8)
assert (R*R.inv()-s.eye(6)).applyfunc(s.cancel)==s.zeros(6)
ans['seconds']=time.time()-st
ans['producer_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
Path('work/generic_Bfree_infinity_constant_form_20261102.json').write_text(json.dumps(ans,indent=2)+'\n');print('PASS',time.time()-st,flush=True)

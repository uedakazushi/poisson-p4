from pathlib import Path
import json,hashlib
src=Path('/tmp/generic-hyperplane-partial-model-t-targets-20261102.in');it=iter(map(int,src.read_text().split()));p,nr,nc,nt=[next(it) for _ in range(4)];B=[next(it),next(it)]
def row():
 r={}
 for _ in range(next(it)):
  j,n=next(it),next(it);r[j]=[next(it) for _ in range(n)]
 return r
rows=[row() for _ in range(nr)];target=[row() for _ in range(nt)];assert next(it,None) is None
def times_B(r):
 z={}
 for j,c in r.items():
  b=[0]*(len(c)+1)
  for i,v in enumerate(c):b[i]=(b[i]+B[0]*v)%p;b[i+1]=(b[i+1]+B[1]*v)%p
  while b and not b[-1]:b.pop()
  if b:z[j]=b
 return z
T=target+[times_B(r) for r in target]+[times_B(times_B(r)) for r in target]
out=Path('/tmp/generic-hyperplane-partial-model-B-targets-20261102.in')
with out.open('w') as f:
 f.write(f'{p} {nr} {nc} {len(T)}\n{B[0]} {B[1]}\n')
 for r in rows+T:
  f.write(str(len(r))+'\n')
  for j,c in sorted(r.items()):f.write(f'{j} {len(c)} '+ ' '.join(map(str,c))+'\n')
meta=dict(scope='Same421 source rows; append B and B² target multiples only. F32003 at a=1,e=2; no universal claim.',input=str(out),source=str(src),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),target_order=[{'B_power':i,'light_index':j} for i in range(3) for j in range(nt)])
Path(__file__).with_suffix('.json').write_text(json.dumps(meta,indent=2)+'\n')

from pathlib import Path
import sys,json,time,itertools,functools
import numpy as np
import sympy as s
from sympy.polys.rings import ring
root=Path.cwd();sys.path.insert(0,str(root/'code'))
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();data=json.loads(Path('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json').read_text());old=json.loads(Path('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json').read_text())['linear']
R,a,e,d=ring('a,e,d',s.QQ);syms=s.symbols('a e d');beta={int(k[1:])-1:s.sympify(v) for k,v in data['beta'].items()};model=S61();two,F=specialize(model,beta,True)
fixed=old['fixed'];cols=old['cols'];cw=data['local_coordinate_weights'];w1=[i for i,w in enumerate(cw) if w==1];w2=[i for i,w in enumerate(cw) if w==2];w3=[i for i,w in enumerate(cw) if w==3];zero={19,23};assert [len(w1),len(w2),len(w3)]==[12,15,13]
W=s.Matrix(old['chart_basis']);Wi=W.inv();assert [list(Wi[old['free'][i],:]).index(1) for i in old['parameters']]==[5,19,23]
J=[{} for _ in range(135)];local=[{} for _ in range(135)]
for i,eq in enumerate(F):
 if i==134:continue
 if data["equation_weights"][i]>4:continue
 for mon,c in eq.items():
  c=R.from_expr(s.sympify(c))
  if len(mon)==2:
   x,y=mon
   if x!=fixed and y==fixed:J[i][cols.index(x)]=J[i].get(cols.index(x),R.zero)+c
   if y!=fixed and x==fixed:J[i][cols.index(y)]=J[i].get(cols.index(y),R.zero)+c
  elif len(mon)==1 and mon[0]==fixed:J[i][44]=J[i].get(44,R.zero)+c
  if fixed not in mon:
   ij=tuple(sorted([cols.index(j) for j in mon]+[44]*(2-len(mon))))
   if not any(j in zero for j in ij):local[i][ij]=local[i].get(ij,R.zero)+c
 for j,c in J[i].items():
  if j not in zero and c:local[i][(j,)]=local[i].get((j,),R.zero)+c
 for mon,c in local[i].items():assert not c or sum(cw[j] for j in mon)==data['equation_weights'][i]
local.append({(5,):R.one});rw=data['equation_weights']+[1]

import collections,hashlib
active=set(i for i,w in enumerate(cw) if w>0);target=[{tuple(sorted((44,j))):R.one} for j in w1]+[{(44,):R.one}];target_weights=[4]*len(w1)+[3]
eqs=[{m:c for m,c in p.items() if c} for p in local];steps=[];cap_core_terms=250000;cap_outer_terms=50000;deadline=time.time()+30
class Guard(Exception):pass

def addterm(z,m,c):
 if c:
  value=z.get(m,R.zero)+c
  if value:z[m]=value
  elif m in z:del z[m]

def multiply(P,Q):
 z={};n=0
 for m,c in P.items():
  for nn,v in Q.items():
   addterm(z,tuple(sorted(m+nn)),c*v);n+=1
   if n%1000==0 and time.time()>deadline:raise Guard('wall30s')
 if len(z)>cap_outer_terms:raise Guard('outer term cap')
 return z

def substitute(P,j,S):
 maximum=max((m.count(j) for m in P),default=0)
 if maximum==0:return P
 powers=[{():R.one},S]
 for k in range(2,maximum+1):powers.append(multiply(powers[-1],S))
 z={}
 for m,c in P.items():
  k=m.count(j)
  if not k:addterm(z,m,c);continue
  left=tuple(v for v in m if v!=j)
  for n,b in powers[k].items():addterm(z,tuple(sorted(left+n)),c*b)
 return z

def stats(eqs,target):
 return dict(nonzero_equations=sum(bool(q) for q in eqs),outer_terms=sum(len(q) for q in eqs),core_terms=sum(len(c) for q in eqs for c in q.values()),target_outer_terms=[len(q) for q in target],target_core_terms=[sum(len(c) for c in q.values()) for q in target],maximum_core_degree=max((sum(m) for q in eqs+target for c in q.values() for m in c),default=0))
reason='no constant pivots'
try:
 while True:
  occurrence=collections.Counter(j for q in eqs+target for m in q for j in set(m));candidates=[]
  for i,q in enumerate(eqs):
   for m,c in q.items():
    if len(m)==1 and len(c)==1 and not any(next(iter(c))):
     j=m[0];assert all(j not in n for n in q if n!=m);score=sum(len(v) for v in q.values())*max(1,occurrence[j]-1);candidates.append((score,len(q),cw[j],i,j))
  if not candidates:break
  score,nt,w,i,j=min(candidates);q=eqs[i];scalar=next(iter(q[(j,)].values()));S={m:c*(-1/scalar) for m,c in q.items() if m!=(j,)};new_eq=[{} if k==i else substitute(q,j,S) for k,q in enumerate(eqs)];new_target=[substitute(q,j,S) for q in target];new_stats=stats(new_eq,new_target)
  if new_stats['core_terms']>cap_core_terms:raise Guard('core term cap')
  if new_stats['outer_terms']>cap_outer_terms:raise Guard('outer term cap')
  eqs,target=new_eq,new_target;active.remove(j)
  for k,q in enumerate(eqs):assert all(sum(cw[v] for v in m)==rw[k] for m in q)
  for w,q in zip(target_weights,target):assert all(sum(cw[v] for v in m)==w for m in q)
  steps.append(dict(equation=i,variable=j,weight=cw[j],scalar=str(scalar),score=score,substitution_terms=len(S),**new_stats,seconds=time.time()-start));print('PIVOT',len(steps),i,j,'weight',cw[j],'coreterms',new_stats['core_terms'],'sec',round(time.time()-start,3),flush=True)
  if time.time()>deadline:raise Guard('wall30s')
except Guard as ex:reason=str(ex)
weights=collections.Counter(cw[j] for j in active)
def monomial_count(weight):
 dp=[0]*5;dp[0]=1
 for j in sorted(active):
  for k in range(cw[j],5):dp[k]+=dp[k-cw[j]]
 return dp[weight]
cols4=monomial_count(4);predrows=sum(monomial_count(4-rw[i]) for i,q in enumerate(eqs) if q and rw[i]<=4);st=stats(eqs,target)
serialize=lambda q:[[list(m),[[list(v),str(c)] for v,c in p.items()]] for m,p in sorted(q.items())]
out=dict(scope='Original134 only; constant-rational linear-variable elimination; no inversion of a,F,B or C.',stop_reason=reason,seconds=time.time()-start,remaining_variables=sorted(active),remaining_weights=dict(sorted(weights.items())),eliminated=len(steps),steps=steps,remaining_equation_counts_by_weight=dict(collections.Counter(rw[i] for i,q in enumerate(eqs) if q)),predicted_weight4_shape=[predrows,cols4],statistics=st,equations_sparse=[dict(original_row=i,weight=rw[i],polynomial=serialize(q)) for i,q in enumerate(eqs) if q],targets_sparse=[serialize(q) for q in target],all_weight_checks=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,separators=(',',':'))+'\n');print('SUMMARY',{k:out[k] for k in ['stop_reason','seconds','remaining_variables','remaining_weights','eliminated','remaining_equation_counts_by_weight','predicted_weight4_shape','statistics']},flush=True)

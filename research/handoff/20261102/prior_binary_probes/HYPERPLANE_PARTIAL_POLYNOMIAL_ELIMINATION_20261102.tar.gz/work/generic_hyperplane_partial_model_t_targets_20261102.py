from pathlib import Path
from fractions import Fraction
import json,hashlib,collections,itertools,time
start=time.time();p=32003
model_path=Path('work/generic_hyperplane_polynomial_a_elimination_20261102.json');chart_path=Path('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json')
model=json.loads(model_path.read_text());chart=json.loads(chart_path.read_text());weights=chart['local_coordinate_weights'];variables=model['remaining_variables'];light=[j for j in variables if weights[j]==1]
def monomials(w,lo=0):
 if w==0:yield ();return
 for pos in range(lo,len(variables)):
  j=variables[pos]
  if weights[j]<=w:
   for tail in monomials(w-weights[j],pos):yield (j,)+tail
mons={w:list(monomials(w)) for w in range(5)};index={m:i for i,m in enumerate(mons[4])};assert len(index)==300
bad_den=[]
def evaluate(P):
 out={}
 for mon,coeff in P:
  coeffd={}
  for ex,c in coeff:
   q=Fraction(c);assert q.denominator%p
   val=q.numerator*pow(q.denominator,-1,p)*pow(2,ex[1],p)%p
   coeffd[ex[2]]=(coeffd.get(ex[2],0)+val)%p
  coeffd={k:v for k,v in coeffd.items() if v}
  if coeffd:out[tuple(mon)]=coeffd
 return out
rows=[];labels=[]
for item in model['equations_sparse']:
 pol=evaluate(item['polynomial'])
 for multiplier in mons[4-item['weight']]:
  out={index[tuple(sorted(m+multiplier))]:c for m,c in pol.items()};rows.append(out);labels.append([item['original_row'],list(multiplier)])
t=evaluate(model['targets_sparse'][-1]);targets=[{index[tuple(sorted(m+(j,)))]:c for m,c in t.items()} for j in light]
assert len(rows)==421 and len(targets)==7
path=Path('/tmp/generic-hyperplane-partial-model-t-targets-20261102.in')
with path.open('w') as f:
 f.write(f'{p} {len(rows)} {len(index)} {len(targets)}\n80 102\n')
 for row in rows+targets:
  f.write(str(len(row))+'\n')
  for j,c in sorted(row.items()):
   n=max(c)+1;f.write(f'{j} {n} '+ ' '.join(str(c.get(k,0)) for k in range(n))+'\n')
report=dict(scope='Exploratory fixed a=1,e=2 over F32003[d]. Original134, a-only exact partial elimination. No QQ/universal membership claim.',shape=[len(rows),len(index)],target_variables=light,target_t_a_denominator=model['target_a_denominators'][-1],row_labels=labels,weight4_monomials=mons[4],row_degree=max(k for row in rows for c in row.values() for k in c),target_degree=max(k for row in targets for c in row.values() for k in c),nonzero_coordinates=sum(len(row) for row in rows),scalar_terms=sum(len(c) for row in rows for c in row.values()),seconds=time.time()-start,input=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source_hashes={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),model_path,chart_path]})
Path(__file__).with_suffix('.json').write_text(json.dumps(report,separators=(',',':'))+'\n');print({k:v for k,v in report.items() if k not in ['row_labels','weight4_monomials']})

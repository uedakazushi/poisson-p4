from pathlib import Path
import json,hashlib,tarfile,re
root=Path.cwd();stem='HYPERPLANE_PARTIAL_POLYNOMIAL_ELIMINATION_20261102'
hashfile=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
variants=['constant','constant134','a'];summaries={}
for v in variants:
 p=Path(f'work/generic_hyperplane_polynomial_{v}_elimination_20261102.json');d=json.loads(p.read_text());summaries[v]={k:x for k,x in d.items() if k not in ['equations_sparse','targets_sparse','normalization_history','steps']};summaries[v]['output_sha256']=hashfile(p)
checks={}
for v in ['t','B']:
 p=Path(f'/tmp/generic-hyperplane-partial-model-{v}-targets-membership-20261102.out') if v=='B' else Path('/tmp/generic-hyperplane-partial-model-t-targets-membership-20261102.out')
 text=p.read_text();blocks=re.split(r'^DEGREE ',text,flags=re.M)[1:];dd=[]
 for block in blocks:
  head=block.splitlines()[0].split();status=re.findall(r'^TARGET (\d+) MEMBER (\d+)$',block,re.M)
  dd.append(dict(D=int(head[0]),equations=int(head[2]),unknowns=int(head[3]),rank=int(head[5]),augmented_rank=int(head[7]),members=[bool(int(b)) for a,b in status]))
 checks[v]=dict(output=str(p),sha256=hashfile(p),degrees=dd)
deps=[Path(x) for x in ['code/s61_model.py','code/s61_flag_transverse_obstruction_20261101.py','code/s61_binary_deeper_uniform_quadratic_20261101.py','reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json','reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json','reports/S61_UNIVERSAL_WEIGHT6_20261031.json','legacy/v02/data/symplectic_slice_certificate.json','legacy/v02/data/symplectic_slice_equations.json','legacy/v02/data/symplectic_slice_reduced_equations.json']]
files=[]
for v in variants:
 files += [Path(f'work/generic_hyperplane_polynomial_{v}_elimination_20261102.{ext}') for ext in ['py','log']]
files += [Path('work/generic_hyperplane_polynomial_a_elimination_20261102.json')]
for st in ['generic_hyperplane_partial_model_t_targets_20261102','generic_hyperplane_partial_model_B_targets_20261102']:
 files += [Path('work/'+st+'.'+ext) for ext in ['py','json']]
files += [Path('work/generic_hyperplane_t_targets_bounded_membership_20261102.cpp'),Path(__file__)]
files += [Path(v['output']) for v in checks.values()]
files += [Path('work/generic_hyperplane_partial_model_t_targets_membership_20261102.log'),Path('work/generic_hyperplane_partial_model_B_targets_membership_20261102.log')]
summary=dict(scope='Exact exploratory polynomial substitutions and finite-field candidate membership checks only. No all-core rank, QQ membership, or ambient nilpotence theorem.',variants=summaries,fixed_field_checks=checks,dependency_hashes={str(p):hashfile(p) for p in deps},files={str(p):hashfile(p) for p in files},note='The large421×300 expansion and constant-only residual JSONs are regenerable and intentionally omitted from the archive. The 10-variable residual model and original t/targets are included.')
manifest=Path('work/'+stem+'.json');manifest.write_text(json.dumps(summary,indent=2)+'\n')
note=Path('work/'+stem+'.txt');note.write_text('''BOUNDED PARTIAL POLYNOMIAL ELIMINATION CANDIDATE — 2026-11-02

Scope: exploration only. Frozen formal cubic certificates are unchanged.

Original source is Jz+H(z,z) in the chart with z19=z23=0; add z5=0.
Every pivot is a same-weight linear variable with coefficient QQ* (first
variants) or QQ* a^k (last variant). Positive weights exclude nonlinear
occurrences of that variable in its pivot equation. Substitutions are exact.
All target denominators are tracked as a powers. Source equations may be
multiplied/divided by known units a,F,B,C on their open; in this run only
powers of a were actually removed, never F/B/C. G6 is omitted in the final
model, so original134 only is retained.

Constant-only135:24 pivots ->19 variables, weights9/6/4, core240289,
1265x822 predicted weight4 matrix; guard stopped after6.12seconds.
Constant-only134:24 pivots ->19 variables, core236884,1256x822,
6.14seconds. Each stopped at250000 coreterms without committing overflow.
a-only134:33 pivots ->10 variables, weights7/3; no remaining permissible
pivot,24.60seconds. Residual61 equations:8 of weight2,20 of weight3,33
of weight4.315329 coreterms,10824 normalterms,max coredegree16.
Predicted weight4 matrix421x300. The remaining variables are
3,4,8,12,20,22,24,35,37,43; heavy variables4,12,35.
The original t is tracked as a^-9 times a weighted cubic with43 ordinary
cubic monomials and1 heavy*light monomial; it is NOT pure ordinary cubic.

At a=1,e=2 overFp[d], p=32003, the residual model produces421x300 with
row degree4 and seven t*remaining-light targets of degree1. The original
source row combinations with coefficient d-degree0,1,2,3,4 do not contain
ANY of the seven targets. Adding B or B^2 multiples as extra right-hand
sides also yields no membership up to degree4. This is a representation
bound only, not non-membership in the complete module. Each individual
RHS is tested after augmented exact finite-field RREF.

Reproduction from repository root:
.venv/bin/python work/generic_hyperplane_polynomial_a_elimination_20261102.py
.venv/bin/python work/generic_hyperplane_partial_model_t_targets_20261102.py
.venv/bin/python work/generic_hyperplane_partial_model_B_targets_20261102.py
Compile the included bounded-membership C++ with the existing FLINT
headers/library, then run BIN INPUT OUTPUT 4. The input files are generated
under /tmp. The native constructor checks output streams and verifies every
successful membership against original rows (none here).

The archive keeps the10-variable model and target data, not its expanded
421-row matrix. All three elimination producers, logs and source dependencies
are hash-pinned in the manifest. This is not an independent implementation
of the old S61 chart and does not assert a generic Poisson-fiber conclusion.
''')
files += [manifest,note]
out=Path('work/'+stem+'.tar.gz')
with tarfile.open(out,'w:gz') as ar:
 for p in files:ar.add(p,arcname=('outputs/'+p.name if p.is_absolute() else str(p)))
print(json.dumps(dict(archive=str(out),bytes=out.stat().st_size,sha256=hashfile(out),files=len(files)),indent=2))

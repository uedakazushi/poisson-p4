from pathlib import Path
import json,time
import numpy as np
import sympy as s
start=time.time();P=32003
exec(Path('work/binary_hyperplane_cubic_short_syzygies_extended_20261102.py').read_text().split("print('READ'")[0])
probe=json.loads(Path('work/generic_hyperplane_univariate_kernel_probe_20261102.json').read_text())
exact=json.loads(Path('work/generic_hyperplane_kernel_schur_20261102.json').read_text())
gens=json.loads(Path('work/binary_hyperplane_heavy_small_generators_20261102.json').read_text())['generators']
template=json.loads(Path('code/data/s61_binary_hyperplane_heavy_template_20261102.json').read_text())
mons=sorted(set().union(*(r.keys() for _,r in selected)));lookup={m:j for j,m in enumerate(mons)}
rep=json.loads(Path('reports/S61_BINARY_HYPERPLANE_QUADRATIC_CODIMENSION_20261102.json').read_text())
qs=[{tuple(m):R.from_dict({tuple(mm):s.QQ(c) for mm,c in pp}) for m,pp in row} for row in rep['quadratic_rows_sparse']]
light=[0,1,2,3,4,6,7];prod=[]
for q in qs:
 for j in light:
  rr={}
  for m,p in q.items():n=list(m);n[j]+=1;rr[tuple(n)]=p
  prod.append(rr)
mons=sorted(set(mons).union(*(r.keys() for r in prod)));lookup={m:j for j,m in enumerate(mons)}
mod=lambda c:int(s.Rational(c).p)%P*pow(int(s.Rational(c).q),-1,P)%P
results=[]
for point in probe['results']:
 aa,ee,dd=point['a'],point['e'],3;qbase={}
 def val(p):return mod(p.evaluate(0,aa).evaluate(0,ee).evaluate(0,dd))
 def vector(row):
  v=np.zeros(len(mons),dtype=np.int64)
  for m,p in row.items():v[lookup[m]]=val(p)
  return v
 def add(row):
  row=row.copy()%P
  for j,b in qbase.items():
   if row[j]:row=(row-int(row[j])*b)%P
  nz=np.flatnonzero(row)
  if not len(nz):return False
  j=int(nz[0]);row=row*pow(int(row[j]),-1,P)%P;qbase[j]=row;return True
 for row in prod:add(vector(row))
 lower=len(qbase)
 for i,row in selected:
  if not any(m[5] for m in row):add(vector(row))
 pure=len(qbase);full=dict((i,vector(row)) for i,row in selected)
 for gen in gens:
  vals=[sum(mod(c)*pow(aa,m[0],P)*pow(ee,m[1],P)*pow(dd,m[2],P) for m,c in poly)%P for poly in gen]
  v=sum((c*full[i] for c,i in zip(vals,template['row_ids'])),np.zeros(len(mons),dtype=np.int64))%P
  assert all(not v[j] for j,m in enumerate(mons) if m[5]);add(v)
 short=len(qbase)
 for k in exact['kernels']:
  vals=[sum(mod(c)*pow(aa,m[0],P)*pow(ee,m[1],P)*pow(dd,m[2],P) for m,c in poly)%P for poly in k['vectors_sparse']]
  v=sum((c*full[i] for c,i in zip(vals,template['row_ids'])),np.zeros(len(mons),dtype=np.int64))%P
  assert all(not v[j] for j,m in enumerate(mons) if m[5]);assert add(v)
 final=len(qbase);results.append(dict(a=aa,e=ee,d=dd,lower=lower,plus_pure=pure,plus_short8=short,plus_two_d4=final))
 print(results[-1],flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(prime=P,results=results,seconds=time.time()-start),indent=2)+'\n')

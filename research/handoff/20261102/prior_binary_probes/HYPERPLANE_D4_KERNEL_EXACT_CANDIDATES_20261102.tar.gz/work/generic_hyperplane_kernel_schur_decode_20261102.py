from pathlib import Path
import json,sympy as s,time,hashlib
start=time.time();P=32003
inp=Path('/tmp/generic-hyperplane-kernel-schur-20261102.out');lines=iter(inp.read_text().splitlines())
def poly(line):
 z=line.split();n=int(z[0]);assert len(z)==1+3*n
 return [[list(map(int,z[2+3*i:4+3*i])),z[1+3*i]] for i in range(n)]
results=[]
for rhs in range(2):
 assert next(lines)==f'KERNEL {rhs}';den=poly(next(lines));coeff=[poly(next(lines)) for j in range(80)]
 vectors=[]
 for i in range(16):
  v=[]
  for j in range(5):
   for m,c in coeff[5*i+j]:v.append([m+[j],c])
  vectors.append(v)
 terms=sum(len(p) for p in vectors);degrees=[max([sum(m) for m,c in p],default=-1) for p in vectors]
 adeg=max(m[0] for p in vectors for m,c in p);edeg=max(m[1] for p in vectors for m,c in p);ddeg=max(m[2] for p in vectors for m,c in p)
 results.append(dict(rhs=rhs,denominator_sparse=den,vectors_sparse=vectors,total_terms=terms,total_degrees=degrees,individual_degrees=[adeg,edeg,ddeg]))
 print('KERNEL',rhs,'terms',terms,'degree',max(degrees),'individual',adeg,edeg,ddeg,'component_terms',[len(p) for p in vectors])
x=json.loads(Path('work/generic_hyperplane_kernel_coefficient_probe_20261102.json').read_text());data=json.loads(Path('code/data/s61_binary_hyperplane_heavy_template_20261102.json').read_text())
paths=['work/generic_hyperplane_kernel_schur_20261102.cpp','work/generic_hyperplane_kernel_schur_input_20261102.py','code/data/s61_binary_hyperplane_heavy_template_20261102.json','work/generic_hyperplane_kernel_coefficient_probe_20261102.json','code/s61_binary_deeper_cubic_field_20261101.hpp']
Path('work/generic_hyperplane_kernel_schur_20261102.json').write_text(json.dumps(dict(variables=['a','e','d'],row_ids=data['row_ids'],kernels=results,exact_all56_equations=True,coefficient_system_pivots=x['pivots'],coefficient_system_rows=x['selected_equation_rows'],coefficient_system_free=x['chosen_free_columns'],input_sha256={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}),indent=2)+'\n')

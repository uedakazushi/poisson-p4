# Two exact d-degree-four heavy-kernel candidates

The two vectors in `work/generic_hyperplane_kernel_schur_20261102.json` satisfy
all seven heavy-block polynomial identities over QQ[a,e,d]. They have d-degree
at most four. Their total degrees are 24 and 27, and their total term counts are
4552 and 5941. The component order is the formal template's 16 `row_ids`.
This is an exact identity result; no whole-core rank coverage is asserted.

The vectors were found by solving a fixed 50 x 50 coefficient minor with two
right-hand sides in the 56 x 80 d-coefficient system. The two free coefficients
are 77 and 78 (column 5*i+j means d^j in component i). All other free coefficients
are zero. The input and output are reconstructed from the frozen heavy template.

The native helper removes row and unknown-column polynomial contents, then
performs scalar-normalized fraction-free Schur steps. It records all column
scales and pivot rows. Back substitution reverses every scale and permutation.
After taking a common denominator, the helper independently multiplies both
80-component polynomial coefficient vectors by ALL 56 original coefficient
rows and asserts exact zero. Thus the identity check does not depend on
trusting the Schur transforms alone. The final equivalent identities are the
seven polynomial heavy equations, each through d-degree seven.

The normalized run took 0.906 seconds for all Schur steps, and 1.117 seconds
including back substitution and all original-row checks. An earlier prototype
omitted rational scalar normalization and was stopped at its 100-second bound;
that failed prototype is not evidence for the result and is not repeated.

At all three finite-field samples (a,e,d)=(1,2,3),(2,3,3),(3,5,3), the two exact
vectors augment the eight existing small syzygies from span 7 to span 9. With
the original weighted cubic equations, the pure rank is 41 -> 44 -> 48 -> 50.
These sample ranks also prove independence over the characteristic-zero
function field, but do not give every-point rank assertions.

The normalization denominators are D0=a^2 H0 and D1=a^4 H0, where H0 is the
product of 50a+9e^2+3e-6 with a polynomial of a-degree 6 and e-degree 12, up to
QQ*. They are saved exactly. Although the cleared kernel identities remain
valid everywhere, spanning by this pair must not be asserted on H0=0 without
an additional rank/minor argument. The unknown denominator factors are not
silently added to the previously established aFBC open.

## Reproduction

From the repo root:

```
.venv/bin/python work/generic_hyperplane_kernel_schur_input_20261102.py
clang++ -O3 -std=c++17 -Iwork/flint-headers/flint/3.5.0/include \
 -I/opt/homebrew/include work/generic_hyperplane_kernel_schur_20261102.cpp \
 work/m2-runtime/lib/libflint.24.0.dylib -L/opt/homebrew/lib -lgmp \
 -o /tmp/generic-hyperplane-kernel-schur-normalized-20261102
DYLD_LIBRARY_PATH="$PWD/work/m2-runtime/lib:/opt/homebrew/lib" \
 /tmp/generic-hyperplane-kernel-schur-normalized-20261102 \
 /tmp/generic-hyperplane-kernel-schur-20261102.in \
 /tmp/generic-hyperplane-kernel-schur-20261102.out
.venv/bin/python work/generic_hyperplane_kernel_schur_decode_20261102.py
```

The raw-cubic finite-field comparison script additionally needs the existing
exploratory weighted-row cache under `/tmp`; it is auxiliary to the exact
heavy identities. The small matrix/template inputs and native source are in
the candidate archive. No frozen research source has been changed.

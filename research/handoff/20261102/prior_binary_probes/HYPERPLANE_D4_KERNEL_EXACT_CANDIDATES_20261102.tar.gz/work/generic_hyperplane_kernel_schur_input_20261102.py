from pathlib import Path
import json,sympy as s
x=json.loads(Path('work/generic_hyperplane_kernel_coefficient_probe_20261102.json').read_text());data=json.loads(Path('code/data/s61_binary_hyperplane_heavy_template_20261102.json').read_text())
M=[[{} for j in range(80)] for i in range(56)]
for i,row in enumerate(data['matrix']):
 for j,poly in enumerate(row):
  for m,c in poly:
   for t in range(5):
    z=M[8*j+t+m[2]][5*i+t];key=tuple(m[:2]);z[key]=z.get(key,s.S.Zero)+s.Rational(c)
with Path('/tmp/generic-hyperplane-kernel-schur-20261102.in').open('w') as f:
 f.write('56 80 50 2\n')
 f.write(' '.join(map(str,x['selected_equation_rows']))+'\n')
 f.write(' '.join(map(str,x['pivots']))+'\n')
 f.write(' '.join(map(str,x['chosen_free_columns']))+'\n')
 for row in M:
  for p in row:
   p={m:c for m,c in p.items() if c};f.write(str(len(p))+''.join(f' {c} {m[0]} {m[1]}' for m,c in p.items())+'\n')

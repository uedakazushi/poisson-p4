from pathlib import Path
from fractions import Fraction
import functools,json,time,hashlib,os,subprocess,sys
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod

start=time.time();root=Path.cwd();p=32003;nr=321;nc=238
wd=Path('/tmp/generic-Bfree-vertical-a-next-kernels-20261102');wd.mkdir(exist_ok=True)
profile_path=Path('work/generic_Bfree_vertical_a_infinity_20261102.json');profile=json.loads(profile_path.read_text())
first_path=Path('work/generic_Bfree_vertical_a_first_kernel_20261102.json');first=json.loads(first_path.read_text());assert first['status']=='completed'
core=Path('/tmp/hyperplane-Bfree-t-targets-exact-core-20261102.in');first_input=Path('/tmp/generic-Bfree-vertical-a-first-kernel-20261102.in');first_kernel=Path('/tmp/generic-Bfree-vertical-a-first-kernel-20261102.out')
for q in [core,first_input,first_kernel]:assert hashlib.sha256(q.read_bytes()).hexdigest()==first['input_sha256'][str(q)]
rb=profile['row_bounds'];cb=profile['column_bounds'];paths=[Path(__file__),profile_path,first_path,core,first_input,first_kernel]
@functools.lru_cache(None)
def rational(c):return Fraction(c)
def mod(c):
    assert c.denominator%p
    return c.numerator*pow(c.denominator,-1,p)%p
report={'scope':'Two bounded rectangular column peels over QQ(e), d=3 and a infinity. Only delta2, then delta1, then delta0 retained. No known-root multiplicity or full vertical-support conclusion.','prime':p,'initial_shape':[nr,nc],'steps':[],'precision_rule':'For A known modulo delta^(s+1), an exactly constant-in-delta kernel column has A*K divisible by delta; the quotient is known modulo delta^s. Complement columns are also truncated to degree s-1. Two peels therefore require only initial delta degree2.'}
full0=wd/'full0';count=0;terms=0;leading=[];degree=[]
with core.open()as f,full0.open('w')as out:
    assert list(map(int,f.readline().split()))==[328,238,321];out.write(f'{nr} {nc}\n')
    for i in range(328):
        deg=[]
        for j in range(nc):
            z=f.readline().split();n=int(z[0]);assert len(z)==1+4*n
            if i>=nr:continue
            values={}
            for k in range(n):
                c=rational(z[1+4*k]);mod(c);aa,ee,dd=map(int,z[2+4*k:5+4*k]);key=(aa,ee);values[key]=values.get(key,Fraction(0))+c*3**dd;count+=1
            values={m:c for m,c in values.items()if c};gd=max([aa for aa,ee in values],default=-100000);deg.append(gd)
            assert gd<=rb[i]+cb[j]or gd==-100000
            poly={(ee,rb[i]+cb[j]-aa):c for (aa,ee),c in values.items()if rb[i]+cb[j]-aa<=2};assert all(delta>=0 for ee,delta in poly)
            leading.append({ee:c for (ee,delta),c in poly.items()if delta==0});terms+=len(poly)
            out.write(str(len(poly))+''.join(f' {c} 0 {ee} {delta}'for (ee,delta),c in sorted(poly.items()))+'\n')
        if i<nr:degree.append(deg)
    assert not f.read().strip()
assert degree==profile['generic_entry_a_degrees']
with first_input.open()as f:
    assert list(map(int,f.readline().split()))==[nr,nc,162,76]
    for _ in range(3):f.readline()
    for q in leading:
        z=f.readline().split();n=int(z[0]);v={int(z[3+3*k]):rational(z[1+3*k])for k in range(n)};assert v==q
    assert not f.read().strip()
paths.append(full0);report.update(initial_delta2_terms=terms,original_QQ_degrees_reverified=True,initial_leading_equals_certified_first_input=True,source_terms=count,preparation_seconds=time.time()-start)
print('PREP',report['preparation_seconds'],'DELTA2_TERMS',terms,flush=True)
native={'peel':Path('work/generic_Bfree_rectangular_truncated_peel_20261102.cpp'),'kernel':Path('code/s61_binary_hyperplane_leading_kernel_20261102.cpp')};env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'}
for name,src in native.items():
    subprocess.run(['clang++','-O3','-std=c++17','-Icode','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(src),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(wd/name)],check=True,timeout=30);paths.append(src)
paths.append(Path('code/s61_binary_deeper_cubic_field_20261101.hpp'))
def run(name,args,label):
    remaining=180-(time.time()-start)
    if remaining<=1:raise RuntimeError('total180s budget')
    t=time.time();log=wd/(label+'.log');cp=subprocess.run([str(wd/name),*map(str,args)],env=env,capture_output=True,text=True,timeout=min(60,remaining));log.write_text(cp.stdout+cp.stderr);paths.append(log);cp.check_returncode()
    report['steps'].append({'name':label,'seconds':time.time()-t});print('RUN',label,round(time.time()-t,3),cp.stderr[-180:],flush=True)
def readpoly(line):
    z=line.split();n=int(z[0]);assert len(z)==1+3*n;q={}
    for k in range(n):
        c=rational(z[1+3*k]);xx,ee=map(int,z[2+3*k:4+3*k]);assert xx==0;mod(c);q[ee]=c
    return q
def kernel_input(leading_path,input_path,expected_rank):
    with leading_path.open()as f:
        assert list(map(int,f.readline().split()))==[nr,nc];lines=f.readlines();assert len(lines)==nr*nc
    A=np.array([sum(mod(c)*pow(2,e,p)for e,c in readpoly(line).items())%p for line in lines],dtype=np.int64).reshape(nr,nc)
    rank,cols=elimination_rank(A,p);assert rank==expected_rank;_,rows=elimination_rank(A[:,cols].T,p);free=[j for j in range(nc)if j not in cols];minor=int(determinant_mod(A[np.ix_(rows,cols)],p));assert minor
    with input_path.open('w')as f:f.write(f'{nr} {nc} {rank} {len(free)}\n'+' '.join(map(str,rows))+'\n'+' '.join(map(str,cols))+'\n'+' '.join(map(str,free))+'\n');f.writelines(lines)
    return {'rank':rank,'nullity':len(free),'rows':rows,'columns':cols,'free_columns':free,'pivot_minor_modp':minor},A
def audit_kernel(path,info,A):
    nf=info['nullity'];ff=info['free_columns'];E=np.zeros((nc,nf),dtype=np.int64);stats=[];anchors=[]
    with path.open()as f:
        for k in range(nf):
            assert f.readline().split()==['KERNEL',str(k)];den=readpoly(f.readline());anchor=sum(mod(c)*pow(2,e,p)for e,c in den.items())%p;assert anchor;anchors.append(anchor);q=[readpoly(f.readline())for _ in range(nc)]
            for j in ff:assert q[j]==(den if j==ff[k]else {})
            for j,v in enumerate(q):E[j,k]=sum(mod(c)*pow(2,e,p)for e,c in v.items())%p
            stats.append({'terms':sum(map(len,q)),'max_numerator_e_degree':max([e for v in q for e in v],default=-1),'anchor_e_degree':max(den,default=-1)})
        assert not f.read().strip()
    assert not np.any(A@E%p)
    return {'all_QQ_row_kernel_products_checked_by_native':True,'free_diagonal_verified':True,'all_rational_coefficients_p_integral':True,'all_anchors_units_at_e2':True,'independent_modular_product_zero':True,'anchor_values_modp':anchors,'kernel_statistics':stats,'output_bytes':path.stat().st_size}
try:
    current_full=full0;current_input=first_input;current_kernel=first_kernel
    for stage,(precision,expected_rank)in enumerate([(2,205),(1,228)],1):
        nxt=wd/f'full{stage}';leadpath=wd/f'leading{stage}';inp=wd/f'input{stage}';ker=wd/f'kernel{stage}'
        run('peel',[current_full,current_input,current_kernel,nxt,leadpath,precision],f'peel{stage}');paths.extend([nxt,leadpath])
        info,A=kernel_input(leadpath,inp,expected_rank);paths.append(inp);report[f'leading{stage}']=info
        run('kernel',[inp,ker],f'kernel{stage}');paths.append(ker);report[f'kernel{stage}']=audit_kernel(ker,info,A)
        current_full=nxt;current_input=inp;current_kernel=ker
    report.update(status='completed',exact_generic_leading_ranks=[162,205,228],successive_nullities=[76,33,10],maximal_minor_delta_valuation_lower=119,selected_minor_generic_a_degree_upper=profile['selected_degree_upper']-119,selected_minor_modular_a_degree=profile['direct_minor']['degree'],selected_minor_exact_generic_a_degree=575,no_delta3_or_full_untruncated_product_computed=True)
    assert report['selected_minor_generic_a_degree_upper']==575
except subprocess.TimeoutExpired as ex:
    label='timeout';log=wd/'timeout.log';text=(ex.stdout or b'')+(ex.stderr or b'');log.write_bytes(text if isinstance(text,bytes)else text.encode());paths.append(log);report.update(status='bounded_timeout',timeout_command=[str(z)for z in ex.cmd],timeout_seconds=ex.timeout)
except (subprocess.CalledProcessError,RuntimeError)as ex:report.update(status='bounded_native_guard_or_budget',error=str(ex))
report['input_sha256']={str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in paths};report['seconds']=time.time()-start
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('RESULT',report['status'],'SECONDS',report['seconds'],flush=True)

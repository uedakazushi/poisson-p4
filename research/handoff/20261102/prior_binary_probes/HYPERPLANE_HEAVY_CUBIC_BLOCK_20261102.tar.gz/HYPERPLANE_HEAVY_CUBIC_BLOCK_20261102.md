# K=0 三core weighted cubic の heavy block

2026-11-02。既存 `HYPERPLANE_WEIGHTED_CHART` の正重み八法線変数に対し、
weight3 の21式から heavy変数 `v5` と一つのlight変数との積の7列だけを取る。
本稿は全pure cubicやweight4の239列を扱わない。

指定raw入力のSHAと全列単項式・元行番号は
`work/HYPERPLANE_HEAVY_CUBIC_BLOCK_20261102.json` にある。
rawは依頼元が元135式から生成した正確なweighted入力を使用し、本producerは
その82MBファイルを読み直す。raw生成自体の第二実装を主張しない。

21行中5行のheavy成分は零。残16行は既知単元F*Bで正確に割り切れる。
全成分について多項式exact quotientを検査する。この除算は指定aFBC開上の行spanを保つ。
続いて係数モノミアルを総次数降順に並べ、QQ上の定数行結合だけで15行へ移す。
保存した15×16定数行列と全多項式行との積を別途正確に照合した。

この15×7行列の次の三つの最大minorを、native FLINTのfraction-free Bareissで計算した。
行番号は零始まりで、ここでの定数行結合後の番号である。

- (13,14,12,11,7,9,1)
- (7,4,14,3,8,5,0)
- (5,13,11,12,2,0,7)

各Bareiss除算を `fmpq_mpoly_divides` で検査し、行・列交換の符号を追跡する。
三minorの全QQ多項式最大公約数は、非零定数倍を除いて

    a^4 C,   C=100a+18e²−9e−2

である。reportのmonic化では `a^4*C/100` となる。
さらに `(a,e,d)=(1,2,3),(2,1,1)` で別SymPy実装の正確な7×7数値行列式と
保存多項式の値を照合した。この二標本は全多項式GCD証明の代用ではなく補助検算である。

従って `QQ[a,e,d,(aFBC)^-1]` 上でこのブロックの最大minor idealは
高さ1素idealに含まれない。三変数多項式環のUFD性から、rank<7 locusは高々一次元。
**全開上でrank7であること、あるいは最大minor idealが単位idealであることは主張しない。**
全cubic行列の階数・長さ65・ambient飽和の結論もここには含まれない。

再現:

```sh
.venv/bin/python work/generic_hyperplane_heavy_certificate_20261102.py \
  --output /tmp/heavy-block-replay.json
```

freshは1.273秒でPASS。sourceは別stemのnative
`work/generic_hyperplane_heavy_minor_certificate_20261102.cpp` を用いる。
旧blind determinant計算を延長せず、単元FB除算・定数行結合とnative Bareissへ変更した。
最初の二minorに一時現れた未知因子Hは第三minorで消え、最終結論には残らない。

from pathlib import Path
import argparse,hashlib,json,os,subprocess,tempfile,time
import sympy as s
from sympy.polys.rings import ring
from sympy.polys.matrices import DomainMatrix
ROOT=Path(__file__).resolve().parents[1]
RAW=Path('/tmp/poisson-binary-hyperplane-weighted-20261102/rows')
NATIVE=ROOT/'work/generic_hyperplane_heavy_minor_certificate_20261102.cpp'
SELECTED=[[13,14,12,11,7,9,1],[7,4,14,3,8,5,0],[5,13,11,12,2,0,7]]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run():
 start=time.time();R,a,e,d=ring('a,e,d',s.QQ);row_ids=[];rawrows=[]
 with RAW.open() as stream:
  for _ in range(int(stream.readline())):
   idx,w,ct=map(int,stream.readline().split());row={}
   for j in range(ct):
    mon=tuple(map(int,stream.readline().split()));line=stream.readline()
    if w==3 and mon[5]==1:
     data=line.split();n=int(data[0]);assert len(data)==1+4*n
     row[mon]=R.from_dict({tuple(map(int,data[2+4*k:5+4*k])):s.QQ.convert(s.Rational(data[1+4*k])) for k in range(n)})
   if w==3:row_ids.append(idx);rawrows.append(row)
 mons=sorted({m for row in rawrows for m in row});assert len(rawrows)==21 and len(mons)==7
 original=[[row.get(m,R.zero) for m in mons] for row in rawrows]
 F=500*a+90*e**2+3*e-24;B=50*a*d+18*d*e**2-9*d*e-2*d+60*e-40;C=100*a+18*e**2-9*e-2
 nonzero=[i for i,row in enumerate(original) if any(row)];assert len(nonzero)==16
 A=[[p.exquo(F*B) for p in original[i]] for i in nonzero]
 keys=sorted({(m,j) for row in A for j,p in enumerate(row) for m in p},key=lambda z:(-sum(z[0]),z[0],z[1]))
 raw=[[row[j].get(m,s.QQ.zero) for m,j in keys]+[s.QQ.one if i==k else s.QQ.zero for k in range(16)] for i,row in enumerate(A)]
 rr,piv=DomainMatrix(raw,(16,len(keys)+16),s.QQ).rref();matrix=[];changes=[]
 for row in rr.to_list():
  if not any(row[:len(keys)]):continue
  new=[R.zero for _ in range(7)]
  for value,(m,j) in zip(row,keys):
   if value:new[j][m]=value
  change=row[len(keys):]
  assert all(new[j]==sum((change[i]*A[i][j] for i in range(16)),R.zero) for j in range(7))
  matrix.append(new);changes.append(change)
 assert len(matrix)==15
 library=ROOT/'work/m2-runtime/lib';env=dict(os.environ,DYLD_LIBRARY_PATH=str(library)+':/opt/homebrew/lib')
 with tempfile.TemporaryDirectory(prefix='hyperplane-heavy-cert-') as temp:
  td=Path(temp);inp=td/'input';out=td/'output';exe=td/'native'
  with inp.open('w') as f:
   f.write('15 7\n')
   for row in matrix:
    for p in row:
     f.write(str(len(p))+'\n')
     for m,c in p.items():f.write(str(c)+' '+' '.join(map(str,m))+'\n')
   f.write('3\n')
   for rows in SELECTED:f.write(' '.join(map(str,rows))+'\n')
  command=['clang++','-O3','-std=c++17','-I'+str(ROOT/'work/flint-headers/flint/3.5.0/include'),'-I/opt/homebrew/include',str(NATIVE),str(library/'libflint.24.0.dylib'),'-L/opt/homebrew/lib','-lgmp','-o',str(exe)]
  subprocess.run(command,check=True,capture_output=True)
  proc=subprocess.run([str(exe),str(inp),str(out)],env=env,check=True,capture_output=True,text=True,timeout=30)
  lines=out.read_text().splitlines();minors=[];gcds=[]
  def readpoly(line):
   v=line.split();n=int(v[0]);assert len(v)==1+4*n
   return R.from_dict({tuple(map(int,v[2+4*k:5+4*k])):s.QQ.convert(s.Rational(v[1+4*k])) for k in range(n)})
  for i in range(3):
   assert lines[4*i].split()==['MINOR',str(i),*map(str,SELECTED[i])]
   minors.append(readpoly(lines[4*i+1]));assert lines[4*i+2]==f'GCD {i}';gcds.append(readpoly(lines[4*i+3]))
  expected=a**4*C/100;assert gcds[-1]==expected
  for p in minors:assert p.rem(expected)==0
  # Independent exact scalar determinant checks, in addition to the native full-QQ Bareiss proof.
  for point in [(1,2,3),(2,1,1)]:
   def ev(p):return s.Rational(p.evaluate(0,point[0]).evaluate(0,point[1]).evaluate(0,point[2]))
   for ids,poly in zip(SELECTED,minors):
    assert s.Matrix([[ev(matrix[i][j]) for j in range(7)] for i in ids]).det()==ev(poly)
  serialize=lambda p:[[list(m),str(c)] for m,c in p.items()]
  result=dict(id='HYPERPLANE_HEAVY_CUBIC_BLOCK_20261102',all_passed=True,variables=['a','e','d'],block_shape=[21,7],nonzero_row_count=16,constant_row_span_rank=15,original_row_ids=row_ids,nonzero_original_rows=nonzero,monomials=mons,removed_common_unit=str((F*B).as_expr()),constant_row_change=[[str(c) for c in row] for row in changes],constant_row_identity_checked=True,reduced_matrix=[[serialize(p) for p in row] for row in matrix],selected_minor_rows=SELECTED,minors=[serialize(p) for p in minors],gcd_up_to_unit=str(expected.as_expr()),gcd_sparse=serialize(expected),rank7_bad_dimension_upper_on_a_F_B_C_open=1,full_open_rank7_not_asserted=True,independent_scalar_points=[[1,2,3],[2,1,1]],native_log=proc.stderr,input_sha256={str(Path(__file__).relative_to(ROOT)):sha(__file__),str(NATIVE.relative_to(ROOT)):sha(NATIVE),str(RAW):sha(RAW)},seconds=time.time()-start)
 return result
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();assert not args.output.exists();result=run();args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['all_passed','gcd_up_to_unit','rank7_bad_dimension_upper_on_a_F_B_C_open','seconds']}))

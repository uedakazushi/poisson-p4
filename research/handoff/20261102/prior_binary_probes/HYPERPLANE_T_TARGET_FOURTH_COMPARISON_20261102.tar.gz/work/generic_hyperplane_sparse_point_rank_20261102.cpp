#include <flint/nmod_mat.h>
#include <fstream>
#include <iostream>
#include <chrono>
#include <cassert>
using namespace std;int main(int argc,char**argv){assert(argc==3);ifstream in(argv[1]);ofstream out(argv[2]);assert(in&&out);int n,m;ulong p;in>>n>>m>>p;nmod_mat_t A;nmod_mat_init(A,n,m,p);long nnz=0;for(int i=0;i<n;i++){int k;in>>k;nnz+=k;for(int t=0;t<k;t++){int j;ulong c;in>>j>>c;nmod_mat_entry(A,i,j)=c;}}assert(in);auto start=chrono::steady_clock::now();long rank=nmod_mat_rank(A);double sec=chrono::duration<double>(chrono::steady_clock::now()-start).count();out<<n<<' '<<m<<' '<<p<<' '<<nnz<<' '<<rank<<' '<<sec<<'\n';out.flush();assert(out.good());cerr<<"RANK "<<rank<<" COLS "<<m<<" NNZ "<<nnz<<" SEC "<<sec<<'\n';nmod_mat_clear(A);flint_cleanup();}

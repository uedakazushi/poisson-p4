from pathlib import Path
import json,sys,itertools,time
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank
start=time.time();z=iter(Path('/tmp/hyperplane-t-targets-univariate-20261102.in').read_text().split());p,nr,nc,nt=[int(next(z)) for _ in range(4)];b0,b1=int(next(z)),int(next(z));M=[]
for _ in range(nr+nt):
 row=np.zeros(nc,dtype=np.int64)
 for _ in range(int(next(z))):
  j,l=int(next(z)),int(next(z));row[j]=sum(int(next(z))*pow(3,k,p) for k in range(l))%p
 M.append(row)
M=np.array(M);A=M[:nr];T=M[nr:];weights=[1,1,1,1,1,2,1,1]
def mons(w,i=0,m=()):
 if i==8:
  if not w:yield m
  return
 for k in range(w//weights[i]+1):yield from mons(w-k*weights[i],i+1,m+(k,))
labels=[];groups={};q2=[];q2pure=[]
with (Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/poisson-hyperplane-cubic-matrix-fresh-20261102/rows')).open() as f:
 n=int(f.readline())
 for _ in range(n):
  idx,w,ct=map(int,f.readline().split())
  for _ in range(ct):f.readline();f.readline()
  for sh in mons(4-w):
   pos=len(labels);labels.append(dict(row=idx,weight=w,source_S61_weight=4 if idx<70 else 5 if idx<134 else 6,shift=list(sh)))
   if w==2:
    q2.append(pos)
    if sh[5]==0:q2pure.append(pos)
   else:groups.setdefault(idx,[]).append(pos)
assert len(labels)==nr and len(q2)==174 and len(q2pure)==168 and len(groups)==21
def rank(ids):return elimination_rank(A[ids],p)[0]
def check(ids):
 r=rank(ids);aug=elimination_rank(np.concatenate([A[ids],T]),p)[0];return dict(rows=len(ids),rank=r,augmented_rank=aug,all_targets=aug==r)
out=dict(prime=p,point=[1,2,3],q2_S2=check(q2pure),q2_weight2=check(q2),full=check(list(range(nr))),single_cubic={str(i):check(q2+g) for i,g in groups.items()},by_source_weight={str(w):check(q2+sum((g for i,g in groups.items() if (4 if i<70 else 5 if i<134 else 6)==w),[])) for w in [4,5,6]})
chosen=[];progress=[]
for i,g in groups.items():
 chosen.append(i);status=check(q2+sum((groups[j] for j in chosen),[]));progress.append(dict(added=i,**status))
 if status['all_targets']:break
for i in chosen[::-1]:
 trial=[j for j in chosen if j!=i]
 if check(q2+sum((groups[j] for j in trial),[]))['all_targets']:chosen=trial
out['by_two_source_weights']={','.join(map(str,pair)):check(q2+sum((g for i,g in groups.items() if (4 if i<70 else 5 if i<134 else 6) in pair),[])) for pair in [(4,5),(4,6),(5,6)]}
out.update(greedy_progress=progress,one_inclusion_minimal_cubic_group_list=chosen,selected_status=check(q2+sum((groups[j] for j in chosen),[])),leave_one_cubic_out={str(i):check(q2+sum((g for j,g in groups.items() if j!=i),[])) for i in groups},row_labels=labels,seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print({k:out[k] for k in ['q2_S2','q2_weight2','full','by_source_weight','by_two_source_weights','one_inclusion_minimal_cubic_group_list','selected_status','seconds']});print('necessary individual',[i for i,r in out['leave_one_cubic_out'].items() if not r['all_targets']])

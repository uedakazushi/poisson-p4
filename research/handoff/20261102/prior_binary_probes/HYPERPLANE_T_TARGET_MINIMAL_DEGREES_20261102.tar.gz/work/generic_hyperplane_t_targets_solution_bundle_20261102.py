from pathlib import Path
import json,hashlib,tarfile
import numpy as np
p=32003;path=Path('/tmp/generic-hyperplane-t-targets-minimal-solution-20261102.out');lines=iter(path.read_text().splitlines());head=next(lines).split();assert head[:2]==['KERNEL_RANK','83'];degrees=list(map(int,head[3:]));solutions=[]
for line in lines:
 z=line.split();assert z[0]=='TARGET';target=int(z[1]);initial=int(z[3]);minimum=int(z[5]);rows=int(z[7]);nonzero=int(z[9]);sparse=[];support=[]
 for line in lines:
  if line=='END_TARGET':break
  z=list(map(int,line.split()));row,n=z[:2];assert len(z)==n+2;support.append(row)
  for d,c in enumerate(z[2:]):
   if c:sparse.append([row,d,c])
 assert len(sparse)==nonzero and len(support)==rows
 solutions.append(dict(target=target,initial_degree=initial,minimum_degree=minimum,row_support=support,coefficients_sparse=sparse))
X=np.zeros((7,321,14),dtype=np.int64)
for q in solutions:
 for r,d,c in q['coefficients_sparse']:X[q['target'],r,d]=c
A=X[:,:,13].T.copy();rank=0;piv=[]
for j in range(7):
 ids=np.flatnonzero(A[rank:,j])
 if not len(ids):continue
 k=rank+int(ids[0]);A[[rank,k]]=A[[k,rank]];A[rank]=A[rank]*pow(int(A[rank,j]),-1,p)%p
 for i in range(321):
  if i!=rank:A[i]=(A[i]-A[i,j]*A[rank])%p
 piv.append(j);rank+=1
assert rank==6;free=[i for i in range(7) if i not in piv];assert len(free)==1
v=np.zeros(7,dtype=np.int64);v[free[0]]=1
for i,j in enumerate(piv):v[j]=-A[i,free[0]]%p
assert not (X[:,:,13].T@v%p).any();combo=sum((int(v[t])*X[t]%p for t in range(7)),start=np.zeros((321,14),dtype=np.int64))%p;assert not combo[:,13].any() and combo[:,12].any()
rank_results=[]
for name in ['bounded-membership','extended-membership','degrees12_13']:
 for line in Path('/tmp/generic-hyperplane-t-targets-'+name+'-20261102.out').read_text().splitlines():
  z=line.split()
  if z[0]=='DEGREE':rank_results.append(dict(D=int(z[1]),equations=int(z[3]),unknowns=int(z[4]),coefficient_rank=int(z[6]),augmented_rank=int(z[8])))
files=sorted(Path('work').glob('generic_hyperplane_t_targets*'))+[Path('/tmp/hyperplane-t-targets-univariate-20261102.in')]+[Path('/tmp/generic-hyperplane-t-targets-'+name+'-20261102.out') for name in ['bounded-membership','extended-membership','degrees12_13','minimal-solution']]
files=[f for f in files if f.name!='generic_hyperplane_t_targets_solution_bundle_20261102.json']
out=dict(scope='Candidate computation only at F32003, a=1,e=2. No QQ or universal parameter membership asserted.',prime=p,source_shape=[321,238],row_degree=5,target_degree=4,kernel_rank=83,kernel_popov_degrees=degrees,kernel_degree_counts={str(d):degrees.count(d) for d in sorted(set(degrees))},solutions=solutions,rank_ansatz_results=rank_results,degree12_target_combination=list(map(int,v)),degree12_combination_nonzero_coefficients=int(np.count_nonzero(combo)),input_sha256={str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in files})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
print('minimums',[q['minimum_degree'] for q in solutions],'kernelindices',out['kernel_degree_counts'],'degree12combo',out['degree12_target_combination'],'rows',[len(q['row_support']) for q in solutions])

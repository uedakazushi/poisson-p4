from pathlib import Path
from fractions import Fraction
import json,hashlib,time,os,subprocess,sys
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod

start=time.time();root=Path.cwd();p=32003;n=238;anchors=[207,210,211]
shortpath=Path('work/generic_Bfree_root_F_sparse_left_20261102.json');short=json.loads(shortpath.read_text());modpath=Path('/tmp/generic-Bfree-root-F-sparse-left-20261102/modular_candidates');lead=Path('/tmp/binary-Bfree-root-20261102-F.leading')
for q in [lead,modpath]:assert hashlib.sha256(q.read_bytes()).hexdigest()==short['input_sha256'][str(q)]
ml=modpath.read_text().splitlines();assert ml[0]=='238 238 169 69';vectors={int(z.split()[0]):list(map(int,z.split()[1:]))for z in ml[1:]};supp=[{j for j,c in enumerate(vectors[a])if c}for a in anchors];common=set.intersection(*supp);union=set.union(*supp);assert len(common)==132 and union==common|set(anchors)and len(union)==135
common=sorted(common);columns=common+anchors;assert not set(common).intersection(short['distinct_free_anchors'])
ls=lead.read_text().splitlines();assert ls[0]=='238 238';lines=ls[1:];assert len(lines)==n*n
def ev(line):
    z=line.split();nt=int(z[0]);assert len(z)==1+3*nt;value=0;used=set()
    for k in range(nt):
        q=Fraction(z[1+3*k]);xx,e=map(int,z[2+3*k:4+3*k]);assert xx==0 and q.denominator%p and e not in used;used.add(e)
        value=(value+q.numerator*pow(q.denominator,-1,p)*pow(2,e,p))%p
    return value
A=np.array([[ev(lines[j*n+i])for j in columns]for i in range(n)],dtype=np.int64)
rank,piv=elimination_rank(A[:,:132],p);assert rank==132;_,rows=elimination_rank(A[:,:132].T,p);minor=int(determinant_mod(A[np.ix_(rows,range(132))],p));assert minor
unionrank,_=elimination_rank(A,p);assert unionrank==132
wd=Path('/tmp/generic-Bfree-root-F-hard-union-rank-20261102');wd.mkdir(exist_ok=True);inp=wd/'input';out=wd/'output';log=wd/'log'
inp.write_text('238 135\n'+''.join(lines[j*n+i]+'\n'for i in range(n)for j in columns))
native=Path('work/binary_Bfree_root_univariate_rank_20261102.cpp');exe=wd/'native';subprocess.run(['clang++','-O3','-std=c++17','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(native),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=20)
env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'};t=time.time();report={'scope':'One bounded rank-only QQ(e) calculation of the three remaining F-root left-kernel supports. No explicit rational kernel restoration or F-order70 claim.','prime':p,'shape':[238,135],'common_columns':common,'anchor_columns':anchors,'columns_in_order':columns,'common132_minor_modp':{'equation_rows':rows,'value':minor},'union_rank_modp':unionrank,'common_avoids_all69_free_anchors':True,'native_wall_bound_seconds':45}
try:
    cp=subprocess.run([str(exe),str(inp),str(out)],env=env,capture_output=True,text=True,timeout=45);log.write_text(cp.stdout+cp.stderr);cp.check_returncode();z=out.read_text().split();assert z==['EXACT_QQ_E_RANK','132'];report.update(status='completed',exact_QQ_e_union_rank=132,three_independent_relations_exist_with_distinct_anchors=True,combined_with66_short_kernels_exact_full_rank=169)
except subprocess.TimeoutExpired as ex:
    txt=(ex.stdout or b'')+(ex.stderr or b'');log.write_bytes(txt if isinstance(txt,bytes)else txt.encode());report['status']='timeout45s'
except subprocess.CalledProcessError:report['status']='native_guard_or_error'
report['native_seconds']=time.time()-t;paths=[Path(__file__),shortpath,modpath,lead,native,inp,log]+([out]if out.exists()else []);report['input_sha256']={str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in paths};report['seconds']=time.time()-start
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('RESULT',report['status'],'NATIVE',report['native_seconds'],'TOTAL',report['seconds'],flush=True)

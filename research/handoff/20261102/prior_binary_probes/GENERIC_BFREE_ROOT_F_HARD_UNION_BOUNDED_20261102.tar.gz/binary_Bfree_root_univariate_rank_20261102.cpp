#include <flint/fmpq.h>
#include <flint/fmpz.h>
#include <flint/fmpq_poly.h>
#include <flint/fmpz_poly.h>
#include <cassert>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <chrono>
using namespace std;
struct Poly{fmpz_poly_t p;Poly(){fmpz_poly_init(p);}Poly(const Poly&a):Poly(){fmpz_poly_set(p,a.p);}Poly(Poly&&a):Poly(){fmpz_poly_swap(p,a.p);}Poly&operator=(Poly a){fmpz_poly_swap(p,a.p);return *this;}~Poly(){fmpz_poly_clear(p);}};
int main(int argc,char**argv){assert(argc==3);ifstream in(argv[1]);ofstream out(argv[2]);assert(in&&out);int n,m;in>>n>>m;vector<vector<Poly>>A(n,vector<Poly>(m));
 fmpq_poly_t q;fmpq_poly_init(q);fmpq_t c;fmpq_init(c);fmpz_t D,b,t;fmpz_init(D);fmpz_init(b);fmpz_init(t);
 for(int i=0;i<n;i++){
  vector<string>den(m);fmpz_one(D);
  for(int j=0;j<m;j++){
   fmpq_poly_zero(q);int count;in>>count;
   for(int z=0;z<count;z++){string coeff;int a,e;in>>coeff>>a>>e;assert(a==0);assert(!fmpq_set_str(c,coeff.c_str(),10));fmpq_canonicalise(c);fmpq_poly_set_coeff_fmpq(q,e,c);}
   fmpq_poly_get_numerator(A[i][j].p,q);fmpq_poly_get_denominator(b,q);char*s=fmpz_get_str(nullptr,10,b);den[j]=s;flint_free(s);fmpz_lcm(D,D,b);
  }
  for(int j=0;j<m;j++){assert(!fmpz_set_str(b,den[j].c_str(),10));fmpz_divexact(t,D,b);fmpz_poly_scalar_mul_fmpz(A[i][j].p,A[i][j].p,t);}
 }
 string extra;assert(in&&!(in>>extra));fmpq_poly_clear(q);fmpq_clear(c);fmpz_clear(D);fmpz_clear(b);fmpz_clear(t);
 auto start=chrono::steady_clock::now();int rank=0;while(n&&m){
  for(int axis=0;axis<2;axis++){
   int outer=axis?m:n,inner=axis?n:m;
   for(int i=0;i<outer;i++){
    Poly g,h,v;
    for(int j=0;j<inner;j++){auto&p=axis?A[j][i]:A[i][j];fmpz_poly_gcd(h.p,g.p,p.p);g=h;if(fmpz_poly_is_one(g.p))break;}
    if(fmpz_poly_is_zero(g.p)||fmpz_poly_is_one(g.p))continue;
    for(int j=0;j<inner;j++){auto&p=axis?A[j][i]:A[i][j];assert(fmpz_poly_divides(v.p,p.p,g.p));p=v;}
   }
  }
  int bi=-1,bj=-1;long best=100000000;for(int i=0;i<n;i++)for(int j=0;j<m;j++){long deg=fmpz_poly_degree(A[i][j].p);if(deg>=0&&deg<best){best=deg;bi=i;bj=j;}}
  if(bi<0)break;
  swap(A[0],A[bi]);for(auto&r:A)swap(r[0],r[bj]);vector<vector<Poly>>B(n-1,vector<Poly>(m-1));Poly x,y;
  for(int i=1;i<n;i++)for(int j=1;j<m;j++){fmpz_poly_mul(x.p,A[0][0].p,A[i][j].p);fmpz_poly_mul(y.p,A[i][0].p,A[0][j].p);fmpz_poly_sub(B[i-1][j-1].p,x.p,y.p);}
  A=std::move(B);n--;m--;rank++;long len=0,maxdegree=0;for(auto&r:A)for(auto&p:r){len+=fmpz_poly_length(p.p);maxdegree=max(maxdegree,fmpz_poly_degree(p.p));}
  double sec=chrono::duration<double>(chrono::steady_clock::now()-start).count();cerr<<"RANK "<<rank<<" SIZE "<<n<<' '<<m<<" LENGTH "<<len<<" MAXDEG "<<maxdegree<<" SECONDS "<<sec<<'\n';assert(sec<55&&len<3000000);
 }
 out<<"EXACT_QQ_E_RANK "<<rank<<'\n';out.flush();assert(out.good());flint_cleanup();}

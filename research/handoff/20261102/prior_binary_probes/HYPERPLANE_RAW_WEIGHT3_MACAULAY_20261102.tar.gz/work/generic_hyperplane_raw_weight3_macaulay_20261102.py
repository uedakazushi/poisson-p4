from pathlib import Path
import sys,json,time,itertools,functools
import numpy as np
import sympy as s
from sympy.polys.rings import ring
root=Path.cwd();sys.path.insert(0,str(root/'code'))
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();data=json.loads(Path('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json').read_text());old=json.loads(Path('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json').read_text())['linear']
R,a,e,d=ring('a,e,d',s.QQ);syms=s.symbols('a e d');beta={int(k[1:])-1:s.sympify(v) for k,v in data['beta'].items()};model=S61();two,F=specialize(model,beta,True)
fixed=old['fixed'];cols=old['cols'];cw=data['local_coordinate_weights'];w1=[i for i,w in enumerate(cw) if w==1];w2=[i for i,w in enumerate(cw) if w==2];w3=[i for i,w in enumerate(cw) if w==3];zero={19,23};assert [len(w1),len(w2),len(w3)]==[12,15,13]
W=s.Matrix(old['chart_basis']);Wi=W.inv();assert [list(Wi[old['free'][i],:]).index(1) for i in old['parameters']]==[5,19,23]
J=[{} for _ in range(135)];local=[{} for _ in range(135)]
for i,eq in enumerate(F):
 if data["equation_weights"][i]>3:continue
 for mon,c in eq.items():
  c=R.from_expr(s.sympify(c))
  if len(mon)==2:
   x,y=mon
   if x!=fixed and y==fixed:J[i][cols.index(x)]=J[i].get(cols.index(x),R.zero)+c
   if y!=fixed and x==fixed:J[i][cols.index(y)]=J[i].get(cols.index(y),R.zero)+c
  elif len(mon)==1 and mon[0]==fixed:J[i][44]=J[i].get(44,R.zero)+c
  if fixed not in mon:
   ij=tuple(sorted([cols.index(j) for j in mon]+[44]*(2-len(mon))))
   if not any(j in zero for j in ij):local[i][ij]=local[i].get(ij,R.zero)+c
 for j,c in J[i].items():
  if j not in zero and c:local[i][(j,)]=local[i].get((j,),R.zero)+c
 for mon,c in local[i].items():assert not c or sum(cw[j] for j in mon)==data['equation_weights'][i]
local.append({(5,):R.one});rw=data['equation_weights']+[1]
mon1=[(j,) for j in w1];mon2=[(j,) for j in w2]+list(itertools.combinations_with_replacement(w1,2));mon3=[(j,) for j in w3]+[tuple(sorted((i,j))) for i in w1 for j in w2]+list(itertools.combinations_with_replacement(w1,3));assert len(mon3)==len(set(mon3))==557;mon3=sorted(mon3);lookup={m:i for i,m in enumerate(mon3)}
shifts={0:[()],1:mon1,2:mon2};rows=[];source=[]
for i,eq in enumerate(local):
 if rw[i]>3:continue
 for shift in shifts[3-rw[i]]:
  v={}
  for m,c in eq.items():
   if c:
    j=lookup[tuple(sorted(m+shift))];v[j]=v.get(j,R.zero)+c
  rows.append({j:c for j,c in v.items() if c});source.append([i,list(shift)])
assert len(rows)==739
p=32003
@functools.lru_cache(maxsize=None)
def mod(c):
 c=s.Rational(c);return int(c.p)%p*pow(int(c.q),-1,p)%p
M=np.zeros((len(rows),557),dtype=np.int64)
for i,row in enumerate(rows):
 for j,c in row.items():M[i,j]=sum(mod(v)*pow(2,m[1],p)*pow(3,m[2],p) for m,v in c.items())%p
rank,rr=elimination_rank(M.T,p);_,cc=elimination_rank(M[rr],p);det=determinant_mod(M[rr][:,cc],p);assert rank==523
out=dict(shape=[739,557],nonzero_entries=sum(len(r) for r in rows),coefficient_terms=sum(len(c) for r in rows for c in r.values()),maximum_core_degree=max(sum(m) for r in rows for c in r.values() for m in c),point=[1,2,3],prime=p,rank=rank,quotient_dimension=557-rank,minor_rows=rr,minor_columns=cc,minor_determinant=det,monomials=mon3,row_sources=source,seconds=time.time()-start)
print({k:out[k] for k in ['shape','nonzero_entries','coefficient_terms','maximum_core_degree','rank','quotient_dimension','seconds']},flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
with Path('/tmp/generic-hyperplane-raw-weight3-macaulay-20261102.in').open('w') as f:
 f.write('739 557\n')
 for row in rows:
  f.write(str(len(row))+'\n')
  for j,c in row.items():f.write(str(j)+' '+str(len(c))+''.join(' '+str(v)+' '+' '.join(map(str,m)) for m,v in c.items())+'\n')

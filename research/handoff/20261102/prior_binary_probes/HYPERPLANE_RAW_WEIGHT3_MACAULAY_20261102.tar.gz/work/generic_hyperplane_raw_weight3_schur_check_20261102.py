from pathlib import Path
import sys,json,time,functools,collections
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank
start=time.time();x=json.loads(Path('work/generic_hyperplane_raw_weight3_macaulay_20261102.json').read_text());found={}
with Path('/tmp/generic-hyperplane-raw-weight3-macaulay-20261102.in').open() as f:
 nr,nc=map(int,f.readline().split())
 for i in range(nr):
  for _ in range(int(f.readline())):
   z=f.readline().split();col=int(z[0]);n=int(z[1]);ts=[(z[2+4*k],tuple(map(int,z[3+4*k:6+4*k]))) for k in range(n)];D=max(map(lambda v:sum(v[1]),ts))
   if D>=3:
    eq,shift=x['row_sources'][i];found[(eq,col)]=(D,ts,shift)
max4=[(eq,col,D,shift,ts) for (eq,col),(D,ts,shift) in found.items() if D==4]
print('HIGH_CORE_ROWS',sorted(set(k[0] for k in found)),'N4',len(max4),flush=True)
for z in max4[:3]:print('DEGREE4_EXAMPLE',z,flush=True)
p=32003
@functools.lru_cache(maxsize=None)
def mod(c):
 if '/' in c:n,d=map(int,c.split('/'));return n%p*pow(d%p,-1,p)%p
 return int(c)%p
power2=[pow(2,k,p) for k in range(50)];power3=[pow(3,k,p) for k in range(50)]
with Path('/tmp/generic-hyperplane-raw-weight3-unit-schur-20261102.out').open() as f:
 nr,nc,piv=map(int,f.readline().split());rr=list(map(int,f.readline().split()));cc=list(map(int,f.readline().split()));M=np.zeros((nr,nc),dtype=np.int64)
 for i in range(nr):
  for _ in range(int(f.readline())):
   z=f.readline().split();j=int(z[0]);n=int(z[1]);M[i,j]=sum(mod(z[2+4*k])*power2[int(z[4+4*k])]*power3[int(z[5+4*k])] for k in range(n))%p
rank,_=elimination_rank(M,p);assert rank+piv==523
print('FINAL_RANK',rank,'PLUS',piv,'=',523,'SECONDS',time.time()-start,flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps(dict(prime=p,point=[1,2,3],constant_pivots=piv,remaining_shape=[nr,nc],remaining_rank=rank,total_rank=rank+piv,degree4_examples=max4[:3],high_core_equation_ids=sorted(set(k[0] for k in found)),seconds=time.time()-start),indent=2)+'\n')

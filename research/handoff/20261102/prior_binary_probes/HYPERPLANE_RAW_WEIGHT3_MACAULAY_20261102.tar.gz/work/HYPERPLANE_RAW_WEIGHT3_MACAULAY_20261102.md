# Original-equation weighted degree-three matrix

This is a bounded construction and measurement, not a new all-core rank-cover
claim. It avoids implicit Taylor expansion.

The old chart's three transverse cuts are exactly z5,z19,z23. The latter two
have weight zero and are set to zero. The former has weight one and is retained
as an extra original linear equation. The remaining variables of weights 1,2,3
number 12,15,13. Thus the weighted degree-three columns are
364 light cubics + 180 light-times-weight-two monomials + 13 weight-three
variables = 557.

All five weight-one equations (including the cut) are multiplied by all 93
weight-two monomials, all twenty original weight-two equations by the twelve
light variables, and all thirty-four original weight-three equations are kept.
This gives 739 rows. The coefficients are extracted directly from Jz+H(z,z)
using the original 135 specialized equations.

The matrix has 13,819 nonzero entries and 17,657 core monomials. Its maximum
core degree is FOUR, rather than the initially anticipated two. The sole
degree-four entry is the homogenizer coefficient in original row134 (G6).
Rows90,92,99,102,120,122,129,132 also have cubic core coefficients. The complete
exceptional example is saved in the check report.

At (a,e,d)=(1,2,3) modulo 32003, the exact rank is 523, so the quotient has
dimension34. A nonzero523minor is saved. This reproduces the known implicit
weighted degree-three dimension without performing an implicit expansion.

A sparse constant-QQ-only pivot elimination using a Markowitz ordering removes
379 units in0.51seconds. The remaining285 x178 matrix has rank144 at the same
point, verified separately, so totalrank523 is preserved. Unfortunately its
coefficients grow to588,636 terms and coredegree21. A second ordering that
prioritizes predicted coefficientdegree is worse:371pivots,299 x186,
2,330,217terms, coredegree26,4.48seconds. No further unchanged elimination
attempt is made. The original low-degree739row presentation is the recommended
candidate for subsequent structured/module elimination.

Files use the stem `generic_hyperplane_raw_weight3_..._20261102` in work/.
The original input is reconstructed by the Python macaulay producer and stored
in `/tmp/generic-hyperplane-raw-weight3-macaulay-20261102.in`.
Its native sparse format is nr nc, then for eachrow row_nn, followed by
`column poly_nn rational a_exp e_exp d_exp ...` for each nonzeroentry.
No frozen source or state file was modified.

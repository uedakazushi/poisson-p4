from pathlib import Path
import sys,json,functools
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
p=32003;src=Path(sys.argv[1]);out=Path(sys.argv[2]);poly=[]
@functools.lru_cache(None)
def mod(c):
 if '/' in c:
  a,b=map(int,c.split('/'));assert b%p;return a%p*pow(b%p,-1,p)%p
 return int(c)%p
lines=src.read_text().splitlines();n,m=map(int,lines[0].split());M=[]
for line in lines[1:]:
 z=line.split();nt=int(z[0]);assert len(z)==1+3*nt
 M.append(sum(mod(z[1+3*i])*pow(2,int(z[2+3*i]),p)*pow(3,int(z[3+3*i]),p) for i in range(nt))%p)
M=np.array(M,dtype=np.int64).reshape(n,m);rank,cols=elimination_rank(M,p);_,rows=elimination_rank(M[:,cols].T,p);free=[i for i in range(m) if i not in cols];det=determinant_mod(M[np.ix_(rows,cols)],p)
out.write_text(f'{n} {m} {rank} {len(free)}\n'+' '.join(map(str,rows))+'\n'+' '.join(map(str,cols))+'\n'+' '.join(map(str,free))+'\n'+'\n'.join(lines[1:])+'\n')
r=dict(rank=rank,free=free,rows=rows,columns=cols,minor_at_a2_e3=det,source=str(src));Path(str(out)+'.json').write_text(json.dumps(r,indent=2)+'\n');print(r,flush=True)

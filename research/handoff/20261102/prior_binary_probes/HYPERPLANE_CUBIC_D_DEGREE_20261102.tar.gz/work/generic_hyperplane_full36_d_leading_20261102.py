from pathlib import Path
import json,time,sys,functools
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank
start=time.time();p=32003;src=Path('/tmp/hyperplane-full-cubic-schur36-input.txt')
meta=json.loads(Path('work/generic_hyperplane_full36_mod_input_20261102.json').read_text())['choices'][0];rr=meta['rows'];cc=meta['columns']
with src.open() as f:
 nr,nc,n=map(int,f.readline().split());full=[]
 for i in range(nr):
  row=[]
  for j in range(nc):
   z=f.readline().split();row.append([(tuple(map(int,z[2+4*t:5+4*t])),z[1+4*t]) for t in range(int(z[0]))])
  full.append(row)
A=[[full[i][j] for j in cc] for i in rr];deg=[[max([m[2] for m,c in q],default=-100000) for q in row] for row in A]
u=[0]*(n+1);v=[0]*(n+1);match=[0]*(n+1);way=[0]*(n+1)
for i in range(1,n+1):
 match[0]=i;j0=0;minv=[10**9]*(n+1);used=[False]*(n+1)
 while True:
  used[j0]=True;i0=match[j0];delta=10**9;j1=0
  for j in range(1,n+1):
   if not used[j]:
    cur=-deg[i0-1][j-1]-u[i0]-v[j]
    if cur<minv[j]:minv[j]=cur;way[j]=j0
    if minv[j]<delta:delta=minv[j];j1=j
  for j in range(n+1):
   if used[j]:u[match[j]]+=delta;v[j]-=delta
   else:minv[j]-=delta
  j0=j1
  if match[j0]==0:break
 while True:
  j1=way[j0];match[j0]=match[j1];j0=j1
  if j0==0:break
rw=[-q for q in u[1:]];cw=[-q for q in v[1:]];upper=sum(rw)+sum(cw)
assert all(rw[i]+cw[j]>=deg[i][j] for i in range(n) for j in range(n));assert upper==sum(deg[match[j]-1][j-1] for j in range(1,n+1))
lead=[[[(m[:2],c) for m,c in A[i][j] if m[2]==rw[i]+cw[j]] for j in range(n)] for i in range(n)]
@functools.lru_cache(None)
def mod(c):
 if '/' in c:
  x,y=map(int,c.split('/'));assert y%p;return x%p*pow(y%p,-1,p)%p
 return int(c)%p
M=np.array([[sum(mod(c)*pow(2,m[0],p)*pow(3,m[1],p) for m,c in q)%p for q in row] for row in lead],dtype=np.int64)
rank,cols=elimination_rank(M,p);_,rows=elimination_rank(M[:,cols].T,p);free=[i for i in range(n) if i not in cols]
path=Path('/tmp/generic-hyperplane-full36-d-leading-20261102.in')
with path.open('w') as f:
 f.write(f'{n} {n} {rank} {len(free)}\n'+' '.join(map(str,rows))+'\n'+' '.join(map(str,cols))+'\n'+' '.join(map(str,free))+'\n')
 for row in lead:
  for q in row:f.write(str(len(q))+''.join(' '+c+' '+' '.join(map(str,m)) for m,c in q)+'\n')
# Full d-infinity polynomial matrix, variables a,e,delta.
with Path('/tmp/generic-hyperplane-full36-d-infinity-20261102.in').open('w') as f:
 f.write(f'{n} {n}\n')
 for i,row in enumerate(A):
  for j,q in enumerate(row):f.write(str(len(q))+''.join(' '+c+f' {m[0]} {m[1]} {rw[i]+cw[j]-m[2]}' for m,c in q)+'\n')
out=dict(hungarian_upper=upper,modular_determinant_degree=79,required_order=upper-79,row_weights=rw,column_weights=cw,leading_sample_a_e=[2,3],leading_modular_rank=rank,kernel_dimension_at_sample=len(free),rows=rows,columns=cols,free=free,leading_terms=sum(len(q) for row in lead for q in row),leading_max_core_degree=max(sum(m) for row in lead for q in row for m,c in q),seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(out,flush=True)

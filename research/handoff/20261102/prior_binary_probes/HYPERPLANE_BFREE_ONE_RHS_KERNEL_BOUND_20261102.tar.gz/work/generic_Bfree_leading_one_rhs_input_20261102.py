from pathlib import Path
from fractions import Fraction
import json,numpy as np,time,hashlib
start=time.time();p=32003;meta_path=Path('work/generic_Bfree_leading_kernel_input_20261102.json');meta=json.loads(meta_path.read_text());src=Path('/tmp/generic-Bfree-leading-kernel-20261102.in')
with src.open() as f:
 nr,nc,rk,nf=map(int,f.readline().split());rr=list(map(int,f.readline().split()));cc=list(map(int,f.readline().split()));ff=list(map(int,f.readline().split()));lines=f.readlines();assert len(lines)==nr*nc
A=np.zeros((nr,nc),dtype=np.int64)
for pos,line in enumerate(lines):
 z=line.split();ct=int(z[0]);assert len(z)==1+3*ct;v=0
 for j in range(ct):
  c=Fraction(z[1+3*j]);assert c.denominator%p;v=(v+c.numerator*pow(c.denominator,-1,p)*pow(2,int(z[3+3*j]),p))%p
 A[pos//nc,pos%nc]=v
Aug=A[np.ix_(rr,cc+ff)].copy()
for i in range(rk):
 hits=np.flatnonzero(Aug[i:,i]);assert len(hits);j=i+int(hits[0]);Aug[[i,j]]=Aug[[j,i]];Aug[i]=Aug[i]*pow(int(Aug[i,i]),-1,p)%p
 for j in range(rk):
  if j!=i and Aug[j,i]:Aug[j]=(Aug[j]-int(Aug[j,i])*Aug[i])%p
assert np.array_equal(Aug[:,:rk],np.eye(rk,dtype=np.int64));K=np.zeros((nc,nf),dtype=np.int64)
for j,f in enumerate(ff):K[f,j]=1;K[cc,j]=-Aug[:,rk+j]%p
assert not np.any(A@K%p)
support=np.count_nonzero(K,axis=0);choice=min(range(nf),key=lambda j:(int(support[j]),ff[j]));free=ff[choice]
out=Path('/tmp/generic-Bfree-leading-one-rhs-20261102.in')
with out.open('w') as f:f.write(f'{nr} {nc} {rk} 1\n'+' '.join(map(str,rr))+'\n'+' '.join(map(str,cc))+'\n'+str(free)+'\n'+''.join(lines))
rep=dict(scope='Choose one sparse finite-field normalized kernel direction for a single bounded QQ(a,e) solve; no all-kernel repetition.',selected_free_column=free,selected_free_position=choice,selected_GF_support=int(support[choice]),GF_kernel_sparse=[[i,int(v)] for i,v in enumerate(K[:,choice]) if v],all_GF_supports=[dict(free_column=f,support=int(support[i])) for i,f in enumerate(ff)],all_GF_kernel_identities_checked=True,input=str(out),input_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),source_hashes={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),meta_path,src]},seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(rep,indent=2)+'\n');print({k:rep[k] for k in ['selected_free_column','selected_free_position','selected_GF_support','seconds']})

#include <flint/nmod_mat.h>
#include <fstream>
#include <iostream>
#include <cassert>
int main(int argc,char**argv){assert(argc==3);std::ifstream in(argv[1]);std::ofstream out(argv[2]);assert(in&&out);unsigned long p;int count;in>>p>>count;for(int k=0;k<count;k++){int n;in>>n;nmod_mat_t A;nmod_mat_init(A,n,n,p);for(int i=0;i<n;i++)for(int j=0;j<n;j++){unsigned long v;in>>v;assert(v<p);nmod_mat_entry(A,i,j)=v;}assert(in);auto det=nmod_mat_det(A);assert(det);out<<n<<' '<<det<<'\n';nmod_mat_clear(A);}out.flush();assert(out.good());flint_cleanup();}

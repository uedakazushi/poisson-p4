from pathlib import Path
from fractions import Fraction
import json,hashlib,itertools,subprocess,os,tempfile,time
import numpy as np
start=time.time();root=Path.cwd();p=32003;point=[1,2,3]
source=Path('work/generic_hyperplane_Bfree_quadratic_small_rows_20261102.txt');oldpath=Path('work/generic_hyperplane_Bfree_quadratic_isotrivial_probe_20261102.json');old=json.loads(oldpath.read_text());mons=[tuple(x) for x in old['monomials']];index={m:i for i,m in enumerate(mons)};light=old['light_positions']
rows=[];derivatives=[];labels=[];denominators=set();universal_checks=0
with source.open() as f:
 for _ in range(int(f.readline())):
  label,weight,count=map(int,f.readline().split());assert weight==2
  row=np.zeros(28,dtype=np.int64);der=np.zeros((28,3),dtype=np.int64);kernel_image={}
  for j in range(count):
   mon=tuple(map(int,f.readline().split()));words=f.readline().split();n=int(words[0]);assert len(words)==1+4*n;assert mon[5]==0 and sum(mon)==2
   mm=tuple(mon[i] for i in light);col=index[mm]
   for k in range(n):
    c=Fraction(words[1+4*k]);ex=tuple(map(int,words[2+4*k:5+4*k]));denominators.add(c.denominator);assert c.denominator%p
    # Full rational coefficient of (I7,-2I6) acting on this quadric.
    value=sum((c*m for m in mm),Fraction(0))-2*c
    key=(mm,ex);kernel_image[key]=kernel_image.get(key,Fraction(0))+value;universal_checks+=1
    cv=c.numerator*pow(c.denominator,-1,p)%p
    for b,z in zip(point,ex):cv=cv*pow(b,z,p)%p
    row[col]=(row[col]+cv)%p
    for h in range(3):
     if ex[h]:der[col,h]=(der[col,h]+cv*ex[h]*pow(point[h],-1,p))%p
  assert all(v==0 for v in kernel_image.values());rows.append(row);derivatives.append(der);labels.append(label)
Q=np.array(rows,dtype=np.int64);rhs=np.vstack(derivatives);assert np.array_equal(Q,np.array(old['quadric_values']));assert np.array_equal(rhs,np.array(old['parameter_derivative_values']));assert len(rows)==6
A=np.zeros((168,85),dtype=np.int64)
for i,row in enumerate(Q):
 for mm,c in zip(mons,row):
  for r in range(7):
   if not mm[r]:continue
   for ss in range(7):
    nn=list(mm);nn[r]-=1;nn[ss]+=1;j=index[tuple(nn)]
    A[28*i+j,7*r+ss]=(A[28*i+j,7*r+ss]+int(c)*mm[r])%p
for i in range(6):
 for j in range(6):A[28*i:28*(i+1),49+6*i+j]=Q[j]
null=np.zeros(85,dtype=np.int64)
for i in range(7):null[8*i]=1
for i in range(6):null[49+7*i]=-2
assert not np.any(A@null%p)
def independent_columns(M):
 M=M.copy();rr=0;piv=[]
 for j in range(M.shape[1]):
  ids=np.flatnonzero(M[rr:,j])
  if not len(ids):continue
  z=rr+int(ids[0]);M[[rr,z]]=M[[z,rr]];M[rr]=M[rr]*pow(int(M[rr,j]),-1,p)%p
  for i in range(rr+1,M.shape[0]):
   if M[i,j]:M[i]=(M[i]-int(M[i,j])*M[rr])%p
  piv.append(j);rr+=1
  if rr==M.shape[0]:break
 return piv
# Python forward elimination is checked below by FLINT's determinant implementation.
def determinant(M):
 M=M.copy();answer=1
 for j in range(len(M)):
  ids=np.flatnonzero(M[j:,j]);assert len(ids);k=j+int(ids[0])
  if k!=j:M[[j,k]]=M[[k,j]];answer=-answer
  v=int(M[j,j]);answer=answer*v%p;inv=pow(v,-1,p)
  for i in range(j+1,len(M)):
   if M[i,j]:M[i]=(M[i]-int(M[i,j])*inv%p*M[j])%p
 return answer%p
minors={};matrices=[]
for name,M,expected in [('orbit',A,84),('orbit_and_core_derivatives',np.column_stack([A,rhs]),87)]:
 cols=independent_columns(M);rr=independent_columns(M[:,cols].T);assert len(cols)==len(rr)==expected
 N=M[np.ix_(rr,cols)];value=determinant(N);assert value;matrices.append(N)
 minors[name]=dict(rows=rr,columns=cols,size=expected,residue_python=value)
cpp=Path('work/generic_hyperplane_orbit_minor_check_20261102.cpp')
with tempfile.TemporaryDirectory(prefix='poisson-orbit-minors-') as td:
 wd=Path(td);infile=wd/'matrices';outfile=wd/'determinants';binary=wd/'native'
 with infile.open('w') as f:
  f.write(f'{p} {len(matrices)}\n')
  for M in matrices:f.write(str(len(M))+'\n'+'\n'.join(' '.join(map(str,row)) for row in M)+'\n')
 command=['clang++','-O3','-std=c++17','-I'+str(root/'work/flint-headers/flint/3.5.0/include'),'-I/opt/homebrew/include',str(cpp),str(root/'work/m2-runtime/lib/libflint.24.0.dylib'),'-L/opt/homebrew/lib','-lgmp','-o',str(binary)]
 subprocess.run(command,check=True,capture_output=True,text=True)
 env=os.environ.copy();env['DYLD_LIBRARY_PATH']=str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'
 subprocess.run([str(binary),str(infile),str(outfile)],env=env,check=True,capture_output=True,text=True)
 values=[list(map(int,line.split())) for line in outfile.read_text().splitlines()];assert len(values)==2
 for cert,(n,v) in zip(minors.values(),values):assert n==cert['size'] and v==cert['residue_python'];cert['residue_independent_flint']=v
openvalues={'a':1,'F':842,'D0':86,'C':152};assert all(v%p for v in openvalues.values())
paths=[Path(__file__),cpp,source,oldpath,Path('work/generic_hyperplane_Bfree_quadratic_small_rows_20261102.json')]
out=dict(scope='Characteristic-zero generic rank obstruction for the six explicit quadratic forms supplied in the pinned cache. No claim on nonlinear equivalence, quartics, or ambient S61.',prime=p,point=dict(zip(['a','e','d'],point)),source_rows=labels,universal_kernel=null.tolist(),universal_kernel_meaning='GL7 identity plus GL6 -2 identity, verified in QQ coefficientwise by Euler degree2 identity.',universal_kernel_QQ_coefficients_verified=universal_checks,orbit_rank_upper_all_points=84,combined_rank_upper_all_points=87,minors=minors,generic_orbit_rank_QQ=84,generic_combined_rank_QQ=87,generic_core_derivative_classes_independent=True,coefficient_denominators_all_prime_units=True,distinct_denominator_count=len(denominators),open_values_at_witness=openvalues,numeric_data_recomputed_from_small_QQ_input=True,determinants_independently_checked=True,limitations=['Small QQ coefficient input is copied exactly from the supplied B-free low-row cache; raw135-to-quadrics reconstruction is not repeated here.','The conclusion concerns linear GL7 variable and GL6 generator changes only.','No assertion about actual isomorphisms of the full implicit schemes or higher-weight equations.'],input_sha256={str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in paths},seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['generic_orbit_rank_QQ','generic_combined_rank_QQ','universal_kernel_QQ_coefficients_verified','seconds']},indent=2));print({name:(c['size'],c['residue_python'],c['residue_independent_flint']) for name,c in minors.items()})

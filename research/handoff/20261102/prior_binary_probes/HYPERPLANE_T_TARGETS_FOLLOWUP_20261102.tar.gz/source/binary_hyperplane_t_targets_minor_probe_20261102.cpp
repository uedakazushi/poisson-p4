#include <flint/nmod_poly.h>
#include <flint/nmod_poly_mat.h>
#include <flint/nmod_poly_factor.h>
#include <flint/ulong_extras.h>
#include <vector>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <tuple>
#include <cassert>
#include <chrono>
using namespace std;ulong prime=32003;
struct Poly{nmod_poly_t p;Poly(){nmod_poly_init(p,prime);}Poly(const Poly&a):Poly(){nmod_poly_set(p,a.p);}Poly(Poly&&a):Poly(){nmod_poly_swap(p,a.p);}Poly&operator=(Poly a){nmod_poly_swap(p,a.p);return *this;}~Poly(){nmod_poly_clear(p);}};
using Row=vector<Poly>;
Row read(istream&in,int n){Row r(n);int count;in>>count;for(int z=0;z<count;z++){int j,len;in>>j>>len;for(int k=0;k<len;k++){ulong c;in>>c;nmod_poly_set_coeff_ui(r[j].p,k,c);}}assert(in);return r;}
int main(int argc,char**argv){assert(argc==3);ifstream in(argv[1]);ofstream out(argv[2]);assert(in&&out);int nr,n,nt;in>>prime>>nr>>n>>nt;ulong b0,b1;in>>b0>>b1;auto start=chrono::steady_clock::now();vector<Row>A;vector<tuple<int,int,int>>order;for(int i=0;i<nr;i++){A.push_back(read(in,n));int deg=-1,nz=0;for(auto&p:A.back()){deg=max(deg,(int)nmod_poly_degree(p.p));nz+=nmod_poly_length(p.p);}order.emplace_back(deg,nz,i);}sort(order.begin(),order.end());vector<vector<ulong>>basis(n);vector<int>selected;for(auto[deg,nz,i]:order){vector<ulong>v(n);for(int j=0;j<n;j++)v[j]=nmod_poly_evaluate_nmod(A[i][j].p,3);for(int j=0;j<n;j++)if(v[j]){if(basis[j].empty()){ulong inv=n_invmod(v[j],prime);for(int k=j;k<n;k++)v[k]=v[k]*inv%prime;basis[j]=v;selected.push_back(i);break;}ulong c=v[j];for(int k=j;k<n;k++)v[k]=(v[k]+prime-c*basis[j][k]%prime)%prime;}if((int)selected.size()==n)break;}assert(selected.size()==n);out<<"SELECTED "<<n<<'\n';for(int i:selected)out<<i<<' ';out<<'\n';out.flush();nmod_poly_mat_t M;nmod_poly_mat_init(M,n,n,prime);for(int i=0;i<n;i++)for(int j=0;j<n;j++)nmod_poly_set(nmod_poly_mat_entry(M,i,j),A[selected[i]][j].p);Poly det;nmod_poly_mat_det_interpolate(det.p,M);cerr<<"DET_DEG "<<nmod_poly_degree(det.p)<<" SEC "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';nmod_poly_factor_t fac;nmod_poly_factor_init(fac);nmod_poly_factor(fac,det.p);out<<"DET_DEG "<<nmod_poly_degree(det.p)<<" FACTORS "<<fac->num<<'\n';for(int i=0;i<fac->num;i++){out<<"FACTOR "<<fac->exp[i]<<' '<<nmod_poly_length(fac->p+i);for(int j=0;j<nmod_poly_length(fac->p+i);j++)out<<' '<<nmod_poly_get_coeff_ui(fac->p+i,j);out<<'\n';}out<<"SECONDS "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<'\n';out.flush();nmod_poly_factor_clear(fac);nmod_poly_mat_clear(M);}

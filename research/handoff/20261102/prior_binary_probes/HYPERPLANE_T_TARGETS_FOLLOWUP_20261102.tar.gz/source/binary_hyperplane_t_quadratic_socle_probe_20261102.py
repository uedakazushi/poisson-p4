from pathlib import Path
import subprocess,os,json,time
start=time.time();text=Path('work/binary_hyperplane_t_targets_univariate_20261102.py').read_text();text=text[:text.index('path=Path(')];exec(text)
light=[0,1,2,3,4,6,7]
def evaluate(q):return sum(c*pow(3,d,p) for d,c in q.items())%p
def expr(row):
 z=[]
 for m,q in row.items():
  c=evaluate(q)
  if c:
   assert m[5]==0;z.append(str(c)+''.join('*x'+str(i)+(f'^{m[j]}' if m[j]>1 else '') for i,j in enumerate(light) if m[j]))
 return '+'.join(z) or '0'
qs=[]
with (wd/'rows').open() as f:
 for _ in range(int(f.readline())):
  idx,w,ct=map(int,f.readline().split());q={}
  for __ in range(ct):m=tuple(map(int,f.readline().split()));q[m]=poly(f.readline().split())
  if w==2:qs.append(q)
src='R=ZZ/32003[x0,x1,x2,x3,x4,x5,x6,MonomialOrder=>GRevLex];\nI=ideal('+','.join(map(expr,qs))+');\nt='+expr(t)+';\n'
src+='<<"DIM "<<dim(R/I)<<" DEGREE "<<degree(R/I)<<endl; <<"HF "<<apply(0..6,d->hilbertFunction(d,R/I))<<endl; C=I:ideal(t); <<"COLON_GENS "<<toString gens C<<endl; <<"TCHECK "<<apply(0..6,i->(t*R_i)%(gb I)==0_R)<<endl; <<"T_IN "<<(t%(gb I)==0_R)<<endl;\n'
path=Path('/tmp/hyperplane-t-quadratic-socle-probe-20261102.m2');path.write_text(src)
env=os.environ|{'DYLD_LIBRARY_PATH':str(Path('work/m2-runtime/lib').resolve())+':/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'}
try:
 cp=subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',str(path)],env=env,capture_output=True,text=True,timeout=45);out=dict(returncode=cp.returncode,stdout=cp.stdout,stderr=cp.stderr,seconds=time.time()-start)
except subprocess.TimeoutExpired as ex:out=dict(timeout=45,stdout=str(ex.stdout),seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

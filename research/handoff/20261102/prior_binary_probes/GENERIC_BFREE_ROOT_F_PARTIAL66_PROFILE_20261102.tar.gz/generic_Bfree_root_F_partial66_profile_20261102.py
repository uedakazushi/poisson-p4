from pathlib import Path
from fractions import Fraction
import json,time,hashlib,sys
import numpy as np
sys.path.insert(0,str(Path('code').resolve()))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod

start=time.time();p=32003;n=238;priorpath=Path('work/generic_Bfree_root_F_sparse_left_20261102.json');prior=json.loads(priorpath.read_text());cert=[q for q in prior['kernels']if q['status']=='exact_all238_identities_pass'];assert len(cert)==66
wd=Path('/tmp/generic-Bfree-root-F-sparse-left-20261102');jetpath=Path('/tmp/generic-Bfree-vertical-root-F-20261102.in');rootreport=Path('work/generic_Bfree_vertical_knownroot_profiles_20261102.json');rootdata=json.loads(rootreport.read_text());assert hashlib.sha256(jetpath.read_bytes()).hexdigest()==rootdata['input_sha256'][str(jetpath)]
lead=Path('/tmp/binary-Bfree-root-20261102-F.leading');assert hashlib.sha256(lead.read_bytes()).hexdigest()==prior['input_sha256'][str(lead)]
def evaluate(line):
    z=line.split();nn=int(z[0]);assert len(z)==1+3*nn;value=0
    for k in range(nn):
        q=Fraction(z[1+3*k]);xx,e=map(int,z[2+3*k:4+3*k]);assert xx==0 and q.denominator%p;value=(value+q.numerator*pow(q.denominator,-1,p)*pow(2,e,p))%p
    return value
it=iter(map(int,jetpath.read_text().split()));assert [next(it)for _ in range(4)]==[p,n,n,32];A0=np.zeros((n,n),dtype=np.int64);A1=A0.copy()
for i in range(n):
    for j in range(n):
        length=next(it);co=[next(it)for _ in range(length)]
        if length:A0[i,j]=co[0]
        if length>1:A1[i,j]=co[1]
assert next(it,None)is None
ls=lead.read_text().splitlines();assert ls[0]=='238 238';assert len(ls)==1+n*n
assert np.array_equal(A0,np.array([evaluate(z)for z in ls[1:]],dtype=np.int64).reshape(n,n))
anchors=[q['anchor']for q in cert];assert len(set(anchors))==66;complement=[j for j in range(n)if j not in anchors];K=np.zeros((66,n),dtype=np.int64);anchorvalues=[];paths=[Path(__file__),priorpath,rootreport,jetpath,lead]
for idx,c in enumerate(cert):
    output=wd/f"kernel{c['index']}";assert hashlib.sha256(output.read_bytes()).hexdigest()==prior['input_sha256'][str(output)];paths.append(output);z=output.read_text().splitlines();assert z[0]=='KERNEL 0';den=evaluate(z[1]);assert den and len(z)==2+len(c['output_component_order']);anchorvalues.append(den)
    for j,line in zip(c['output_component_order'],z[2:]):K[idx,j]=evaluate(line)
assert np.array_equal(K[:,anchors],np.diag(anchorvalues))
assert not np.any(K@A0%p)
T=np.concatenate([np.eye(n,dtype=np.int64)[complement],K]);detT=int(determinant_mod(T,p));assert detT
permutation=complement+anchors;sign=-1 if sum(permutation[i]>permutation[j]for i in range(n)for j in range(i+1,n))%2 else 1;pred=sign
for q in anchorvalues:pred=pred*q%p
assert detT==pred
# Complement rows remain unchanged; the66 certified kernel rows are divided
# bydelta. Their leading terms are exactly K*A1 because K*A0=0.
B0=np.concatenate([A0[complement],K@A1%p]);rank,columns=elimination_rank(B0,p);_,rows=elimination_rank(B0[:,columns].T,p);minor=int(determinant_mod(B0[np.ix_(rows,columns)],p));assert minor
R=B0.T.copy();piv=[]
for col in range(n):
    r=len(piv);found=np.flatnonzero(R[r:,col])
    if not len(found):continue
    i=r+int(found[0]);R[[r,i]]=R[[i,r]];R[r]=R[r]*pow(int(R[r,col]),-1,p)%p
    ids=np.flatnonzero(R[:,col]);ids=ids[ids!=r];R[ids]=(R[ids]-R[ids,col,None]*R[r,None,:])%p;piv.append(col)
assert len(piv)==rank and not np.any(R[rank:]);free=[j for j in range(n)if j not in piv];kernels=[]
for a in free:
    v=np.zeros(n,dtype=np.int64);v[a]=1;v[piv]=-R[:rank,a]%p;assert not np.any(v@B0%p)
    support=np.flatnonzero(v).tolist();kernels.append({'anchor_in_new_row_basis':a,'support':support,'coefficients_on_support':[int(v[j])for j in support],'complement_part':[j for j in support if j<172],'certified_kernel_part':[j-172 for j in support if j>=172]})
report={'scope':'One F32003 e2,d3 partial left peel using ONLY66 certified QQ left kernels. No assumption on three unproved original kernels, no new QQ identities or F^70 claim.','prime':p,'certified_kernel_count':66,'original_leading_equals_supplied_QQ_e_specialization':True,'all66x238_constant_products_zero':True,'delta_division_checked_for66_rows':True,'original_free_anchors_in_kernel_order':anchors,'complement_standard_rows':complement,'anchor_values':anchorvalues,'row_basis_determinant_modp':detT,'predicted_signed_anchor_product':pred,'new_leading_shape':[n,n],'new_leading_rank':rank,'new_left_nullity':n-rank,'new_nonzero_minor':{'rows':rows,'columns':columns,'value':minor},'new_left_kernels':kernels,'new_leading_matrix_modp':B0.tolist(),'permutation_of_standard_rows_before_kernel_substitution':permutation,'input_sha256':{str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in paths},'seconds':time.time()-start}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print('RANK',rank,'NULLITY',n-rank,'SUPPORTS',[len(q['support'])for q in kernels],'SECONDS',report['seconds'],flush=True)

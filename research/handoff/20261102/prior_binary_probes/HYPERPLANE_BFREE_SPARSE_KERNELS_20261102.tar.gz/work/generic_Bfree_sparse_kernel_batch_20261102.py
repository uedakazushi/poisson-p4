from pathlib import Path
from fractions import Fraction
import sys,json,time,hashlib,subprocess,os
import numpy as np
root=Path.cwd();sys.path.insert(0,str(root/'code'))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();p=32003;src=Path('/tmp/generic-Bfree-leading-kernel-20261102.in')
with src.open() as f:
 nr,nc,rk,nf=map(int,f.readline().split());rr=list(map(int,f.readline().split()));cc=list(map(int,f.readline().split()));ff=list(map(int,f.readline().split()));lines=f.readlines()
A=np.zeros((nr,nc),dtype=np.int64)
for pos,line in enumerate(lines):
 z=line.split();value=0
 for k in range(int(z[0])):
  c=Fraction(z[1+3*k]);assert c.denominator%p;value=(value+c.numerator*pow(c.denominator,-1,p)*pow(2,int(z[3+3*k]),p))%p
 A[pos//nc,pos%nc]=value
Aug=A[np.ix_(rr,cc+ff)].copy()
for i in range(rk):
 hit=i+int(np.flatnonzero(Aug[i:,i])[0]);Aug[[i,hit]]=Aug[[hit,i]];Aug[i]=Aug[i]*pow(int(Aug[i,i]),-1,p)%p
 for j in range(rk):
  if j!=i and Aug[j,i]:Aug[j]=(Aug[j]-int(Aug[j,i])*Aug[i])%p
K=np.zeros((nc,nf),dtype=np.int64)
for j,f in enumerate(ff):K[f,j]=1;K[cc,j]=-Aug[:,rk+j]%p
assert not np.any(A@K%p);supports=np.count_nonzero(K,axis=0)
choices=[j for j,f in enumerate(ff) if supports[j]<=30 and f!=128]
choices += [min((j for j in range(nf) if supports[j]==82),key=lambda j:ff[j])]
assert len(choices)==3

def readpoly(line):
 z=line.split();n=int(z[0]);assert len(z)==1+3*n
 return {(int(z[2+3*i]),int(z[3+3*i])):Fraction(z[1+3*i]) for i in range(n)}
def poly_mod(q):return sum(c.numerator*pow(c.denominator,-1,p)*pow(2,ex[1],p) for ex,c in q.items())%p
def inspect(output,free,position):
 with output.open() as f:
  assert f.readline().strip()=='KERNEL 0';den=readpoly(f.readline());vec=[readpoly(f.readline()) for _ in range(nc)];assert not f.read().strip()
 assert den and vec[free]==den and all(not vec[j] for j in ff if j!=free)
 good=all(c.denominator%p for q in [den]+vec for c in q.values());dv=poly_mod(den) if good else None;equal=False
 if good and dv:
  reduced=np.array([poly_mod(q)*pow(dv,-1,p)%p for q in vec],dtype=np.int64);equal=np.array_equal(reduced,K[:,position]);assert equal
 return dict(QQ_all238_identities_verified_by_native=True,support=sum(bool(q) for q in vec),total_numerator_terms=sum(len(q) for q in vec),max_numerator_degree=max((sum(ex) for q in vec for ex in q),default=0),denominator_degree=max(sum(ex) for ex in den),denominator_terms=len(den),max_rational_height_bits=max(max(abs(c.numerator).bit_length(),c.denominator.bit_length()) for q in [den]+vec for c in q.values()),all_rational_denominators_prime_units=good,free_denominator_at_point=dv,normalized_modular_vector_matches=equal,output_sha256=hashlib.sha256(output.read_bytes()).hexdigest())
results=[];env=os.environ.copy();env['DYLD_LIBRARY_PATH']=str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'
first=Path('/tmp/generic-Bfree-sparse-kernel-20261102.out');firstmeta=inspect(first,128,ff.index(128));results.append(dict(free_column=128,status='previous_complete',output=str(first),**firstmeta));print('PREVIOUS128',firstmeta,flush=True)
for pos in choices:
 free=ff[pos];unknown=[i for i,v in enumerate(K[:,pos]) if v and i!=free];rank,pivrows=elimination_rank(A[:,unknown].T,p);assert rank==len(unknown);assert all(j in cc for j in unknown)
 ip=Path(f'/tmp/generic-Bfree-sparse-kernel-{free}-20261102.in');op=Path(f'/tmp/generic-Bfree-sparse-kernel-{free}-20261102.out');log=Path(f'work/generic_Bfree_sparse_kernel_{free}_20261102.log')
 with ip.open('w') as f:f.write(f'{nr} {nc} {rank} 1\n'+' '.join(map(str,pivrows))+'\n'+' '.join(map(str,unknown))+'\n'+str(free)+'\n'+''.join(lines))
 st=time.time();status='complete';returncode=None
 with log.open('w') as out:
  try:
   r=subprocess.run(['/tmp/generic-Bfree-leading-kernel-bounded-20261102',str(ip),str(op)],env=env,stdout=out,stderr=out,timeout=min(10,max(.1,60-(time.time()-start))));returncode=r.returncode
   if r.returncode:status='failed_or_guard'
  except subprocess.TimeoutExpired:status='wall10_timeout'
 item=dict(free_column=free,GF_support=int(supports[pos]),unknown_columns=unknown,pivot_rows=pivrows,pivot_minor_mod_p=determinant_mod(A[np.ix_(pivrows,unknown)],p),status=status,returncode=returncode,seconds=time.time()-st,input=str(ip),input_sha256=hashlib.sha256(ip.read_bytes()).hexdigest(),output=str(op),log=str(log))
 if status=='complete':item.update(inspect(op,free,pos))
 results.append(item);print('CASE',{k:v for k,v in item.items() if k not in ['unknown_columns','pivot_rows']},flush=True)
 if time.time()-start>60:break
report=dict(scope='Sparse finite-field supports are used only as candidates. Each successful QQ(a,e) kernel is checked against every original238 leading row. No full-delta product, no all75-kernel claim.',prime=p,point=[1,2],field_rank_lower=163,first163_pivot_minor_mod_p=29761,GF_support_distribution={str(x):int(sum(supports==x)) for x in sorted(set(supports))},cases=results,successful_kernel_count=sum(x['status'] in ['complete','previous_complete'] for x in results),successful_vectors_have_distinct_free_unit_positions=True,seconds=time.time()-start,source_hashes={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),src,Path('work/generic_Bfree_leading_kernel_bounded_20261102.cpp'),Path('code/s61_binary_deeper_cubic_field_20261101.hpp')]})
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')

from pathlib import Path
from fractions import Fraction
import json,time,hashlib,sys
import numpy as np
root=Path.cwd();sys.path.insert(0,str(root/'code'))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();p=32003;meta_path=Path('work/generic_Bfree_leading_one_rhs_input_20261102.json');meta=json.loads(meta_path.read_text());free=meta['selected_free_column'];support=[i for i,v in meta['GF_kernel_sparse']];unknown=[i for i in support if i!=free];src=Path('/tmp/generic-Bfree-leading-kernel-20261102.in')
with src.open() as f:
 nr,nc,rk,nf=map(int,f.readline().split());f.readline();oldcols=list(map(int,f.readline().split()));f.readline();lines=f.readlines()
assert len(unknown)==20 and all(i in oldcols for i in unknown);A=np.zeros((nr,len(unknown)),dtype=np.int64)
for i in range(nr):
 for t,j in enumerate(unknown):
  z=lines[i*nc+j].split();v=0
  for k in range(int(z[0])):
   c=Fraction(z[1+3*k]);assert c.denominator%p;v=(v+c.numerator*pow(c.denominator,-1,p)*pow(2,int(z[3+3*k]),p))%p
  A[i,t]=v
rank,rows=elimination_rank(A.T,p);assert rank==len(unknown);det=determinant_mod(A[rows,:],p)
out=Path('/tmp/generic-Bfree-sparse-kernel-20261102.in')
with out.open('w') as f:f.write(f'{nr} {nc} {rank} 1\n'+' '.join(map(str,rows))+'\n'+' '.join(map(str,unknown))+'\n'+str(free)+'\n'+''.join(lines))
report=dict(scope='Sparse Ansatz for one kernel: omitted coordinates fixed zero, with all238 rows to be checked exactly by native after solving.',free_column=free,unknown_columns=unknown,pivot_rows=rows,pivot_minor_mod_p=det,point=[1,2],prime=p,input=str(out),input_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),source_hashes={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),meta_path,src]},seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print({k:report[k] for k in ['free_column','unknown_columns','pivot_minor_mod_p','seconds']})

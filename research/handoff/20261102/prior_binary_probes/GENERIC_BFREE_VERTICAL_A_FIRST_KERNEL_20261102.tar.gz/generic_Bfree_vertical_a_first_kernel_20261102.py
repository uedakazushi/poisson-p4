from pathlib import Path
from fractions import Fraction
import functools,json,time,hashlib,os,subprocess
import numpy as np

start=time.time();root=Path.cwd();p=32003;nr=321;nc=238
profile_path=Path('work/generic_Bfree_vertical_a_infinity_20261102.json');profile=json.loads(profile_path.read_text())
core=Path('/tmp/hyperplane-Bfree-t-targets-exact-core-20261102.in');native=Path('code/s61_binary_hyperplane_leading_kernel_20261102.cpp');header=Path('code/s61_binary_deeper_cubic_field_20261101.hpp')
base=Path('/tmp/generic-Bfree-vertical-a-first-kernel-20261102');inp=base.with_suffix('.in');out=base.with_suffix('.out');log=base.with_suffix('.log')
first=profile['stages'][0];assert first['rank']==162
rr=[z[3]for z in first['pivots']];cc=[z[4]for z in first['pivots']];ff=[j for j in range(nc)if j not in cc];assert len(rr)==len(cc)==162 and len(ff)==76
rb=profile['row_bounds'];cb=profile['column_bounds'];lead=[];count=0;degree=[]
@functools.lru_cache(None)
def rational(c):return Fraction(c)
def mod(c):
    assert c.denominator%p
    return c.numerator*pow(c.denominator,-1,p)%p
with core.open()as f:
    assert list(map(int,f.readline().split()))==[328,238,321]
    for i in range(328):
        deg=[]
        for j in range(nc):
            z=f.readline().split();n=int(z[0]);assert len(z)==1+4*n
            if i>=nr:continue
            values={}
            for k in range(n):
                c=rational(z[1+4*k]);mod(c);aa,ee,dd=map(int,z[2+4*k:5+4*k]);key=(aa,ee);values[key]=values.get(key,Fraction(0))+c*3**dd;count+=1
            values={m:c for m,c in values.items()if c}
            gd=max([aa for aa,ee in values],default=-100000);deg.append(gd)
            assert gd<=rb[i]+cb[j]or gd==-100000
            lead.append({ee:c for (aa,ee),c in values.items()if aa==rb[i]+cb[j]})
        if i<nr:degree.append(deg)
    assert not f.read().strip()
assert degree==profile['generic_entry_a_degrees']
with inp.open('w')as f:
    f.write(f'{nr} {nc} 162 76\n'+' '.join(map(str,rr))+'\n'+' '.join(map(str,cc))+'\n'+' '.join(map(str,ff))+'\n')
    for q in lead:f.write(str(len(q))+''.join(f' {c} 0 {ee}'for ee,c in sorted(q.items()))+'\n')
evallead=np.array([sum(mod(c)*pow(2,ee,p)for ee,c in q.items())%p for q in lead],dtype=np.int64).reshape(nr,nc)
# Independent numeric determinant of the saved first-stage original minor.
def determinant(A):
    A=A.copy();det=1
    for j in range(len(A)):
        ids=np.flatnonzero(A[j:,j]);assert len(ids);k=j+int(ids[0])
        if k!=j:A[[j,k]]=A[[k,j]];det=-det
        v=int(A[j,j]);det=det*v%p;A[j]=A[j]*pow(v,-1,p)%p
        for k in range(j+1,len(A)):
            if A[k,j]:A[k]=(A[k]-int(A[k,j])*A[j])%p
    return det%p
minor=determinant(evallead[np.ix_(rr,cc)])
report={'scope':'One bounded QQ(e) leading-kernel attempt only, at d=3/a infinity. No full delta product, next kernel, or vertical-support theorem.','prime':p,'shape':[nr,nc],'selected_rank':162,'kernel_count':76,'rows':rr,'columns':cc,'free_columns':ff,'pivot_minor_at_e2_modp':minor,'original_generic_entry_degrees_recomputed':True,'original_core_rational_terms':count,'leading_polynomial_terms':sum(map(len,lead)),'maximum_leading_e_degree':max([ee for q in lead for ee in q],default=0),'preparation_seconds':time.time()-start}
print('PREP',report['preparation_seconds'],'TERMS',report['leading_polynomial_terms'],'MAX_E',report['maximum_leading_e_degree'],'MINOR',minor,flush=True)
exe=base.with_suffix('.exe');subprocess.run(['clang++','-O3','-std=c++17','-Icode','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(native),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=30)
env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'};t=time.time()
try:
    cp=subprocess.run([str(exe),str(inp),str(out)],env=env,capture_output=True,text=True,timeout=60)
    log.write_text(cp.stdout+cp.stderr);cp.check_returncode();report['status']='completed'
except subprocess.TimeoutExpired as ex:
    text=(ex.stdout or b'')+(ex.stderr or b'');log.write_bytes(text if isinstance(text,bytes)else text.encode());report['status']='timeout60s'
except subprocess.CalledProcessError:report['status']='native_guard_or_error'
report['native_seconds']=time.time()-t
if report['status']=='completed':
    def readpoly(f):
        z=f.readline().split();n=int(z[0]);assert len(z)==1+3*n;q={}
        for k in range(n):
            c=rational(z[1+3*k]);xx,ee=map(int,z[2+3*k:4+3*k]);assert xx==0;mod(c);q[ee]=c
        return q
    stats=[];anchors=[];E=np.zeros((nc,76),dtype=np.int64)
    with out.open()as f:
        for k in range(76):
            assert f.readline().split()==['KERNEL',str(k)];den=readpoly(f);anchor=sum(mod(c)*pow(2,e,p)for e,c in den.items())%p;assert anchor;anchors.append(anchor)
            polys=[readpoly(f)for _ in range(nc)]
            for j in ff:assert polys[j]==(den if j==ff[k]else {})
            stats.append({'kernel':k,'anchor_e_degree':max(den,default=-1),'nonzero_components':sum(bool(q)for q in polys),'terms':sum(map(len,polys)),'maximum_numerator_e_degree':max([e for q in polys for e in q],default=-1)})
            for j,q in enumerate(polys):E[j,k]=sum(mod(c)*pow(2,e,p)for e,c in q.items())%p
        assert not f.read().strip()
    assert not np.any(evallead@E%p)
    report.update(all321x76_QQ_identities_checked_by_native=True,free_block_diagonal_checked=True,all_kernel_coefficients_p_integral=True,all76_anchors_units_at_e2=True,independent_all321x76_modular_product_zero=True,anchor_values_at_e2_modp=anchors,kernels=stats,output_bytes=out.stat().st_size)
paths=[Path(__file__),profile_path,core,native,header,inp,log]+([out]if out.exists()else [])
report['input_sha256']={str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in paths};report['seconds']=time.time()-start
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print('RESULT',report['status'],'NATIVE',report['native_seconds'],'TOTAL',report['seconds'],flush=True)

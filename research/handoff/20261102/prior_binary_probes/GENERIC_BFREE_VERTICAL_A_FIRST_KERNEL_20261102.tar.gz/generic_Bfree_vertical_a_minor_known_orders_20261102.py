from pathlib import Path
import json,hashlib,time
import sympy as s

start=time.time();source=Path('work/generic_Bfree_vertical_a_infinity_20261102.json');r=json.loads(source.read_text());p=32003;a=s.Symbol('a')
P=s.Poly.from_list(list(reversed(r['direct_minor']['coefficients_ascending'])),a,modulus=p)
assert P.degree()==575 and int(P.LC())%p==16008
known={'a':a,'F':500*a+342,'D0':50*a+36,'C':100*a+52};q=P;orders={}
for name,expression in known.items():
    f=s.Poly(expression,a,modulus=p).monic();k=0
    while not q.rem(f):q=q.exquo(f);k+=1
    orders[name]={'order':k,'monic_factor_coefficients_ascending':[int(f.nth(i))%p for i in range(f.degree()+1)]}
    assert q.rem(f)
product=q
for name,expression in known.items():product*=s.Poly(expression,a,modulus=p).monic()**orders[name]['order']
assert product==P
out={'scope':'Exact F32003 division orders of the selected degree575 determinant only. Unknown residual is not factored; no QQ multiplicity conclusion.','prime':p,'fixed_e':2,'fixed_d':3,'selected_determinant_degree':P.degree(),'selected_determinant_leading_coefficient':int(P.LC())%p,'known_orders':orders,'known_degree_sum':sum(v['order']for v in orders.values()),'residual_degree':q.degree(),'residual_coefficients_ascending':[int(q.nth(i))%p for i in range(q.degree()+1)],'factor_product_checked':True,'residual_coprime_to_each_known_factor':True,'input_sha256':{str(z):hashlib.sha256(z.read_bytes()).hexdigest()for z in [Path(__file__),source]},'seconds':time.time()-start}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print('ORDERS',{k:v['order']for k,v in orders.items()},'RESIDUAL',q.degree(),'SECONDS',out['seconds'])

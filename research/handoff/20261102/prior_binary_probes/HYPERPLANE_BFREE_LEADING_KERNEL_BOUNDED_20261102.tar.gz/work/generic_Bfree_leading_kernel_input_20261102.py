from pathlib import Path
from fractions import Fraction
import json,sys,hashlib,time
import numpy as np
root=Path.cwd();sys.path.insert(0,str(root/'code'))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();profile=Path('work/generic_Bfree_minor_infinity_profile_20261102.json');meta=json.loads(profile.read_text());inputmeta=Path('work/generic_Bfree_minor_infinity_input_20261102.json');inp=json.loads(inputmeta.read_text());selected=inp['selected_rows'];rb=meta['row_bounds'];cb=meta['column_bounds'];n=len(selected);where={r:i for i,r in enumerate(selected)};exact=Path('/tmp/hyperplane-Bfree-t-targets-exact-core-20261102.in');M=[[{} for _ in range(n)] for _ in range(n)]
with exact.open() as f:
 nr,nc,ns=map(int,f.readline().split());assert nc==n==238
 for i in range(nr):
  for j in range(nc):
   line=f.readline()
   if i not in where:continue
   r=where[i];z=line.split();ct=int(z[0]);assert len(z)==1+4*ct;target=rb[r]+cb[j]
   for k in range(ct):
    if int(z[4+4*k])==target:
     c=Fraction(z[1+4*k]);ex=(int(z[2+4*k]),int(z[3+4*k]));M[r][j][ex]=M[r][j].get(ex,Fraction(0))+c
   M[r][j]={ex:c for ex,c in M[r][j].items() if c}
 assert not f.read().strip()
p=32003
@__import__('functools').lru_cache(None)
def cm(c):assert c.denominator%p;return c.numerator*pow(c.denominator,-1,p)%p
A=np.array([[sum(cm(c)*pow(2,ex[1],p) for ex,c in q.items())%p for q in row] for row in M],dtype=np.int64);rank,cols=elimination_rank(A,p);_,rows=elimination_rank(A[:,cols].T,p);free=[j for j in range(n) if j not in cols];assert rank==len(rows)==163 and len(free)==75;det=determinant_mod(A[np.ix_(rows,cols)],p)
out=Path('/tmp/generic-Bfree-leading-kernel-20261102.in')
with out.open('w') as f:
 f.write(f'{n} {n} {rank} {len(free)}\n'+' '.join(map(str,rows))+'\n'+' '.join(map(str,cols))+'\n'+' '.join(map(str,free))+'\n')
 for row in M:
  for q in row:f.write(str(len(q))+''.join(' '+str(c)+' '+str(ex[0])+' '+str(ex[1]) for ex,c in sorted(q.items(),reverse=True))+'\n')
report=dict(scope='Exact leading QQ[a,e] matrix from the pinned source; selected rank163 is witnessed mod32003 at a=1,e=2. QQ75-kernel computation is a separate bounded stage.',n=n,rank_lower=rank,pivot_rows=rows,pivot_columns=cols,free_columns=free,pivot_minor_mod_p=det,point=[1,2],prime=p,polynomial_terms=sum(len(q) for row in M for q in row),nonzero_entries=sum(bool(q) for row in M for q in row),max_core_degree=max(sum(ex) for row in M for q in row for ex in q),zero_columns=[j for j in range(n) if not any(M[i][j] for i in range(n))],input=str(out),input_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),source_hashes={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),profile,inputmeta,exact]},seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print({k:report[k] for k in ['n','rank_lower','pivot_minor_mod_p','polynomial_terms','nonzero_entries','max_core_degree','zero_columns','seconds']})

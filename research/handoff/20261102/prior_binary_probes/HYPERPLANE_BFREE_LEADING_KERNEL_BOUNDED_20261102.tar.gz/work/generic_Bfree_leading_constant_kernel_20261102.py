from pathlib import Path
from fractions import Fraction
from math import isqrt,gcd
import json,hashlib,time,subprocess,os
start=time.time();p=32003;source=Path('/tmp/generic-Bfree-leading-kernel-20261102.in');stack={}
with source.open() as f:
 nr,nc,rk,k=map(int,f.readline().split());f.readline();f.readline();f.readline()
 for i in range(nr):
  for j in range(nc):
   z=f.readline().split();ct=int(z[0]);assert len(z)==1+3*ct
   for h in range(ct):
    c=Fraction(z[1+3*h]);ex=(int(z[2+3*h]),int(z[3+3*h]));row=stack.setdefault((i,ex),{});row[j]=row.get(j,Fraction(0))+c
rows=[{j:c for j,c in row.items() if c} for _,row in sorted(stack.items())];assert all(rows)
infile=Path('/tmp/generic-Bfree-leading-constant-kernel-20261102.in');outfile=Path('/tmp/generic-Bfree-leading-constant-kernel-20261102.out')
with infile.open('w') as f:
 f.write(f'{len(rows)} {nc} {p}\n')
 for row in rows:
  f.write(str(len(row)))
  for j,c in sorted(row.items()):assert c.denominator%p;f.write(f' {j} {c.numerator*pow(c.denominator,-1,p)%p}')
  f.write('\n')
env=os.environ.copy();env['DYLD_LIBRARY_PATH']=str(Path.cwd()/'work/m2-runtime/lib')+':/opt/homebrew/lib';subprocess.run(['/tmp/generic-Bfree-leading-constant-kernel-20261102',str(infile),str(outfile)],env=env,timeout=20,check=True)
lines=outfile.read_text().splitlines();nrows,ncols,rank,nullity=map(int,lines[0].split());assert nrows==len(rows) and ncols==nc
bound=isqrt(p//2)
def rr(x):
 if x==0:return Fraction(0)
 r0,r1=p,x;t0,t1=0,1
 while abs(r1)>bound:
  q=r0//r1;r0,r1=r1,r0-q*r1;t0,t1=t1,t0-q*t1
 if t1<0:r1,t1=-r1,-t1
 if not (0<t1<=bound and gcd(r1,t1)==1 and (r1-x*t1)%p==0):return None
 return Fraction(r1,t1)
def check(vec):
 for row in rows:
  if sum((c*vec[j] for j,c in row.items() if vec[j]),Fraction(0)):return False
 return True
verified=[];failed=[];timed=False
for line in lines[1:]:
 z=list(map(int,line.split()));free=z[0];values=z[1:];assert len(values)==nc
 candidates=[('centered',[Fraction(v if v<=p//2 else v-p) for v in values])];rv=[rr(v) for v in values]
 if all(v is not None for v in rv):candidates.append(('small_rational_reconstruction',rv))
 for mode,vec in candidates:
  if check(vec):
   verified.append(dict(free_column=free,mode=mode,vector_sparse=[[j,str(v)] for j,v in enumerate(vec) if v]));break
 else:failed.append(free)
 if time.time()-start>20:timed=True;break
out=dict(scope='Bounded fallback: exact constant QQ kernel vectors of the leading QQ[a,e] matrix, verified coefficientwise. Does not certify the remaining field kernel.',coefficient_stack_shape=[nrows,ncols],modular_stack_rank=rank,modular_constant_nullity=nullity,constant_QQ_kernel_is_zero=(rank==ncols),QQ_verified_constant_kernels=verified,verified_count=len(verified),failed_lifts=failed,time_guard=timed,total_original_field_nullity_candidate=75,unverified_GF_field_kernel_directions=75-len(verified),seconds=time.time()-start,input_sha256={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),Path('work/generic_Bfree_leading_constant_kernel_20261102.cpp'),source,infile,outfile]})
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print({k:out[k] for k in ['coefficient_stack_shape','modular_stack_rank','modular_constant_nullity','verified_count','failed_lifts','time_guard','seconds']})

from pathlib import Path
from fractions import Fraction
import json,time,hashlib,sys
import sympy as s,numpy as np
root=Path.cwd();sys.path.insert(0,str(root/'code'))
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();p=32003;a,e,d=s.symbols('a e d');point={a:-s.Rational(18,25),e:2,d:-5}
chartpath=Path('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json');oldpath=Path('reports/S61_BINARY_DEEPER_TRIANGULAR_CHART_20261101.json');datapath=Path('work/generic_hyperplane_polynomial_a_elimination_20261102.json')
chart=json.loads(chartpath.read_text());old=json.loads(oldpath.read_text())['linear'];data=json.loads(datapath.read_text());weights=chart['local_coordinate_weights'];ew=chart['equation_weights']+[1];fixed=old['fixed'];cols=old['cols'];zero={19,23}
def mod(x):
 q=Fraction(str(x));assert q.denominator%p;return q.numerator*pow(q.denominator,-1,p)%p
ap=mod(point[a]);beta={int(k[1:])-1:s.sympify(v).subs(point) for k,v in chart['beta'].items()};_,raw=specialize(S61(),beta,True);eqs=[{} for _ in range(136)]
def add(q,m,c):
 if c%p:
  q[m]=(q.get(m,0)+c)%p
  if not q[m]:del q[m]
for i,f in enumerate(raw):
 if ew[i]>4:continue
 for mon,c in f.items():
  c=mod(c)
  if len(mon)==2:
   x,y=mon
   if x!=fixed and y==fixed and cols.index(x) not in zero:add(eqs[i],(cols.index(x),),c)
   if y!=fixed and x==fixed and cols.index(y) not in zero:add(eqs[i],(cols.index(y),),c)
  elif len(mon)==1 and mon[0]==fixed:add(eqs[i],(44,),c)
  if fixed not in mon:
   m=tuple(sorted([cols.index(j) for j in mon]+[44]*(2-len(mon))))
   if not any(j in zero for j in m):add(eqs[i],m,c)
eqs[135]={(5,):1}
def mult(q,r):
 out={}
 for m,c in q.items():
  for n,v in r.items():add(out,tuple(sorted(m+n)),c*v)
 return out
def substitute(q,j,S):
 maxocc=max((m.count(j) for m in q),default=0)
 if not maxocc:return q.copy()
 powers=[{():1},S]
 for k in range(2,maxocc+1):powers.append(mult(powers[-1],S))
 out={}
 for m,c in q.items():
  left=tuple(v for v in m if v!=j)
  for n,v in powers[m.count(j)].items():add(out,tuple(sorted(left+n)),c*v)
 return out
for step,history in zip(data['steps'],data['normalization_history']):
 i,j=step['equation'],step['variable'];q=eqs[i];scalar=q[(j,)];assert scalar==mod(step['scalar'])*pow(ap,step['a_power'],p)%p
 assert all(j not in m for m in q if m!=(j,));S={m:-c*pow(scalar,-1,p)%p for m,c in q.items() if m!=(j,)}
 new=[{} if k==i else substitute(qq,j,S) for k,qq in enumerate(eqs)]
 for h in history:
  assert not any(h['unit_powers'][1:]);k=h['row'];unit=pow(ap,h['cleared_a']-h['unit_powers'][0],p);new[k]={m:c*unit%p for m,c in new[k].items()}
 eqs=new
 for k,q in enumerate(eqs):assert all(sum(weights[j] for j in m)==ew[k] for m in q)
# Independently evaluate the saved final134 model and compare every coefficient.
saved={}
for item in data['equations_sparse']:
 q={}
 for mon,coeff in item['polynomial']:
  value=sum(mod(c)*pow(ap,ex[0],p)*pow(2,ex[1],p)*pow(p-5,ex[2],p) for ex,c in coeff)%p
  if value:q[tuple(mon)]=value
 saved[item['original_row']]=q
assert all(eqs[i]==saved.get(i,{}) for i in range(134));assert eqs[135]=={}
variables=data['remaining_variables'];G=eqs[134];assert G and ew[134]==3

def mons(w,lo=0):
 if w==0:yield ();return
 for k in range(lo,len(variables)):
  j=variables[k]
  if weights[j]<=w:
   for tail in mons(w-weights[j],k):yield (j,)+tail
mon={w:list(mons(w)) for w in range(5)};results={}
for degree in [2,3,4]:
 index={m:i for i,m in enumerate(mon[degree])};rows=[];labels=[]
 for i,q in enumerate(eqs[:135]):
  if not q or ew[i]>degree:continue
  for shift in mon[degree-ew[i]]:
   row=np.zeros(len(index),dtype=np.int64)
   for m,c in q.items():row[index[tuple(sorted(m+shift))]]=c
   rows.append(row);labels.append([i,list(shift)])
 mat=np.array(rows,dtype=np.int64);rk,cc=elimination_rank(mat,p);_,rr=elimination_rank(mat[:,cc].T,p);det=determinant_mod(mat[np.ix_(rr,cc)],p)
 results[str(degree)]=dict(shape=list(mat.shape),rank=rk,quotient_dimension=len(index)-rk,minor_rows=rr,minor_columns=cc,determinant=det,minor_source_labels=[labels[i] for i in rr])
out=dict(scope='Fixed F32003 point on D0=B=0. Numeric replay of all33 a-only substitutions against original135, including G6; no QQ/generic or ambient theorem.',prime=p,point={str(k):str(v) for k,v in point.items()},pivot_steps_replayed=len(data['steps']),all134_saved_coefficients_independently_matched=True,all_weights_checked=True,G6_weight=ew[134],G6_final_sparse=[[list(m),c] for m,c in sorted(G.items())],ranks=results,input_sha256={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),chartpath,oldpath,datapath,root/'code/s61_model.py',root/'code/s61_flag_transverse_obstruction_20261101.py',root/'reports/S61_UNIVERSAL_WEIGHT6_20261031.json']},seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print({w:{k:r[k] for k in ['shape','rank','quotient_dimension','determinant']} for w,r in results.items()});print('G6TERMS',len(G),'SECONDS',out['seconds'])

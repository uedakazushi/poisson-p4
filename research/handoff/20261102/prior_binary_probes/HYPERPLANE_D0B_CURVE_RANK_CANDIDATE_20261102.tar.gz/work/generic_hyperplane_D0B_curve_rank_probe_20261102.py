from pathlib import Path
from fractions import Fraction
from functools import lru_cache
import sys,json,hashlib,time
import numpy as np
root=Path.cwd();sys.path.insert(0,str(root/'code'))
from s61_binary_deeper_uniform_quadratic_20261101 import elimination_rank,determinant_mod
start=time.time();p=32003;source=Path('work/generic_hyperplane_polynomial_a_elimination_20261102.json');chart_path=Path('reports/S61_BINARY_HYPERPLANE_WEIGHTED_CHART_20261102.json');data=json.loads(source.read_text());chart=json.loads(chart_path.read_text());point=[Fraction(-18,25),Fraction(2),Fraction(-5)];pm=[x.numerator*pow(x.denominator,-1,p)%p for x in point];variables=data['remaining_variables'];weights=chart['local_coordinate_weights']
assert all(not v['unit_powers'][i] for history in data['normalization_history'] for v in history for i in [1,2,3])
@lru_cache(None)
def mod(s):
 q=Fraction(s);assert q.denominator%p;return q.numerator*pow(q.denominator,-1,p)%p
@lru_cache(None)
def power(ex):
 out=1
 for a,n in zip(pm,ex):out=out*pow(a,n,p)%p
 return out
polys=[]
for item in data['equations_sparse']:
 q={}
 for mon,c in item['polynomial']:
  value=sum(mod(v)*power(tuple(ex)) for ex,v in c)%p
  if value:q[tuple(mon)]=value
 polys.append((item['original_row'],item['weight'],q))
def monomials(w,lo=0):
 if w==0:yield ();return
 for i in range(lo,len(variables)):
  j=variables[i]
  if weights[j]<=w:
   for tail in monomials(w-weights[j],i):yield (j,)+tail
mon={w:list(monomials(w)) for w in range(5)};results={}
for degree in [2,3,4]:
 index={m:i for i,m in enumerate(mon[degree])};rows=[];labels=[]
 for source_row,w,q in polys:
  if w>degree:continue
  for shift in mon[degree-w]:
   row=np.zeros(len(index),dtype=np.int64)
   for m,c in q.items():row[index[tuple(sorted(m+shift))]]=c
   rows.append(row);labels.append([source_row,list(shift)])
 mat=np.array(rows,dtype=np.int64);rank,cols=elimination_rank(mat,p);_,rr=elimination_rank(mat[:,cols].T,p);assert len(cols)==len(rr)==rank
 det=determinant_mod(mat[np.ix_(rr,cols)],p)
 results[str(degree)]=dict(shape=list(mat.shape),rank=rank,quotient_dimension=len(index)-rank,minor_rows=rr,minor_columns=cols,determinant=det,minor_source_labels=[labels[i] for i in rr])
print({w:{k:r[k] for k in ['shape','rank','quotient_dimension','determinant']} for w,r in results.items()},flush=True)
a,e,d=point;vals=dict(a=a,F=500*a+90*e*e+3*e-24,B=50*a*d+18*d*e*e-9*d*e-2*d+60*e-40,C=100*a+18*e*e-9*e-2,D0=50*a+9*e*e+3*e-6);assert vals['D0']==vals['B']==0 and vals['a']*vals['F']*vals['C']
out=dict(scope='Fixed finite-field point on D0=B=0, using the exact a-only partial10-variable source model. No B-free frame and no QQ/generic or ambient conclusion.',prime=p,rational_point=dict(zip(['a','e','d'],map(str,point))),point_mod_p=pm,factor_values={k:str(v) for k,v in vals.items()},remaining_variables=variables,weights=[weights[j] for j in variables],ranks=results,all_model_normalizations_only_a=True,input_sha256={str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path(__file__),source,chart_path,root/'code/s61_binary_deeper_uniform_quadratic_20261101.py']},seconds=time.time()-start)
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print('SECONDS',out['seconds'])

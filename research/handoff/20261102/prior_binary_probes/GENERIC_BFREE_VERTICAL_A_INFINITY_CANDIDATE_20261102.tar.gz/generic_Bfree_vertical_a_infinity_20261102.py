from pathlib import Path
from fractions import Fraction
import json,hashlib,time,functools,os,subprocess

start=time.time();root=Path.cwd();p=32003;nr=321;nc=238;limit=32
core=Path('/tmp/hyperplane-Bfree-t-targets-exact-core-20261102.in')
uni=Path('/tmp/generic-Bfree-vertical-a-d3-20261102.in')
base=Path('/tmp/generic-Bfree-vertical-a-infinity-20261102')
report={'scope':'Bounded F32003 profile candidate at e=2,d=3. Generic entry a-degrees are computed exactly after d=3 over QQ[e]; no QQ kernel or vertical support theorem.','prime':p,'fixed_d':3,'fixed_e_modp':2,'jet_limit':limit}
paths=[Path(__file__),core,uni]

def hungarian_rectangular(deg):
    # Assign every original column to a distinct original row.
    n=len(deg[0]);m=len(deg);u=[0]*(n+1);v=[0]*(m+1);match=[0]*(m+1);way=[0]*(m+1)
    for i in range(1,n+1):
        match[0]=i;j0=0;minv=[10**9]*(m+1);used=[False]*(m+1)
        while True:
            used[j0]=True;i0=match[j0];delta=10**9;j1=0
            for j in range(1,m+1):
                if not used[j]:
                    cur=-deg[j-1][i0-1]-u[i0]-v[j]
                    if cur<minv[j]:minv[j]=cur;way[j]=j0
                    if minv[j]<delta:delta=minv[j];j1=j
            for j in range(m+1):
                if used[j]:u[match[j]]+=delta;v[j]-=delta
                else:minv[j]-=delta
            j0=j1
            if match[j0]==0:break
        while True:
            j1=way[j0];match[j0]=match[j1];j0=j1
            if j0==0:break
    cb=[-x for x in u[1:]];dual_rb=[-x for x in v[1:]]
    assert all(dual_rb[i]+cb[j]>=deg[i][j] for i in range(m)for j in range(n))
    assignment=[[j-1,match[j]-1]for j in range(1,m+1)if match[j]]
    bound=sum(dual_rb)+sum(cb)
    assert bound==sum(deg[i][j]for i,j in assignment)
    rb=[max([deg[i][j]-cb[j]for j in range(n)if deg[i][j]>-100000],default=0)for i in range(m)]
    return rb,cb,assignment,bound

@functools.lru_cache(None)
def rational(z):return Fraction(z)

it=iter(map(int,uni.read_text().split()));assert [next(it)for _ in range(4)]==[p,nr,nc,0];next(it);next(it)
M=[]
for i in range(nr):
    row={}
    for _ in range(next(it)):
        j,n=next(it),next(it);row[j]=[next(it)for _ in range(n)]
    M.append(row)
assert next(it,None)is None
degree=[];count=0;entrymax=-1;nonzero=0
with core.open()as f:
    assert list(map(int,f.readline().split()))==[328,238,321]
    for i in range(328):
        deg=[]
        for j in range(nc):
            z=f.readline().split();nt=int(z[0]);assert len(z)==1+4*nt
            if i>=nr:continue
            values={}
            for k in range(nt):
                c=rational(z[1+4*k]);assert c.denominator%p
                aa,ee,dd=map(int,z[2+4*k:5+4*k]);key=(aa,ee)
                values[key]=values.get(key,Fraction(0))+c*3**dd;count+=1
            values={key:c for key,c in values.items()if c}
            gd=max([key[0]for key in values],default=-100000);deg.append(gd);entrymax=max(entrymax,gd);nonzero+=bool(values)
            evals={}
            for (aa,ee),c in values.items():
                val=c.numerator*pow(c.denominator,-1,p)%p*pow(2,ee,p)%p
                evals[aa]=(evals.get(aa,0)+val)%p
            evals={k:c for k,c in evals.items()if c}
            assert evals=={k:c for k,c in enumerate(M[i].get(j,[]))if c},(i,j)
        if i<nr:degree.append(deg)
    assert not f.read().strip()
rb,cb,assignment,bound=hungarian_rectangular(degree)
report.update(generic_entry_a_degrees=degree,maximum_entry_a_degree=entrymax,nonzero_generic_entries=nonzero,checked_source_core_terms=count,row_bounds=rb,column_bounds=cb,hungarian_assignment=assignment,hungarian_maximum_minor_bound=bound,coefficient_specialization_and_p_integrality_pass=True,preparation_seconds=time.time()-start)
print('PREPARATION',report['preparation_seconds'],'MAX_ENTRY',entrymax,'HUNGARIAN',bound,flush=True)
inp=base.with_suffix('.in');out=base.with_suffix('.out')
with inp.open('w')as f:
    f.write(f'{p} {nr} {nc} {limit}\n')
    for i in range(nr):
        for j in range(nc):
            vals={rb[i]+cb[j]-k:c for k,c in enumerate(M[i].get(j,[]))if c}
            assert all(k>=0 for k in vals)
            vals={k:c for k,c in vals.items()if k<=limit}
            co=[vals.get(k,0)for k in range(max(vals)+1)]if vals else []
            f.write(str(len(co))+(' '+' '.join(map(str,co))if co else '')+'\n')
env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib'}
def native(cpp,name,args,timeout=30):
    exe=Path('/tmp')/name
    subprocess.run(['clang++','-O3','-std=c++17','-Iwork/flint-headers/flint/3.5.0/include','-I/opt/homebrew/include',str(cpp),'work/m2-runtime/lib/libflint.24.0.dylib','-L/opt/homebrew/lib','-lgmp','-o',str(exe)],check=True,timeout=30)
    t=time.time();log=base.with_name(base.name+'-'+name+'.log')
    try:
        cp=subprocess.run([str(exe),*map(str,args)],env=env,capture_output=True,text=True,timeout=timeout)
        log.write_text(cp.stdout+cp.stderr);cp.check_returncode()
        paths.extend([cpp,log]);return {'status':'completed','seconds':time.time()-t}
    except subprocess.TimeoutExpired as ex:
        text=(ex.stdout or b'')+(ex.stderr or b'');log.write_bytes(text if isinstance(text,bytes)else text.encode())
        paths.extend([cpp,log]);return {'status':'timeout30s','seconds':time.time()-t}
    except subprocess.CalledProcessError:
        paths.extend([cpp,log]);return {'status':'native_error_or_guard','seconds':time.time()-t}
cpp=Path('work/generic_Bfree_vertical_a_infinity_profile_20261102.cpp')
report['profile_run']=native(cpp,'generic-Bfree-vertical-a-profile-20261102',[inp,out]);paths.append(inp)
if out.exists():paths.append(out)
if report['profile_run']['status']=='completed':
    stages=[];last=None;res={}
    for ln in out.read_text().splitlines():
        z=ln.split()
        if z[0]=='STAGE':
            vals={z[k]:z[k+1]for k in range(0,len(z),2)};last={k.lower():float(v)if k=='SECONDS'else int(v)for k,v in vals.items()};last['pivots']=[];stages.append(last)
        elif z[0]=='PIVOT':
            vals=list(map(int,z[1:]));assert vals[0]==last['stage'];last['pivots'].append(vals[1:])
        elif z[0]=='RESULT':res={z[k]:z[k+1]for k in range(1,len(z),2)}
        elif z[0].startswith('STOP'):pass
        else:raise AssertionError(ln)
    report['stages']=stages;report['complete']=res.get('COMPLETE')=='1';report['valuation']=int(res['VALUATION']);report['native_profile_seconds']=float(res['SECONDS'])
    print('PROFILE',[(q['rows'],q['cols'],q['rank'])for q in stages],'VALUATION',report['valuation'],flush=True)
    if report['complete']:
        rows=[q[3]for stage in stages for q in stage['pivots']];cols=[q[4]for stage in stages for q in stage['pivots']];units=[q[5]for stage in stages for q in stage['pivots']]
        assert len(rows)==len(set(rows))==nc and sorted(cols)==list(range(nc))
        upper=sum(rb[i]for i in rows)+sum(cb);predicted=1
        for v in units:predicted=predicted*v%p
        inv=sum(cols[i]>cols[j]for i in range(nc)for j in range(i+1,nc));predicted=predicted*(-1 if inv%2 else 1)%p
        report.update(selected_original_rows=rows,column_pivot_order=cols,selected_row_weight_sum=sum(rb[i]for i in rows),column_weight_sum=sum(cb),selected_degree_upper=upper,profile_predicted_degree=upper-report['valuation'],profile_predicted_leading_coefficient=predicted)
        selection=base.with_name(base.name+'-selection.in');selection.write_text(str(nc)+'\n'+' '.join(map(str,rows))+'\n');detout=base.with_name(base.name+'-minor.out');paths.append(selection)
        cpp2=Path('work/generic_Bfree_vertical_a_minor_20261102.cpp')
        if time.time()-start<55:
            report['determinant_run']=native(cpp2,'generic-Bfree-vertical-a-minor-20261102',[uni,selection,detout])
            if detout.exists():paths.append(detout)
            if report['determinant_run']['status']=='completed':
                direct={};evals=[]
                for ln in detout.read_text().splitlines():
                    z=ln.split()
                    if z[0]=='DETERMINANT_DEGREE':direct.update(degree=int(z[1]),leading_coefficient=int(z[3]),seconds=float(z[5]))
                    elif z[0]=='DETERMINANT_COEFFICIENTS':assert int(z[1])==len(z)-2;direct['coefficients_ascending']=list(map(int,z[2:]))
                    elif z[0]=='EVALUATION':evals.append(list(map(int,z[1:])))
                    elif z[0]=='TOTAL_SECONDS':pass
                    else:raise AssertionError(ln)
                assert direct['degree']==report['profile_predicted_degree'] and direct['leading_coefficient']==predicted
                direct['independent_evaluations']=evals;report['direct_minor']=direct
                print('DIRECT_MINOR',direct['degree'],direct['leading_coefficient'],'SECONDS',direct['seconds'],flush=True)
        else:report['determinant_run']={'status':'not_started_total_budget'}
report['input_sha256']={str(q):hashlib.sha256(q.read_bytes()).hexdigest()for q in paths};report['seconds']=time.time()-start
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print('TOTAL',report['seconds'],flush=True)

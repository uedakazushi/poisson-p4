import os,sys,json,subprocess,time,collections,itertools
from pathlib import Path
import sympy as s
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'code'));folder=Path(__file__).resolve().parent
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
m=S61();one=[i for i,w in enumerate(m.reduced['parameter_weights'])if w==1];qw=json.load(open(root/'reports/S61_MARKED_SIGMA_RESIDUAL_FINITE_20261102.json'))['frame']['q_weights']
chart=[i for i in range(45)if i!=25];P=32003
def field(x):
 x=s.Rational(x);return int(x.p)%P*pow(int(x.q)%P,-1,P)%P
def flatten(M):return ' '.join(str(field(z)) for z in M)
def test(a,c,h=0):
 d=folder/f'marked-axis-line-{a}-{c}-{h}';d.mkdir(exist_ok=True);r=s.Symbol('r');v=dict.fromkeys(one,s.S.Zero);v.update({4:r,11:1,25:a,26:h,50:c})
 _,forms=specialize(m,v,True);lin=s.Matrix([[-f.get(tuple(sorted((25,j))),0) for j in chart]+[-f.get((25,),0)]for f in forms]);J=lin.subs(r,0)
 orbitcuts=[0,19,27] if a else [0,9,27];cuts=[chart.index(j)for j in [*orbitcuts,32]]; cols=[i for i in range(45)if i not in cuts]
 rr,pv=J[:,cols].to_DM().to_field().rref();rr=rr.to_Matrix();fr=[j for j in range(len(cols))if j not in pv];n=len(fr)+1;pc=[cols[j]for j in pv];sel=list(J[:,pc].T.to_DM().rref()[1])
 if n>16:print('skip huge n',a,c,n);return
 T=s.zeros(45,n-1);U=s.zeros(45,len(pv));iv=J[sel,pc].inv(method='DM')
 for k,j in enumerate(fr):T[cols[j],k]=1
 for i,j in enumerate(pc):
  U[j,:]=iv[i,:]
  for k,q in enumerate(fr):T[j,k]=-rr[i,q]
 if T[44,-1]!=1:print('warning t coord nondiagonal',a,c)
 nw=[qw[cols[j]]for j in fr]+[1];lines=[f'{n} {len(pv)}',' '.join(map(str,qw)),' '.join(map(str,nw)),' '.join(map(str,sel)),flatten(J),flatten(T),flatten(U)]
 for f in forms:
  H=[]
  for mon,k in f.items():
   k*=(-1)**mon.count(25);ids=[chart.index(j) for j in mon if j!=25]+[44]*(2-len(mon))
   for (rr,),z in s.Poly(k,r).terms():
    if not z or (len(ids)==1 and not rr):continue
    H.append([ids[0], ids[-1]if len(ids)==2 else -1,rr,field(z)])
  lines.append(str(len(H))+' '+ ' '.join(' '.join(map(str,t))for t in H))
 (d/'model.in').write_text('\n'.join(lines));subprocess.run(['/tmp/marked_axis_modular_20261102',str(d/'model.in'),str(d/'model.m2')],check=True)
 with (d/'model.m2').open('a')as f:f.write('G=gb I;print("S="|toString hilbertSeries(R/I,Reduce=>true));U=I+ideal(rho);print("U="|toString hilbertSeries(R/U,Reduce=>true));A=saturate(I,ideal(rho));print("A="|toString hilbertSeries(R/A,Reduce=>true));print("R="|toString(radical A==ideal apply(toList(0..numgens R-2),i->R_i)));\n')
 ev=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'};script=str(d/'model.m2')
 with (d/'model.log').open('w')as out:
  try:subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',script],env=ev,stdout=out,stderr=subprocess.STDOUT,timeout=60)
  except subprocess.TimeoutExpired:print('timeout',a,c,flush=True);return
 print(a,c,h,n,[(q[:140])for q in (d/'model.log').read_text().splitlines()if q[:2]in ['S=','U=','A=','R=']],flush=True)
for c in [2,0,1,3,-1,-2,4,7]:test(1,c)
test(0,1)

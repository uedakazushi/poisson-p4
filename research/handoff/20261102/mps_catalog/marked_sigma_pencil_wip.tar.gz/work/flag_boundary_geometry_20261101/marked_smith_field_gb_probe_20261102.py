from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import subprocess,os,time
d=Path(__file__).resolve().parent/'marked-vertical-symbolic';root=d.parents[2];p=32003;t0=time.monotonic()
with (d/'global-rows').open()as f:
 n,N=map(int,f.readline().split());rows=[]
 for i in range(N):
  w,k=map(int,f.readline().split());co=defaultdict(dict)
  for _ in range(k):
   fields=f.readline().split();q,h,rho=fields[0],int(fields[1]),int(fields[-1])
   if rho or i==135:continue
   exp=tuple(map(int,fields[2:-1]));a,b=Fraction(q).as_integer_ratio();v=a%p*pow(b%p,-1,p)%p
   if v:co[exp][h]=v
  rows.append((w,co))
v=[f'v{i}'for i in range(n-1)];nw=[1]*7+[2]*4+[3]*2
def coefficient(f):
 return '+'.join(str(c)+(f'*h^{j}'if j else '')for j,c in sorted(f.items()))
def encode(d):
 return '+'.join('('+coefficient(f)+')'+''.join('*'+n+(f'^{j}'if j>1 else'')for n,j in zip(v,ex)if j)for ex,f in d.items())
head='K=frac(ZZ/32003[h]);R=K['+','.join(v)+',Degrees=>{'+','.join(map(str,nw))+'}];\n'
out=d/'smith-zero-rho-field-gb.m2'
out.write_text(head+'I=ideal('+','.join(encode(d)for _,d in rows if d)+');\nprint("INPUT READ");<<flush;G=gb(I,DegreeLimit=>4);print("D4");<<flush;G=gb(I,DegreeLimit=>6);print("D6 complete");print(toString apply(toList(0..7),i->hilbertFunction(i,R/I)));\n')
print('prepared',out.stat().st_size,time.monotonic()-t0,flush=True)
env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'}
with (d/'smith-gb-field.log').open('w')as f:
 try:rc=subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',str(out)],stdout=f,stderr=subprocess.STDOUT,env=env,timeout=75);print(rc.returncode,flush=True)
 except subprocess.TimeoutExpired:print('75s bound',flush=True)

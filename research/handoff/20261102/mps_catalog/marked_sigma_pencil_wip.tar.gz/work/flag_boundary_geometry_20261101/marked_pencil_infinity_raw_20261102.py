from pathlib import Path
import os,sys,json,time,subprocess
import sympy as s
root=Path(__file__).resolve().parents[2];sys.path.insert(0,str(root/'code'))
from s61_model import S61
from s61_flag_transverse_obstruction_20261101 import specialize
d=Path(__file__).resolve().parent/'marked-vertical-symbolic';m=S61();one=[i for i,v in enumerate(m.reduced['parameter_weights'])if v==1];chart=[j for j in range(45)if j!=25]
w=json.load(open(root/'reports/S61_MARKED_SIGMA_RESIDUAL_FINITE_20261102.json'))['frame']['q_weights'];r=s.Symbol('rho');h=s.Symbol('h')
def run(tag,a,c,hh,field,cuts,timeout):
 vals=dict.fromkeys(one,s.S.Zero);vals.update({4:r,11:1,25:a,26:hh,50:c});_,F=specialize(m,vals,True)
 cols=[j for j in chart if j not in cuts];names=['q'+str(j)for j in cols]+['t','rho'];ws=[w[chart.index(j)]for j in cols]+[3,1]
 polys=[]
 for f in F:
  terms=[]
  for mon,v in f.items():
   if any(j in cuts for j in mon):continue
   v*=(-1)**mon.count(25)
   x=[f'q{j}'for j in mon if j!=25]+['t']*(2-len(mon))
   if v:
    terms.append('('+str(v).replace('**','^')+')'+''.join('*'+j for j in x))
  if terms:polys.append('+'.join(terms))
 src='K='+field+';R=K['+','.join(names)+',Degrees=>{'+','.join(map(str,ws))+'}];\nI=ideal('+','.join(polys)+');\nprint("INPUT");'
 if 'frac'in field:src+='G=gb(I,DegreeLimit=>4);print("D4"); G=gb(I,DegreeLimit=>5);print("D5");'
 else:src+='G=gb I;U=I+ideal(rho);W=I+ideal(rho-1);print("H",toString hilbertSeries(R/I,Reduce=>true));print("zero",dim(R/U),numColumns basis(R/U),"one",numColumns basis(R/W));print("t",t%I==0,t^2%I==0);'
 p=d/(tag+'.m2');p.write_text(src);print(tag,'bytes',len(src),flush=True)
 env=os.environ|{'DYLD_LIBRARY_PATH':str(root/'work/m2-runtime/lib')+':/opt/homebrew/lib:/opt/homebrew/opt/givaro/lib'}
 with p.with_suffix('.log').open('w')as o:
  try:subprocess.run(['/opt/homebrew/Cellar/macaulay2/1.26.05/bin/M2-binary','--script',str(p)],env=env,stdout=o,stderr=subprocess.STDOUT,timeout=timeout)
  except subprocess.TimeoutExpired:print('STOP',tag,timeout,flush=True)
 print(p.with_suffix('.log').read_text()[-500:],flush=True)
run('infty-direct',0,0,1,'QQ',[0,9,27,32],80)
run('symbolic-direct',1,2,h,'frac(ZZ/32003[h])',[0,19,27,32],65)

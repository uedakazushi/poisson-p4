// Work probe. Fraction-free homogeneous reductions over F_p[h] for U=S/(rho).
#include <flint/nmod_poly.h>
#include <flint/ulong_extras.h>
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>
using namespace std;const ulong prime=32003;using Mon=uint64_t;
struct P{nmod_poly_t x;P(){nmod_poly_init(x,prime);} P(const P&b):P(){nmod_poly_set(x,b.x);}P(P&&b):P(){nmod_poly_swap(x,b.x);}P&operator=(P b){nmod_poly_swap(x,b.x);return *this;}~P(){nmod_poly_clear(x);}bool zero()const{return nmod_poly_is_zero(x);}long deg()const{return nmod_poly_degree(x);}};
using Row=map<Mon,P>;vector<int>wt={1,1,1,1,1,1,1,2,2,2,2,3,3};int n;P bad;
auto clock0=chrono::steady_clock::now();double sec(){return chrono::duration<double>(chrono::steady_clock::now()-clock0).count();}
ulong scalar(const string&s){auto p=s.find('/');auto digit=[](const string&s){bool neg=s[0]=='-';ulong v=0;for(char c:s)if(c>='0'&&c<='9')v=(10*v+c-'0')%prime;return neg&&v?prime-v:v;};ulong num=digit(s.substr(0,p));return p==string::npos?num:num*n_invmod(digit(s.substr(p+1)),prime)%prime;}
int weight(Mon m){int r=0;for(int i=0;i<n;i++)r+=wt[i]*(m>>(4*i)&15);return r;}
bool mon_divides(Mon a,Mon b){for(int i=0;i<n;i++)if((a>>(4*i)&15)>(b>>(4*i)&15))return false;return true;}
Mon lcm_mon(Mon a,Mon b){Mon c=0;for(int i=0;i<n;i++)c|=max((a>>(4*i))&15,(b>>(4*i))&15)<<(4*i);return c;}
void remember(const P&f){if(f.deg()<1)return;P g,q;nmod_poly_gcd(g.x,bad.x,f.x);nmod_poly_div(q.x,f.x,g.x);nmod_poly_mul(bad.x,bad.x,q.x);nmod_poly_make_monic(bad.x,bad.x);}
void primitive(Row&r,bool record){if(r.empty())return;P g=r.begin()->second;for(auto&[m,v]:r){nmod_poly_gcd(g.x,g.x,v.x);if(g.deg()==0)break;}if(g.deg()){if(record)remember(g);for(auto&[m,v]:r)nmod_poly_div(v.x,v.x,g.x);}}
void reduce_once(Row&r,const Row&G,Mon m,Mon l,bool record){Mon sh=m-l;P a=r.at(m),b=G.at(l),g;nmod_poly_gcd(g.x,a.x,b.x);nmod_poly_div(a.x,a.x,g.x);nmod_poly_div(b.x,b.x,g.x);for(auto&[k,v]:r)nmod_poly_mul(v.x,v.x,b.x);
 for(auto&[k,v]:G){auto j=k+sh;P u;nmod_poly_mul(u.x,v.x,a.x);auto &z=r[j];nmod_poly_sub(z.x,z.x,u.x);if(z.zero())r.erase(j);}
 primitive(r,record);}
struct Gen{Row r;Mon lead;int w;};
vector<Gen>B;
void reduce(Row&r,bool record){while(!r.empty()){bool hit=false;for(auto it=r.begin();it!=r.end();it++){Mon m=it->first;const Gen*best=nullptr;for(auto&g:B)if(mon_divides(g.lead,m)&&(!best||g.r.size()<best->r.size()))best=&g;
 if(best){reduce_once(r,best->r,m,best->lead,record);hit=true;break;}}if(!hit)return;}}
Row pair_row(const Gen&a,const Gen&b,Mon l){Row r;for(auto&[m,c]:a.r)r[m+l-a.lead]=c;reduce_once(r,b.r,l,b.lead,true);return r;}
int main(int argc,char**argv){assert(argc==4);ifstream in(argv[1]);int NN,maximum=stoi(argv[3]);in>>n>>NN;int all=n;--n;assert(n==13);vector<vector<Row>>rows(11);nmod_poly_one(bad.x);
 for(int i=0;i<NN;i++){int w;long nn;in>>w>>nn;Row r;for(long j=0;j<nn;j++){string val;in>>val;int h,e;Mon m=0;in>>h;for(int k=0;k<n;k++){in>>e;m|=Mon(e)<<(4*k);}in>>e;if(e||i==135)continue;ulong c=scalar(val);if(c)nmod_poly_set_coeff_ui(r[m].x,h,c);}for(auto it=r.begin();it!=r.end();)if(it->second.zero())it=r.erase(it);else it++;if(!r.empty())rows[w].push_back(std::move(r));}
 ofstream out(argv[2]);for(int w=1;w<=maximum;w++){
 vector<pair<int,int>>pairs;for(int i=0;i<(int)B.size();i++)for(int j=0;j<i;j++){auto l=lcm_mon(B[i].lead,B[j].lead);if(weight(l)==w&&w!=B[i].w+B[j].w)pairs.push_back({i,j});}
 vector<Row>&cands=rows[w];for(auto[i,j]:pairs)cands.push_back(pair_row(B[i],B[j],lcm_mon(B[i].lead,B[j].lead)));
 stable_sort(cands.begin(),cands.end(),[](auto&a,auto&b){return a.size()<b.size();});int fresh=0,tried=0;for(auto&r:cands){tried++;reduce(r,true);if(r.empty())continue;auto lm=r.begin()->first;int md=0;for(auto&[k,v]:r)md=max(md,(int)v.deg());remember(r.begin()->second);B.push_back({std::move(r),lm,w});fresh++;cerr<<"new "<<w<<" "<<fresh<<" "<<B.back().r.size()<<" deg "<<md<<" total "<<sec()<<"\n";if(sec()>90){cerr<<"bounded stop\n";return 3;}}
 out<<w<<" "<<fresh<<" "<<tried<<" "<<bad.deg()<<"\n";out.flush();cerr<<"degree "<<w<<" done "<<sec()<<"\n";}
}

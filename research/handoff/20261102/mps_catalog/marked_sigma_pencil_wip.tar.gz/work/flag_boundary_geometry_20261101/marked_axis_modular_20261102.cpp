#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;
using E=uint64_t;
using Poly=unordered_map<E,int>;
const int P=32003;
void ap(Poly& a,const Poly& b,int c,E sh=0){if(!c)return;for(auto [m,z]:b){auto j=m+sh;int v=(a[j]+c*(long long)z)%P;if(v<0)v+=P;if(v)a[j]=v;else a.erase(j);}}
Poly mult(const Poly&a,const Poly&b){Poly z;for(auto [i,v]:a)ap(z,b,v,i);return z;}
int main(int narg,char**arg){if(narg!=3)return 1;ifstream in(arg[1]);ofstream out(arg[2]);int n,rank;in>>n>>rank;if(n>16)return 2;
 vector<int>w(45),nw(n),sel(rank);for(auto &j:w)in>>j;for(auto&j:nw)in>>j;for(auto&j:sel)in>>j;
 vector<Poly>Y(45); vector<vector<int>>J(135,vector<int>(45)),U(45,vector<int>(rank));for(auto&row:J)for(auto&c:row)in>>c;
 for(int i=0;i<45;i++)for(int j=0;j<n-1;j++){int a;in>>a;if(a)Y[i][E(1)<<(4*j)]=a;}
 for(auto&row:U)for(auto&c:row)in>>c;
 vector<vector<array<int,4>>>H(135);for(auto&row:H){int cnt;in>>cnt;row.resize(cnt);for(auto&e:row)for(int&i:e)in>>i;}
 auto raw=[&](int row){Poly a;for(auto [i,j,r,c]:H[row]){E sh=E(r)<<(4*(n-1));if(j<0)ap(a,Y[i],c,sh);else ap(a,mult(Y[i],Y[j]),c,sh);}return a;};
 for(int d=1;d<=4;d++){vector<Poly>A(rank);vector<int>filled(rank);for(int i=0;i<45;i++)if(w[i]==d)for(int k=0;k<rank;k++)if(U[i][k]){if(!filled[k]){A[k]=raw(sel[k]);filled[k]=1;}ap(Y[i],A[k],-U[i][k]);}}
 out<<"R=ZZ/32003[";for(int i=0;i<n;i++){if(i)out<<",";out<<"v"<<i;}out<<",Degrees=>{";for(int j=0;j<n;j++){if(j)out<<",";out<<nw[j];}out<<"}];\nI=ideal(";bool first=true;for(int i=0;i<135;i++){Poly f=raw(i);for(int j=0;j<45;j++)ap(f,Y[j],J[i][j]);for(int k:sel)if(i==k&&!f.empty())return 3;if(f.empty())continue;if(!first)out<<",";first=false;bool ffirst=true;for(auto[m,v]:f){if(!ffirst)out<<"+";ffirst=false;out<<v;for(int j=0;j<n;j++){int k=m>>(4*j)&15;if(k)out<<"*v"<<j<<"^"<<k;}}}out<<");rho=v"<<(n-1)<<";tval=v"<<(n-2)<<";\n";return 0;}

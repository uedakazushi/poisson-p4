from pathlib import Path
import itertools,collections,time,sys
from fractions import Fraction
root=Path(__file__).resolve().parents[2];folder=Path(__file__).resolve().parent/'marked-vertical-symbolic';P=32003;target=int(sys.argv[1])if len(sys.argv)>1 else 5;zero=int(sys.argv[2])if len(sys.argv)>2 else 1;t0=time.monotonic();ws=[1]*7+[2]*4+[3]*2+([] if zero else [1]);n=len(ws)
def mons(w,j=0):
 if j==n:
  if w==0:yield 0
  return
 for k in range(w//ws[j]+1):
  for m in mons(w-k*ws[j],j+1):yield m|(k<<(4*j))
def scalar(q):
 a,b=Fraction(q).as_integer_ratio();return a%P*pow(b%P,-1,P)%P
with (folder/'global-rows').open()as src:
 nv,ni=map(int,src.readline().split());raw=[]
 for i in range(ni):
  w,count=map(int,src.readline().split());row=collections.defaultdict(dict)
  for _ in range(count):
   line=src.readline()
   if i==135 or w>target:continue
   q,*e=line.split()
   if zero and e[-1]!='0':continue
   m=sum(int(k)<<(4*j)for j,k in enumerate(e[1:1+n]));c=scalar(q)
   if c:row[m][int(e[0])]=c
  if row:raw.append((i,w,dict(row)))
idx={m:i for i,m in enumerate(sorted(mons(target)))};rows=[];prefix={}
for i,w,row in raw:
 d=max(max(p)for p in row.values())
 for m in mons(target-w):rows.append((d,len(row),i,m))
 prefix[i]=row
rows.sort()
file=folder/('zero'if zero else'full')/f'module-{target}.txt';file.parent.mkdir(exist_ok=True)
with file.open('w')as out:
 out.write(f'{P} {len(rows)} {len(idx)} 0\n0 1\n')
 for deg,num,i,m in rows:
  row=prefix[i];out.write(f'{len(row)}\n')
  for mon,coeff in row.items():
   c=max(coeff)+1
   out.write(' '.join(map(str,[idx[m+mon],c,*[coeff.get(j,0)for j in range(c)]]))+'\n')
print('WROTE',file,len(rows),len(idx),file.stat().st_size,time.monotonic()-t0)

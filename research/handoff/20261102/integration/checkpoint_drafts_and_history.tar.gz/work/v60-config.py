C=[]
def add(i,title,msg,stems,deps,lim):
 C.append([i,title,msg,[x+'_20261102' for x in stems],deps,lim])
add('S61_BINARY_ZERO_PAIR_STRATUM_REMOVAL_REVIEW','非平方零対の独立再現','混合標数上の固有性と全群方向を戻す証明を独立点検し、零対層の元式計算を再実行した。',['S61_BINARY_ZERO_PAIR_STRATUM_REMOVAL_REVIEW'],['S61_BINARY_ZERO_PAIR_STRATUM_REMOVAL'],'非零cは別の層である。')
add('S61_AFFINE_ANCHOR_RESIDUE_DEGREE','真の境界が会う有限点の剰余次数','固定平面の六係数へのSL2作用から各残留点の剰余次数は10以上。未知曲面なら交叉数c≥20となるので、有限局所商の長さの和19以下で全曲面を排除できる。',['S61_AFFINE_ANCHOR_RESIDUE_DEGREE'],['S61_AFFINE_ANCHOR_LENGTH_BOUND','S61_BINARY_ZERO_PAIR_STRATUM_REMOVAL','S61_MARKED_SIGMA_PROJECTIVE_CORE'],'この数値上界の成立は未証明。')
add('S61_MARKED_SIGMA_PURE_ENDPOINT_REMOVAL','指定平方旗の純三次端点因子の除去','指定線形切断の正重み中央環と二つの追加軌道での全周囲正則性を用い、純三次端点の十六次元像全体を一般β上で除去。',['S61_MARKED_SIGMA_PURE_ENDPOINT_REMOVAL'],['S61_MARKED_SIGMA_PROJECTIVE_CORE'],'十分一般の一次ジェット上の主張。')
add('S61_MARKED_SIGMA_ZERO_H_REMOVAL','指定平方旗の剰余次数15候補の全除去','正規化coreのh=0因子を一般β上で全て除去した。これにより指定平方旗に残り得る剰余次数は10の倍数となる。',['S61_MARKED_SIGMA_ZERO_H_REMOVAL','S61_MARKED_SIGMA_ENDPOINTS_PROOF_REVIEW'],['S61_MARKED_SIGMA_PROJECTIVE_CORE','S61_AFFINE_ANCHOR_RESIDUE_DEGREE'],'特殊βでのアフィン直線は存続する。')
add('S61_MARKED_SIGMA_PENCIL_MODEL','指定平方旗の試験直線全域の方程式','c=2aの有限chart全hで元135式を多項式Smith基底で14変数に還元した。無限遠端点[0:0:1]では全周囲の冪零性を別に証明した。',['S61_MARKED_SIGMA_PENCIL_MODEL','S61_MARKED_SIGMA_PENCIL_INFINITY'],['S61_MARKED_SIGMA_PROJECTIVE_CORE','S61_MARKED_SIGMA_ZERO_H_REMOVAL'],'有限hの全点で必要な階数被覆は未証明。')
add('S61_PROJECTIVE_TOP_CYCLE','元135式の三次元基本サイクル','元135式の一般射影ファイバーの三次元サイクルは65[B]+5[F]。次数は30と70、全体2300、t=0商2270。一般三切断のt作用も決定した。',['S61_PROJECTIVE_TOP_CYCLE'],['S61_AFFINE_SURFACE_BOUND'],'アフィン部分の長さを数えない。')
add('S61_FIXED_PAIR_SINGLE_COLON','座標二つを固定した有限な射影候補','一般βで(u6,u42)の任意の固定値に対し、二乗t²による一度のコロンで元135射影式の全曲線が消え、零次元以下になる。',['S61_FIXED_PAIR_SINGLE_COLON'],['S61_PROJECTIVE_TOP_CYCLE','S61_AFFINE_TWO_COORDINATE_PROJECTION'],'有限候補の長さと残存する無限遠点は未確定。')
add('S61_AFFINE_HOMOGENIZER_FINITE_ACTION','全20法線方向での斉次化変数の有限作用','191生成表示の作用の交換関係を課し、指定開の各方向においてtの191乗の階数からアフィン部分の長さを正確に回収する。',['S61_AFFINE_HOMOGENIZER_FINITE_ACTION'],['S61_AFFINE_FIXED_PAIR_UNIVARIATE'],'全方向にわたる解の総数は未確定。')
intro='''v60では、**元の二座標を任意の値に固定した一般一次ジェット上で、元135式から零次元の射影候補を得た**。斉次化変数の二乗による一度のコロンで全ての曲線が消える。固定前の三次元サイクルは二つの無限遠成分からなり、重複度と次数から全次数2300を得る。有限候補には無限遠の点が残り得る。

真の境界曲線が会う有限点の剰余次数は10以上で、未知曲面があれば指定因子との交叉数は20以上になる。指定平方旗では純三次端点の因子と、剰余次数15の候補を一般一次ジェット上で全て除去した。未知曲面の不存在、一般五点の尽くしと成分数の上界は未証明で、被約成分数の下界は57である。

'''
current='''Current v60 additions: after fixing (u6,u42) arbitrarily over general beta,
one colon by t^2 leaves a projective scheme of dimension <=0. Some finite
infinity points can remain. The original three-cycle is 65[B]+5[F] with
degrees 30 and 70, total 2300. Every actual finite anchor has residue degree
at least 10; any hypothetical surface gives marked intersection >=20. The
pure-cubic and h=0 divisors of marked square cores are removed over general
beta. The c=2a pencil is explicit over all finite h; its point at infinity
is removed. Residual affine length and generic five-point exhaustion remain
open. Lower57. Continue after checkpoints.

'''
nexttext='''## v60 からの具体的な前進

- 固定二座標で零次元となったコロンの長さと t の可逆部分を計算する。191生成表示の作用を用いて、無限遠の有限点をアフィン部分から区別する。
- 指定因子への交叉数は曲面があれば20以上である。実局所商長の和19以下、あるいは全指定点での周囲冪零性を証明する。非平方側は a=0 と d=0 の試験直線、平方側は c=2a の有限値を調べる。
- 一般五点の尽くし、特殊一次ジェット上の成分、全体の個数と一般元の幾何を扱い、軌道・交叉・非被約構造の分類へ進める。

'''

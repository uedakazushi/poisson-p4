from pathlib import Path
import hashlib,json,subprocess
f=sorted(json.loads(Path('work/v60-files-frozen.json').read_text())+['papers/s61_first_jet_reduction_ja.pdf']);assert f==sorted(subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines());pf=json.loads(Path('work/v60-preflight.json').read_text());assert not pf['errors'];r={}
for n in f:
 if n.startswith('reports/'):
  d=json.loads(Path(n).read_text());assert d.get('all_passed');r[Path(n).stem]={k:d[k] for k in ['all_passed','accepted','seconds','review_scope','review_type'] if k in d}
hashf=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert hashf('papers/s61_first_jet_reduction_ja.pdf')==hashf('build/papers/s61_first_jet_reduction_ja.pdf')
assert not subprocess.check_output(['git','diff','--cached','--check'],text=True)
log=Path('build/papers/s61_first_jet_reduction_ja.log').read_text();assert 'Overfull' not in log and 'LaTeX Warning: There were undefined' not in log and 'LaTeX Warning: Reference' not in log and 'LaTeX Warning: Citation' not in log
src=json.loads(Path('work/v60-sources-check.log').read_text());assert src['all_passed'] and src['versions']==23
obj=dict(checkpoint='v60-s61',date='2026-11-02',all_passed=True,claim_count=6,research_files=len(f),input_hashes_checked=pf['input_hashes'],distinct_inputs_checked=pf['distinct_inputs'],completion=False,component_lower_bound=57,component_upper_bound_proved=False,checks=r,pdf=dict(pages=104,visual_qa_pages=[96,97],overfull_boxes=0,undefined_references=0,sha256=hashf('papers/s61_first_jet_reduction_ja.pdf'),note='Tracked PDF verified against clean manuscript build.'),source_integrity=src,limitations=['The user objective is not complete. The affine generic five-point exhaustion, the component upper bound, intersections and subsequent orbit classification remain open.','Every true boundary curve meets a finite marked set. The local length sufficient to rule out surfaces has not been bounded numerically. Nonzero c H11 and the marked square nonzero b1 case remain.','Archive hash validation is not a new full mathematical replay of historical dependency chains. Numerical, proof-only and independent coefficient checks are distinguished by individual notes.','ChatGPT Library save unavailable; no Library receipt.'],files_sha256={v:hashf(v) for v in f})
p=Path('reports/V60_CHECKPOINT_AUDIT_20261102.json');p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');subprocess.run(['git','add','--',str(p)],check=True);print('audited',len(f),len(r),pf['input_hashes'])

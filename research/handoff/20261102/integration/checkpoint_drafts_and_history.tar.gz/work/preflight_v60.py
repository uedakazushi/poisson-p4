from pathlib import Path
import json, subprocess, hashlib, ast, collections, tarfile
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines());staged=set(subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines());modified=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
C=json.loads(Path('work/v60-claims-config.json').read_text());stems=set(x for c in C for x in c[3]);files=set(modified)|staged
for stem in stems:
 for root,ext in [('reports','.json'),('research/notes','.md'),('code','.py'),('code','.cpp')]:
  if root=='code':p=next((x for x in Path(root).glob('*'+ext) if x.stem.casefold()==stem.casefold()),None)
  else:p=Path(root)/(stem+ext)
  if p and p.exists():files.add(str(p))
# Include exactly the frozen reports' dependencies, keeping other ongoing research out.
for stem in stems:
 r=json.loads(Path('reports',stem+'.json').read_text())
 for key in ('input_sha256','source_sha256','primary_dependency_sha256','primary_input_sha256','input_hashes'):
  for p in r.get(key,{}):
   if p not in tracked and p in new and p.startswith(('code/','research/','reports/')):files.add(p)
files.discard('reports/V60_CHECKPOINT_AUDIT_20261102.json');files=sorted(files);errors=[];hashes=0;hcache={};rev=[];all_cases={x.casefold():x for x in set(files)|tracked}
for f in files:
 p=Path(f)
 if not p.exists():errors.append(['missing',f]);continue
 if p.suffix=='.py':ast.parse(p.read_text())
 if p.suffix=='.json':json.loads(p.read_text())
 if f.startswith('reports/'):
  r=json.loads(p.read_text());assert r.get('all_passed'),f
  for k in ['input_sha256','input_hashes','primary_input_sha256','source_sha256','primary_dependency_sha256','static_input_sha256','quartic_dependency_inputs']:
   for source,digest in r.get(k,{}).items():
    hashes+=1
    if not Path(source).is_file(): errors.append(['missing_input',f,source]);continue
    if source not in hcache:hcache[source]=hashlib.sha256(Path(source).read_bytes()).hexdigest()
    if digest!=hcache[source]:errors.append(['stale',f,source,digest,hcache[source]])
    if source not in tracked and source not in files and not source.startswith('legacy/'):
     errors.append(['unpackaged_input',f,source,all_cases.get(source.casefold())])
 if f.endswith('.tar.gz'):
  with tarfile.open(f,'r:gz') as t:
   for m in t.getmembers():
    if m.isfile():assert len(t.extractfile(m).read())==m.size
  rev.append(f)
entries=json.loads(Path('research/CLAIMS.json').read_text())['claims'];ids={x['id'] for x in entries};assert len(ids)==len(entries)
for c in entries[-len(C):]:
 for dep in c['dependencies']['claims']:assert dep in ids,(c['id'],dep)
 for p in c['proof_sources']:assert Path(p['path']).is_file()
 for f in c['verification_records']:assert f in files,f
assert json.loads(Path('research/COMPONENTS.json').read_text())['checkpoint']=='v60-s61'
r=dict(files=len(files),claims=len(C),reports=len(stems),input_hashes=hashes,distinct_inputs=len(hcache),archives_read=rev,errors=errors)
Path('work/v60-files.json').write_text(json.dumps(files,indent=2)+'\n');Path('work/v60-preflight.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));assert not errors

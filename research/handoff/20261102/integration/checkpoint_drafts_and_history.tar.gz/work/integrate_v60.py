from pathlib import Path
import json
exec(Path("work/v60-config.py").read_text())
shared=['AGENTS.md','README.md','RESEARCH_POLICY.md','research/STATE.md','research/NEXT_TASKS.md','code/S61_README.md','research/notes/README.md','papers/README.md']
for name in shared:
 p=Path(name);p.write_text(p.read_text().replace('v59-s61','v60-s61'))
for name in ['RESEARCH_POLICY.md']:
 p=Path(name);p.write_text(p.read_text().replace('日付：2026年11月1日','日付：2026年11月2日',1))
for name in ['README.md','RESEARCH_POLICY.md','research/STATE.md']:
 p=Path(name);t=p.read_text();i=t.index('v59では');p.write_text(t[:i]+intro+t[i:])
p=Path('AGENTS.md');t=p.read_text();i=t.index('Current v59 additions:');p.write_text(t[:i]+current+t[i:].replace('Current v59 additions:','Previous v59 additions:',1))
p=Path('research/NEXT_TASKS.md');t=p.read_text();a=t.index('## v59 から');b=t.index('## 具体的な開始点',a);p.write_text(t[:a]+nexttext+t[b:])
r=json.loads(Path('research/CLAIMS.json').read_text());r.update(checkpoint='v60-s61',date='2026-11-02');ids={x['id'] for x in r['claims']}
for ident,title,statement,stems,deps,limit in C:
 assert ident not in ids
 r['claims'].append(dict(id=ident,title_ja=title,statement_ja=statement,scope='Exactly the pointwise, generic-open, all-degree or finite-model scope stated in each proof note.',status=dict(proof='proof_with_exact_certificates_and_explicit_dependencies',independent_review='scope_recorded_in_separate_review_notes_or_exact_cross_checks',certificates='reproduced_2026_11_02',novelty='not_independently_established'),dependencies=dict(claims=deps,external=[]),proof_sources=[dict(path=f'research/notes/{x}.md') for x in stems],verification_records=[f'reports/{x}.json' for x in stems],limitations_ja=[limit]))
Path('research/CLAIMS.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
r=json.loads(Path('research/COMPONENTS.json').read_text());r.update(checkpoint='v60-s61',date='2026-11-02');Path('research/COMPONENTS.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
r=json.loads(Path('papers/SOURCE_INDEX.json').read_text());r.update(current_checkpoint='v60-s61',current_research_checkpoint='v60-s61');r['v60_first_jet_sources']=dict(claims=[x[0] for x in C],notes=[f'research/notes/{x[3][0]}.md' for x in C]);r['current_manuscripts'][0]['claims'] += [x[0] for x in C];Path('papers/SOURCE_INDEX.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
for name in ['research/notes/README.md','code/S61_README.md','papers/README.md']:
 p=Path(name);t=p.read_text()+'\n## v60: 有限射影候補、境界の剰余次数と平方旗因子\n\n'
 for _,title,_,stems,_,_ in C:t+='- '+title+': `'+stems[0]+'`。適用範囲と未解決部分を各ノートに明記。\n'
 p.write_text(t)
Path('work/v60-claims-config.json').write_text(json.dumps(C,ensure_ascii=False,indent=2)+'\n')
print('v60 prepared',len(C))

from pathlib import Path
import json,zipfile,hashlib,io
r=json.loads(Path('work/v60-bundle-receipt.json').read_text());p=Path(r['path'])
assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None
 mn=next(n for n in z.namelist() if n.endswith('/BUNDLE_MANIFEST.json'));prefix=mn.rsplit('/',1)[0]+'/'
 m=json.loads(z.read(mn));n=0
 for f in m['files']:
  data=z.read(prefix+f['path']);assert len(data)==f['size_bytes'];assert hashlib.sha256(data).hexdigest()==f['sha256']
  if f['path'].startswith('sources/') and f['path'].endswith('.zip'):
   with zipfile.ZipFile(io.BytesIO(data)) as source:assert source.testzip() is None
   n+=1
 assert n==23
 names={f['path'] for f in m['files']}
 for f in m['files']:
  if f['path'].startswith('reports/') and f['path'].endswith('.json') and ('20261101' in f['path'] or '20261102' in f['path']):
   r0=json.loads(z.read(prefix+f['path']))
   for key in ['input_sha256','source_sha256','files_sha256']:
    for rel in r0.get(key,{}):
     if '/' in rel:assert rel in names or rel.startswith(('legacy/','work/')),(f['path'],rel)
r.update(all_passed=True,manifest_files_verified=len(m['files']),nested_source_archives_verified=n)
Path('work/v60-bundle-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

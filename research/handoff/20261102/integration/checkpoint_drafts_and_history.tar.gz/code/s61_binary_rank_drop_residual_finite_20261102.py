#!/usr/bin/env python3
"""Remove the artificial unipotent normalization and bound residual rank-drop points."""
import argparse
import hashlib
import json
import time
from pathlib import Path
import sympy as s
ROOT=Path(__file__).resolve().parents[1]
STEM='S61_BINARY_RANK_DROP_RESIDUAL_FINITE_20261102'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def certificate():
    start=time.monotonic();hs={}
    def load(stem):
        p=Path('reports')/(stem+'.json');j=json.loads((ROOT/p).read_text())
        assert j['all_passed'];hs[str(p)]=sha(ROOT/p);return j
    tr=load('S61_BINARY_HYPERPLANE_TRANSVERSE_CODIMENSION_20261102')
    act=load('S61_BINARY_NUISANCE_CONTRACTION_20261102')
    unif=load('S61_BINARY_UNIFORM_RANK_20261101')
    seven=load('S61_BINARY_DEEPER_SEVEN_SLICE_20261101')
    kl=load('S61_BINARY_DEEPER_REDUCTION_20261101')
    table=load('S61_BINARY_RANK_DROP_COVER_20261101')
    c0=load('S61_BINARY_RANK_DROP_FAMILY_20261101')
    ends=load('S61_BINARY_ENDPOINTS_20261101')
    ci=load('S61_BINARY_CODIM_TWO_FORMAL_20261101')
    assert tr['exceptional_core_dimension_upper']==1 and tr['relative_module_rank_on_zero_nuisance_section']==65
    ids=[4,5,12,13,14,25,26,27,34,35,36,37,48,49,50,51]
    u=s.symbols('u1:62');vec=s.Matrix([u[i-1] for i in ids])
    a,b,c,d,e,f=[u[i-1] for i in [4,14,35,36,49,50]]
    nu=[5,25,26,27,34,37,48,51];core=[4,14,35,36,49,50]
    weights=act['parameter_weights'];nw=[weights[i-1] for i in nu]
    assert nw==[2,4,2,4,2,2,2,2] and all(weights[i-1]==0 for i in core)
    assert sorted(nu+core+[12,13])==ids and act['equations_checked']==135
    x,z,t=s.symbols('x z t',nonzero=True);L=5*b-e
    M=s.Matrix.hstack(*[s.Matrix(v).applyfunc(s.sympify) for v in unif['primitive_actions']])
    tor={v:v*x**(-2*M[i,4]/v).cancel()*z**((M[i,2]+2*M[i,4])/v).cancel() for i,v in enumerate(vec)}
    assert all(s.cancel(tor[v]/v).as_powers_dict().get(w,0)==ww[i] for i,v in enumerate(vec) for w,ww in [(x,seven['torus_x_weights']),(z,seven['torus_z_weights'])])
    par={x:L,z:1/c};norm={v:w.subs(par,simultaneous=True).cancel() for v,w in tor.items()}
    assert norm[c]==1 and s.cancel(L.subs(norm,simultaneous=True)-1)==0
    assert s.cancel(norm[f].subs(f,-5*c)+5)==0
    ug=[s.Matrix(unif['stabilizer_generators'][i]) for i in [0,1,3]]
    # On homogeneous coordinates (x,y,z,w), each A maps span(x,w) to span(y,z)
    # and kills span(y,z); composing any two gives zero. I+sum(t_i*A_i) fixes Q0.
    assert all(A*B==s.zeros(4) for A in ug for B in ug)
    assert all(A[i,j]==0 for A in ug for i in range(4) for j in range(4) if i not in [1,2] or j not in [0,3])
    assert s.Matrix.hstack(*[A.reshape(16,1) for A in ug]).rank()==3
    J=s.diag(s.Matrix([[0,1],[-1,0]]),s.Matrix([[0,1],[-1,0]]))
    tvec=s.symbols('t0:3');g=s.eye(4)+sum((ti*A for ti,A in zip(tvec,ug)),s.zeros(4))
    assert (g.T*J*g-J).applyfunc(s.expand)==s.zeros(4)
    rep=[M[:,i].jacobian(vec) for i in [0,1,3]]
    assert all(v*w==w*v for v in rep for w in rep)
    N=sum((ti*A for ti,A in zip(tvec,rep)),s.zeros(16))
    assert N**4==s.zeros(16)
    value=(s.eye(16)+N+N**2/2+N**3/6)*vec
    sub={u[11]:0,u[12]:0,f:-5*c}
    for i in core+[12,13]:
        assert s.expand((value[ids.index(i)]-u[i-1]).subs(sub))==0
    assert [x['joint_image_dimension'] for x in table['orbit_strata']]==[18,17,17]
    assert len(table['prime_ideals'])==5
    img={s.Symbol(k):s.sympify(v) for k,v in table['finite_symmetry_core_images'].items()}
    assert s.expand((5*c+f).subs(img,simultaneous=True)-L)==0 and s.expand(L.subs(img,simultaneous=True)-(5*c+f))==0
    assert kl['excluded_components'][0]['ideal_index']==0 and kl['excluded_components'][0]['beta_image_dimension_upper_bound']==15
    assert c0['joint_image_dimension']==17
    assert all(i['generic_fixed_beta_stratum_removed'] and i['joint_image_dimension']==16 and set(['u35','u50'])<=set(i['beta_constraints']) for i in ends['cases'])
    assert all(i['ambient_nilpotence_on_nonempty_open'] and i['joint_image_dimension']==17 for i in ci['cases'])
    for x in [Path(__file__).relative_to(ROOT),Path('research/notes')/(STEM+'.md'),Path(ends['proof_note']),Path(ci['proof_note']),Path('research/notes/S61_HOMOGENIZED_EQUIVARIANCE_20261101.md')]:
        hs[str(x)]=sha(ROOT/x)
    return dict(id=STEM,all_passed=True,open_core_complement_dimension_upper=1,unrestricted_normalized_source_dimension=11,
                nuisance_indices_one_based=nu,nuisance_weights=nw,unipotent_group_dimension=3,core_fixed_under_unipotents=True,
                torus_normalization=['x=5b-e','z=1/c'],relative_free_rank_at_good_zero_nuisance_section=65,relative_base_dimension=14,
                residual_joint_dimension_upper=10+8+1-3,number_of_rank_drop_prime_presentations=5,symmetry_reduced_presentations=3,
                full135_projective_jacobian_rank_upper_in_scope=34,generic_beta_residual_rank_drop_dimension_upper=0,
                residual_finite_over_general_beta=True,residual_empty_proved=False,ordinary_rank35_included=False,
                square_binary_included=False,full_S61_exhaustion_claimed=False,input_sha256=hs,seconds=time.monotonic()-start)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    r=certificate()
    with args.output.open('x')as f:json.dump(r,f,indent=2);f.write('\n')
    print(f"PASS: eight nuisance weights {r['nuisance_weights']}, joint dimension at most 16; {r['seconds']:.3f} s")

from pathlib import Path
import sys,time,pickle,itertools,functools,os,subprocess
import sympy as s
from sympy.polys.rings import ring
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'code'))
from s61_binary_zero_pair_stratum_removal_20261102 import write_quartics,compile_span
from s61_binary_endpoint_full_transverse_20261102 import CUTS,PRIME,A,monomials
wd=Path('/tmp/h11-d-zero-pencil-20261102')
start=time.monotonic();r,w,g,_=pickle.load((wd/'raw.pickle').open('rb')); blocks=pickle.load((wd/'smith.pickle').open('rb'))
free_weights=[]
for grade,(ii,jj,D,U,V)in enumerate(blocks,1):
 for i in range(len(jj)):
  if i>=min(D.shape) or not D[i,i] or not D[i,i].is_Rational:
   free_weights.append(grade)
assert free_weights==[1]*7+[2]*2
rr,*v=ring('a,'+','.join('x'+str(i)for i in range(len(free_weights))),s.GF(PRIME))
@functools.lru_cache(None)
def cv(expr):
 expr=s.Poly(expr,A,domain=s.QQ);out=rr.zero
 for (i,),c in expr.terms():
  coef=int(c.p)*pow(int(c.q),-1,PRIME)%PRIME
  out+=rr(coef)*v[0]**i
 return out
coords=[rr.zero]*47
@functools.lru_cache(None)
def product_of(mon):
 out=rr.one
 for j in mon:out=out*coords[j]
 return out
def ev(row,maxorder=4):
 out=rr.zero
 for m,c in row.items():
  if all(coords[j] for j in m):out+=cv(c)*product_of(m)
 return out
counter=0
for grade,(ii,jj,D,U,V)in enumerate(blocks,1):
 vals=[ev(r[i])for i in ii]
 rz=[sum((cv(c)*val for c,val in zip(row,vals)if c and val),rr.zero)for row in U.tolist()]
 tmp=[]
 for j in range(len(jj)):
  if j<min(D.shape)and D[j,j] and D[j,j].is_Rational:tmp.append(-rz[j]*cv(1/D[j,j]))
  else:counter+=1;tmp.append(v[counter])
 rrvals=[sum((cv(c)*val for c,val in zip(row,tmp) if c and val),rr.zero) for row in V.tolist()]
 for j,z in zip(jj,rrvals):coords[j]=z
 print('grade',grade,'left',counter,'size',sum(len(z)for z in rrvals),'sec',time.monotonic()-start,flush=True)
res=[ev(row)if grade<=4 else rr.zero for row,grade in zip(r,g)]
print('raw residual counts',sum(len(z)for z in res),'sec',time.monotonic()-start,flush=True)
with (wd/'res.pkl').open('wb')as f:pickle.dump([{mon:int(c) for mon,c in z.items()}for z in res],f)
rows=write_quartics(wd/'matrix4',res,free_weights,g)
print('input',rows,(wd/'matrix4').stat().st_size,flush=True)

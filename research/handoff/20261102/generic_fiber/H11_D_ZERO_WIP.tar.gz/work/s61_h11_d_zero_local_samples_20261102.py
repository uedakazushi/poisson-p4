import sys,subprocess,inspect,pickle,time
from pathlib import Path
import sympy as sp
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'code'))
import s61_binary_endpoint_full_transverse_20261102 as src
wd=Path('/tmp/h11-d-zero-pencil-20261102')
r,w,g,bl=pickle.load((wd/'raw.pickle').open('rb'))
def program(rows,sub):
 ids=[i for i in range(47)if i not in src.CUTS]
 def exp(row):
  parts=[]
  for m,c in row.items():
   val=sp.Rational(c.subs(sub))
   coef=int(val.p)*pow(int(val.q),-1,32003)%32003
   if coef:parts.append(str(coef)+''.join('*x'+str(i)for i in m))
  return '+'.join(parts)or '0'
 return 'R=(ZZ/32003)['+','.join('x'+str(i)for i in ids)+',Degrees=>{'+','.join(str(w[i])for i in ids)+'}];I=ideal('+','.join(exp(row)for row in rows)+');print toString hilbertSeries(R/I,Reduce=>true);'
for name,m in [('zero',0),('root1',sp.Rational(-19,5)),('root2',sp.Rational(49,25)),('infty',None)]:
 if m is None:
  orig=inspect.getsource(src.original_transversal);txt=orig.replace('3:A,13:B,35:D,48:E,11:normal[0],12:normal[1]','3:-sp.Rational(1,24),13:sp.Rational(1,9),34:1,35:0,48:sp.Rational(5,9),49:-5,11:normal[0],12:normal[1]')
  gb=dict(vars(src));exec(txt,gb);rows,_,_,_,_=gb['original_transversal']();sub={}
 else:rows=r;sub={src.A:m}
 fn=wd/(name+'.m2');fn.write_text(program(rows,sub))
 result=subprocess.run(['M2','--script',str(fn)],capture_output=True,text=True,timeout=30)
 print(name,result.returncode,result.stdout.strip()[-350:],result.stderr[:100],flush=True)

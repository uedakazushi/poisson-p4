from pathlib import Path
import sys,inspect,itertools,time,subprocess,os,pickle
import sympy as sp
root=Path.cwd();sys.path.insert(0,str(root/'code'))
import s61_binary_endpoint_full_transverse_20261102 as src
from s61_binary_zero_pair_stratum_removal_20261102 import write_quartics,compile_span
P=src.PRIME
delta=sp.Rational(-7,5)
wd=Path('/tmp/h11-d-zero-pencil-20261102');wd.mkdir(exist_ok=True)
def raw():
  orig=inspect.getsource(src.original_transversal)
  src_copy=orig.replace('3:A,13:B,35:D,48:E,11:normal[0],12:normal[1]',
     '3:(delta-A**2)/24,13:(5*A+10)/45,34:1,35:0,48:(5*A+1)/9,49:-5,11:normal[0],12:normal[1]')
  glob=dict(vars(src),delta=delta)
  assert src_copy!=orig
  exec(src_copy,glob)
  r,w,g,_,_=glob['original_transversal']()
  return r,w,g
def rank_profile(rows,weights,grades):
  out=[]
  for grade in range(1,5):
    ii=[j for j,g in enumerate(grades) if grade==g]
    jj=[j for j,w in enumerate(weights) if w==grade and j not in src.CUTS]
    M=sp.Matrix([[rows[i].get((j,),0)for j in jj]for i in ii])
    blocks=[]
    for m in [0,1,2]:
      mat=M.subs(src.A,m)
      cs=list(mat.to_DM().rref()[1]);rr=list(mat[:,cs].T.to_DM().rref()[1]);det=sp.factor(M.extract(rr,cs).det(method='domain-ge'))
      print('grade',grade,'m',m,'rank',len(rr),'factor',det,flush=True)
      blocks.append(([ii[k]for k in rr],[jj[k] for k in cs],det))
    out.append(blocks)
  return out
if __name__=='__main__':
 r,w,g=raw();bl=rank_profile(r,w,g)
 with (wd/'raw.pickle').open('wb')as f:pickle.dump((r,w,g,bl),f)

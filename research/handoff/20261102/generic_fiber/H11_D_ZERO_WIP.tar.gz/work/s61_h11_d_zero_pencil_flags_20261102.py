import sys,json,itertools,subprocess,os,hashlib
from pathlib import Path
import sympy as s
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'code'))
from primitive_jet_elliptic_curve_20261101 import primitive_beta
from s61_model import S61
from weight1_structure import COORDS,J
from s61_marked_sigma_core_axis_engine_20261102 import build_axis
wd=Path('/tmp/h11-d-zero-pencil-20261102')
m=S61();y,u,tt=primitive_beta(m); y=s.Matrix(y);vec=lambda f:s.Matrix([f[i,j].diff(y[k])for (i,j),k in COORDS]);basis=vec(tt).jacobian(u);piv=list(basis.T.to_DM().rref()[1]);get=lambda M:(basis[piv,:].inv()*vec(M)[piv,:]).applyfunc(s.factor)
flag=json.load(open('reports/S61_FLAG_UNIFORM_OPEN_20261101.json'));FH=s.Matrix(flag['flag']['beta_kernel']).applyfunc(s.Rational)
core=s.zeros(15,1)
core[3],core[12],core[5],core[6],core[14]=s.Rational(4,5),1,1,3,2
beta=tt.subs(dict(zip(u,FH*core)));v=s.symbols('m')
ex=s.eye(4);ex[2,2]=ex[3,3]=0;ex[2,3]=-1;ex[3,2]=1
U=s.Matrix([[-s.Rational(5,18),s.Rational(10,3)],[s.Rational(1,3),0]])*s.Matrix([[1,0],[-v/12,1]])
sg=s.diag(-1,1);V=sg*U.inv().T*sg;g=s.zeros(4)
for ij,Q in [([0,3],V),([1,2],U)]:
 for i,j in itertools.product(range(2),repeat=2):g[ij[i],ij[j]]=Q[i,j]
g=ex*g
assert (g.T*J*g-J).applyfunc(s.expand)==s.zeros(4)
pulled=get(g.T*beta.subs(dict(zip(y,g*y)),simultaneous=True)*g)
print('beta',list(zip(u,pulled)),flush=True)
assert s.expand(pulled[0]-(s.Rational(-7,5)-v*v)/24)==0 and s.expand(pulled[4]-(5*v+10)/45)==0 and pulled[9]==1 and pulled[10]==0 and s.expand(pulled[13]-(5*v+1)/9)==0 and pulled[14]==-5
assert all(pulled[i]==0 for i in [1,2,3,5,6,7,8,11,12,15])
q=s.zeros(4);q[1,2]=y[0]*y[3];q-=q.T
push=(g*q.subs(dict(zip(y,g.inv()*y)),simultaneous=True)*g.T).applyfunc(s.factor)
print('pushed',push,'sec slope',push.diff(v),flush=True)
# prime-specific central support, retaining rho.
old=json.load(open('reports/S61_MARKED_SIGMA_RESIDUAL_FINITE_20261102.json'))
names,weights,polynomials,frame=build_axis(core,[9,19,27],old['frame']['q_weights'])
def encode(poly):
 terms=[]
 for mon,val in poly.items():
  p=s.Rational(val);n=int(p.p)*pow(int(p.q),-1,32003)%32003
  if n:terms.append(str(n)+''.join('*'+a+('^'+str(e)if e>1 else '')for a,e in zip(names,mon)if e))
 return '+'.join(terms)or'0'
program='R=(ZZ/32003)['+','.join(names)+',Degrees=>{'+','.join(map(str,weights))+'}];I=ideal('+','.join(encode(p)for p in polynomials if p)+');\n'
program+='''P=ideal apply(0..12,i->R_i);A=saturate(I,ideal(rho));U=I+ideal(rho);
assert(dim(R/I)==1 and dim(R/U)==0 and numColumns basis(R/U)==76);
assert(radical A==P and A==saturate(A,ideal(rho)));assert(numColumns basis(R/(A+ideal(rho)))==31);
assert(v12^2%I==0);print(toString hilbertSeries(R/I,Reduce=>true));'''
path=wd/'actual-infinity-p.m2';path.write_text(program)
env=os.environ|{'DYLD_LIBRARY_PATH':str(ROOT/'work/m2-runtime/lib')+':/opt/homebrew/lib'}
rr=subprocess.run(['M2-binary','--script',str(path)],env=env,capture_output=True,text=True,timeout=70)
print('actual Fp flag axis',rr.returncode,rr.stdout[-250:],rr.stderr[-150:],flush=True)

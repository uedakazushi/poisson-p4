import pickle,sys,time
from pathlib import Path
import sympy as s
from sympy.matrices.normalforms import smith_normal_decomp
from sympy.polys.matrices import DomainMatrix
wd=Path('/tmp/h11-d-zero-pencil-20261102')
r,w,g,_=pickle.load((wd/'raw.pickle').open('rb'))
cut=[5,19,20,23,27]
A=s.Symbol('a');out=[]
for k in range(1,5):
 ii=[j for j,l in enumerate(g)if l==k];jj=[j for j,l in enumerate(w)if l==k and j not in cut]
 MM=s.Matrix([[r[i].get((j,),0)for j in jj]for i in ii])
 d=s.QQ.poly_ring(A)
 now=time.time();S,U,V=smith_normal_decomp(MM,domain=d); print(k,MM.shape,'sec',time.time()-now,'diag',[s.factor(x)for x in S.diagonal()if x],'umax',max((s.degree(x,A)for x in U if x!=0),default=0),'vmax',max((s.degree(x,A)for x in V if x!=0),default=0),flush=True)
 assert (U*MM*V-S).applyfunc(s.expand)==s.zeros(*MM.shape)
 out.append((ii,jj,S,U,V))
with (wd/'smith.pickle').open('wb')as f:pickle.dump(out,f)
